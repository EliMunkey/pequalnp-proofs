import Q1020K12L1S0Local
import Q1020K12L2S0
import Q1020K12L2S1
import Q1020K12L2S2
import Q1020K12L2S4
import Q1020K12L2S5
import Q1020K12L2S6
import Q1020K12L2S9
import Q1020K12L2S10
import Q1020K12L2S11
import Q1020K12L2S12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L1S0Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b1_3 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_3 := by
  apply PetersenIndexedNode.close (bank := [s2_37,s2_36,a121,a122,a123,s2_244,s2_430,s2_245,s2_71,s2_69,a124,a125,a126,s2_251,s2_488,s2_252,s2_202,s2_201,a127,a128,a129,s2_257,a130,s2_258,a131,a132,s2_31,s2_30,a133,a134,a135,a136,a137,a138,s2_25,s2_24,a139,a140,a141,a142,s2_6,s2_1,a143,s2_267,s2_266,a144,a145,a146,a147,a148,a149,a150,a151,a152,s2_277,s2_276,s2_237,a153,a154,s2_253,s2_238,a155,a156,s2_259,s2_239,s2_230,a157,s2_261,s2_240,s2_222,a158,a159,s2_241,a160,a161,s2_268,s2_242,a162,a163,a164,s2_243,s2_41,a165,s2_273,s2_246,a166,a167,s2_260,a168,s2_231,a169,s2_262,s2_247,s2_223,a170,s2_264,s2_248,a171,a172,s2_269,s2_249,s2_219,a173,s2_271,s2_250,s2_77,a174,s2_274,a175,s2_232,a176,s2_263,s2_254,s2_224,a177,s2_265,s2_255,a178,a179,a180,s2_278,s2_270,a181,a182,a183,a184,s2_256,s2_203,a185,s2_275,a186,s2_225,s2_233,a187,a188,a189,s2_234,a190,a191,a192,s2_235,a193,a194,a195,s2_236,a196,a197,a198,s2_227,s2_226,a199,a200,a201,a202,s2_228,a203,a204,a205,s2_229,a206,a207,a208,a209,a210,a211,s2_220,s2_221,a212,a213,a214,a215]) (PetersenIndexedNode.reasons 256 17 556 0x8054b1110840442028054210118504c202805531111850484448053a1010840442028053402960148a000801bc00d94100a0808016210120056840480511888941006222805090809c1804202805198889c180622280501080941004202804f24040a0809000804ea101121009000804fa404121009010804e21010a0808404804d1404121005000804c90808a0805000804d94040a0805010804c1080921004202804ac0250a08050408049a8200e0c07060804bc0258e0c07060804928200a080504080482303050408c048047a1011918084048048a30319180840c804721010504084048046120205040480080459080890804800804692020908048088045108085040420280442a220908048408043a8200504028208044aa220504028208043282009080484080422622050402820804194100706038208042a622070602830804114100504028208040210100c048400803fa4041090084008040a101109008404803f240400c040602803e130300c040602803d9080989804202803e930318980480c803d108080c040602803bc01d80c040602803aa82004c442622803cc01e04c442622803a282000c0406028039151100c0406028038941002c2416028039951102c2406128038141000c04060280370b0900c04060280368a0801c140e0280378b0901c14060a80360a0800c040602803524848060203018034a1011070283018035a4849070290128034210100602030180331080806024200803292020848042008033908088480420280321202006020301803128a08060203018030a82004c4826248031a8a084c48262480302820006020301802f24a0806020301802e9410026221301802fa4a0826220311802e1410006020301802d0a88806020301802c8a08016120b01802d8a88816120309802c0a08006020301802b0180806020600802aa12000c080600802b818080c080602802a2120006020301802921414060403028028a1011070483028029a1415070484058028210100604030280271242406040302802690808c2c04202802792424c2c0480980261080806040302802528604060403028024a8200424021208025a86044240212080242820006040302802314504060403028022941002624130280239450426240312802214100060403028021125040604030280208a08016140b028021925041614030a80200a08006040302801f2160406040302801e818084a480602801fa16044a482124801e0180806040302801d00c0442400300801c8181006040300801d80c0406040301801c0181042400604801bc00da006aa0208014a10120050840480191888a0062622280181080a005e4202801a1888a0066622280171080a005a42028016400ae005421018014a82020050210180129c182004870608011941020044504080139c182004c706080109410200405040800e8a08200382820800d9210200344840800f8a082003c2820800c9210200304840800a8988a0028262280098180a00240602800b8988a002c262280088180a0020060280068989200182624800580c0600140301800789892001c2624800480c060010030180028848200082120800180c0a00040302800388482000c2120800080c0a00000302)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b2_37 theta
    · exact b2_36 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_31 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_30 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_422 theta)
    · exact b2_244 theta
    · exact b2_430 theta
    · exact b2_245 theta
    · exact b2_71 theta
    · exact b2_69 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_11 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_10 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_464 theta)
    · exact b2_251 theta
    · exact b2_488 theta
    · exact b2_252 theta
    · exact b2_202 theta
    · exact b2_201 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_25 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_24 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_386 theta)
    · exact b2_257 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_434 theta)
    · exact b2_258 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_37 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_36 theta)
    · exact b2_31 theta
    · exact b2_30 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_422 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_244 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_430 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_245 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_202 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_201 theta)
    · exact b2_25 theta
    · exact b2_24 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_386 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_257 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_434 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_258 theta)
    · exact b2_6 theta
    · exact b2_1 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_478 theta)
    · exact b2_267 theta
    · exact b2_266 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_71 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_69 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_11 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_10 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_464 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_251 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_488 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_252 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_529 theta)
    · exact b2_277 theta
    · exact b2_276 theta
    · exact b2_237 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_204 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_235 theta)
    · exact b2_253 theta
    · exact b2_238 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_225 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_233 theta)
    · exact b2_259 theta
    · exact b2_239 theta
    · exact b2_230 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_230 theta)
    · exact b2_261 theta
    · exact b2_240 theta
    · exact b2_222 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_232 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_263 theta)
    · exact b2_241 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_205 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_234 theta)
    · exact b2_268 theta
    · exact b2_242 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_43 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_231 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_262 theta)
    · exact b2_243 theta
    · exact b2_41 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_236 theta)
    · exact b2_273 theta
    · exact b2_246 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_228 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_206 theta)
    · exact b2_260 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_242 theta)
    · exact b2_231 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_43 theta)
    · exact b2_262 theta
    · exact b2_247 theta
    · exact b2_223 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_50 theta)
    · exact b2_264 theta
    · exact b2_248 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_89 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_79 theta)
    · exact b2_269 theta
    · exact b2_249 theta
    · exact b2_219 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_219 theta)
    · exact b2_271 theta
    · exact b2_250 theta
    · exact b2_77 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_115 theta)
    · exact b2_274 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_240 theta)
    · exact b2_232 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_222 theta)
    · exact b2_263 theta
    · exact b2_254 theta
    · exact b2_224 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_224 theta)
    · exact b2_265 theta
    · exact b2_255 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_48 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_227 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_226 theta)
    · exact b2_278 theta
    · exact b2_270 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_247 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_50 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_223 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_264 theta)
    · exact b2_256 theta
    · exact b2_203 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_229 theta)
    · exact b2_275 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_238 theta)
    · exact b2_225 theta
    · exact b2_233 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_259 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_241 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_205 theta)
    · exact b2_234 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_268 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_237 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_204 theta)
    · exact b2_235 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_253 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_243 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_41 theta)
    · exact b2_236 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_273 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_255 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_48 theta)
    · exact b2_227 theta
    · exact b2_226 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_278 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_270 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_246 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_206 theta)
    · exact b2_228 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_260 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_256 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_203 theta)
    · exact b2_229 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_275 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_248 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_79 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_89 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_269 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_220 theta)
    · exact b2_220 theta
    · exact b2_221 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_250 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_77 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_115 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_274 theta)
end Orbits1020Cost12
