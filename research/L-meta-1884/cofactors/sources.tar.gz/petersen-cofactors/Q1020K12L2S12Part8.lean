import Q1020K12L2S12Local
import Q1020K12L3S0
import Q1020K12L3S5
import Q1020K12L3S6
import Q1020K12L3S33
import Q1020K12L3S34
import Q1020K12L3S37
import Q1020K12L3S38
import Q1020K12L3S39
import Q1020K12L3S40
import Q1020K12L3S46
import Q1020K12L3S52
import Q1020K12L3S55
import Q1020K12L3S63
import Q1020K12L3S64
import Q1020K12L3S69
import Q1020K12L3S70
import Q1020K12L3S71
import Q1020K12L3S79
import Q1020K12L3S80
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L2S12Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b2_524 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_524 := by
  intro m le c
  apply rejects_sound extra26 i7 10 tgt (small26 theta) hot26 [(false,(4,true),(6,true))] s2_524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000,0xcccccccccccccccccccccccccccccccc,0xffffffffffffffff0000000000000000,0xffffffffffffffffffff0000ffff0000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0] (PetersenWireProjection.cons stored7 (PetersenWireProjection.cons stored6 (PetersenWireProjection.cons stored5 (PetersenWireProjection.cons stored4 (PetersenWireProjection.cons stored3 (PetersenWireProjection.cons stored2 (PetersenWireProjection.cons pc26w31 (PetersenWireProjection.cons stored1 (PetersenWireProjection.cons stored0 rfl))))))))) (by decide +kernel)
theorem b2_525 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_525 := by
  intro m le c
  apply rejects_sound extra30 i7 10 tgt (small30 theta) hot30 [(false,(3,true),(0,true))] s2_525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00,0x0,0xcccccccccccccccccccccccccccccccc,0xffffffffffffffff0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xffffffff00000000ffffffff00000000] (PetersenWireProjection.cons stored15 (PetersenWireProjection.cons stored14 (PetersenWireProjection.cons stored13 (PetersenWireProjection.cons stored12 (PetersenWireProjection.cons stored11 (PetersenWireProjection.cons stored10 (PetersenWireProjection.cons pc30w40 (PetersenWireProjection.cons stored9 (PetersenWireProjection.cons stored8 rfl))))))))) (by decide +kernel)
theorem b2_526 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_526 := by
  intro m le c
  apply rejects_sound extra34 i7 10 tgt (small34 theta) hot34 [(false,(0,true),(2,true))] s2_526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccccccccccccccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00,0x0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xfafafafafafafafafafafafafafafafa,0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons stored23 (PetersenWireProjection.cons stored22 (PetersenWireProjection.cons stored21 (PetersenWireProjection.cons stored20 (PetersenWireProjection.cons stored19 (PetersenWireProjection.cons stored18 (PetersenWireProjection.cons pc34w44 (PetersenWireProjection.cons stored17 (PetersenWireProjection.cons stored16 rfl))))))))) (by decide +kernel)
theorem b2_527 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_527 := by
  intro m le c
  apply rejects_sound extra26 i7 10 tgt (small26 theta) hot26 [(false,(4,true),(0,true))] s2_527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000,0xcccccccccccccccccccccccccccccccc,0xffffffffffffffff0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xffffaaaaffffaaaaffffaaaaffffaaaa,0xffffaaaaffffaaaaffffaaaaffffaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0] (PetersenWireProjection.cons stored7 (PetersenWireProjection.cons stored6 (PetersenWireProjection.cons stored5 (PetersenWireProjection.cons stored4 (PetersenWireProjection.cons stored3 (PetersenWireProjection.cons stored2 (PetersenWireProjection.cons stored1 (PetersenWireProjection.cons pc26w54 (PetersenWireProjection.cons pc26w53 (PetersenWireProjection.cons stored0 rfl)))))))))) (by decide +kernel)
theorem b2_528 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_528 := by
  apply PetersenIndexedNode.close (bank := [a3222,a3223,s3_2654,a3224,a3225,s3_3344,s3_2690,s3_2689,s3_2683,a3226,a3227,a3228,a3229,s3_3331,a3230,a3231,s3_1939,a3232,a3233,s3_2899,a3234,a3235,s3_20,a3236,s3_19,a3237,a3238,a3239,a3240,a3241,a3242,a3243,a3244,a3245,a3246,a3247,a3248,s3_3332,a3249,a3250,a3251,a3252,a3253,a3254,a3255,a3256,a3257,a3258,a3259,a3260,a3261,a3262,s3_2193,a3263,a3264,a3265,s3_2220,a3266,a3267,a3268,a3269,a3270,a3271,a3272,a3273,a3274,a3275,a2863,a3276,a2864,s3_21,a2424,a2867,a3277,s3_1672,a3278,s3_3353,a3279,s3_1686,a3280,s3_3337]) (PetersenIndexedNode.reasons 256 17 498 0x12425004f490921012009c8404490940141242484048026a10112425004b49092101200948404490940131242484048024a10120091003d8023c0062002d0046622210808840484046141308098888c282622221010840442028022c01120087001821011080a008500143818400588404420250100a829440484045141288094040a282501021010541484048020c00fc420300181505084060081003f801f400f454142a0a801e400ee0074622215051880884046141210118888c282422221010a82884049010282024001080890804800240412100901042021410108090038484024202006e50402820400e4a0805040801b2420121010034484024202006650402820400d4a08050408019242012100521248401480884045040210114848a080421221012420084043a1a28200e8285414706015050e868e0c02a1a15051410054148c0c1410230110808c8c04202230319180840c42020a081080900308017c00ba005a28201410400c4504028208016400ae0055002814100a082004e2a221511400a454442a2280130a08050404a0a141012808840448402101128289080420a21010a08084042a0a24200a808c282282015010a82850402a0a30a0921009080988814100a080a08038301c10262207060283028200a0805040840403012100120208480420021011090084044808018080c050024424021202004606020301400940c04060280112120109010020424021202003e06020301400840c040602800f212010901001c0301018088404c4c02101400758980c4c02101018080c046545030101808541426221301195144c4406221505018080c045444030101808a08016120b01151102c2406122820018080c042c2403010180850400e0a07010b0901c14060a1410018080c0492122120248490808c2c0420224849858092124202109010809001b800d400660030424021204005e002a2624800b109004c484202800a9080a0028424021204004e0024480a1505109005414614131301890054146260150518504848042404941109008480504080081410125050011494114100848042401511109005444282080070a0805445000f15110a080848028200301109000c0484802322119000c04464403012120084804240428280c080604840441c120c090a0a83824202a10100604030280064002e00150009018100c0a001a0302018140022000f000680020848042410003018100c0a000a030201814000842402120800000c080604420230b01080a0002616030b0108080604030230a080c0806042a0a109008c08c282212010900a8280604030228a080c0806045040098904c08a28213120189141000604030224a080c0806042820058502c0892820b0a01850a0800604030242c080c08060406021292018090b0225241092018080604030221a08848042404240018100c088682030201811090042402120)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact via sym6 fix6 (by decide +kernel) (b3_1944 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_3377 theta)
    · exact b3_2654 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_222 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2198 theta)
    · exact b3_3344 theta
    · exact b3_2690 theta
    · exact b3_2689 theta
    · exact b3_2683 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_37 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2319 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2320 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2314 theta)
    · exact b3_3331 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_1944 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_3377 theta)
    · exact b3_1939 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_3379 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2899 theta)
    · exact b3_2899 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_1435 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1435 theta)
    · exact b3_20 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_1425 theta)
    · exact b3_19 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_1597 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1598 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1592 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1939 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_3379 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2659 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_224 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2193 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_3346 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2705 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_26 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2220 theta)
    · exact b3_3332 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_2654 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_222 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2198 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_3344 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2690 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2689 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2683 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_37 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2319 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2320 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2314 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_3331 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2659 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_224 theta)
    · exact b3_2193 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_3346 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2705 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_26 theta)
    · exact b3_2220 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_3332 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2986 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2985 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2978 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_267 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1681 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1669 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1678 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1667 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_1425 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_1597 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_1598 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_1592 theta)
    · exact b3_21 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_264 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_265 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2980 theta)
    · exact b3_1672 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_269 theta)
    · exact b3_3353 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_2990 theta)
    · exact b3_1686 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_33 theta)
    · exact b3_3337 theta
end Orbits1020Cost12
