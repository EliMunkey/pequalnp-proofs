import Q1020K12L1S0Local
import Q1020K12L2S0
import Q1020K12L2S1
import Q1020K12L2S2
import Q1020K12L2S3
import Q1020K12L2S4
import Q1020K12L2S9
import Q1020K12L2S10
import Q1020K12L2S11
import Q1020K12L2S12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L1S0Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b1_0 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_0 := by
  intro m le c
  apply rejects_sound extra26 i7 10 tgt (small26 theta) hot26 [] s1_0 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000,0xcccccccccccccccccccccccccccccccc,0xffffffffffffffff0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pc26w8 (PetersenWireProjection.cons stored7 (PetersenWireProjection.cons stored6 (PetersenWireProjection.cons stored5 (PetersenWireProjection.cons stored4 (PetersenWireProjection.cons stored3 (PetersenWireProjection.cons stored2 (PetersenWireProjection.cons stored1 (PetersenWireProjection.cons stored0 rfl))))))))) (by decide +kernel)
theorem b1_1 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_1 := by
  apply PetersenIndexedNode.close (bank := [s2_35,s2_34,a92,a93,a94,s2_132,s2_429,s2_133,s2_6,s2_0,a95,s2_140,s2_139,s2_65,s2_64,a96,a97,a98,s2_147,a99,s2_148,a100,a101,s2_29,s2_28,a102,s2_155,a103,s2_156,s2_67,s2_66,s2_23,s2_22,a104,a105,s2_164,s2_163,s2_538,a106,s2_197,s2_165,s2_71,s2_68,s2_20,s2_19,a107,s2_172,a108,s2_173,s2_74,s2_72,s2_11,s2_9,a109,s2_180,a110,s2_181,a111,s2_196,s2_190,s2_125,s2_113,s2_118,s2_141,s2_126,s2_105,s2_119,s2_149,s2_127,s2_98,s2_120,s2_157,s2_128,s2_90,s2_121,s2_166,s2_129,s2_84,s2_122,s2_174,s2_130,a112,s2_123,s2_182,s2_131,s2_40,s2_124,s2_189,s2_134,s2_107,s2_106,s2_114,s2_198,s2_150,s2_135,s2_99,a113,s2_158,s2_136,s2_92,s2_91,a114,s2_199,s2_167,s2_137,s2_86,s2_85,a115,s2_200,s2_175,s2_138,s2_79,s2_115,s2_183,a116,s2_116,s2_117,s2_142,s2_100,s2_108,s2_159,s2_143,s2_93,s2_109,s2_168,s2_144,a117,s2_110,s2_176,s2_145,a118,s2_111,s2_184,s2_146,s2_75,s2_112,s2_191,s2_151,s2_94,s2_101,s2_169,s2_152,s2_87,s2_102,s2_177,s2_153,s2_80,s2_103,s2_185,s2_154,a119,s2_104,s2_192,s2_160,a120,s2_95,s2_178,s2_161,s2_81,s2_96,s2_186,s2_162,s2_76,s2_97,s2_193,s2_170,s2_82,s2_88,s2_187,s2_171,s2_77,s2_89,s2_194,s2_179,s2_78,s2_83,s2_195]) (PetersenIndexedNode.reasons 256 17 556 0x8057b11108404420280572101185048404805831111850484448056a1010840442028055a80804202a0008055210114100a0008056280814100a0208054a10104202210180539888842022101805310808c2826101805418888c2824222805290808420221018051a4040a080900080512101121009000805224041210090108050a1010a0808404804f9404121005000804f10808a0805000805014040a0805010804e9080921004202804d8c444a0803101804d08404e0c02101804e0c444e0c02111804c88404a0802101804ba303050408c04804b2101191808404804c230319180840c804aa1010504084048049920205040480080491080890804800804a12020908048088048908085040420280478a020908028008047084045040280080480a02050402808804688404908021018045a6220504028208045141007060382080462622070602830804494100504028208043a10100c04840080432404109008400804421011090084048042a40400c0406028041930300c040602804110809898042028042130318980480c8040908080c040602803f894140c042501803f084044c4421018040094144c442105803e884040c042101803d951100c040602803d141002c241602803e151102c240612803c941000c040602803b8b0900c040602803b0a0801c140e02803c0b0901c14060a803a8a0800c040602803a401ce00e48301801dc00e907028381800621012001684048038108090702420280379202185804808803890809858042028037120210702480880358a82907022a0a80350840600d2210180368a82a00d82a0a803408405070221018032a4a090702928080321410200c650408033a4a0a00cc90828031141010702504080300a88907022a22802f8a0811712282080308a88917122a22802f0a08107022820802d8180907020602802d2120200b28480802e8180a00b80602802c2120107028480802b2141406040302802aa101107048404802ba141507048405802a210100604030280291242406040302802890808c2c04202802992424c2c04809802810808060403028027084040604210080268a020424021008027884044240210180260a02006040302802514504060403028024941002624130280259450426240312802414100060403028023125040604030280228a08016140b028023925041614030a80220a08006040302802121604060403028020818084a4806028021a16044a48212480200180806040302801f20e0442402120801eb0b0006040302801fa0e0406040302801e30b0042402120801dc00ea007292128004a101200108404801b1080a006a4202801a1202200664808801c1080a006e42028019120220062480880170a82a005a2a0a8016084060056210180180a82a005e2a0a8015084060052210180124008e00450021801014102003e504080144009e004d0025800f14102003a5040800d0a88a00322a22800c0a082002e2820800e0a88a00362a22800b0a082002a282080090180a00220602800821202001e8480800a0180a00260602800721202001a848080064002e001403018004a0e0600100301800280c0a0008030280018848200042120800380c0a000c030280008848200002120)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b2_35 theta
    · exact b2_34 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_33 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_32 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_421 theta)
    · exact b2_132 theta
    · exact b2_429 theta
    · exact b2_133 theta
    · exact b2_6 theta
    · exact b2_0 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_460 theta)
    · exact b2_140 theta
    · exact b2_139 theta
    · exact b2_65 theta
    · exact b2_64 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_27 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_26 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_387 theta)
    · exact b2_147 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_432 theta)
    · exact b2_148 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_39 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_38 theta)
    · exact b2_29 theta
    · exact b2_28 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_420 theta)
    · exact b2_155 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_431 theta)
    · exact b2_156 theta
    · exact b2_67 theta
    · exact b2_66 theta
    · exact b2_23 theta
    · exact b2_22 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_385 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_384 theta)
    · exact b2_164 theta
    · exact b2_163 theta
    · exact b2_538 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_433 theta)
    · exact b2_197 theta
    · exact b2_165 theta
    · exact b2_71 theta
    · exact b2_68 theta
    · exact b2_20 theta
    · exact b2_19 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_483 theta)
    · exact b2_172 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_490 theta)
    · exact b2_173 theta
    · exact b2_74 theta
    · exact b2_72 theta
    · exact b2_11 theta
    · exact b2_9 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_465 theta)
    · exact b2_180 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_489 theta)
    · exact b2_181 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_522 theta)
    · exact b2_196 theta
    · exact b2_190 theta
    · exact b2_125 theta
    · exact b2_113 theta
    · exact b2_118 theta
    · exact b2_141 theta
    · exact b2_126 theta
    · exact b2_105 theta
    · exact b2_119 theta
    · exact b2_149 theta
    · exact b2_127 theta
    · exact b2_98 theta
    · exact b2_120 theta
    · exact b2_157 theta
    · exact b2_128 theta
    · exact b2_90 theta
    · exact b2_121 theta
    · exact b2_166 theta
    · exact b2_129 theta
    · exact b2_84 theta
    · exact b2_122 theta
    · exact b2_174 theta
    · exact b2_130 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_44 theta)
    · exact b2_123 theta
    · exact b2_182 theta
    · exact b2_131 theta
    · exact b2_40 theta
    · exact b2_124 theta
    · exact b2_189 theta
    · exact b2_134 theta
    · exact b2_107 theta
    · exact b2_106 theta
    · exact b2_114 theta
    · exact b2_198 theta
    · exact b2_150 theta
    · exact b2_135 theta
    · exact b2_99 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_45 theta)
    · exact b2_158 theta
    · exact b2_136 theta
    · exact b2_92 theta
    · exact b2_91 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_51 theta)
    · exact b2_199 theta
    · exact b2_167 theta
    · exact b2_137 theta
    · exact b2_86 theta
    · exact b2_85 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_83 theta)
    · exact b2_200 theta
    · exact b2_175 theta
    · exact b2_138 theta
    · exact b2_79 theta
    · exact b2_115 theta
    · exact b2_183 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_116 theta)
    · exact b2_116 theta
    · exact b2_117 theta
    · exact b2_142 theta
    · exact b2_100 theta
    · exact b2_108 theta
    · exact b2_159 theta
    · exact b2_143 theta
    · exact b2_93 theta
    · exact b2_109 theta
    · exact b2_168 theta
    · exact b2_144 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_46 theta)
    · exact b2_110 theta
    · exact b2_176 theta
    · exact b2_145 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_49 theta)
    · exact b2_111 theta
    · exact b2_184 theta
    · exact b2_146 theta
    · exact b2_75 theta
    · exact b2_112 theta
    · exact b2_191 theta
    · exact b2_151 theta
    · exact b2_94 theta
    · exact b2_101 theta
    · exact b2_169 theta
    · exact b2_152 theta
    · exact b2_87 theta
    · exact b2_102 theta
    · exact b2_177 theta
    · exact b2_153 theta
    · exact b2_80 theta
    · exact b2_103 theta
    · exact b2_185 theta
    · exact b2_154 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_42 theta)
    · exact b2_104 theta
    · exact b2_192 theta
    · exact b2_160 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_47 theta)
    · exact b2_95 theta
    · exact b2_178 theta
    · exact b2_161 theta
    · exact b2_81 theta
    · exact b2_96 theta
    · exact b2_186 theta
    · exact b2_162 theta
    · exact b2_76 theta
    · exact b2_97 theta
    · exact b2_193 theta
    · exact b2_170 theta
    · exact b2_82 theta
    · exact b2_88 theta
    · exact b2_187 theta
    · exact b2_171 theta
    · exact b2_77 theta
    · exact b2_89 theta
    · exact b2_194 theta
    · exact b2_179 theta
    · exact b2_78 theta
    · exact b2_83 theta
    · exact b2_195 theta
theorem b1_2 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_2 := by
  intro m le c
  apply rejects_sound extra30 i7 10 tgt (small30 theta) hot30 [] s1_2 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00,0x0,0xcccccccccccccccccccccccccccccccc,0xffffffffffffffff0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xffffffff00000000ffffffff00000000] (PetersenWireProjection.cons pc30w17 (PetersenWireProjection.cons stored15 (PetersenWireProjection.cons stored14 (PetersenWireProjection.cons stored13 (PetersenWireProjection.cons stored12 (PetersenWireProjection.cons stored11 (PetersenWireProjection.cons stored10 (PetersenWireProjection.cons stored9 (PetersenWireProjection.cons stored8 rfl))))))))) (by decide +kernel)
end Orbits1020Cost12
