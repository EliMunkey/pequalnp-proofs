import Q1020K12L2S6Local
import Q1020K12L3S0
import Q1020K12L3S3
import Q1020K12L3S4
import Q1020K12L3S5
import Q1020K12L3S6
import Q1020K12L3S7
import Q1020K12L3S8
import Q1020K12L3S10
import Q1020K12L3S19
import Q1020K12L3S23
import Q1020K12L3S27
import Q1020K12L3S30
import Q1020K12L3S38
import Q1020K12L3S39
import Q1020K12L3S40
import Q1020K12L3S57
import Q1020K12L3S62
import Q1020K12L3S65
import Q1020K12L3S66
import Q1020K12L3S69
import Q1020K12L3S70
import Q1020K12L3S72
import Q1020K12L3S74
import Q1020K12L3S79
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L2S6Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b2_281 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_281 := by
  apply PetersenIndexedNode.close (bank := [s3_423,a1402,a1403,s3_2731,s3_967,a1404,a1405,s3_3052,s3_1164,a1406,a1407,a1408,a1409,s3_362,a1410,a1411,a1412,s3_323,a1413,a1414,s3_1268,s3_286,a1415,a1416,a1417,s3_127,a1418,a1419,s3_21,s3_19,s3_6,a1420,a1421,s3_1666,a1422,s3_1669,a1423,s3_1682,s3_1634,a1424,a1425,s3_1670,s3_1621,a1426,s3_1611,a1427,a1428,s3_1642,a1429,a1430,a1431,a1432,s3_1668,a1433,s3_1683,s3_1648,a1434,a1435,s3_1671,a1436,a1437,s3_1626,a1438,a1439,a1440,s3_1617,a1441,s3_1659,a1442,s3_1608,s3_1672,a1443,a1444,a1445,a1446,a1447,a1448,s3_1681,s3_1678]) (PetersenIndexedNode.reasons 256 17 510 0x20099004b80254008e009d004d420240085080900482101108090808c2824202401258504c28242021080884050047801832222003c42022101280804202a0004202282014000a020504028081080821011080c01144202210180220a8285415004615050a82a00862101108098888420221012101185048404622230a090888840421011080a4040a0809000420224201200090104840240410808504042024010521009080802014100a0810042282014102007e908048401484921005202210114100840452122820108488404908021010c444a080310110809c18042023111383008444420250401080a303050408c0442023230108088c0c646021031080828204202400f450402820801e0a8885445003e15110a88a0076282014101282850404a0221011210084044a0a2420108288404282021010a0209080280010808a0805000280814100a020420248401080a62205040282028200e0c0704098881c180a0c0a08028201410210100c04840048082120108008404424021011202006020301400e509008480801c018080c05003a03010180a006e84804240400d40c04060221013130084050036626031300840406020301094140c04250110808988842022505131108414420206021080951100c0406022820058482c0454440b0901848a080060203010b0900c0406021410038281c042c24070501828504006020301400cc84804240420230b0108090034616030b01080842404202400ca00628381800f109008480420280189080a006042402120400be005c480a150510900541421013130084045414626015050840484802101494110900848050408016141012505002d494114100848042401511109005444282080150a0805445002b15110a080848028200301109000c0484802322119000c04464403012120084804240428280c080604840441c1210110a0a83824202a10100604030280140848042410027018100c0a0052030201814009842402120801200c080604420230b01080a004a616030b01080806040302108080c08420028081090084004202212010808a0200604030228a080c0806045040098904c08a28213120189141000604030224a080c0806042820058502c0892820b0a01850a0800604030242c080c08060406021292018090b0225241092018080604030221a08848042404240018100c0886820302018110900424021208011c008924248404800ea101200430020800fc007a003b001c2101400688404c282800cb0a088405001b210130a0a0030c28215054005854142101800a884045415001715050840600282101282040048a08090808008a4200a0810013282024202002090801511400385444282080068a0805445000f15110a082001828200301400280c0484808004a12000c05000b030121202001084802120400188480c2c08002b0b0084810007212030b020008c2c0018140008060421208000884800605000301810848200002120)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b3_423 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_362 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2613 theta)
    · exact b3_2731 theta
    · exact b3_967 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_127 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2796 theta)
    · exact b3_3052 theta
    · exact b3_1164 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_323 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2410 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2744 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_423 theta)
    · exact b3_362 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_2613 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2731 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1164 theta)
    · exact b3_323 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_2410 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2744 theta)
    · exact b3_1268 theta
    · exact b3_286 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_2912 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_3108 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_967 theta)
    · exact b3_127 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_2796 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_3052 theta)
    · exact b3_21 theta
    · exact b3_19 theta
    · exact b3_6 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_2975 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2976 theta)
    · exact b3_1666 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_3330 theta)
    · exact b3_1669 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1621 theta)
    · exact b3_1682 theta
    · exact b3_1634 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_208 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1626 theta)
    · exact b3_1670 theta
    · exact b3_1621 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1682 theta)
    · exact b3_1611 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1683 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1642 theta)
    · exact b3_1642 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_1284 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1284 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1283 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_801 theta)
    · exact b3_1668 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1611 theta)
    · exact b3_1683 theta
    · exact b3_1648 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_212 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1617 theta)
    · exact b3_1671 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1634 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_208 theta)
    · exact b3_1626 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1670 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1648 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_212 theta)
    · exact b3_1617 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_1671 theta)
    · exact b3_1659 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_240 theta)
    · exact b3_1608 theta
    · exact b3_1672 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_1283 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_801 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1668 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_247 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_246 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_248 theta)
    · exact b3_1681 theta
    · exact b3_1678 theta
end Orbits1020Cost12
