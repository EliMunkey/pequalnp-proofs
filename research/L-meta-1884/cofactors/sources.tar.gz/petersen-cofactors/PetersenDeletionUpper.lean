import catalogue.NineRelabel
import PetersenPackedPin
open PetersenSignedBridge PetersenWordCost PetersenPackedPin PetersenInducedCostTable
namespace PetersenDeletionUpper
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048

def program : List Instr := [(true,(1,false),(5,false)),(true,(3,false),(6,false)),(true,(3,false),(10,false)),(true,(5,false),(11,false)),(false,(4,false),(3,false)),(true,(9,false),(3,false)),(true,(10,false),(3,false)),(false,(6,false),(4,false)),(false,(15,false),(2,false)),(false,(15,false),(2,false)),(false,(8,false),(2,false)),(true,(14,false),(0,false)),(false,(8,false),(0,false)),(true,(8,false),(0,false)),(true,(5,false),(0,false)),(true,(5,false),(0,false))]
theorem upper : PetersenGraphRelabel.upper 9 (induced 1022) 16 := by
  let t := graphTarget 9 (induced 1022)
  have checked : (replay (inputs 9) program)[0]? = some t := by decide +kernel
  have gates := program_valid (inputs 9) program
  change PetersenSignedBridge.Run _ 16 _ at gates
  exact ⟨_,gates,Av.wire (List.mem_map.mpr ⟨_,List.mem_of_getElem? checked,rfl⟩)⟩

theorem all (s : Fin 1024) (size : (vertices s.val).length = 9) :
    PetersenGraphRelabel.upper (vertices s.val).length (induced s.val) 16 :=
  PetersenNineRelabel.upper_bound 16 upper s size

#print axioms upper
#print axioms all
end PetersenDeletionUpper
