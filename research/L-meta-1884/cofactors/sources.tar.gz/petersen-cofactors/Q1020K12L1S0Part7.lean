import Q1020K12L1S0Local
import Q1020K12L2S0
import Q1020K12L2S1
import Q1020K12L2S4
import Q1020K12L2S5
import Q1020K12L2S6
import Q1020K12L2S7
import Q1020K12L2S8
import Q1020K12L2S9
import Q1020K12L2S10
import Q1020K12L2S11
import Q1020K12L2S12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L1S0Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b1_19 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_19 := by
  apply PetersenIndexedNode.close (bank := [s2_379,a625,a626,s2_495,s2_393,a627,a628,s2_501,a629,a630,a631,a632,s2_400,s2_306,a633,a634,a635,a636,a637,a638,s2_415,a639,a640,a641,a642,a643,s2_424,s2_423,a644,a645,a646,a647,s2_531,s2_527,a648,s2_59,a649,a650,a651,a652,a653,a654,a655,a656,a657,a658,a659,s2_506,a660,s2_327,s2_322,a661,a662,a663,s2_455,a664,a665,s2_519,a430,s2_481,s2_477,a666,a667,a668,a669,s2_6,s2_5,a407,a670,s2_183,a671,a672,a673,a674,a675,s2_512,a676,s2_336,a677,a678,a679,a680,a681,a682,a683,a684,a685,a686,a687,a688,a689,a690,a691,a692,a693,a694,a695,a696,a697,s2_214,a698,a699,a700,a701,a702,a703,a704,a705,a706,a707,a708,a709,a710,a711,a712,a713,a714,a715,a716,a717,a718,a719,a720,a721,a722,a723,a724,a725,a726,a727,a728,a729,s2_352,a730,a731,a732,a733,a734,s2_359,s2_358,a735,a736,a737,a738,a739,a740,a741,a742,a743,a744,a745,a746,a747,a748,a749,a750,s2_532,s2_528,a751,s2_271,a752,s2_530,a364,a753,a754,a755,a756,a757,a758,s2_282,s2_281,a759,a760,a761,a762]) (PetersenIndexedNode.reasons 256 17 556 0x80562484a015692128055210120152840480572484a015a9212805421012014e84048052b1110840442028052210118504c2028053311118504c4448051a101084044202801f4028a007a4808802140104840442028050280804202a000804fa10114100a0008050a80814100a020804f2101042022101804dc026842022101804cc026054142a0a804ec027054142a0a804bc025842022101804a1888842022101804990808c2824202804a98888c282422280491080842022101804824040a08090008047a1011210090008048a404121009010804721010a08084048045c0229210090808044c0220a08050408046c0230a08050408043c02192100908080421484921005202804190808a0804202804294848a08042128041108092100420280400c444a0803101803f88404e0c0210180408c444e0c02111803f08404a0802101803e2303050408c04803da101191808404803ea30319180840c803d2101050408404803bc01d850402820803ac01d054442a22803cc01e054442a228039c01c85040282080381282850404a02803790808908042028038928289080420a8037108085040420280360a020908028008035884045040280080368a020504028088035084049080210180342622050402820803394100706038208034a622070602830803314100504028208032210100c0484008031a4041090084008032a1011090084048031240400c040602802fc017909008480802ec01700c0406028030c01800c040602802dc016909008480802bc01580c040602802a9080989804202802cc01618980c4c0802a108080c0406028029094140c0425018028884044c4421018029894144c4421058028084040c0421018027151100c0406028026941002c2416028027951102c2406128026141000c04060280250b0900c04060280248a0801c140e0280258b0901c14060a80240a0800c040602802324848848092128022a1011858084048023a4849858092128022210108480840480204010e007e03018021401048480030180201080a007e4202801f400f484804240801e400ee0074480a801c0a82884802a0a801b88404c4c02101801c8a828c4c02a0a801b08404848021018019a4a088480424080191410200625040801aa4a0a006892828018141008480424080168a88884802a2280160a0820056282080178a88a005c2a2280150a08084802820801401808848006028013a12008c8846408014818088c88060280132120084804240801221414060403028011a1011070483028012a14150704840580112101006040302800fc007842402120800ec0070060403028010c008006040302800dc006842402120800bc005806040302800a90808c2c04202800cc0060c2c06160800a10808060403028009084040604210080088a020424021008009884044240210180080a02006040302800714504060403028006941002624130280079450426240312800614100060403028005125040604030280048a08016140b028005925041614030a80040a08006040302800321604060403028002818084a4806028003a16044a48212480020180806040302800110d044240212080009090006040302800190d040604030280001090042402120)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b2_379 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_217 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_352 theta)
    · exact b2_495 theta
    · exact b2_393 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_339 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_339 theta)
    · exact b2_501 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_395 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_336 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_336 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_503 theta)
    · exact b2_400 theta
    · exact b2_306 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_306 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_512 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_382 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_214 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_355 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_498 theta)
    · exact b2_415 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_62 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_327 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_322 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_534 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_506 theta)
    · exact b2_424 theta
    · exact b2_423 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_17 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_18 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_359 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_358 theta)
    · exact b2_531 theta
    · exact b2_527 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_418 theta)
    · exact b2_59 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_325 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_509 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_379 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_352 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_217 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_495 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_415 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_327 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_322 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_62 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_534 theta)
    · exact b2_506 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_415 theta)
    · exact b2_327 theta
    · exact b2_322 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_62 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_534 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_506 theta)
    · exact b2_455 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_183 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_194 theta)
    · exact b2_519 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_481 theta)
    · exact b2_481 theta
    · exact b2_477 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_277 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_276 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_277 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_276 theta)
    · exact b2_6 theta
    · exact b2_5 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_272 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_455 theta)
    · exact b2_183 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_194 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_519 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_400 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_306 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_306 theta)
    · exact b2_512 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_395 theta)
    · exact b2_336 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_336 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_503 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_418 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_59 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_325 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_509 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_415 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_62 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_327 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_322 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_534 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_506 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_424 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_423 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_17 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_18 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_359 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_358 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_531 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_527 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_382 theta)
    · exact b2_214 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_355 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_498 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_393 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_339 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_339 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_501 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_382 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_214 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_355 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_498 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_379 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_217 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_352 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_495 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_424 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_423 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_17 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_18 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_359 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_358 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_531 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_527 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_418 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_59 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_325 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_509 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_418 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_59 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_325 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_509 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_379 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_217 theta)
    · exact b2_352 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_495 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_424 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_423 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_17 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_18 theta)
    · exact b2_359 theta
    · exact b2_358 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_531 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_527 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_382 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_214 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_355 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_498 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_455 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_194 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_183 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_519 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_486 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_487 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_20 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_21 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_282 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_281 theta)
    · exact b2_532 theta
    · exact b2_528 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_479 theta)
    · exact b2_271 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_271 theta)
    · exact b2_530 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_272 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_455 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_183 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_194 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_519 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_486 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_487 theta)
    · exact b2_282 theta
    · exact b2_281 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_20 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_21 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_532 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_528 theta)
end Orbits1020Cost12
