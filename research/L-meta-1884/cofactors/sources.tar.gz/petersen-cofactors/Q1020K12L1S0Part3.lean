import Q1020K12L1S0Local
import Q1020K12L2S0
import Q1020K12L2S1
import Q1020K12L2S3
import Q1020K12L2S4
import Q1020K12L2S5
import Q1020K12L2S6
import Q1020K12L2S7
import Q1020K12L2S8
import Q1020K12L2S9
import Q1020K12L2S10
import Q1020K12L2S11
import Q1020K12L2S12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L1S0Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b1_12 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_12 := by
  apply PetersenIndexedNode.close (bank := [s2_367,s2_366,a216,a217,a218,a219,s2_491,s2_440,s2_372,a220,a221,s2_441,s2_388,a222,a223,s2_442,a224,a225,a226,a227,s2_396,s2_301,a228,s2_447,a229,a230,a231,a232,s2_408,a233,a234,s2_453,a235,s2_52,a236,a237,s2_6,s2_2,a238,a239,a240,a241,a242,a243,a244,a245,a246,a247,s2_443,a248,a249,a250,a251,a252,a253,a254,a255,a256,a257,s2_310,s2_309,a258,a259,a260,a261,s2_539,a262,s2_463,s2_448,a263,a264,a265,s2_437,s2_435,a266,a267,a268,a269,a270,s2_454,a271,a272,s2_71,s2_70,a273,a274,a275,a276,a277,a278,a279,s2_444,a280,a281,a282,s2_445,a283,s2_315,a284,s2_449,a285,s2_462,s2_451,s2_438,a286,a287,s2_455,s2_439,s2_137,a288,a289,a290,a291,a292,s2_446,a293,s2_329,a294,s2_450,a295,a296,a297,a298,a299,a300,a301,s2_456,a302,s2_207,a303,a304,a305,a306,a307,a308,a309,a310,a311,a312,a313,a314,a315,s2_457,a316,a317,a318,a319,a320,a321,a322,a323,a324,a325,s2_345,s2_458,a326,a327,a328,a329,a330,a331,a332,s2_459,a333,s2_248,a334,a335,s2_452,a336,a337,s2_461]) (PetersenIndexedNode.reasons 256 17 556 0x8054b1110840442028054210118504c202805531111850484448053a1010840442028052a80804202a0008052210114100a0008053280814100a0208051a10104202210180509888842022101805010808c2826101805118888c2826222804f9080842022101804ea4040a0809000804e2101121009000804f2404121009010804da1010a0808404804c9404121005000804c10808a0805000804d14040a0805010804b9080921004202804a8c444a0803101804a08404e0c02101804b0c444e0c02111804988404a08021018048a303050408c04804821011918084048049230319180840c8047a1010504084048046920205040480080461080890804800804712020908048088045908085040420280448a020908028008044084045040280080450a02050402808804388404908021018042a6220504028208042141007060382080432622070602830804194100504028208040a10100c0484008040240410900840080412101109008404803fa40400c040602803e930300c040602803e1080989804202803f130318980480c803d908080c040602803c894140c042501803c084044c442101803d094144c442105803b884040c042101803a951100c040602803a141002c241602803b151102c2406128039941000c04060280388b0900c04060280380a0801c140e0280390b0901c14060a80378a0800c0406028036a48480602030180362101107028301803724849070290128035a101006020301803490808060242008034120208480420080351080884804202803392020060203018023c011806020301801408406004e210180334019600c8280a803124a0806020301803094100262213018031a4a082622031180301410006020301802f0a88806020301802e8a08016120b01802f8a88816120309802e0a08006020301802d0180806020600802ca12000c080600802d818080c080602802c2120006020301802aa888a00a8a2228029a101200a48404802ba888a00aca2228028a101200a0840480269888a0098622280259080a0094420280279888a009c622280249080a009042028023c011a008a2a0a801288406004821018020400fe007d003d801e141020076504080224010e00850041801d1410200725040801b0a88a006a2a22801a0a08200662820801c0a88a006e2a2280190a0820062282080170988a005a262280160180a0056060280180988a005e262280150180a0052060280144009e004c2624801280c0600480301801121414060403028010a1011070483028011a14150704840580102101006040302800f1242406040302800e90808c2c04202800f92424c2c04809800e1080806040302800d0840406042100800c8a02042402100800d8840442402101800c0a02006040302800b1450406040302800a9410026241302800b9450426240312800a14100060403028009125040604030280088a08016140b028009925041614030a80080a08006040302800721604060403028006818084a4806028007a16044a48212480060180806040302800500c044240030080048181006040300800580c0406040301800401810424006048002c0010060403028001c0008464423228003c0018464423228000c000006040302)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b2_367 theta
    · exact b2_366 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_292 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_291 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_344 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_343 theta)
    · exact b2_491 theta
    · exact b2_440 theta
    · exact b2_372 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_209 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_351 theta)
    · exact b2_441 theta
    · exact b2_388 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_331 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_335 theta)
    · exact b2_442 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_388 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_331 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_335 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_442 theta)
    · exact b2_396 theta
    · exact b2_301 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_305 theta)
    · exact b2_447 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_372 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_209 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_351 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_441 theta)
    · exact b2_408 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_52 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_321 theta)
    · exact b2_453 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_408 theta)
    · exact b2_52 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_321 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_453 theta)
    · exact b2_6 theta
    · exact b2_2 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_188 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_140 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_139 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_371 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_370 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_314 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_313 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_290 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_289 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_493 theta)
    · exact b2_443 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_371 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_370 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_314 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_313 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_290 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_289 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_493 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_443 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_407 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_406 theta)
    · exact b2_310 theta
    · exact b2_309 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_286 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_284 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_285 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_283 theta)
    · exact b2_539 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_504 theta)
    · exact b2_463 theta
    · exact b2_448 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_188 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_140 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_139 theta)
    · exact b2_437 theta
    · exact b2_435 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_71 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_70 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_288 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_287 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_514 theta)
    · exact b2_454 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_437 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_435 theta)
    · exact b2_71 theta
    · exact b2_70 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_288 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_287 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_514 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_454 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_374 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_348 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_213 theta)
    · exact b2_444 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_411 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_317 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_54 theta)
    · exact b2_445 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_414 theta)
    · exact b2_315 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_58 theta)
    · exact b2_449 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_462 theta)
    · exact b2_462 theta
    · exact b2_451 theta
    · exact b2_438 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_248 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_250 theta)
    · exact b2_455 theta
    · exact b2_439 theta
    · exact b2_137 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_179 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_459 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_398 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_303 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_303 theta)
    · exact b2_446 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_390 theta)
    · exact b2_329 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_332 theta)
    · exact b2_450 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_411 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_54 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_317 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_445 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_410 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_55 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_318 theta)
    · exact b2_456 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_375 theta)
    · exact b2_207 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_347 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_457 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_390 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_329 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_332 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_450 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_374 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_213 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_348 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_444 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_375 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_207 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_347 theta)
    · exact b2_457 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_410 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_55 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_318 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_456 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_414 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_58 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_315 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_449 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_378 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_210 theta)
    · exact b2_345 theta
    · exact b2_458 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_378 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_210 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_345 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_458 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_439 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_137 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_179 theta)
    · exact b2_459 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_438 theta)
    · exact b2_248 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_250 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_455 theta)
    · exact b2_452 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_170 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_170 theta)
    · exact b2_461 theta
end Orbits1020Cost12
