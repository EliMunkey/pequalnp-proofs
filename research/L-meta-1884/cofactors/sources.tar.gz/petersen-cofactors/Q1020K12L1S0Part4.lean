import Q1020K12L1S0Local
import Q1020K12L2S0
import Q1020K12L2S1
import Q1020K12L2S3
import Q1020K12L2S4
import Q1020K12L2S5
import Q1020K12L2S6
import Q1020K12L2S7
import Q1020K12L2S8
import Q1020K12L2S9
import Q1020K12L2S10
import Q1020K12L2S11
import Q1020K12L2S12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L1S0Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b1_13 (theta : Extra1020K12.Theta) : Blocked tgt 11 s1_13 := by
  apply PetersenIndexedNode.close (bank := [s2_369,s2_368,a338,a339,a340,a341,a342,a343,a344,a345,s2_492,s2_466,s2_373,a346,a347,s2_467,s2_389,a348,a349,s2_468,a350,a351,a352,s2_469,s2_397,s2_302,a353,a354,a355,a356,a357,s2_473,s2_409,a358,a359,a360,a361,s2_53,a362,a363,s2_6,s2_3,a364,a365,a366,a367,a368,a369,a370,a371,a372,a373,a374,a375,a376,a377,a378,a379,a380,a381,a382,a383,a384,a385,a386,a387,a388,a389,a390,a391,a392,s2_312,s2_311,a393,a394,a395,a396,s2_540,a397,s2_482,a398,s2_437,s2_436,a399,a400,a401,a402,a403,a404,a405,s2_515,a406,s2_474,a407,a408,a409,a410,a411,s2_74,s2_73,a412,a413,a414,a415,s2_535,a416,s2_480,a417,a418,a419,a420,a421,a422,a423,a424,s2_470,a425,s2_316,a426,a427,s2_438,a428,a429,s2_475,a430,s2_481,s2_477,a431,s2_138,a432,a433,a434,a435,a436,s2_471,a437,s2_330,a438,a439,a440,a441,a442,s2_476,a443,a444,a445,a446,a447,s2_208,a448,a449,a450,a451,a452,a453,a454,a455,a456,a457,a458,a459,a460,a461,a462,a463,a464,a465,a466,a467,a468,a469,a470,a471,s2_346,a472,a473,a474,a475,a476,a477,a478,a479,a480,s2_472,s2_249,a481,s2_479,a482,a483,a484,a485]) (PetersenIndexedNode.reasons 256 17 556 0x805eb11109010c404805e2101191108404805f3111191108444805da101090108404805ca80804202a000805c210114100a000805d280814100a020805ba101042022101805a9c0c042022101805a12020c2826101805b1c0c0c2825030805992020420221018058a4040a080900080582101121009000805924041210090108057a1010a080840480569404121005000805612020a0805000805714040a08050108055920212100480880548c444a0803101805408404e0c0210180550c444e0c02111805388404a08021018052a303050408c04805221011918084048053230319180840c8051a101050408404805092020504048008050140409080480080511202090804808804f9404050405010804e8a02090802800804e0840450402800804f0a02050402808804d8840490802101804ca622050402820804c1410070603820804d2622070602830804b9410050402820804aa10100c048400804a2404109008400804b21011090084048049a40400c0406028048930300c040602804812021898048088049130318980480c8047920200c0406028046894140c0425018046084044c4421018047094144c4421058045884040c0421018044951100c0406028044141002c2416028045151102c2406128043941000c04060280428b0900c04060280420a0801c140e0280430b0901c14060a80418a0800c0406028040a4848060203018040210110702830180412484907029012803fa101006020301802fc01780602030180161202200564808803f401f600f8480a803d0a82806020301803c884044c482101803d8a8284c48280a803c0840406020301803b24a0806020301803a9410026221301803ba4a0826220311803a141000602030180390a8880602030180388a08016120b0180398a8881612030980380a08006020301803701808060206008036a12000c0806008037818080c080602803621200060203018033c019a00cb00648031a101200c484048035c01aa00d300688030a101200c08404802fc017a00ba420280149202200504202802c4015e00ad0055802a0840600a62101802e4016e00b5005980290840600a2210180264012e00950049802414102008e504080284013e009d004d802314102008a50408020400fe007d003d801e0a0820076282080224010e00850041801d0a08200722820801a400ce0065003180180180a005e0602801c400de006d003580170180a005a06028016400ae00544240801480c0600500301801321414060403028012a1011070483028013a1415070484058012210100604030280111242406040302801092020c2c04808801192424c2c0480980101202006040302800f0840406042100800e8a02042402100800f8840442402101800e0a02006040302800d1450406040302800c9410026241302800d9450426240312800c1410006040302800b1250406040302800a8a08016140b02800b925041614030a800a0a08006040302800921604060403028008818084a4806028009a16044a48212480080180806040302800700c044240030080068181006040300800780c0406040301800601810424006048003c0018060403028002c0012000700028005c002a001300088000c000006040302)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b2_369 theta
    · exact b2_368 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_296 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_295 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_294 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_293 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_312 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_311 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_540 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_482 theta)
    · exact b2_492 theta
    · exact b2_466 theta
    · exact b2_373 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_211 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_346 theta)
    · exact b2_467 theta
    · exact b2_389 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_333 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_333 theta)
    · exact b2_468 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_391 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_330 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_330 theta)
    · exact b2_469 theta
    · exact b2_397 theta
    · exact b2_302 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_302 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_471 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_376 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_208 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_349 theta)
    · exact b2_473 theta
    · exact b2_409 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_56 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_316 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_470 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_412 theta)
    · exact b2_53 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_319 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_476 theta)
    · exact b2_6 theta
    · exact b2_3 theta
    · exact via sym1 fix1 (by decide +kernel) (b2_272 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_267 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_266 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_369 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_368 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_312 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_311 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_296 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_294 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_295 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_293 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_540 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_492 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_482 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_466 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_369 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_368 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_312 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_311 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_296 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_294 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_295 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_293 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_540 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_492 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_482 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_466 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_369 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_368 theta)
    · exact b2_312 theta
    · exact b2_311 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_296 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_294 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_295 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_293 theta)
    · exact b2_540 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_492 theta)
    · exact b2_482 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_466 theta)
    · exact b2_437 theta
    · exact b2_436 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_74 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_73 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_300 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_298 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_299 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_297 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_535 theta)
    · exact b2_515 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_480 theta)
    · exact b2_474 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_272 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_267 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_266 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_437 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_436 theta)
    · exact b2_74 theta
    · exact b2_73 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_300 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_298 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_299 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_297 theta)
    · exact b2_535 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_515 theta)
    · exact b2_480 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_474 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_373 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_346 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_211 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_467 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_409 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_316 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_56 theta)
    · exact b2_470 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_409 theta)
    · exact b2_316 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_56 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_470 theta)
    · exact b2_438 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_138 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_171 theta)
    · exact b2_475 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_481 theta)
    · exact b2_481 theta
    · exact b2_477 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_438 theta)
    · exact b2_138 theta
    · exact via sym7 fix7 (by decide +kernel) (b2_171 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_475 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_397 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_302 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_302 theta)
    · exact b2_471 theta
    · exact via sym3 fix3 (by decide +kernel) (b2_391 theta)
    · exact b2_330 theta
    · exact via sym5 fix5 (by decide +kernel) (b2_330 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_469 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_412 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_53 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_319 theta)
    · exact b2_476 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_409 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_56 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_316 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_470 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_376 theta)
    · exact b2_208 theta
    · exact via sym4 fix4 (by decide +kernel) (b2_349 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_473 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_389 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_333 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_333 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_468 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_376 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_208 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_349 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_473 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_373 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_211 theta)
    · exact via sym2 fix2 (by decide +kernel) (b2_346 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_467 theta)
    · exact via sym4 fix4 (by decide +kernel) (b2_412 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_53 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_319 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_476 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_412 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_53 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_319 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_476 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_373 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_211 theta)
    · exact b2_346 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_467 theta)
    · exact via sym7 fix7 (by decide +kernel) (b2_376 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_208 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_349 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_473 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_438 theta)
    · exact via sym1 fix1 (by decide +kernel) (b2_171 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_138 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_475 theta)
    · exact b2_472 theta
    · exact b2_249 theta
    · exact via sym2 fix2 (by decide +kernel) (b2_249 theta)
    · exact b2_479 theta
    · exact via sym6 fix6 (by decide +kernel) (b2_438 theta)
    · exact via sym5 fix5 (by decide +kernel) (b2_138 theta)
    · exact via sym3 fix3 (by decide +kernel) (b2_171 theta)
    · exact via sym6 fix6 (by decide +kernel) (b2_475 theta)
end Orbits1020Cost12
