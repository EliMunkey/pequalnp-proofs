# Exact costs of Petersen cofactors

The original Boolean function is true when at least one of the Petersen graph’s fifteen edges has two true endpoints. A partial assignment fixes some vertices to true or false and leaves the rest as independent inputs. Signed binary circuits in this certificate allow arbitrary wire sharing, free constants, free complements, and binary AND and OR gates.

`PetersenMaskCofactor.unconditional` computes and proves the exact gate count of every partial assignment with at least two fixed inputs. The theorem takes `free` and `on` as ten-bit masks. Bits outside these two masks are fixed false. Ordinary partial assignments use disjoint masks. The unfixed coordinates in the output truth table occur in increasing order of original vertex number.

If two pinned-true vertices share an edge, the truth table is constant true. Otherwise every free neighbor of a true vertex contributes a singleton term. After collecting these terms, the remaining function tests edges of the induced graph on the other free vertices. For a nonconstant remainder of exact cost `k` and `s` singleton terms, the minimum is `k+s`. An empty remainder gives a disjunction with cost `max(0,s−1)`. The proof covers circuits with shared intermediate gates.

The exhaustive induced-graph certificate checks isomorphisms for all 1,013 vertex masks of size at most eight. The largest bases are the two eight-vertex deletions. Deleting an adjacent pair costs thirteen gates and deleting a nonadjacent pair costs twelve. An upper-bound program accompanies each lower bound. `PetersenMaskCofactor.three_or_more_fixed` also isolates the 58,848 cofactors whose exact costs follow before the thirteen-gate case.

For exactly two pinned vertices, the complete lookup has six entries.

| Pinned vertices | Both false | One true | Both true |
| --- | ---: | ---: | ---: |
| Adjacent | 13 | 10 | 0 |
| Nonadjacent | 12 | 8 | 7 |

Fixing a single vertex to true leaves three singleton neighbors and a six-cycle, of total cost eleven. Including these ten cases, the catalogue determines 59,038 of the 59,049 ternary restrictions. The omitted cases keep every input free or fix one vertex to false.

An independent enumeration also compared the normalized formula with the literal fifteen-edge predicate on all 1,037,312 valuations represented by these cofactors.

To verify, use the public `pequalnp-proofs` checkout at commit `074709bd01fc526b9f6279e5b0a028946ceb39fb`, Lean 4.36.0, its recorded Lake dependencies, and the compiled `PEqualNP.Defs.MetaComplexity` module. From any directory, point the included script at the checkout.

```sh
python3 /path/to/petersen-cofactors/replay.py /path/to/pequalnp-proofs
```

The script checks the compiler version, the pinned project source and manifest, and each local file digest. The default build directory is under the source package. `--out` and `--jobs` change the output location and concurrent file count. The final log lists the Lean axioms used by the theorem.
