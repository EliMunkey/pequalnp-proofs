import PetersenWordCost

open PetersenSignedBridge PetersenWordCost
namespace PetersenGraphRelabel

variable {X Y : Type}

def Covers (r : Y → X) (W : List (Func X)) (V : List (Func Y)) : Prop :=
  ∀ f ∈ W, Av V (f ∘ r)

private theorem av_map {r : Y → X} {W V f} (c : Covers r W V) (a : Av W f) : Av V (f ∘ r) := by
  induction a with
  | wire e => exact c _ e
  | zero => exact Av.zero
  | one => exact Av.one
  | neg _ ih => exact Av.neg ih

private theorem av_cons {f g : Func X} {W} (a : Av W f) : Av (g::W) f := by
  induction a with
  | wire e => exact Av.wire (List.mem_cons_of_mem _ e)
  | zero => exact Av.zero
  | one => exact Av.one
  | neg _ ih => exact Av.neg ih

private theorem simulate {r : Y → X} {I J W k} (start : Covers r I J) (c : Run I k W) :
    ∃ V, Run J k V ∧ Covers r W V := by
  induction c with
  | start => exact ⟨_,Run.start,start⟩
  | and _ ha hb ih =>
    obtain ⟨V,rv,cv⟩ := ih
    refine ⟨_,Run.and rv (av_map cv ha) (av_map cv hb),?_⟩
    intro f hf
    rcases List.mem_cons.mp hf with rfl|old
    · exact Av.wire (List.mem_cons_self ..)
    · exact av_cons (cv _ old)
  | or _ ha hb ih =>
    obtain ⟨V,rv,cv⟩ := ih
    refine ⟨_,Run.or rv (av_map cv ha) (av_map cv hb),?_⟩
    intro f hf
    rcases List.mem_cons.mp hf with rfl|old
    · exact Av.wire (List.mem_cons_self ..)
    · exact av_cons (cv _ old)

/-- Realization is covariant under any row map for which each old input remains available. -/
theorem map_realized {r : Y → X} {I J f g k} (cover : Covers r I J) (target : f ∘ r = g)
    (given : ∃ W, Run I k W ∧ Av W f) : ∃ V, Run J k V ∧ Av V g := by
  obtain ⟨W,run,out⟩ := given
  obtain ⟨V,rv,cv⟩ := simulate cover run
  exact ⟨V,rv,target ▸ av_map cv out⟩

/-- A row permutation or identification maps each old input to its listed new coordinate. -/
def rows (n m : Nat) (cols : List Nat) (x : Fin (2^m)) : Fin (2^n) :=
  (pack (fun i : Fin n => x.val.testBit (cols.getD i 0))).toFin

private theorem bit_rows {n m} (cols : List Nat) (x : Fin (2^m)) (i : Nat) (hi : i < n) :
    (rows n m cols x).val.testBit i = x.val.testBit (cols.getD i 0) := by
  exact congrFun (read_pack (fun j : Fin n => x.val.testBit (cols.getD j 0))) ⟨i,hi⟩

private def sortEdge (a : Nat × Nat) : Nat × Nat := (min a.1 a.2,max a.1 a.2)
private def rename (cols : List Nat) (a : Nat × Nat) : Nat × Nat :=
  (cols.getD a.1 0,cols.getD a.2 0)
private def hits (v : Nat) (e : Nat × Nat) : Bool := v.testBit e.1 && v.testBit e.2

private theorem sort_hits (v : Nat) (e : Nat × Nat) : hits v (sortEdge e) = hits v e := by
  obtain ⟨a,b⟩ := e
  by_cases h : a ≤ b
  · simp [sortEdge,hits,min_eq_left h,max_eq_right h]
  · have p := Nat.le_of_lt (Nat.lt_of_not_ge h)
    simp [sortEdge,hits,min_eq_right p,max_eq_left p,Bool.and_comm]

/-- This verification compares endpoint sets, without enumerating Boolean assignments. -/
def fits (n m : Nat) (cols : List Nat) (E F : List (Nat × Nat)) : Bool :=
  decide (cols.length = n) && cols.all (fun j => decide (j < m)) &&
  E.all (fun e => decide (e.1 < n ∧ e.2 < n)) &&
  decide ((E.map (sortEdge ∘ rename cols)).toFinset = (F.map sortEdge).toFinset)

private theorem target_map {n m cols E F} (h : fits n m cols E F = true) :
    read (graphTarget n E) ∘ rows n m cols = read (graphTarget m F) := by
  obtain ⟨left,eq⟩ := Bool.and_eq_true_iff.mp h
  obtain ⟨_,ends⟩ := Bool.and_eq_true_iff.mp left
  have seteq := of_decide_eq_true eq
  funext x
  simp only [graphTarget,read_pack,Function.comp_apply]
  change E.any (hits (rows n m cols x).val) = F.any (hits x.val)
  have matching (e) (he : e ∈ E) :
      hits (rows n m cols x).val e = hits x.val (rename cols e) := by
    have q := of_decide_eq_true (List.all_eq_true.mp ends e he)
    simp only [hits,rename,bit_rows _ _ _ q.1,bit_rows _ _ _ q.2]
  apply Bool.eq_iff_iff.mpr
  constructor
  · intro yes
    obtain ⟨e,he,ev⟩ := List.any_eq_true.mp yes
    have mem : sortEdge (rename cols e) ∈ (E.map (sortEdge ∘ rename cols)).toFinset :=
      List.mem_toFinset.mpr (List.mem_map.mpr ⟨e,he,rfl⟩)
    rw [seteq] at mem
    obtain ⟨f,hf,same⟩ := List.mem_map.mp (List.mem_toFinset.mp mem)
    exact List.any_eq_true.mpr ⟨f,hf,by rwa [←sort_hits _ f,same,sort_hits,←matching e he]⟩
  · intro yes
    obtain ⟨f,hf,ev⟩ := List.any_eq_true.mp yes
    have mem : sortEdge f ∈ (F.map sortEdge).toFinset := List.mem_toFinset.mpr (List.mem_map.mpr ⟨f,hf,rfl⟩)
    rw [←seteq] at mem
    obtain ⟨e,he,same⟩ := List.mem_map.mp (List.mem_toFinset.mp mem)
    change sortEdge (rename cols e) = sortEdge f at same
    exact List.any_eq_true.mpr ⟨e,he,by rwa [matching e he,←sort_hits _ (rename cols e),same,sort_hits]⟩

private theorem input_cover {n m cols E F} (h : fits n m cols E F = true) :
    Covers (rows n m cols) ((inputs n).map read) ((inputs m).map read) := by
  obtain ⟨left,_⟩ := Bool.and_eq_true_iff.mp h
  obtain ⟨left,_⟩ := Bool.and_eq_true_iff.mp left
  obtain ⟨len,bounds⟩ := Bool.and_eq_true_iff.mp left
  have len' : cols.length = n := of_decide_eq_true len
  intro f hf
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hf
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp ha
  have hidx : i.val < cols.length := len' ▸ i.isLt
  have hget : cols.getD i.val 0 = cols[i.val] := by simp [List.getD_eq_getElem?_getD,hidx]
  have bnd : cols.getD i.val 0 < m := by
    rw [hget]; exact of_decide_eq_true (List.all_eq_true.mp bounds _ (List.getElem_mem ..))
  let j : Fin m := ⟨cols.getD i.val 0,bnd⟩
  have rel : (read (pack (fun z : Fin (2^n) => z.val.testBit i.val))) ∘ rows n m cols =
      read (pack (fun z : Fin (2^m) => z.val.testBit j.val)) := by
    rw [read_pack,read_pack];funext x;exact bit_rows cols x i i.isLt
  rw [rel]
  exact Av.wire (List.mem_map.mpr ⟨_,List.mem_ofFn.mpr ⟨j,rfl⟩,rfl⟩)

theorem lower {n m cols E F k} (h : fits n m cols E F = true)
    (b : NoAtMost (inputs m) (graphTarget m F) k) : NoAtMost (inputs n) (graphTarget n E) k := by
  intro j le W run out
  obtain ⟨V,rv,cv⟩ := simulate (input_cover h) run
  exact b j le V rv ((target_map h) ▸ av_map cv out)

def upper (n : Nat) (E : List (Nat × Nat)) (k : Nat) : Prop :=
  ∃ W, Run ((inputs n).map read) k W ∧ Av W (read (graphTarget n E))

theorem upper_map {n m cols E F k} (h : fits n m cols E F = true) (b : upper n E k) :
    upper m F k := by
  obtain ⟨W,run,out⟩ := b
  obtain ⟨V,rv,cv⟩ := simulate (input_cover h) run
  exact ⟨V,rv,(target_map h) ▸ av_map cv out⟩

#print axioms lower
#print axioms upper_map
end PetersenGraphRelabel
