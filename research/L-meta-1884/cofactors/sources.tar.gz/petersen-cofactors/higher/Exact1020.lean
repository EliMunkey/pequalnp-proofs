import Q1020K12Closing
import higher.UpperTable

open PetersenWordCost PetersenInducedCostTable PetersenUpperTable
namespace EightVertexLifts

/-- The eight-vertex graph obtained by deleting adjacent Petersen vertices has signed size thirteen. -/
theorem mask1020_ge13 : lower 1020 13 :=
  Orbits1020Cost12.bound ThetaCert.bound

theorem exact1020 : lower 1020 13 ∧ achievable 1020 13 := ⟨mask1020_ge13,upper1020⟩

#print axioms mask1020_ge13
#print axioms exact1020
end EightVertexLifts
