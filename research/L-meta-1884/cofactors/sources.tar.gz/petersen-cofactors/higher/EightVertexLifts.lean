import D9Closing
import PetersenSmallPins
open PetersenWordCost PetersenGraphCosts
namespace EightVertexLifts
set_option maxHeartbeats 0
set_option maxRecDepth 200000
abbrev HardTheta := NoAtMost (inputs 7) (graphTarget 7 [(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(2,6),(5,6)]) 10
theorem mask1018_eleven : NoAtMost (inputs 8) (graphTarget 8 [(1,2),(0,4),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 10 := by
  let rows := embedding 8 7 [none,some 4,some 3,some 5,some 1,some 6,some 0,some 2]
  apply lift_pin (rows false) (rows true) Deleted191Cost9.bound <;> decide +kernel
theorem mask1018_twelve (h : HardTheta) : NoAtMost (inputs 8) (graphTarget 8 [(1,2),(0,4),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 11 := by
  let rows := embedding 8 7 [none,some 4,some 3,some 5,some 1,some 6,some 0,some 2]
  apply lift_pin (rows false) (rows true) h <;> decide +kernel
theorem mask1020_eleven : NoAtMost (inputs 8) (graphTarget 8 [(0,1),(1,2),(0,5),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 10 := by
  let rows := embedding 8 7 [some 1,some 0,some 5,some 3,none,some 2,some 4,some 6]
  apply lift_pin (rows false) (rows true) Deleted191Cost9.bound <;> decide +kernel
theorem mask1020_twelve (h : HardTheta) : NoAtMost (inputs 8) (graphTarget 8 [(0,1),(1,2),(0,5),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 11 := by
  let rows := embedding 8 7 [some 1,some 0,some 5,some 3,none,some 2,some 4,some 6]
  apply lift_pin (rows false) (rows true) h <;> decide +kernel
#print axioms mask1018_eleven
#print axioms mask1020_twelve
end EightVertexLifts
