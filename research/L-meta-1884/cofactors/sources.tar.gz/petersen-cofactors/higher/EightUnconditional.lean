import higher.EightVertexLifts
import ThetaClosing
open PetersenWordCost
namespace EightVertexLifts

theorem mask1018_ge12 : NoAtMost (inputs 8) (graphTarget 8 [(1,2),(0,4),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 11 := mask1018_twelve ThetaCert.bound
#print axioms mask1018_ge12

theorem mask1020_ge12 : NoAtMost (inputs 8) (graphTarget 8 [(0,1),(1,2),(0,5),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 11 := mask1020_twelve ThetaCert.bound
#print axioms mask1020_ge12

end EightVertexLifts
