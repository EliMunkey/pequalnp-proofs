import higher.InducedCostTable
import higher.EightUnconditional
import PetersenPackedPin

open PetersenSignedBridge PetersenWordCost PetersenPackedPin PetersenInducedCostTable
namespace PetersenUpperTable

def achievable (m k : Nat) : Prop :=
  let size := (vertices m).length
  ∃ W, Run ((inputs size).map PetersenWordCost.read) k W ∧ Av W (PetersenWordCost.read (graphTarget size (induced m)))

private theorem checked_program (m k : Nat) (code : List Instr) (len : code.length = k)
    (check : (replay (inputs (vertices m).length) code)[0]? =
      some (graphTarget (vertices m).length (induced m))) : achievable m k := by
  obtain ⟨⟩ := len
  refine ⟨_,program_valid _ _, Av.wire (List.mem_map.mpr ⟨_, List.mem_of_getElem? check,rfl⟩)⟩

set_option maxHeartbeats 0
set_option maxRecDepth 200000

private def program3 : List Instr := [(false,(0,false),(1,false))]
theorem upper3 : achievable 3 1 := checked_program _ _ program3 rfl (by decide +kernel)

private def program7 : List Instr := [(true,(0,false),(2,false)),(false,(2,false),(0,false))]
theorem upper7 : achievable 7 2 := checked_program _ _ program7 rfl (by decide +kernel)

private def program15 : List Instr := [(false,(0,false),(1,false)),(true,(2,false),(4,false)),(false,(4,false),(0,false)),(true,(2,false),(0,false))]
theorem upper15 : achievable 15 4 := checked_program _ _ program15 rfl (by decide +kernel)

private def program45 : List Instr := [(false,(0,false),(3,false)),(false,(2,false),(3,false)),(true,(1,false),(0,false))]
theorem upper45 : achievable 45 3 := checked_program _ _ program45 rfl (by decide +kernel)

private def program51 : List Instr := [(true,(1,false),(2,false)),(true,(0,false),(4,false)),(false,(2,false),(0,false))]
theorem upper51 : achievable 51 3 := checked_program _ _ program51 rfl (by decide +kernel)

private def program31 : List Instr := [(true,(1,false),(4,false)),(false,(1,false),(0,false)),(false,(3,false),(4,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(true,(3,false),(2,false)),(true,(0,false),(1,false))]
theorem upper31 : achievable 31 7 := checked_program _ _ program31 rfl (by decide +kernel)

private def program47 : List Instr := [(true,(1,false),(4,false)),(false,(1,false),(0,false)),(true,(3,false),(5,false)),(false,(5,false),(0,false)),(true,(2,false),(0,false))]
theorem upper47 : achievable 47 5 := checked_program _ _ program47 rfl (by decide +kernel)

private def program55 : List Instr := [(true,(1,false),(3,false)),(true,(0,false),(5,false)),(false,(2,false),(0,false)),(false,(4,false),(5,false)),(true,(1,false),(0,false))]
theorem upper55 : achievable 55 5 := checked_program _ _ program55 rfl (by decide +kernel)

private def program63 : List Instr := [(true,(1,false),(4,false)),(true,(0,false),(6,false)),(false,(2,false),(0,false)),(false,(4,false),(5,false)),(true,(6,false),(8,false)),(false,(8,false),(0,false)),(true,(3,false),(2,false)),(true,(0,false),(1,false))]
theorem upper63 : achievable 63 8 := checked_program _ _ program63 rfl (by decide +kernel)

private def program111 : List Instr := [(true,(1,false),(4,false)),(false,(1,false),(0,false)),(true,(4,false),(7,false)),(false,(4,false),(0,false)),(false,(6,false),(7,false)),(true,(3,false),(1,false)),(true,(0,false),(1,false))]
theorem upper111 : achievable 111 7 := checked_program _ _ program111 rfl (by decide +kernel)

private def program119 : List Instr := [(true,(1,false),(3,false)),(true,(0,false),(5,false)),(false,(2,false),(0,false)),(true,(5,false),(8,false)),(false,(5,false),(0,false)),(true,(2,false),(0,false))]
theorem upper119 : achievable 119 6 := checked_program _ _ program119 rfl (by decide +kernel)

private def program189 : List Instr := [(true,(3,false),(4,false)),(false,(1,false),(0,false)),(true,(3,false),(5,false)),(false,(5,false),(0,false)),(true,(5,false),(8,false)),(false,(10,false),(0,false)),(true,(4,false),(2,false)),(true,(0,false),(1,false))]
theorem upper189 : achievable 189 8 := checked_program _ _ program189 rfl (by decide +kernel)

private def program250 : List Instr := [(false,(0,false),(4,false)),(false,(2,false),(3,false)),(false,(5,false),(7,false)),(true,(2,false),(1,false)),(true,(0,false),(1,false))]
theorem upper250 : achievable 250 5 := checked_program _ _ program250 rfl (by decide +kernel)

private def program127 : List Instr := [(true,(1,false),(4,false)),(true,(0,false),(6,false)),(false,(2,false),(0,false)),(true,(5,false),(9,false)),(false,(5,false),(0,false)),(true,(7,false),(9,false)),(false,(9,false),(0,false)),(true,(4,false),(2,false)),(true,(0,false),(1,false))]
theorem upper127 : achievable 127 9 := checked_program _ _ program127 rfl (by decide +kernel)

private def program191 : List Instr := [(true,(1,false),(4,false)),(true,(0,false),(6,false)),(false,(2,false),(0,false)),(false,(4,false),(5,false)),(true,(6,false),(8,false)),(false,(8,false),(0,false)),(true,(8,false),(11,false)),(false,(13,false),(0,false)),(true,(5,false),(4,false)),(true,(0,false),(3,false)),(true,(0,false),(2,false))]
theorem upper191 : achievable 191 11 := checked_program _ _ program191 rfl (by decide +kernel)

private def program251 : List Instr := [(true,(0,false),(5,false)),(false,(2,false),(0,false)),(true,(4,false),(2,false)),(false,(6,false),(0,false)),(true,(4,false),(10,false)),(false,(9,false),(0,false)),(true,(4,false),(2,false)),(true,(0,false),(1,false))]
theorem upper251 : achievable 251 8 := checked_program _ _ program251 rfl (by decide +kernel)

private def program1018 : List Instr := [(true,(2,false),(6,false)),(false,(2,false),(0,false)),(true,(7,false),(8,false)),(false,(6,false),(0,false)),(true,(4,false),(10,false)),(false,(9,false),(0,false)),(true,(8,false),(11,false)),(true,(0,false),(11,false)),(false,(15,false),(0,false)),(true,(7,false),(5,false)),(true,(0,false),(4,false)),(true,(0,false),(2,false))]
theorem upper1018 : achievable 1018 12 := checked_program _ _ program1018 rfl (by decide +kernel)

private def program1020 : List Instr := [(true,(0,false),(2,false)),(true,(0,false),(7,false)),(false,(3,false),(0,false)),(true,(3,false),(6,false)),(true,(0,false),(11,false)),(false,(10,false),(0,false)),(true,(10,false),(9,false)),(false,(13,false),(0,false)),(true,(10,false),(12,false)),(false,(16,false),(0,false)),(true,(7,false),(4,false)),(true,(0,false),(3,false)),(true,(0,false),(2,false))]
theorem upper1020 : achievable 1020 13 := checked_program _ _ program1020 rfl (by decide +kernel)

private def program1022 : List Instr := [(true,(1,false),(5,false)),(false,(1,false),(0,false)),(true,(3,false),(5,false)),(true,(0,false),(10,false)),(false,(6,false),(0,false)),(true,(6,false),(9,false)),(true,(0,false),(14,false)),(false,(13,false),(0,false)),(true,(13,false),(12,false)),(false,(16,false),(0,false)),(true,(13,false),(15,false)),(false,(19,false),(0,false)),(true,(10,false),(7,false)),(true,(0,false),(5,false)),(true,(0,false),(4,false)),(true,(0,false),(3,false))]
theorem upper1022 : achievable 1022 16 := checked_program _ _ program1022 rfl (by decide +kernel)

private def program1023 : List Instr := [(true,(1,false),(4,false)),(true,(0,false),(6,false)),(false,(2,false),(0,false)),(true,(5,false),(9,false)),(false,(5,false),(0,false)),(true,(7,false),(9,false)),(true,(0,false),(14,false)),(false,(10,false),(0,false)),(true,(10,false),(13,false)),(true,(0,false),(18,false)),(false,(17,false),(0,false)),(true,(17,false),(16,false)),(false,(20,false),(0,false)),(true,(17,false),(19,false)),(false,(23,false),(0,false)),(true,(12,false),(10,false)),(true,(0,false),(8,false)),(true,(0,false),(6,false)),(true,(0,false),(5,false)),(true,(0,false),(4,false))]
theorem upper1023 : achievable 1023 20 := checked_program _ _ program1023 rfl (by decide +kernel)

theorem table_exact : ∀ e ∈ prices, lower e.1 e.2 ∧ achievable e.1 e.2 := by
  intro e h
  refine ⟨all_checked e h,?_⟩
  simp only [prices,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact upper3
  · exact upper7
  · exact upper15
  · exact upper45
  · exact upper51
  · exact upper31
  · exact upper47
  · exact upper55
  · exact upper63
  · exact upper111
  · exact upper119
  · exact upper189
  · exact upper250
  · exact upper127
  · exact upper191
  · exact upper251

theorem exact1018 : lower 1018 12 ∧ achievable 1018 12 :=
  ⟨EightVertexLifts.mask1018_ge12,upper1018⟩
#print axioms table_exact
#print axioms exact1018
end PetersenUpperTable
