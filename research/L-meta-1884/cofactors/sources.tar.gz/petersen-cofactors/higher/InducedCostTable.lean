import ThetaClosing
import M189Closing
import PetersenComponentLifts
import PetersenBareBases
import Cost3
import Cost7

open PetersenWordCost PetersenGraphCosts
namespace PetersenInducedCostTable

private def edges : List (Nat × Nat) :=
  [(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]

def vertices (mask : Nat) : List Nat := (List.range 10).filter mask.testBit

def induced (mask : Nat) : List (Nat × Nat) :=
  edges.filterMap fun (a,b) =>
    if mask.testBit a && mask.testBit b then some ((vertices mask).idxOf a,(vertices mask).idxOf b) else none

def lower (mask price : Nat) : Prop :=
  NoAtMost (inputs (vertices mask).length) (graphTarget (vertices mask).length (induced mask)) (price-1)

def prices : List (Nat × Nat) := [(3, 1), (7, 2), (15, 4), (45, 3), (51, 3), (31, 7), (47, 5), (55, 5), (63, 8), (111, 7), (119, 6), (189, 8), (250, 5), (127, 9), (191, 11), (251, 8)]

set_option maxHeartbeats 0
set_option maxRecDepth 200000

/-- Every listed witness certifies a lower bound for the corresponding induced Petersen graph. -/
theorem all_checked : ∀ e ∈ prices, lower e.1 e.2 := by
  intro e h
  simp only [prices,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact mask3_lower
  · exact mask7_lower
  · exact mask15_lower
  · exact mask45_lower
  · exact mask51_lower
  · exact PetersenCycleFive.no_six_gates
  · exact mask47_lower
  · exact mask55_lower
  · exact mask63_exact_lower
  · exact M111.bound
  · exact mask119_lower
  · exact M189Certificate.lower
  · exact mask250_lower
  · exact mask127_exact_lower
  · exact ThetaCert.bound
  · exact mask251_exact_lower

#print axioms all_checked
end PetersenInducedCostTable
