import Q1020K12L2S6Local
import Q1020K12L3S0
import Q1020K12L3S1
import Q1020K12L3S2
import Q1020K12L3S3
import Q1020K12L3S4
import Q1020K12L3S6
import Q1020K12L3S7
import Q1020K12L3S8
import Q1020K12L3S9
import Q1020K12L3S10
import Q1020K12L3S14
import Q1020K12L3S15
import Q1020K12L3S16
import Q1020K12L3S17
import Q1020K12L3S19
import Q1020K12L3S22
import Q1020K12L3S26
import Q1020K12L3S27
import Q1020K12L3S30
import Q1020K12L3S33
import Q1020K12L3S34
import Q1020K12L3S35
import Q1020K12L3S36
import Q1020K12L3S37
import Q1020K12L3S38
import Q1020K12L3S57
import Q1020K12L3S62
import Q1020K12L3S64
import Q1020K12L3S65
import Q1020K12L3S66
import Q1020K12L3S67
import Q1020K12L3S68
import Q1020K12L3S69
import Q1020K12L3S70
import Q1020K12L3S71
import Q1020K12L3S73
import Q1020K12L3S78
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L2S6Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b2_279 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_279 := by
  apply PetersenIndexedNode.close (bank := [s3_407,a1317,a1318,s3_2724,s3_1124,s3_944,s3_644,a1319,a1320,a1321,a1322,s3_3009,s3_1161,a1323,a1324,a1325,a1326,s3_349,a1327,a1328,a1329,s3_308,a1330,a1331,s3_1402,s3_260,a1332,a1333,s3_21,s3_18,s3_5,a1334,a1335,s3_1564,a1336,s3_196,a1337,a1338,a1339,s3_1568,s3_1496,s3_1604,s3_1501,s3_1600,s3_1514,s3_1513,s3_1512,a1340,s3_1504,s3_1503,s3_1502,s3_1569,s3_1478,s3_1605,s3_1524,s3_1523,a1341,a1342,a1343,a1344,s3_1607,s3_1606,s3_1566,s3_1490,s3_1601,s3_1532,a1345,s3_1492,s3_1571,s3_1541,a1346,s3_1482,s3_1573,s3_1550,a1347,s3_1473,s3_1575,a1348,a1349,s3_1602,a1350,s3_1567,s3_1563,s3_1467,a1351,s3_1585,a1352,a1353,a1354,s3_1599,s3_1593]) (PetersenIndexedNode.reasons 256 17 510 0x18888420221012101185048404622230a090888840421011080a00b10057802b4009e00b5005942024008508084202802a108089011005324041080a00aa42022404401489011005015050a8290808a2824202401454504a28242020a829080862221505188088405004e21011888a009e422221010a8288405004d801c28202003c2a0a150524040a0809000420224201200090104840240410808504042021404121005000210114100a00050102820140408404908021014012ca080504080251c180e0c1004c38301c1820092504028200e868a0803a0a15051c18054143a1a38300a8685414504015052303050408c0442023230108088c0c6460210310808282042021202050404800210112100900048082420120208404282021014011c9080484080230a0805041004814100a082008a484024200a82890802a0251410a08054042a0a14100a829450448402420262205040282028200e0c0704098881c180a0c0a08028201410210100c04840048082120108008404424021011202006020301130300c04060221013130084044c0c6260120308404060203014010d090084808021018080c05004403010180a008284804240400fc0c0406021505098884c050040131101888541406020301151100c0406022820058482c0454440b0901848a080060203010b0900c0406021410038281c042c24070501828504006020301400ec4c4826244202400190809003e801ec00f1080826244202108084c48420224041898090104202313010808901026242404400ea00728381800f098904c482a0a801c8a82a007026241312400de006c280a4941098904c4850401b1a0d89125043634131a141004c48262415110989054402820801a0a0805445003514110a0804c4828200301189800c0484801312098800c042624030121200c4c06260428280c080604840441c1210110a0a83824202a101006040302248480c080604420230b01080892126160240490808060403028019400c60061002f018100c0a006603020181400ba005b002c801500c0806042a0a109008c0a0056212010900a8280604030228a080c0806045040098904c08a28213120189141000604030224a080c0806042820058502c0892820b0a01850a0800604030242c080c08060406021292018090b0225241092018080604030280140848042402624018100c0a00520302018109890424021208013c009924248404800ea101084050024210112022004648082101400948404480880111202200430020800fc007a003b001c1505400685414a282800ca8a085415001b150528a0a0030a282383040058e0c05040800a94100e0c10017383014102002850401410400485040484080089210050410013141012102002048400301400380c0484808006a12000c05000f030121202001884801312400284c49000980044001c4c49000b13124001a000b0004018140008060483828000a0e0806050003018120e0a00008382)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b3_407 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_367 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2624 theta)
    · exact b3_2724 theta
    · exact b3_1124 theta
    · exact b3_944 theta
    · exact b3_644 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_144 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_132 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_85 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2800 theta)
    · exact b3_3009 theta
    · exact b3_1161 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_326 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2425 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2751 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_426 theta)
    · exact b3_349 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_2615 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2733 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_1167 theta)
    · exact b3_308 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_2408 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2753 theta)
    · exact b3_1402 theta
    · exact b3_260 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_2883 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_3085 theta)
    · exact b3_21 theta
    · exact b3_18 theta
    · exact b3_5 theta
    · exact via sym3 fix3 (by decide +kernel) (b3_2942 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2936 theta)
    · exact b3_1564 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_612 theta)
    · exact b3_196 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_2839 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_3068 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_3281 theta)
    · exact b3_1568 theta
    · exact b3_1496 theta
    · exact b3_1604 theta
    · exact b3_1501 theta
    · exact b3_1600 theta
    · exact b3_1514 theta
    · exact b3_1513 theta
    · exact b3_1512 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_185 theta)
    · exact b3_1504 theta
    · exact b3_1503 theta
    · exact b3_1502 theta
    · exact b3_1569 theta
    · exact b3_1478 theta
    · exact b3_1605 theta
    · exact b3_1524 theta
    · exact b3_1523 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_724 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_687 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_686 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_804 theta)
    · exact b3_1607 theta
    · exact b3_1606 theta
    · exact b3_1566 theta
    · exact b3_1490 theta
    · exact b3_1601 theta
    · exact b3_1532 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_166 theta)
    · exact b3_1492 theta
    · exact b3_1571 theta
    · exact b3_1541 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_161 theta)
    · exact b3_1482 theta
    · exact b3_1573 theta
    · exact b3_1550 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_50 theta)
    · exact b3_1473 theta
    · exact b3_1575 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_723 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_682 theta)
    · exact b3_1602 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_1293 theta)
    · exact b3_1567 theta
    · exact b3_1563 theta
    · exact b3_1467 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_90 theta)
    · exact b3_1585 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_105 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_104 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_106 theta)
    · exact b3_1599 theta
    · exact b3_1593 theta
end Orbits1020Cost12
