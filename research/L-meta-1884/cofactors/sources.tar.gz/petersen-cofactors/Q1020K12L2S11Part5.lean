import Q1020K12L2S11Local
import Q1020K12L3S0
import Q1020K12L3S5
import Q1020K12L3S6
import Q1020K12L3S13
import Q1020K12L3S20
import Q1020K12L3S23
import Q1020K12L3S30
import Q1020K12L3S32
import Q1020K12L3S39
import Q1020K12L3S40
import Q1020K12L3S44
import Q1020K12L3S45
import Q1020K12L3S46
import Q1020K12L3S49
import Q1020K12L3S52
import Q1020K12L3S55
import Q1020K12L3S60
import Q1020K12L3S63
import Q1020K12L3S66
import Q1020K12L3S68
import Q1020K12L3S70
import Q1020K12L3S71
import Q1020K12L3S74
import Q1020K12L3S75
import Q1020K12L3S77
import Q1020K12L3S79
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
open Q1020K12L2S11Local
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b2_487 (theta : Extra1020K12.Theta) : Blocked tgt 10 s2_487 := by
  apply PetersenIndexedNode.close (bank := [s3_2334,a2128,a2129,s3_3113,a2130,s3_2981,a2131,s3_214,a2132,s3_2977,a784,s3_265,s3_253,a2133,a2134,a2135,a2136,a2137,a2138,a2139,s3_3191,a2140,s3_1849,a2141,a2142,a2143,a2144,a2145,a2146,s3_2864,a2147,a2148,a2149,a1057,s3_579,a2150,a2151,s3_21,s3_12,a2152,a2153,a2154,a2155,s3_2984,s3_860,a2156,s3_252,s3_251,s3_2986,s3_2985,s3_2978,a2157,a2158,a2159,a2160,a2161,a2162,a2163,s3_2982,a2164,a2165,a2166,s3_2979,a2167,a2168,a2169,a2170,a2171,a2172,a2173,a2174,s3_1363,a2175,a2176,s3_2972,a2177,a2178,s3_2980,s3_1362]) (PetersenIndexedNode.reasons 256 17 510 0x2009d0047420240099404084048026108088405004b31111888a009a6222311140128840442027030108088404a020614128081c0c0c282503028080840442028024c0120420300265040084054041004850104011d4100a080802340115084862225040188888404e0c0210118889c18062222101282008405004328201410200847060383040110e0c07060802094100a080b03028202c0814040908050102c0c12100a0305010141014040501048401400084045040280014040a08050102101242008405003f28201410141007060383040100e0c07060504014100a081003d242012102007828201410400f850402820801d921009081003914100a0814040c8c05010400e99180c8c050100a08050404808141012000840448402400120209080480821010a0808404a8882420121014100282014102a220504028205040121009080988814100a080a08038301c10262207060283028200a0805041003703010180a006c26221311400e04c442622801a818080c04a424030101809404084805010290910900a0245010018080c044c0c0301018088404c4c02101130318980480c2101018080c050033030101809410026221311400d04c4426225040018080c045444030101808a08016120b01151102c2406122820018080c042c2403010180850400e0a07010b0901c14060a1410018080c050029018080c06005f000c8017400ca00630030511100c040602a0208016280814445002d51112808006020301210100c04840048082120108008404424021011202006020301514100c040602a0808015282014505002b51412820006020301494100c0406025040098884c052504131101889410006020301151100c0406022820058482c0454440b0901848a08006020301030100c040c0084800302018000c040604030121200060203018014c00a2004f0026800540095444500235111280820044a0205111400914444a0208010a8080c445001f31111080a003c4202311140080c4444202800e908094505001b5141282020034a0805141400714504a080800ca820125050017494114102002c504049414006125045040800a941005445001315110a082002428201511400505444282080088a0804c45000f13110180a001c06021311400404c44060280068180a0019000b131200c0600140301800400c08060500071090084820012212010904001806040302800200c080604a02041c128082000a838241c12808006040302248480c080604420230b010808921261602404908080604030250c080c080604a080109008481430221201090282000604030228a080c0806045040098904c08a28213120189141000604030224a080c0806042820058502c0892820b0a01850a0800604030242c080c08060406021292018090b0225241092018080604030201808848006000604018100c000602030201808181042400604800100c0806050001119108c8a0006232211914000006040302)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b3_2334 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_1697 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_2072 theta)
    · exact b3_3113 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_1936 theta)
    · exact b3_2981 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_2648 theta)
    · exact b3_214 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_2190 theta)
    · exact b3_2977 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_19 theta)
    · exact b3_265 theta
    · exact b3_253 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_2334 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2072 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_1697 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_3113 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_2542 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1849 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1696 theta)
    · exact b3_3191 theta
    · exact via sym6 fix6 (by decide +kernel) (b3_2542 theta)
    · exact b3_1849 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_1696 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_3191 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2796 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_579 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_967 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_3250 theta)
    · exact b3_2864 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_1268 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1698 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_3326 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2796 theta)
    · exact b3_579 theta
    · exact via sym7 fix7 (by decide +kernel) (b3_967 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_3250 theta)
    · exact b3_21 theta
    · exact b3_12 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_1673 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1667 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_1666 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_860 theta)
    · exact b3_2984 theta
    · exact b3_860 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_2984 theta)
    · exact b3_252 theta
    · exact b3_251 theta
    · exact b3_2986 theta
    · exact b3_2985 theta
    · exact b3_2978 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_1936 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2981 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2648 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_214 theta)
    · exact via sym4 fix4 (by decide +kernel) (b3_2190 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2977 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_1927 theta)
    · exact b3_2982 theta
    · exact via sym4 fix4 (by decide +kernel) (b3_2651 theta)
    · exact via sym5 fix5 (by decide +kernel) (b3_216 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2187 theta)
    · exact b3_2979 theta
    · exact via sym1 fix1 (by decide +kernel) (b3_1927 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2982 theta)
    · exact via sym7 fix7 (by decide +kernel) (b3_2651 theta)
    · exact via sym6 fix6 (by decide +kernel) (b3_216 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2187 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_2979 theta)
    · exact via sym3 fix3 (by decide +kernel) (b3_2870 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_2870 theta)
    · exact b3_1363 theta
    · exact via sym2 fix2 (by decide +kernel) (b3_1363 theta)
    · exact via sym2 fix2 (by decide +kernel) (b3_1362 theta)
    · exact b3_2972 theta
    · exact via sym5 fix5 (by decide +kernel) (b3_261 theta)
    · exact via sym1 fix1 (by decide +kernel) (b3_1659 theta)
    · exact b3_2980 theta
    · exact b3_1362 theta
end Orbits1020Cost12
