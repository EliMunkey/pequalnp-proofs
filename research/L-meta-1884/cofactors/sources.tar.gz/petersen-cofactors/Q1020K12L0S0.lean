import higher.IndexedNode
import higher.WireProjection
import Q1020K12Data
import Q1020K12L1S0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenSymmetry
open Q1020Symmetry
namespace Orbits1020Cost12
set_option maxRecDepth 200000
set_option maxHeartbeats 0

theorem b0_0 (theta : Extra1020K12.Theta) : Blocked tgt 12 s0_0 := by
  apply PetersenIndexedNode.close (bank := [s1_8,a0,a1,s1_14,s1_9,a2,a3,s1_15,a4,a5,a6,a7,s1_10,s1_4,a8,a9,a10,a11,a12,a13,s1_11,a14,a15,a16,a17,s1_0,a18,a19,a20,a21,a22,a23,a24,a25,a26,s1_16,a27,s1_5,a28,a29,s1_12,a30,a31,s1_18,s1_13,a32,a33,s1_19,a34,s1_1,a35,a36,a37,a38,a39,s1_17,a40,s1_6,a41,a42,a43,a44,a45,a46,a47,a48,a49,a50,a51,s1_2,a52,a53,a54,a55,a56,a57,a58,a59,a60,a61,a62,a63,a64,a65,a66,a67,a68,a69,a70,a71,a72,a73,a74,a75,s1_7,a76,a77,a78,a79,a80,a81,a82,a83,a84,a85,s1_3,a86,a87,a88,a89,a90,a91]) (PetersenIndexedNode.reasons 256 17 448 0x803731110840442028036a10118504c2028037b111185048444803621010840442028035280804202a0008034a10114100a0008035a80814100a0208034210104202210180331888842022101803290808c2826101803398888c282422280321080842022101803124040a08090008030a1011210090008031a404121009010803021010a0808404802f1404121005000802e90808a0805000802f94040a0805010802e1080921004202802d0c444a0803101802c88404e0c02101802d8c444e0c02111802c08404a0802101802b2303050408c04802aa101191808404802ba30319180840c802a21010504084048029120205040480080289080890804800802992020908048088028108085040420280270a020908028008026884045040280080278a020504028088026084049080210180252622050402820802494100706038208025a622070602830802414100504028208023210100c0484008022a4041090084008023a1011090084048022240400c0406028021130300c040602802090809898042028021930318980480c8020108080c040602801f094140c042501801e884044c442101801f894144c442105801e084040c042101801d151100c040602801c941002c241602801d951102c240612801c141000c040602801b0b0900c040602801a8a0801c140e02801b8b0901c14060a801a0a0800c040602801924848060203018018a1011070283018019a484907029012801821010060203018017108080602420080169202084804200801790808848042028016120200602030180150a828060203018014884044c48210180158a8284c48280a80140840406020301801324a0806020301801294100262213018013a4a08262203118012141000602030180110a8880602030180108a08016120b0180118a8881612030980100a08006020301800f0180806020600800ea12000c080600800f818080c080602800e2120006020301800d2141406040302800ca101107048302800da141507048405800c2101006040302800b1242406040302800a90808c2c04202800b92424c2c04809800a10808060403028009084040604210080088a020424021008009884044240210180080a02006040302800714504060403028006941002624130280079450426240312800614100060403028005125040604030280048a08016140b028005925041614030a80040a08006040302800321604060403028002818084a4806028003a16044a48212480020180806040302800100c044240030080008181006040300800180c040604030180000181042400604)
  · decide +kernel
  · intro R mem
    simp only [List.mem_cons,List.not_mem_nil,or_false] at mem
    rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
    · exact b1_8 theta
    · exact via sym4 fix4 (by decide +kernel) (b1_2 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_7 theta)
    · exact b1_14 theta
    · exact b1_9 theta
    · exact via sym4 fix4 (by decide +kernel) (b1_6 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_6 theta)
    · exact b1_15 theta
    · exact via sym1 fix1 (by decide +kernel) (b1_9 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_6 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_6 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_15 theta)
    · exact b1_10 theta
    · exact b1_4 theta
    · exact via sym6 fix6 (by decide +kernel) (b1_4 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_17 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_8 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_2 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_7 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_14 theta)
    · exact b1_11 theta
    · exact via sym1 fix1 (by decide +kernel) (b1_0 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_5 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_16 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_11 theta)
    · exact b1_0 theta
    · exact via sym7 fix7 (by decide +kernel) (b1_5 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_16 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_8 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_7 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_2 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_14 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_11 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_5 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_0 theta)
    · exact b1_16 theta
    · exact via sym6 fix6 (by decide +kernel) (b1_11 theta)
    · exact b1_5 theta
    · exact via sym7 fix7 (by decide +kernel) (b1_0 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_16 theta)
    · exact b1_12 theta
    · exact via sym2 fix2 (by decide +kernel) (b1_1 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_1 theta)
    · exact b1_18 theta
    · exact b1_13 theta
    · exact via sym1 fix1 (by decide +kernel) (b1_3 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_3 theta)
    · exact b1_19 theta
    · exact via sym2 fix2 (by decide +kernel) (b1_12 theta)
    · exact b1_1 theta
    · exact via sym7 fix7 (by decide +kernel) (b1_1 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_18 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_10 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_4 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_4 theta)
    · exact b1_17 theta
    · exact via sym3 fix3 (by decide +kernel) (b1_9 theta)
    · exact b1_6 theta
    · exact via sym5 fix5 (by decide +kernel) (b1_6 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_15 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_11 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_0 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_5 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_16 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_11 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_0 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_5 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_16 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_8 theta)
    · exact b1_2 theta
    · exact via sym4 fix4 (by decide +kernel) (b1_7 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_14 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_9 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_6 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_6 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_15 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_8 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_2 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_7 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_14 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_8 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_2 theta)
    · exact via sym2 fix2 (by decide +kernel) (b1_7 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_14 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_11 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_0 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_5 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_16 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_11 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_0 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_5 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_16 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_8 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_2 theta)
    · exact b1_7 theta
    · exact via sym6 fix6 (by decide +kernel) (b1_14 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_8 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_2 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_7 theta)
    · exact via sym7 fix7 (by decide +kernel) (b1_14 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_12 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_1 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_1 theta)
    · exact via sym4 fix4 (by decide +kernel) (b1_18 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_13 theta)
    · exact b1_3 theta
    · exact via sym2 fix2 (by decide +kernel) (b1_3 theta)
    · exact via sym1 fix1 (by decide +kernel) (b1_19 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_12 theta)
    · exact via sym5 fix5 (by decide +kernel) (b1_1 theta)
    · exact via sym3 fix3 (by decide +kernel) (b1_1 theta)
    · exact via sym6 fix6 (by decide +kernel) (b1_18 theta)
end Orbits1020Cost12

