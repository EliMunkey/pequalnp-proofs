import catalogue.EightCensus
import higher.Exact1020

open PetersenInducedCostTable
namespace PetersenGraphCatalogue

/-- All 1,013 induced graphs with at most eight original Petersen vertices have the stated exact cost. -/
theorem exhaustive (s : Fin 1024) (h : (vertices s.val).length ≤ 8) :
    exactCost s.val (query s.val).price :=
  all_small EightVertexLifts.mask1020_ge13 s h

theorem exact_at_eight (s : Fin 1024) (h : (vertices s.val).length = 8) :
    exactCost s.val (eightPrice s.val) := by
  rw [←price_at_eight s h]
  exact exhaustive s (by omega)

#print axioms exhaustive
#print axioms exact_at_eight
end PetersenGraphCatalogue
