import catalogue.OnePins
import catalogue.CensusExact
open PetersenWordCost PetersenInducedCostTable PetersenSingleton
namespace PetersenMaskCofactor

/-- Exact costs of the 59,028 ordinary partial assignments with at least two fixed vertices. -/
theorem unconditional (free on : Fin 1024) (size : (vertices free.val).length ≤ 8) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) :=
  all_pins EightVertexLifts.mask1020_ge13 free on size

theorem unconditional_pair (i j : Fin 10) (a b : Bool) (different : i ≠ j) :
    Minimum ((inputs (vertices (pairFree i j).val).length).map read)
      (read (table (pairFree i j).val (pairOn i j a b).val)) (pairPrice i j a b) :=
  pair_exact EightVertexLifts.mask1020_ge13 i j a b different

set_option maxHeartbeats 0 in
set_option maxRecDepth 100000 in
private theorem one_tail : ∀ s : Fin 1024, (vertices s.val).length = 9 →
    (vertices (tailMask s.val (1023-s.val)).val).length = 6 := by decide +kernel

/-- Covers 59,038 of the 59,049 ordinary ternary restrictions, including the single-to-true cases. -/
theorem except_one_zero_and_full (free on : Fin 1024)
    (allowed : (vertices free.val).length ≤ 8 ∨
      ((vertices free.val).length = 9 ∧ on.val = 1023-free.val)) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) := by
  rcases allowed with small|⟨nine,pinned⟩
  · exact unconditional _ _ small
  · apply from_tail
    have six := one_tail free nine
    rw [pinned]
    exact PetersenGraphCatalogue.except_adjacent _ (by omega) (Or.inl (by omega))

#print axioms unconditional
#print axioms except_one_zero_and_full
#print axioms unconditional_pair
end PetersenMaskCofactor
