import higher.Relabel
import PetersenSingleton

open PetersenSignedBridge PetersenSingleton PetersenGraphRelabel
namespace PetersenResidual
variable {V : Type} [DecidableEq V]
abbrev Assignment (V : Type) := V → Bool

def wires (L : List V) : List (Func (Assignment V)) := L.map fun v x => x v

def Supported (L : List V) (f : Func (Assignment V)) : Prop :=
  ∀ x y, (∀ v ∈ L, x v = y v) → f x = f y

def both (f : Func (Assignment V)) : Prop := (∃ x, f x = false) ∧ (∃ x, f x = true)

theorem minimum_transport {X Y : Type} {I : List (Func X)} {J : List (Func Y)} {f g k}
    (forward : ∀ j, Realized I f j → Realized J g j)
    (backward : ∀ j, Realized J g j → Realized I f j)
    (base : Minimum I f k) : Minimum J g k :=
  ⟨forward k base.1,fun j hj q => base.2 j hj (backward j q)⟩

/-- Adding an independent singleton OR costs exactly one binary gate, including under arbitrary fanout. -/
theorem add_one {R : List V} {v : V} {f : Func (Assignment V)} {k : Nat} (fresh : v ∉ R)
    (support : Supported R f) (nc : both f) (base : Minimum (wires R) f k) :
    Minimum (wires (v::R)) (fun x => x v || f x) (k+1) := by
  let split (x : Assignment V) : Bool × Assignment V := (x v,x)
  let join (p : Bool × Assignment V) : Assignment V := Function.update p.2 v p.1
  have coverSplit : Covers split (extend (wires R)) (wires (v::R)) := by
    intro a ha
    rcases List.mem_cons.mp ha with rfl|hm
    · exact Av.wire (List.mem_cons_self ..)
    · obtain ⟨g,hg,rfl⟩ := List.mem_map.mp hm
      exact Av.wire (List.mem_cons_of_mem _ hg)
  have coverJoin : Covers join (wires (v::R)) (extend (wires R)) := by
    intro a ha
    obtain ⟨z,hz,rfl⟩ := List.mem_map.mp ha
    rcases List.mem_cons.mp hz with eq|mounted
    · subst z
      have e : (fun x : Assignment V => x v) ∘ join = Prod.fst := by
        funext p; simp [join]
      rw [e]; exact Av.wire (List.mem_cons_self ..)
    · have ne : z ≠ v := by intro equ; exact fresh (equ ▸ mounted)
      have e : (fun x : Assignment V => x z) ∘ join = fun (p : Bool × Assignment V) => p.2 z := by
        funext p; simp [join,Function.update_of_ne ne]
      rw [e]
      exact Av.wire (List.mem_cons_of_mem _ (List.mem_map.mpr
        ⟨fun x : Assignment V => x z,List.mem_map.mpr ⟨z,mounted,rfl⟩,rfl⟩))
  have target : (fun x : Assignment V => x v || f x) ∘ join = withSingleton f := by
    funext p
    have unchanged : f (join p) = f p.2 := support _ _ (by
      intro z hz; have ne : z ≠ v := by rintro rfl;exact fresh hz
      simp [join,Function.update_of_ne ne])
    simp [Function.comp_apply,join,withSingleton] at unchanged ⊢
    rw [unchanged]
  apply minimum_transport (f := withSingleton f) (g := fun x => x v || f x) (fun _ => map_realized coverSplit rfl) (fun _ => map_realized coverJoin target)
  exact minimum_extend nc.1 nc.2 base

def withList (P : List V) (f : Func (Assignment V)) : Func (Assignment V) :=
  fun x => P.any x || f x

theorem list_support {P R : List V} {f : Func (Assignment V)} (base : Supported R f) :
    Supported (P++R) (withList P f) := by
  intro x y same
  have h : P.any x = P.any y := by
    apply Bool.eq_iff_iff.mpr
    constructor <;> intro value
    · obtain ⟨i,hi,one⟩ := List.any_eq_true.mp value
      exact List.any_eq_true.mpr ⟨i,hi,(same i (List.mem_append_left _ hi)) ▸ one⟩
    · obtain ⟨i,hi,one⟩ := List.any_eq_true.mp value
      exact List.any_eq_true.mpr ⟨i,hi,(same i (List.mem_append_left _ hi)).symm ▸ one⟩
  simp only [withList,h,base x y (fun i hi => same i (List.mem_append_right _ hi))]

private theorem list_both {P R : List V} {f : Func (Assignment V)} (base : Supported R f)
    (disjoint : ∀ i ∈ P, i ∉ R) (nc : both f) : both (withList P f) := by
  obtain ⟨⟨x,hx⟩,⟨y,hy⟩⟩ := nc
  let z (i : V) := if i ∈ P then false else x i
  have same : f z = f x := base _ _ (by
    intro i hi; have n : i ∉ P := fun p => disjoint i p hi
    simp [z,n])
  refine ⟨⟨z,?_⟩,⟨y,by simp [withList,hy]⟩⟩
  have off : P.any z = false := List.any_eq_false.mpr (fun i hi => by simp [z,hi])
  simp [withList,off,same,hx]

theorem add_many {R : List V} (P : List V) {f : Func (Assignment V)} {k : Nat}
    (nd : P.Nodup) (apart : ∀ i ∈ P, i ∉ R) (support : Supported R f) (nc : both f)
    (base : Minimum (wires R) f k) : Minimum (wires (P++R)) (withList P f) (k+P.length) := by
  induction P with
  | nil =>
    have e : withList [] f = f := by funext x; simp [withList]
    simpa [e] using base
  | cons a P ih =>
    obtain ⟨new,tail⟩ := List.nodup_cons.mp nd
    have d : ∀ i ∈ P, i ∉ R := fun i h => apart i (List.mem_cons_of_mem _ h)
    have fresh : a ∉ P++R := by simpa [new] using apart a (List.mem_cons_self ..)
    have step := add_one fresh (list_support support) (list_both support d nc) (ih tail d)
    have e : withList (a::P) f = (fun x => x a || withList P f x) := by
      funext x; simp [withList,Bool.or_assoc]
    simpa only [List.cons_append,List.length_cons,Nat.add_assoc,e] using step

#print axioms add_many
end PetersenResidual
