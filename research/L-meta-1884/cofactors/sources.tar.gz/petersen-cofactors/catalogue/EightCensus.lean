import catalogue.Census
open PetersenInducedCostTable
namespace PetersenGraphCatalogue
set_option maxHeartbeats 0
set_option maxRecDepth 100000

/-- When two vertices are deleted, their adjacency determines the exact signed gate count. -/
def eightPrice (mask : Nat) : Nat := if (induced (1023-mask)).isEmpty then 12 else 13

theorem price_at_eight : ∀ mask : Fin 1024, (vertices mask.val).length = 8 →
    (query mask.val).price = eightPrice mask.val := by decide +kernel

end PetersenGraphCatalogue
