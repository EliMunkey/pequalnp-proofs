import catalogue.PackedResidual

namespace PetersenResidual
variable {V : Type} [DecidableEq V]
abbrev EdgeList (V : Type) := List (V × V)

def evaluates (E : EdgeList V) (x : Assignment V) : Bool :=
  E.any fun e => x e.1 && x e.2

def neighborOf (E : EdgeList V) (T : List V) (v : V) : Bool :=
  E.any fun e => (v == e.1 && T.contains e.2) || (v == e.2 && T.contains e.1)

def pinned (F T : List V) (x : Assignment V) : Assignment V :=
  fun v => T.contains v || (F.contains v && x v)

def singletons (E : EdgeList V) (F T : List V) := F.filter (neighborOf E T)
def remainder (E : EdgeList V) (F T : List V) := F.filter (fun v => !(neighborOf E T v))
def inside (E : EdgeList V) (R : List V) := E.filter (fun e => R.contains e.1 && R.contains e.2)

private theorem neighbor_iff {E : EdgeList V} {T v} : neighborOf E T v = true ↔
    ∃ e ∈ E, (v = e.1 ∧ e.2 ∈ T) ∨ (v = e.2 ∧ e.1 ∈ T) := by
  simp [neighborOf,Bool.or_eq_true,Bool.and_eq_true,List.contains_iff_mem]

private theorem pin_iff {F T : List V} {x v} : pinned F T x v = true ↔
    v ∈ T ∨ v ∈ F ∧ x v = true := by
  simp [pinned,Bool.or_eq_true,Bool.and_eq_true,List.contains_iff_mem]

private theorem eval_iff {E : EdgeList V} {x} : evaluates E x = true ↔
    ∃ e ∈ E, x e.1 = true ∧ x e.2 = true := by simp [evaluates,Bool.and_eq_true]

private theorem single_iff {E : EdgeList V} {F T v} : v ∈ singletons E F T ↔
    v ∈ F ∧ neighborOf E T v = true := by simp [singletons]

private theorem remains_iff {E : EdgeList V} {F T v} : v ∈ remainder E F T ↔
    v ∈ F ∧ neighborOf E T v = false := by simp [remainder]

private theorem inside_iff {E : EdgeList V} {R e} : e ∈ inside E R ↔ e ∈ E ∧ e.1 ∈ R ∧ e.2 ∈ R := by
  simp [inside,Bool.and_eq_true,List.contains_iff_mem]

/-- A fixed edge makes the output constant. Otherwise each surviving term is either a free
neighbor of a true vertex or an edge with both endpoints outside all such neighbors. -/
theorem edge_cofactor (E : EdgeList V) (F T : List V) (x : Assignment V) :
    evaluates E (pinned F T x) =
    (evaluates E T.contains || (singletons E F T).any x || evaluates (inside E (remainder E F T)) x) := by
  apply Bool.eq_iff_iff.mpr
  simp only [Bool.or_eq_true]
  constructor
  · intro h
    obtain ⟨e,he,xa,xb⟩ := eval_iff.mp h
    rcases pin_iff.mp xa with a|⟨a,va⟩ <;> rcases pin_iff.mp xb with b|⟨b,vb⟩
    · exact Or.inl (Or.inl (eval_iff.mpr ⟨e,he,List.contains_iff_mem.mpr a,List.contains_iff_mem.mpr b⟩))
    · exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨e.2,single_iff.mpr
        ⟨b,neighbor_iff.mpr ⟨e,he,Or.inr ⟨rfl,a⟩⟩⟩,vb⟩))
    · exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨e.1,single_iff.mpr
        ⟨a,neighbor_iff.mpr ⟨e,he,Or.inl ⟨rfl,b⟩⟩⟩,va⟩))
    · cases na : neighborOf E T e.1 <;> cases nb : neighborOf E T e.2
      · exact Or.inr (eval_iff.mpr ⟨e,inside_iff.mpr
          ⟨he,remains_iff.mpr ⟨a,na⟩,remains_iff.mpr ⟨b,nb⟩⟩,va,vb⟩)
      · exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨e.2,single_iff.mpr ⟨b,nb⟩,vb⟩))
      all_goals exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨e.1,single_iff.mpr ⟨a,na⟩,va⟩))
  · rintro ((fixed|single)|rest)
    · obtain ⟨e,he,ta,tb⟩ := eval_iff.mp fixed
      exact eval_iff.mpr ⟨e,he,pin_iff.mpr (Or.inl (List.contains_iff_mem.mp ta)),
        pin_iff.mpr (Or.inl (List.contains_iff_mem.mp tb))⟩
    · obtain ⟨v,hv,value⟩ := List.any_eq_true.mp single
      obtain ⟨free,adj⟩ := single_iff.mp hv
      obtain ⟨e,he,a|b⟩ := neighbor_iff.mp adj
      · obtain ⟨eq,t⟩ := a
        exact eval_iff.mpr ⟨e,he,pin_iff.mpr (Or.inr ⟨eq ▸ free,eq ▸ value⟩),pin_iff.mpr (Or.inl t)⟩
      · obtain ⟨eq,t⟩ := b
        exact eval_iff.mpr ⟨e,he,pin_iff.mpr (Or.inl t),pin_iff.mpr (Or.inr ⟨eq ▸ free,eq ▸ value⟩)⟩
    · obtain ⟨e,he,va,vb⟩ := eval_iff.mp rest
      obtain ⟨inE,ar,br⟩ := inside_iff.mp he
      exact eval_iff.mpr ⟨e,inE,pin_iff.mpr (Or.inr ⟨(remains_iff.mp ar).1,va⟩),
        pin_iff.mpr (Or.inr ⟨(remains_iff.mp br).1,vb⟩)⟩

#print axioms edge_cofactor
end PetersenResidual
