import catalogue.EightCensus

open PetersenSignedBridge PetersenWordCost PetersenInducedCostTable PetersenUpperTable
namespace PetersenGraphCatalogue
set_option maxHeartbeats 0
set_option maxRecDepth 100000

private theorem other_known {m k} (h : (m,k) ∈ representatives) (apart : m ≠ 1020) :
    lower m k ∧ achievable m k := by
  rw [representatives,List.mem_append] at h
  rcases h with old|new
  · exact table_exact _ old
  · simp only [List.mem_cons,List.not_mem_nil,or_false] at new
    rcases new with h|h <;> cases h
    · exact exact1018
    · exact False.elim (apart rfl)

private theorem except_repr : ∀ s : Fin 1024, (vertices s.val).length ≤ 8 →
    ((vertices s.val).length ≠ 8 ∨ eightPrice s.val = 12) → (query s.val).repr ≠ 1020 := by decide +kernel

/-- All costs through seven vertices, and all eight-vertex nonadjacent deletions, use the smaller basis. -/
theorem except_adjacent (s : Fin 1024) (size : (vertices s.val).length ≤ 8)
    (away : (vertices s.val).length ≠ 8 ∨ eightPrice s.val = 12) :
    exactCost s.val (query s.val).price := by
  let w := query s.val
  have h : verifies s.val w = true := checked s size
  by_cases zero : w.price = 0
  · have empty : induced s.val = [] := List.isEmpty_iff.mp (by simpa [verifies,zero] using h)
    refine ⟨Or.inl zero,?_⟩
    change achievable s.val w.price
    unfold achievable
    rw [zero,empty]
    exact ⟨_,Run.start,by simpa [graphTarget,read_pack] using
      (Av.zero (W := (inputs (vertices s.val).length).map read))⟩
  · simp only [verifies,ite_eq_right zero] at h
    obtain ⟨left,back⟩ := Bool.and_eq_true_iff.mp h
    obtain ⟨known,forward⟩ := Bool.and_eq_true_iff.mp left
    obtain ⟨lb,ub⟩ := other_known (List.contains_iff_mem.mp known) (except_repr s size away)
    exact ⟨Or.inr (PetersenGraphRelabel.lower forward lb),PetersenGraphRelabel.upper_map back ub⟩

#print axioms except_adjacent
end PetersenGraphCatalogue
