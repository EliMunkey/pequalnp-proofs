import catalogue.AllPinsKnown
open PetersenWordCost PetersenInducedCostTable PetersenGraphCatalogue PetersenSingleton
namespace PetersenMaskCofactor

def pairFree (i j : Fin 10) : Fin 1024 := ⟨1023-((1<<<i.val)|||(1<<<j.val)),by omega⟩
def pairOn (i j : Fin 10) (a b : Bool) : Fin 1024 :=
  Fin.ofNat _ ((if a then 1<<<i.val else 0)|||(if b then 1<<<j.val else 0))
def adjacent (i j : Fin 10) : Bool := edges.contains (i.val,j.val) || edges.contains (j.val,i.val)

def pairPrice (i j : Fin 10) (a b : Bool) : Nat :=
  if adjacent i j then
    if a && b then 0 else if a || b then 10 else 13
  else if a && b then 7 else if a || b then 8 else 12

set_option maxHeartbeats 0
set_option maxRecDepth 200000

private theorem checked_pairs : ∀ i j : Fin 10, ∀ a b : Bool, i ≠ j →
    (vertices (pairFree i j).val).length = 8 ∧
    gateCount (pairFree i j).val (pairOn i j a b).val = pairPrice i j a b ∧
    (pairPrice i j a b ≠ 13 →
      (vertices (tailMask (pairFree i j).val (pairOn i j a b).val).val).length ≠ 8 ∨
      eightPrice (tailMask (pairFree i j).val (pairOn i j a b).val).val = 12) := by decide +kernel

/-- The six entries for all double pins, including the two orders of the unequal fixed values. -/
theorem pair_exact (h1020 : lower 1020 13) (i j : Fin 10) (a b : Bool) (different : i ≠ j) :
    Minimum ((inputs (vertices (pairFree i j).val).length).map read)
      (read (table (pairFree i j).val (pairOn i j a b).val)) (pairPrice i j a b) := by
  obtain ⟨size,eq,_⟩ := checked_pairs i j a b different
  rw [←eq]
  exact all_pins h1020 _ _ (by omega)

/-- All 165 double pin assignments outside the adjacent 00 case require only the smaller basis. -/
theorem pair_exact_except_13 (i j : Fin 10) (a b : Bool) (different : i ≠ j) (other : pairPrice i j a b ≠ 13) :
    Minimum ((inputs (vertices (pairFree i j).val).length).map read)
      (read (table (pairFree i j).val (pairOn i j a b).val)) (pairPrice i j a b) := by
  obtain ⟨size,eq,known⟩ := checked_pairs i j a b different
  rw [←eq]
  exact pins_known _ _ (by omega) (known other)

#print axioms pair_exact_except_13
end PetersenMaskCofactor
