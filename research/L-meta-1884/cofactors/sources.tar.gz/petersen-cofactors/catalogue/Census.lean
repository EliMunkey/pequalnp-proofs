import catalogue.CensusRecords
open PetersenInducedCostTable
namespace PetersenGraphCatalogue
def group : Nat → Array Entry
  | 0 => group0
  | 1 => group1
  | 2 => group2
  | 3 => group3
  | 4 => group4
  | 5 => group5
  | 6 => group6
  | 7 => group7
  | 8 => group8
  | 9 => group9
  | 10 => group10
  | 11 => group11
  | 12 => group12
  | 13 => group13
  | 14 => group14
  | 15 => group15
  | 16 => group16
  | 17 => group17
  | 18 => group18
  | 19 => group19
  | 20 => group20
  | 21 => group21
  | 22 => group22
  | 23 => group23
  | 24 => group24
  | 25 => group25
  | 26 => group26
  | 27 => group27
  | 28 => group28
  | 29 => group29
  | 30 => group30
  | 31 => group31
  | _ => #[]
def query (s : Nat) : Entry := ((group (s/32))[s%32]?).getD default
private theorem group_ok (g : Fin 32) (i : Fin 32) (h : (vertices (32*g.val+i.val)).length ≤ 8) :
    verifies (32*g.val+i.val) (((group g.val)[i.val]?).getD default) = true := by
  fin_cases g
  · exact check0 i h
  · exact check1 i h
  · exact check2 i h
  · exact check3 i h
  · exact check4 i h
  · exact check5 i h
  · exact check6 i h
  · exact check7 i h
  · exact check8 i h
  · exact check9 i h
  · exact check10 i h
  · exact check11 i h
  · exact check12 i h
  · exact check13 i h
  · exact check14 i h
  · exact check15 i h
  · exact check16 i h
  · exact check17 i h
  · exact check18 i h
  · exact check19 i h
  · exact check20 i h
  · exact check21 i h
  · exact check22 i h
  · exact check23 i h
  · exact check24 i h
  · exact check25 i h
  · exact check26 i h
  · exact check27 i h
  · exact check28 i h
  · exact check29 i h
  · exact check30 i h
  · exact check31 i h

theorem checked (s : Fin 1024) (h : (vertices s.val).length ≤ 8) :
    verifies s.val (query s.val) = true := by
  let g : Fin 32 := ⟨s.val/32,by omega⟩
  let i : Fin 32 := ⟨s.val%32,by omega⟩
  have eq : 32*g.val+i.val = s.val := by dsimp [g,i]; omega
  have ok := group_ok g i (eq ▸ h)
  unfold query; rw [eq] at ok; exact ok

/-- Exact signed binary gate costs for all 1,013 Petersen-induced graphs on up to eight vertices. -/
theorem all_small (h1020 : lower 1020 13) (s : Fin 1024) (h : (vertices s.val).length ≤ 8) :
    exactCost s.val (query s.val).price := sound h1020 (checked s h)

end PetersenGraphCatalogue
