import higher.Relabel
import higher.UpperTable

open PetersenSignedBridge PetersenWordCost PetersenInducedCostTable PetersenUpperTable
namespace PetersenGraphCatalogue

structure Entry where
  repr : Nat
  price : Nat
  toRepr : List Nat
  fromRepr : List Nat
deriving Inhabited

def representatives := prices ++ [(1018,12),(1020,13)]

/-- Free constants compute every graph without edges. Other records include the two relabelings. -/
def verifies (s : Nat) (w : Entry) : Bool :=
  if w.price = 0 then (induced s).isEmpty else
    representatives.contains (w.repr,w.price) &&
    PetersenGraphRelabel.fits (vertices s).length (vertices w.repr).length w.toRepr (induced s) (induced w.repr) &&
    PetersenGraphRelabel.fits (vertices w.repr).length (vertices s).length w.fromRepr (induced w.repr) (induced s)

def exactCost (s price : Nat) : Prop :=
  (price = 0 ∨ lower s price) ∧ achievable s price

private theorem representative (h1020 : lower 1020 13) {m k}
    (h : (m,k) ∈ representatives) : lower m k ∧ achievable m k := by
  rw [representatives,List.mem_append] at h
  rcases h with old|new
  · exact table_exact _ old
  · simp only [List.mem_cons,List.not_mem_nil,or_false] at new
    rcases new with h|h <;> cases h
    · exact exact1018
    · exact ⟨h1020,upper1020⟩

theorem sound (h1020 : lower 1020 13) {s w} (h : verifies s w = true) : exactCost s w.price := by
  by_cases hz : w.price = 0
  · have empty : induced s = [] := List.isEmpty_iff.mp (by simpa [verifies,hz] using h)
    refine ⟨Or.inl hz,?_⟩
    unfold achievable
    rw [hz,empty]
    exact ⟨_,Run.start,by simpa [graphTarget,read_pack] using
      (Av.zero (W := (inputs (vertices s).length).map read))⟩
  · simp only [verifies,if_neg hz] at h
    obtain ⟨left,back⟩ := Bool.and_eq_true_iff.mp h
    obtain ⟨known,forward⟩ := Bool.and_eq_true_iff.mp left
    obtain ⟨lb,ub⟩ := representative h1020 (List.contains_iff_mem.mp known)
    exact ⟨Or.inr (PetersenGraphRelabel.lower forward lb),PetersenGraphRelabel.upper_map back ub⟩

#print axioms sound
end PetersenGraphCatalogue
