import catalogue.GraphCofactor
open PetersenSignedBridge PetersenSingleton PetersenGraphRelabel
namespace PetersenResidual
variable {V : Type} [DecidableEq V]

private theorem reorder {L K : List V} {f : Func (Assignment V)} {k : Nat}
    (same : ∀ v, v ∈ L ↔ v ∈ K) (base : Minimum (wires L) f k) : Minimum (wires K) f k := by
  have cov {U W : List V} (s : ∀ v ∈ U, v ∈ W) : Covers id (wires U) (wires W) := by
    intro a ha;obtain ⟨v,hv,rfl⟩ := List.mem_map.mp ha
    exact Av.wire (List.mem_map.mpr ⟨v,s v hv,rfl⟩)
  exact minimum_transport (fun _ => map_realized (cov (fun v => (same v).1)) (f := f) rfl)
    (fun _ => map_realized (cov (fun v => (same v).2)) (f := f) rfl) base

private theorem zeroCost (L : List V) (b : Bool) : Minimum (wires L) (fun _ => b) 0 := by
  refine ⟨⟨_,Run.start,?_⟩,by intro j h;omega⟩
  cases b <;> first | exact Av.zero | exact Av.one

private theorem pure (P R : List V) (nd : P.Nodup) (apart : ∀ v ∈ P, v ∉ R) :
    Minimum (wires (P++R)) (fun x => P.any x) (P.length-1) := by
  cases P with
  | nil => exact zeroCost R false
  | cons a Q =>
    obtain ⟨fresh,tail⟩ := List.nodup_cons.mp nd
    have source : Minimum (wires (a::R)) (fun x => x a) 0 :=
      ⟨⟨_,Run.start,Av.wire (List.mem_cons_self ..)⟩,by intro j h;omega⟩
    have no : both (fun x : Assignment V => x a) :=
      ⟨⟨fun _ => false,rfl⟩,⟨fun _ => true,rfl⟩⟩
    have supported : Supported (a::R) (fun x => x a) := fun _ _ eq => eq a (List.mem_cons_self ..)
    have disj : ∀ v ∈ Q, v ∉ a::R := by
      intro v hv bad;rcases List.mem_cons.mp bad with eq|inR
      · exact fresh (eq ▸ hv)
      · exact apart v (List.mem_cons_of_mem a hv) inR
    have price := add_many Q tail disj supported no source
    have perm := reorder (K := (a::Q)++R) (fun v => by simp [or_comm,or_left_comm,or_assoc]) price
    have target : withList Q (fun x => x a) = fun x => (a::Q).any x := by
      funext x;simp [withList,Bool.or_comm]
    simpa only [target,Nat.zero_add,List.length_cons,Nat.add_sub_cancel] using perm

private theorem graph_support (E : EdgeList V) (R : List V) : Supported R (evaluates (inside E R)) := by
  intro x y same;apply Bool.eq_iff_iff.mpr
  simp only [evaluates,List.any_eq_true,Bool.and_eq_true]
  constructor <;> rintro ⟨e,he,ha,hb⟩ <;> refine ⟨e,he,?_⟩
  all_goals
    have hr : e.1 ∈ R ∧ e.2 ∈ R := by simpa [inside,Bool.and_eq_true] using (List.mem_filter.mp he).2
    simp_all [same _ hr.1,same _ hr.2]

def price (E : EdgeList V) (F T : List V) (base : Nat) : Nat :=
  let P := singletons E F T
  if evaluates E T.contains then 0 else
    if (inside E (remainder E F T)).isEmpty then P.length-1 else base+P.length

theorem cofactor_minimum (E : EdgeList V) (F T : List V) (nd : F.Nodup) {k : Nat}
    (base : Minimum (wires (remainder E F T)) (evaluates (inside E (remainder E F T))) k) :
    Minimum (wires F) (fun x => evaluates E (pinned F T x)) (price E F T k) := by
  let P := singletons E F T
  let R := remainder E F T
  have same : ∀ v, v∈P++R ↔ v∈F := by
    intro v;cases e : neighborOf E T v <;> simp [P,R,singletons,remainder,e]
  have pn : P.Nodup := List.Nodup.filter _ nd
  have apart : ∀ v ∈ P, v ∉ R := by
    intro v h; have one := (List.mem_filter.mp h).2
    simp [R,remainder,one]
  cases fixed : evaluates E T.contains with
  | true =>
    have target : (fun x => evaluates E (pinned F T x)) = fun _ => true := by
      funext x;simp [edge_cofactor,fixed]
    rw [target];simpa [price,fixed] using zeroCost F true
  | false =>
    cases empty : (inside E R).isEmpty with
    | true =>
      have noEdges : inside E R = [] := List.isEmpty_iff.mp empty
      have target : (fun x => evaluates E (pinned F T x)) = fun x => P.any x := by
        funext x;rw [edge_cofactor];change (evaluates E T.contains || P.any x || evaluates (inside E R) x) = _
        rw [fixed,noEdges]; simp [evaluates]
      rw [target]
      have amount : price E F T k = P.length-1 := by
        change (if evaluates E T.contains then 0 else if (inside E R).isEmpty then P.length-1 else k+P.length) = _
        rw [fixed,empty];rfl
      rw [amount]; exact reorder same (pure P R pn apart)
    | false =>
      have nc : both (evaluates (inside E R)) := by
        have ne : inside E R ≠ [] := by intro bad; simp [bad] at empty
        obtain ⟨⟨a,b⟩,hb⟩ := List.exists_mem_of_ne_nil _ ne
        refine ⟨⟨fun _ => false,?_⟩,⟨fun _ => true,?_⟩⟩
        · simp [evaluates]
        · exact List.any_eq_true.mpr ⟨(a,b),hb,rfl⟩
      have target : (fun x => evaluates E (pinned F T x)) = withList P (evaluates (inside E R)) := by
        funext x;rw [edge_cofactor];simp [fixed,withList,P,R]
      rw [target]
      have amount : price E F T k = k+P.length := by
        change (if evaluates E T.contains then 0 else if (inside E R).isEmpty then P.length-1 else k+P.length) = _
        rw [fixed,empty];rfl
      rw [amount]; exact reorder same (add_many P pn apart (graph_support E R) nc base)

theorem pinned_support (E : EdgeList V) (F T : List V) :
    Supported F (fun x => evaluates E (pinned F T x)) := by
  intro x y agree
  apply congrArg (evaluates E);funext v;by_cases hv : v ∈ F
  · simp [pinned,hv,agree _ hv]
  · simp [pinned,hv]

#print axioms cofactor_minimum
end PetersenResidual
