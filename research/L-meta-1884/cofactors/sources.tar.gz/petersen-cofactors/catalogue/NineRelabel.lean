import higher.Relabel
import higher.InducedCostTable
open PetersenWordCost PetersenInducedCostTable
namespace PetersenNineRelabel
set_option maxHeartbeats 0
set_option maxRecDepth 100000
private def maps : Nat → List Nat × List Nat
  | 511 => ([1,2,7,5,0,6,3,4,8],[4,0,1,6,7,3,5,2,8])
  | 767 => ([1,2,7,4,6,0,3,5,8],[5,0,1,6,3,7,4,2,8])
  | 895 => ([1,2,3,8,6,0,7,5,4],[5,0,1,2,8,7,4,6,3])
  | 959 => ([1,0,5,7,2,6,8,4,3],[1,0,4,8,7,2,5,3,6])
  | 991 => ([0,1,2,7,5,6,3,4,8],[0,1,2,6,7,4,5,3,8])
  | 1007 => ([0,1,2,3,5,6,7,8,4],[0,1,2,3,8,4,5,6,7])
  | 1015 => ([1,2,3,0,6,7,8,4,5],[3,0,1,2,7,8,4,5,6])
  | 1019 => ([1,0,3,2,6,5,4,8,7],[1,0,3,2,6,5,4,8,7])
  | 1021 => ([3,0,1,2,8,4,5,6,7],[1,2,3,0,5,6,7,8,4])
  | 1022 => ([0,1,2,3,4,5,6,7,8],[0,1,2,3,4,5,6,7,8])
  | _ => ([],[])
private theorem valid : ∀ s : Fin 1024, (vertices s.val).length = 9 →
    PetersenGraphRelabel.fits (vertices s.val).length (vertices 1022).length (maps s.val).1 (induced s.val) (induced 1022) = true ∧
    PetersenGraphRelabel.fits (vertices 1022).length (vertices s.val).length (maps s.val).2 (induced 1022) (induced s.val) = true := by decide +kernel

theorem lower_bound (k : Nat) (base : lower 1022 k) (s : Fin 1024) (h : (vertices s.val).length = 9) :
    lower s.val k := PetersenGraphRelabel.lower (valid s h).1 base

theorem upper_bound (k : Nat) (base : PetersenGraphRelabel.upper (vertices 1022).length (induced 1022) k)
    (s : Fin 1024) (h : (vertices s.val).length = 9) :
    PetersenGraphRelabel.upper (vertices s.val).length (induced s.val) k :=
  PetersenGraphRelabel.upper_map (valid s h).2 base

#print axioms lower_bound
end PetersenNineRelabel
