import catalogue.AllPins
import catalogue.KnownCosts
open PetersenWordCost PetersenInducedCostTable PetersenGraphCatalogue PetersenSingleton PetersenResidual
namespace PetersenMaskCofactor

theorem pins_known (free on : Fin 1024) (size : (vertices free.val).length ≤ 8)
    (other : (vertices (tailMask free.val on.val).val).length ≠ 8 ∨
      eightPrice (tailMask free.val on.val).val = 12) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) := by
  let F := vertices free.val
  let T := vertices on.val
  let r := tailMask free.val on.val
  have vertexEq : vertices r.val = remainder edges F T := tail_vertices ..
  have small : (vertices r.val).length ≤ 8 := by
    rw [vertexEq];exact (List.length_filter_le ..).trans size
  have minor := base_minimum (except_adjacent r small other)
  rw [vertexEq] at minor
  have nd : F.Nodup := List.Nodup.filter _ List.nodup_range
  exact (packed_iff F (pinned_support edges F T)).mp (cofactor_minimum edges F T nd minor)

/-- The 58,848 ordinary partial assignments pinning at least three of the ten inputs are covered
without the adjacent-deletion eight-vertex result. -/
theorem three_or_more_fixed (free on : Fin 1024) (size : (vertices free.val).length ≤ 7) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) := by
  apply pins_known _ _ (by omega)
  left
  rw [tail_vertices]
  have lim : (remainder edges (vertices free.val) (vertices on.val)).length ≤ (vertices free.val).length :=
    List.length_filter_le ..
  omega

#print axioms three_or_more_fixed
end PetersenMaskCofactor
