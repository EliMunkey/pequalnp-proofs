import catalogue.MaskCofactor
import catalogue.PinPrice
open PetersenWordCost PetersenInducedCostTable PetersenGraphCatalogue PetersenSingleton PetersenResidual
namespace PetersenMaskCofactor

/-- Bit-packed cofactor on the unfixed coordinates, in increasing original vertex order. -/
def table (free on : Nat) : BitVec (2^(vertices free).length) :=
  pack ((fun x => evaluates edges (pinned (vertices free) (vertices on) x)) ∘ namedRow (vertices free))

def gateCount (free on : Nat) : Nat :=
  price edges (vertices free) (vertices on) (query (tailMask free on).val).price

/-- Every actual partial assignment on at most eight free Petersen vertices has this exact
signed binary circuit cost, with arbitrary sharing, free complements and free constants. -/
theorem all_pins (adjacent : lower 1020 13) (free on : Fin 1024)
    (size : (vertices free.val).length ≤ 8) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) := by
  let F := vertices free.val
  let T := vertices on.val
  let r := tailMask free.val on.val
  have vertexEq : vertices r.val = remainder edges F T := tail_vertices ..
  have small : (vertices r.val).length ≤ 8 := by
    rw [vertexEq];exact (List.length_filter_le ..).trans size
  have minor := base_minimum (all_small adjacent r small)
  rw [vertexEq] at minor
  have nd : F.Nodup := List.Nodup.filter _ List.nodup_range
  exact (packed_iff F (pinned_support edges F T)).mp (cofactor_minimum edges F T nd minor)

/-- Pinning two adjacent vertices to one covers every remaining assignment. -/
example : gateCount 1020 3 = 0 := by decide +kernel
/-- Pinning both of those vertices to zero leaves the thirteen-gate graph. -/
example : gateCount 1020 0 = 13 := by decide +kernel

#print axioms all_pins
end PetersenMaskCofactor
