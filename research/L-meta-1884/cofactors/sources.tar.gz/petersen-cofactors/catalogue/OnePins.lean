import catalogue.PairTable
open PetersenWordCost PetersenInducedCostTable PetersenGraphCatalogue PetersenSingleton PetersenResidual
namespace PetersenMaskCofactor

/-- Only the surviving graph matters to the catalogue bound. The free singleton coordinates
need not satisfy the eight-vertex limit. -/
theorem from_tail {free on : Fin 1024}
    (known : exactCost (tailMask free.val on.val).val (query (tailMask free.val on.val).val).price) :
    Minimum ((inputs (vertices free.val).length).map read) (read (table free.val on.val))
      (gateCount free.val on.val) := by
  have vertexEq := tail_vertices free.val on.val
  have minor := base_minimum known
  rw [vertexEq] at minor
  have nd : (vertices free.val).Nodup := List.Nodup.filter _ List.nodup_range
  exact (packed_iff _ (pinned_support edges (vertices free.val) (vertices on.val))).mp (cofactor_minimum edges _ _ nd minor)

def oneFree (i : Fin 10) : Fin 1024 := ⟨1023 - (1<<<i.val),Nat.lt_succ_of_le (Nat.sub_le ..)⟩
def oneTrue (i : Fin 10) : Fin 1024 := Fin.ofNat _ (1<<<i.val)

set_option maxHeartbeats 0
set_option maxRecDepth 100000
private theorem one_data : ∀ i : Fin 10,
    (vertices (tailMask (oneFree i).val (oneTrue i).val).val).length = 6 ∧
    gateCount (oneFree i).val (oneTrue i).val = 11 := by decide +kernel

/-- Pinning any one Petersen vertex to true yields a nine-input target of exact signed cost eleven. -/
theorem single_true (i : Fin 10) :
    Minimum ((inputs (vertices (oneFree i).val).length).map read)
      (read (table (oneFree i).val (oneTrue i).val)) 11 := by
  obtain ⟨six,price⟩ := one_data i
  rw [←price]
  apply from_tail
  exact except_adjacent _ (by omega) (Or.inl (by omega))

#print axioms single_true
end PetersenMaskCofactor
