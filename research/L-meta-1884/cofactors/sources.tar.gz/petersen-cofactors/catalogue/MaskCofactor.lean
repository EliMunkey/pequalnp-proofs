import catalogue.GraphCofactor
import catalogue.Census
open PetersenWordCost PetersenInducedCostTable PetersenGraphCatalogue PetersenSingleton PetersenResidual
namespace PetersenMaskCofactor

def edges : EdgeList Nat :=
  [(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]

def tailMask (free on : Nat) : Fin 1024 :=
  (pack fun i : Fin 10 => free.testBit i && !neighborOf edges (vertices on) i).toFin

private theorem vmem {m i} : i ∈ vertices m ↔ i<10 ∧ m.testBit i = true := by simp [vertices]

theorem tail_vertices (free on : Nat) :
    vertices (tailMask free on).val = remainder edges (vertices free) (vertices on) := by
  unfold remainder vertices
  rw [List.filter_filter];apply List.filter_congr
  intro i hi
  have h := congrFun (read_pack (fun j : Fin 10 => free.testBit j && !neighborOf edges (vertices on) j)) ⟨i,List.mem_range.mp hi⟩
  change (tailMask free on).val.testBit i = (free.testBit i && !neighborOf edges (vertices on) i) at h
  rw [h];exact Bool.and_comm ..

private theorem reindex (m : Nat) :
    induced m = (inside edges (vertices m)).map (fun e => ((vertices m).idxOf e.1,(vertices m).idxOf e.2)) := by
  let R := vertices m
  let idx (e : Nat × Nat) := (R.idxOf e.1,R.idxOf e.2)
  have bounded : ∀ e ∈ edges, e.1 < 10 ∧ e.2 < 10 := by decide
  change edges.filterMap (fun e => if m.testBit e.1 && m.testBit e.2 then some (idx e) else none) =
    (edges.filter (fun e => R.contains e.1 && R.contains e.2)).map idx
  generalize eq : edges = L at bounded ⊢
  clear eq
  induction L with
  | nil => rfl
  | cons e L ih =>
    obtain ⟨a,b⟩ := bounded e (List.mem_cons_self ..)
    have hit (i) (lt : i<10) : R.contains i = m.testBit i := by
      apply Bool.eq_iff_iff.mpr
      simp [R,vmem,lt]
    have tailEq := ih (fun v h => bounded v (List.mem_cons_of_mem _ h))
    rw [List.filterMap_cons,List.filter_cons,hit _ a,hit _ b]
    cases z : m.testBit e.1 && m.testBit e.2
    · exact tailEq
    · exact congrArg (List.cons (idx e)) tailEq

private theorem graph_value (m : Nat) :
    onNamed (vertices m) (graphTarget (vertices m).length (induced m)) = evaluates (inside edges (vertices m)) := by
  funext x
  simp only [onNamed,Function.comp_apply,graphTarget,read_pack,reindex,List.any_map]
  unfold evaluates
  apply Bool.eq_iff_iff.mpr
  simp only [List.any_eq_true]
  have ends (e) (h : e ∈ inside edges (vertices m)) : e.1 ∈ vertices m ∧ e.2 ∈ vertices m := by
    simpa [inside,Bool.and_eq_true] using (List.mem_filter.mp h).2
  have bit (i) (h : i ∈ vertices m) :
      (wordRow (vertices m) x).val.testBit ((vertices m).idxOf i) = x i := by
    have hi := List.idxOf_lt_length_of_mem h
    have e := word_bit (vertices m) x ⟨(vertices m).idxOf i,hi⟩
    change _ = x ((vertices m)[(vertices m).idxOf i]) at e
    rwa [List.getElem_idxOf hi] at e
  constructor <;> rintro ⟨e,h,eq⟩ <;> refine ⟨e,h,?_⟩
  · simpa [Function.comp_def,bit _ (ends e h).1,bit _ (ends e h).2] using eq
  · simpa [Function.comp_def,bit _ (ends e h).1,bit _ (ends e h).2] using eq

theorem base_minimum {m k : Nat} (h : exactCost m k) :
    Minimum (wires (vertices m)) (evaluates (inside edges (vertices m))) k := by
  have nd : (vertices m).Nodup := List.Nodup.filter _ List.nodup_range
  rw [←graph_value]
  apply named_base nd
  refine ⟨h.2,?_⟩
  intro j less realized
  rcases h.1 with zero|pos
  · omega
  · obtain ⟨W,r,out⟩ := realized
    exact pos j (by omega) W r out

#print axioms base_minimum
end PetersenMaskCofactor
