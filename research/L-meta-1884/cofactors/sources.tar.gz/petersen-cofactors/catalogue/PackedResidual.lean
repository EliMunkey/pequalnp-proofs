import catalogue.Singletons
open PetersenSignedBridge PetersenSingleton PetersenWordCost PetersenGraphRelabel
namespace PetersenResidual
variable {V : Type} [DecidableEq V]

def namedRow (R : List V) (b : Fin (2^R.length)) : Assignment V :=
  fun v => b.val.testBit (R.idxOf v)

def wordRow (R : List V) (x : Assignment V) : Fin (2^R.length) :=
  (pack (fun i : Fin R.length => x R[i])).toFin

theorem word_bit (R : List V) (x : Assignment V) (i : Fin R.length) :
    (wordRow R x).val.testBit i = x R[i] :=
  congrFun (read_pack (fun j : Fin R.length => x R[j])) i

private theorem restore {R : List V} (x : Assignment V) {v : V} (inR : v ∈ R) :
    namedRow R (wordRow R x) v = x v := by
  have h := List.idxOf_lt_length_of_mem inR
  have eq := word_bit R x ⟨R.idxOf v,h⟩
  change (wordRow R x).val.testBit (R.idxOf v) = x (R[R.idxOf v]) at eq
  rw [List.getElem_idxOf h] at eq
  exact eq

private theorem packedCovers (R : List V) :
    Covers (wordRow R) ((inputs R.length).map read) (wires R) := by
  intro f hf
  obtain ⟨a,ha,rfl⟩ := List.mem_map.mp hf
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp ha
  rw [read_pack]
  have eq : (fun b : Fin (2^R.length) => b.val.testBit i.val) ∘ wordRow R = fun x => x R[i] :=
    funext fun x => word_bit R x i
  rw [eq]
  exact Av.wire (List.mem_map.mpr ⟨R[i],List.getElem_mem ..,rfl⟩)

private theorem namedCovers (R : List V) :
    Covers (namedRow R) (wires R) ((inputs R.length).map read) := by
  intro f hf
  obtain ⟨v,hv,rfl⟩ := List.mem_map.mp hf
  let i : Fin R.length := ⟨R.idxOf v,List.idxOf_lt_length_of_mem hv⟩
  let a := pack (fun b : Fin (2^R.length) => b.val.testBit i)
  have e : (fun x : Assignment V => x v) ∘ namedRow R = read a := (read_pack _).symm
  rw [e]; exact Av.wire (List.mem_map.mpr ⟨a,List.mem_ofFn.mpr ⟨i,rfl⟩,rfl⟩)

/-- A named Boolean function supported on a list has exactly the cost of its packed truth table
in those coordinates. The map may retain irrelevant or repeated input names. -/
theorem packed_iff (R : List V) {f : Func (Assignment V)} {k : Nat} (support : Supported R f) :
    Minimum (wires R) f k ↔
      Minimum ((inputs R.length).map read) (read (pack (f ∘ namedRow R))) k := by
  have same : read (pack (f ∘ namedRow R)) ∘ wordRow R = f := by
    rw [read_pack];funext x
    exact support _ _ (fun _ => restore x)
  have pc := packedCovers R
  have nc := namedCovers R
  constructor
  · exact minimum_transport (fun _ => map_realized nc (read_pack _).symm) (fun _ => map_realized pc same)
  · exact minimum_transport (fun _ => map_realized pc same) (fun _ => map_realized nc (read_pack _).symm)

theorem roundtrip (R : List V) (nd : R.Nodup) (b : Fin (2^R.length)) :
    wordRow R (namedRow R b) = b := by
  have e : pack (fun i : Fin R.length => namedRow R b R[i]) = BitVec.ofFin b := by
    apply BitVec.eq_of_getLsbD_eq
    intro j hj
    have q := word_bit R (namedRow R b) ⟨j,hj⟩
    change (pack (fun i : Fin R.length => namedRow R b R[i])).getLsbD j =
      b.val.testBit (R.idxOf R[j]) at q
    rwa [nd.idxOf_getElem j hj] at q
  exact congrArg BitVec.toFin e

def onNamed (R : List V) (t : BitVec (2^R.length)) : Func (Assignment V) := read t ∘ wordRow R

theorem onNamed_support (R : List V) (t : BitVec (2^R.length)) : Supported R (onNamed R t) := by
  intro x y agree
  have eq : (fun j : Fin R.length => x R[j]) = (fun j => y R[j]) :=
    funext fun j => agree _ (List.getElem_mem ..)
  exact congrArg (fun a : Fin R.length → Bool => read t (pack a).toFin) eq

theorem named_base {R : List V} (nd : R.Nodup) {t : BitVec (2^R.length)} {k : Nat}
    (base : Minimum ((inputs R.length).map read) (read t) k) : Minimum (wires R) (onNamed R t) k := by
  apply (packed_iff R (onNamed_support R t)).mpr
  have e : read (pack (onNamed R t ∘ namedRow R)) = read t := by
    rw [read_pack];funext x;simp [onNamed,roundtrip R nd]
  rwa [e]

theorem packed_add {R : List V} (rnodup : R.Nodup) (P : List V) (nd : P.Nodup)
    (apart : ∀ i ∈ P, i ∉ R) {t : BitVec (2^R.length)} {k : Nat}
    (no : ∃ x, read t x = false) (yes : ∃ x, read t x = true)
    (base : Minimum ((inputs R.length).map read) (read t) k) :
    Minimum ((inputs (P++R).length).map read)
      (read (pack (withList P (onNamed R t) ∘ namedRow (P++R)))) (k+P.length) := by
  obtain ⟨x,hx⟩ := no
  obtain ⟨y,hy⟩ := yes
  have nc : both (onNamed R t) := ⟨⟨namedRow R x,by simpa [onNamed,roundtrip R rnodup]⟩,
    ⟨namedRow R y,by simpa [onNamed,roundtrip R rnodup]⟩⟩
  exact (packed_iff _ (list_support (onNamed_support R t))).mp
    (add_many P nd apart (onNamed_support R t) nc (named_base rnodup base))

#print axioms packed_iff
#print axioms packed_add
end PetersenResidual
