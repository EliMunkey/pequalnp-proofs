#!/usr/bin/env python3
"""Build a checked source export using the pinned pequalnp-proofs Lean project."""
from argparse import ArgumentParser
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess

def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path, help="pequalnp-proofs checkout or its lean/ directory")
    parser.add_argument("--sources", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--out", type=Path, help="object and log directory (default SOURCES/build)")
    parser.add_argument("--module", help="override the entry module from the export")
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    source = args.sources.resolve()
    entry = source / "entry-module.txt"
    args.module = args.module or (entry.read_text().strip() if entry.is_file() else "higher.Exact1020")
    build = (args.out or source / "build").resolve()
    project = args.project.resolve()
    if not (project / "lean-toolchain").exists():
        project = project / "lean"
    if (project / "lean-toolchain").read_text().strip() != "leanprover/lean4:v4.36.0":
        parser.error("The source export uses Lean 4.36.0")
    actual = subprocess.check_output(["lake", "env", "lean", "--version"], cwd=project, text=True)
    if not re.search(r"Lean \(version 4\.36\.0(?:,|\))", actual):
        parser.error("Expected Lean 4.36.0 from lake, found " + actual.strip())
    owner_hashes = {
        "PEqualNP/Defs/MetaComplexity.lean": "863a9682c4e45a88aa71112f51d40cd2e308d2790acbcbcc4cf388cc8e8ce303",
        "lake-manifest.json": "d0af863cde532caaef1b1bee0d63ec47100208e33e488309cb80abc88b8f1509",
    }
    for rel, expected in owner_hashes.items():
        if sha256((project / rel).read_bytes()).hexdigest() != expected:
            parser.error("Project source differs from the pinned checkout: " + rel)
    for line in (source / "SHA256SUMS").read_text().splitlines():
        digest, path = line.split("  ", 1)
        if sha256((source / path).read_bytes()).hexdigest() != digest:
            raise SystemExit("Source checksum mismatch: " + path)
    modules = set((source / "modules.txt").read_text().split())
    if args.module not in modules:
        parser.error("Selected module is missing from the source manifest")
    paths = {m: Path(*m.split(".")).with_suffix(".lean") for m in modules}
    deps = {}
    def collect(m):
        if m in deps:
            return
        text = (source / paths[m]).read_text()
        deps[m] = set(re.findall(r"^import ([A-Za-z_][.\w]+)", text, re.M)) & modules
        for dep in deps[m]:
            collect(dep)
    collect(args.module)
    build.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, LEAN_PATH=str(build))
    def object_file(m):
        return (build / paths[m]).with_suffix(".olean")
    def compile_module(m):
        path = source / paths[m]
        obj = object_file(m)
        inputs = [path, *(object_file(d) for d in deps[m])]
        if obj.is_file() and obj.stat().st_mtime_ns >= max(f.stat().st_mtime_ns for f in inputs):
            return
        obj.parent.mkdir(parents=True, exist_ok=True)
        partial = obj.with_suffix(".tmp.olean")
        log = obj.with_suffix(".log")
        with log.open("w") as stream:
            result = subprocess.run(["lake", "env", "lean", "-j", "2", "--root="+str(source), "-o",
                                     str(partial), str(path)], env=env, cwd=project,
                                    stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(m + "\n" + log.read_text())
        partial.replace(obj)
        print("checked", m, flush=True)
    done = set()
    active = {}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while len(done) < len(deps):
            ready = sorted(m for m in deps.keys() - done - set(active.values()) if deps[m] <= done)
            for m in ready[:args.jobs-len(active)]:
                active[pool.submit(compile_module, m)] = m
            if not active:
                raise RuntimeError("Module dependency cycle")
            for job in wait(active, return_when=FIRST_COMPLETED).done:
                job.result()
                done.add(active.pop(job))
    print("verified", args.module, "with", len(deps), "source modules")
    log = object_file(args.module).with_suffix(".log")
    if log.exists():
        print(log.read_text(), end="")

if __name__ == "__main__":
    main()
