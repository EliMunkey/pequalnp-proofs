import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules6
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot645
import Full18Quot4001
import Full18Quot17779
import Full18Quot18257
import Full18Quot18639
import Full18Quot19798
import Full18Quot19807
import Full18Quot19822
import Full18Quot20218
import Full18Quot21361
import PetersenProjectedRule
import Full18StepS501
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient501 (h : Needs) : Blocked Root17.tgt 15 live501 := by
  apply stepS501
  · change ∀ r ∈ [rule7443,rule5881,rule8075,rule6590,rule5944,rule6082,rule6725,rule3250,rule8051,rule7568,rule7496,rule2827,rule3924,rule5999,rule8022,rule7459], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5881) (quickSound5881 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3250) (quickSound3250 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7568) (quickSound7568 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7496) (quickSound7496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2827) (quickSound2827 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3924) (quickSound3924 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5999) (quickSound5999 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22259,live22330,live21580,live21640,live20331,live17779,live8871,live20599,live18186,live7750,live20827,live18588,live6540,live21164,live19269,live4001,live21361,live21359,live19807,live19798,live645,live10147,live18257,live18648,live19307,live19822,live19808,live19799,live9432,live18709,live19346,live19835,live19809,live19800,live8312,live19385,live19824,live19810,live19801,live7108,live19838,live19812,live19803,live4586], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22259) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live22259) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22330) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2] (L := live22330) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21580) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live21580) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21640) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live21640) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20331) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2] (L := live20331) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live17779) (quotient17779 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live8871) (PetersenFastSymmetry.move [thinSym0] (L := live8871) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20599) (PetersenFastSymmetry.move [thinSym1,thinSym2] (L := live20599) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18186) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live18186) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live7750) (PetersenFastSymmetry.move [thinSym3] (L := live7750) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20827) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2] (L := live20827) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18588) (PetersenFastSymmetry.move [thinSym3] (L := live18588) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live6540) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live6540) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21164) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2] (L := live21164) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19269) (PetersenFastSymmetry.move [thinSym0] (L := live19269) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live4001) (quotient4001 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21361) (quotient21361 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21359) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live21359) (V := live19807) (by decide +kernel) (quotient19807 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19807) (quotient19807 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19798) (quotient19798 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live645) (quotient645 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live10147) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live10147) (V := live645) (by decide +kernel) (quotient645 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18257) (quotient18257 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18648) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live18648) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19307) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live19307) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19822) (quotient19822 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19808) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live19808) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19799) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live19799) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live9432) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live9432) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18709) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live18709) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19346) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live19346) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19835) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live19835) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19809) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1] (L := live19809) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19800) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live19800) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live8312) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2] (L := live8312) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19385) (PetersenFastSymmetry.move [thinSym0] (L := live19385) (V := live18257) (by decide +kernel) (quotient18257 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19824) (PetersenFastSymmetry.move [thinSym3] (L := live19824) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19810) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1] (L := live19810) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19801) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live19801) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live7108) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live7108) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19838) (PetersenFastSymmetry.move [thinSym0] (L := live19838) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19812) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live19812) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19803) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2] (L := live19803) (V := live17779) (by decide +kernel) (quotient17779 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live4586) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live4586) (V := live4001) (by decide +kernel) (quotient4001 h)) <|
      PetersenLocalChildren.nil
end Full18
