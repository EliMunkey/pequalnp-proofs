import Full18ThinRules3
import Full18ThinRules5
import Full18ThinRules7
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot10830
import Full18Quot18629
import Full18Quot18639
import Full18Quot19092
import Full18Quot19846
import Full18Quot19847
import Full18Quot21179
import Full18Quot21362
import Full18Quot21503
import PetersenProjectedRule
import Full18StepS461
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient461 (h : Needs) : Blocked Root17.tgt 15 live461 := by
  apply stepS461
  · change ∀ r ∈ [rule3052,rule8081,rule6674,rule7443,rule7546,rule8051,rule8075,rule7469,rule8022,rule7505,rule6725,rule8000,rule5209,rule5450,rule5394,rule3921,rule5156,rule5496,rule5549,rule5557,rule5257,rule5571,rule7459,rule6590,rule5275,rule5277,rule5550,rule5284,rule3228,rule5297,rule5535], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8081) (quickSound8081 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7546) (quickSound7546 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7505) (quickSound7505 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5209) (quickSound5209 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5450) (quickSound5450 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5394) (quickSound5394 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3921) (quickSound3921 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5156) (quickSound5156 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5496) (quickSound5496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5549) (quickSound5549 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5257) (quickSound5257 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5571) (quickSound5571 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5275) (quickSound5275 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5277) (quickSound5277 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5550) (quickSound5550 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5284) (quickSound5284 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3228) (quickSound3228 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5297) (quickSound5297 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5535) (quickSound5535 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22219,live12851,live22284,live21643,live20851,live19870,live18683,live19884,live19885,live19872,live19092,live18709], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22219) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3] (L := live22219) (V := live21503) (by decide +kernel) (quotient21503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live12851) (PetersenFastSymmetry.move [thinSym3] (L := live12851) (V := live10830) (by decide +kernel) (quotient10830 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22284) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3] (L := live22284) (V := live21503) (by decide +kernel) (quotient21503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21643) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live21643) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20851) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0] (L := live20851) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19870) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live19870) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18683) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live18683) (V := live18629) (by decide +kernel) (quotient18629 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19884) (PetersenFastSymmetry.move [thinSym3] (L := live19884) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19885) (PetersenFastSymmetry.move [thinSym3] (L := live19885) (V := live19847) (by decide +kernel) (quotient19847 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19872) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live19872) (V := live19847) (by decide +kernel) (quotient19847 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19092) (quotient19092 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18709) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live18709) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.nil
end Full18
