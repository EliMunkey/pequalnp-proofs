import Full18ThinRules3
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot1957
import Full18Quot1958
import Full18Quot4576
import Full18Quot4577
import Full18Quot18650
import Full18Quot19092
import Full18Quot21179
import Full18Quot21252
import Full18Quot21274
import Full18Quot21361
import Full18Quot21362
import PetersenProjectedRule
import Full18StepS514
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient514 (h : Needs) : Blocked Root17.tgt 15 live514 := by
  apply stepS514
  · change ∀ r ∈ [rule8051,rule5209,rule6082,rule7443,rule7568,rule4257,rule4221,rule3924,rule3213,rule8022,rule7459,rule6590], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5209) (quickSound5209 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7568) (quickSound7568 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4257) (quickSound4257 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4221) (quickSound4221 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3924) (quickSound3924 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3213) (quickSound3213 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22342,live20162,live20703,live21363,live21275,live21252,live12261,live12260,live21265,live21654,live20836,live21280,live21254,live9331,live9330,live21268,live21291,live21258,live7006,live7005,live21270,live21361,live21274,live1958,live1957], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22342) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym2] (L := live22342) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20162) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live20162) (V := live18650) (by decide +kernel) (quotient18650 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20703) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live20703) (V := live18650) (by decide +kernel) (quotient18650 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21363) (PetersenFastSymmetry.move [thinSym0] (L := live21363) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21275) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21275) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21252) (quotient21252 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live12261) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3] (L := live12261) (V := live4576) (by decide +kernel) (quotient4576 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live12260) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3] (L := live12260) (V := live4577) (by decide +kernel) (quotient4577 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21265) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live21265) (V := live19092) (by decide +kernel) (quotient19092 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21654) (PetersenFastSymmetry.move [thinSym0,thinSym2] (L := live21654) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20836) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live20836) (V := live18650) (by decide +kernel) (quotient18650 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21280) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live21280) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21254) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym2,thinSym0] (L := live21254) (V := live21252) (by decide +kernel) (quotient21252 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live9331) (PetersenFastSymmetry.move [thinSym0] (L := live9331) (V := live4576) (by decide +kernel) (quotient4576 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live9330) (PetersenFastSymmetry.move [thinSym0] (L := live9330) (V := live4577) (by decide +kernel) (quotient4577 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21268) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1] (L := live21268) (V := live19092) (by decide +kernel) (quotient19092 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21291) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21291) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21258) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0] (L := live21258) (V := live21252) (by decide +kernel) (quotient21252 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live7006) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live7006) (V := live4576) (by decide +kernel) (quotient4576 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live7005) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live7005) (V := live4577) (by decide +kernel) (quotient4577 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21270) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2,thinSym3] (L := live21270) (V := live19092) (by decide +kernel) (quotient19092 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21361) (quotient21361 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21274) (quotient21274 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live1958) (quotient1958 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live1957) (quotient1957 h) <|
      PetersenLocalChildren.nil
end Full18
