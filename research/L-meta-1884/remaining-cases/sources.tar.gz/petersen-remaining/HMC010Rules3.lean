import Extra1020K12
import HMC010G6
import HMC010G7
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule122 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages122 s.steps 128 4 i5 p
theorem correct122 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule122 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r122 tgt) 4 := by rw [match122]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk122 s small hot122 p hit
def rule123 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages123 s.steps 64 4 i5 p
theorem correct123 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule123 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r123 tgt) 4 := by rw [match123]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk123 s small hot123 p hit
def rule124 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages124 s.steps 32 4 i5 p
theorem correct124 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule124 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r124 tgt) 4 := by rw [match124]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk124 s small hot124 p hit
def rule129 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages129 s.steps 32 4 i5 p
theorem correct129 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule129 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r129 tgt) 4 := by rw [match129]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk129 s small hot129 p hit
def rule131 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages131 s.steps 0 4 i5 p
theorem correct131 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule131 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r131 tgt) 4 := by rw [match131]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk131 s small hot131 p hit
def rule140 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages140 s.steps 32 4 i5 p
theorem correct140 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule140 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r140 tgt) 4 := by rw [match140]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk140 s small hot140 p hit
def rule141 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages141 s.steps 0 4 i5 p
theorem correct141 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule141 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r141 tgt) 4 := by rw [match141]; exact Extra1020K12.b55_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk141 s small hot141 p hit
def rule143 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages143 s.steps 64 4 i5 p
theorem correct143 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule143 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r143 tgt) 4 := by rw [match143]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk143 s small hot143 p hit
def rule146 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages146 s.steps 0 3 i4 p
theorem correct146 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule146 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r146 tgt) 3 := by rw [match146]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk146 s small hot146 p hit
def rule167 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages167 s.steps 32 4 i5 p
theorem correct167 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule167 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r167 tgt) 4 := by rw [match167]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk167 s small hot167 p hit
def rule169 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages169 s.steps 0 3 i4 p
theorem correct169 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule169 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r169 tgt) 3 := by rw [match169]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk169 s small hot169 p hit
def rule179 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages179 s.steps 64 4 i5 p
theorem correct179 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule179 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r179 tgt) 4 := by rw [match179]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk179 s small hot179 p hit
def rule189 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages189 s.steps 128 4 i5 p
theorem correct189 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule189 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r189 tgt) 4 := by rw [match189]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk189 s small hot189 p hit
def rule190 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages190 s.steps 64 4 i5 p
theorem correct190 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule190 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r190 tgt) 4 := by rw [match190]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk190 s small hot190 p hit
def rule191 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages191 s.steps 32 4 i5 p
theorem correct191 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule191 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r191 tgt) 4 := by rw [match191]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk191 s small hot191 p hit
def rule195 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages195 s.steps 64 4 i5 p
theorem correct195 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule195 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r195 tgt) 4 := by rw [match195]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk195 s small hot195 p hit
def rule198 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages198 s.steps 0 3 i4 p
theorem correct198 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule198 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r198 tgt) 3 := by rw [match198]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk198 s small hot198 p hit
def rule206 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages206 s.steps 0 4 i5 p
theorem correct206 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule206 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r206 tgt) 4 := by rw [match206]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk206 s small hot206 p hit
def rule211 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages211 s.steps 0 4 i5 p
theorem correct211 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule211 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r211 tgt) 4 := by rw [match211]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk211 s small hot211 p hit
def rule216 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages216 s.steps 0 4 i5 p
theorem correct216 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule216 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r216 tgt) 4 := by rw [match216]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk216 s small hot216 p hit
end MC010Cert
