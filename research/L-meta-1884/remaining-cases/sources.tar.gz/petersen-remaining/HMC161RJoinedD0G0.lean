import first8.AdjacentSym
import HMC161RHyp
import HMC161RJoinedD1G0
import HMC161RJoinedD1G1
import HMC161RJoinedD1G2
import HMC161RRules0
import HMC161RRules4
import HMC161RSym
import HMC161RW0
import HMC161RW1
import PetersenSymmetry
import Q1020K12Closing
import first8.MixedNode
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 150000
set_option maxHeartbeats 0
set_option linter.concreteInstances false

def s0_0 : List (BitVec 256) := [w56,w298,w341,w379,w391,w423,w456,w501,w537]
private def c0_0 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule26 route0 [(false,(6,false),(2,true))],rule2 route0 [],rule2 route5 [],rule26 route1 [],rule3 route4 [],rule30 route0 [],rule30 route0 [(false,(0,false),(5,true))],rule412 route2 [],rule411 route0 [],rule410 route5 [],rule26 route3 [],rule26 route5 [],rule26 route5 [(false,(6,false),(2,true))],rule26 route4 [],rule30 route5 [],rule30 route5 [(false,(0,false),(5,true))],rule412 route6 [],rule411 route5 [],rule410 route0 [],rule26 route7 [],rule3 route1 [],rule30 route4 [(false,(3,false),(2,true))],rule32 route5 [(false,(6,false),(2,true))],rule34 route5 [(false,(2,false),(6,true))],rule30 route2 [(false,(5,false),(0,true))],rule26 route1 [(false,(4,false),(0,true))],rule30 route7 [(false,(2,false),(3,true))],rule26 route4 [(false,(4,false),(0,true))],rule34 route0 [(false,(2,false),(6,true))],rule26 route7 [(false,(0,false),(4,true))],rule26 route2 [(false,(2,false),(6,true))],rule26 route3 [(false,(0,false),(4,true))],rule32 route0 [(false,(6,false),(2,true))],rule30 route6 [(false,(5,false),(0,true))],rule30 route1 [(false,(3,false),(2,true))],rule26 route6 [(false,(2,false),(6,true))],rule30 route3 [(false,(2,false),(3,true))]]
private def m0_0 : Array (List (BitVec 256)) := #[[w298,w299,w341,w379,w391,w423,w456,w501,w537],[w32,w298,w341,w379,w391,w423,w456,w501,w537],[w39,w298,w341,w379,w391,w423,w456,w501,w537],[w298,w341,w350,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w350,w379,w391,w423,w456,w501,w537],[w28,w298,w341,w379,w391,w423,w456,w501,w537],[w298,w336,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w336,w341,w379,w391,w423,w456,w501,w537],[w298,w341,w379,w391,w392,w423,w456,w501,w537],[w21,w298,w341,w379,w391,w423,w456,w501,w537],[w298,w341,w379,w391,w423,w450,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537],[w53,w298,w341,w379,w391,w423,w456,w501,w537],[w298,w341,w379,w391,w423,w456,w501,w505,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w505,w537],[w7,w298,w341,w379,w391,w423,w456,w501,w537],[w298,w341,w379,w391,w423,w456,w498,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w498,w501,w537],[w298,w341,w379,w391,w423,w456,w501,w537,w566],[w56,w298,w341,w379,w391,w423,w456,w501,w566],[w56,w298,w341,w379,w391,w423,w456,w501,w537,w566],[w56,w298,w341,w374,w379,w391,w423,w456,w501,w537],[w56,w279,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w513,w537],[w56,w285,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w537,w550],[w56,w287,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w406,w423,w456,w501,w537],[w56,w207,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w482,w501,w537],[w56,w129,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w325,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w521,w537],[w56,w91,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w264,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w333,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w537,w555],[w44,w56,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w269,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w528,w537],[w56,w214,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w537,w560],[w56,w220,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w533,w537],[w56,w137,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w140,w298,w341,w379,w391,w423,w456,w501],[w56,w140,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w497,w501,w537],[w56,w298,w341,w379,w391,w423,w456,w501,w537,w581],[w56,w65,w298,w341,w379,w391,w423,w456,w501,w537],[w56,w102,w298,w341,w379,w391,w423,w456,w501,w537]]
private def hs0_0 : List (List Nat) := [[605,0,605,1,8315,38,8315,2,605,39,605,3,8315,4,8315,1],[349,40,349,2,9344,41,9344,42,349,43,349,5,9344,44,9344,45],[608,6,608,7,8832,8,8832,9,608,10,608,3,8832,11,8832,7],[16546,12,16546,13,8322,46,8322,3,16546,47,16546,2,8322,14,8322,13],[16554,15,16554,16,24778,17,24778,18,16554,19,16554,2,24778,20,24778,16],[379,0,33018,1,379,48,49,2],[668,50,668,3,8892,51,8892,52,668,53,668,21,8892,54,8892,55],[1246,0,1246,1,8442,56,57,58],[1120,8315,1120,1,349,605,349,59,93,605,1120,22,93,8315,349,60],[605,605,608,1,9339,9343,33247,9,608,9343,608,23,605,605,33247,24],[605,605,8322,1,2653,2661,16803,2,613,2661,8322,1,605,605,16803,13],[605,605,16554,1,4701,4717,16811,18,621,4717,16554,1,605,605,16811,16],[605,605,33018,1,8315,8315,33275,2,8315,8315,33018,25,605,605,33275,3],[605,605,668,1,2466,24763,2467,61,668,24763,668,26,605,605,2467,62],[605,605,1246,1,1502,33501,1503,63,733,33501,1246,1,605,605,1503,64],[349,349,32990,7,608,1120,608,9,96,1120,32990,10,96,349,608,27],[349,349,8322,13,2397,2405,8836,65,357,2405,8322,66,349,349,8836,28],[349,349,16554,29,4445,4461,33516,19,365,4461,16554,19,349,349,33516,30],[349,349,33018,2,9344,9344,33532,67,9344,9344,33018,68,349,349,33532,5],[349,349,2210,69,668,16540,668,70,156,16540,2210,71,156,349,668,72],[349,349,1246,73,4842,33245,4844,74,477,33245,1246,75,349,349,4844,76],[608,608,8322,13,2656,2664,9350,9,616,2664,8322,7,608,608,9350,13],[608,608,16554,7,4704,4720,17582,9,624,4720,16554,7,608,608,17582,16],[608,608,33018,7,8832,8832,9,9,8832,8832,33018,31,608,608,10,3],[608,608,668,24,3234,49438,3238,10,668,49438,668,32,608,608,3238,10],[608,608,4330,7,1246,32990,1246,9,222,32990,4330,7,222,608,1246,10],[8322,8322,16554,13,12418,12434,35058,18,8338,12434,16554,33,8322,8322,35058,29],[16546,16546,33018,13,8322,8322,35074,3,8322,8322,33018,34,16546,16546,35074,2],[668,8322,668,13,2210,16546,2210,77,162,16546,668,35,162,8322,2210,78],[1246,8322,1246,13,3294,49442,3302,79,1246,49442,1246,13,1254,8322,3302,80],[16554,16554,33018,16,24778,24778,18,18,24778,24778,33018,36,16554,16554,19,2],[668,33002,668,16,4266,16554,4266,18,170,16554,668,37,170,33002,4266,19],[1246,16554,1246,16,4330,33002,4330,18,234,33002,1246,16,234,16554,4330,19],[668,33018,668,3,8892,49466,8892,81,668,49466,668,21,8892,33018,8892,82],[1246,49,1246,2,33018,33018,57,58,250,83,84,85],[668,668,1246,86,17630,33564,17694,87,796,33564,1246,88,668,668,17694,89]]
theorem node0_0 [Assumptions] : Blocked tgt 12 s0_0 := by
  refine PetersenMixedNode.close (cut := c0_0) (more := m0_0) (hs := hs0_0) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(6,false),(2,true))]) (correct26 route0 [(false,(6,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 []) (correct2 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 []) (correct26 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 []) (correct3 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 []) (correct30 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(0,false),(5,true))]) (correct30 route0 [(false,(0,false),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route2 []) (correct412 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule411 route0 []) (correct411 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule410 route5 []) (correct410 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 []) (correct26 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(6,false),(2,true))]) (correct26 route5 [(false,(6,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 []) (correct26 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route5 []) (correct30 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route5 [(false,(0,false),(5,true))]) (correct30 route5 [(false,(0,false),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route6 []) (correct412 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule411 route5 []) (correct411 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule410 route0 []) (correct410 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 [(false,(3,false),(2,true))]) (correct30 route4 [(false,(3,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route5 [(false,(6,false),(2,true))]) (correct32 route5 [(false,(6,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(2,false),(6,true))]) (correct34 route5 [(false,(2,false),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 [(false,(5,false),(0,true))]) (correct30 route2 [(false,(5,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(4,false),(0,true))]) (correct26 route1 [(false,(4,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 [(false,(2,false),(3,true))]) (correct30 route7 [(false,(2,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(4,false),(0,true))]) (correct26 route4 [(false,(4,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(2,false),(6,true))]) (correct34 route0 [(false,(2,false),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(0,false),(4,true))]) (correct26 route7 [(false,(0,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(2,false),(6,true))]) (correct26 route2 [(false,(2,false),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(0,false),(4,true))]) (correct26 route3 [(false,(0,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true))]) (correct32 route0 [(false,(6,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route6 [(false,(5,false),(0,true))]) (correct30 route6 [(false,(5,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(3,false),(2,true))]) (correct30 route1 [(false,(3,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(2,false),(6,true))]) (correct26 route6 [(false,(2,false),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route3 [(false,(2,false),(3,true))]) (correct30 route3 [(false,(2,false),(3,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w299,w341,w379,w391,w423,w456,w501,w537]) node1_87 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w32,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_7) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w39,w298,w341,w379,w391,w423,w456,w501,w537]) node1_15 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w350,w379,w391,w423,w456,w501,w537]) node1_91 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w350,w379,w391,w423,w456,w501,w537]) node1_59 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w28,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) node1_3) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w336,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) node1_89) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w336,w341,w379,w391,w423,w456,w501,w537]) node1_58 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w379,w391,w392,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_87) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w21,w298,w341,w379,w391,w423,w456,w501,w537]) node1_7 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w379,w391,w423,w450,w456,w501,w537]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b1_13 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) node1_74 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w53,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_15) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w379,w391,w423,w456,w501,w505,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_91) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w505,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_59) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w7,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) node1_3) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w379,w391,w423,w456,w498,w501,w537]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) node1_89) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w498,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_58) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w298,w341,w379,w391,w423,w456,w501,w537,w566]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b1_19 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w566]) node1_83 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537,w566]) node1_82 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w374,w379,w391,w423,w456,w501,w537]) node1_60 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w279,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_42) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w513,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_69) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w285,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_38) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537,w550]) node1_79 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w287,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_43) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w406,w423,w456,w501,w537]) node1_69 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w207,w298,w341,w379,w391,w423,w456,w501,w537]) node1_38 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w482,w501,w537]) node1_76 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w129,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) node1_18) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w325,w341,w379,w391,w423,w456,w501,w537]) node1_56 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w521,w537]) node1_78 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w91,w298,w341,w379,w391,w423,w456,w501,w537]) node1_26 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w264,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) node1_26) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w333,w341,w379,w391,w423,w456,w501,w537]) node1_57 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537,w555]) node1_80 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w44,w56,w298,w341,w379,w391,w423,w456,w501,w537]) node1_16 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w269,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) node1_19) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w528,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_60) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w214,w298,w341,w379,w391,w423,w456,w501,w537]) node1_42 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537,w560]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_79) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w220,w298,w341,w379,w391,w423,w456,w501,w537]) node1_43 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w533,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_76) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w137,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) node1_18) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) node1_27) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w140,w298,w341,w379,w391,w423,w456,w501]) node1_27 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w140,w298,w341,w379,w391,w423,w456,w501,w537]) node1_28 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w497,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_57) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537,w581]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_80) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w65,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node1_16) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w56,w102,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) node1_19) <|
      PetersenLocalChildren.nil
end MC161RCert
