import Full18EarlyRule4971
import Full18EarlyRule6557
import Full18EarlyRule7991
import PetersenProjectedRule
import Full18StepFirst2
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem earlyFirst2 (child : Blocked Root17.tgt 16 live7) : PetersenRootOrbit.DeadPair Root17.tgt 17 Root17.primary.toFinset (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 1024) (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 1024) := by
  apply stepFirst2
  · change ∀ r ∈ [rule7991,rule6557], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7991) ordinary7991 <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6557) ordinary6557 <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live7], Blocked Root17.tgt 16 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 16 s)) (x := live7) child <|
      PetersenLocalChildren.nil
end Full18
