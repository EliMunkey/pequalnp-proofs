import PetersenLayerCheck
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
def rawInput5 : List (BitVec 32) := [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000]
theorem rawInput5_eq : rawInput5 = inputs 5 := by decide +kernel
def rawInput6 : List (BitVec 64) := [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000]
theorem rawInput6_eq : rawInput6 = inputs 6 := by decide +kernel
def rawInput7 : List (BitVec 128) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem rawInput7_eq : rawInput7 = inputs 7 := by decide +kernel
class Assumptions : Prop where
  h0 : NoAtMost (0xaaaa0000 :: rawInput5) 0xeaeaeac8 4
  h1 : NoAtMost (0xaaaa :: rawInput5) 0xfaeaf8c8 4
  h2 : NoAtMost (0xf000f0 :: rawInput5) 0xfaeaf8c8 4
  h3 : NoAtMost (0xaaaa :: rawInput5) 0xffeaf8c8 6
  h4 : NoAtMost (0xcccc :: rawInput5) 0xffeaf8c8 6
  h5 : NoAtMost (0xff00 :: rawInput5) 0xffeaf8c8 6
  h6 : NoAtMost (0xaa00aa :: rawInput5) 0xffeaf8c8 6
  h7 : NoAtMost (0xcc00cc :: rawInput5) 0xffeaf8c8 6
  h8 : NoAtMost (0xf000f0 :: rawInput5) 0xffeaf8c8 6
  h9 : NoAtMost (0xff0000 :: rawInput5) 0xffeaf8c8 6
  h10 : NoAtMost (0xa0a0a0a :: rawInput5) 0xffeaf8c8 6
  h11 : NoAtMost (0xc0c0c0c :: rawInput5) 0xffeaf8c8 6
  h12 : NoAtMost (0xf000f00 :: rawInput5) 0xffeaf8c8 6
  h13 : NoAtMost (0xf0f0000 :: rawInput5) 0xffeaf8c8 6
  h14 : NoAtMost (0x30303030 :: rawInput5) 0xffeaf8c8 6
  h15 : NoAtMost (0x33003300 :: rawInput5) 0xffeaf8c8 6
  h16 : NoAtMost (0x33330000 :: rawInput5) 0xffeaf8c8 6
  h17 : NoAtMost (0x44444444 :: rawInput5) 0xffeaf8c8 6
  h18 : NoAtMost (0x55005500 :: rawInput5) 0xffeaf8c8 6
  h19 : NoAtMost (0x55550000 :: rawInput5) 0xffeaf8c8 6
  h20 : NoAtMost (0xcccc0000 :: rawInput5) 0xffeaf8c8 6
  h21 : NoAtMost (0xeeeeeeee :: rawInput5) 0xffeaf8c8 6
  h22 : NoAtMost (0xfcfcfcfc :: rawInput5) 0xffeaf8c8 6
  h23 : NoAtMost (0xfff0fff0 :: rawInput5) 0xffeaf8c8 6
  h24 : NoAtMost (0xffffaaaa :: rawInput5) 0xffeaf8c8 6
  h25 : NoAtMost (0xffffff00 :: rawInput5) 0xffeaf8c8 6
  h26 : NoAtMost (0xf000f0 :: rawInput5) 0xfffff8c8 4
  h27 : NoAtMost (0xa0a0a0a :: rawInput5) 0xfffff8c8 4
  h28 : NoAtMost (0x33003300 :: rawInput5) 0xfffff8c8 4
  h29 : NoAtMost (0x44444444 :: rawInput5) 0xfffff8c8 4
  h30 : NoAtMost (0xcccccccc :: rawInput6) 0xfeeefcccfaeaf8c8 6
  h31 : NoAtMost (0xf000f000f000f0 :: rawInput6) 0xfeeefcccfaeaf8c8 6
  h32 : NoAtMost (0xf0f0f0f00000000 :: rawInput6) 0xfeeefcccfaeaf8c8 6
  h33 : NoAtMost (0xeeeeeeeeeeeeeeee :: rawInput6) 0xfeeefcccfaeaf8c8 6
  h34 : NoAtMost (0xffffffffcccccccc :: rawInput6) 0xfeeefcccfaeaf8c8 6
  h35 : NoAtMost (0xaaaaaaaa :: rawInput6) 0xffeafaeaffeaf8c8 7
  h36 : NoAtMost (0x8888888888888888 :: rawInput6) 0xffeafaeaffeaf8c8 7
  h37 : NoAtMost (0xaaaa0000aaaa0000 :: rawInput6) 0xffeafaeaffeaf8c8 7
  h38 : NoAtMost (0xaaaa0000aaaa :: rawInput6) 0xfffffffffaeaf8c8 5
  h39 : NoAtMost (0xf000f000f000f0 :: rawInput6) 0xfffffffffaeaf8c8 5
  h40 : NoAtMost (0xf000f000f000f0 :: rawInput6) 0xfffffffffffff8c8 5
  h41 : NoAtMost (0xa0a0a0a0a0a0a0a :: rawInput6) 0xfffffffffffff8c8 5
  h42 : NoAtMost (0x3300330033003300 :: rawInput6) 0xfffffffffffff8c8 5
  h43 : NoAtMost (0x4444444444444444 :: rawInput6) 0xfffffffffffff8c8 5
  h44 : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: rawInput7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8
  h45 : NoAtMost (0xffccffccffccffccffccffccffccffcc :: rawInput7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8
  h46 : NoAtMost (0xaaaaaaaaaaaaaaaa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h47 : NoAtMost (0xf0f0f0f0f0f0f0f0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h48 : NoAtMost (0xaaaaaaaa00000000aaaaaaaa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h49 : NoAtMost (0xf0f0f0f000000000f0f0f0f0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h50 : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h51 : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h52 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h53 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h54 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h55 : NoAtMost (0x50505050505050505050505050505050 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h56 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h57 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa00 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h58 : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h59 : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h60 : NoAtMost (0xf0f0f0f000000000f0f0f0f000000000 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h61 : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h62 : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h63 : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h64 : NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h65 : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h66 : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h67 : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h68 : NoAtMost (0xffffffffffffffffffffffff00000000 :: rawInput7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10
  h69 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: rawInput7) 0xfffffffffffffffffffffffffffff8c8 6
end MC010Cert
