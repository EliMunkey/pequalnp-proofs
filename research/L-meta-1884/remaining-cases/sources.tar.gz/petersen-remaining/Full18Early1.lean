import Full18EarlyRule4971
import Full18EarlyRule6557
import Full18EarlyRule7991
import PetersenProjectedRule
import Full18StepFirst1
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem earlyFirst1 (child : Blocked Root17.tgt 16 live6) : PetersenRootOrbit.DeadPair Root17.tgt 17 Root17.primary.toFinset (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 1024) (0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc : BitVec 1024) := by
  apply stepFirst1
  · change ∀ r ∈ [rule7991,rule4971], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7991) ordinary7991 <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4971) ordinary4971 <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live6], Blocked Root17.tgt 16 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 16 s)) (x := live6) child <|
      PetersenLocalChildren.nil
end Full18
