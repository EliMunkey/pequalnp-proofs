import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules8
import Full18ThinRules10
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot19822
import Full18Quot19846
import Full18Quot19847
import Full18Quot19857
import Full18Quot21362
import Full18Quot21502
import Full18Quot21503
import Full18Quot21537
import Full18Quot21540
import Full18Quot21644
import Full18Quot21645
import Full18Quot21646
import PetersenProjectedRule
import Full18StepS518
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient518 (h : Needs) : Blocked Root17.tgt 15 live518 := by
  apply stepS518
  · change ∀ r ∈ [rule8051,rule5209,rule8000,rule8022,rule6674,rule3943,rule6725,rule8030,rule4976,rule4984,rule4994,rule2938,rule1825,rule5040,rule5048,rule5107,rule5156,rule5057,rule5688,rule5245,rule5077,rule5275,rule5284,rule3919,rule3223,rule5297,rule5263], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5209) (quickSound5209 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3943) (quickSound3943 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8030) (quickSound8030 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4976) (quickSound4976 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4984) (quickSound4984 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4994) (quickSound4994 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2938) (quickSound2938 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1825) (quickSound1825 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5040) (quickSound5040 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5048) (quickSound5048 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5107) (quickSound5107 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5156) (quickSound5156 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5057) (quickSound5057 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5688) (quickSound5688 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5245) (quickSound5245 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5077) (quickSound5077 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5275) (quickSound5275 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5284) (quickSound5284 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3919) (quickSound3919 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3223) (quickSound3223 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5297) (quickSound5297 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5263) (quickSound5263 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22125,live22349,live22351,live21502,live21647,live21554,live21563,live21572,live21537,live21652,live21573,live21648,live21538,live21547,live21556,live21649,live21643,live21540,live21576,live21550,live21577,live21580], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22125) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live22125) (V := live21646) (by decide +kernel) (quotient21646 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22349) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3] (L := live22349) (V := live21644) (by decide +kernel) (quotient21644 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22351) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3] (L := live22351) (V := live21645) (by decide +kernel) (quotient21645 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21502) (quotient21502 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21647) (PetersenFastSymmetry.move [thinSym0] (L := live21647) (V := live21644) (by decide +kernel) (quotient21644 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21554) (PetersenFastSymmetry.move [thinSym0] (L := live21554) (V := live21503) (by decide +kernel) (quotient21503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21563) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live21563) (V := live19847) (by decide +kernel) (quotient19847 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21572) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live21572) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21537) (quotient21537 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21652) (PetersenFastSymmetry.move [thinSym2] (L := live21652) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21573) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21573) (V := live21540) (by decide +kernel) (quotient21540 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21648) (PetersenFastSymmetry.move [thinSym0] (L := live21648) (V := live21646) (by decide +kernel) (quotient21646 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21538) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21538) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21547) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym2,thinSym0] (L := live21547) (V := live19847) (by decide +kernel) (quotient19847 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21556) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live21556) (V := live21503) (by decide +kernel) (quotient21503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21649) (PetersenFastSymmetry.move [thinSym0] (L := live21649) (V := live21645) (by decide +kernel) (quotient21645 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21643) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live21643) (V := live21362) (by decide +kernel) (quotient21362 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21540) (quotient21540 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21576) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21576) (V := live21537) (by decide +kernel) (quotient21537 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21550) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym1,thinSym2] (L := live21550) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21577) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2] (L := live21577) (V := live19857) (by decide +kernel) (quotient19857 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21580) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live21580) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.nil
end Full18
