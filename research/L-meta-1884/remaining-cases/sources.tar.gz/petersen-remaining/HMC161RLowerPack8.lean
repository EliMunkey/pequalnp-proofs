import HMC161RHyp
import HMC161RThetaRoutes
import M191StartPreferredCheckedF0X4Z0
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold46_0 : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0xfff0fff0fff0fff0fff0fff0fff0fff0) (a:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_0

theorem hold47_0 : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (a:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_0

theorem hold49_0 : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows1 thetaInputs1 thetaTarget1 (g:=0xfffffffffffffffff0f0f0f0f0f0f0f0) (a:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_0
end MC161RCert
