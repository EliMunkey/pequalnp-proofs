import first8.AdjacentSym
import HMC161RSym
import first8.FirstInputs
import Q1020K12Closing
import ThetaClosing
import HMC161RJoinedD0G0
import HMC161RW0
import HMC161RW1
import PetersenLocalChildren
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
theorem reject1_6_1 [Assumptions] : NoAtMost (0xcccccccccccccccc0000000000000000cccccccccccccccc :: inputs 8) tgt 12 := by
  change NoAtMost [w91,w298,w341,w379,w391,w423,w456,w501,w537] tgt 12
  apply PetersenFirstInputs.root (by decide) (by intro a h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h;rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e;have v := congrFun e (3:Fin 256);change true=false at v;contradiction
    · intro e;have v := congrFun e (0:Fin 256);change false=true at v;contradiction)
    #[[w298,w341,w379,w391,w423,w456,w501,w537],[w91,w298,w341,w379,w391,w423,w456,w501,w537]] [5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,68,35,35,82,82,5,35,68,68,35,35,82,82,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,68,35,35,134,134,5,35,68,68,35,35,162,162,5,68,8,68,74,74,74,74,5,68,68,68,74,74,74,74,5,68,8,68,82,82,82,82,5,68,68,68,82,82,82,82,5,68,8,68,74,74,74,74,5,68,68,68,74,74,74,74,5,68,8,68,134,134,134,134,5,68,68,68,517,517,580,1158,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,134,35,35,134,134,5,35,146,146,35,35,146,146,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,134,35,35,134,134,5,35,162,162,35,35,162,162,5,134,8,134,134,134,134,134,5,146,146,146,146,146,146,146,5,134,8,134,134,134,134,134,5,146,146,146,146,146,146,146,5,134,8,134,134,134,134,134,5,517,261,1158,517,517,1158,1158,5,134,8,134,134,134,134,134,5,517,261,1158,517,517,1158,1158,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,68,35,35,82,82,5,35,68,68,35,35,82,82,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,68,35,35,291,291,5,35,68,68,35,35,291,291,5,68,8,68,74,74,74,74,5,68,68,68,74,74,74,74,5,68,8,68,82,82,82,82,5,68,68,68,82,82,82,82,5,68,8,68,74,74,74,74,5,68,68,68,74,74,74,74,5,68,8,68,517,517,520,520,5,68,68,68,517,517,580,2122,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,291,35,35,291,291,5,35,261,291,35,35,291,291,5,35,8,42,35,35,42,42,5,35,42,42,35,35,42,42,5,35,8,291,35,35,291,291,5,35,261,291,35,35,291,291,5,517,8,520,517,517,520,520,5,517,261,8234,517,517,8234,8234,5,517,8,520,517,517,520,520,5,517,261,16452,517,517,16466,16466,5,517,8,520,517,517,520,520,5,517,261,8234,517,517,8234,8234,5,517,8,520,517,517,520,520,5,517,261,16452,517,517,0,1] (by decide +kernel)
  change ∀ v∈[[w298,w341,w379,w391,w423,w456,w501,w537],[w91,w298,w341,w379,w391,w423,w456,w501,w537]], Blocked tgt 12 v
  exact PetersenLocalChildren.push (P := Blocked tgt 12) (x := [w298,w341,w379,w391,w423,w456,w501,w537]) (Orbits1020Cost12.b0_0 ThetaCert.bound) <| PetersenLocalChildren.push (P := Blocked tgt 12) (x := [w91,w298,w341,w379,w391,w423,w456,w501,w537]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) node0_0) PetersenLocalChildren.nil
#print axioms reject1_6_1
end MC161RCert
