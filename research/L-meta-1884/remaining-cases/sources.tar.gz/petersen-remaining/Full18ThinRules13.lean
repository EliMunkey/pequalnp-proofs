import PetersenProjectedRule
import Full18FastBases
import Full18Data6
import Full18Data7
import Full18ThinView1
import Full18ThinView2
import Full18ThinView3
import Full18ThinView4
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound6674 (h : Needs) : Correct rule6674 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6674) (t := Root17.tgt) SEP32 ONES32 thinBasis15 TG32 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6678 (h : Needs) : Correct rule6678 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6678) (t := Root17.tgt) SEP61 ONES61 thinBasis15 TG61 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6682 (h : Needs) : Correct rule6682 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6682) (t := Root17.tgt) SEP32 ONES32 thinBasis11 TG32 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6701 (h : Needs) : Correct rule6701 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6701) (t := Root17.tgt) SEP33 ONES33 thinBasis20 TG33 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6705 (h : Needs) : Correct rule6705 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6705) (t := Root17.tgt) SEP32 ONES32 thinBasis17 TG32 (baseThin17 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound6712 (h : Needs) : Correct rule6712 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6712) (t := Root17.tgt) SEP34 ONES34 thinBasis19 TG34 (baseThin19 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound6716 (h : Needs) : Correct rule6716 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6716) (t := Root17.tgt) SEP34 ONES34 thinBasis8 TG34 (baseThin8 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound6725 (h : Needs) : Correct rule6725 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6725) (t := Root17.tgt) SEP35 ONES35 thinBasis15 TG35 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6732 (h : Needs) : Correct rule6732 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6732) (t := Root17.tgt) SEP72 ONES72 thinBasis15 TG72 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6733 (h : Needs) : Correct rule6733 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6733) (t := Root17.tgt) SEP35 ONES35 thinBasis11 TG35 (baseThin11 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound6736 (h : Needs) : Correct rule6736 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6736) (t := Root17.tgt) SEP35 ONES35 thinBasis11 TG35 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6737 (h : Needs) : Correct rule6737 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6737) (t := Root17.tgt) SEP35 ONES35 thinBasis20 TG35 (baseThin20 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound6739 (h : Needs) : Correct rule6739 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6739) (t := Root17.tgt) SEP35 ONES35 thinBasis10 TG35 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6741 (h : Needs) : Correct rule6741 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6741) (t := Root17.tgt) SEP35 ONES35 thinBasis9 TG35 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6743 (h : Needs) : Correct rule6743 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6743) (t := Root17.tgt) SEP36 ONES36 thinBasis10 TG36 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6745 (h : Needs) : Correct rule6745 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6745) (t := Root17.tgt) SEP36 ONES36 thinBasis9 TG36 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7420 (h : Needs) : Correct rule7420 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7420) (t := Root17.tgt) SEP37 ONES37 thinBasis8 TG37 (baseThin8 h) (by decide +kernel) [(false,(4,true),(1,true)),(false,(7,true),(4,true))] rfl (by decide +kernel)
theorem quickSound7421 (h : Needs) : Correct rule7421 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7421) (t := Root17.tgt) SEP37 ONES37 thinBasis8 TG37 (baseThin8 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound7428 (h : Needs) : Correct rule7428 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7428) (t := Root17.tgt) SEP38 ONES38 thinBasis15 TG38 (baseThin15 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound7430 (h : Needs) : Correct rule7430 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7430) (t := Root17.tgt) SEP38 ONES38 thinBasis15 TG38 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7435 (h : Needs) : Correct rule7435 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7435) (t := Root17.tgt) SEP84 ONES84 thinBasis15 TG84 (baseThin15 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound7436 (h : Needs) : Correct rule7436 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7436) (t := Root17.tgt) SEP84 ONES84 thinBasis15 TG84 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7440 (h : Needs) : Correct rule7440 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7440) (t := Root17.tgt) SEP38 ONES38 thinBasis11 TG38 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7442 (h : Needs) : Correct rule7442 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7442) (t := Root17.tgt) SEP38 ONES38 thinBasis20 TG38 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7443 (h : Needs) : Correct rule7443 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7443) (t := Root17.tgt) SEP38 ONES38 thinBasis10 TG38 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7445 (h : Needs) : Correct rule7445 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7445) (t := Root17.tgt) SEP38 ONES38 thinBasis9 TG38 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7447 (h : Needs) : Correct rule7447 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7447) (t := Root17.tgt) SEP39 ONES39 thinBasis10 TG39 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7449 (h : Needs) : Correct rule7449 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7449) (t := Root17.tgt) SEP39 ONES39 thinBasis9 TG39 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7457 (h : Needs) : Correct rule7457 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7457) (t := Root17.tgt) SEP41 ONES41 thinBasis15 TG41 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7459 (h : Needs) : Correct rule7459 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7459) (t := Root17.tgt) SEP67 ONES67 thinBasis15 TG67 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7466 (h : Needs) : Correct rule7466 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7466) (t := Root17.tgt) SEP43 ONES43 thinBasis15 TG43 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7468 (h : Needs) : Correct rule7468 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7468) (t := Root17.tgt) SEP80 ONES80 thinBasis15 TG80 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
