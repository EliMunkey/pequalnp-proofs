import first8.AdjacentSym
import HMC010Hyp
import HMC010JoinedD4G0
import HMC010JoinedD4G1
import HMC010Rules0
import HMC010Rules1
import HMC010Rules11
import HMC010Rules12
import HMC010Rules13
import HMC010Rules14
import HMC010Rules2
import HMC010Rules3
import HMC010Rules4
import HMC010Rules5
import HMC010Rules6
import HMC010Rules8
import HMC010Rules9
import HMC010Sym
import HMC010W0
import HMC010W1
import HMC010W2
import HMC010W3
import PetersenSymmetry
import Q1020K12Closing
import first8.FastLocal
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 150000
set_option maxHeartbeats 0
set_option linter.concreteInstances false

def s3_18492 : List (BitVec 256) := [w517,w572,w622,w644,w680,w720,w778,w880,w977,w1076]
private def c3_18492 : Array (PetersenProjectedRule.Rule 256) := #[rule61 route4 [],rule26 route4 [(false,(3,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))],rule576 route3 [],rule26 route7 [(false,(1,true),(2,true)),(false,(7,true),(5,true)),(false,(1,true),(0,true))],rule404 route1 []]
private def m3_18492 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_18492 : List (List Nat) := [[1036,265,9,9],[521,33417,24679,521],[521,9255,524,521],[521,2569,529,521],[521,4617,537,521],[521,8231,8231,521],[521,24615,12406,521],[521,17867,8358,521],[521,8231,8231,521],[265,16713,16456,265],[265,524,12,12],[265,2313,273,265],[265,4361,281,265],[265,9260,9260,265],[265,12918,12406,265],[265,8870,8358,265],[265,9260,9260,265],[524,33163,524,33163],[8238,16719,8238,16719],[16470,16727,16470,16727],[32934,16743,32934,16743],[12406,33480,8808,8808],[8358,17867,8358,8872],[5,0],[524,2572,532,524],[524,4620,540,524],[524,8748,8748,524],[524,13430,12406,524],[524,9382,8358,524],[524,8748,8748,524],[8238,12334,8254,8238],[16462,8238,8238,16462],[8238,16462,8302,8238],[8238,49230,8358,8238],[1,8238,8238,2],[16470,24662,16502,16470],[32918,12406,8310,8310],[8358,12454,8358,8374],[3,16470,16470,4],[12374,12374,16743,12406],[9354,8358,16614,8358],[295,295],[8358,17546,8358,8422],[2126,2126],[1162,1162]]
theorem node3_18492 [Assumptions] : Blocked tgt 9 s3_18492 := by
  refine PetersenFastLocal.close (cut := c3_18492) (more := m3_18492) (hs := hs3_18492) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route4 []) (correct61 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))]) (correct26 route4 [(false,(3,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule576 route3 []) (correct576 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true)),(false,(7,true),(5,true)),(false,(1,true),(0,true))]) (correct26 route7 [(false,(1,true),(2,true)),(false,(7,true),(5,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule404 route1 []) (correct404 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_18499 : List (BitVec 256) := [w517,w572,w622,w644,w680,w720,w778,w945,w977,w1061]
private def c3_18499 : Array (PetersenProjectedRule.Rule 256) := #[rule425 route7 [(false,(2,true),(3,true)),(false,(0,true),(1,false)),(false,(3,true),(9,true))],rule69 route0 []]
private def m3_18499 : Array (List (BitVec 256)) := #[]
private def hs3_18499 : List (List Nat) := [[1032,261,5,5],[517,33413,24675,517],[517,9251,520,517],[517,2565,525,517],[517,4613,533,517],[517,8227,8227,517],[517,8227,8227,517],[517,17863,17606,517],[517,24611,12402,517],[261,16709,16452,261],[261,520,8,8],[261,2309,269,261],[261,4357,277,261],[261,9256,9256,261],[261,9256,9256,261],[261,33157,16837,261],[261,12914,12402,261],[520,33159,520,33159],[8234,16715,8234,16715],[16466,16723,16466,16723],[49314,16739,49314,16739],[35018,33476,35018,33476],[17606,17863,17606,17863],[8804,8804],[520,2568,528,520],[520,4616,536,520],[520,8744,8744,520],[520,8744,8744,520],[520,17606,16582,520],[520,13426,12402,520],[8234,12330,8250,8234],[16458,8234,8234,16458],[33476,8234,8234,32970],[8234,49226,16586,8234],[8234,16458,8298,8234],[16466,24658,16498,16466],[32914,16466,16466,32914],[16466,32914,16594,16466],[0,12402,8306,8306],[291,291],[16739,24738,16546,16546],[12370,12370,16739,12402],[17542,17542,33476,17606],[1,12402,2122,2122],[1158,1158]]
theorem node3_18499 [Assumptions] : Blocked tgt 9 s3_18499 := by
  refine PetersenFastLocal.close (cut := c3_18499) (more := m3_18499) (hs := hs3_18499) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule425 route7 [(false,(2,true),(3,true)),(false,(0,true),(1,false)),(false,(3,true),(9,true))]) (correct425 route7 [(false,(2,true),(3,true)),(false,(0,true),(1,false)),(false,(3,true),(9,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18512 : List (BitVec 256) := [w517,w572,w624,w644,w680,w720,w778,w880,w977,w1076]
private def c3_18512 : Array (PetersenProjectedRule.Rule 256) := #[rule146 route4 [],rule216 route7 []]
private def m3_18512 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w395,w517,w572,w644,w680,w720,w778,w880,w977],[w341,w517,w572,w624,w644,w720,w778,w880,w977],[w296,w517,w572,w624,w644,w680,w778,w880,w977]]
private def hs3_18512 : List (List Nat) := [[1036,265,9,9],[521,8745,8231,521],[521,33163,524,521],[521,2569,529,521],[521,4617,537,521],[521,8745,8745,521],[521,35279,8808,521],[521,17867,8358,521],[521,8745,8745,521],[265,16713,9260,265],[265,524,12,12],[265,2313,273,265],[265,4361,281,265],[265,33448,16743,265],[265,8808,12406,265],[265,8872,8358,265],[265,16713,16713,265],[524,8748,524,8748],[8238,8752,8238,8752],[16470,16727,16470,16727],[32934,16743,32934,16743],[12406,8808,12406,8808],[8358,8872,8358,8872],[2,3],[524,2572,532,524],[524,4620,540,524],[524,8748,8748,524],[524,13430,8808,524],[524,9382,8358,524],[524,8748,8748,524],[8238,12334,8254,8238],[16462,8238,8238,16462],[8238,16462,8302,8238],[8238,49230,8358,8238],[0,8238,8238,4],[16470,24662,16502,16470],[8808,12406,8310,8310],[8358,12454,8358,8374],[1,16470,16470,5],[8776,8776,16743,8808],[9354,8358,16614,8358],[2094,2094],[8358,17546,8358,8422],[2126,2126],[1162,1162]]
theorem node3_18512 [Assumptions] : Blocked tgt 9 s3_18512 := by
  refine PetersenFastLocal.close (cut := c3_18512) (more := m3_18512) (hs := hs3_18512) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule146 route4 []) (correct146 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule216 route7 []) (correct216 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w395,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (Orbits1020Cost12.b4_284 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w341,w517,w572,w624,w644,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) node4_7274) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w296,w517,w572,w624,w644,w680,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) node4_7264) <|
      PetersenLocalChildren.nil
def s3_18516 : List (BitVec 256) := [w517,w572,w625,w631,w644,w680,w720,w778,w880,w977]
private def c3_18516 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 []]
private def m3_18516 : Array (List (BitVec 256)) := #[[w517,w572,w632,w644,w680,w720,w778,w880,w977],[w165,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_18516 : List (List Nat) := [[1289,518,262],[518,8228],[518,33414,33414,518],[518,33160,521,518],[518,2566,526,518],[518,4614,534,518],[518,292,550,292],[518,35276,12403,518],[518,17864,8355,518],[262,1033],[262,16710,16710,262],[262,521,266,262],[262,2310,270,262],[262,4358,278,262],[262,2605,292,262],[262,16710,12403,262],[262,33158,8355,262],[0,1,0,2],[32903,521,32903,521],[8235,8749,8235,8749],[16467,16724,16467,16724],[2091,292,2091,292],[12403,33477,12403,33477],[8355,17864,8355,17864],[521,32903,521,32903],[8235,16459,8235,16459],[24691,16467,24691,16467],[292,16740,292,16740],[12403,33477,581,581],[8355,17607,1159,1159],[521,2569,529,521],[521,4617,537,521],[292,1316,292,296],[521,13427,12403,521],[521,9379,8355,521],[8235,12331,8251,8235],[292,2091,43,43],[8235,16459,8299,8235],[8235,49227,8355,8235],[292,4388,292,308],[32915,12403,8307,8307],[8355,12451,8355,8371],[292,12403,2155,292],[292,8355,163,163],[8355,17543,8355,8419]]
theorem node3_18516 [Assumptions] : Blocked tgt 9 s3_18516 := by
  refine PetersenFastLocal.close (cut := c3_18516) (more := m3_18516) (hs := hs3_18516) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w632,w644,w680,w720,w778,w880,w977]) (Orbits1020Cost12.b4_2865 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w165,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b4_26 ThetaCert.bound)) <|
      PetersenLocalChildren.nil

def s3_18660 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w950,w977]
private def c3_18660 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule27 route0 [],rule2 route3 [],rule35 route7 [],rule26 route4 [(false,(3,true),(2,true))]]
private def m3_18660 : Array (List (BitVec 256)) := #[[w328,w517,w572,w625,w644,w720,w778,w880,w977],[w296,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18660 : List (List Nat) := [[1293,522,266],[522,8232],[522,33164,525,522],[522,2570,530,522],[522,4618,538,522],[522,8746,8746,522],[522,35280,8809,522],[522,8746,8746,522],[522,4504,4247,522],[266,1037],[266,525,270,266],[266,2314,274,266],[266,4362,282,266],[266,33449,16744,266],[266,8809,12407,266],[266,16714,16714,266],[266,4761,4247,266],[32907,525,32907,525],[8239,8753,8239,8753],[16471,16728,16471,16728],[32935,16744,32935,16744],[12407,8809,12407,8809],[0,1,2,3],[4247,4504,4247,4504],[525,2573,533,525],[525,4621,541,525],[525,8749,8749,525],[525,13431,8809,525],[525,8749,8749,525],[525,5271,4247,525],[8239,12335,8255,8239],[16463,8239,8239,16463],[8239,16463,8303,8239],[4,8239,8239,5],[4247,6295,4247,4255],[16471,24663,16503,16471],[8809,12407,8311,8311],[32919,16471,16471,6],[8359,4247,151,151],[8777,8777,16744,8809],[296,296],[4247,8359,4247,8359],[585,585],[4247,17547,4247,8423],[4247,8359,1163,1163]]
theorem node3_18660 [Assumptions] : Blocked tgt 9 s3_18660 := by
  refine PetersenFastLocal.close (cut := c3_18660) (more := m3_18660) (hs := hs3_18660) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 []) (correct2 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true))]) (correct26 route4 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w328,w517,w572,w625,w644,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) node4_7069) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w296,w517,w572,w625,w644,w680,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b4_2182 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_18716 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1050]
private def c3_18716 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule27 route1 [],rule0 route6 [],rule35 route7 [],rule26 route4 [(false,(3,true),(2,true))]]
private def m3_18716 : Array (List (BitVec 256)) := #[[w338,w517,w572,w625,w644,w720,w778,w880,w977],[w296,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18716 : List (List Nat) := [[1293,522,266],[522,8232],[522,33164,525,522],[522,2570,530,522],[522,4618,538,522],[522,8746,8746,522],[522,4440,4183,522],[522,17868,8359,522],[522,8746,8746,522],[266,1037],[266,525,270,266],[266,2314,274,266],[266,4362,282,266],[266,33449,16744,266],[266,4697,4183,266],[266,8873,8359,266],[266,16714,16714,266],[32907,525,32907,525],[8239,8753,8239,8753],[24695,33176,24695,33176],[32935,16744,32935,16744],[4183,4440,4183,4440],[8359,8873,8359,8873],[0,1,2,3],[525,2573,533,525],[525,4621,541,525],[525,8749,8749,525],[525,5207,4183,525],[525,9383,8359,525],[525,8749,8749,525],[8239,12335,8255,8239],[16463,8239,8239,16463],[4183,6231,4183,4191],[8239,49231,8359,8239],[4,8239,8239,5],[16744,24695,16503,16503],[8809,4183,87,87],[8359,12455,8359,8375],[16471,16471,24695,6],[4183,8777,4183,8809],[9355,8359,16615,8359],[296,296],[4183,17547,8359,4183],[4183,8809,585,585],[1163,1163]]
theorem node3_18716 [Assumptions] : Blocked tgt 9 s3_18716 := by
  refine PetersenFastLocal.close (cut := c3_18716) (more := m3_18716) (hs := hs3_18716) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route1 []) (correct27 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route6 []) (correct0 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true))]) (correct26 route4 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w338,w517,w572,w625,w644,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) node4_6149) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w296,w517,w572,w625,w644,w680,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b4_2182 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_18726 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1062]
private def c3_18726 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule29 route2 [],rule35 route7 [],rule26 route6 [(false,(1,true),(0,true))]]
private def m3_18726 : Array (List (BitVec 256)) := #[[w296,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18726 : List (List Nat) := [[1291,520,264],[520,8230],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,4406,4664,520],[520,35278,8807,520],[520,17866,8357,520],[520,8744,8744,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,6719,4406,264],[264,8807,16712,264],[264,8871,8357,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[6205,4406,6205,4406],[35021,8807,35021,8807],[8357,8871,8357,8871],[0,1,0,2],[523,2571,531,523],[523,4619,539,523],[523,5430,4406,523],[523,49289,8807,523],[523,9381,8357,523],[523,8747,8747,523],[8237,12349,12349,8237],[4406,6205,4157,4157],[8237,16461,8301,8237],[8237,49229,8357,8237],[12349,8237,8237,12349],[16469,4406,310,310],[8807,16469,8309,8309],[8357,32917,8357,8373],[3,16469,16469,4],[4406,8775,16742,4406],[4406,8357,16613,4406],[4406,16742,294,294],[8357,17545,8357,8421],[583,583],[1161,1161]]
theorem node3_18726 [Assumptions] : Blocked tgt 9 s3_18726 := by
  refine PetersenFastLocal.close (cut := c3_18726) (more := m3_18726) (hs := hs3_18726) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true))]) (correct26 route6 [(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w296,w517,w572,w625,w644,w680,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b4_2182 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_18727 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1063]
private def c3_18727 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule26 route7 [(false,(1,true),(2,true))],rule568 route1 []]
private def m3_18727 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w395,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_18727 : List (List Nat) := [[1291,520,264],[520,24678],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,294,552,294],[520,35278,12405,520],[520,17866,8357,520],[520,33416,33416,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,2607,294,264],[264,16712,12405,264],[264,33160,8357,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[32933,294,32933,294],[12405,33479,12405,33479],[8357,17866,8357,17866],[0,3,0,4],[523,2571,531,523],[523,4619,539,523],[294,1318,294,298],[523,13429,12405,523],[523,9381,8357,523],[523,32905,32905,523],[8237,12333,8253,8237],[294,2342,294,302],[8237,16461,8301,8237],[8237,49229,8357,8237],[8751,8237,8237,8751],[294,4390,294,310],[32917,12405,8309,8309],[8357,12453,8357,8373],[1,16469,16469,2],[294,12373,16742,294],[294,8357,16613,294],[294,16742,2093,294],[8357,17545,8357,8421],[583,583],[1161,1161]]
theorem node3_18727 [Assumptions] : Blocked tgt 9 s3_18727 := by
  refine PetersenFastLocal.close (cut := c3_18727) (more := m3_18727) (hs := hs3_18727) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true))]) (correct26 route7 [(false,(1,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule568 route1 []) (correct568 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w395,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (Orbits1020Cost12.b4_284 ThetaCert.bound)) <|
      PetersenLocalChildren.nil

def s3_18728 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1064]
private def c3_18728 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule26 route7 [(false,(1,true),(2,true))],rule568 route1 []]
private def m3_18728 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w395,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_18728 : List (List Nat) := [[1291,520,264],[520,8230],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,8712,552,520],[520,35278,12405,520],[520,17866,8357,520],[520,33416,33416,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,2607,296,264],[264,16712,12405,264],[264,33160,8357,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[32933,2607,32933,2607],[12405,33479,12405,33479],[8357,17866,8357,17866],[0,3,0,4],[523,2571,531,523],[523,4619,539,523],[523,8715,555,523],[523,13429,12405,523],[523,9381,8357,523],[523,32905,32905,523],[8237,12333,8253,8237],[16461,2607,559,559],[8237,16461,8301,8237],[8237,49229,8357,8237],[8751,8237,8237,8751],[2607,6703,2607,2623],[32917,12405,8309,8309],[8357,12453,8357,8373],[1,16469,16469,2],[2607,12373,16742,2607],[2607,8357,16613,2607],[2607,16742,294,294],[8357,17545,8357,8421],[583,583],[1161,1161]]
theorem node3_18728 [Assumptions] : Blocked tgt 9 s3_18728 := by
  refine PetersenFastLocal.close (cut := c3_18728) (more := m3_18728) (hs := hs3_18728) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true))]) (correct26 route7 [(false,(1,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule568 route1 []) (correct568 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w395,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (Orbits1020Cost12.b4_284 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_18745 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1083]
private def c3_18745 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule29 route2 [],rule35 route7 [],rule26 route4 [(false,(3,true),(2,true))]]
private def m3_18745 : Array (List (BitVec 256)) := #[[w345,w517,w572,w625,w644,w720,w778,w880,w977],[w296,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18745 : List (List Nat) := [[1292,521,265],[521,8231],[521,33163,524,521],[521,2569,529,521],[521,4633,4633,521],[521,4407,4665,521],[521,4439,4182,521],[521,4503,4246,521],[521,4633,4633,521],[265,1036],[265,524,269,265],[265,2313,273,265],[265,4377,4377,265],[265,6720,4407,265],[265,4696,4182,265],[265,4760,4246,265],[265,4377,4377,265],[32906,524,32906,524],[8238,8752,8238,8752],[16470,16727,16470,16727],[6206,4407,6206,4407],[4182,4439,4182,4439],[4246,4503,4246,4503],[0,1,0,2],[524,2572,532,524],[524,4636,4636,524],[524,5431,4407,524],[524,5206,4182,524],[524,5270,4246,524],[524,4636,4636,524],[8238,12334,8254,8238],[4407,6206,4158,4158],[4182,6230,4182,4190],[4246,6294,4246,4254],[3,8238,8238,4],[4391,4391,16502,4407],[4680,4182,8310,4182],[5258,4246,8358,4246],[16470,5],[4182,8776,4182,4214],[4246,8358,4246,4278],[295,295],[4182,17546,4246,4182],[584,584],[1162,1162]]
theorem node3_18745 [Assumptions] : Blocked tgt 9 s3_18745 := by
  refine PetersenFastLocal.close (cut := c3_18745) (more := m3_18745) (hs := hs3_18745) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true))]) (correct26 route4 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w345,w517,w572,w625,w644,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) node4_8032) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w296,w517,w572,w625,w644,w680,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (Orbits1020Cost12.b4_2182 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_18749 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w985,w1061]
private def c3_18749 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_18749 : Array (List (BitVec 256)) := #[[w517,w572,w625,w644,w680,w720,w778,w880,w977]]
private def hs3_18749 : List (List Nat) := [[1287,516,260],[516,8226],[516,33158,519,516],[516,2564,524,516],[516,4612,532,516],[516,8740,8740,516],[516,35274,33475,516],[516,8740,8740,516],[516,33412,8353,516],[260,1031],[260,519,264,260],[260,2308,268,260],[260,4356,276,260],[260,33443,16738,260],[260,16708,16708,260],[260,33156,16836,260],[260,8867,8353,260],[32901,519,32901,519],[8233,8747,8233,8747],[16465,16722,16465,16722],[32929,16738,32929,16738],[35017,33475,35017,33475],[17605,17862,17605,17862],[8353,8867,8353,8867],[519,2567,527,519],[519,4615,535,519],[519,8743,8743,519],[519,49285,32965,519],[519,8743,8743,519],[519,9377,8353,519],[8233,12329,8249,8233],[16457,8233,8233,16457],[8233,16457,16457,8233],[16457,8233,8233,16457],[8233,16457,8353,8233],[16465,24657,16497,16465],[32913,16465,16465,32913],[16465,32913,16593,16465],[8353,12449,8353,8369],[32929,16738,16738,32929],[16738,24801,290,290],[9349,8353,16738,8353],[17541,17541,33475,17605],[579,579],[0,8353,1157,1157]]
theorem node3_18749 [Assumptions] : Blocked tgt 9 s3_18749 := by
  refine PetersenFastLocal.close (cut := c3_18749) (more := m3_18749) (hs := hs3_18749) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b1_14 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_18767 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w889,w977,w1061]
private def c3_18767 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_18767 : Array (List (BitVec 256)) := #[[w517,w572,w625,w644,w680,w720,w778,w880,w977]]
private def hs3_18767 : List (List Nat) := [[1287,516,260],[516,8226],[516,33158,519,516],[516,2564,524,516],[516,4612,532,516],[516,8740,8740,516],[516,8740,8740,516],[516,17862,17605,516],[516,33412,8803,516],[260,1031],[260,519,264,260],[260,2308,268,260],[260,4356,276,260],[260,33443,16738,260],[260,16708,16708,260],[260,33156,16836,260],[260,8803,12401,260],[32901,519,32901,519],[8233,8747,8233,8747],[16465,16722,16465,16722],[32929,16738,32929,16738],[35017,33475,35017,33475],[17605,17862,17605,17862],[12401,8803,12401,8803],[519,2567,527,519],[519,4615,535,519],[519,8743,8743,519],[519,8743,8743,519],[519,17605,16581,519],[519,13425,8803,519],[8233,12329,8249,8233],[16457,8233,8233,16457],[33475,8233,8233,32969],[8233,49225,16585,8233],[8233,16457,8297,8233],[16465,24657,16497,16465],[32913,16465,16465,32913],[16465,32913,16593,16465],[8803,12401,8305,8305],[32929,16738,290,290],[16738,24801,16609,16609],[8771,8771,16738,8803],[17541,17541,33475,17605],[0,8803,579,579],[1157,1157]]
theorem node3_18767 [Assumptions] : Blocked tgt 9 s3_18767 := by
  refine PetersenFastLocal.close (cut := c3_18767) (more := m3_18767) (hs := hs3_18767) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b1_14 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil

def s3_18769 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w896,w945,w977]
private def c3_18769 : Array (PetersenProjectedRule.Rule 256) := #[rule107 route7 []]
private def m3_18769 : Array (List (BitVec 256)) := #[[w517,w572,w625,w644,w680,w720,w778,w880,w977]]
private def hs3_18769 : List (List Nat) := [[1288,517,261],[517,8227],[517,33159,520,517],[517,2565,525,517],[517,4613,533,517],[517,8741,8741,517],[517,33413,8804,517],[517,8741,8741,517],[517,17863,8354,517],[261,1032],[261,520,265,261],[261,2309,269,261],[261,4357,277,261],[261,0,16739,261],[261,8804,12402,261],[261,16709,16709,261],[261,8868,8354,261],[32902,520,32902,520],[8234,8748,8234,8748],[16466,16723,16466,16723],[49378,16739,49378,16739],[12402,8804,12402,8804],[35018,33476,35018,33476],[8354,8868,8354,8868],[520,2568,528,520],[520,4616,536,520],[520,8744,8744,520],[520,13426,8804,520],[520,8744,8744,520],[520,9378,8354,520],[8234,12330,8250,8234],[16458,8234,8234,16458],[8234,16458,8298,8234],[33476,8234,8234,32970],[8234,49226,8354,8234],[16466,24658,16498,16466],[8804,12402,8306,8306],[32914,16466,16466,32914],[8354,12450,8354,8370],[8772,8772,16739,8804],[291,291],[16739,8354,16610,8354],[1,8804,580,580],[8354,17606,1158,1158],[17542,8354,33476,8354]]
theorem node3_18769 [Assumptions] : Blocked tgt 9 s3_18769 := by
  refine PetersenFastLocal.close (cut := c3_18769) (more := m3_18769) (hs := hs3_18769) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route7 []) (correct107 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b1_14 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_18781 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w902,w977,w1061]
private def c3_18781 : Array (PetersenProjectedRule.Rule 256) := #[rule33 route3 [],rule35 route7 [],rule26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))],rule1 route0 [(false,(0,true),(1,true))]]
private def m3_18781 : Array (List (BitVec 256)) := #[]
private def hs3_18781 : List (List Nat) := [[1290,519,263],[519,24677],[519,33161,522,519],[519,2567,527,519],[519,4615,535,519],[519,293,551,293],[519,35277,33478,519],[519,17865,17608,519],[519,33415,12404,519],[263,1034],[263,522,267,263],[263,2311,271,263],[263,4359,279,263],[263,2606,293,263],[263,16711,16711,263],[263,33159,16839,263],[263,16711,12404,263],[32904,522,32904,522],[8236,8750,8236,8750],[16468,16725,16468,16725],[49316,293,49316,293],[35020,33478,35020,33478],[17608,17865,17608,17865],[12404,0,12404,1],[522,2570,530,522],[522,4618,538,522],[293,1317,293,297],[522,49288,32968,522],[522,17608,16584,522],[522,13428,12404,522],[8236,12332,8252,8236],[293,2341,293,301],[8750,8236,8236,8750],[8236,49228,16588,8236],[8236,16460,8300,8236],[293,4389,293,309],[32916,16468,16468,32916],[16468,32916,16596,16468],[2,12404,8308,8308],[293,16741,2092,293],[293,24740,16548,293],[293,12372,16741,293],[17544,17544,33478,17608],[3,12404,582,582],[1160,1160]]
theorem node3_18781 [Assumptions] : Blocked tgt 9 s3_18781 := by
  refine PetersenFastLocal.close (cut := c3_18781) (more := m3_18781) (hs := hs3_18781) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route3 []) (correct33 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))]) (correct26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(0,true),(1,true))]) (correct1 route0 [(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18786 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w903,w977,w1061]
private def c3_18786 : Array (PetersenProjectedRule.Rule 256) := #[rule37 route1 [],rule41 route7 [],rule26 route7 [(false,(1,true),(2,true)),(false,(3,true),(1,false)),(false,(0,true),(8,true))],rule1 route0 [(false,(0,true),(1,true))]]
private def m3_18786 : Array (List (BitVec 256)) := #[]
private def hs3_18786 : List (List Nat) := [[1290,519,263],[519,8229],[519,33161,522,519],[519,2567,527,519],[519,4615,535,519],[519,8711,551,519],[519,35277,33478,519],[519,17865,17608,519],[519,33415,12404,519],[263,1034],[263,522,267,263],[263,2311,271,263],[263,4359,279,263],[263,2606,295,263],[263,16711,16711,263],[263,33159,16839,263],[263,16711,12404,263],[32904,522,32904,522],[8236,8750,8236,8750],[16468,16725,16468,16725],[49316,2606,49316,2606],[35020,33478,35020,33478],[17608,17865,17608,17865],[12404,0,12404,1],[522,2570,530,522],[522,4618,538,522],[522,8714,554,522],[522,49288,32968,522],[522,17608,16584,522],[522,13428,12404,522],[8236,12332,8252,8236],[16460,2606,558,558],[8750,8236,8236,8750],[8236,49228,16588,8236],[8236,16460,8300,8236],[2606,6702,2606,2622],[32916,16468,16468,32916],[16468,32916,16596,16468],[2,12404,8308,8308],[2606,16741,293,293],[2606,24740,16548,2606],[2606,12372,16741,2606],[17544,17544,33478,17608],[3,12404,582,582],[1160,1160]]
theorem node3_18786 [Assumptions] : Blocked tgt 9 s3_18786 := by
  refine PetersenFastLocal.close (cut := c3_18786) (more := m3_18786) (hs := hs3_18786) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route1 []) (correct37 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route7 []) (correct41 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true)),(false,(3,true),(1,false)),(false,(0,true),(8,true))]) (correct26 route7 [(false,(1,true),(2,true)),(false,(3,true),(1,false)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(0,true),(1,true))]) (correct1 route0 [(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18817 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w945,w1015,w1061]
private def c3_18817 : Array (PetersenProjectedRule.Rule 256) := #[rule75 route0 []]
private def m3_18817 : Array (List (BitVec 256)) := #[]
private def hs3_18817 : List (List Nat) := [[49475,516,33156],[516,8226],[516,33158,519,516],[516,2564,524,516],[516,4612,532,516],[516,8740,8740,516],[516,8740,8740,516],[17605,516,516,17862],[516,33284,644,516],[33156,49219],[32901,519,32901,519],[8233,8747,8233,8747],[16465,33427,16465,33156],[16738,0,16738,33156],[33156,33347,33092,33092],[260,260],[12401,4755,12401,4755],[32901,519,32901,519],[8233,8747,8233,8747],[16465,16722,16465,16722],[49313,16738,49313,16738],[35017,33347,35017,33347],[17605,17862,17605,17862],[12401,4755,12401,4755],[519,2567,527,519],[519,4615,535,519],[519,8743,8743,519],[519,8743,8743,519],[24737,519,519,16581],[519,13425,647,519],[8233,12329,8249,8233],[16457,8233,8233,16457],[33347,8233,8233,32969],[8233,8747,8747,8233],[4755,6803,4755,4763],[16465,24657,16497,16465],[32913,16465,16465,32913],[16465,32913,16593,16465],[8803,4755,659,659],[290,290],[16738,24737,16545,16545],[4755,8771,4755,8803],[17541,17541,33347,17605],[4755,8803,579,579],[12401,4755,1157,1157]]
theorem node3_18817 [Assumptions] : Blocked tgt 9 s3_18817 := by
  refine PetersenFastLocal.close (cut := c3_18817) (more := m3_18817) (hs := hs3_18817) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route0 []) (correct75 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_18825 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w791,w880,w945,w977]
private def c3_18825 : Array (PetersenProjectedRule.Rule 256) := #[rule117 route7 []]
private def m3_18825 : Array (List (BitVec 256)) := #[[w517,w572,w625,w644,w680,w720,w778,w880,w977]]
private def hs3_18825 : List (List Nat) := [[1288,517,261],[517,8227],[517,33159,520,517],[517,2565,525,517],[517,4613,533,517],[517,8741,8741,517],[517,0,8804,517],[517,8741,8741,517],[517,17863,8354,517],[261,1032],[261,520,265,261],[261,2309,269,261],[261,4357,277,261],[261,33157,16739,261],[261,8804,12402,261],[261,16709,16709,261],[261,8868,8354,261],[32902,520,32902,520],[8234,8748,8234,8748],[16466,16723,16466,16723],[49378,16739,49378,16739],[12402,8804,12402,8804],[32930,33187,32930,33187],[8354,8868,8354,8868],[520,2568,528,520],[520,4616,536,520],[520,8744,8744,520],[520,13426,8804,520],[520,8744,8744,520],[520,9378,8354,520],[8234,12330,8250,8234],[16458,8234,8234,16458],[8234,16458,8298,8234],[32930,8234,8234,32938],[8234,49226,8354,8234],[16466,24658,16498,16466],[8804,12402,8306,8306],[32914,16466,16466,32914],[8354,12450,8354,8370],[8772,8772,16739,8804],[1,16739,291,291],[16739,8354,1158,1158],[580,580],[8354,17606,8354,8418],[9350,8354,32930,8354]]
theorem node3_18825 [Assumptions] : Blocked tgt 9 s3_18825 := by
  refine PetersenFastLocal.close (cut := c3_18825) (more := m3_18825) (hs := hs3_18825) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route7 []) (correct117 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b1_14 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_18841 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w865,w880,w977,w1076]
private def c3_18841 : Array (PetersenProjectedRule.Rule 256) := #[rule404 route0 [],rule26 route7 [(false,(0,true),(6,true)),(false,(0,false),(5,true))],rule34 route0 [(false,(1,true),(0,true))]]
private def m3_18841 : Array (List (BitVec 256)) := #[]
private def hs3_18841 : List (List Nat) := [[1289,518,262],[518,8228],[518,33160,521,518],[518,2566,526,518],[518,4630,4630,518],[518,4630,4630,518],[518,35276,8805,518],[518,17864,8355,518],[518,4404,4662,518],[262,1033],[262,521,266,262],[262,2310,270,262],[262,4374,4374,262],[262,4374,4374,262],[262,8805,12371,262],[262,8869,8355,262],[262,6717,4404,262],[32903,521,32903,521],[8235,8749,8235,8749],[24659,0,24659,1],[32931,16740,32931,16740],[12371,8805,12371,8805],[8355,8869,8355,8869],[6203,4404,6203,4404],[521,2569,529,521],[521,4633,4633,521],[521,4633,4633,521],[521,13395,8805,521],[521,9379,8355,521],[521,5428,4404,521],[8235,12331,8251,8235],[16459,8235,8235,16459],[8235,16459,8299,8235],[8235,49227,8355,8235],[4404,6203,4155,4155],[16467,16467],[8805,12371,8275,8275],[8355,12435,8339,8339],[4388,4388,24659,4404],[8773,8773,16740,8805],[9351,8355,16611,8355],[2,4404,292,292],[8355,17543,8355,8419],[581,581],[1159,1159]]
theorem node3_18841 [Assumptions] : Blocked tgt 9 s3_18841 := by
  refine PetersenFastLocal.close (cut := c3_18841) (more := m3_18841) (hs := hs3_18841) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule404 route0 []) (correct404 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(0,true),(6,true)),(false,(0,false),(5,true))]) (correct26 route7 [(false,(0,true),(6,true)),(false,(0,false),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(1,true),(0,true))]) (correct34 route0 [(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18847 : List (BitVec 256) := [w517,w572,w625,w644,w680,w728,w778,w880,w977,w1061]
private def c3_18847 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route0 [],rule39 route1 [],rule39 route0 [],rule108 route7 [],rule26 route6 [(false,(1,true),(0,true))]]
private def m3_18847 : Array (List (BitVec 256)) := #[[w278,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18847 : List (List Nat) := [[1292,521,265],[521,8231],[521,33163,524,521],[521,2569,529,521],[521,4617,537,521],[521,4391,4649,521],[521,35279,33480,521],[521,17867,17610,521],[521,33417,33417,521],[265,1036],[265,524,269,265],[265,2313,273,265],[265,4361,281,265],[265,6704,4391,265],[265,16713,16713,265],[265,33161,16841,265],[265,16713,16713,265],[32906,524,32906,524],[8238,8752,8238,8752],[16470,16727,16470,16727],[6190,4391,6190,4391],[35022,33480,35022,33480],[17610,17867,17610,17867],[0,1,2,3],[524,2572,532,524],[524,4620,540,524],[524,5415,4391,524],[524,49290,32970,524],[524,17610,16586,524],[524,32906,32906,524],[16462,8238,8238,16462],[4391,6190,4142,4142],[8238,16462,16462,8238],[8238,49230,16590,8238],[8238,16462,16462,8238],[16470,4391,295,295],[32918,16470,16470,32918],[16470,32918,16598,16470],[4,16470,16470,5],[4391,16743,16743,4391],[4391,24806,16614,4391],[4391,16743,16743,4391],[17546,33480,17610],[584,584],[1162,1162]]
theorem node3_18847 [Assumptions] : Blocked tgt 9 s3_18847 := by
  refine PetersenFastLocal.close (cut := c3_18847) (more := m3_18847) (hs := hs3_18847) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route7 []) (correct108 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true))]) (correct26 route6 [(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w278,w517,w572,w625,w644,w680,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b3_2254 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_18880 : List (BitVec 256) := [w517,w572,w625,w644,w680,w747,w778,w880,w977,w1061]
private def c3_18880 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [(false,(1,false),(4,true)),(false,(0,true),(4,true))],rule41 route1 [],rule108 route7 [],rule1 route0 [(false,(0,true),(1,true))]]
private def m3_18880 : Array (List (BitVec 256)) := #[[w249,w517,w572,w625,w644,w680,w778,w880,w977]]
private def hs3_18880 : List (List Nat) := [[1291,520,264],[520,8230],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,4390,4648,520],[520,35278,33479,520],[520,17866,17609,520],[520,33416,33416,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,6703,4390,264],[264,16712,16712,264],[264,33160,16840,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[6189,4390,6189,4390],[35021,33479,35021,33479],[17609,17866,17609,17866],[0,1,0,2],[523,2571,531,523],[523,4619,539,523],[523,5414,4390,523],[523,49289,32969,523],[523,17609,16585,523],[523,32905,32905,523],[16461,8237,8237,16461],[4390,6189,4141,4141],[8237,16461,16461,8237],[8237,49229,16589,8237],[8237,16461,16461,8237],[16469,4390,294,294],[32917,16469,16469,32917],[16469,32917,16597,16469],[3,16469,16469,4],[4390,16742,16742,4390],[4390,24805,16613,4390],[4390,16742,16742,4390],[17545,33479,17609],[583,583],[1161,1161]]
theorem node3_18880 [Assumptions] : Blocked tgt 9 s3_18880 := by
  refine PetersenFastLocal.close (cut := c3_18880) (more := m3_18880) (hs := hs3_18880) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(1,false),(4,true)),(false,(0,true),(4,true))]) (correct3 route0 [(false,(1,false),(4,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route7 []) (correct108 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(0,true),(1,true))]) (correct1 route0 [(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w249,w517,w572,w625,w644,w680,w778,w880,w977]) (Orbits1020Cost12.b4_1692 ThetaCert.bound) <|
      PetersenLocalChildren.nil

def s3_18903 : List (BitVec 256) := [w517,w572,w625,w644,w680,w763,w778,w880,w971,w977]
private def c3_18903 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule3 route2 []]
private def m3_18903 : Array (List (BitVec 256)) := #[]
private def hs3_18903 : List (List Nat) := [[5400,517,4373],[517,8227],[517,33159,520,517],[517,2565,525,517],[16466,517,517,16723],[517,4403,4645,517],[517,4435,4178,517],[517,4613,533,517],[517,1415,645,517],[4373,5144],[4373,520,4377,520],[4373,6421,4381,4373],[261,261],[4373,6700,4389,4373],[4178,4676,4178,4373],[4357,4357,4373,33428],[1158,4756,1158,4373],[32902,520,32902,520],[8234,8748,8234,8748],[16466,16723,16466,16723],[6202,4403,6202,4403],[4178,4435,4178,4435],[0,33428,1,33428],[1158,1415,1158,1415],[520,2568,528,520],[16466,520,520,16470],[520,5427,4403,520],[520,5202,4178,520],[520,4616,536,520],[520,1158,134,134],[8234,8748,8250,8234],[4403,6202,4154,4154],[4178,6226,4178,4186],[33428,8234,8234,33436],[1158,3206,1158,1166],[4387,4387,16498,4403],[6218,4178,8306,4178],[0,16466,16466,32914],[1158,4242,1158,4242],[4178,8772,4178,4210],[291,291],[1158,8354,1158,4274],[580,580],[1158,17606,1158,4178],[1158,4242,660,660]]
theorem node3_18903 [Assumptions] : Blocked tgt 9 s3_18903 := by
  refine PetersenFastLocal.close (cut := c3_18903) (more := m3_18903) (hs := hs3_18903) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 []) (correct3 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18904 : List (BitVec 256) := [w517,w572,w625,w644,w680,w763,w865,w880,w945,w977]
private def c3_18904 : Array (PetersenProjectedRule.Rule 256) := #[rule143 route6 [],rule274 route2 [],rule26 route0 [(false,(4,true),(1,true)),(false,(7,true),(1,true)),(false,(3,true),(8,true))],rule26 route7 [(false,(0,true),(6,true))],rule474 route5 []]
private def m3_18904 : Array (List (BitVec 256)) := #[]
private def hs3_18904 : List (List Nat) := [[5403,520,4376],[520,8230],[520,33162,523,520],[520,2568,528,520],[24661,520,520,0],[520,4616,536,520],[520,1,8791,520],[520,4406,4648,520],[520,1418,648,520],[4376,5147],[4376,523,4380,523],[4376,6424,4384,4376],[264,264],[4360,4360,4376,33431],[4376,8791,12373,4376],[4376,6703,4392,4376],[1161,4759,1161,4376],[32905,523,32905,523],[8237,8751,8237,8751],[24661,2,24661,3],[49381,16742,49381,16742],[12373,8791,12373,8791],[6205,4406,6205,4406],[1161,1418,1161,1418],[523,2571,531,523],[24661,523,523,24665],[523,4619,539,523],[523,13397,8791,523],[523,5430,4406,523],[523,1161,137,137],[8237,8751,8253,8237],[16461,8237,8237,16461],[8237,16461,8301,8237],[4406,6205,4157,4157],[1161,3209,1161,1169],[16742,24661,16469,16469],[4,8791,8277,8277],[4390,4390,24661,4406],[1161,4245,1161,4245],[8775,8775,16742,8791],[33431,4406,294,294],[1161,4245,663,663],[583,583],[1161,17609,1161,8421],[1161,8357,1161,4277]]
theorem node3_18904 [Assumptions] : Blocked tgt 9 s3_18904 := by
  refine PetersenFastLocal.close (cut := c3_18904) (more := m3_18904) (hs := hs3_18904) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule143 route6 []) (correct143 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule274 route2 []) (correct274 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(4,true),(1,true)),(false,(7,true),(1,true)),(false,(3,true),(8,true))]) (correct26 route0 [(false,(4,true),(1,true)),(false,(7,true),(1,true)),(false,(3,true),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(0,true),(6,true))]) (correct26 route7 [(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule474 route5 []) (correct474 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18910 : List (BitVec 256) := [w517,w572,w625,w644,w680,w769,w865,w880,w945,w977]
private def c3_18910 : Array (PetersenProjectedRule.Rule 256) := #[rule143 route6 [],rule93 route2 [],rule24 route4 [(false,(3,true),(4,true))],rule26 route7 [(false,(0,true),(6,true))],rule474 route5 []]
private def m3_18910 : Array (List (BitVec 256)) := #[]
private def hs3_18910 : List (List Nat) := [[1291,520,264],[520,12326],[520,33162,523,520],[520,2568,528,520],[520,0],[520,4616,536,520],[520,1,8791,520],[520,4390,4648,520],[520,1418,648,520],[264,5147],[264,523,268,264],[264,2312,272,264],[264,2],[264,4360,280,264],[264,8791,12373,264],[264,6703,4390,264],[264,4759,392,264],[32905,523,32905,523],[8237,8751,8237,8751],[24661,3],[49381,16726,49381,16726],[12373,8791,12373,8791],[6205,4390,6205,4390],[1161,1418,1161,1418],[523,2571,531,523],[24661,523,523,24665],[523,4619,539,523],[523,13397,8791,523],[523,5414,4390,523],[523,1161,137,137],[8237,8751,8253,8237],[16461,8237,8237,16461],[8237,16461,8301,8237],[4390,6205,4157,4157],[1161,3209,1161,1169],[49381,16726,16469,16469],[4,8791,8277,8277],[6189,4390,24661,4390],[1161,1418,1161,1418],[8775,8775,16726,8791],[33174,4390,294,294],[1161,4245,406,406],[583,583],[1161,17609,1161,8421],[1161,8357,1161,4277]]
theorem node3_18910 [Assumptions] : Blocked tgt 9 s3_18910 := by
  refine PetersenFastLocal.close (cut := c3_18910) (more := m3_18910) (hs := hs3_18910) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule143 route6 []) (correct143 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule93 route2 []) (correct93 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule24 route4 [(false,(3,true),(4,true))]) (correct24 route4 [(false,(3,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(0,true),(6,true))]) (correct26 route7 [(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule474 route5 []) (correct474 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_18951 : List (BitVec 256) := [w517,w572,w625,w644,w680,w865,w880,w945,w977,w1039]
private def c3_18951 : Array (PetersenProjectedRule.Rule 256) := #[rule108 route0 [],rule3 route7 [(false,(1,true),(4,true))],rule492 route0 [(false,(5,true),(3,true)),(false,(3,true),(2,true))]]
private def m3_18951 : Array (List (BitVec 256)) := #[[w572,w625,w644,w680,w865,w907,w945,w977,w1039]]
private def hs3_18951 : List (List Nat) := [[1290,519,263],[519,8229],[519,33161,522,519],[519,2567,527,519],[519,4631,4631,519],[519,3,8806,519],[519,4405,4663,519],[519,4501,4244,519],[519,4631,4631,519],[263,1034],[263,522,267,263],[263,2311,271,263],[263,4375,4375,263],[263,8806,12372,263],[263,6718,4405,263],[263,4758,4244,263],[263,4375,4375,263],[32904,522,32904,522],[8236,8750,8236,8750],[32916,16741,32916,16741],[12372,8806,12372,8806],[6204,4405,6204,4405],[4244,4501,4244,4501],[24660,0,24660,1],[522,2570,530,522],[522,4634,4634,522],[522,13396,8806,522],[522,5429,4405,522],[522,5268,4244,522],[522,4634,4634,522],[16460,8236,8236,16460],[8236,16460,8300,8236],[4405,6204,4156,4156],[4244,6292,4244,4252],[8236,12332,8252,8236],[8774,8774,16741,8806],[32916,4405,293,293],[5256,4244,32916,4244],[16741,24660,16468,16468],[582,582],[4244,2,4244,8806],[8806,12372,8276,8276],[4244,12436,4244,4260],[4389,4389,4405,24660],[1160,1160]]
theorem node3_18951 [Assumptions] : Blocked tgt 9 s3_18951 := by
  refine PetersenFastLocal.close (cut := c3_18951) (more := m3_18951) (hs := hs3_18951) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route0 []) (correct108 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route7 [(false,(1,true),(4,true))]) (correct3 route7 [(false,(1,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule492 route0 [(false,(5,true),(3,true)),(false,(3,true),(2,true))]) (correct492 route0 [(false,(5,true),(3,true)),(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w572,w625,w644,w680,w865,w907,w945,w977,w1039]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) node4_11090) <|
      PetersenLocalChildren.nil

def s3_18953 : List (BitVec 256) := [w517,w572,w625,w644,w687,w720,w778,w880,w945,w977]
private def c3_18953 : Array (PetersenProjectedRule.Rule 256) := #[rule117 route7 [],rule99 route3 [],rule146 route0 [],rule39 route3 [],rule39 route2 [],rule380 route7 [],rule26 route5 [(false,(5,true),(0,true))]]
private def m3_18953 : Array (List (BitVec 256)) := #[[w327,w517,w572,w625,w644,w720,w778,w880,w977]]
private def hs3_18953 : List (List Nat) := [[1294,523,267],[523,8233],[523,33165,526,523],[523,2571,531,523],[523,4619,539,523],[523,8747,8747,523],[523,0,8810,523],[523,8747,8747,523],[523,3469,2699,523],[267,1038],[267,526,271,267],[267,2315,275,267],[267,4363,283,267],[267,1,16745,267],[267,8810,12408,267],[267,16715,16715,267],[267,6810,2443,267],[32908,526,32908,526],[8240,8754,8240,8754],[16472,16729,16472,16729],[49384,16745,49384,16745],[12408,8810,12408,8810],[2,3,4,5],[3212,3469,3212,3469],[526,2574,534,526],[526,4622,542,526],[526,8750,8750,526],[526,13432,8810,526],[526,8750,8750,526],[526,3212,2188,526],[8240,12336,8256,8240],[16464,8240,8240,16464],[8240,16464,8304,8240],[6,8240,8240,7],[8240,3212,1164,1164],[16472,24664,16504,16472],[8810,12408,8312,8312],[32920,16472,16472,32920],[3212,6296,2200,2200],[8778,16745,8810],[297,297],[3212,8360,3212,8360],[586,586],[3212,17612,3212,8424],[3212,8360,3212,8360]]
theorem node3_18953 [Assumptions] : Blocked tgt 9 s3_18953 := by
  refine PetersenFastLocal.close (cut := c3_18953) (more := m3_18953) (hs := hs3_18953) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route7 []) (correct117 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route3 []) (correct99 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule146 route0 []) (correct146 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route3 []) (correct39 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route2 []) (correct39 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule380 route7 []) (correct380 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(0,true))]) (correct26 route5 [(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w327,w517,w572,w625,w644,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b3_2270 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19041 : List (BitVec 256) := [w517,w572,w625,w660,w680,w720,w778,w880,w977,w1061]
private def c3_19041 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule31 route4 [],rule35 route7 [],rule26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))],rule548 route0 []]
private def m3_19041 : Array (List (BitVec 256)) := #[]
private def hs3_19041 : List (List Nat) := [[1291,520,264],[520,8234],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,294,552,294],[520,35278,33479,520],[520,17866,17609,520],[520,33416,33416,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,2607,294,264],[264,16712,16712,264],[264,33160,16840,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[3117,294,3117,294],[35021,33479,35021,33479],[17609,17866,17609,17866],[0,1,0,2],[523,2571,531,523],[523,4619,539,523],[294,1318,294,298],[523,49289,32969,523],[523,17609,16585,523],[523,32905,32905,523],[8237,12333,8253,8237],[294,2342,294,302],[8237,16461,16461,8237],[8237,49229,16589,8237],[8237,16461,16461,8237],[294,4390,294,310],[32917,16469,16469,32917],[16469,32917,16597,16469],[3,16469,16469,4],[294,16742,16742,294],[294,24777,16870,294],[294,16742,16742,294],[17545,33479,17609],[583,583],[1161,1161]]
theorem node3_19041 [Assumptions] : Blocked tgt 9 s3_19041 := by
  refine PetersenFastLocal.close (cut := c3_19041) (more := m3_19041) (hs := hs3_19041) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route4 []) (correct31 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route0 []) (correct548 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_19042 : List (BitVec 256) := [w517,w572,w625,w661,w680,w720,w778,w880,w977]
private def c3_19042 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))],rule30 route4 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))],rule0 route6 [(false,(0,true),(3,true))],rule26 route4 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))],rule34 route6 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))],rule35 route6 [],rule26 route1 [(false,(1,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))],rule41 route4 [],rule3 route2 [(false,(0,true),(2,true))],rule26 route2 [(false,(3,true),(4,true)),(false,(6,true),(3,true)),(false,(1,false),(0,true))],rule31 route4 [],rule0 route5 [(false,(2,true),(4,true))],rule35 route7 [],rule26 route5 [(false,(5,true),(0,true)),(false,(4,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))],rule32 route7 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))],rule26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))],rule32 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))],rule34 route0 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))],rule26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))],rule2 route1 [(false,(3,true),(0,true))],rule1 route7 [(false,(0,true),(2,true))],rule3 route0 [(false,(3,true),(1,true))]]
private def m3_19042 : Array (List (BitVec 256)) := #[]
private def hs3_19042 : List (List Nat) := [[1308,0,0,537,537,1,281,2,281],[537,537,3,8251,2,4],[537,537,540,33179,5,33179,540,1,540,537,537,33179],[537,537,8254,2585,2593,16735,545,2593,8254,537,537,16735],[537,537,17510,4633,4649,16743,553,4649,17510,537,537,16743],[537,537,2624,311,8761,311,569,8761,2624,311,537,311],[537,537,600,2399,5,2399,600,6,600,537,537,2399],[537,537,1178,1435,33433,1435,665,33433,1178,537,537,1435],[281,281,3,1052,1,1],[281,281,32922,540,1309,540,285,1309,32922,281,281,540],[281,281,8254,2329,2337,8768,289,2337,8254,281,281,8768],[281,281,16743,4377,4393,33448,297,4393,16743,281,281,33448],[281,281,311,2624,7,2624,311,8,311,281,281,2624],[281,281,2142,600,16729,600,345,16729,2142,281,281,600],[281,281,1178,4776,33177,4776,409,33177,1178,281,281,4776],[32922,9,32922,540,10,540,32922,11,32922,540,12,540],[8254,13,8254,8768,10,8768,8254,8,8254,8768,14,8768],[17510,15,17510,16743,16,16743,17510,17,17510,16743,18,16743],[3134,19,3134,311,10,311,3134,8,3134,311,18,311],[2142,11,2142,600,10,600,2142,19,2142,600,12,600],[1178,20,1178,1435,10,1435,1178,21,1178,1435,12,1435],[540,540,8768,2588,2596,8254,548,2596,8768,540,540,8254],[540,540,16743,4636,4652,17510,556,4652,16743,540,540,17510],[311,540,311,1335,8764,1339,311,8764,311,315,540,1339],[540,540,600,3166,49370,3170,600,49370,600,540,540,3170],[540,540,4519,1178,32922,1178,154,32922,4519,154,540,1178],[8254,8254,16743,12350,12366,35247,8270,12366,16743,8254,8254,35247],[311,16478,311,2359,8254,2367,311,8254,311,319,16478,2367],[600,8254,600,2142,16478,2142,94,16478,600,94,8254,2142],[1178,8254,1178,3226,49374,3234,1178,49374,1178,1186,8254,3234],[311,16743,311,4407,24710,4423,311,24710,311,327,16743,4423],[600,33191,600,4198,16743,4198,359,16743,600,359,33191,4198],[1178,16743,1178,4250,33191,4262,423,33191,1178,423,16743,4262],[311,311,600,8792,16759,8824,375,16759,600,311,311,8824],[311,311,1178,8346,33207,8374,439,33207,1178,311,311,8374],[600,600,1178,17562,33496,17626,728,33496,1178,600,600,17626]]
theorem node3_19042 [Assumptions] : Blocked tgt 9 s3_19042 := by
  refine PetersenFastLocal.close (cut := c3_19042) (more := m3_19042) (hs := hs3_19042) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))]) (correct26 route0 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))]) (correct30 route4 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route6 [(false,(0,true),(3,true))]) (correct0 route6 [(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) (correct26 route4 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route6 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))]) (correct34 route6 [(false,(1,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(1,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))]) (correct26 route1 [(false,(1,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 [(false,(0,true),(2,true))]) (correct3 route2 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(3,true),(4,true)),(false,(6,true),(3,true)),(false,(1,false),(0,true))]) (correct26 route2 [(false,(3,true),(4,true)),(false,(6,true),(3,true)),(false,(1,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route4 []) (correct31 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route5 [(false,(2,true),(4,true))]) (correct0 route5 [(false,(2,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(0,true)),(false,(4,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) (correct26 route5 [(false,(5,true),(0,true)),(false,(4,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) (correct32 route7 [(false,(3,true),(2,true)),(false,(6,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))]) (correct32 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) (correct34 route0 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))]) (correct26 route7 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 [(false,(3,true),(0,true))]) (correct2 route1 [(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route7 [(false,(0,true),(2,true))]) (correct1 route7 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(3,true),(1,true))]) (correct3 route0 [(false,(3,true),(1,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_19070 : List (BitVec 256) := [w517,w572,w625,w662,w680,w720,w778,w880,w977,w1061]
private def c3_19070 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule41 route4 [],rule41 route7 [],rule26 route6 [(false,(1,true),(0,true)),(false,(1,true),(3,false)),(false,(0,true),(7,true))],rule548 route0 []]
private def m3_19070 : Array (List (BitVec 256)) := #[]
private def hs3_19070 : List (List Nat) := [[1291,520,264],[520,8230],[520,33162,523,520],[520,2568,528,520],[520,4616,536,520],[520,1318,552,520],[520,35278,33479,520],[520,17866,17609,520],[520,33416,33416,520],[264,1035],[264,523,268,264],[264,2312,272,264],[264,4360,280,264],[264,2607,296,264],[264,16712,16712,264],[264,33160,16840,264],[264,16712,16712,264],[32905,523,32905,523],[8237,8751,8237,8751],[16469,16726,16469,16726],[3117,1318,3117,1318],[35021,33479,35021,33479],[17609,17866,17609,17866],[0,1,0,2],[523,2571,531,523],[523,4619,539,523],[523,1318,294,294],[523,49289,32969,523],[523,17609,16585,523],[523,32905,32905,523],[8237,12333,8253,8237],[1318,2607,559,559],[8237,16461,16461,8237],[8237,49229,16589,8237],[8237,16461,16461,8237],[1318,5414,1318,1334],[32917,16469,16469,32917],[16469,32917,16597,16469],[3,16469,16469,4],[1318,17766,17766,1318],[1318,24777,17609,1318],[1318,17766,17766,1318],[17545,33479,17609],[583,583],[1161,1161]]
theorem node3_19070 [Assumptions] : Blocked tgt 9 s3_19070 := by
  refine PetersenFastLocal.close (cut := c3_19070) (more := m3_19070) (hs := hs3_19070) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route7 []) (correct41 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(1,true),(3,false)),(false,(0,true),(7,true))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(1,true),(3,false)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route0 []) (correct548 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_19107 : List (BitVec 256) := [w517,w572,w625,w680,w720,w778,w836,w880,w977,w1061]
private def c3_19107 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route0 [],rule61 route4 [],rule69 route7 [],rule425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,false)),(false,(0,true),(8,true))]]
private def m3_19107 : Array (List (BitVec 256)) := #[[w278,w517,w572,w625,w680,w778,w836,w880,w977]]
private def hs3_19107 : List (List Nat) := [[1291,520,264],[520,8230],[520,2568,528,520],[520,4616,536,520],[520,294,552,294],[520,33162,523,520],[520,35278,33479,520],[520,17866,17609,520],[520,33416,33416,520],[264,1035],[264,2312,272,264],[264,4360,280,264],[264,2607,294,264],[264,523,268,264],[264,16712,16712,264],[264,33160,16840,264],[264,16712,16712,264],[8237,8751,8237,8751],[16469,16726,16469,16726],[2093,294,2093,294],[32905,523,32905,523],[35021,33479,35021,33479],[17609,17866,17609,17866],[0,1,0,2],[8237,12333,8253,8237],[294,2093,45,45],[523,2571,523,531],[8237,16461,16461,8237],[8237,49229,16589,8237],[8237,16461,16461,8237],[294,4390,294,310],[523,4619,523,539],[32917,16469,16469,32917],[16469,32917,16597,16469],[3,16469,16469,4],[294,1318,298,294],[294,17766,17766,294],[294,24777,17609,294],[294,17766,17766,294],[523,49289,32969,523],[523,17609,16585,523],[523,32905,32905,523],[17545,33479,17609],[583,583],[1161,1161]]
theorem node3_19107 [Assumptions] : Blocked tgt 9 s3_19107 := by
  refine PetersenFastLocal.close (cut := c3_19107) (more := m3_19107) (hs := hs3_19107) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route4 []) (correct61 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route7 []) (correct69 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,false)),(false,(0,true),(8,true))]) (correct425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,false)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w278,w517,w572,w625,w680,w778,w836,w880,w977]) node4_6757 <|
      PetersenLocalChildren.nil
def s3_19116 : List (BitVec 256) := [w517,w572,w626,w644,w680,w720,w778,w880,w977,w1061]
private def c3_19116 : Array (PetersenProjectedRule.Rule 256) := #[rule3 route0 [],rule39 route0 [],rule425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,true)),(false,(0,true),(1,false))],rule548 route0 []]
private def m3_19116 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w394,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19116 : List (List Nat) := [[1292,265,521,265],[521,24679],[521,9255,524,521],[521,2569,529,521],[521,4617,537,521],[521,295,553,295],[521,35279,33480,521],[521,17867,17610,521],[521,33417,33417,521],[265,1036],[265,524,269,265],[265,2313,273,265],[265,4361,281,265],[265,2606,295,265],[265,16713,16713,265],[265,33161,16841,265],[265,16713,16713,265],[32906,524,32906,524],[16462,8238,16462,8238],[16470,16727,16470,16727],[32934,295,2094,295],[35022,33480,35022,33480],[17610,17867,17610,17867],[0,4,1,5],[524,2572,532,524],[524,4620,540,524],[295,1319,295,299],[524,49290,32970,524],[524,17610,16586,524],[524,32906,32906,524],[8238,12334,8254,8238],[295,2343,295,303],[8238,16462,16462,8238],[8238,49230,16590,8238],[8238,16462,16462,8238],[295,4391,295,311],[32918,16470,16470,32918],[16470,32918,16598,16470],[2,16470,16470,3],[295,16743,16743,295],[295,24806,16614,295],[295,16743,16743,295],[17546,33480,17610],[584,584],[1162,1162]]
theorem node3_19116 [Assumptions] : Blocked tgt 9 s3_19116 := by
  refine PetersenFastLocal.close (cut := c3_19116) (more := m3_19116) (hs := hs3_19116) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,true)),(false,(0,true),(1,false))]) (correct425 route6 [(false,(2,true),(1,true)),(false,(4,false),(1,true)),(false,(0,true),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route0 []) (correct548 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w394,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b3_309 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19144 : List (BitVec 256) := [w517,w572,w627,w644,w680,w720,w778,w880,w977,w1061]
private def c3_19144 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route0 [],rule39 route0 [],rule26 route6 [(false,(1,true),(0,true)),(false,(3,false),(7,true)),(false,(0,true),(1,false))],rule548 route0 []]
private def m3_19144 : Array (List (BitVec 256)) := #[[w455,w572,w644,w680,w720,w778,w880,w977,w1061],[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w393,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19144 : List (List Nat) := [[1293,266,522,266],[522,4],[522,9256,525,522],[522,2570,530,522],[522,4618,538,522],[522,296,554,296],[522,24680,24680,522],[522,17868,17611,522],[522,24680,24680,522],[266,1037],[266,525,270,266],[266,2314,274,266],[266,4362,282,266],[266,2607,296,266],[266,16714,16714,266],[266,33162,16842,266],[266,16714,16714,266],[32907,525,32907,525],[16463,8239,16463,8239],[16471,16728,16471,16728],[32935,296,2095,296],[35023,33481,35023,33481],[17611,17868,17611,17868],[0,5,1,6],[525,2573,533,525],[525,4621,541,525],[296,1320,296,300],[525,49291,32971,525],[525,17611,16587,525],[525,32907,32907,525],[8239,12335,8255,8239],[296,2344,296,304],[8239,16463,16463,8239],[8239,49231,16591,8239],[8239,16463,16463,8239],[296,4392,296,312],[32919,16471,16471,32919],[16471,32919,16599,16471],[2,16471,16471,3],[296,16744,16744,296],[296,32935,16615,296],[296,16744,16744,296],[17547,33481,17611],[585,585],[1163,1163]]
theorem node3_19144 [Assumptions] : Blocked tgt 9 s3_19144 := by
  refine PetersenFastLocal.close (cut := c3_19144) (more := m3_19144) (hs := hs3_19144) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(3,false),(7,true)),(false,(0,true),(1,false))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(3,false),(7,true)),(false,(0,true),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route0 []) (correct548 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w455,w572,w644,w680,w720,w778,w880,w977,w1061]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b4_1720 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w393,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (Orbits1020Cost12.b4_237 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_19149 : List (BitVec 256) := [w517,w572,w628,w644,w680,w720,w778,w880,w977]
private def c3_19149 : Array (PetersenProjectedRule.Rule 256) := #[rule35 route6 [],rule31 route4 [],rule41 route4 [],rule26 route2 [],rule27 route0 [],rule35 route5 [],rule30 route7 [],rule26 route5 [],rule35 route2 [],rule32 route7 [],rule26 route6 [],rule29 route2 [],rule35 route0 [],rule26 route7 [],rule0 route1 [],rule41 route2 [],rule0 route7 [],rule1 route5 [],rule41 route1 [],rule2 route7 [],rule2 route3 [],rule41 route0 []]
private def m3_19149 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w458,w572,w644,w680,w720,w778,w880,w977],[w458,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w832,w880,w977],[w517,w572,w644,w680,w720,w778,w880,w915,w977],[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w392,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19149 : List (List Nat) := [[1315,8254,9283,288,544,288,544,544,9283,288,8254,288],[544,544,22,23,0,24],[544,544,547,9278,9282,33186,547,9282,547,544,544,33186],[544,544,8261,2592,2600,16742,552,2600,8261,544,544,16742],[544,544,16493,4640,4656,16750,560,4656,16493,544,544,16750],[544,544,2631,318,8254,318,576,8254,2631,318,544,318],[544,544,607,2405,24702,2406,607,24702,607,544,544,2406],[544,544,1185,1442,33440,1442,672,33440,1185,544,544,1442],[288,288,22,1059,1,2],[288,288,32929,547,1316,547,292,1316,32929,288,288,547],[288,288,8261,2336,2344,8775,296,2344,8261,288,288,8775],[288,288,16493,4384,4400,33455,304,4400,16493,288,288,33455],[288,288,318,2629,9283,2631,318,9283,318,288,288,2631],[288,288,2406,607,16479,607,352,16479,2406,288,288,607],[288,288,1185,4783,33184,4783,416,33184,1185,288,288,4783],[32929,3,32929,547,4,547,32929,5,32929,547,6,547],[49381,7,49381,8261,4,8261,49381,8,49381,8261,9,8261],[32941,10,32941,16493,11,16493,32941,12,32941,16493,13,16493],[32957,14,32957,318,25,318,2117,15,32957,318,16,318],[35045,17,35045,607,26,607,2149,18,35045,607,19,607],[1185,20,1185,1442,27,1442,1185,21,1185,1442,28,1442],[547,547,8261,2595,2603,9289,555,2603,8261,547,547,9289],[547,547,16493,4643,4659,17521,563,4659,16493,547,547,17521],[318,547,318,1342,8771,1346,318,8771,318,322,547,1346],[547,547,607,3430,49377,3434,607,49377,607,547,547,3434],[547,547,4269,1185,32929,1185,161,32929,4269,161,547,1185],[8261,8261,16493,12357,12373,34997,8277,12373,16493,8261,8261,34997],[318,16485,318,2366,8261,2374,318,8261,318,326,16485,2374],[607,8261,607,2406,16485,2406,358,16485,607,358,8261,2406],[1185,8261,1185,3233,49381,3241,1185,49381,1185,1193,8261,3241],[318,16493,318,4414,24717,4430,318,24717,318,334,16493,4430],[607,32941,607,4462,16493,4462,366,16493,607,366,32941,4462],[1185,16493,1185,4269,32941,4269,173,32941,1185,173,16493,4269],[318,318,607,8799,16766,8831,382,16766,607,318,318,8831],[318,318,1185,8895,32957,8895,189,32957,1185,189,318,8895],[607,607,1185,17826,33503,17890,735,33503,1185,607,607,17890]]
theorem node3_19149 [Assumptions] : Blocked tgt 9 s3_19149 := by
  refine PetersenFastLocal.close (cut := c3_19149) (more := m3_19149) (hs := hs3_19149) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route4 []) (correct31 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route5 []) (correct35 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route2 []) (correct35 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 []) (correct32 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route1 []) (correct0 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route5 []) (correct1 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route7 []) (correct2 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 []) (correct2 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w458,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b4_1750 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w458,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b4_1748 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w832,w880,w977]) (Orbits1020Cost12.b4_2903 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w915,w977]) (Orbits1020Cost12.b4_2914 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w392,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_23 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil

def s3_19150 : List (BitVec 256) := [w517,w572,w629,w644,w680,w720,w778,w880,w945,w977]
private def c3_19150 : Array (PetersenProjectedRule.Rule 256) := #[rule108 route7 [],rule74 route6 [],rule3 route0 [],rule39 route2 [],rule47 route5 [],rule548 route2 []]
private def m3_19150 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w390,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19150 : List (List Nat) := [[1294,267,523,267],[523,8233],[523,33164,526,523],[523,2571,531,523],[523,4619,539,523],[523,8747,8747,523],[523,0,8810,523],[523,8747,8747,523],[523,1420,651,523],[267,1038],[267,526,271,267],[267,2315,275,267],[267,4363,283,267],[267,1,16745,267],[267,8810,12408,267],[267,16715,16715,267],[267,4760,395,267],[49356,526,49356,526],[8240,8754,8240,8754],[16472,16729,16472,16729],[49384,16745,49384,16745],[12408,8810,12408,8810],[2,6,3,7],[8360,1421,1164,1164],[526,2574,534,526],[526,4622,542,526],[526,8750,8750,526],[526,13432,8810,526],[526,8750,8750,526],[526,1421,397,397],[8240,12336,8256,8240],[16464,8240,8240,16464],[8240,16464,8304,8240],[4,8240,8240,5],[1421,3469,1421,1429],[16472,24664,16504,16472],[8810,12408,8312,8312],[32920,16472,16472,32920],[1421,4505,409,409],[8778,16745,8810],[297,297],[1421,8360,1421,8360],[586,586],[1421,17612,1421,8424],[1421,8360,1421,8360]]
theorem node3_19150 [Assumptions] : Blocked tgt 9 s3_19150 := by
  refine PetersenFastLocal.close (cut := c3_19150) (more := m3_19150) (hs := hs3_19150) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route7 []) (correct108 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule74 route6 []) (correct74 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route2 []) (correct39 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule47 route5 []) (correct47 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route2 []) (correct548 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w390,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b3_327 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19179 : List (BitVec 256) := [w517,w572,w630,w644,w680,w720,w778,w880,w977,w1061]
private def c3_19179 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route0 [],rule39 route0 [],rule26 route6 [(false,(1,true),(0,true)),(false,(3,false),(5,true)),(false,(0,true),(1,false))],rule548 route0 []]
private def m3_19179 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w389,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19179 : List (List Nat) := [[1292,265,521,265],[521,24679],[521,9255,524,521],[521,2569,529,521],[521,4617,537,521],[521,295,553,295],[521,35279,33480,521],[521,17867,17610,521],[521,33417,33417,521],[265,1036],[265,524,269,265],[265,2313,273,265],[265,4361,281,265],[265,2606,295,265],[265,16713,16713,265],[265,33161,16841,265],[265,16713,16713,265],[32906,524,32906,524],[16462,8238,16462,8238],[16470,16727,16470,16727],[49382,295,2094,295],[35022,33480,35022,33480],[17610,17867,17610,17867],[0,4,1,5],[524,2572,532,524],[524,4620,540,524],[295,1319,295,299],[524,49290,32970,524],[524,17610,16586,524],[524,32906,32906,524],[8238,12334,8254,8238],[295,2343,295,303],[8238,16462,16462,8238],[8238,49230,16590,8238],[8238,16462,16462,8238],[295,4391,295,311],[32918,16470,16470,32918],[16470,32918,16598,16470],[2,16470,16470,3],[295,16743,16743,295],[295,24806,16614,295],[295,16743,16743,295],[17546,33480,17610],[584,584],[1162,1162]]
theorem node3_19179 [Assumptions] : Blocked tgt 9 s3_19179 := by
  refine PetersenFastLocal.close (cut := c3_19179) (more := m3_19179) (hs := hs3_19179) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(3,false),(5,true)),(false,(0,true),(1,false))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(3,false),(5,true)),(false,(0,true),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route0 []) (correct548 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w389,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (Orbits1020Cost12.b4_251 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_19192 : List (BitVec 256) := [w517,w572,w632,w644,w680,w720,w778,w880,w977]
private def c3_19192 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [(false,(0,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))],rule35 route6 [],rule35 route7 [],rule30 route4 [(false,(0,true),(2,true)),(false,(4,true),(0,true)),(false,(0,true),(7,true))],rule26 route1 [(false,(2,true),(0,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))],rule31 route4 [],rule41 route4 [],rule61 route2 [],rule26 route2 [],rule29 route2 [],rule27 route2 [],rule35 route5 [],rule33 route5 [],rule30 route7 [],rule26 route5 [],rule27 route0 [],rule35 route2 [],rule32 route7 [],rule26 route6 [],rule35 route0 [],rule26 route7 [],rule2 route1 [],rule41 route2 [],rule2 route5 [],rule41 route1 [],rule0 route7 [],rule0 route3 [],rule41 route0 []]
private def m3_19192 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w461,w517,w572,w644,w680,w720,w778,w880,w977],[w355,w517,w572,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w880,w977,w1078],[w386,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w880,w916,w977],[w517,w572,w644,w680,w720,w778,w880,w977,w1027]]
private def hs3_19192 : List (List Nat) := [[1321,0,16485,294,550,294,550,550,16485,294,1,294],[550,550,28,8260,1,29],[550,550,553,33191,2,33192,553,3,553,550,550,33192],[550,550,8267,2598,2606,16748,558,2606,8267,550,550,16748],[550,550,16499,4646,4662,16756,566,4662,16499,550,550,16756],[550,550,2123,324,8774,324,582,8774,2123,324,550,324],[550,550,613,2411,1,2412,613,4,613,550,550,2412],[550,550,4789,1447,33446,1448,678,33446,4789,550,550,1448],[294,294,28,1065,5,6],[294,294,32935,553,1322,553,298,1322,32935,294,294,553],[294,294,8267,2342,2350,8781,302,2350,8267,294,294,8781],[294,294,16499,4390,4406,33461,310,4406,16499,294,294,33461],[294,294,324,2637,6,2637,324,7,324,294,294,2637],[294,294,2412,613,16485,613,358,16485,2412,294,294,613],[294,294,1448,4787,33190,4789,422,33190,1448,294,294,4789],[8,8,9,553,10,553,30,11,12,553,13,553],[8267,14,8267,8781,15,8781,8267,16,8267,8781,17,8781],[24723,18,24723,16499,9,16499,24723,19,24723,16499,20,16499],[2123,21,2123,324,31,324,2123,22,2123,324,32,324],[12435,23,12435,613,33,613,2155,24,12435,613,25,613],[8387,26,8387,1448,34,1448,1191,27,8387,1191,25,1448],[553,553,8267,2601,2609,9295,561,2609,8267,553,553,9295],[553,553,16499,4649,4665,17527,569,4665,16499,553,553,17527],[324,553,324,1348,8777,1352,324,8777,324,328,553,1352],[553,553,613,3436,49383,3440,613,49383,613,553,553,3440],[553,553,4532,1448,32935,1448,424,32935,4532,424,553,1448],[8267,8267,16499,12363,12379,35003,8283,12379,16499,8267,8267,35003],[324,16491,324,2123,8267,2123,75,8267,324,75,16491,2123],[613,8267,613,2412,16491,2412,364,16491,613,364,8267,2412],[1448,8267,1448,3496,49387,3504,1448,49387,1448,1456,8267,3504],[324,16499,324,4420,24723,4436,324,24723,324,340,16499,4436],[613,32947,613,4468,16499,4468,372,16499,613,372,32947,4468],[1448,16499,1448,4532,32947,4532,436,32947,1448,436,16499,4532],[324,324,613,8805,16772,8837,388,16772,613,324,324,8837],[324,324,1448,8387,33220,8387,195,33220,1448,195,324,8387],[613,613,1448,17575,33509,17639,741,33509,1448,613,613,17639]]
theorem node3_19192 [Assumptions] : Blocked tgt 9 s3_19192 := by
  refine PetersenFastLocal.close (cut := c3_19192) (more := m3_19192) (hs := hs3_19192) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))]) (correct26 route0 [(false,(0,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 [(false,(0,true),(2,true)),(false,(4,true),(0,true)),(false,(0,true),(7,true))]) (correct30 route4 [(false,(0,true),(2,true)),(false,(4,true),(0,true)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(2,true),(0,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))]) (correct26 route1 [(false,(2,true),(0,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route4 []) (correct31 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route2 []) (correct61 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route2 []) (correct27 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route5 []) (correct35 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route5 []) (correct33 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route2 []) (correct35 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 []) (correct32 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 []) (correct2 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route3 []) (correct0 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w461,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b4_1669 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w355,w517,w572,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node4_6206) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1078]) (Orbits1020Cost12.b4_2927 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w386,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_27 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w916,w977]) (Orbits1020Cost12.b4_2915 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1027]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (Orbits1020Cost12.b4_2906 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_19248 : List (BitVec 256) := [w517,w572,w634,w644,w680,w778,w865,w880,w977]
private def c3_19248 : Array (PetersenProjectedRule.Rule 256) := #[rule110 route6 [],rule34 route6 [(false,(1,true),(0,false)),(false,(2,true),(7,true)),(false,(1,true),(6,true))],rule19 route4 [(false,(5,true),(0,true))],rule54 route0 [],rule110 route2 [],rule3 route1 [],rule0 route7 [],rule16 route0 [],rule23 route7 [],rule30 route5 [],rule26 route7 [],rule43 route1 [],rule116 route0 [],rule26 route6 [(false,(1,true),(0,true)),(false,(5,true),(0,false))],rule107 route0 [],rule429 route0 [(false,(2,true),(1,false)),(false,(3,true),(8,true)),(false,(1,true),(7,true))]]
private def m3_19248 : Array (List (BitVec 256)) := #[]
private def hs3_19248 : List (List Nat) := [[1302,24689,16466,275,531,275,531,531,16466,275,24689,275],[531,531,24704,8241,0,1],[531,531,534,25713,25717,33173,534,25717,534,531,531,33173],[531,531,8248,2579,2587,16729,539,2587,8248,531,531,16729],[531,531,6200,4401,8755,4401,4659,8755,6200,531,531,4401],[531,531,32928,4627,4643,16737,547,4643,32928,531,531,16737],[531,531,594,2392,24689,2393,594,24689,594,531,531,2393],[531,531,1172,1429,33427,1429,659,33427,1172,531,531,1429],[275,275,24704,1046,2,2],[275,275,32916,534,1303,534,279,1303,32916,275,275,534],[275,275,8248,2323,2331,8762,283,2331,8248,275,275,8762],[275,275,4401,6714,24690,6714,4401,24690,4401,275,275,6714],[275,275,16737,4371,4387,33442,291,4387,16737,275,275,33442],[275,275,2393,594,16466,594,339,16466,2393,275,275,594],[275,275,1172,4770,33171,4770,403,33171,1172,275,275,4770],[24704,24704,32916,534,25732,534,25728,25732,32916,534,24704,534],[8248,24704,8248,8762,3,8762,8248,4,8248,8762,24704,8762],[6200,5,6200,4401,24704,4401,6200,24704,6200,4401,6,4401],[16480,7,32928,16480,24704,16737,24704,24704,32928,16737,8,16737],[4192,9,4192,594,24704,594,2136,24704,4192,594,10,594],[1172,24704,1172,1429,11,1429,1172,12,1172,1429,24704,1429],[534,534,8248,2582,2590,9276,542,2590,8248,534,534,9276],[534,534,4401,5425,8758,5429,4401,8758,4401,534,534,5429],[534,534,16737,4630,4646,17765,550,4646,16737,534,534,17765],[534,534,594,3417,49364,3421,594,49364,594,534,534,3421],[534,534,4256,1172,32916,1172,148,32916,4256,148,534,1172],[4401,16472,4401,6200,8248,6200,4152,8248,4401,4152,16472,6200],[16472,16472,16737,8248,8248,34984,8248,8248,16737,16472,16472,34984],[594,8248,594,2393,16472,2393,345,16472,594,345,8248,2393],[1172,8248,1172,3220,49368,3228,1172,49368,1172,1180,8248,3228],[305,4401,16737,305,13,13],[594,4401,594,8288,14,8320,594,11,594,4224,4401,8320],[1172,4401,1172,8352,15,8368,1172,3,1172,4272,4401,8368],[594,32928,594,4192,16737,4192,96,16737,594,96,32928,4192],[1172,16737,1172,4256,32928,4256,160,32928,1172,160,16737,4256],[594,594,1172,17620,33490,17620,722,33490,1172,594,594,17620]]
theorem node3_19248 [Assumptions] : Blocked tgt 9 s3_19248 := by
  refine PetersenFastLocal.close (cut := c3_19248) (more := m3_19248) (hs := hs3_19248) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route6 []) (correct110 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route6 [(false,(1,true),(0,false)),(false,(2,true),(7,true)),(false,(1,true),(6,true))]) (correct34 route6 [(false,(1,true),(0,false)),(false,(2,true),(7,true)),(false,(1,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule19 route4 [(false,(5,true),(0,true))]) (correct19 route4 [(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule54 route0 []) (correct54 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route2 []) (correct110 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule16 route0 []) (correct16 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule23 route7 []) (correct23 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route5 []) (correct30 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule43 route1 []) (correct43 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route0 []) (correct116 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(5,true),(0,false))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(5,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route0 []) (correct107 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule429 route0 [(false,(2,true),(1,false)),(false,(3,true),(8,true)),(false,(1,true),(7,true))]) (correct429 route0 [(false,(2,true),(1,false)),(false,(3,true),(8,true)),(false,(1,true),(7,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_19250 : List (BitVec 256) := [w517,w572,w635,w644,w680,w720,w778,w880,w977]
private def c3_19250 : Array (PetersenProjectedRule.Rule 256) := #[rule35 route6 [],rule34 route6 [(false,(6,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))],rule31 route4 [],rule41 route4 [],rule26 route2 [],rule27 route0 [],rule35 route5 [],rule30 route7 [],rule26 route5 [],rule35 route2 [],rule32 route7 [],rule26 route6 [],rule29 route5 [],rule34 route0 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(0,false),(2,true))],rule26 route7 [],rule34 route1 [],rule41 route2 [],rule30 route5 [],rule34 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))],rule41 route1 [],rule3 route3 [],rule29 route2 [],rule41 route0 [],rule3 route7 [],rule54 route0 [],rule26 route6 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))]]
private def m3_19250 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19250 : List (List Nat) := [[1313,8252,9281,286,542,286,542,542,9281,286,8252,286],[542,542,26,12364,0,1],[542,542,545,9276,9280,33184,545,9280,545,542,542,33184],[542,542,8259,2590,2598,16740,550,2598,8259,542,542,16740],[542,542,32939,4638,4654,16748,558,4654,32939,542,542,16748],[542,542,2629,316,8252,316,574,8252,2629,316,542,316],[542,542,605,2403,24700,2404,605,24700,605,542,542,2404],[542,542,1183,1440,33438,1440,670,33438,1183,542,542,1440],[286,286,26,1057,2,3],[286,286,32927,545,1314,545,290,1314,32927,286,286,545],[286,286,8259,2334,2342,8773,294,2342,8259,286,286,8773],[286,286,16748,4382,4398,33453,302,4398,16748,286,286,33453],[286,286,316,2627,9281,2629,316,9281,316,286,286,2629],[286,286,2404,605,16477,605,350,16477,2404,286,286,605],[286,286,1183,4781,33182,4781,414,33182,1183,286,286,4781],[32927,4,32927,545,5,545,32927,6,32927,545,7,545],[12371,8,12371,8259,5,8259,12371,9,12371,8259,10,8259],[16491,11,32939,16491,12,16748,32939,13,32939,16748,14,16748],[6227,15,6227,316,5,316,2115,16,6227,316,14,316],[4203,17,4203,605,18,605,2147,19,4203,605,14,605],[1183,20,1183,1440,21,1440,1183,22,1183,1440,23,1440],[545,545,8259,2593,2601,9287,553,2601,8259,545,545,9287],[545,545,16748,4641,4657,17776,561,4657,16748,545,545,17776],[316,545,316,1340,8769,1344,316,8769,316,320,545,1344],[545,545,605,3428,49375,3432,605,49375,605,545,545,3432],[545,545,4267,1183,32927,1183,159,32927,4267,159,545,1183],[8259,8259,16748,12371,12371,34995,8789,12371,16748,8259,8259,34995],[316,16483,316,2364,8259,2372,316,8259,316,324,16483,2372],[605,8259,605,2404,16483,2404,356,16483,605,356,8259,2404],[1183,8259,1183,3231,49379,3239,1183,49379,1183,1191,8259,3239],[316,16748,316,4412,24,4428,316,25,316,332,16748,4428],[605,32939,605,4203,16748,4203,107,16748,605,107,32939,4203],[1183,16748,1183,4267,32939,4267,171,32939,1183,171,16748,4267],[316,316,605,8797,16764,8829,380,16764,605,316,316,8829],[316,316,1183,8379,33212,8379,444,33212,1183,316,316,8379],[605,605,1183,17631,33501,17631,733,33501,1183,605,605,17631]]
theorem node3_19250 [Assumptions] : Blocked tgt 9 s3_19250 := by
  refine PetersenFastLocal.close (cut := c3_19250) (more := m3_19250) (hs := hs3_19250) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route6 [(false,(6,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))]) (correct34 route6 [(false,(6,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route4 []) (correct31 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route5 []) (correct35 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route2 []) (correct35 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 []) (correct32 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route5 []) (correct29 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(0,false),(2,true))]) (correct34 route0 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(0,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route1 []) (correct34 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route5 []) (correct30 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))]) (correct34 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 []) (correct3 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route7 []) (correct3 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule54 route0 []) (correct54 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))]) (correct26 route6 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(0,false),(1,false))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_19269 : List (BitVec 256) := [w517,w572,w636,w644,w680,w720,w778,w880,w945,w977]
private def c3_19269 : Array (PetersenProjectedRule.Rule 256) := #[rule108 route7 [],rule74 route6 [],rule26 route2 [(false,(2,true),(0,true))],rule569 route5 [],rule3 route1 [],rule41 route2 [],rule111 route0 [],rule27 route0 [],rule39 route2 [],rule35 route7 [],rule26 route5 [(false,(5,true),(0,true)),(false,(4,true),(3,false)),(false,(0,true),(1,false))],rule548 route2 []]
private def m3_19269 : Array (List (BitVec 256)) := #[]
private def hs3_19269 : List (List Nat) := [[1298,271,527,271],[527,8237],[527,33168,530,527],[527,2575,535,527],[527,4623,543,527],[527,8751,8751,527],[527,0,8814,527],[527,8751,8751,527],[527,1424,655,527],[271,1042],[271,530,275,271],[271,2319,279,271],[271,4367,287,271],[271,1,16749,271],[271,8814,12412,271],[271,16719,16719,271],[271,4766,399,271],[2,530,3,530],[8244,8758,8244,8758],[16476,16733,16476,16733],[4,16749,5,16749],[12412,8814,12412,8814],[6,7,8,9],[4252,1425,1168,1168],[530,2578,538,530],[530,4626,546,530],[530,8754,8754,530],[530,13436,8814,530],[530,8754,8754,530],[530,1425,401,401],[8244,12340,8260,8244],[16468,8244,8244,16468],[8244,16468,8308,8244],[10,8244,8244,11],[1425,3473,1425,1433],[16476,24668,16508,16476],[8814,12412,8316,8316],[33181,16476,16476,33181],[1425,4252,156,156],[8782,16749,8814],[301,301],[1425,8878,1425,8878],[590,590],[1425,17873,1425,8814],[1425,8878,1425,8878]]
theorem node3_19269 [Assumptions] : Blocked tgt 9 s3_19269 := by
  refine PetersenFastLocal.close (cut := c3_19269) (more := m3_19269) (hs := hs3_19269) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route7 []) (correct108 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule74 route6 []) (correct74 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(2,true),(0,true))]) (correct26 route2 [(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule569 route5 []) (correct569 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule111 route0 []) (correct111 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route2 []) (correct39 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(0,true)),(false,(4,true),(3,false)),(false,(0,true),(1,false))]) (correct26 route5 [(false,(5,true),(0,true)),(false,(4,true),(3,false)),(false,(0,true),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule548 route2 []) (correct548 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_19557 : List (BitVec 256) := [w517,w572,w644,w680,w703,w720,w778,w880,w977]
private def c3_19557 : Array (PetersenProjectedRule.Rule 256) := #[rule35 route2 [],rule30 route6 [(false,(1,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))],rule26 route0 [],rule27 route0 [],rule34 route7 [],rule35 route6 [],rule27 route4 [],rule41 route4 [],rule92 route1 [],rule26 route2 [],rule30 route0 [(false,(5,false),(2,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false))],rule30 route7 [],rule34 route5 [(false,(6,false),(0,true)),(false,(2,true),(5,true)),(false,(1,true),(0,false))],rule29 route2 [],rule34 route2 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))],rule26 route4 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))],rule35 route3 [],rule30 route1 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))],rule3 route3 [(false,(3,true),(1,true))],rule26 route5 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))],rule26 route6 [],rule2 route2 [(false,(3,true),(0,true))],rule1 route0 [(false,(3,true),(1,true))],rule26 route7 [],rule3 route1 [],rule29 route1 [],rule41 route2 [],rule0 route7 [],rule3 route5 [],rule29 route6 [],rule41 route3 [],rule1 route3 [],rule2 route7 []]
private def m3_19557 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w308,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19557 : List (List Nat) := [[1065,8260,1065,550,550,1322,550,550,1065,1066,8260,1322],[550,550,553,9288,9288,33192,553,9288,553,550,550,33192],[550,550,8781,2598,2606,0,558,2606,8781,550,550,1],[8260,8260,2,550,550,3,550,550,4,8260,8260,5],[550,550,16499,4646,4662,16756,566,4662,16499,550,550,16756],[550,550,2123,324,8260,324,68,8260,2123,68,550,324],[550,550,613,2411,24708,2412,613,24708,613,550,550,2412],[550,550,1191,1447,33446,1448,678,33446,1191,550,550,1448],[1318,2350,32935,553,1065,553,1065,1065,32935,553,2350,553],[1065,1065,9295,2342,2350,8781,1073,2350,9295,1065,1065,8781],[294,1065,33,294,6,7],[1065,1065,16499,5161,5177,33461,1081,5177,16499,1065,1065,33461],[324,1065,324,2635,9289,2637,324,9289,324,1065,1065,2637],[1065,1065,2155,613,7,613,1129,8,2155,613,1065,613],[1065,1065,1191,4787,33190,4789,1191,33190,1191,1065,1065,4789],[553,553,8781,2601,2609,9295,561,2609,8781,553,553,9295],[49383,49383,9,553,553,10,553,553,11,49383,49383,12],[553,553,16499,4649,4665,17527,569,4665,16499,553,553,17527],[324,553,324,1352,8777,1352,324,8777,324,553,553,1352],[553,553,613,3179,49383,3183,613,49383,613,553,553,3183],[553,553,4789,1191,32935,1191,681,32935,4789,553,553,1191],[8267,8781,33,8267,13,14],[8781,8781,16499,12877,12893,35003,8797,12893,16499,8781,8781,35003],[324,15,324,2123,8781,2123,324,8781,324,589,16,2123],[613,8781,613,2155,0,2155,613,17,613,621,8781,2155],[1191,8781,1191,3239,18,3247,1191,19,1191,1199,8781,3247],[16499,20,16499,32947,21,32947,16499,22,16499,32947,23,32947],[324,24,324,1352,25,1352,324,26,324,1352,27,1352],[4211,28,4211,613,29,613,4211,30,4211,613,34,613],[17639,31,17639,1191,18,1191,4275,22,17639,1191,32,1191],[324,16499,324,4420,24723,4436,324,24723,324,340,16499,4436],[613,32947,613,4211,16499,4211,115,16499,613,115,32947,4211],[1191,16499,1191,4789,32947,4789,693,32947,1191,693,16499,4789],[324,324,613,8805,16772,8837,388,16772,613,324,324,8837],[324,324,1191,8901,32963,8901,709,32963,1191,324,324,8901],[613,613,1191,17639,33509,17639,741,33509,1191,613,613,17639]]
theorem node3_19557 [Assumptions] : Blocked tgt 9 s3_19557 := by
  refine PetersenFastLocal.close (cut := c3_19557) (more := m3_19557) (hs := hs3_19557) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route2 []) (correct35 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route6 [(false,(1,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))]) (correct30 route6 [(false,(1,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route7 []) (correct34 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route4 []) (correct27 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route1 []) (correct92 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(5,false),(2,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false))]) (correct30 route0 [(false,(5,false),(2,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(6,false),(0,true)),(false,(2,true),(5,true)),(false,(1,true),(0,false))]) (correct34 route5 [(false,(6,false),(0,true)),(false,(2,true),(5,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))]) (correct34 route2 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))]) (correct26 route4 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route3 []) (correct35 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))]) (correct30 route1 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 [(false,(3,true),(1,true))]) (correct3 route3 [(false,(3,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))]) (correct26 route5 [(false,(1,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route2 [(false,(3,true),(0,true))]) (correct2 route2 [(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(3,true),(1,true))]) (correct1 route0 [(false,(3,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route1 []) (correct29 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 []) (correct3 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route6 []) (correct29 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route3 []) (correct41 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route3 []) (correct1 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route7 []) (correct2 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w308,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_31 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19562 : List (BitVec 256) := [w517,w572,w644,w680,w704,w720,w778,w880,w977]
private def c3_19562 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule27 route0 [],rule34 route7 [],rule35 route6 [],rule27 route4 [],rule41 route4 [],rule109 route2 [],rule26 route2 [],rule26 route2 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))],rule30 route0 [(false,(5,false),(0,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false))],rule30 route7 [],rule27 route5 [],rule34 route5 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))],rule29 route2 [],rule34 route2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))],rule26 route6 [],rule2 route2 [(false,(0,true),(3,true))],rule1 route0 [(false,(1,true),(3,true))],rule26 route7 [],rule3 route1 [],rule29 route1 [],rule41 route2 [],rule3 route5 [],rule41 route1 [],rule2 route7 [],rule0 route3 [],rule3 route2 [(false,(3,true),(1,true))],rule0 route7 []]
private def m3_19562 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w359,w517,w572,w680,w720,w778,w880,w977],[w307,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19562 : List (List Nat) := [[1061,8256,1061,546,546,1318,546,546,1061,1062,8256,1318],[546,546,549,9280,9284,33188,549,9284,549,546,546,33188],[546,546,8777,2594,2602,17772,554,2602,8777,546,546,17772],[8256,8256,0,546,546,1,546,546,2,8256,8256,3],[546,546,16495,4642,4658,16752,562,4658,16495,546,546,16752],[546,546,2119,320,8256,320,64,8256,2119,64,546,320],[546,546,609,2407,24704,2408,609,24704,609,546,546,2408],[546,546,1187,1443,33442,1444,674,33442,1187,546,546,1444],[1314,2346,32931,549,1061,549,1061,1061,32931,549,2346,549],[1061,1061,17515,2338,2346,8777,1069,2346,17515,1061,1061,8777],[290,1061,28,290,4,5],[1061,1061,16495,5157,5173,33457,1077,5173,16495,1061,1061,33457],[320,1061,320,2631,5,2633,320,6,320,1061,1061,2633],[1061,1061,2151,609,17509,609,1125,17509,2151,609,1061,609],[1061,1061,1187,4783,33186,4785,1187,33186,1187,1061,1061,4785],[549,549,8777,2597,2605,17515,557,2605,8777,549,549,17515],[7,8,7,549,549,9,549,549,10,29,11,12],[549,549,16495,4645,4661,17523,565,4661,16495,549,549,17523],[320,549,320,3143,8773,3147,320,8773,320,324,549,3147],[549,549,609,3175,49379,3179,609,49379,609,549,549,3179],[549,549,4785,1187,32931,1187,677,32931,4785,549,549,1187],[8263,8777,28,8263,13,14],[8777,8777,16495,12873,12889,34999,8793,12889,16495,8777,8777,34999],[320,17515,320,2119,8777,2119,320,8777,320,585,17515,2119],[609,8777,609,2151,17515,2151,609,17515,609,617,8777,2151],[1187,8777,1187,3235,49383,3243,1187,49383,1187,1195,8777,3243],[16495,15,16495,17523,16,17523,16495,17,16495,17523,18,17523],[320,19,320,1348,20,2119,320,21,320,2119,30,2119],[4207,22,4207,609,11,609,4207,23,4207,609,24,609],[8383,25,8383,1187,26,1187,4271,17,8383,1187,27,1187],[320,16495,320,4416,24719,4432,320,24719,320,336,16495,4432],[609,32943,609,4207,16495,4207,111,16495,609,111,32943,4207],[1187,16495,1187,4785,32943,4785,689,32943,1187,689,16495,4785],[320,320,609,8801,16768,8833,384,16768,609,320,320,8833],[320,320,1187,8383,33473,8383,191,33473,1187,191,320,8383],[609,609,1187,17571,33505,17635,737,33505,1187,609,609,17635]]
theorem node3_19562 [Assumptions] : Blocked tgt 9 s3_19562 := by
  refine PetersenFastLocal.close (cut := c3_19562) (more := m3_19562) (hs := hs3_19562) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route7 []) (correct34 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route4 []) (correct27 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route2 []) (correct109 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))]) (correct26 route2 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(5,false),(0,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false))]) (correct30 route0 [(false,(5,false),(0,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route5 []) (correct27 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))]) (correct34 route5 [(false,(6,false),(2,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))]) (correct34 route2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route2 [(false,(0,true),(3,true))]) (correct2 route2 [(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(1,true),(3,true))]) (correct1 route0 [(false,(1,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route1 []) (correct29 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 []) (correct3 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route7 []) (correct2 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route3 []) (correct0 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 [(false,(3,true),(1,true))]) (correct3 route2 [(false,(3,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w359,w517,w572,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node4_6143) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w307,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_33 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil

def s3_19567 : List (BitVec 256) := [w517,w572,w644,w680,w705,w720,w778,w880,w977]
private def c3_19567 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule3 route0 [(false,(2,true),(0,true))],rule34 route7 [],rule0 route6 [(false,(4,true),(2,true))],rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(4,true))],rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false))],rule41 route4 [],rule3 route2 [(false,(1,true),(3,true))],rule26 route2 [(false,(4,true),(6,false)),(false,(2,true),(5,true)),(false,(1,true),(0,false))],rule26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))],rule26 route2 [],rule26 route2 [(false,(4,true),(1,true)),(false,(0,false),(7,true))],rule30 route7 [],rule518 route4 [],rule34 route5 [(false,(1,true),(4,true)),(false,(7,true),(0,false))],rule26 route4 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule43 route5 [],rule26 route3 [(false,(6,true),(4,false)),(false,(2,true),(7,true)),(false,(1,true),(0,false))],rule29 route2 [],rule34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))],rule26 route6 [],rule1 route0 [(false,(3,true),(1,true))],rule26 route7 [],rule3 route1 [],rule29 route1 [],rule41 route2 [],rule0 route7 [],rule3 route5 [],rule27 route5 [],rule41 route1 [],rule2 route7 [],rule26 route3 []]
private def m3_19567 : Array (List (BitVec 256)) := #[[w0,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w880,w977,w1036]]
private def hs3_19567 : List (List Nat) := [[3120,8259,3120,549,549,2349,549,549,3120,2093,8259,2349],[549,549,552,9283,9287,35247,552,9287,552,549,549,35247],[549,549,8780,2597,2605,49643,557,2605,8780,549,549,49643],[8259,8259,0,549,549,1,549,549,2,8259,8259,3],[549,549,16498,4645,4661,16755,565,4661,16498,549,549,16755],[549,549,2122,323,8259,323,67,8259,2122,67,549,323],[549,549,612,2410,24707,2411,612,24707,612,549,549,2411],[549,549,1190,1446,33445,1447,677,33445,1190,549,549,1447],[2349,2349,34990,552,3120,552,2096,3120,34990,552,2349,552],[2341,33189,49386,2341,2349,8780,2349,2349,49386,8780,33189,8780],[293,2349,32,293,4,5],[2349,2349,16498,6445,6461,33460,2365,6461,16498,2349,2349,33460],[323,2349,323,2634,6,2636,323,7,323,2124,2349,2636],[2154,2349,2154,612,49380,612,2154,49380,2154,612,2349,612],[1190,2349,1190,4786,33189,4788,1190,33189,1190,2349,2349,4788],[552,552,8780,2600,2608,8,560,2608,8780,552,552,9],[32934,8,10,552,552,11,552,552,12,13,14,15],[552,552,16498,4648,4664,17526,568,4664,16498,552,552,17526],[323,552,323,1347,8776,1351,323,8776,323,327,552,1351],[552,552,612,3178,16,3182,612,17,612,552,552,3182],[552,552,4788,1190,33448,1190,166,33448,4788,166,552,1190],[8266,8780,32,8266,18,19],[8780,8780,16498,12876,12892,35002,8796,12892,16498,8780,8780,35002],[323,49386,323,2122,8780,2122,323,8780,323,588,49386,2122],[612,8780,612,2154,49386,2154,612,49386,612,620,8780,2154],[1190,8780,1190,3246,49386,3246,1190,49386,1190,3246,8780,3246],[16498,20,16498,32946,21,32946,16498,21,16498,32946,22,32946],[323,23,323,2122,24,2122,323,25,323,2122,26,2122],[4210,27,4210,612,28,612,4210,29,4210,612,30,612],[1190,31,1190,3246,33,3246,1190,21,1190,3246,12,3246],[323,16498,323,4419,24722,4435,323,24722,323,339,16498,4435],[612,32946,612,4210,16498,4210,114,16498,612,114,32946,4210],[1190,16498,1190,4788,32946,4788,692,32946,1190,692,16498,4788],[323,323,612,8804,16771,8836,387,16771,612,323,323,8836],[323,323,1190,8900,32962,8900,708,32962,1190,323,323,8900],[612,612,1190,17574,33508,17638,740,33508,1190,612,612,17638]]
theorem node3_19567 [Assumptions] : Blocked tgt 9 s3_19567 := by
  refine PetersenFastLocal.close (cut := c3_19567) (more := m3_19567) (hs := hs3_19567) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(2,true),(0,true))]) (correct3 route0 [(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route7 []) (correct34 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route6 [(false,(4,true),(2,true))]) (correct0 route6 [(false,(4,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(4,true))]) (correct26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false))]) (correct26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route4 []) (correct41 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 [(false,(1,true),(3,true))]) (correct3 route2 [(false,(1,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(4,true),(6,false)),(false,(2,true),(5,true)),(false,(1,true),(0,false))]) (correct26 route2 [(false,(4,true),(6,false)),(false,(2,true),(5,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))]) (correct26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(4,true),(1,true)),(false,(0,false),(7,true))]) (correct26 route2 [(false,(4,true),(1,true)),(false,(0,false),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule518 route4 []) (correct518 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(1,true),(4,true)),(false,(7,true),(0,false))]) (correct34 route5 [(false,(1,true),(4,true)),(false,(7,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct26 route4 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule43 route5 []) (correct43 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(6,true),(4,false)),(false,(2,true),(7,true)),(false,(1,true),(0,false))]) (correct26 route3 [(false,(6,true),(4,false)),(false,(2,true),(7,true)),(false,(1,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))]) (correct34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(3,true),(1,true))]) (correct1 route0 [(false,(3,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route1 []) (correct29 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 []) (correct0 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 []) (correct3 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route5 []) (correct27 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route7 []) (correct2 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 []) (correct26 route3 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_6 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1036]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_526 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19651 : List (BitVec 256) := [w517,w572,w644,w680,w707,w720,w778,w880,w977]
private def c3_19651 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule27 route0 [],rule30 route4 [],rule35 route6 [],rule24 route0 [],rule24 route7 [],rule75 route0 [],rule69 route7 [],rule30 route0 [(false,(5,true),(2,true)),(false,(4,true),(2,true)),(false,(0,true),(1,true))],rule34 route5 [(false,(6,true),(0,true)),(false,(5,true),(2,true)),(false,(0,true),(1,true))],rule76 route5 [],rule26 route3 [(false,(4,true),(2,true)),(false,(7,true),(2,true)),(false,(0,true),(1,true))],rule32 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))],rule34 route2 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))],rule76 route3 [],rule26 route5 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))],rule34 route3 [(false,(1,true),(2,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))],rule26 route6 [],rule33 route2 [],rule35 route0 [],rule32 route4 [],rule3 route1 [],rule29 route1 [],rule41 route2 [],rule3 route4 [],rule3 route6 [],rule2 route6 [],rule3 route3 [],rule2 route4 [],rule3 route5 [],rule0 route4 []]
private def m3_19651 : Array (List (BitVec 256)) := #[[w517,w569,w572,w644,w680,w720,w778,w880,w977],[w12,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w642,w644,w680,w720,w778,w880,w977],[w14,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w679,w680,w720,w778,w880,w977],[w16,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19651 : List (List Nat) := [[1067,8262,1067,296,552,296,40,552,1067,40,8262,296],[552,552,555,9286,9290,35250,555,9290,555,552,552,35250],[552,552,8269,2600,2608,17778,560,2608,8269,552,552,17778],[552,552,0,25738,25738,1,25738,25738,2,552,552,3],[552,552,16501,4648,4664,16758,568,4664,16501,552,552,16758],[552,552,2125,326,8262,326,70,8262,2125,70,552,326],[552,552,4213,4469,24710,4470,4213,24710,4213,552,552,4470],[552,552,4277,4533,33448,4534,4277,33448,4277,552,552,4534],[296,296,34993,555,1067,555,43,1067,34993,43,296,555],[296,296,8269,2344,2352,8783,304,2352,8269,296,296,8783],[296,296,31,17515,17515,4,16487,17515,32,296,296,5],[296,296,16501,4392,4408,33463,312,4408,16501,296,296,33463],[296,296,326,2637,9291,2639,326,9291,326,296,296,2639],[296,296,4213,4725,17515,33511,4213,17515,4213,296,296,33511],[296,296,4277,4789,35248,6,4277,35248,4277,296,296,7],[555,555,8269,2603,2611,9297,563,2611,8269,555,555,9297],[555,555,33,33451,33451,8,32937,33451,34,555,555,9],[555,555,16501,4651,4667,17529,571,4667,16501,555,555,17529],[326,555,326,1350,8779,1354,326,8779,326,330,555,1354],[555,555,4213,5237,10,8,4213,11,4213,555,555,9],[555,555,4277,5301,33451,17641,4277,33451,4277,555,555,17641],[8269,8269,35,17521,17521,12,16493,17521,36,8269,8269,13],[8269,8269,16501,12365,12381,35005,8285,12381,16501,8269,8269,35005],[326,17521,326,2125,8269,2125,77,8269,326,77,17521,2125],[4213,8269,4213,6261,17521,35053,4213,17521,4213,8269,8269,35053],[4277,8269,4277,6325,14,12,4277,15,4277,8269,8269,16],[16501,17,16501,17529,18,17529,16501,19,16501,17529,20,17529],[326,21,326,17802,22,17802,326,23,326,17802,24,17802],[4213,25,4213,33511,26,33511,615,27,4213,615,28,33511],[4277,27,4277,17641,25,17641,1193,29,4277,1193,30,17641],[326,16501,326,4422,24725,4438,326,24725,326,342,16501,4438],[32949,32949,33511,4213,16501,4213,117,16501,33511,117,32949,4213],[8389,16501,8389,4277,32949,4277,181,32949,8389,181,16501,4277],[326,326,4213,12405,16774,12437,390,16774,4213,326,326,12437],[326,326,4277,8389,32965,8389,197,32965,4277,197,326,8389],[4213,4213,4277,17577,33511,17641,4277,33511,4277,4213,4213,17641]]
theorem node3_19651 [Assumptions] : Blocked tgt 9 s3_19651 := by
  refine PetersenFastLocal.close (cut := c3_19651) (more := m3_19651) (hs := hs3_19651) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 []) (correct30 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route6 []) (correct35 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule24 route0 []) (correct24 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule24 route7 []) (correct24 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route0 []) (correct75 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route7 []) (correct69 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(5,true),(2,true)),(false,(4,true),(2,true)),(false,(0,true),(1,true))]) (correct30 route0 [(false,(5,true),(2,true)),(false,(4,true),(2,true)),(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(6,true),(0,true)),(false,(5,true),(2,true)),(false,(0,true),(1,true))]) (correct34 route5 [(false,(6,true),(0,true)),(false,(5,true),(2,true)),(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route5 []) (correct76 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(4,true),(2,true)),(false,(7,true),(2,true)),(false,(0,true),(1,true))]) (correct26 route3 [(false,(4,true),(2,true)),(false,(7,true),(2,true)),(false,(0,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) (correct32 route0 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) (correct34 route2 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route3 []) (correct76 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) (correct26 route5 [(false,(1,true),(0,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route3 [(false,(1,true),(2,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))]) (correct34 route3 [(false,(1,true),(2,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route2 []) (correct33 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route4 []) (correct32 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route1 []) (correct29 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 []) (correct3 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route6 []) (correct3 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route6 []) (correct2 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 []) (correct3 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 []) (correct2 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 []) (correct3 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route4 []) (correct0 route4 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w569,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_485 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w12,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_11 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w642,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_426 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w14,w517,w572,w644,w680,w720,w778,w880,w977]) (fun m le c => (Orbits1020Cost12.b2_13 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w679,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_426 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w16,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_13 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19658 : List (BitVec 256) := [w517,w572,w644,w680,w708,w720,w778,w860,w880,w977]
private def c3_19658 : Array (PetersenProjectedRule.Rule 256) := #[rule110 route2 [],rule73 route1 [],rule41 route2 [],rule115 route0 [],rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))],rule37 route0 [],rule3 route4 []]
private def m3_19658 : Array (List (BitVec 256)) := #[[w358,w517,w572,w680,w720,w778,w860,w880,w977]]
private def hs3_19658 : List (List Nat) := [[1038,523,523,1039],[523,9261,526,523],[523,2571,531,523],[8233,523,523,8233],[523,4619,539,523],[523,8233,8233,523],[523,8233,8233,523],[523,2384,586,523],[523,4504,4248,523],[1291,526,1038,526],[1038,2315,1046,1038],[267,267],[1038,5134,1054,1038],[1038,9262,9262,1038],[1038,9262,9262,1038],[1038,586,1102,586],[1038,8874,4248,1038],[526,2574,534,526],[526,7],[526,4622,542,526],[526,8750,8750,526],[526,8750,8750,526],[526,3152,586,526],[526,9388,4248,526],[8240,8240],[8754,12850,8770,8754],[17492,8754,8754,17492],[17492,8754,8754,17492],[586,2128,586,594],[4248,0,4248,8754],[16472,17500,16472,17500],[1,33450,2,33450],[3,4,5,6],[4184,586,4184,586],[4248,8874,4248,8874],[16472,24696,24696,16472],[16472,24696,24696,16472],[586,4184,88,88],[8360,4248,152,152],[297,297],[586,8810,586,8810],[4248,8360,4248,8360],[586,8810,586,8810],[4248,8360,1164,1164],[586,24744,4248,586]]
theorem node3_19658 [Assumptions] : Blocked tgt 9 s3_19658 := by
  refine PetersenFastLocal.close (cut := c3_19658) (more := m3_19658) (hs := hs3_19658) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route2 []) (correct110 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule73 route1 []) (correct73 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 []) (correct41 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule115 route0 []) (correct115 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))]) (correct26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 []) (correct3 route4 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w358,w517,w572,w680,w720,w778,w860,w880,w977]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) node4_6093) <|
      PetersenLocalChildren.nil
def s3_19664 : List (BitVec 256) := [w517,w572,w644,w680,w708,w720,w778,w880,w925,w977]
private def c3_19664 : Array (PetersenProjectedRule.Rule 256) := #[rule108 route4 [],rule108 route2 [],rule69 route6 [],rule41 route1 [],rule118 route0 [],rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(2,true))],rule39 route0 [],rule2 route4 []]
private def m3_19664 : Array (List (BitVec 256)) := #[]
private def hs3_19664 : List (List Nat) := [[1038,523,523,1039],[523,9261,526,523],[523,2571,531,523],[8233,523,523,8233],[523,4619,539,523],[523,297,41,41],[523,24681,24681,523],[523,24681,24681,523],[523,4504,4248,523],[1291,526,1038,526],[1038,2315,1046,1038],[267,267],[1038,5134,1054,1038],[297,2608,297,1038],[1038,17486,17486,1038],[1038,17486,17486,1038],[1038,35219,4248,1038],[526,2574,534,526],[526,49356],[526,4622,542,526],[297,1325,297,526],[526,0,33482,526],[526,33422,33422,526],[526,17612,4248,526],[8240,8240],[8754,12850,8770,8754],[297,2096,297,562],[8754,17492,17492,8754],[8754,17492,17492,8754],[4248,1,4248,8754],[16472,17500,16472,17500],[297,1325,297,1325],[2,33482,3,33482],[4,5,6,7],[4248,17612,4248,17612],[297,4393,297,313],[32920,16472,16472,32920],[32920,16472,16472,32920],[8360,4248,152,152],[297,16745,16745,297],[297,16745,16745,297],[297,8360,168,168],[586,586],[4248,17548,4248,17612],[4248,17612,1164,1164]]
theorem node3_19664 [Assumptions] : Blocked tgt 9 s3_19664 := by
  refine PetersenFastLocal.close (cut := c3_19664) (more := m3_19664) (hs := hs3_19664) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route4 []) (correct108 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route2 []) (correct108 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule118 route0 []) (correct118 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(2,true))]) (correct26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 []) (correct2 route4 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_19688 : List (BitVec 256) := [w517,w572,w644,w680,w708,w720,w778,w880,w977,w1076]
private def c3_19688 : Array (PetersenProjectedRule.Rule 256) := #[rule404 route2 [],rule26 route4 [(false,(1,true),(2,true))],rule35 route3 [],rule236 route0 [],rule29 route0 [],rule37 route0 [],rule27 route4 [],rule26 route7 [(false,(3,true),(2,true)),(false,(0,false),(6,true))],rule577 route1 []]
private def m3_19688 : Array (List (BitVec 256)) := #[]
private def hs3_19688 : List (List Nat) := [[1039,524,524,1040],[524,9262,527,524],[524,2572,532,524],[8234,524,524,8234],[524,4620,540,524],[524,8234,8234,524],[524,24618,8298,524],[524,17869,8361,524],[524,8234,8234,524],[1292,527,1039,527],[1039,2316,1047,1039],[268,268],[1039,5135,1055,1039],[1039,9263,9263,1039],[1039,8811,9327,1039],[1039,8875,8361,1039],[1039,9263,9263,1039],[527,2575,535,527],[527,32909],[527,4623,543,527],[527,8751,8751,527],[527,13437,8811,527],[527,9389,8361,527],[527,8751,8751,527],[8241,8241],[8755,12851,8771,8755],[16746,8755,8755,17493],[8755,17493,8811,8755],[8361,0,8361,8755],[1,8755,8755,2],[16473,17501,16473,17501],[16746,17774,16746,17774],[12409,8811,12409,8811],[8361,8875,8361,8875],[3,4,5,6],[16473,24665,16505,16473],[8811,12409,8313,8313],[8361,12457,8361,8377],[7,16473,16473,8],[8779,8779,16746,8811],[9357,8361,16617,8361],[298,298],[8361,17549,8361,8425],[587,587],[1165,1165]]
theorem node3_19688 [Assumptions] : Blocked tgt 9 s3_19688 := by
  refine PetersenFastLocal.close (cut := c3_19688) (more := m3_19688) (hs := hs3_19688) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule404 route2 []) (correct404 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(1,true),(2,true))]) (correct26 route4 [(false,(1,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route3 []) (correct35 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule236 route0 []) (correct236 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route0 []) (correct29 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route4 []) (correct27 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(3,true),(2,true)),(false,(0,false),(6,true))]) (correct26 route7 [(false,(3,true),(2,true)),(false,(0,false),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule577 route1 []) (correct577 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_19692 : List (BitVec 256) := [w517,w572,w644,w680,w708,w720,w778,w900,w977]
private def c3_19692 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))],rule29 route0 [],rule30 route4 [(false,(6,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))],rule84 route6 [],rule26 route3 [(false,(6,true),(1,true)),(false,(0,false),(5,false)),(false,(0,true),(4,true))],rule24 route7 [(false,(5,true),(3,false)),(false,(0,true),(5,true))],rule27 route5 [],rule34 route5 [(false,(4,true),(1,true)),(false,(0,false),(7,false)),(false,(0,true),(2,true))],rule35 route4 [],rule3 route2 [(false,(3,true),(1,false)),(false,(0,true),(5,true))],rule34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))],rule3 route3 [(false,(1,true),(3,true))],rule26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))],rule26 route6 [(false,(5,true),(0,true)),(false,(0,false),(4,true)),(false,(0,false),(8,false)),(false,(0,true),(7,true))],rule2 route2 [(false,(0,true),(3,true))],rule1 route0 [(false,(1,true),(3,true))],rule32 route4 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(6,false)),(false,(0,true),(9,true))],rule61 route1 [],rule31 route1 [],rule110 route2 [],rule27 route4 [],rule61 route6 [],rule27 route3 [],rule41 route1 [],rule3 route3 [],rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))]]
private def m3_19692 : Array (List (BitVec 256)) := #[]
private def hs3_19692 : List (List Nat) := [[1056,8251,1056,541,541,1313,541,541,1056,1057,8251,1313],[541,541,544,9279,9279,35239,544,9279,544,541,541,35239],[541,541,8772,2589,2597,17767,549,2597,8772,541,541,17767],[8251,8251,0,541,541,1,541,541,2,8251,8251,3],[541,541,16490,4637,4653,16747,557,4653,16490,541,541,16747],[541,541,2114,315,8251,315,59,8251,2114,59,541,315],[541,541,604,2402,24699,2403,604,24699,604,541,541,2403],[541,541,1182,1438,33437,1439,669,33437,1182,541,541,1439],[1309,2341,34982,544,1056,544,1056,1056,34982,544,2341,544],[1056,1056,9286,2333,2341,8772,1064,2341,9286,1056,1056,8772],[285,1056,4,285,5,5],[1056,1056,16490,5152,5168,33452,1072,5168,16490,1056,1056,33452],[315,1056,315,2626,9280,2628,315,9280,315,1056,1056,2628],[1056,1056,2146,604,17504,604,1120,17504,2146,604,1056,604],[1056,1056,1182,4780,35237,4780,1182,35237,1182,1056,1056,4780],[544,544,8772,2592,2600,9286,552,2600,8772,544,544,9286],[544,544,4,32990,6,7],[544,544,16490,4640,4656,17518,560,4656,16490,544,544,17518],[315,544,315,1343,8768,1343,315,8768,315,544,544,1343],[544,544,604,3170,8,3174,604,4,604,544,544,3174],[544,544,4780,1182,33440,1182,672,33440,4780,544,544,1182],[8258,8772,4,8258,9,10],[8772,8772,16490,12868,12884,34994,8788,12884,16490,8772,8772,34994],[315,17510,315,2114,8772,2114,315,8772,315,580,17510,2114],[604,8772,604,2146,17510,2146,604,17510,604,612,8772,2146],[1182,8772,1182,3230,11,3238,1182,12,1182,1190,8772,3238],[16490,13,16490,17518,14,17518,16490,15,16490,17518,16,17518],[315,17,315,1343,18,1343,315,19,315,1343,20,1343],[4202,21,4202,604,22,604,4202,23,4202,604,20,604],[24762,24,24762,1182,11,1182,24762,15,24762,1182,25,1182],[315,16490,315,4411,24714,4427,315,24714,315,331,16490,4427],[604,33452,604,4202,16490,4202,106,16490,604,106,33452,4202],[1182,16490,1182,4780,32938,4780,684,32938,1182,684,16490,4780],[315,315,604,8796,16763,8828,379,16763,604,315,315,8828],[315,315,1182,8892,32954,8892,700,32954,1182,315,315,8892],[604,604,1182,17566,33500,17630,732,33500,1182,604,604,17630]]
theorem node3_19692 [Assumptions] : Blocked tgt 9 s3_19692 := by
  refine PetersenFastLocal.close (cut := c3_19692) (more := m3_19692) (hs := hs3_19692) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))]) (correct26 route0 [(false,(3,true),(4,true)),(false,(0,false),(6,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route0 []) (correct29 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 [(false,(6,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))]) (correct30 route4 [(false,(6,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(4,false)),(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule84 route6 []) (correct84 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(6,true),(1,true)),(false,(0,false),(5,false)),(false,(0,true),(4,true))]) (correct26 route3 [(false,(6,true),(1,true)),(false,(0,false),(5,false)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule24 route7 [(false,(5,true),(3,false)),(false,(0,true),(5,true))]) (correct24 route7 [(false,(5,true),(3,false)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route5 []) (correct27 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route5 [(false,(4,true),(1,true)),(false,(0,false),(7,false)),(false,(0,true),(2,true))]) (correct34 route5 [(false,(4,true),(1,true)),(false,(0,false),(7,false)),(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route4 []) (correct35 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 [(false,(3,true),(1,false)),(false,(0,true),(5,true))]) (correct3 route2 [(false,(3,true),(1,false)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))]) (correct34 route2 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 [(false,(1,true),(3,true))]) (correct3 route3 [(false,(1,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))]) (correct26 route5 [(false,(1,true),(0,true)),(false,(0,false),(3,false)),(false,(0,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(5,true),(0,true)),(false,(0,false),(4,true)),(false,(0,false),(8,false)),(false,(0,true),(7,true))]) (correct26 route6 [(false,(5,true),(0,true)),(false,(0,false),(4,true)),(false,(0,false),(8,false)),(false,(0,true),(7,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route2 [(false,(0,true),(3,true))]) (correct2 route2 [(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(1,true),(3,true))]) (correct1 route0 [(false,(1,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route4 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(6,false)),(false,(0,true),(9,true))]) (correct32 route4 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(6,false)),(false,(0,true),(9,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route1 []) (correct61 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route1 []) (correct31 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route2 []) (correct110 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route4 []) (correct27 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route6 []) (correct61 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route3 []) (correct27 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 []) (correct3 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))]) (correct26 route4 [(false,(1,true),(2,true)),(false,(0,false),(1,false)),(false,(0,true),(8,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_19766 : List (BitVec 256) := [w517,w572,w644,w680,w720,w778,w817,w880,w977]
private def c3_19766 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule27 route0 [],rule30 route4 [],rule35 route7 [],rule3 route2 [],rule2 route0 [],rule2 route1 [],rule3 route4 [],rule75 route7 [],rule69 route0 [],rule118 route7 [],rule292 route5 [],rule30 route0 [(false,(3,true),(0,true)),(false,(6,true),(3,true)),(false,(1,true),(0,true))],rule76 route4 [],rule30 route7 [(false,(5,true),(2,true)),(false,(4,true),(1,true)),(false,(1,true),(0,true))],rule26 route2 [(false,(4,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))],rule34 route4 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))],rule26 route3 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))],rule391 route4 [],rule26 route5 [],rule31 route1 [],rule26 route4 [],rule35 route3 [],rule26 route7 [],rule27 route7 [],rule32 route4 [],rule35 route0 [],rule3 route1 [],rule117 route7 [],rule69 route1 [],rule3 route7 [],rule3 route3 [],rule19 route7 [],rule20 route5 []]
private def m3_19766 : Array (List (BitVec 256)) := #[[w517,w572,w639,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w844,w880,w977],[w167,w517,w572,w644,w680,w720,w778,w880,w977],[w361,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w808,w880,w977],[w171,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w815,w880,w977],[w172,w517,w572,w644,w680,w720,w778,w880,w977]]
private def hs3_19766 : List (List Nat) := [[8267,8267,9296,301,557,301,45,557,9296,45,8267,301],[557,557,32942,9295,9295,33199,9295,9295,32942,557,557,33199],[557,557,8274,2605,2613,16755,565,2613,8274,557,557,16755],[557,557,16506,4653,4669,16763,573,4669,16506,557,557,16763],[557,557,2130,331,8267,331,75,8267,2130,75,557,331],[557,557,0,9295,9295,1,9295,9295,2,557,557,3],[557,557,2162,2418,24715,2419,2162,24715,2162,557,557,2419],[557,557,1198,1454,33453,1455,1198,33453,1198,557,557,1455],[301,301,32942,1325,9296,33456,9296,9296,32942,301,301,33456],[301,301,8274,2349,2357,8788,309,2357,8274,301,301,8788],[301,301,16506,4397,4413,33468,317,4413,16506,301,301,33468],[301,301,331,2642,9296,2644,331,9296,331,301,301,2644],[301,301,4,9296,9296,5,1072,9296,6,301,301,7],[301,301,2162,2674,24716,33516,2162,24716,2162,301,301,33516],[301,301,1198,4794,8,9,1198,9,1198,301,301,10],[8274,32942,8274,9302,34998,9302,8274,34998,8274,9302,32942,9302],[16506,32942,16506,17530,11,17534,16506,12,16506,16510,32942,17534],[331,32942,331,1355,13,14,331,15,331,32942,32942,16],[32942,32942,34,33456,33456,35,560,33456,36,560,32942,37],[2162,32942,2162,3186,49390,3190,2162,49390,2162,2166,32942,3190],[4282,17,4282,1198,32942,1198,174,32942,4282,174,18,1198],[8274,8274,16506,12370,12386,35010,8290,12386,16506,8274,8274,35010],[331,16498,331,2130,8274,2130,82,8274,331,82,16498,2130],[8274,8274,19,9302,9302,20,9302,9302,21,8274,8274,22],[4218,8274,4218,2162,16498,2162,114,16498,4218,114,8274,2162],[1198,8274,1198,3246,49394,3254,1198,49394,1198,1206,8274,3254],[331,16506,331,4427,24730,4443,331,24730,331,347,16506,4443],[16506,16506,23,24730,24730,24,24730,24730,25,16506,16506,26],[2162,32954,2162,4218,16506,4218,122,16506,2162,122,32954,4218],[1198,16506,1198,4282,32954,4282,186,32954,1198,186,16506,4282],[331,331,7,33484,33484,6,1359,33484,27,331,331,4],[331,331,2162,12410,28,13470,2162,29,2162,331,331,13470],[331,331,1198,9422,33484,9422,1198,33484,1198,331,331,9422],[2162,38,2162,13470,30,13470,620,31,2162,620,39,13470],[1198,40,1198,9422,32,9422,1198,33,1198,4796,41,9422],[1198,2162,1198,17582,33516,17646,1198,33516,1198,1262,2162,17646]]
theorem node3_19766 [Assumptions] : Blocked tgt 9 s3_19766 := by
  refine PetersenFastLocal.close (cut := c3_19766) (more := m3_19766) (hs := hs3_19766) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route0 []) (correct27 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 []) (correct30 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route7 []) (correct35 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 []) (correct3 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 []) (correct3 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route7 []) (correct75 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule118 route7 []) (correct118 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule292 route5 []) (correct292 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(3,true),(0,true)),(false,(6,true),(3,true)),(false,(1,true),(0,true))]) (correct30 route0 [(false,(3,true),(0,true)),(false,(6,true),(3,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route4 []) (correct76 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 [(false,(5,true),(2,true)),(false,(4,true),(1,true)),(false,(1,true),(0,true))]) (correct30 route7 [(false,(5,true),(2,true)),(false,(4,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(4,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))]) (correct26 route2 [(false,(4,true),(2,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route4 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))]) (correct34 route4 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))]) (correct26 route3 [(false,(6,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule391 route4 []) (correct391 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule31 route1 []) (correct31 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 []) (correct26 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route3 []) (correct35 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route7 []) (correct27 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route4 []) (correct32 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 []) (correct3 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route7 []) (correct117 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route1 []) (correct69 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route7 []) (correct3 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route3 []) (correct3 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule19 route7 []) (correct19 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule20 route5 []) (correct20 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w639,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_426 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w844,w880,w977]) (Orbits1020Cost12.b4_2905 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w167,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_13 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w361,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) (Orbits1020Cost12.b4_1793 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w808,w880,w977]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_485 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w171,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_11 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w815,w880,w977]) (PetersenAdjacentSymmetry.via3 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_485 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w172,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_11 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
def s3_19768 : List (BitVec 256) := [w517,w572,w644,w680,w720,w778,w818,w880,w977,w1067]
private def c3_19768 : Array (PetersenProjectedRule.Rule 256) := #[rule116 route5 [],rule76 route2 [],rule41 route7 [],rule108 route5 [],rule23 route7 [],rule578 route0 [],rule69 route0 [],rule2 route1 [],rule39 route7 []]
private def m3_19768 : Array (List (BitVec 256)) := #[[w517,w572,w644,w680,w720,w778,w880,w977,w1068]]
private def hs3_19768 : List (List Nat) := [[8235,525,525,8235],[525,9263,9263,525],[525,2573,533,525],[525,4621,541,525],[525,299,43,43],[8235,525,525,8235],[525,3414,3158,525],[525,1422,1166,525],[525,9263,9263,525],[24684,9264,9264,24684],[8242,8756,8242,8756],[9264,13360,9280,9264],[299,2612,299,2612],[269,269],[3158,24684,3158,9264],[1166,0,1166,9264],[1,9264,9264,2],[8242,9270,8242,9270],[16474,17498,16474,16478],[299,3,299,32910],[32910,33424,33424,32910],[3154,3154,32974,3158],[5274,1166,16590,1166],[528,528],[8242,12338,8258,8242],[299,2098,50,50],[8242,8756,8756,8242],[5214,3158,1110,1110],[1166,3214,1166,1174],[8242,9270,9270,8242],[299,4395,299,315],[16474,24698,24698,16474],[3158,5214,1118,1118],[1166,5262,1166,1182],[4,16474,16474,5],[299,2612,1327,299],[299,13438,3158,299],[299,9390,1166,299],[299,33452,33452,299],[3158,13438,3158,13438],[1166,9390,1166,9390],[6,9,7,8],[1166,17550,1166,1230],[588,588],[1166,4250]]
theorem node3_19768 [Assumptions] : Blocked tgt 9 s3_19768 := by
  refine PetersenFastLocal.close (cut := c3_19768) (more := m3_19768) (hs := hs3_19768) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route5 []) (correct116 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route2 []) (correct76 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route7 []) (correct41 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route5 []) (correct108 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule23 route7 []) (correct23 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule578 route0 []) (correct578 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route7 []) (correct39 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1068]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b3_3355 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.nil
end MC010Cert
