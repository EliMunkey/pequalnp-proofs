import EightReducedCX010D0G0
import HMC010Sym
import HMC010W1
import HMC010W2
import HMC010W3
import PetersenLocalChildren
import PetersenSymmetry
import Q1020K12Closing
import ThetaClosing
import first8.FirstInputs
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
open MC010Cert
namespace PetersenLiveReduced.CX010
set_option maxRecDepth 300000
set_option maxHeartbeats 0
set_option linter.concreteInstances false
theorem reject0_1_0 [Assumptions] : NoAtMost (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :: inputs 8) tgt 12 := by
  change NoAtMost [w625,w517,w572,w644,w680,w720,w778,w880,w977] tgt 12
  apply PetersenFirstInputs.root (by decide) (by intro a h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h;rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e;have v := congrFun e (3:Fin 256);change true=false at v;contradiction
    · intro e;have v := congrFun e (0:Fin 256);change false=true at v;contradiction)
    #[[w517,w572,w644,w680,w720,w778,w880,w977],[w625,w517,w572,w644,w680,w720,w778,w880,w977]] [5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,82,8,82,35,82,82,82,5,82,68,82,35,82,82,82,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,134,8,134,35,134,134,134,5,162,68,162,35,162,162,162,5,74,8,74,74,74,74,74,5,74,68,74,74,74,74,74,5,82,8,82,82,82,82,82,5,82,68,82,82,82,82,82,5,74,8,74,74,74,74,74,5,74,68,74,74,74,74,74,5,134,8,134,134,134,134,134,5,261,68,261,517,517,580,580,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,134,8,134,35,134,134,134,5,146,146,146,35,146,146,146,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,134,8,134,35,134,134,134,5,162,162,162,35,162,162,162,5,134,8,134,134,134,134,134,5,146,146,146,146,146,146,146,5,134,8,134,134,134,134,134,5,146,146,146,146,146,146,146,5,134,8,134,134,134,134,134,5,261,261,261,517,517,1158,1158,5,134,8,134,134,134,134,134,5,261,261,261,517,517,1158,1158,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,82,8,82,35,82,82,82,5,82,68,82,35,82,82,82,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,261,8,261,35,291,291,291,5,261,68,261,35,291,291,291,5,74,8,74,74,74,74,74,5,74,68,74,74,74,74,74,5,82,8,82,82,82,82,82,5,82,68,82,82,82,82,82,5,74,8,74,74,74,74,74,5,74,68,74,74,74,74,74,5,261,8,261,517,517,520,520,5,261,68,261,517,517,580,580,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,261,8,261,35,291,291,291,5,261,261,261,35,291,291,291,5,42,8,42,35,42,42,42,5,42,42,42,35,42,42,42,5,261,8,261,35,291,291,291,5,261,261,261,35,291,291,291,5,261,8,261,517,517,520,520,5,261,261,261,517,517,8234,8234,5,261,8,261,517,517,520,520,5,261,261,261,517,517,16466,16466,5,261,8,261,517,517,520,520,5,261,261,261,517,517,8234,8234,5,261,8,261,517,517,520,520,5,261,261,261,517,517,0,1] (by decide +kernel)
  change ∀ v∈[[w517,w572,w644,w680,w720,w778,w880,w977],[w625,w517,w572,w644,w680,w720,w778,w880,w977]], Blocked tgt 12 v
  exact PetersenLocalChildren.push (P := Blocked tgt 12) (x := [w517,w572,w644,w680,w720,w778,w880,w977]) (Orbits1020Cost12.b0_0 ThetaCert.bound) <| PetersenLocalChildren.push (P := Blocked tgt 12) (x := [w625,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenFirstInputs.reorder (by decide +kernel) PetersenLiveReduced.CX010.r0_0) PetersenLocalChildren.nil
#print axioms reject0_1_0
end PetersenLiveReduced.CX010
