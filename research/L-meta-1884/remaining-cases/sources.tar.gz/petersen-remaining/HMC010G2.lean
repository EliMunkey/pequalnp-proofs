import HEX010G1
import HEX010G2
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
def r28 (i : Fin 128) : Fin 256 := (#[0,32,128,160,16,48,144,176,64,96,192,224,80,112,208,240,8,40,136,168,24,56,152,184,72,104,200,232,88,120,216,248,1,33,129,161,17,49,145,177,65,97,193,225,81,113,209,241,9,41,137,169,25,57,153,185,73,105,201,233,89,121,217,249,4,36,132,164,20,52,148,180,68,100,196,228,84,116,212,244,12,44,140,172,28,60,156,188,76,108,204,236,92,124,220,252,5,37,133,165,21,53,149,181,69,101,197,229,85,117,213,245,13,45,141,173,29,61,157,189,77,109,205,237,93,125,221,253] : Array (Fin 256))[i.val]?.getD 0
def stages28 : List PetersenWordProjection.Stage := [⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x1f,0xaaaaaaaa00000000aaaaaaaa00000000aaaaaaaa00000000aaaaaaaa,0x5555555500000000555555550000000055555555000000005555555500000000,0xaaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555⟩]
theorem rowOk28 : PetersenWordProjection.check stages28 0 r28 = true := by decide +kernel
theorem hot28 : forcedConst r28 tgt = false := by decide +kernel
theorem match28 : PetersenPackedPin.project r28 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
abbrev r29 := EX010Cert.r29
abbrev stages29 := EX010Cert.stages29
theorem rowOk29 : PetersenWordProjection.check stages29 128 r29 = true := EX010Cert.rowOk29
theorem hot29 : forcedConst r29 tgt = false := EX010Cert.hot29
theorem match29 : PetersenPackedPin.project r29 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match29
abbrev r30 := EX010Cert.r30
abbrev stages30 := EX010Cert.stages30
theorem rowOk30 : PetersenWordProjection.check stages30 0 r30 = true := EX010Cert.rowOk30
theorem hot30 : forcedConst r30 tgt = false := EX010Cert.hot30
theorem match30 : PetersenPackedPin.project r30 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match30
abbrev r31 := EX010Cert.r31
abbrev stages31 := EX010Cert.stages31
theorem rowOk31 : PetersenWordProjection.check stages31 128 r31 = true := EX010Cert.rowOk31
theorem hot31 : forcedConst r31 tgt = false := EX010Cert.hot31
theorem match31 : PetersenPackedPin.project r31 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match31
abbrev r32 := EX010Cert.r32
abbrev stages32 := EX010Cert.stages32
theorem rowOk32 : PetersenWordProjection.check stages32 0 r32 = true := EX010Cert.rowOk32
theorem hot32 : forcedConst r32 tgt = false := EX010Cert.hot32
theorem match32 : PetersenPackedPin.project r32 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match32
abbrev r33 := EX010Cert.r33
abbrev stages33 := EX010Cert.stages33
theorem rowOk33 : PetersenWordProjection.check stages33 128 r33 = true := EX010Cert.rowOk33
theorem hot33 : forcedConst r33 tgt = false := EX010Cert.hot33
theorem match33 : PetersenPackedPin.project r33 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match33
abbrev r34 := EX010Cert.r34
abbrev stages34 := EX010Cert.stages34
theorem rowOk34 : PetersenWordProjection.check stages34 0 r34 = true := EX010Cert.rowOk34
theorem hot34 : forcedConst r34 tgt = false := EX010Cert.hot34
theorem match34 : PetersenPackedPin.project r34 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match34
abbrev r35 := EX010Cert.r35
abbrev stages35 := EX010Cert.stages35
theorem rowOk35 : PetersenWordProjection.check stages35 128 r35 = true := EX010Cert.rowOk35
theorem hot35 : forcedConst r35 tgt = false := EX010Cert.hot35
theorem match35 : PetersenPackedPin.project r35 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match35
def r36 (i : Fin 128) : Fin 256 := (#[0,2,64,66,16,18,80,82,128,130,192,194,144,146,208,210,4,6,68,70,20,22,84,86,132,134,196,198,148,150,212,214,1,3,65,67,17,19,81,83,129,131,193,195,145,147,209,211,5,7,69,71,21,23,85,87,133,135,197,199,149,151,213,215,8,10,72,74,24,26,88,90,136,138,200,202,152,154,216,218,12,14,76,78,28,30,92,94,140,142,204,206,156,158,220,222,9,11,73,75,25,27,89,91,137,139,201,203,153,155,217,219,13,15,77,79,29,31,93,95,141,143,205,207,157,159,221,223] : Array (Fin 256))[i.val]?.getD 0
def stages36 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x78,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00000000000000000000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff0000ff00ff00ff00ff00ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk36 : PetersenWordProjection.check stages36 0 r36 = true := by decide +kernel
theorem hot36 : forcedConst r36 tgt = false := by decide +kernel
theorem match36 : PetersenPackedPin.project r36 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
abbrev r37 := EX010Cert.r37
abbrev stages37 := EX010Cert.stages37
theorem rowOk37 : PetersenWordProjection.check stages37 128 r37 = true := EX010Cert.rowOk37
theorem hot37 : forcedConst r37 tgt = false := EX010Cert.hot37
theorem match37 : PetersenPackedPin.project r37 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match37
abbrev r38 := EX010Cert.r38
abbrev stages38 := EX010Cert.stages38
theorem rowOk38 : PetersenWordProjection.check stages38 0 r38 = true := EX010Cert.rowOk38
theorem hot38 : forcedConst r38 tgt = false := EX010Cert.hot38
theorem match38 : PetersenPackedPin.project r38 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match38
abbrev r39 := EX010Cert.r39
abbrev stages39 := EX010Cert.stages39
theorem rowOk39 : PetersenWordProjection.check stages39 128 r39 = true := EX010Cert.rowOk39
theorem hot39 : forcedConst r39 tgt = false := EX010Cert.hot39
theorem match39 : PetersenPackedPin.project r39 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match39
end MC010Cert
