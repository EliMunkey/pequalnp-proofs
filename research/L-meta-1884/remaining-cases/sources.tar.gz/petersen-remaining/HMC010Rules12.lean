import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010G4
import HMC010G7
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule538 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xffffaaaa :: i5) p
theorem correct538 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule538 s p) tgt := by
  have small : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h24
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule539 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages15 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct539 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule539 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r15 tgt) 7 := by rw [match15]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk15 s small hot15 p hit
def rule540 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xf000f0 :: i5) p
theorem correct540 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule540 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h8
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule541 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages5 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct541 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule541 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r5 tgt) 7 := by rw [match5]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk5 s small hot5 p hit
def rule542 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xf0f00000f0f00000f0f00000f0f00000 :: i7) p
theorem correct542 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule542 s p) tgt := by
  have small : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h59
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule543 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xffffff00 :: i5) p
theorem correct543 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule543 s p) tgt := by
  have small : NoAtMost (0xffffff00 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h25
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule544 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0x33003300 :: i5) p
theorem correct544 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule544 s p) tgt := by
  have small : NoAtMost (0x33003300 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h15
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule545 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages228 s.steps 64 4 (0xf000f0 :: i5) p
theorem correct545 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule545 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r228 tgt) 4 := by rw [match228]; exact Assumptions.h26
  intro d L hit
  exact PetersenRoutedPin.quick rowOk228 s small hot228 p hit
def rule546 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xff00 :: i5) p
theorem correct546 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule546 s p) tgt := by
  have small : NoAtMost (0xff00 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h5
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule547 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0x55005500 :: i5) p
theorem correct547 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule547 s p) tgt := by
  have small : NoAtMost (0x55005500 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h18
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule548 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages75 s.steps 64 5 (0xf000f000f000f0 :: i6) p
theorem correct548 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule548 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r75 tgt) 5 := by rw [match75]; exact Assumptions.h40
  intro d L hit
  exact PetersenRoutedPin.quick rowOk75 s small hot75 p hit
def rule549 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xf0f0f0f000000000f0f0f0f000000000 :: i7) p
theorem correct549 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule549 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f000000000f0f0f0f000000000 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h60
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule550 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages6 s.steps 0 7 (0xaaaa0000aaaa0000 :: i6) p
theorem correct550 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule550 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000 :: i6) (PetersenPackedPin.project r6 tgt) 7 := by rw [match6]; exact Assumptions.h37
  intro d L hit
  exact PetersenRoutedPin.quick rowOk6 s small hot6 p hit
def rule551 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages4 s.steps 0 7 (0xaaaa0000aaaa0000 :: i6) p
theorem correct551 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule551 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000 :: i6) (PetersenPackedPin.project r4 tgt) 7 := by rw [match4]; exact Assumptions.h37
  intro d L hit
  exact PetersenRoutedPin.quick rowOk4 s small hot4 p hit
def rule552 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages28 s.steps 0 8 (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) p
theorem correct552 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule552 s p) tgt := by
  have small : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) (PetersenPackedPin.project r28 tgt) 8 := by rw [match28]; exact Assumptions.h44
  intro d L hit
  exact PetersenRoutedPin.quick rowOk28 s small hot28 p hit
def rule553 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xffffff00 :: i5) p
theorem correct553 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule553 s p) tgt := by
  have small : NoAtMost (0xffffff00 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h25
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule554 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xf0f0f0f000000000f0f0f0f0 :: i7) p
theorem correct554 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule554 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f000000000f0f0f0f0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h49
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule555 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xfcfcfcfc :: i5) p
theorem correct555 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule555 s p) tgt := by
  have small : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h22
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule556 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages12 s.steps 0 7 (0x8888888888888888 :: i6) p
theorem correct556 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule556 s p) tgt := by
  have small : NoAtMost (0x8888888888888888 :: i6) (PetersenPackedPin.project r12 tgt) 7 := by rw [match12]; exact Assumptions.h36
  intro d L hit
  exact PetersenRoutedPin.quick rowOk12 s small hot12 p hit
def rule557 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xf0f00000f0f00000f0f00000f0f0 :: i7) p
theorem correct557 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule557 s p) tgt := by
  have small : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h51
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
end MC010Cert
