import PetersenProjectedRule
import ThetaClosing
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem minor191 : NoAtMost (inputs 7) (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := ThetaCert.bound
end Full18
