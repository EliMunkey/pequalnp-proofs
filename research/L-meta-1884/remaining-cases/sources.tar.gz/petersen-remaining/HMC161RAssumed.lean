import HMC161RHyp
import HMC161RThetaRoutes
import HMC161RLowerPack0
import HMC161RLowerPack1
import HMC161RLowerPack2
import HMC161RLowerPack3
import HMC161RLowerPack4
import HMC161RLowerPack5
import HMC161RLowerPack6
import HMC161RLowerPack7
import HMC161RLowerPack8
import HMC161RLowerPack9
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
instance proven : Assumptions where
  h0 := by rw [rawInput4_eq]; exact hold0_0
  h1 := by rw [rawInput5_eq]; exact hold1_0
  h2 := by rw [rawInput5_eq]; exact hold2_0
  h3 := by rw [rawInput5_eq]; exact hold3_0
  h4 := by rw [rawInput5_eq]; exact hold4_0
  h5 := by rw [rawInput5_eq]; exact hold5_0
  h6 := by rw [rawInput5_eq]; exact hold6_0
  h7 := by rw [rawInput5_eq]; exact hold7_0
  h8 := by rw [rawInput5_eq]; exact hold8_0
  h9 := by rw [rawInput5_eq]; exact hold9_0
  h10 := by rw [rawInput5_eq]; exact hold10_0
  h11 := by rw [rawInput5_eq]; exact hold11_0
  h12 := by rw [rawInput5_eq]; exact hold12_0
  h13 := by rw [rawInput5_eq]; exact hold13_0
  h14 := by rw [rawInput5_eq]; exact hold14_0
  h15 := by rw [rawInput5_eq]; exact hold15_0
  h16 := by rw [rawInput5_eq]; exact hold16_0
  h17 := by rw [rawInput5_eq]; exact hold17_0
  h18 := by rw [rawInput5_eq]; exact hold18_0
  h19 := by rw [rawInput5_eq]; exact hold19_0
  h20 := by rw [rawInput5_eq]; exact hold20_0
  h21 := by rw [rawInput5_eq]; exact hold21_0
  h22 := by rw [rawInput5_eq]; exact hold22_0
  h23 := by rw [rawInput5_eq]; exact hold23_0
  h24 := by rw [rawInput5_eq]; exact hold24_1
  h25 := by rw [rawInput5_eq]; exact hold25_1
  h26 := by rw [rawInput6_eq]; exact hold26_0
  h27 := by rw [rawInput6_eq]; exact hold27_0
  h28 := by rw [rawInput6_eq]; exact hold28_0
  h29 := by rw [rawInput6_eq]; exact hold29_1
  h30 := by rw [rawInput6_eq]; exact hold30_2
  h31 := by rw [rawInput6_eq]; exact hold31_2
  h32 := by rw [rawInput7_eq]; exact hold32_0
  h33 := by rw [rawInput7_eq]; exact hold33_0
  h34 := by rw [rawInput7_eq]; exact hold34_0
  h35 := by rw [rawInput7_eq]; exact hold35_0
  h36 := by rw [rawInput7_eq]; exact hold36_0
  h37 := by rw [rawInput7_eq]; exact hold37_0
  h38 := by rw [rawInput7_eq]; exact hold38_0
  h39 := by rw [rawInput7_eq]; exact hold39_0
  h40 := by rw [rawInput7_eq]; exact hold40_0
  h41 := by rw [rawInput7_eq]; exact hold41_0
  h42 := by rw [rawInput7_eq]; exact hold42_0
  h43 := by rw [rawInput7_eq]; exact hold43_0
  h44 := by rw [rawInput7_eq]; exact hold44_0
  h45 := by rw [rawInput7_eq]; exact hold45_0
  h46 := by rw [rawInput7_eq]; exact hold46_0
  h47 := by rw [rawInput7_eq]; exact hold47_0
  h48 := by rw [rawInput7_eq]; exact hold48_0
  h49 := by rw [rawInput7_eq]; exact hold49_0
  h50 := by rw [rawInput7_eq]; exact hold50_3
  h51 := by rw [rawInput7_eq]; exact hold51_3
end MC161RCert
