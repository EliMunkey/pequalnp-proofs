import HEX010G4
import HEX010G5
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r110 := EX010Cert.r110
abbrev stages110 := EX010Cert.stages110
theorem rowOk110 : PetersenWordProjection.check stages110 64 r110 = true := EX010Cert.rowOk110
theorem hot110 : forcedConst r110 tgt = false := EX010Cert.hot110
theorem match110 : PetersenPackedPin.project r110 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match110
abbrev r111 := EX010Cert.r111
abbrev stages111 := EX010Cert.stages111
theorem rowOk111 : PetersenWordProjection.check stages111 0 r111 = true := EX010Cert.rowOk111
theorem hot111 : forcedConst r111 tgt = false := EX010Cert.hot111
theorem match111 : PetersenPackedPin.project r111 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match111
def r115 (i : Fin 64) : Fin 256 := (#[0,2,64,66,8,10,72,74,1,3,65,67,9,11,73,75,4,6,68,70,12,14,76,78,5,7,69,71,13,15,77,79,16,18,80,82,24,26,88,90,17,19,81,83,25,27,89,91,20,22,84,86,28,30,92,94,21,23,85,87,29,31,93,95] : Array (Fin 256))[i.val]?.getD 0
def stages115 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0x4,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f0,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f00,0xf00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk115 : PetersenWordProjection.check stages115 0 r115 = true := by decide +kernel
theorem hot115 : forcedConst r115 tgt = false := by decide +kernel
theorem match115 : PetersenPackedPin.project r115 tgt = (0xeeeeeecceaeaeac8 : BitVec 64) := by decide +kernel
abbrev r116 := EX010Cert.r116
abbrev stages116 := EX010Cert.stages116
theorem rowOk116 : PetersenWordProjection.check stages116 128 r116 = true := EX010Cert.rowOk116
theorem hot116 : forcedConst r116 tgt = false := EX010Cert.hot116
theorem match116 : PetersenPackedPin.project r116 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match116
abbrev r117 := EX010Cert.r117
abbrev stages117 := EX010Cert.stages117
theorem rowOk117 : PetersenWordProjection.check stages117 64 r117 = true := EX010Cert.rowOk117
theorem hot117 : forcedConst r117 tgt = false := EX010Cert.hot117
theorem match117 : PetersenPackedPin.project r117 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match117
abbrev r118 := EX010Cert.r118
abbrev stages118 := EX010Cert.stages118
theorem rowOk118 : PetersenWordProjection.check stages118 0 r118 = true := EX010Cert.rowOk118
theorem hot118 : forcedConst r118 tgt = false := EX010Cert.hot118
theorem match118 : PetersenPackedPin.project r118 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match118
abbrev r122 := EX010Cert.r122
abbrev stages122 := EX010Cert.stages122
theorem rowOk122 : PetersenWordProjection.check stages122 128 r122 = true := EX010Cert.rowOk122
theorem hot122 : forcedConst r122 tgt = false := EX010Cert.hot122
theorem match122 : PetersenPackedPin.project r122 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match122
abbrev r123 := EX010Cert.r123
abbrev stages123 := EX010Cert.stages123
theorem rowOk123 : PetersenWordProjection.check stages123 64 r123 = true := EX010Cert.rowOk123
theorem hot123 : forcedConst r123 tgt = false := EX010Cert.hot123
theorem match123 : PetersenPackedPin.project r123 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match123
abbrev r129 := EX010Cert.r129
abbrev stages129 := EX010Cert.stages129
theorem rowOk129 : PetersenWordProjection.check stages129 32 r129 = true := EX010Cert.rowOk129
theorem hot129 : forcedConst r129 tgt = false := EX010Cert.hot129
theorem match129 : PetersenPackedPin.project r129 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match129
abbrev r140 := EX010Cert.r140
abbrev stages140 := EX010Cert.stages140
theorem rowOk140 : PetersenWordProjection.check stages140 32 r140 = true := EX010Cert.rowOk140
theorem hot140 : forcedConst r140 tgt = false := EX010Cert.hot140
theorem match140 : PetersenPackedPin.project r140 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match140
abbrev r143 := EX010Cert.r143
abbrev stages143 := EX010Cert.stages143
theorem rowOk143 : PetersenWordProjection.check stages143 64 r143 = true := EX010Cert.rowOk143
theorem hot143 : forcedConst r143 tgt = false := EX010Cert.hot143
theorem match143 : PetersenPackedPin.project r143 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match143
abbrev r146 := EX010Cert.r146
abbrev stages146 := EX010Cert.stages146
theorem rowOk146 : PetersenWordProjection.check stages146 0 r146 = true := EX010Cert.rowOk146
theorem hot146 : forcedConst r146 tgt = false := EX010Cert.hot146
theorem match146 : PetersenPackedPin.project r146 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match146
end MC161RCert
