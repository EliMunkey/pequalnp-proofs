import M63StartLabeled
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveaug63G0x2222222222222222 : NoAtMost (0x2222222222222222 :: inputs 6) PetersenSmallStarts.M63.tgt 7 := PetersenSmallStarts.M63.all_forbidden 0x2222222222222222 (by decide +kernel)
#print axioms theFirstLiveaug63G0x2222222222222222
end PetersenLive8
