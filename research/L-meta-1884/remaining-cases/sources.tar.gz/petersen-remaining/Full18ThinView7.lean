import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP140 : steps140.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES140 : PetersenWordProjection.projectFast steps140 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG140 : PetersenWordProjection.projectFast steps140 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP141 : steps141.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES141 : PetersenWordProjection.projectFast steps141 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG141 : PetersenWordProjection.projectFast steps141 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP142 : steps142.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES142 : PetersenWordProjection.projectFast steps142 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG142 : PetersenWordProjection.projectFast steps142 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP145 : steps145.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES145 : PetersenWordProjection.projectFast steps145 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG145 : PetersenWordProjection.projectFast steps145 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP146 : steps146.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES146 : PetersenWordProjection.projectFast steps146 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG146 : PetersenWordProjection.projectFast steps146 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP147 : steps147.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES147 : PetersenWordProjection.projectFast steps147 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG147 : PetersenWordProjection.projectFast steps147 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP149 : steps149.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES149 : PetersenWordProjection.projectFast steps149 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG149 : PetersenWordProjection.projectFast steps149 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP150 : steps150.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES150 : PetersenWordProjection.projectFast steps150 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG150 : PetersenWordProjection.projectFast steps150 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP151 : steps151.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES151 : PetersenWordProjection.projectFast steps151 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG151 : PetersenWordProjection.projectFast steps151 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP153 : steps153.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES153 : PetersenWordProjection.projectFast steps153 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG153 : PetersenWordProjection.projectFast steps153 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP154 : steps154.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES154 : PetersenWordProjection.projectFast steps154 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG154 : PetersenWordProjection.projectFast steps154 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP155 : steps155.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES155 : PetersenWordProjection.projectFast steps155 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG155 : PetersenWordProjection.projectFast steps155 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP156 : steps156.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES156 : PetersenWordProjection.projectFast steps156 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG156 : PetersenWordProjection.projectFast steps156 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP157 : steps157.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES157 : PetersenWordProjection.projectFast steps157 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG157 : PetersenWordProjection.projectFast steps157 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP158 : steps158.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES158 : PetersenWordProjection.projectFast steps158 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG158 : PetersenWordProjection.projectFast steps158 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP159 : steps159.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES159 : PetersenWordProjection.projectFast steps159 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG159 : PetersenWordProjection.projectFast steps159 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
end Full18
