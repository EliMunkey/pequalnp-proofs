import Full18ThinRules3
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot178493
import PetersenProjectedRule
import Full18StepS112991
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient112991 (h : Needs) : Blocked Root17.tgt 13 live112991 := by
  apply stepS112991
  · change ∀ r ∈ [rule3052,rule3064,rule3251,rule3073], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live187547], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187547) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live187547) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.nil
end Full18
