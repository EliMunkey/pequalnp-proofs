import PetersenProjectedRule
import Full18Needs
import Full18Minor189
import Full18Minor191
import Full18Minor1022
import Full18Minor63
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
def thinBasis0 : List (BitVec 256) := [0xcccccccccccccccc0000000000000000cccccccccccccccc0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin0 (h : Needs) : NoAtMost thinBasis0 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis0 = (0xcccccccccccccccc0000000000000000cccccccccccccccc0000000000000000 : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_1_6_3
def thinBasis1 : List (BitVec 256) := [0x5555555555555555000000000000000055555555555555550000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin1 (h : Needs) : NoAtMost thinBasis1 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis1 = (0x5555555555555555000000000000000055555555555555550000000000000000 : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_6_2
def thinBasis2 : List (BitVec 256) := [0xffffffffccccccccffffffffccccccccffffffffccccccccffffffffcccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin2 (h : Needs) : NoAtMost thinBasis2 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis2 = (0xffffffffccccccccffffffffccccccccffffffffccccccccffffffffcccccccc : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_1_5_0
def thinBasis3 : List (BitVec 128) := [0xaa00aa00aa00aa00aa00aa00aa00aa00,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin3 (h : Needs) : NoAtMost thinBasis3 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis3 = (0xaa00aa00aa00aa00aa00aa00aa00aa00 : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_3_3
def thinBasis4 : List (BitVec 256) := [0xffffffffffffffffccccccccccccccccffffffffffffffffcccccccccccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin4 (h : Needs) : NoAtMost thinBasis4 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis4 = (0xffffffffffffffffccccccccccccccccffffffffffffffffcccccccccccccccc : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_1_6_0
def thinBasis5 : List (BitVec 256) := [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin5 (h : Needs) : NoAtMost thinBasis5 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis5 = (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_1_0
def thinBasis6 : List (BitVec 256) := [0x5555000055550000555500005555000055550000555500005555000055550000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin6 (h : Needs) : NoAtMost thinBasis6 (0xfffffffffffffffcfffffffffffff0f0ffffffccffffffccffeaffc0eaeac0c0 : BitVec 256) 11 := by
  have eq : thinBasis6 = (0x5555000055550000555500005555000055550000555500005555000055550000 : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1018_0_4_2
def thinBasis7 : List (BitVec 256) := [0xcccccccc00000000cccccccc00000000cccccccc00000000cccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin7 (h : Needs) : NoAtMost thinBasis7 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis7 = (0xcccccccc00000000cccccccc00000000cccccccc00000000cccccccc : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_1_5_1
def thinBasis8 : List (BitVec 128) := [0xffffffffff00ff00ffffffffff00ff00,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin8 (h : Needs) : NoAtMost thinBasis8 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis8 = (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_3_5_0
def thinBasis9 : List (BitVec 128) := [0xaaaa0000aaaa0000aaaa0000aaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin9 (h : Needs) : NoAtMost thinBasis9 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis9 = (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_4_1
def thinBasis10 : List (BitVec 128) := [0xffffaaaaffffaaaaffffaaaaffffaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin10 (h : Needs) : NoAtMost thinBasis10 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis10 = (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_4_0
def thinBasis11 : List (BitVec 128) := [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin11 (h : Needs) : NoAtMost thinBasis11 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis11 = (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_2_3
def thinBasis12 : List (BitVec 64) := [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000]
theorem baseThin12 (h : Needs) : NoAtMost thinBasis12 (0xfffffeccfaeafac0 : BitVec 64) 7 := by
  have eq : thinBasis12 = inputs 6 := by decide +kernel
  rw [eq]; exact minor189
def thinBasis13 : List (BitVec 256) := [0xffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin13 (h : Needs) : NoAtMost thinBasis13 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis13 = (0xffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_4_0
def thinBasis14 : List (BitVec 256) := [0x4444444444444444444444444444444444444444444444444444444444444444,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin14 (h : Needs) : NoAtMost thinBasis14 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis14 = (0x4444444444444444444444444444444444444444444444444444444444444444 : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_1_2
def thinBasis15 : List (BitVec 128) := [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin15 (h : Needs) : NoAtMost thinBasis15 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis15 = (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_2_1
def thinBasis16 : List (BitVec 256) := [0xcccccccccccccccc0000000000000000cccccccccccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin16 (h : Needs) : NoAtMost thinBasis16 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis16 = (0xcccccccccccccccc0000000000000000cccccccccccccccc : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_1_6_1
def thinBasis17 : List (BitVec 128) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin17 (h : Needs) : NoAtMost thinBasis17 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis17 = inputs 7 := by decide +kernel
  rw [eq]; exact minor191
def thinBasis18 : List (BitVec 64) := [0xeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000]
theorem baseThin18 (h : Needs) : NoAtMost thinBasis18 (0xfffffeccfaeafac0 : BitVec 64) 7 := by
  have eq : thinBasis18 = (0xeeeeeeeeeeeeeeee : BitVec 64) :: inputs 6 := by decide +kernel
  rw [eq]; exact h.g189_0_1_0
def thinBasis19 : List (BitVec 128) := [0xffffff00ffffff00ffffff00ffffff00,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin19 (h : Needs) : NoAtMost thinBasis19 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis19 = (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_3_4_0
def thinBasis20 : List (BitVec 128) := [0xaa00aa00aa00aa00aa00aa00aa00aa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
theorem baseThin20 (h : Needs) : NoAtMost thinBasis20 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) 10 := by
  have eq : thinBasis20 = (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) :: inputs 7 := by decide +kernel
  rw [eq]; exact h.g191_0_3_1
def thinBasis21 : List (BitVec 512) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000ffffffffffffffffffffffffffffffff00000000000000000000000000000000,0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff0000000000000000000000000000000000000000000000000000000000000000]
theorem baseThin21 (h : Needs) : NoAtMost thinBasis21 (0xfffffffffffffffffffffffffffffff8ffffffffffffffffffffffffffc8ffc8fffffffffffffcfcfffffffffffff8f8fffffeeefffffcccfaeafaeaf8c8f8c8 : BitVec 512) 14 := by
  have eq : thinBasis21 = inputs 9 := by decide +kernel
  rw [eq]; exact minor1022
def thinBasis22 : List (BitVec 64) := [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000]
theorem baseThin22 (h : Needs) : NoAtMost thinBasis22 (0xfffffeccfaeafac0 : BitVec 64) 7 := by
  have eq : thinBasis22 = (0x2222222222222222 : BitVec 64) :: inputs 6 := by decide +kernel
  rw [eq]; exact h.g189_0_1_1
def thinBasis23 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin23 (h : Needs) : NoAtMost thinBasis23 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis23 = (0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_6_1
def thinBasis24 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa0000000000000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem baseThin24 (h : Needs) : NoAtMost thinBasis24 (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) 12 := by
  have eq : thinBasis24 = (0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa0000000000000000 : BitVec 256) :: inputs 8 := by decide +kernel
  rw [eq]; exact h.g1020_0_6_3
def thinBasis25 : List (BitVec 64) := [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000]
theorem baseThin25 (h : Needs) : NoAtMost thinBasis25 (0xffeafaeaffeaf8c8 : BitVec 64) 7 := by
  have eq : thinBasis25 = inputs 6 := by decide +kernel
  rw [eq]; exact minor63
end Full18
