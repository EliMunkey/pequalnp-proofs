import PetersenProjectedRule
import PetersenComponentLifts
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem minor63 : NoAtMost (inputs 6) (0xffeafaeaffeaf8c8 : BitVec 64) 7 := PetersenGraphCosts.mask63_exact_lower
end Full18
