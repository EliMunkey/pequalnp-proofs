import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot17756
import Full18Quot17767
import Full18Quot18613
import Full18Quot18964
import Full18Quot19092
import Full18Quot19822
import Full18Quot19847
import Full18Quot19857
import Full18Quot20218
import Full18Quot20527
import PetersenProjectedRule
import Full18StepS469
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient469 (h : Needs) : Blocked Root17.tgt 15 live469 := by
  apply stepS469
  · change ∀ r ∈ [rule8022,rule3290,rule7459,rule5557,rule6082,rule8051,rule6109,rule6004,rule3250,rule7496,rule2956,rule7568,rule8000,rule3357,rule3375,rule3457,rule3471,rule6104,rule3479,rule3421,rule3924,rule3703,rule7443,rule6590,rule3768], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6109) (quickSound6109 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6004) (quickSound6004 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3250) (quickSound3250 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7496) (quickSound7496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2956) (quickSound2956 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7568) (quickSound7568 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3357) (quickSound3357 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3375) (quickSound3375 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3457) (quickSound3457 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3471) (quickSound3471 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6104) (quickSound6104 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3479) (quickSound3479 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3421) (quickSound3421 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3924) (quickSound3924 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3703) (quickSound3703 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3768) (quickSound3768 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22292,live21547,live21019,live18959,live19857,live19041,live18951,live18961,live19429,live18964], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22292) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym2] (L := live22292) (V := live19822) (by decide +kernel) (quotient19822 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21547) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym2,thinSym0] (L := live21547) (V := live19847) (by decide +kernel) (quotient19847 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21019) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live21019) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18959) (PetersenFastSymmetry.move [thinSym0] (L := live18959) (V := live17756) (by decide +kernel) (quotient17756 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19857) (quotient19857 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19041) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3] (L := live19041) (V := live20527) (by decide +kernel) (quotient20527 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18951) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym2,thinSym0] (L := live18951) (V := live17767) (by decide +kernel) (quotient17767 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18961) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live18961) (V := live18613) (by decide +kernel) (quotient18613 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19429) (PetersenFastSymmetry.move [thinSym3] (L := live19429) (V := live19092) (by decide +kernel) (quotient19092 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18964) (quotient18964 h) <|
      PetersenLocalChildren.nil
end Full18
