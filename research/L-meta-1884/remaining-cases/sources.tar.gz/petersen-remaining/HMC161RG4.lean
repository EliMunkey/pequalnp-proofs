import HEX010G3
import HEX010G4
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r84 := EX010Cert.r84
abbrev stages84 := EX010Cert.stages84
theorem rowOk84 : PetersenWordProjection.check stages84 64 r84 = true := EX010Cert.rowOk84
theorem hot84 : forcedConst r84 tgt = false := EX010Cert.hot84
theorem match84 : PetersenPackedPin.project r84 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match84
abbrev r92 := EX010Cert.r92
abbrev stages92 := EX010Cert.stages92
theorem rowOk92 : PetersenWordProjection.check stages92 128 r92 = true := EX010Cert.rowOk92
theorem hot92 : forcedConst r92 tgt = false := EX010Cert.hot92
theorem match92 : PetersenPackedPin.project r92 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match92
abbrev r93 := EX010Cert.r93
abbrev stages93 := EX010Cert.stages93
theorem rowOk93 : PetersenWordProjection.check stages93 64 r93 = true := EX010Cert.rowOk93
theorem hot93 : forcedConst r93 tgt = false := EX010Cert.hot93
theorem match93 : PetersenPackedPin.project r93 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match93
abbrev r94 := EX010Cert.r94
abbrev stages94 := EX010Cert.stages94
theorem rowOk94 : PetersenWordProjection.check stages94 128 r94 = true := EX010Cert.rowOk94
theorem hot94 : forcedConst r94 tgt = false := EX010Cert.hot94
theorem match94 : PetersenPackedPin.project r94 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match94
abbrev r95 := EX010Cert.r95
abbrev stages95 := EX010Cert.stages95
theorem rowOk95 : PetersenWordProjection.check stages95 64 r95 = true := EX010Cert.rowOk95
theorem hot95 : forcedConst r95 tgt = false := EX010Cert.hot95
theorem match95 : PetersenPackedPin.project r95 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match95
abbrev r97 := EX010Cert.r97
abbrev stages97 := EX010Cert.stages97
theorem rowOk97 : PetersenWordProjection.check stages97 128 r97 = true := EX010Cert.rowOk97
theorem hot97 : forcedConst r97 tgt = false := EX010Cert.hot97
theorem match97 : PetersenPackedPin.project r97 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match97
abbrev r98 := EX010Cert.r98
abbrev stages98 := EX010Cert.stages98
theorem rowOk98 : PetersenWordProjection.check stages98 64 r98 = true := EX010Cert.rowOk98
theorem hot98 : forcedConst r98 tgt = false := EX010Cert.hot98
theorem match98 : PetersenPackedPin.project r98 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match98
abbrev r99 := EX010Cert.r99
abbrev stages99 := EX010Cert.stages99
theorem rowOk99 : PetersenWordProjection.check stages99 128 r99 = true := EX010Cert.rowOk99
theorem hot99 : forcedConst r99 tgt = false := EX010Cert.hot99
theorem match99 : PetersenPackedPin.project r99 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match99
abbrev r100 := EX010Cert.r100
abbrev stages100 := EX010Cert.stages100
theorem rowOk100 : PetersenWordProjection.check stages100 64 r100 = true := EX010Cert.rowOk100
theorem hot100 : forcedConst r100 tgt = false := EX010Cert.hot100
theorem match100 : PetersenPackedPin.project r100 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match100
abbrev r107 := EX010Cert.r107
abbrev stages107 := EX010Cert.stages107
theorem rowOk107 : PetersenWordProjection.check stages107 128 r107 = true := EX010Cert.rowOk107
theorem hot107 : forcedConst r107 tgt = false := EX010Cert.hot107
theorem match107 : PetersenPackedPin.project r107 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match107
abbrev r108 := EX010Cert.r108
abbrev stages108 := EX010Cert.stages108
theorem rowOk108 : PetersenWordProjection.check stages108 64 r108 = true := EX010Cert.rowOk108
theorem hot108 : forcedConst r108 tgt = false := EX010Cert.hot108
theorem match108 : PetersenPackedPin.project r108 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match108
abbrev r109 := EX010Cert.r109
abbrev stages109 := EX010Cert.stages109
theorem rowOk109 : PetersenWordProjection.check stages109 128 r109 = true := EX010Cert.rowOk109
theorem hot109 : forcedConst r109 tgt = false := EX010Cert.hot109
theorem match109 : PetersenPackedPin.project r109 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match109
end MC161RCert
