import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules15
import Full18ThinRules16
import PetersenProjectedRule
import Full18StepS41821
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient41821 (h : Needs) : Blocked Root17.tgt 13 live41821 := by
  apply stepS41821
  · change ∀ r ∈ [rule3251,rule3064,rule3255,rule3070,rule3254,rule3052,rule5944,rule6590,rule5639,rule6582,rule3261,rule8071,rule5615,rule4344,rule3636,rule5651,rule9238], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3254) (quickSound3254 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5639) (quickSound5639 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6582) (quickSound6582 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8071) (quickSound8071 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5615) (quickSound5615 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4344) (quickSound4344 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3636) (quickSound3636 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5651) (quickSound5651 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule9238) (quickSound9238 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [], Blocked Root17.tgt 12 s
    exact PetersenLocalChildren.nil
end Full18
