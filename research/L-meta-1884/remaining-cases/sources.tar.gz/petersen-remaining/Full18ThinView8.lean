import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP160 : steps160.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES160 : PetersenWordProjection.projectFast steps160 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG160 : PetersenWordProjection.projectFast steps160 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP161 : steps161.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES161 : PetersenWordProjection.projectFast steps161 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG161 : PetersenWordProjection.projectFast steps161 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP162 : steps162.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES162 : PetersenWordProjection.projectFast steps162 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG162 : PetersenWordProjection.projectFast steps162 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP163 : steps163.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES163 : PetersenWordProjection.projectFast steps163 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG163 : PetersenWordProjection.projectFast steps163 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP164 : steps164.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES164 : PetersenWordProjection.projectFast steps164 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG164 : PetersenWordProjection.projectFast steps164 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP165 : steps165.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES165 : PetersenWordProjection.projectFast steps165 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG165 : PetersenWordProjection.projectFast steps165 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP166 : steps166.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES166 : PetersenWordProjection.projectFast steps166 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG166 : PetersenWordProjection.projectFast steps166 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP167 : steps167.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES167 : PetersenWordProjection.projectFast steps167 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG167 : PetersenWordProjection.projectFast steps167 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP168 : steps168.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES168 : PetersenWordProjection.projectFast steps168 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG168 : PetersenWordProjection.projectFast steps168 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP169 : steps169.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES169 : PetersenWordProjection.projectFast steps169 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG169 : PetersenWordProjection.projectFast steps169 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP170 : steps170.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES170 : PetersenWordProjection.projectFast steps170 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG170 : PetersenWordProjection.projectFast steps170 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP171 : steps171.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES171 : PetersenWordProjection.projectFast steps171 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG171 : PetersenWordProjection.projectFast steps171 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP172 : steps172.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES172 : PetersenWordProjection.projectFast steps172 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG172 : PetersenWordProjection.projectFast steps172 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP174 : steps174.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES174 : PetersenWordProjection.projectFast steps174 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG174 : PetersenWordProjection.projectFast steps174 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP175 : steps175.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES175 : PetersenWordProjection.projectFast steps175 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG175 : PetersenWordProjection.projectFast steps175 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP176 : steps176.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES176 : PetersenWordProjection.projectFast steps176 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG176 : PetersenWordProjection.projectFast steps176 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP177 : steps177.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES177 : PetersenWordProjection.projectFast steps177 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG177 : PetersenWordProjection.projectFast steps177 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP178 : steps178.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES178 : PetersenWordProjection.projectFast steps178 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG178 : PetersenWordProjection.projectFast steps178 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP179 : steps179.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES179 : PetersenWordProjection.projectFast steps179 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG179 : PetersenWordProjection.projectFast steps179 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
end Full18
