import HMC161RHyp
import HMC161RThetaRoutes
import M191StartPreferredCheckedF0X2Z3
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold44_0 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_2_3
end MC161RCert
