import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP80 : steps80.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES80 : PetersenWordProjection.projectFast steps80 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG80 : PetersenWordProjection.projectFast steps80 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP82 : steps82.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES82 : PetersenWordProjection.projectFast steps82 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG82 : PetersenWordProjection.projectFast steps82 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP83 : steps83.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES83 : PetersenWordProjection.projectFast steps83 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG83 : PetersenWordProjection.projectFast steps83 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP84 : steps84.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES84 : PetersenWordProjection.projectFast steps84 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG84 : PetersenWordProjection.projectFast steps84 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP85 : steps85.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES85 : PetersenWordProjection.projectFast steps85 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG85 : PetersenWordProjection.projectFast steps85 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff0f0ffffffccffffffccffeaffc0eaeac0c0 : BitVec 256) := by decide +kernel
theorem SEP86 : steps86.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES86 : PetersenWordProjection.projectFast steps86 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG86 : PetersenWordProjection.projectFast steps86 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP87 : steps87.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES87 : PetersenWordProjection.projectFast steps87 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG87 : PetersenWordProjection.projectFast steps87 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP88 : steps88.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES88 : PetersenWordProjection.projectFast steps88 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG88 : PetersenWordProjection.projectFast steps88 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP89 : steps89.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES89 : PetersenWordProjection.projectFast steps89 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG89 : PetersenWordProjection.projectFast steps89 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP90 : steps90.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES90 : PetersenWordProjection.projectFast steps90 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG90 : PetersenWordProjection.projectFast steps90 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP91 : steps91.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES91 : PetersenWordProjection.projectFast steps91 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG91 : PetersenWordProjection.projectFast steps91 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP92 : steps92.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES92 : PetersenWordProjection.projectFast steps92 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG92 : PetersenWordProjection.projectFast steps92 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP93 : steps93.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES93 : PetersenWordProjection.projectFast steps93 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG93 : PetersenWordProjection.projectFast steps93 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP94 : steps94.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES94 : PetersenWordProjection.projectFast steps94 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG94 : PetersenWordProjection.projectFast steps94 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP97 : steps97.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES97 : PetersenWordProjection.projectFast steps97 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG97 : PetersenWordProjection.projectFast steps97 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP98 : steps98.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES98 : PetersenWordProjection.projectFast steps98 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG98 : PetersenWordProjection.projectFast steps98 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP99 : steps99.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES99 : PetersenWordProjection.projectFast steps99 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG99 : PetersenWordProjection.projectFast steps99 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
end Full18
