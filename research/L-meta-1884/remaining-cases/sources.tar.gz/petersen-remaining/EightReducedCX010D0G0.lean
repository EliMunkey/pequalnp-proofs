import EightReducedCX010D1G0
import EightReducedCX010D1G1
import EightReducedCX010D1G2
import EightReducedCX010D1G3
import HMC010Hyp
import HMC010Rules0
import HMC010Rules1
import HMC010Rules5
import HMC010Rules6
import HMC010Sym
import HMC010W0
import HMC010W1
import HMC010W2
import HMC010W3
import LiveProgramCX010D1G0
import PetersenSymmetry
import Q1020K12Closing
import first8.AdjacentSym
import first8.FastLocal
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
open MC010Cert
namespace PetersenLiveReduced.CX010
set_option maxRecDepth 300000
set_option maxHeartbeats 0
set_option linter.concreteInstances false
def s0_0 : List (BitVec 256) := [w517,w572,w625,w644,w680,w720,w778,w880,w977]
private def c0_0 : Array (PetersenProjectedRule.Rule 256) := #[rule26 route0 [],rule30 route4 [],rule34 route6 [],rule432 route7 [],rule30 route7 [(false,(6,true),(5,true))],rule26 route1 [],rule30 route2 [],rule30 route6 [(false,(6,true),(2,true))],rule26 route6 [(false,(1,true),(0,true))],rule34 route7 [],rule26 route2 [(false,(3,true),(4,true))],rule3 route0 [],rule0 route5 [],rule26 route5 [(false,(5,true),(0,true))],rule422 route0 [],rule3 route2 [],rule26 route4 [(false,(3,true),(2,true))],rule26 route7 [(false,(1,true),(2,true))],rule431 route4 [],rule425 route0 [],rule427 route0 [],rule2 route1 [],rule413 route4 [],rule410 route7 [],rule26 route2 [],rule430 route0 [],rule419 route5 [],rule30 route7 [],rule26 route5 [],rule416 route2 [],rule32 route7 [],rule32 route7 [(false,(3,true),(2,true))],rule26 route6 [],rule26 route7 [],rule411 route7 [],rule420 route3 [],rule2 route3 [],rule423 route0 [],rule26 route3 [(false,(5,true),(6,true))],rule424 route0 [],rule30 route0 [(false,(4,true),(3,true))],rule30 route5 [(false,(1,true),(2,true))],rule415 route4 [],rule414 route5 [],rule426 route3 [],rule417 route4 [],rule30 route1 [(false,(4,true),(0,true))],rule30 route3 [(false,(1,true),(0,true))],rule426 route0 [],rule418 route3 [],rule428 route0 [],rule417 route2 [],rule414 route3 [],rule420 route5 [],rule410 route6 [],rule429 route0 [],rule413 route2 [],rule421 route6 [],rule412 route5 [],rule412 route3 []]
private def m0_0 : Array (List (BitVec 256)) := #[[w454,w572,w625,w644,w680,w720,w778,w880,w977],[w454,w517,w572,w644,w680,w720,w778,w880,w977],[w572,w625,w644,w680,w720,w778,w880,w907,w977],[w402,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w763,w778,w880,w977],[w180,w517,w625,w644,w680,w720,w778,w880,w977],[w419,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w880,w977,w1015],[w517,w572,w644,w680,w720,w769,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w769,w778,w880,w977],[w239,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w616,w644,w680,w720,w778,w880,w977],[w182,w517,w572,w644,w680,w720,w778,w880,w977],[w386,w517,w572,w644,w680,w720,w778,w880,w977],[w386,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w618,w644,w680,w720,w778,w880,w977],[w131,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w644,w680,w720,w778,w880,w977,w1025],[w517,w572,w625,w644,w680,w720,w778,w880,w977,w1025],[w74,w517,w572,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w865,w880,w977],[w244,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w880,w928,w977],[w248,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w880,w977,w1039],[w274,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w880,w945,w977],[w139,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w774,w778,w880,w977],[w86,w517,w572,w625,w644,w680,w720,w778,w880,w977],[w517,w572,w625,w644,w680,w720,w778,w880,w977,w1061]]
private def hs0_0 : List (List Nat) := [[1377,0,0,0,606,606,1,1,350,60,350,2],[606,606,0,0,8316,60,61,2],[606,606,609,0,33248,3,33248,0,609,1,609,1,606,606,33248,4],[606,606,8323,5,2654,2662,16804,0,614,2662,8323,6,606,606,16804,7],[606,606,16555,0,4702,4718,16812,0,622,4718,16555,0,606,606,16812,8],[606,606,2179,5,380,8830,380,0,638,8830,2179,6,380,606,380,9],[606,606,669,0,2468,62,2468,0,669,5,669,5,606,606,2468,2],[606,606,1247,5,1504,33502,1504,0,734,33502,1247,0,606,606,1504,9],[350,350,0,0,1121,1,63,1],[350,350,32991,10,609,1378,609,11,354,1378,32991,12,350,350,609,4],[350,350,8323,13,2398,2406,8837,14,358,2406,8323,15,350,350,8837,16],[350,350,16555,8,4446,4462,33517,64,366,4462,16555,11,350,350,33517,17],[350,350,380,11,2693,18,2693,19,380,65,380,15,350,350,2693,66],[350,350,2211,11,669,16798,669,20,414,16798,2211,21,350,350,669,22],[350,350,1247,15,4845,33246,4845,67,478,33246,1247,11,350,350,4845,23],[32991,24,32991,10,609,25,609,11,32991,26,32991,12,609,27,609,4],[8323,28,8323,13,8837,14,8837,14,8323,29,8323,15,8837,30,8837,31],[16555,32,16555,8,16812,68,16812,69,16555,70,16555,11,16812,33,16812,17],[2179,71,2179,21,380,19,380,19,2179,72,2179,15,380,73,380,74],[2211,75,2211,12,669,20,669,20,2211,76,2211,21,669,34,669,34],[1247,35,1247,36,1504,77,1504,78,1247,79,1247,11,1504,23,1504,23],[609,609,8323,10,2657,2665,9351,37,617,2665,8323,10,609,609,9351,13],[609,609,16555,38,4705,4721,17583,39,625,4721,16555,40,609,609,17583,41],[380,609,380,38,1404,8833,1408,39,380,8833,380,10,384,609,1408,42],[609,609,669,10,3235,49439,3239,39,669,49439,669,38,609,609,3239,43],[609,609,4331,38,1247,32991,1247,44,223,32991,4331,40,223,609,1247,45],[8323,8323,16555,13,12419,12435,35059,14,8339,12435,16555,46,8323,8323,35059,47],[380,16547,380,16,2179,8323,2179,48,131,8323,380,7,131,16547,2179,49],[669,8323,669,13,2211,16547,2211,50,163,16547,669,46,163,8323,2211,51],[1247,8323,1247,16,3295,49443,3303,14,1247,49443,1247,13,1255,8323,3303,52],[380,16555,380,17,4476,24779,4492,80,380,24779,380,8,396,16555,4492,81],[669,33003,669,8,4267,16555,4267,82,171,16555,669,47,171,33003,4267,83],[1247,16555,1247,17,4331,33003,4331,84,235,33003,1247,41,235,16555,4331,85],[380,380,669,53,8861,16828,8893,86,444,16828,669,87,380,380,8893,54],[380,380,1247,88,8443,33019,8443,55,251,33019,1247,89,251,380,8443,56],[669,669,1247,57,17631,33565,17695,90,797,33565,1247,58,669,669,17695,59]]
theorem r0_0 [Assumptions] : Blocked tgt 12 s0_0 := by
  refine PetersenFastLocal.close (cut := c0_0) (more := m0_0) (hs := hs0_0) (by decide +kernel) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 []) (correct26 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route4 []) (correct30 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route6 []) (correct34 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule432 route7 []) (correct432 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 [(false,(6,true),(5,true))]) (correct30 route7 [(false,(6,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 []) (correct26 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 []) (correct30 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route6 [(false,(6,true),(2,true))]) (correct30 route6 [(false,(6,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 [(false,(1,true),(0,true))]) (correct26 route6 [(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route7 []) (correct34 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(3,true),(4,true))]) (correct26 route2 [(false,(3,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 []) (correct3 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route5 []) (correct0 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(0,true))]) (correct26 route5 [(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule422 route0 []) (correct422 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 []) (correct3 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route4 [(false,(3,true),(2,true))]) (correct26 route4 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(1,true),(2,true))]) (correct26 route7 [(false,(1,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule431 route4 []) (correct431 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule425 route0 []) (correct425 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule427 route0 []) (correct427 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule413 route4 []) (correct413 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule410 route7 []) (correct410 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 []) (correct26 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule430 route0 []) (correct430 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule419 route5 []) (correct419 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route7 []) (correct30 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 []) (correct26 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule416 route2 []) (correct416 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 []) (correct32 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route7 [(false,(3,true),(2,true))]) (correct32 route7 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route6 []) (correct26 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 []) (correct26 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule411 route7 []) (correct411 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule420 route3 []) (correct420 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 []) (correct2 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule423 route0 []) (correct423 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(5,true),(6,true))]) (correct26 route3 [(false,(5,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule424 route0 []) (correct424 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(4,true),(3,true))]) (correct30 route0 [(false,(4,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route5 [(false,(1,true),(2,true))]) (correct30 route5 [(false,(1,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule415 route4 []) (correct415 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule414 route5 []) (correct414 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule426 route3 []) (correct426 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule417 route4 []) (correct417 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(4,true),(0,true))]) (correct30 route1 [(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route3 [(false,(1,true),(0,true))]) (correct30 route3 [(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule426 route0 []) (correct426 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule418 route3 []) (correct418 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule428 route0 []) (correct428 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule417 route2 []) (correct417 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule414 route3 []) (correct414 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule420 route5 []) (correct420 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule410 route6 []) (correct410 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule429 route0 []) (correct429 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule413 route2 []) (correct413 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule421 route6 []) (correct421 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route5 []) (correct412 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route3 []) (correct412 route3 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w454,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) PetersenLiveReduced.CX010.r1_86) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w454,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) (Orbits1020Cost12.b1_7 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w572,w625,w644,w680,w720,w778,w880,w907,w977]) (PetersenAdjacentSymmetry.via6 (by decide +kernel) PetersenLiveReduced.CX010.r1_170) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w402,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) (Orbits1020Cost12.b1_2 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w763,w778,w880,w977]) PetersenLiveReduced.CX010.r1_139 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w180,w517,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) PetersenLiveReduced.CX010.r1_31) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w419,w517,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via4 (by decide +kernel) PetersenLive8.CX010.c1_29) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1015]) PetersenLiveReduced.CX010.r1_157 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w644,w680,w720,w769,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) PetersenLiveReduced.CX010.r1_165) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w769,w778,w880,w977]) PetersenLive8.CX010.c1_140 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w239,w517,w572,w644,w680,w720,w778,w880,w977]) PetersenLiveReduced.CX010.r1_65 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w616,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLiveReduced.CX010.r1_124) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w182,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) PetersenLiveReduced.CX010.r1_45) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w386,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) PetersenLiveReduced.CX010.r1_12) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w386,w517,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via7 (by decide +kernel) PetersenLive8.CX010.c1_13) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w618,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via5 (by decide +kernel) PetersenLiveReduced.CX010.r1_130) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w131,w517,w572,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLiveReduced.CX010.r1_51) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w644,w680,w720,w778,w880,w977,w1025]) (PetersenAdjacentSymmetry.via2 (by decide +kernel) PetersenLiveReduced.CX010.r1_167) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1025]) PetersenLive8.CX010.c1_158 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w74,w517,w572,w644,w680,w720,w778,w880,w977]) PetersenLiveReduced.CX010.r1_33 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w865,w880,w977]) PetersenLiveReduced.CX010.r1_148 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w244,w517,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLive8.CX010.c1_58) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w928,w977]) PetersenLiveReduced.CX010.r1_154 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w248,w517,w572,w625,w644,w680,w720,w778,w880,w977]) PetersenLiveReduced.CX010.r1_77 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1039]) PetersenLiveReduced.CX010.r1_160 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w274,w517,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLiveReduced.CX010.r1_79) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w945,w977]) PetersenLiveReduced.CX010.r1_155 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w139,w517,w572,w625,w644,w680,w720,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLive8.CX010.c1_25) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w774,w778,w880,w977]) (PetersenAdjacentSymmetry.via1 (by decide +kernel) PetersenLive8.CX010.c1_128) <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w86,w517,w572,w625,w644,w680,w720,w778,w880,w977]) PetersenLive8.CX010.c1_46 <|
      PetersenLocalChildren.push (P := Blocked tgt 11) (x := [w517,w572,w625,w644,w680,w720,w778,w880,w977,w1061]) PetersenLiveReduced.CX010.r1_162 <|
      PetersenLocalChildren.nil
end PetersenLiveReduced.CX010
