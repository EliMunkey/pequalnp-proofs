import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot29713
import Full18Quot53064
import Full18Quot105746
import PetersenProjectedRule
import Full18StepS21361
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21361 (h : Needs) : Blocked Root17.tgt 14 live21361 := by
  apply stepS21361
  · change ∀ r ∈ [rule3052,rule8075,rule3064,rule5944,rule8051,rule6074,rule3213,rule3259,rule3261,rule7436,rule5180,rule8022,rule4218,rule7443,rule6590,rule7430], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6074) (quickSound6074 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3213) (quickSound3213 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3259) (quickSound3259 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7436) (quickSound7436 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5180) (quickSound5180 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4218) (quickSound4218 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7430) (quickSound7430 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live79337,live108866,live75860,live70652,live108868,live63956,live108871,live108874,live53064,live108877,live35429,live29713], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live79337) (PetersenFastSymmetry.move [thinSym3,thinSym2] (L := live79337) (V := live29713) (by decide +kernel) (quotient29713 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108866) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live108866) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live75860) (PetersenFastSymmetry.move [thinSym2,thinSym0] (L := live75860) (V := live53064) (by decide +kernel) (quotient53064 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live70652) (PetersenFastSymmetry.move [thinSym2] (L := live70652) (V := live29713) (by decide +kernel) (quotient29713 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108868) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3] (L := live108868) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live63956) (PetersenFastSymmetry.move [thinSym3] (L := live63956) (V := live53064) (by decide +kernel) (quotient53064 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108871) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live108871) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108874) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym3] (L := live108874) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live53064) (quotient53064 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108877) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3] (L := live108877) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live35429) (PetersenFastSymmetry.move [thinSym0] (L := live35429) (V := live29713) (by decide +kernel) (quotient29713 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live29713) (quotient29713 h) <|
      PetersenLocalChildren.nil
end Full18
