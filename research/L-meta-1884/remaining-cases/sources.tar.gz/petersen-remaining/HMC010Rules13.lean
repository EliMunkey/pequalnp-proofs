import Extra1020K12
import HMC010G1
import HMC010G10
import HMC010G2
import HMC010G4
import HMC010G5
import HMC010G8
import HMC010G9
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule558 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xf0f0f0f0f0f0f0f0 :: i7) p
theorem correct558 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule558 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h47
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule559 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages36 s.steps 0 8 (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) p
theorem correct559 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule559 s p) tgt := by
  have small : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) (PetersenPackedPin.project r36 tgt) 8 := by rw [match36]; exact Assumptions.h44
  intro d L hit
  exact PetersenRoutedPin.quick rowOk36 s small hot36 p hit
def rule560 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages69 s.steps 0 4 (0xaaaa :: i5) p
theorem correct560 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule560 s p) tgt := by
  have small : NoAtMost (0xaaaa :: i5) (PetersenPackedPin.project r69 tgt) 4 := by rw [match69]; exact Assumptions.h1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk69 s small hot69 p hit
def rule561 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages111 s.steps 0 4 (0xaaaa :: i5) p
theorem correct561 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule561 s p) tgt := by
  have small : NoAtMost (0xaaaa :: i5) (PetersenPackedPin.project r111 tgt) 4 := by rw [match111]; exact Assumptions.h1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk111 s small hot111 p hit
def rule562 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages117 s.steps 64 5 (0xa0a0a0a0a0a0a0a :: i6) p
theorem correct562 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule562 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a :: i6) (PetersenPackedPin.project r117 tgt) 5 := by rw [match117]; exact Assumptions.h41
  intro d L hit
  exact PetersenRoutedPin.quick rowOk117 s small hot117 p hit
def rule563 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages397 s.steps 128 4 (0xf000f0 :: i5) p
theorem correct563 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule563 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r397 tgt) 4 := by rw [match397]; exact Assumptions.h26
  intro d L hit
  exact PetersenRoutedPin.quick rowOk397 s small hot397 p hit
def rule564 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages288 s.steps 128 4 (0xa0a0a0a :: i5) p
theorem correct564 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule564 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r288 tgt) 4 := by rw [match288]; exact Assumptions.h27
  intro d L hit
  exact PetersenRoutedPin.quick rowOk288 s small hot288 p hit
def rule565 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages354 s.steps 128 4 (0x44444444 :: i5) p
theorem correct565 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule565 s p) tgt := by
  have small : NoAtMost (0x44444444 :: i5) (PetersenPackedPin.project r354 tgt) 4 := by rw [match354]; exact Assumptions.h29
  intro d L hit
  exact PetersenRoutedPin.quick rowOk354 s small hot354 p hit
def rule566 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages404 s.steps 32 4 (0xf000f0 :: i5) p
theorem correct566 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule566 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r404 tgt) 4 := by rw [match404]; exact Assumptions.h2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk404 s small hot404 p hit
def rule567 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages37 s.steps 128 6 (0xf000f000f000f000f000f000f000f0 :: i7) p
theorem correct567 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule567 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f000f000f000f000f0 :: i7) (PetersenPackedPin.project r37 tgt) 6 := by rw [match37]; exact Assumptions.h69
  intro d L hit
  exact PetersenRoutedPin.quick rowOk37 s small hot37 p hit
def rule568 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages117 s.steps 64 5 (0xf000f000f000f0 :: i6) p
theorem correct568 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule568 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r117 tgt) 5 := by rw [match117]; exact Assumptions.h40
  intro d L hit
  exact PetersenRoutedPin.quick rowOk117 s small hot117 p hit
def rule569 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages383 s.steps 64 4 (0xf000f0 :: i5) p
theorem correct569 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule569 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r383 tgt) 4 := by rw [match383]; exact Assumptions.h26
  intro d L hit
  exact PetersenRoutedPin.quick rowOk383 s small hot383 p hit
def rule570 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages74 s.steps 128 5 (0xf000f000f000f0 :: i6) p
theorem correct570 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule570 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r74 tgt) 5 := by rw [match74]; exact Assumptions.h40
  intro d L hit
  exact PetersenRoutedPin.quick rowOk74 s small hot74 p hit
def rule571 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages74 s.steps 128 5 (0x4444444444444444 :: i6) p
theorem correct571 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule571 s p) tgt := by
  have small : NoAtMost (0x4444444444444444 :: i6) (PetersenPackedPin.project r74 tgt) 5 := by rw [match74]; exact Assumptions.h43
  intro d L hit
  exact PetersenRoutedPin.quick rowOk74 s small hot74 p hit
def rule572 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages110 s.steps 64 5 (0xaaaa0000aaaa :: i6) p
theorem correct572 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule572 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa :: i6) (PetersenPackedPin.project r110 tgt) 5 := by rw [match110]; exact Assumptions.h38
  intro d L hit
  exact PetersenRoutedPin.quick rowOk110 s small hot110 p hit
def rule573 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages100 s.steps 64 5 (0xf000f000f000f0 :: i6) p
theorem correct573 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule573 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r100 tgt) 5 := by rw [match100]; exact Assumptions.h39
  intro d L hit
  exact PetersenRoutedPin.quick rowOk100 s small hot100 p hit
def rule574 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages93 s.steps 64 5 (0xf000f000f000f0 :: i6) p
theorem correct574 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule574 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r93 tgt) 5 := by rw [match93]; exact Assumptions.h39
  intro d L hit
  exact PetersenRoutedPin.quick rowOk93 s small hot93 p hit
def rule575 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages23 s.steps 0 6 (0xcccccccc :: i6) p
theorem correct575 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule575 s p) tgt := by
  have small : NoAtMost (0xcccccccc :: i6) (PetersenPackedPin.project r23 tgt) 6 := by rw [match23]; exact Assumptions.h30
  intro d L hit
  exact PetersenRoutedPin.quick rowOk23 s small hot23 p hit
def rule576 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages76 s.steps 0 4 (0xf000f0 :: i5) p
theorem correct576 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule576 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r76 tgt) 4 := by rw [match76]; exact Assumptions.h2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk76 s small hot76 p hit
def rule577 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages257 s.steps 64 4 (0xf000f0 :: i5) p
theorem correct577 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule577 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r257 tgt) 4 := by rw [match257]; exact Assumptions.h2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk257 s small hot257 p hit
end MC010Cert
