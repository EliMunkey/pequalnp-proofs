import M111StartL6B1
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown111G104 : NoAtMost PetersenSmallStarts.M111.s104 PetersenSmallStarts.M111.tgt 6 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(2,34),(2,3),(32,34),(2,6),(36,44),(33,49)] (by decide +kernel) PetersenSmallStarts.M111.b104
#print axioms theFirstLiveknown111G104
end PetersenLive8
