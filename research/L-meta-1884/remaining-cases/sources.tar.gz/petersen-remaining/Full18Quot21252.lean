import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot41826
import PetersenProjectedRule
import Full18StepS21252
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21252 (h : Needs) : Blocked Root17.tgt 14 live21252 := by
  apply stepS21252
  · change ∀ r ∈ [rule3052,rule3064,rule2406,rule8051,rule5796,rule3063,rule3258,rule7568,rule5944,rule6082,rule7485,rule8044], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2406) (quickSound2406 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5796) (quickSound5796 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3258) (quickSound3258 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7568) (quickSound7568 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7485) (quickSound7485 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8044) (quickSound8044 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live75056], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live75056) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3] (L := live75056) (V := live41826) (by decide +kernel) (quotient41826 h)) <|
      PetersenLocalChildren.nil
end Full18
