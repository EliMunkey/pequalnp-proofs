import Full18ThinRules3
import PetersenProjectedRule
import Full18StepS189239
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient189239 (h : Needs) : Blocked Root17.tgt 12 live189239 := by
  apply stepS189239
  · change ∀ r ∈ [rule3052,rule3064,rule3251,rule3255], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [], Blocked Root17.tgt 11 s
    exact PetersenLocalChildren.nil
end Full18
