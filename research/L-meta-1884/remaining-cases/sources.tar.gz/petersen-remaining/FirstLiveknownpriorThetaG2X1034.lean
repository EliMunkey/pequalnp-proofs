import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknownpriorThetaG2X1034 : NoAtMost ThetaCert.s2_1034 0xfffffffffffaf8f8ffeafaeaffeaf8c8 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(21,20),(1,3),(18,22),(4,12),(5,21),(9,13),(1,33),(4,68)] (by decide +kernel) ThetaCert.b2_1034
#print axioms theFirstLiveknownpriorThetaG2X1034
end PetersenLive8
