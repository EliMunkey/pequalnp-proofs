import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknownpriorThetaG2X429 : NoAtMost ThetaCert.s2_429 0xfffffffffffaf8f8ffeafaeaffeaf8c8 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(4,68),(66,67),(65,67),(64,68),(4,12),(65,81),(64,96)] (by decide +kernel) ThetaCert.b2_429
#print axioms theFirstLiveknownpriorThetaG2X429
end PetersenLive8
