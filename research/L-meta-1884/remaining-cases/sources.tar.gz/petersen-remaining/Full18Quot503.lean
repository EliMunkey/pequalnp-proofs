import Full18ThinRules0
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot20197
import Full18Quot20218
import Full18Quot20527
import Full18Quot21179
import PetersenProjectedRule
import Full18StepS503
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient503 (h : Needs) : Blocked Root17.tgt 15 live503 := by
  apply stepS503
  · change ∀ r ∈ [rule8051,rule3290,rule8022,rule7992,rule5881,rule7469,rule7459,rule6082,rule1006,rule8030,rule7443,rule5804,rule5807,rule6590,rule1295,rule5817,rule5819,rule5704,rule3086,rule5830,rule5834,rule6656,rule6104,rule5864,rule5878], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7992) (quickSound7992 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5881) (quickSound5881 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1006) (quickSound1006 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8030) (quickSound8030 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5804) (quickSound5804 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5807) (quickSound5807 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1295) (quickSound1295 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5817) (quickSound5817 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5819) (quickSound5819 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5704) (quickSound5704 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3086) (quickSound3086 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5830) (quickSound5830 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5834) (quickSound5834 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6656) (quickSound6656 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6104) (quickSound6104 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5864) (quickSound5864 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5878) (quickSound5878 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live20839,live20197,live21024,live20206,live20208,live20235,live20218], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20839) (PetersenFastSymmetry.move [thinSym0] (L := live20839) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20197) (quotient20197 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21024) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21024) (V := live21179) (by decide +kernel) (quotient21179 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20206) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live20206) (V := live20197) (by decide +kernel) (quotient20197 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20208) (PetersenFastSymmetry.move [thinSym0,thinSym1] (L := live20208) (V := live20527) (by decide +kernel) (quotient20527 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20235) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live20235) (V := live20218) (by decide +kernel) (quotient20218 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20218) (quotient20218 h) <|
      PetersenLocalChildren.nil
end Full18
