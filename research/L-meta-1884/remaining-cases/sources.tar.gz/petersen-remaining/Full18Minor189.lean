import PetersenProjectedRule
import M189Closing
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem minor189 : NoAtMost (inputs 6) (0xfffffeccfaeafac0 : BitVec 64) 7 := M189Certificate.lower
end Full18
