import Full18ThinRules0
import Full18ThinRules1
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules9
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot357
import Full18Quot367
import Full18Quot502
import Full18Quot503
import Full18Quot517
import PetersenProjectedRule
import Full18StepS6
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient6 (h : Needs) : Blocked Root17.tgt 16 live6 := by
  apply stepS6
  · change ∀ r ∈ [rule5881,rule5209,rule8051,rule3943,rule3290,rule8030,rule7469,rule7459,rule5557,rule3250,rule3924,rule5787,rule1561,rule1927,rule1006,rule5817,rule5704,rule5830,rule5844,rule1317,rule3864,rule3092,rule5864,rule5595], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5881) (quickSound5881 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5209) (quickSound5209 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3943) (quickSound3943 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8030) (quickSound8030 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3250) (quickSound3250 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3924) (quickSound3924 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5787) (quickSound5787 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1561) (quickSound1561 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1927) (quickSound1927 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1006) (quickSound1006 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5817) (quickSound5817 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5704) (quickSound5704 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5830) (quickSound5830 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5844) (quickSound5844 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1317) (quickSound1317 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3864) (quickSound3864 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3092) (quickSound3092 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5864) (quickSound5864 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5595) (quickSound5595 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live522,live523,live520,live521,live502,live503,live505,live507,live509,live511,live513,live515,live357,live366,live393,live402,live367,live376,live377,live386,live395,live378,live405,live388], Blocked Root17.tgt 15 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live522) (PetersenFastSymmetry.move [thinSym3] (L := live522) (V := live517) (by decide +kernel) (quotient517 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live523) (PetersenFastSymmetry.move [thinSym1,thinSym3] (L := live523) (V := live517) (by decide +kernel) (quotient517 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live520) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live520) (V := live517) (by decide +kernel) (quotient517 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live521) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live521) (V := live517) (by decide +kernel) (quotient517 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live502) (quotient502 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live503) (quotient503 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live505) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live505) (V := live502) (by decide +kernel) (quotient502 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live507) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live507) (V := live502) (by decide +kernel) (quotient502 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live509) (PetersenFastSymmetry.move [thinSym1] (L := live509) (V := live502) (by decide +kernel) (quotient502 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live511) (PetersenFastSymmetry.move [thinSym0] (L := live511) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live513) (PetersenFastSymmetry.move [thinSym0,thinSym1] (L := live513) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live515) (PetersenFastSymmetry.move [thinSym1] (L := live515) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live357) (quotient357 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live366) (PetersenFastSymmetry.move [thinSym0] (L := live366) (V := live357) (by decide +kernel) (quotient357 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live393) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live393) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live402) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live402) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live367) (quotient367 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live376) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live376) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live377) (PetersenFastSymmetry.move [thinSym1] (L := live377) (V := live357) (by decide +kernel) (quotient357 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live386) (PetersenFastSymmetry.move [thinSym0] (L := live386) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live395) (PetersenFastSymmetry.move [thinSym0,thinSym1] (L := live395) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live378) (PetersenFastSymmetry.move [thinSym0,thinSym1] (L := live378) (V := live357) (by decide +kernel) (quotient357 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live405) (PetersenFastSymmetry.move [thinSym1] (L := live405) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live388) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live388) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.nil
end Full18
