import HEX010G6
import HEX010G7
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r246 := EX010Cert.r246
abbrev stages246 := EX010Cert.stages246
theorem rowOk246 : PetersenWordProjection.check stages246 0 r246 = true := EX010Cert.rowOk246
theorem hot246 : forcedConst r246 tgt = false := EX010Cert.hot246
theorem match246 : PetersenPackedPin.project r246 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match246
abbrev r255 := EX010Cert.r255
abbrev stages255 := EX010Cert.stages255
theorem rowOk255 : PetersenWordProjection.check stages255 32 r255 = true := EX010Cert.rowOk255
theorem hot255 : forcedConst r255 tgt = false := EX010Cert.hot255
theorem match255 : PetersenPackedPin.project r255 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match255
abbrev r257 := EX010Cert.r257
abbrev stages257 := EX010Cert.stages257
theorem rowOk257 : PetersenWordProjection.check stages257 64 r257 = true := EX010Cert.rowOk257
theorem hot257 : forcedConst r257 tgt = false := EX010Cert.hot257
theorem match257 : PetersenPackedPin.project r257 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match257
abbrev r260 := EX010Cert.r260
abbrev stages260 := EX010Cert.stages260
theorem rowOk260 : PetersenWordProjection.check stages260 0 r260 = true := EX010Cert.rowOk260
theorem hot260 : forcedConst r260 tgt = false := EX010Cert.hot260
theorem match260 : PetersenPackedPin.project r260 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match260
abbrev r268 := EX010Cert.r268
abbrev stages268 := EX010Cert.stages268
theorem rowOk268 : PetersenWordProjection.check stages268 0 r268 = true := EX010Cert.rowOk268
theorem hot268 : forcedConst r268 tgt = false := EX010Cert.hot268
theorem match268 : PetersenPackedPin.project r268 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match268
abbrev r274 := EX010Cert.r274
abbrev stages274 := EX010Cert.stages274
theorem rowOk274 : PetersenWordProjection.check stages274 128 r274 = true := EX010Cert.rowOk274
theorem hot274 : forcedConst r274 tgt = false := EX010Cert.hot274
theorem match274 : PetersenPackedPin.project r274 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match274
abbrev r288 := EX010Cert.r288
abbrev stages288 := EX010Cert.stages288
theorem rowOk288 : PetersenWordProjection.check stages288 128 r288 = true := EX010Cert.rowOk288
theorem hot288 : forcedConst r288 tgt = false := EX010Cert.hot288
theorem match288 : PetersenPackedPin.project r288 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match288
abbrev r292 := EX010Cert.r292
abbrev stages292 := EX010Cert.stages292
theorem rowOk292 : PetersenWordProjection.check stages292 0 r292 = true := EX010Cert.rowOk292
theorem hot292 : forcedConst r292 tgt = false := EX010Cert.hot292
theorem match292 : PetersenPackedPin.project r292 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match292
def r319 (i : Fin 32) : Fin 256 := (#[0,2,64,66,16,18,80,82,128,130,192,194,144,146,208,210,1,3,65,67,17,19,81,83,129,131,193,195,145,147,209,211] : Array (Fin 256))[i.val]?.getD 0
def stages319 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x78,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00000000000000000000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff0000ff00ff00ff00ff00ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk319 : PetersenWordProjection.check stages319 0 r319 = true := by decide +kernel
theorem hot319 : forcedConst r319 tgt = false := by decide +kernel
theorem match319 : PetersenPackedPin.project r319 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
def r324 (i : Fin 32) : Fin 256 := (#[0,1,32,33,128,129,160,161,16,17,48,49,144,145,176,177,2,3,34,35,130,131,162,163,18,19,50,51,146,147,178,179] : Array (Fin 256))[i.val]?.getD 0
def stages324 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x10,0xffff000000000000ffff000000000000ffff000000000000ffff0000,0xffff000000000000ffff000000000000ffff000000000000ffff00000000,0xffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x7c,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00000000000000000000000000000000,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f⟩,⟨0x1e,0xcccccccc00000000cccccccc00000000cccccccc00000000cccccccc,0x3333333300000000333333330000000033333333000000003333333300000000,0xcccccccc33333333cccccccc33333333cccccccc33333333cccccccc33333333⟩]
theorem rowOk324 : PetersenWordProjection.check stages324 0 r324 = true := by decide +kernel
theorem hot324 : forcedConst r324 tgt = false := by decide +kernel
theorem match324 : PetersenPackedPin.project r324 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
def r334 (i : Fin 16) : Fin 256 := (#[0,1,2,3,64,65,66,67,8,9,10,11,72,73,74,75] : Array (Fin 256))[i.val]?.getD 0
def stages334 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩]
theorem rowOk334 : PetersenWordProjection.check stages334 0 r334 = true := by decide +kernel
theorem hot334 : forcedConst r334 tgt = false := by decide +kernel
theorem match334 : PetersenPackedPin.project r334 tgt = (0xf8c8 : BitVec 16) := by decide +kernel
abbrev r343 := EX010Cert.r343
abbrev stages343 := EX010Cert.stages343
theorem rowOk343 : PetersenWordProjection.check stages343 64 r343 = true := EX010Cert.rowOk343
theorem hot343 : forcedConst r343 tgt = false := EX010Cert.hot343
theorem match343 : PetersenPackedPin.project r343 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match343
end MC010Cert
