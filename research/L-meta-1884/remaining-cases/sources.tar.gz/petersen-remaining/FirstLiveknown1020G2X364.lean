import Q1020K12Closing
import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown1020G2X364 : NoAtMost Orbits1020Cost12.s2_364 Orbits1020Cost12.tgt 10 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(64,80),(18,19),(17,19),(18,22),(48,56),(17,49),(16,80),(16,144)] (by decide +kernel) (Orbits1020Cost12.b2_364 ThetaCert.bound)
#print axioms theFirstLiveknown1020G2X364
end PetersenLive8
