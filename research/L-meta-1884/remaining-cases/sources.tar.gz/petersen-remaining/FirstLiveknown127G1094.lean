import M127StartL7B31
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown127G1094 : NoAtMost PetersenSmallStarts.M127.s1094 PetersenSmallStarts.M127.tgt 7 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(65,97),(97,96),(65,67),(34,38),(36,44),(65,81),(34,98)] (by decide +kernel) PetersenSmallStarts.M127.b1094
#print axioms theFirstLiveknown127G1094
end PetersenLive8
