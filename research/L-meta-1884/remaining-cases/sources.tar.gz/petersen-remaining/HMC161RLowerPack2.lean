import HMC161RHyp
import M119StartLabeled
import M127Needed8
import M15StartLabeled
import M47StartLabeled
import M63StartLabeled
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold24_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold24_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold24_0 <;> decide +kernel

theorem hold25_0 : NoAtMost (0x4444 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hold25_1 : NoAtMost (0x44444444 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold25_0 <;> decide +kernel

theorem hold26_0 : NoAtMost (0xcccccccc :: inputs 6) 0xeeeeeecceaeaeac8 5 := by
  exact PetersenSmallStarts.M119.all_forbidden 0xcccccccc (by decide +kernel)

theorem hold27_0 : NoAtMost (0xaaaaaaaa :: inputs 6) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenSmallStarts.M63.all_forbidden 0xaaaaaaaa (by decide +kernel)

theorem hold28_0 : NoAtMost (0xaaaa0000aaaa0000 :: inputs 6) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenSmallStarts.M63.all_forbidden 0xaaaa0000aaaa0000 (by decide +kernel)

theorem hold29_0 : NoAtMost (0xf000f0 :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xf000f0 (by decide +kernel)
theorem hold29_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffaeaf8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold29_0 <;> decide +kernel

theorem hold30_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold30_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold30_0 <;> decide +kernel
theorem hold30_2 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold30_1 <;> decide +kernel

theorem hold31_0 : NoAtMost (0x4444 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hold31_1 : NoAtMost (0x44444444 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold31_0 <;> decide +kernel
theorem hold31_2 : NoAtMost (0x4444444444444444 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold31_1 <;> decide +kernel

theorem hold32_0 : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: inputs 7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8 := by
  exact PetersenSmallStarts.M127.gate_0_3_0

theorem hold33_0 : NoAtMost (0xffccffccffccffccffccffccffccffcc :: inputs 7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8 := by
  exact PetersenSmallStarts.M127.First8Support.labeled_1_3_0

theorem hold50_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold50_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold50_0 <;> decide +kernel
theorem hold50_2 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold50_1 <;> decide +kernel
theorem hold50_3 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: inputs 7) 0xfffffffffffffffffffffffffffff8c8 6 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) hold50_2 <;> decide +kernel

theorem hold51_0 : NoAtMost (0x3300 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hold51_1 : NoAtMost (0x33003300 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold51_0 <;> decide +kernel
theorem hold51_2 : NoAtMost (0x3300330033003300 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold51_1 <;> decide +kernel
theorem hold51_3 : NoAtMost (0x33003300330033003300330033003300 :: inputs 7) 0xfffffffffffffffffffffffffffff8c8 6 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) hold51_2 <;> decide +kernel
end MC161RCert
