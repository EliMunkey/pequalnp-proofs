import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknownpriorThetaG2X648 : NoAtMost ThetaCert.s2_648 0xfffffffffffaf8f8ffeafaeaffeaf8c8 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(1,3),(2,3),(2,6),(4,12),(1,17),(1,33),(4,68)] (by decide +kernel) ThetaCert.b2_648
#print axioms theFirstLiveknownpriorThetaG2X648
end PetersenLive8
