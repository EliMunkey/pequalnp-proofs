import Full18ThinRules0
import Full18ThinRules3
import Full18ThinRules7
import Full18ThinRules15
import Full18ThinSym0
import Full18Quot189239
import PetersenProjectedRule
import Full18StepS115094
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient115094 (h : Needs) : Blocked Root17.tgt 13 live115094 := by
  apply stepS115094
  · change ∀ r ∈ [rule3052,rule3064,rule8051,rule991,rule5025,rule3063,rule3073,rule8059,rule3070], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule991) (quickSound991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5025) (quickSound5025 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8059) (quickSound8059 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live189248], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live189248) (PetersenFastSymmetry.move [thinSym0] (L := live189248) (V := live189239) (by decide +kernel) (quotient189239 h)) <|
      PetersenLocalChildren.nil
end Full18
