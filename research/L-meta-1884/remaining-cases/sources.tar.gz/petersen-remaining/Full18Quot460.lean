import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot18600
import Full18Quot18613
import Full18Quot18623
import Full18Quot18629
import Full18Quot18639
import Full18Quot18650
import Full18Quot19846
import Full18Quot21645
import PetersenProjectedRule
import Full18StepS460
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient460 (h : Needs) : Blocked Root17.tgt 15 live460 := by
  apply stepS460
  · change ∀ r ∈ [rule7443,rule3290,rule7469,rule5557,rule6082,rule8022,rule8051,rule6655,rule7505,rule5308,rule5316,rule8101,rule5326,rule5335,rule2951,rule3249,rule3319,rule8000,rule7546,rule6004,rule3357,rule5385,rule5450,rule5458,rule6656,rule5464,rule6104,rule5394,rule5403,rule5360,rule3421,rule5373,rule6615,rule5496,rule3657,rule5538,rule6674,rule5549,rule3706,rule3691,rule5550,rule3748,rule7459,rule3809,rule6590,rule3778,rule3786,rule3754,rule5571,rule5572,rule3906,rule5528,rule5535], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6655) (quickSound6655 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7505) (quickSound7505 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5308) (quickSound5308 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5316) (quickSound5316 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8101) (quickSound8101 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5326) (quickSound5326 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5335) (quickSound5335 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2951) (quickSound2951 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3249) (quickSound3249 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3319) (quickSound3319 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7546) (quickSound7546 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6004) (quickSound6004 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3357) (quickSound3357 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5385) (quickSound5385 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5450) (quickSound5450 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5458) (quickSound5458 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6656) (quickSound6656 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5464) (quickSound5464 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6104) (quickSound6104 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5394) (quickSound5394 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5403) (quickSound5403 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5360) (quickSound5360 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3421) (quickSound3421 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5373) (quickSound5373 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6615) (quickSound6615 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5496) (quickSound5496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3657) (quickSound3657 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5538) (quickSound5538 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5549) (quickSound5549 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3706) (quickSound3706 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3691) (quickSound3691 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5550) (quickSound5550 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3748) (quickSound3748 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3809) (quickSound3809 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3778) (quickSound3778 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3786) (quickSound3786 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3754) (quickSound3754 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5571) (quickSound5571 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5572) (quickSound5572 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3906) (quickSound3906 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5528) (quickSound5528 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5535) (quickSound5535 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live22340,live22283,live18650,live18600,live18629,live18639,live21538,live21645,live20836,live18631,live19897,live19870,live18613,live18623,live18626,live18648], Blocked Root17.tgt 14 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22340) (PetersenFastSymmetry.move [thinSym3] (L := live22340) (V := live21645) (by decide +kernel) (quotient21645 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live22283) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live22283) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18650) (quotient18650 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18600) (quotient18600 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18629) (quotient18629 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18639) (quotient18639 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21538) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live21538) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live21645) (quotient21645 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live20836) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live20836) (V := live18650) (by decide +kernel) (quotient18650 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18631) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live18631) (V := live18600) (by decide +kernel) (quotient18600 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19897) (PetersenFastSymmetry.move [thinSym0] (L := live19897) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live19870) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live19870) (V := live19846) (by decide +kernel) (quotient19846 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18613) (quotient18613 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18623) (quotient18623 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18626) (PetersenFastSymmetry.move [thinSym3] (L := live18626) (V := live18613) (by decide +kernel) (quotient18613 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 14 s)) (x := live18648) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live18648) (V := live18639) (by decide +kernel) (quotient18639 h)) <|
      PetersenLocalChildren.nil
end Full18
