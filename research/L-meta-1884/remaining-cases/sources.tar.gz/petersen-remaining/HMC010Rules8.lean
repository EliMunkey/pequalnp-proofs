import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule458 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0x50505050505050505050505050505050 :: i7) p
theorem correct458 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule458 s p) tgt := by
  have small : NoAtMost (0x50505050505050505050505050505050 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h55
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule459 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xaaaaaaaaaaaaaaaa :: i7) p
theorem correct459 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule459 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h46
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule460 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xf0f0f0f0f0f0f0f0 :: i7) p
theorem correct460 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule460 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h47
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule461 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xaaaaaaaaaaaaaaaa :: i7) p
theorem correct461 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule461 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h46
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule462 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xffffffffffffffffffffffff00000000 :: i7) p
theorem correct462 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule462 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffffffff00000000 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h68
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule463 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xaaaaaaaa00000000aaaaaaaa :: i7) p
theorem correct463 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule463 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa00000000aaaaaaaa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h48
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule464 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xf0f0f0f000000000f0f0f0f0 :: i7) p
theorem correct464 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule464 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f000000000f0f0f0f0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h49
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule465 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) p
theorem correct465 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule465 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h58
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule466 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) p
theorem correct466 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule466 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h56
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule467 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) p
theorem correct467 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule467 s p) tgt := by
  have small : NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h64
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule468 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) p
theorem correct468 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule468 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h56
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule469 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) p
theorem correct469 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule469 s p) tgt := by
  have small : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h66
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule470 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xff0000 :: i5) p
theorem correct470 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule470 s p) tgt := by
  have small : NoAtMost (0xff0000 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h9
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule471 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xffffff00 :: i5) p
theorem correct471 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule471 s p) tgt := by
  have small : NoAtMost (0xffffff00 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h25
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule472 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0x44444444 :: i5) p
theorem correct472 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule472 s p) tgt := by
  have small : NoAtMost (0x44444444 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h17
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule473 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0x55550000 :: i5) p
theorem correct473 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule473 s p) tgt := by
  have small : NoAtMost (0x55550000 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h19
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule474 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xffffaaaa :: i5) p
theorem correct474 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule474 s p) tgt := by
  have small : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h24
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule475 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xa0a0a0a :: i5) p
theorem correct475 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule475 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h10
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule476 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xf000f00 :: i5) p
theorem correct476 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule476 s p) tgt := by
  have small : NoAtMost (0xf000f00 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h12
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule477 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) p
theorem correct477 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule477 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h50
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
end MC010Cert
