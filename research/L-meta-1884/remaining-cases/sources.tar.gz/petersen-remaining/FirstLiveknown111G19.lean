import M111StartL4B0
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown111G19 : NoAtMost PetersenSmallStarts.M111.s19 PetersenSmallStarts.M111.tgt 4 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(18,50),(48,49),(48,50),(18,22),(52,60)] (by decide +kernel) PetersenSmallStarts.M111.b19
#print axioms theFirstLiveknown111G19
end PetersenLive8
