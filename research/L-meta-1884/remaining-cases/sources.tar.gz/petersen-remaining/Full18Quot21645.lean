import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot97160
import Full18Quot97318
import Full18Quot97875
import Full18Quot97906
import Full18Quot97909
import Full18Quot112934
import Full18Quot112991
import Full18Quot113205
import Full18Quot121578
import PetersenProjectedRule
import Full18StepS21645
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21645 (h : Needs) : Blocked Root17.tgt 14 live21645 := by
  apply stepS21645
  · change ∀ r ∈ [rule3064,rule3290,rule7469,rule5557,rule3251,rule6082,rule6674,rule7546,rule5326,rule5335,rule6655,rule5327,rule3226,rule8101,rule7443,rule8051,rule5360,rule3421,rule5373,rule8000,rule5538,rule5385,rule3691,rule5550,rule3778,rule3786,rule3915,rule5535], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7546) (quickSound7546 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5326) (quickSound5326 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5335) (quickSound5335 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6655) (quickSound6655 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5327) (quickSound5327 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3226) (quickSound3226 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8101) (quickSound8101 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5360) (quickSound5360 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3421) (quickSound3421 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5373) (quickSound5373 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5538) (quickSound5538 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5385) (quickSound5385 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3691) (quickSound3691 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5550) (quickSound5550 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3778) (quickSound3778 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3786) (quickSound3786 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3915) (quickSound3915 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5535) (quickSound5535 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live121585,live121572,live112934,live112916,live112925,live113494,live113234,live112991,live112901,live112910,live112913,live112933], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live121585) (PetersenFastSymmetry.move [thinSym0] (L := live121585) (V := live121578) (by decide +kernel) (quotient121578 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live121572) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live121572) (V := live113205) (by decide +kernel) (quotient113205 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112934) (quotient112934 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112916) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live112916) (V := live97875) (by decide +kernel) (quotient97875 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112925) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live112925) (V := live97318) (by decide +kernel) (quotient97318 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live113494) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live113494) (V := live112934) (by decide +kernel) (quotient112934 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live113234) (PetersenFastSymmetry.move [thinSym0] (L := live113234) (V := live113205) (by decide +kernel) (quotient113205 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112991) (quotient112991 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112901) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym3,thinSym1,thinSym2,thinSym3] (L := live112901) (V := live97160) (by decide +kernel) (quotient97160 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112910) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live112910) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112913) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym2] (L := live112913) (V := live97909) (by decide +kernel) (quotient97909 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112933) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live112933) (V := live97318) (by decide +kernel) (quotient97318 h)) <|
      PetersenLocalChildren.nil
end Full18
