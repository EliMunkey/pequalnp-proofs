import Extra1020K12
import HMC010G2
import HMC010G3
import HMC010G4
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule33 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages33 s.steps 128 6 i7 p
theorem correct33 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule33 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r33 tgt) 6 := by rw [match33]; exact Extra1020K12.b47_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk33 s small hot33 p hit
def rule34 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 i7 p
theorem correct34 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule34 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Extra1020K12.b191_0 ThetaCert.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule35 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages35 s.steps 128 6 i7 p
theorem correct35 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule35 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r35 tgt) 6 := by rw [match35]; exact Extra1020K12.b47_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk35 s small hot35 p hit
def rule37 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages37 s.steps 128 6 i7 p
theorem correct37 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule37 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r37 tgt) 6 := by rw [match37]; exact Extra1020K12.b15_3
  intro d L hit
  exact PetersenRoutedPin.quick rowOk37 s small hot37 p hit
def rule39 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages39 s.steps 128 6 i7 p
theorem correct39 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule39 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r39 tgt) 6 := by rw [match39]; exact Extra1020K12.b15_3
  intro d L hit
  exact PetersenRoutedPin.quick rowOk39 s small hot39 p hit
def rule41 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages41 s.steps 128 6 i7 p
theorem correct41 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule41 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r41 tgt) 6 := by rw [match41]; exact Extra1020K12.b15_3
  intro d L hit
  exact PetersenRoutedPin.quick rowOk41 s small hot41 p hit
def rule42 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages42 s.steps 128 5 i6 p
theorem correct42 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule42 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r42 tgt) 5 := by rw [match42]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk42 s small hot42 p hit
def rule43 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages43 s.steps 64 5 i6 p
theorem correct43 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule43 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r43 tgt) 5 := by rw [match43]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk43 s small hot43 p hit
def rule44 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages44 s.steps 128 5 i6 p
theorem correct44 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule44 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r44 tgt) 5 := by rw [match44]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk44 s small hot44 p hit
def rule45 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages45 s.steps 64 5 i6 p
theorem correct45 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule45 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r45 tgt) 5 := by rw [match45]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk45 s small hot45 p hit
def rule47 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages47 s.steps 128 5 i6 p
theorem correct47 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule47 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r47 tgt) 5 := by rw [match47]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk47 s small hot47 p hit
def rule48 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages48 s.steps 64 5 i6 p
theorem correct48 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule48 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r48 tgt) 5 := by rw [match48]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk48 s small hot48 p hit
def rule53 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages53 s.steps 128 5 i6 p
theorem correct53 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule53 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r53 tgt) 5 := by rw [match53]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk53 s small hot53 p hit
def rule54 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages54 s.steps 64 5 i6 p
theorem correct54 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule54 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r54 tgt) 5 := by rw [match54]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk54 s small hot54 p hit
def rule61 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages61 s.steps 128 5 i6 p
theorem correct61 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule61 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r61 tgt) 5 := by rw [match61]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk61 s small hot61 p hit
def rule62 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages62 s.steps 64 5 i6 p
theorem correct62 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule62 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r62 tgt) 5 := by rw [match62]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk62 s small hot62 p hit
def rule69 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages69 s.steps 0 4 i5 p
theorem correct69 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule69 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r69 tgt) 4 := by rw [match69]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk69 s small hot69 p hit
def rule73 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages73 s.steps 0 5 i6 p
theorem correct73 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule73 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r73 tgt) 5 := by rw [match73]; exact Extra1020K12.b119_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk73 s small hot73 p hit
def rule74 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages74 s.steps 128 5 i6 p
theorem correct74 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule74 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r74 tgt) 5 := by rw [match74]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk74 s small hot74 p hit
def rule75 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages75 s.steps 64 5 i6 p
theorem correct75 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule75 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r75 tgt) 5 := by rw [match75]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk75 s small hot75 p hit
end MC010Cert
