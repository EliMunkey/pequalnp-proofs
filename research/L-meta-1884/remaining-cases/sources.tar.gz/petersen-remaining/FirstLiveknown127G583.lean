import M127StartL7B15
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown127G583 : NoAtMost PetersenSmallStarts.M127.s583 PetersenSmallStarts.M127.tgt 7 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(1,17),(16,17),(1,3),(18,22),(16,24),(1,33),(18,82)] (by decide +kernel) PetersenSmallStarts.M127.b583
#print axioms theFirstLiveknown127G583
end PetersenLive8
