import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule478 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xaaaa :: i5) p
theorem correct478 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule478 s p) tgt := by
  have small : NoAtMost (0xaaaa :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h3
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule479 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xf000f000f000f000f000f000f000f0 :: i7) p
theorem correct479 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule479 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f000f000f000f000f0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h53
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule480 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xff0000 :: i5) p
theorem correct480 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule480 s p) tgt := by
  have small : NoAtMost (0xff0000 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h9
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule481 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) p
theorem correct481 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule481 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h56
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule482 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xc0c0c0c :: i5) p
theorem correct482 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule482 s p) tgt := by
  have small : NoAtMost (0xc0c0c0c :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h11
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule483 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) p
theorem correct483 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule483 s p) tgt := by
  have small : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h61
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule484 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xaa00aa :: i5) p
theorem correct484 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule484 s p) tgt := by
  have small : NoAtMost (0xaa00aa :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h6
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule485 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xff0000 :: i5) p
theorem correct485 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule485 s p) tgt := by
  have small : NoAtMost (0xff0000 :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h9
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule486 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) p
theorem correct486 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule486 s p) tgt := by
  have small : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h62
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule487 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xaa00aa00aa00aa00aa00aa00aa00aa :: i7) p
theorem correct487 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule487 s p) tgt := by
  have small : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h52
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule488 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xf000f000f000f000f000f000f000f0 :: i7) p
theorem correct488 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule488 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f000f000f000f000f0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h53
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule489 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xf0f00000f0f00000f0f00000f0f00000 :: i7) p
theorem correct489 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule489 s p) tgt := by
  have small : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h59
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule490 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xffffff00 :: i5) p
theorem correct490 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule490 s p) tgt := by
  have small : NoAtMost (0xffffff00 :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h25
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule491 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xc0c0c0c :: i5) p
theorem correct491 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule491 s p) tgt := by
  have small : NoAtMost (0xc0c0c0c :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h11
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule492 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xffffffffffffffffffff0000ffff0000 :: i7) p
theorem correct492 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule492 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h67
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule493 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) p
theorem correct493 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule493 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h50
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule494 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) p
theorem correct494 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule494 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h58
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule495 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) p
theorem correct495 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule495 s p) tgt := by
  have small : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h62
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule496 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xf0f00000f0f00000f0f00000f0f0 :: i7) p
theorem correct496 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule496 s p) tgt := by
  have small : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h51
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule497 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages5 s.steps 0 7 (0xaaaa0000aaaa0000 :: i6) p
theorem correct497 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule497 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000 :: i6) (PetersenPackedPin.project r5 tgt) 7 := by rw [match5]; exact Assumptions.h37
  intro d L hit
  exact PetersenRoutedPin.quick rowOk5 s small hot5 p hit
end MC010Cert
