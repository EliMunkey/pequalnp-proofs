import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule438 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xfff0fff0 :: i5) p
theorem correct438 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule438 s p) tgt := by
  have small : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h23
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule439 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xeeeeeeee :: i5) p
theorem correct439 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule439 s p) tgt := by
  have small : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h21
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule440 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xffffaaaa :: i5) p
theorem correct440 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule440 s p) tgt := by
  have small : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h24
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule441 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) p
theorem correct441 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule441 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h54
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule442 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages6 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct442 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule442 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r6 tgt) 7 := by rw [match6]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk6 s small hot6 p hit
def rule443 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0x50505050505050505050505050505050 :: i7) p
theorem correct443 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule443 s p) tgt := by
  have small : NoAtMost (0x50505050505050505050505050505050 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h55
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule444 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0x44444444 :: i5) p
theorem correct444 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule444 s p) tgt := by
  have small : NoAtMost (0x44444444 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h17
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule445 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0x55550000 :: i5) p
theorem correct445 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule445 s p) tgt := by
  have small : NoAtMost (0x55550000 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h19
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule446 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xeeeeeeee :: i5) p
theorem correct446 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule446 s p) tgt := by
  have small : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h21
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule447 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xffffaaaa :: i5) p
theorem correct447 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule447 s p) tgt := by
  have small : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h24
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule448 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages38 s.steps 0 8 (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) p
theorem correct448 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule448 s p) tgt := by
  have small : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) (PetersenPackedPin.project r38 tgt) 8 := by rw [match38]; exact Assumptions.h44
  intro d L hit
  exact PetersenRoutedPin.quick rowOk38 s small hot38 p hit
def rule449 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages38 s.steps 0 8 (0xffccffccffccffccffccffccffccffcc :: i7) p
theorem correct449 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule449 s p) tgt := by
  have small : NoAtMost (0xffccffccffccffccffccffccffccffcc :: i7) (PetersenPackedPin.project r38 tgt) 8 := by rw [match38]; exact Assumptions.h45
  intro d L hit
  exact PetersenRoutedPin.quick rowOk38 s small hot38 p hit
def rule450 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) p
theorem correct450 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule450 s p) tgt := by
  have small : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h66
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule451 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages23 s.steps 0 6 (0xffffffffcccccccc :: i6) p
theorem correct451 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule451 s p) tgt := by
  have small : NoAtMost (0xffffffffcccccccc :: i6) (PetersenPackedPin.project r23 tgt) 6 := by rw [match23]; exact Assumptions.h34
  intro d L hit
  exact PetersenRoutedPin.quick rowOk23 s small hot23 p hit
def rule452 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xeeeeeeee :: i5) p
theorem correct452 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule452 s p) tgt := by
  have small : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h21
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule453 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xff0000 :: i5) p
theorem correct453 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule453 s p) tgt := by
  have small : NoAtMost (0xff0000 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h9
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule454 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xfcfcfcfc :: i5) p
theorem correct454 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule454 s p) tgt := by
  have small : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h22
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule455 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xfff0fff0 :: i5) p
theorem correct455 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule455 s p) tgt := by
  have small : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h23
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule456 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0xa0a0a0a :: i5) p
theorem correct456 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule456 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h10
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule457 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) p
theorem correct457 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule457 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h54
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
end MC010Cert
