import M111StartL4B0
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown111G53 : NoAtMost PetersenSmallStarts.M111.s53 PetersenSmallStarts.M111.tgt 4 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(9,25),(24,25),(9,11),(56,60),(26,58)] (by decide +kernel) PetersenSmallStarts.M111.b53
#print axioms theFirstLiveknown111G53
end PetersenLive8
