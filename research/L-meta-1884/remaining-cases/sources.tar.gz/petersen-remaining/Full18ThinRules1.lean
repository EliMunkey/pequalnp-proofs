import PetersenProjectedRule
import Full18FastBases
import Full18Data1
import Full18Data2
import Full18ThinView4
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound1482 (h : Needs) : Correct rule1482 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1482) (t := Root17.tgt) SEP174 ONES174 thinBasis2 TG174 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1494 (h : Needs) : Correct rule1494 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1494) (t := Root17.tgt) SEP92 ONES92 thinBasis4 TG92 (baseThin4 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1507 (h : Needs) : Correct rule1507 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1507) (t := Root17.tgt) SEP172 ONES172 thinBasis2 TG172 (baseThin2 h) (by decide +kernel) [(false,(5,true),(4,true)),(false,(9,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1508 (h : Needs) : Correct rule1508 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1508) (t := Root17.tgt) SEP172 ONES172 thinBasis2 TG172 (baseThin2 h) (by decide +kernel) [(false,(5,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1561 (h : Needs) : Correct rule1561 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1561) (t := Root17.tgt) SEP88 ONES88 thinBasis5 TG88 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound1587 (h : Needs) : Correct rule1587 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1587) (t := Root17.tgt) SEP88 ONES88 thinBasis13 TG88 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound1598 (h : Needs) : Correct rule1598 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1598) (t := Root17.tgt) SEP88 ONES88 thinBasis1 TG88 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound1627 (h : Needs) : Correct rule1627 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1627) (t := Root17.tgt) SEP156 ONES156 thinBasis1 TG156 (baseThin1 h) (by decide +kernel) [(false,(5,true),(2,true))] rfl (by decide +kernel)
theorem quickSound1642 (h : Needs) : Correct rule1642 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1642) (t := Root17.tgt) SEP88 ONES88 thinBasis2 TG88 (baseThin2 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound1646 (h : Needs) : Correct rule1646 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1646) (t := Root17.tgt) SEP88 ONES88 thinBasis7 TG88 (baseThin7 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound1708 (h : Needs) : Correct rule1708 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1708) (t := Root17.tgt) SEP153 ONES153 thinBasis7 TG153 (baseThin7 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1754 (h : Needs) : Correct rule1754 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1754) (t := Root17.tgt) SEP121 ONES121 thinBasis5 TG121 (baseThin5 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound1774 (h : Needs) : Correct rule1774 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1774) (t := Root17.tgt) SEP121 ONES121 thinBasis1 TG121 (baseThin1 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound1795 (h : Needs) : Correct rule1795 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1795) (t := Root17.tgt) SEP163 ONES163 thinBasis5 TG163 (baseThin5 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound1825 (h : Needs) : Correct rule1825 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1825) (t := Root17.tgt) SEP121 ONES121 thinBasis2 TG121 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound1857 (h : Needs) : Correct rule1857 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1857) (t := Root17.tgt) SEP153 ONES153 thinBasis16 TG153 (baseThin16 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1860 (h : Needs) : Correct rule1860 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1860) (t := Root17.tgt) SEP90 ONES90 thinBasis0 TG90 (baseThin0 h) (by decide +kernel) [(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1905 (h : Needs) : Correct rule1905 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1905) (t := Root17.tgt) SEP89 ONES89 thinBasis5 TG89 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1916 (h : Needs) : Correct rule1916 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1916) (t := Root17.tgt) SEP89 ONES89 thinBasis5 TG89 (baseThin5 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound1927 (h : Needs) : Correct rule1927 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1927) (t := Root17.tgt) SEP89 ONES89 thinBasis5 TG89 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound1948 (h : Needs) : Correct rule1948 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1948) (t := Root17.tgt) SEP89 ONES89 thinBasis13 TG89 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2055 (h : Needs) : Correct rule2055 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2055) (t := Root17.tgt) SEP147 ONES147 thinBasis7 TG147 (baseThin7 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound2098 (h : Needs) : Correct rule2098 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2098) (t := Root17.tgt) SEP157 ONES157 thinBasis5 TG157 (baseThin5 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2117 (h : Needs) : Correct rule2117 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2117) (t := Root17.tgt) SEP157 ONES157 thinBasis1 TG157 (baseThin1 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2137 (h : Needs) : Correct rule2137 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2137) (t := Root17.tgt) SEP126 ONES126 thinBasis5 TG126 (baseThin5 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2163 (h : Needs) : Correct rule2163 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2163) (t := Root17.tgt) SEP157 ONES157 thinBasis2 TG157 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2182 (h : Needs) : Correct rule2182 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2182) (t := Root17.tgt) SEP147 ONES147 thinBasis16 TG147 (baseThin16 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound2225 (h : Needs) : Correct rule2225 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2225) (t := Root17.tgt) SEP91 ONES91 thinBasis5 TG91 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound2232 (h : Needs) : Correct rule2232 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2232) (t := Root17.tgt) SEP91 ONES91 thinBasis5 TG91 (baseThin5 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2242 (h : Needs) : Correct rule2242 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2242) (t := Root17.tgt) SEP91 ONES91 thinBasis5 TG91 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2306 (h : Needs) : Correct rule2306 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2306) (t := Root17.tgt) SEP91 ONES91 thinBasis13 TG91 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2336 (h : Needs) : Correct rule2336 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2336) (t := Root17.tgt) SEP94 ONES94 thinBasis5 TG94 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
