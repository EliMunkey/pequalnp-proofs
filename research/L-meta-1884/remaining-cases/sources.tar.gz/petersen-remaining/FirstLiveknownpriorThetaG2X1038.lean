import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknownpriorThetaG2X1038 : NoAtMost ThetaCert.s2_1038 0xfffffffffffaf8f8ffeafaeaffeaf8c8 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(2,3),(2,6),(18,26),(36,38),(1,17),(66,98),(9,11),(4,68)] (by decide +kernel) ThetaCert.b2_1038
#print axioms theFirstLiveknownpriorThetaG2X1038
end PetersenLive8
