import PetersenProjectedRule
import Full18FastBases
import Full18Data5
import Full18ThinView5
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound5450 (h : Needs) : Correct rule5450 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5450) (t := Root17.tgt) SEP102 ONES102 thinBasis4 TG102 (baseThin4 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5458 (h : Needs) : Correct rule5458 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5458) (t := Root17.tgt) SEP102 ONES102 thinBasis16 TG102 (baseThin16 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5464 (h : Needs) : Correct rule5464 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5464) (t := Root17.tgt) SEP165 ONES165 thinBasis16 TG165 (baseThin16 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5471 (h : Needs) : Correct rule5471 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5471) (t := Root17.tgt) SEP155 ONES155 thinBasis2 TG155 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5481 (h : Needs) : Correct rule5481 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5481) (t := Root17.tgt) SEP155 ONES155 thinBasis2 TG155 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound5492 (h : Needs) : Correct rule5492 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5492) (t := Root17.tgt) SEP155 ONES155 thinBasis2 TG155 (baseThin2 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5496 (h : Needs) : Correct rule5496 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5496) (t := Root17.tgt) SEP155 ONES155 thinBasis2 TG155 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5506 (h : Needs) : Correct rule5506 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5506) (t := Root17.tgt) SEP155 ONES155 thinBasis7 TG155 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5527 (h : Needs) : Correct rule5527 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5527) (t := Root17.tgt) SEP155 ONES155 thinBasis13 TG155 (baseThin13 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5528 (h : Needs) : Correct rule5528 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5528) (t := Root17.tgt) SEP155 ONES155 thinBasis13 TG155 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5535 (h : Needs) : Correct rule5535 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5535) (t := Root17.tgt) SEP160 ONES160 thinBasis5 TG160 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5538 (h : Needs) : Correct rule5538 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5538) (t := Root17.tgt) SEP165 ONES165 thinBasis5 TG165 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5547 (h : Needs) : Correct rule5547 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5547) (t := Root17.tgt) SEP130 ONES130 thinBasis5 TG130 (baseThin5 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5549 (h : Needs) : Correct rule5549 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5549) (t := Root17.tgt) SEP130 ONES130 thinBasis5 TG130 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5550 (h : Needs) : Correct rule5550 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5550) (t := Root17.tgt) SEP134 ONES134 thinBasis5 TG134 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5556 (h : Needs) : Correct rule5556 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5556) (t := Root17.tgt) SEP169 ONES169 thinBasis2 TG169 (baseThin2 h) (by decide +kernel) [(false,(4,true),(2,true))] rfl (by decide +kernel)
theorem quickSound5557 (h : Needs) : Correct rule5557 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5557) (t := Root17.tgt) SEP169 ONES169 thinBasis2 TG169 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5559 (h : Needs) : Correct rule5559 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5559) (t := Root17.tgt) SEP130 ONES130 thinBasis2 TG130 (baseThin2 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5566 (h : Needs) : Correct rule5566 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5566) (t := Root17.tgt) SEP130 ONES130 thinBasis2 TG130 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5571 (h : Needs) : Correct rule5571 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5571) (t := Root17.tgt) SEP130 ONES130 thinBasis2 TG130 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5572 (h : Needs) : Correct rule5572 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5572) (t := Root17.tgt) SEP130 ONES130 thinBasis7 TG130 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5575 (h : Needs) : Correct rule5575 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5575) (t := Root17.tgt) SEP109 ONES109 thinBasis5 TG109 (baseThin5 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5579 (h : Needs) : Correct rule5579 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5579) (t := Root17.tgt) SEP109 ONES109 thinBasis13 TG109 (baseThin13 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5583 (h : Needs) : Correct rule5583 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5583) (t := Root17.tgt) SEP109 ONES109 thinBasis1 TG109 (baseThin1 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5595 (h : Needs) : Correct rule5595 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5595) (t := Root17.tgt) SEP109 ONES109 thinBasis4 TG109 (baseThin4 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5611 (h : Needs) : Correct rule5611 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5611) (t := Root17.tgt) SEP146 ONES146 thinBasis2 TG146 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true)),(false,(0,false),(9,true))] rfl (by decide +kernel)
theorem quickSound5615 (h : Needs) : Correct rule5615 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5615) (t := Root17.tgt) SEP146 ONES146 thinBasis2 TG146 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5616 (h : Needs) : Correct rule5616 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5616) (t := Root17.tgt) SEP149 ONES149 thinBasis7 TG149 (baseThin7 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound5622 (h : Needs) : Correct rule5622 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5622) (t := Root17.tgt) SEP142 ONES142 thinBasis5 TG142 (baseThin5 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5625 (h : Needs) : Correct rule5625 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5625) (t := Root17.tgt) SEP142 ONES142 thinBasis14 TG142 (baseThin14 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5639 (h : Needs) : Correct rule5639 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5639) (t := Root17.tgt) SEP128 ONES128 thinBasis2 TG128 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5651 (h : Needs) : Correct rule5651 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5651) (t := Root17.tgt) SEP112 ONES112 thinBasis4 TG112 (baseThin4 h) (by decide +kernel) [(false,(8,true),(1,true))] rfl (by decide +kernel)
end Full18
