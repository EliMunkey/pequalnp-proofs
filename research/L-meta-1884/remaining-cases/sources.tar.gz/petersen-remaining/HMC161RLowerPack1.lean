import HMC161RHyp
import M31StartLabeled
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold12_0 : NoAtMost (0xf0f0000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xf0f0000 (by decide +kernel)

theorem hold13_0 : NoAtMost (0x30303030 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0x30303030 (by decide +kernel)

theorem hold14_0 : NoAtMost (0x33330000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0x33330000 (by decide +kernel)

theorem hold15_0 : NoAtMost (0x55550000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0x55550000 (by decide +kernel)

theorem hold16_0 : NoAtMost (0xa0a0a0a0 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a0 (by decide +kernel)

theorem hold17_0 : NoAtMost (0xcc00cc00 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xcc00cc00 (by decide +kernel)

theorem hold18_0 : NoAtMost (0xcccc0000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xcccc0000 (by decide +kernel)

theorem hold19_0 : NoAtMost (0xf0f00000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xf0f00000 (by decide +kernel)

theorem hold20_0 : NoAtMost (0xfcfcfcfc :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xfcfcfcfc (by decide +kernel)

theorem hold21_0 : NoAtMost (0xfff0fff0 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xfff0fff0 (by decide +kernel)

theorem hold22_0 : NoAtMost (0xffffaaaa :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xffffaaaa (by decide +kernel)

theorem hold23_0 : NoAtMost (0xffffff00 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xffffff00 (by decide +kernel)
end MC161RCert
