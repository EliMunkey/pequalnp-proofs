import PetersenProjectedRule
import Full18FastBases
import Full18Data2
import Full18Data3
import Full18ThinView0
import Full18ThinView4
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound2970 (h : Needs) : Correct rule2970 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2970) (t := Root17.tgt) SEP93 ONES93 thinBasis1 TG93 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3025 (h : Needs) : Correct rule3025 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3025) (t := Root17.tgt) SEP166 ONES166 thinBasis2 TG166 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3051 (h : Needs) : Correct rule3051 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3051) (t := Root17.tgt) SEP4 ONES4 thinBasis18 TG4 (baseThin18 h) (by decide +kernel) [(false,(6,true),(1,true))] rfl (by decide +kernel)
theorem quickSound3052 (h : Needs) : Correct rule3052 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3052) (t := Root17.tgt) SEP4 ONES4 thinBasis18 TG4 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3053 (h : Needs) : Correct rule3053 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3053) (t := Root17.tgt) SEP2 ONES2 thinBasis22 TG2 (baseThin22 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3057 (h : Needs) : Correct rule3057 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3057) (t := Root17.tgt) SEP1 ONES1 thinBasis12 TG1 (baseThin12 h) (by decide +kernel) [(false,(3,true),(4,true))] rfl (by decide +kernel)
theorem quickSound3063 (h : Needs) : Correct rule3063 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3063) (t := Root17.tgt) SEP5 ONES5 thinBasis12 TG5 (baseThin12 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3064 (h : Needs) : Correct rule3064 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3064) (t := Root17.tgt) SEP7 ONES7 thinBasis18 TG7 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3066 (h : Needs) : Correct rule3066 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3066) (t := Root17.tgt) SEP6 ONES6 thinBasis12 TG6 (baseThin12 h) (by decide +kernel) [(false,(2,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3070 (h : Needs) : Correct rule3070 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3070) (t := Root17.tgt) SEP8 ONES8 thinBasis18 TG8 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3073 (h : Needs) : Correct rule3073 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3073) (t := Root17.tgt) SEP9 ONES9 thinBasis18 TG9 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3086 (h : Needs) : Correct rule3086 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3086) (t := Root17.tgt) SEP97 ONES97 thinBasis5 TG97 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3092 (h : Needs) : Correct rule3092 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3092) (t := Root17.tgt) SEP97 ONES97 thinBasis5 TG97 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3160 (h : Needs) : Correct rule3160 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3160) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(0,true),(8,true)),(false,(1,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3163 (h : Needs) : Correct rule3163 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3163) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3164 (h : Needs) : Correct rule3164 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3164) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3172 (h : Needs) : Correct rule3172 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3172) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(2,true),(4,true)),(false,(7,true),(4,true)),(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3198 (h : Needs) : Correct rule3198 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3198) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3201 (h : Needs) : Correct rule3201 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3201) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(3,true),(7,true)),(false,(4,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3205 (h : Needs) : Correct rule3205 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3205) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(4,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3213 (h : Needs) : Correct rule3213 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3213) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(5,true),(0,true))] rfl (by decide +kernel)
theorem quickSound3218 (h : Needs) : Correct rule3218 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3218) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true)),(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3223 (h : Needs) : Correct rule3223 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3223) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true))] rfl (by decide +kernel)
theorem quickSound3226 (h : Needs) : Correct rule3226 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3226) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(6,true),(7,true)),(false,(9,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3228 (h : Needs) : Correct rule3228 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3228) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound3238 (h : Needs) : Correct rule3238 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3238) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(8,true),(4,true)),(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3241 (h : Needs) : Correct rule3241 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3241) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound3249 (h : Needs) : Correct rule3249 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3249) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [(false,(8,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3250 (h : Needs) : Correct rule3250 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3250) (t := Root17.tgt) SEP97 ONES97 thinBasis2 TG97 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3251 (h : Needs) : Correct rule3251 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3251) (t := Root17.tgt) SEP10 ONES10 thinBasis18 TG10 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3254 (h : Needs) : Correct rule3254 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3254) (t := Root17.tgt) SEP11 ONES11 thinBasis12 TG11 (baseThin12 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3255 (h : Needs) : Correct rule3255 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3255) (t := Root17.tgt) SEP12 ONES12 thinBasis18 TG12 (baseThin18 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
