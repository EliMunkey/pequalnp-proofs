import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot42184
import Full18Quot96894
import Full18Quot96968
import Full18Quot97071
import PetersenProjectedRule
import Full18StepS19798
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient19798 (h : Needs) : Blocked Root17.tgt 14 live19798 := by
  apply stepS19798
  · change ∀ r ∈ [rule8075,rule5944,rule3258,rule3052,rule6074,rule5914,rule3064,rule7436,rule5907,rule3260,rule5932,rule3066,rule6082,rule6725,rule5945,rule7443,rule6590,rule8048,rule7430,rule8041,rule8051], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3258) (quickSound3258 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6074) (quickSound6074 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5914) (quickSound5914 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7436) (quickSound7436 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5907) (quickSound5907 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3260) (quickSound3260 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5932) (quickSound5932 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3066) (quickSound3066 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5945) (quickSound5945 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8048) (quickSound8048 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7430) (quickSound7430 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8041) (quickSound8041 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live118690,live120167,live111604,live112683,live100833,live102622,live104130,live106648,live97071,live96968,live96894,live63951,live97151,live96970,live96910,live58567,live97095,live96972,live96926,live53059,live97201,live96976,live96946,live42184], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live118690) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live118690) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live120167) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2] (L := live120167) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live111604) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live111604) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112683) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live112683) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live100833) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live100833) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live102622) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live102622) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live104130) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live104130) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live106648) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2] (L := live106648) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live97071) (quotient97071 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96968) (quotient96968 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96894) (quotient96894 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live63951) (PetersenFastSymmetry.move [thinSym0] (L := live63951) (V := live42184) (by decide +kernel) (quotient42184 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live97151) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live97151) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96970) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live96970) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96910) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live96910) (V := live96894) (by decide +kernel) (quotient96894 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live58567) (PetersenFastSymmetry.move [thinSym3] (L := live58567) (V := live42184) (by decide +kernel) (quotient42184 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live97095) (PetersenFastSymmetry.move [thinSym3] (L := live97095) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96972) (PetersenFastSymmetry.move [thinSym3] (L := live96972) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96926) (PetersenFastSymmetry.move [thinSym3] (L := live96926) (V := live96894) (by decide +kernel) (quotient96894 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live53059) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live53059) (V := live42184) (by decide +kernel) (quotient42184 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live97201) (PetersenFastSymmetry.move [thinSym0] (L := live97201) (V := live97071) (by decide +kernel) (quotient97071 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96976) (PetersenFastSymmetry.move [thinSym0] (L := live96976) (V := live96968) (by decide +kernel) (quotient96968 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live96946) (PetersenFastSymmetry.move [thinSym0] (L := live96946) (V := live96894) (by decide +kernel) (quotient96894 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live42184) (quotient42184 h) <|
      PetersenLocalChildren.nil
end Full18
