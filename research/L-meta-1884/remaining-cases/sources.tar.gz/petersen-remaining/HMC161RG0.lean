import HEX010G0
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r0 := EX010Cert.r0
abbrev stages0 := EX010Cert.stages0
theorem rowOk0 : PetersenWordProjection.check stages0 0 r0 = true := EX010Cert.rowOk0
theorem hot0 : forcedConst r0 tgt = false := EX010Cert.hot0
theorem match0 : PetersenPackedPin.project r0 tgt = (0xffeaf8c8 : BitVec 32) := EX010Cert.match0
abbrev r1 := EX010Cert.r1
abbrev stages1 := EX010Cert.stages1
theorem rowOk1 : PetersenWordProjection.check stages1 0 r1 = true := EX010Cert.rowOk1
theorem hot1 : forcedConst r1 tgt = false := EX010Cert.hot1
theorem match1 : PetersenPackedPin.project r1 tgt = (0xffeaf8c8 : BitVec 32) := EX010Cert.match1
abbrev r2 := EX010Cert.r2
abbrev stages2 := EX010Cert.stages2
theorem rowOk2 : PetersenWordProjection.check stages2 0 r2 = true := EX010Cert.rowOk2
theorem hot2 : forcedConst r2 tgt = false := EX010Cert.hot2
theorem match2 : PetersenPackedPin.project r2 tgt = (0xffeaf8c8 : BitVec 32) := EX010Cert.match2
abbrev r3 := EX010Cert.r3
abbrev stages3 := EX010Cert.stages3
theorem rowOk3 : PetersenWordProjection.check stages3 0 r3 = true := EX010Cert.rowOk3
theorem hot3 : forcedConst r3 tgt = false := EX010Cert.hot3
theorem match3 : PetersenPackedPin.project r3 tgt = (0xffeaf8c8 : BitVec 32) := EX010Cert.match3
def r4 (i : Fin 64) : Fin 256 := (#[0,2,1,3,32,34,33,35,8,10,9,11,40,42,41,43,64,66,65,67,96,98,97,99,72,74,73,75,104,106,105,107,4,6,5,7,36,38,37,39,12,14,13,15,44,46,45,47,68,70,69,71,100,102,101,103,76,78,77,79,108,110,109,111] : Array (Fin 256))[i.val]?.getD 0
def stages4 : List PetersenWordProjection.Stage := [⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x1c,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f0,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f00000000,0xf0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0f⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk4 : PetersenWordProjection.check stages4 0 r4 = true := by decide +kernel
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
theorem match4 : PetersenPackedPin.project r4 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := by decide +kernel
abbrev r5 := EX010Cert.r5
abbrev stages5 := EX010Cert.stages5
theorem rowOk5 : PetersenWordProjection.check stages5 0 r5 = true := EX010Cert.rowOk5
theorem hot5 : forcedConst r5 tgt = false := EX010Cert.hot5
theorem match5 : PetersenPackedPin.project r5 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := EX010Cert.match5
abbrev r6 := EX010Cert.r6
abbrev stages6 := EX010Cert.stages6
theorem rowOk6 : PetersenWordProjection.check stages6 0 r6 = true := EX010Cert.rowOk6
theorem hot6 : forcedConst r6 tgt = false := EX010Cert.hot6
theorem match6 : PetersenPackedPin.project r6 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := EX010Cert.match6
def r7 (i : Fin 64) : Fin 256 := (#[0,2,4,6,128,130,132,134,16,18,20,22,144,146,148,150,64,66,68,70,192,194,196,198,80,82,84,86,208,210,212,214,1,3,5,7,129,131,133,135,17,19,21,23,145,147,149,151,65,67,69,71,193,195,197,199,81,83,85,87,209,211,213,215] : Array (Fin 256))[i.val]?.getD 0
def stages7 : List PetersenWordProjection.Stage := [⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x7c,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00000000000000000000000000000000,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f⟩,⟨0x2,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c,0x3030303030303030303030303030303030303030303030303030303030303030,0xc3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk7 : PetersenWordProjection.check stages7 0 r7 = true := by decide +kernel
theorem hot7 : forcedConst r7 tgt = false := by decide +kernel
theorem match7 : PetersenPackedPin.project r7 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := by decide +kernel
abbrev r9 := EX010Cert.r9
abbrev stages9 := EX010Cert.stages9
theorem rowOk9 : PetersenWordProjection.check stages9 0 r9 = true := EX010Cert.rowOk9
theorem hot9 : forcedConst r9 tgt = false := EX010Cert.hot9
theorem match9 : PetersenPackedPin.project r9 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := EX010Cert.match9
def r11 (i : Fin 64) : Fin 256 := (#[0,32,8,40,64,96,72,104,16,48,24,56,80,112,88,120,128,160,136,168,192,224,200,232,144,176,152,184,208,240,216,248,1,33,9,41,65,97,73,105,17,49,25,57,81,113,89,121,129,161,137,169,193,225,201,233,145,177,153,185,209,241,217,249] : Array (Fin 256))[i.val]?.getD 0
def stages11 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x70,0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff00000000000000000000000000000000,0xffff0000ffff0000ffff0000ffff00000000ffff0000ffff0000ffff0000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩,⟨0x6,0xcc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc00cc,0x3300330033003300330033003300330033003300330033003300330033003300,0xcc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33cc33⟩,⟨0x1f,0xaaaaaaaa00000000aaaaaaaa00000000aaaaaaaa00000000aaaaaaaa,0x5555555500000000555555550000000055555555000000005555555500000000,0xaaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555⟩]
theorem rowOk11 : PetersenWordProjection.check stages11 0 r11 = true := by decide +kernel
theorem hot11 : forcedConst r11 tgt = false := by decide +kernel
theorem match11 : PetersenPackedPin.project r11 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := by decide +kernel
def r12 (i : Fin 64) : Fin 256 := (#[0,64,2,66,4,68,6,70,128,192,130,194,132,196,134,198,16,80,18,82,20,84,22,86,144,208,146,210,148,212,150,214,8,72,10,74,12,76,14,78,136,200,138,202,140,204,142,206,24,88,26,90,28,92,30,94,152,216,154,218,156,220,158,222] : Array (Fin 256))[i.val]?.getD 0
def stages12 : List PetersenWordProjection.Stage := [⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x78,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00000000000000000000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff0000ff00ff00ff00ff00ff00ff00ff00ff⟩,⟨0x3f,0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0x5555555555555555000000000000000055555555555555550000000000000000,0xaaaaaaaaaaaaaaaa5555555555555555aaaaaaaaaaaaaaaa5555555555555555⟩]
theorem rowOk12 : PetersenWordProjection.check stages12 0 r12 = true := by decide +kernel
theorem hot12 : forcedConst r12 tgt = false := by decide +kernel
theorem match12 : PetersenPackedPin.project r12 tgt = (0xffeafaeaffeaf8c8 : BitVec 64) := by decide +kernel
abbrev r16 := EX010Cert.r16
abbrev stages16 := EX010Cert.stages16
theorem rowOk16 : PetersenWordProjection.check stages16 0 r16 = true := EX010Cert.rowOk16
theorem hot16 : forcedConst r16 tgt = false := EX010Cert.hot16
theorem match16 : PetersenPackedPin.project r16 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match16
end MC161RCert
