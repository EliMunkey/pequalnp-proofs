import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule418 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) p
theorem correct418 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule418 s p) tgt := by
  have small : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h61
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule419 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xffffff00ffffff00ffffff00ffffff00 :: i7) p
theorem correct419 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule419 s p) tgt := by
  have small : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h63
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule420 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) p
theorem correct420 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule420 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h58
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule421 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) p
theorem correct421 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule421 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h56
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule422 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) p
theorem correct422 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule422 s p) tgt := by
  have small : NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h64
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule423 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffffffff00ff00ffffffffff00ff00 :: i7) p
theorem correct423 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule423 s p) tgt := by
  have small : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h65
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule424 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xffffff00ffffff00ffffff00ffffff00 :: i7) p
theorem correct424 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule424 s p) tgt := by
  have small : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h63
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule425 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffffffffffffffffff0000ffff0000 :: i7) p
theorem correct425 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule425 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h67
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule426 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffffffffffffffffffffff00000000 :: i7) p
theorem correct426 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule426 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffffffff00000000 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h68
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule427 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) p
theorem correct427 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule427 s p) tgt := by
  have small : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h62
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule428 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) p
theorem correct428 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule428 s p) tgt := by
  have small : NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h64
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule429 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) p
theorem correct429 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule429 s p) tgt := by
  have small : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h66
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule430 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xffffff00ffffff00ffffff00ffffff00 :: i7) p
theorem correct430 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule430 s p) tgt := by
  have small : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h63
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule431 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xffffffffff00ff00ffffffffff00ff00 :: i7) p
theorem correct431 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule431 s p) tgt := by
  have small : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h65
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule432 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xffffffffffffffffffffffff00000000 :: i7) p
theorem correct432 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule432 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffffffff00000000 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h68
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule433 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xcc00cc :: i5) p
theorem correct433 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule433 s p) tgt := by
  have small : NoAtMost (0xcc00cc :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h7
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule434 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xeeeeeeee :: i5) p
theorem correct434 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule434 s p) tgt := by
  have small : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h21
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule435 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0x44444444 :: i5) p
theorem correct435 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule435 s p) tgt := by
  have small : NoAtMost (0x44444444 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h17
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule436 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xfff0fff0 :: i5) p
theorem correct436 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule436 s p) tgt := by
  have small : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h23
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule437 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0x55550000 :: i5) p
theorem correct437 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule437 s p) tgt := by
  have small : NoAtMost (0x55550000 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h19
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
end MC010Cert
