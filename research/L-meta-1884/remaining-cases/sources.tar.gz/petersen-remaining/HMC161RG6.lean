import HEX010G5
import HEX010G6
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r167 := EX010Cert.r167
abbrev stages167 := EX010Cert.stages167
theorem rowOk167 : PetersenWordProjection.check stages167 32 r167 = true := EX010Cert.rowOk167
theorem hot167 : forcedConst r167 tgt = false := EX010Cert.hot167
theorem match167 : PetersenPackedPin.project r167 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match167
abbrev r179 := EX010Cert.r179
abbrev stages179 := EX010Cert.stages179
theorem rowOk179 : PetersenWordProjection.check stages179 64 r179 = true := EX010Cert.rowOk179
theorem hot179 : forcedConst r179 tgt = false := EX010Cert.hot179
theorem match179 : PetersenPackedPin.project r179 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match179
abbrev r189 := EX010Cert.r189
abbrev stages189 := EX010Cert.stages189
theorem rowOk189 : PetersenWordProjection.check stages189 128 r189 = true := EX010Cert.rowOk189
theorem hot189 : forcedConst r189 tgt = false := EX010Cert.hot189
theorem match189 : PetersenPackedPin.project r189 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match189
def r198 (i : Fin 16) : Fin 256 := (#[0,4,2,6,64,68,66,70,16,20,18,22,80,84,82,86] : Array (Fin 256))[i.val]?.getD 0
def stages198 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩,⟨0x3,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x5050505050505050505050505050505050505050505050505050505050505050,0xa5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5⟩]
theorem rowOk198 : PetersenWordProjection.check stages198 0 r198 = true := by decide +kernel
theorem hot198 : forcedConst r198 tgt = false := by decide +kernel
theorem match198 : PetersenPackedPin.project r198 tgt = (0xf8c8 : BitVec 16) := by decide +kernel
abbrev r221 := EX010Cert.r221
abbrev stages221 := EX010Cert.stages221
theorem rowOk221 : PetersenWordProjection.check stages221 0 r221 = true := EX010Cert.rowOk221
theorem hot221 : forcedConst r221 tgt = false := EX010Cert.hot221
theorem match221 : PetersenPackedPin.project r221 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match221
abbrev r228 := EX010Cert.r228
abbrev stages228 := EX010Cert.stages228
theorem rowOk228 : PetersenWordProjection.check stages228 64 r228 = true := EX010Cert.rowOk228
theorem hot228 : forcedConst r228 tgt = false := EX010Cert.hot228
theorem match228 : PetersenPackedPin.project r228 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match228
abbrev r246 := EX010Cert.r246
abbrev stages246 := EX010Cert.stages246
theorem rowOk246 : PetersenWordProjection.check stages246 0 r246 = true := EX010Cert.rowOk246
theorem hot246 : forcedConst r246 tgt = false := EX010Cert.hot246
theorem match246 : PetersenPackedPin.project r246 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match246
abbrev r255 := EX010Cert.r255
abbrev stages255 := EX010Cert.stages255
theorem rowOk255 : PetersenWordProjection.check stages255 32 r255 = true := EX010Cert.rowOk255
theorem hot255 : forcedConst r255 tgt = false := EX010Cert.hot255
theorem match255 : PetersenPackedPin.project r255 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match255
abbrev r257 := EX010Cert.r257
abbrev stages257 := EX010Cert.stages257
theorem rowOk257 : PetersenWordProjection.check stages257 64 r257 = true := EX010Cert.rowOk257
theorem hot257 : forcedConst r257 tgt = false := EX010Cert.hot257
theorem match257 : PetersenPackedPin.project r257 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match257
abbrev r260 := EX010Cert.r260
abbrev stages260 := EX010Cert.stages260
theorem rowOk260 : PetersenWordProjection.check stages260 0 r260 = true := EX010Cert.rowOk260
theorem hot260 : forcedConst r260 tgt = false := EX010Cert.hot260
theorem match260 : PetersenPackedPin.project r260 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match260
abbrev r268 := EX010Cert.r268
abbrev stages268 := EX010Cert.stages268
theorem rowOk268 : PetersenWordProjection.check stages268 0 r268 = true := EX010Cert.rowOk268
theorem hot268 : forcedConst r268 tgt = false := EX010Cert.hot268
theorem match268 : PetersenPackedPin.project r268 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match268
abbrev r274 := EX010Cert.r274
abbrev stages274 := EX010Cert.stages274
theorem rowOk274 : PetersenWordProjection.check stages274 128 r274 = true := EX010Cert.rowOk274
theorem hot274 : forcedConst r274 tgt = false := EX010Cert.hot274
theorem match274 : PetersenPackedPin.project r274 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match274
end MC161RCert
