import Q1020K12Closing
import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown1020G4X1188 : NoAtMost Orbits1020Cost12.s4_1188 Orbits1020Cost12.tgt 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(10,11),(32,40),(9,11),(10,14),(64,80),(8,40),(8,72),(12,140)] (by decide +kernel) (Orbits1020Cost12.b4_1188 ThetaCert.bound)
#print axioms theFirstLiveknown1020G4X1188
end PetersenLive8
