import PetersenProjectedRule
import Full18FastBases
import Full18Data3
import Full18Data4
import Full18ThinView4
import Full18ThinView5
import Full18ThinView6
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound3924 (h : Needs) : Correct rule3924 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3924) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3943 (h : Needs) : Correct rule3943 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3943) (t := Root17.tgt) SEP100 ONES100 thinBasis5 TG100 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3946 (h : Needs) : Correct rule3946 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3946) (t := Root17.tgt) SEP100 ONES100 thinBasis14 TG100 (baseThin14 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3968 (h : Needs) : Correct rule3968 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3968) (t := Root17.tgt) SEP100 ONES100 thinBasis13 TG100 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3997 (h : Needs) : Correct rule3997 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3997) (t := Root17.tgt) SEP135 ONES135 thinBasis5 TG135 (baseThin5 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3998 (h : Needs) : Correct rule3998 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3998) (t := Root17.tgt) SEP135 ONES135 thinBasis5 TG135 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4000 (h : Needs) : Correct rule4000 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4000) (t := Root17.tgt) SEP135 ONES135 thinBasis14 TG135 (baseThin14 h) (by decide +kernel) [(false,(0,true),(6,true))] rfl (by decide +kernel)
theorem quickSound4018 (h : Needs) : Correct rule4018 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4018) (t := Root17.tgt) SEP175 ONES175 thinBasis1 TG175 (baseThin1 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound4025 (h : Needs) : Correct rule4025 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4025) (t := Root17.tgt) SEP175 ONES175 thinBasis1 TG175 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4043 (h : Needs) : Correct rule4043 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4043) (t := Root17.tgt) SEP122 ONES122 thinBasis1 TG122 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound4051 (h : Needs) : Correct rule4051 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4051) (t := Root17.tgt) SEP122 ONES122 thinBasis1 TG122 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4052 (h : Needs) : Correct rule4052 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4052) (t := Root17.tgt) SEP100 ONES100 thinBasis2 TG100 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound4058 (h : Needs) : Correct rule4058 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4058) (t := Root17.tgt) SEP100 ONES100 thinBasis2 TG100 (baseThin2 h) (by decide +kernel) [(false,(5,true),(3,true)),(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound4061 (h : Needs) : Correct rule4061 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4061) (t := Root17.tgt) SEP100 ONES100 thinBasis2 TG100 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound4062 (h : Needs) : Correct rule4062 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4062) (t := Root17.tgt) SEP100 ONES100 thinBasis2 TG100 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4071 (h : Needs) : Correct rule4071 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4071) (t := Root17.tgt) SEP100 ONES100 thinBasis7 TG100 (baseThin7 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound4072 (h : Needs) : Correct rule4072 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4072) (t := Root17.tgt) SEP100 ONES100 thinBasis7 TG100 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4212 (h : Needs) : Correct rule4212 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4212) (t := Root17.tgt) SEP135 ONES135 thinBasis2 TG135 (baseThin2 h) (by decide +kernel) [(false,(0,false),(5,true))] rfl (by decide +kernel)
theorem quickSound4218 (h : Needs) : Correct rule4218 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4218) (t := Root17.tgt) SEP135 ONES135 thinBasis2 TG135 (baseThin2 h) (by decide +kernel) [(false,(0,true),(5,true))] rfl (by decide +kernel)
theorem quickSound4221 (h : Needs) : Correct rule4221 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4221) (t := Root17.tgt) SEP135 ONES135 thinBasis2 TG135 (baseThin2 h) (by decide +kernel) [(false,(3,true),(0,true))] rfl (by decide +kernel)
theorem quickSound4251 (h : Needs) : Correct rule4251 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4251) (t := Root17.tgt) SEP135 ONES135 thinBasis2 TG135 (baseThin2 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound4257 (h : Needs) : Correct rule4257 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4257) (t := Root17.tgt) SEP135 ONES135 thinBasis2 TG135 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4269 (h : Needs) : Correct rule4269 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4269) (t := Root17.tgt) SEP135 ONES135 thinBasis7 TG135 (baseThin7 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound4272 (h : Needs) : Correct rule4272 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4272) (t := Root17.tgt) SEP135 ONES135 thinBasis7 TG135 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4294 (h : Needs) : Correct rule4294 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4294) (t := Root17.tgt) SEP135 ONES135 thinBasis13 TG135 (baseThin13 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound4295 (h : Needs) : Correct rule4295 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4295) (t := Root17.tgt) SEP135 ONES135 thinBasis13 TG135 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4321 (h : Needs) : Correct rule4321 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4321) (t := Root17.tgt) SEP175 ONES175 thinBasis5 TG175 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4330 (h : Needs) : Correct rule4330 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4330) (t := Root17.tgt) SEP176 ONES176 thinBasis1 TG176 (baseThin1 h) (by decide +kernel) [(false,(8,true),(4,true)),(false,(8,true),(2,true))] rfl (by decide +kernel)
theorem quickSound4331 (h : Needs) : Correct rule4331 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4331) (t := Root17.tgt) SEP176 ONES176 thinBasis1 TG176 (baseThin1 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound4344 (h : Needs) : Correct rule4344 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4344) (t := Root17.tgt) SEP122 ONES122 thinBasis5 TG122 (baseThin5 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound4348 (h : Needs) : Correct rule4348 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4348) (t := Root17.tgt) SEP122 ONES122 thinBasis5 TG122 (baseThin5 h) (by decide +kernel) [(false,(6,true),(3,true))] rfl (by decide +kernel)
theorem quickSound4349 (h : Needs) : Correct rule4349 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4349) (t := Root17.tgt) SEP122 ONES122 thinBasis5 TG122 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
