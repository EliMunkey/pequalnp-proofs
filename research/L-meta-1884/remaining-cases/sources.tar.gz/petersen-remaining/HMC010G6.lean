import HEX010G5
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r122 := EX010Cert.r122
abbrev stages122 := EX010Cert.stages122
theorem rowOk122 : PetersenWordProjection.check stages122 128 r122 = true := EX010Cert.rowOk122
theorem hot122 : forcedConst r122 tgt = false := EX010Cert.hot122
theorem match122 : PetersenPackedPin.project r122 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match122
abbrev r123 := EX010Cert.r123
abbrev stages123 := EX010Cert.stages123
theorem rowOk123 : PetersenWordProjection.check stages123 64 r123 = true := EX010Cert.rowOk123
theorem hot123 : forcedConst r123 tgt = false := EX010Cert.hot123
theorem match123 : PetersenPackedPin.project r123 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match123
abbrev r124 := EX010Cert.r124
abbrev stages124 := EX010Cert.stages124
theorem rowOk124 : PetersenWordProjection.check stages124 32 r124 = true := EX010Cert.rowOk124
theorem hot124 : forcedConst r124 tgt = false := EX010Cert.hot124
theorem match124 : PetersenPackedPin.project r124 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match124
abbrev r129 := EX010Cert.r129
abbrev stages129 := EX010Cert.stages129
theorem rowOk129 : PetersenWordProjection.check stages129 32 r129 = true := EX010Cert.rowOk129
theorem hot129 : forcedConst r129 tgt = false := EX010Cert.hot129
theorem match129 : PetersenPackedPin.project r129 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match129
def r131 (i : Fin 32) : Fin 256 := (#[0,8,32,40,128,136,160,168,4,12,36,44,132,140,164,172,64,72,96,104,192,200,224,232,68,76,100,108,196,204,228,236] : Array (Fin 256))[i.val]?.getD 0
def stages131 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x78,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00000000000000000000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff0000ff00ff00ff00ff00ff00ff00ff00ff⟩,⟨0x7c,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00000000000000000000000000000000,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f⟩,⟨0x1e,0xcccccccc00000000cccccccc00000000cccccccc00000000cccccccc,0x3333333300000000333333330000000033333333000000003333333300000000,0xcccccccc33333333cccccccc33333333cccccccc33333333cccccccc33333333⟩,⟨0x7,0xaa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa00aa,0x5500550055005500550055005500550055005500550055005500550055005500,0xaa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55aa55⟩]
theorem rowOk131 : PetersenWordProjection.check stages131 0 r131 = true := by decide +kernel
theorem hot131 : forcedConst r131 tgt = false := by decide +kernel
theorem match131 : PetersenPackedPin.project r131 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
abbrev r140 := EX010Cert.r140
abbrev stages140 := EX010Cert.stages140
theorem rowOk140 : PetersenWordProjection.check stages140 32 r140 = true := EX010Cert.rowOk140
theorem hot140 : forcedConst r140 tgt = false := EX010Cert.hot140
theorem match140 : PetersenPackedPin.project r140 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match140
abbrev r141 := EX010Cert.r141
abbrev stages141 := EX010Cert.stages141
theorem rowOk141 : PetersenWordProjection.check stages141 0 r141 = true := EX010Cert.rowOk141
theorem hot141 : forcedConst r141 tgt = false := EX010Cert.hot141
theorem match141 : PetersenPackedPin.project r141 tgt = (0xeaeaeac8 : BitVec 32) := EX010Cert.match141
abbrev r143 := EX010Cert.r143
abbrev stages143 := EX010Cert.stages143
theorem rowOk143 : PetersenWordProjection.check stages143 64 r143 = true := EX010Cert.rowOk143
theorem hot143 : forcedConst r143 tgt = false := EX010Cert.hot143
theorem match143 : PetersenPackedPin.project r143 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match143
abbrev r146 := EX010Cert.r146
abbrev stages146 := EX010Cert.stages146
theorem rowOk146 : PetersenWordProjection.check stages146 0 r146 = true := EX010Cert.rowOk146
theorem hot146 : forcedConst r146 tgt = false := EX010Cert.hot146
theorem match146 : PetersenPackedPin.project r146 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match146
abbrev r167 := EX010Cert.r167
abbrev stages167 := EX010Cert.stages167
theorem rowOk167 : PetersenWordProjection.check stages167 32 r167 = true := EX010Cert.rowOk167
theorem hot167 : forcedConst r167 tgt = false := EX010Cert.hot167
theorem match167 : PetersenPackedPin.project r167 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match167
abbrev r169 := EX010Cert.r169
abbrev stages169 := EX010Cert.stages169
theorem rowOk169 : PetersenWordProjection.check stages169 0 r169 = true := EX010Cert.rowOk169
theorem hot169 : forcedConst r169 tgt = false := EX010Cert.hot169
theorem match169 : PetersenPackedPin.project r169 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match169
abbrev r179 := EX010Cert.r179
abbrev stages179 := EX010Cert.stages179
theorem rowOk179 : PetersenWordProjection.check stages179 64 r179 = true := EX010Cert.rowOk179
theorem hot179 : forcedConst r179 tgt = false := EX010Cert.hot179
theorem match179 : PetersenPackedPin.project r179 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match179
end MC010Cert
