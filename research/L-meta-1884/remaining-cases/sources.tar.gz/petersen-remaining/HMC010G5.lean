import HEX010G4
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r98 := EX010Cert.r98
abbrev stages98 := EX010Cert.stages98
theorem rowOk98 : PetersenWordProjection.check stages98 64 r98 = true := EX010Cert.rowOk98
theorem hot98 : forcedConst r98 tgt = false := EX010Cert.hot98
theorem match98 : PetersenPackedPin.project r98 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match98
abbrev r99 := EX010Cert.r99
abbrev stages99 := EX010Cert.stages99
theorem rowOk99 : PetersenWordProjection.check stages99 128 r99 = true := EX010Cert.rowOk99
theorem hot99 : forcedConst r99 tgt = false := EX010Cert.hot99
theorem match99 : PetersenPackedPin.project r99 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match99
abbrev r100 := EX010Cert.r100
abbrev stages100 := EX010Cert.stages100
theorem rowOk100 : PetersenWordProjection.check stages100 64 r100 = true := EX010Cert.rowOk100
theorem hot100 : forcedConst r100 tgt = false := EX010Cert.hot100
theorem match100 : PetersenPackedPin.project r100 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match100
abbrev r107 := EX010Cert.r107
abbrev stages107 := EX010Cert.stages107
theorem rowOk107 : PetersenWordProjection.check stages107 128 r107 = true := EX010Cert.rowOk107
theorem hot107 : forcedConst r107 tgt = false := EX010Cert.hot107
theorem match107 : PetersenPackedPin.project r107 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match107
abbrev r108 := EX010Cert.r108
abbrev stages108 := EX010Cert.stages108
theorem rowOk108 : PetersenWordProjection.check stages108 64 r108 = true := EX010Cert.rowOk108
theorem hot108 : forcedConst r108 tgt = false := EX010Cert.hot108
theorem match108 : PetersenPackedPin.project r108 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match108
abbrev r109 := EX010Cert.r109
abbrev stages109 := EX010Cert.stages109
theorem rowOk109 : PetersenWordProjection.check stages109 128 r109 = true := EX010Cert.rowOk109
theorem hot109 : forcedConst r109 tgt = false := EX010Cert.hot109
theorem match109 : PetersenPackedPin.project r109 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match109
abbrev r110 := EX010Cert.r110
abbrev stages110 := EX010Cert.stages110
theorem rowOk110 : PetersenWordProjection.check stages110 64 r110 = true := EX010Cert.rowOk110
theorem hot110 : forcedConst r110 tgt = false := EX010Cert.hot110
theorem match110 : PetersenPackedPin.project r110 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match110
abbrev r111 := EX010Cert.r111
abbrev stages111 := EX010Cert.stages111
theorem rowOk111 : PetersenWordProjection.check stages111 0 r111 = true := EX010Cert.rowOk111
theorem hot111 : forcedConst r111 tgt = false := EX010Cert.hot111
theorem match111 : PetersenPackedPin.project r111 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match111
def r115 (i : Fin 64) : Fin 256 := (#[0,2,64,66,8,10,72,74,1,3,65,67,9,11,73,75,4,6,68,70,12,14,76,78,5,7,69,71,13,15,77,79,16,18,80,82,24,26,88,90,17,19,81,83,25,27,89,91,20,22,84,86,28,30,92,94,21,23,85,87,29,31,93,95] : Array (Fin 256))[i.val]?.getD 0
def stages115 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0x4,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f0,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f00,0xf00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk115 : PetersenWordProjection.check stages115 0 r115 = true := by decide +kernel
theorem hot115 : forcedConst r115 tgt = false := by decide +kernel
theorem match115 : PetersenPackedPin.project r115 tgt = (0xeeeeeecceaeaeac8 : BitVec 64) := by decide +kernel
abbrev r116 := EX010Cert.r116
abbrev stages116 := EX010Cert.stages116
theorem rowOk116 : PetersenWordProjection.check stages116 128 r116 = true := EX010Cert.rowOk116
theorem hot116 : forcedConst r116 tgt = false := EX010Cert.hot116
theorem match116 : PetersenPackedPin.project r116 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match116
abbrev r117 := EX010Cert.r117
abbrev stages117 := EX010Cert.stages117
theorem rowOk117 : PetersenWordProjection.check stages117 64 r117 = true := EX010Cert.rowOk117
theorem hot117 : forcedConst r117 tgt = false := EX010Cert.hot117
theorem match117 : PetersenPackedPin.project r117 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match117
abbrev r118 := EX010Cert.r118
abbrev stages118 := EX010Cert.stages118
theorem rowOk118 : PetersenWordProjection.check stages118 0 r118 = true := EX010Cert.rowOk118
theorem hot118 : forcedConst r118 tgt = false := EX010Cert.hot118
theorem match118 : PetersenPackedPin.project r118 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match118
end MC010Cert
