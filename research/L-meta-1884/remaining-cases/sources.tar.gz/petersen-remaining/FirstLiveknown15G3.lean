import M15StartL3B0
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown15G3 : NoAtMost PetersenSmallStarts.M15.s3 PetersenSmallStarts.M15.tgt 3 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(2,3),(1,3),(2,6),(5,13)] (by decide +kernel) PetersenSmallStarts.M15.b3
#print axioms theFirstLiveknown15G3
end PetersenLive8
