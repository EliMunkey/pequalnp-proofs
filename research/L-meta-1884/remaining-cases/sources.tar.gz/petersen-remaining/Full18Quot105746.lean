import Full18ThinRules3
import Full18ThinRules13
import Full18ThinRules15
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot135871
import PetersenProjectedRule
import Full18StepS105746
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient105746 (h : Needs) : Blocked Root17.tgt 13 live105746 := by
  apply stepS105746
  · change ∀ r ∈ [rule3052,rule8051,rule3064,rule6674,rule3251,rule3073], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live157996], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live157996) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym3] (L := live157996) (V := live135871) (by decide +kernel) (quotient135871 h)) <|
      PetersenLocalChildren.nil
end Full18
