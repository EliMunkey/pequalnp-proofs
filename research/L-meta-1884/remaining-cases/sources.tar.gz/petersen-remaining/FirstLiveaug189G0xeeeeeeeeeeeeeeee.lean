import M189StartLabeled
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveaug189G0xeeeeeeeeeeeeeeee : NoAtMost (0xeeeeeeeeeeeeeeee :: inputs 6) PetersenSmallStarts.M189.tgt 7 := PetersenSmallStarts.M189.all_forbidden 0xeeeeeeeeeeeeeeee (by decide +kernel)
#print axioms theFirstLiveaug189G0xeeeeeeeeeeeeeeee
end PetersenLive8
