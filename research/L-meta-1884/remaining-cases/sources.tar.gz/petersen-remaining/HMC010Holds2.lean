import HMC010Hyp
import M47StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem hold2_0 : NoAtMost (0xf000f0 :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xf000f0 (by decide +kernel)
end MC010Cert
