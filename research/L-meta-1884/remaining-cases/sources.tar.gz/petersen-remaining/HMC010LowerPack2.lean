import HMC010Hyp
import M111StartLabeled
import M127Needed8
import M15StartLabeled
import M47StartLabeled
import M63StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold34_0 : NoAtMost (0xffffffffcccccccc :: inputs 6) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenSmallStarts.M111.all_forbidden 0xffffffffcccccccc (by decide +kernel)

theorem hold35_0 : NoAtMost (0xaaaaaaaa :: inputs 6) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenSmallStarts.M63.all_forbidden 0xaaaaaaaa (by decide +kernel)

theorem hold36_0 : NoAtMost (0x8888888888888888 :: inputs 6) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenSmallStarts.M63.all_forbidden 0x8888888888888888 (by decide +kernel)

theorem hold37_0 : NoAtMost (0xaaaa0000aaaa0000 :: inputs 6) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenSmallStarts.M63.all_forbidden 0xaaaa0000aaaa0000 (by decide +kernel)

theorem hold38_0 : NoAtMost (0xaaaa :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xaaaa (by decide +kernel)
theorem hold38_1 : NoAtMost (0xaaaa0000aaaa :: inputs 6) 0xfffffffffaeaf8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold38_0 <;> decide +kernel

theorem hold39_0 : NoAtMost (0xf000f0 :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xf000f0 (by decide +kernel)
theorem hold39_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffaeaf8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold39_0 <;> decide +kernel

theorem hold40_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold40_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold40_0 <;> decide +kernel
theorem hold40_2 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold40_1 <;> decide +kernel

theorem hold41_0 : NoAtMost (0xa0a :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xa0a (by decide +kernel)
theorem hold41_1 : NoAtMost (0xa0a0a0a :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold41_0 <;> decide +kernel
theorem hold41_2 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold41_1 <;> decide +kernel

theorem hold42_0 : NoAtMost (0x3300 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hold42_1 : NoAtMost (0x33003300 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold42_0 <;> decide +kernel
theorem hold42_2 : NoAtMost (0x3300330033003300 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold42_1 <;> decide +kernel

theorem hold43_0 : NoAtMost (0x4444 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hold43_1 : NoAtMost (0x44444444 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold43_0 <;> decide +kernel
theorem hold43_2 : NoAtMost (0x4444444444444444 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold43_1 <;> decide +kernel

theorem hold44_0 : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: inputs 7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8 := by
  exact PetersenSmallStarts.M127.gate_0_3_0

theorem hold45_0 : NoAtMost (0xffccffccffccffccffccffccffccffcc :: inputs 7) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8 := by
  exact PetersenSmallStarts.M127.First8Support.labeled_1_3_0
end MC010Cert
