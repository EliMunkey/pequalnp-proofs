import HMC010Hyp
import M31StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem hold9_0 : NoAtMost (0xff0000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xff0000 (by decide +kernel)
end MC010Cert
