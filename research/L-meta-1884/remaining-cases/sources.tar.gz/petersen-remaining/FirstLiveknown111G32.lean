import M111StartL6B0
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown111G32 : NoAtMost PetersenSmallStarts.M111.s32 PetersenSmallStarts.M111.tgt 6 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(1,17),(16,17),(1,3),(18,22),(20,28),(18,50)] (by decide +kernel) PetersenSmallStarts.M111.b32
#print axioms theFirstLiveknown111G32
end PetersenLive8
