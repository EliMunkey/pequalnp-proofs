import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP180 : steps180.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES180 : PetersenWordProjection.projectFast steps180 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG180 : PetersenWordProjection.projectFast steps180 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP181 : steps181.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES181 : PetersenWordProjection.projectFast steps181 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG181 : PetersenWordProjection.projectFast steps181 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP183 : steps183.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES183 : PetersenWordProjection.projectFast steps183 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 512)) := by decide +kernel
theorem TG183 : PetersenWordProjection.projectFast steps183 0 Root17.tgt = (0xfffffffffffffffffffffffffffffff8ffffffffffffffffffffffffffc8ffc8fffffffffffffcfcfffffffffffff8f8fffffeeefffffcccfaeafaeaf8c8f8c8 : BitVec 512) := by decide +kernel
theorem SEP184 : steps184.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES184 : PetersenWordProjection.projectFast steps184 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 512)) := by decide +kernel
theorem TG184 : PetersenWordProjection.projectFast steps184 0 Root17.tgt = (0xfffffffffffffffffffffffffffffff8ffffffffffffffffffffffffffc8ffc8fffffffffffffcfcfffffffffffff8f8fffffeeefffffcccfaeafaeaf8c8f8c8 : BitVec 512) := by decide +kernel
theorem SEP186 : steps186.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES186 : PetersenWordProjection.projectFast steps186 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 512)) := by decide +kernel
theorem TG186 : PetersenWordProjection.projectFast steps186 0 Root17.tgt = (0xfffffffffffffffffffffffffffffff8ffffffffffffffffffffffffffc8ffc8fffffffffffffcfcfffffffffffff8f8fffffeeefffffcccfaeafaeaf8c8f8c8 : BitVec 512) := by decide +kernel
theorem SEP187 : steps187.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES187 : PetersenWordProjection.projectFast steps187 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 512)) := by decide +kernel
theorem TG187 : PetersenWordProjection.projectFast steps187 0 Root17.tgt = (0xfffffffffffffffffffffffffffffff8ffffffffffffffffffffffffffc8ffc8fffffffffffffcfcfffffffffffff8f8fffffeeefffffcccfaeafaeaf8c8f8c8 : BitVec 512) := by decide +kernel
end Full18
