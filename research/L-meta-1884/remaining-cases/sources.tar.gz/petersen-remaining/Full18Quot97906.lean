import Full18ThinRules0
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules8
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinSym0
import Full18ThinSym3
import Full18Quot168479
import Full18Quot176567
import PetersenProjectedRule
import Full18StepS97906
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient97906 (h : Needs) : Blocked Root17.tgt 13 live97906 := by
  apply stepS97906
  · change ∀ r ∈ [rule3052,rule991,rule3251,rule3070,rule3073,rule1358,rule7546,rule2560,rule1272,rule2484,rule1385,rule7507,rule3064,rule6682,rule5391,rule6674,rule7510], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule991) (quickSound991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1358) (quickSound1358 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7546) (quickSound7546 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2560) (quickSound2560 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1272) (quickSound1272 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2484) (quickSound2484 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1385) (quickSound1385 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7507) (quickSound7507 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6682) (quickSound6682 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5391) (quickSound5391 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7510) (quickSound7510 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live183068,live182203,live168479], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live183068) (PetersenFastSymmetry.move [thinSym3] (L := live183068) (V := live176567) (by decide +kernel) (quotient176567 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live182203) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live182203) (V := live176567) (by decide +kernel) (quotient176567 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live168479) (quotient168479 h) <|
      PetersenLocalChildren.nil
end Full18
