import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules11
import Full18ThinRules13
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot127163
import Full18Quot135867
import PetersenProjectedRule
import Full18StepS96894
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient96894 (h : Needs) : Blocked Root17.tgt 13 live96894 := by
  apply stepS96894
  · change ∀ r ∈ [rule3051,rule3070,rule3073,rule3260,rule3052,rule3251,rule6074,rule3258,rule8075,rule3064,rule8053,rule6725,rule3255,rule5944,rule6063], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3051) (quickSound3051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3260) (quickSound3260 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6074) (quickSound6074 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3258) (quickSound3258 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8053) (quickSound8053 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6063) (quickSound6063 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live156180,live147786,live130743], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live156180) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live156180) (V := live127163) (by decide +kernel) (quotient127163 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live147786) (PetersenFastSymmetry.move [thinSym3] (L := live147786) (V := live135867) (by decide +kernel) (quotient135867 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live130743) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live130743) (V := live127163) (by decide +kernel) (quotient127163 h)) <|
      PetersenLocalChildren.nil
end Full18
