import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot20
import Full18Quot65
import Full18Quot88
import Full18Quot236
import Full18Quot357
import Full18Quot367
import Full18Quot439
import Full18Quot441
import Full18Quot460
import Full18Quot461
import Full18Quot468
import Full18Quot469
import Full18Quot486
import Full18Quot501
import Full18Quot502
import Full18Quot503
import Full18Quot510
import Full18Quot514
import Full18Quot517
import Full18Quot518
import PetersenProjectedRule
import Full18StepS7
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient7 (h : Needs) : Blocked Root17.tgt 16 live7 := by
  apply stepS7
  · change ∀ r ∈ [rule8051,rule7991,rule3943,rule5209,rule3290,rule5557,rule3250,rule3924,rule6557,rule5881,rule2956], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7991) (quickSound7991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3943) (quickSound3943 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5209) (quickSound5209 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3250) (quickSound3250 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3924) (quickSound3924 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6557) (quickSound6557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5881) (quickSound5881 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2956) (quickSound2956 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live522,live524,live525,live517,live502,live236,live439,live448,live457,live475,live484,live493,live518,live519,live504,live441,live159,live506,live450,live136,live508,live459,live112,live510,live468,live88,live512,live477,live65,live514,live486,live42,live516,live495,live20,live451,live460,live469,live478,live487,live496,live461,live470,live479,live488,live497,live471,live480,live489,live498,live481,live491,live500,live501], Blocked Root17.tgt 15 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live522) (PetersenFastSymmetry.move [thinSym3] (L := live522) (V := live517) (by decide +kernel) (quotient517 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live524) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live524) (V := live518) (by decide +kernel) (quotient518 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live525) (PetersenFastSymmetry.move [thinSym3] (L := live525) (V := live518) (by decide +kernel) (quotient518 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live517) (quotient517 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live502) (quotient502 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live236) (quotient236 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live439) (quotient439 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live448) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live448) (V := live439) (by decide +kernel) (quotient439 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live457) (PetersenFastSymmetry.move [thinSym3] (L := live457) (V := live439) (by decide +kernel) (quotient439 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live475) (PetersenFastSymmetry.move [thinSym0] (L := live475) (V := live439) (by decide +kernel) (quotient439 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live484) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live484) (V := live461) (by decide +kernel) (quotient461 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live493) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live493) (V := live461) (by decide +kernel) (quotient461 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live518) (quotient518 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live519) (PetersenFastSymmetry.move [thinSym0] (L := live519) (V := live518) (by decide +kernel) (quotient518 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live504) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2] (L := live504) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live441) (quotient441 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live159) (PetersenFastSymmetry.move [thinSym0] (L := live159) (V := live65) (by decide +kernel) (quotient65 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live506) (PetersenFastSymmetry.move [thinSym1,thinSym2] (L := live506) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live450) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live450) (V := live441) (by decide +kernel) (quotient441 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live136) (PetersenFastSymmetry.move [thinSym3] (L := live136) (V := live65) (by decide +kernel) (quotient65 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live508) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2] (L := live508) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live459) (PetersenFastSymmetry.move [thinSym3] (L := live459) (V := live441) (by decide +kernel) (quotient441 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live112) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live112) (V := live65) (by decide +kernel) (quotient65 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live510) (quotient510 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live468) (quotient468 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live88) (quotient88 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live512) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2] (L := live512) (V := live503) (by decide +kernel) (quotient503 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live477) (PetersenFastSymmetry.move [thinSym0] (L := live477) (V := live441) (by decide +kernel) (quotient441 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live65) (quotient65 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live514) (quotient514 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live486) (quotient486 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live42) (PetersenFastSymmetry.move [thinSym0] (L := live42) (V := live20) (by decide +kernel) (quotient20 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live516) (PetersenFastSymmetry.move [thinSym0] (L := live516) (V := live514) (by decide +kernel) (quotient514 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live495) (PetersenFastSymmetry.move [thinSym0] (L := live495) (V := live486) (by decide +kernel) (quotient486 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live20) (quotient20 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live451) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3] (L := live451) (V := live357) (by decide +kernel) (quotient357 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live460) (quotient460 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live469) (quotient469 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live478) (PetersenFastSymmetry.move [thinSym3] (L := live478) (V := live461) (by decide +kernel) (quotient461 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live487) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live487) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live496) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1] (L := live496) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live461) (quotient461 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live470) (PetersenFastSymmetry.move [thinSym0,thinSym3] (L := live470) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live479) (PetersenFastSymmetry.move [thinSym0] (L := live479) (V := live460) (by decide +kernel) (quotient460 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live488) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1,thinSym2] (L := live488) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live497) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym3] (L := live497) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live471) (PetersenFastSymmetry.move [thinSym3] (L := live471) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live480) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3] (L := live480) (V := live357) (by decide +kernel) (quotient357 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live489) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym3] (L := live489) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live498) (PetersenFastSymmetry.move [thinSym2,thinSym3,thinSym1,thinSym2] (L := live498) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live481) (PetersenFastSymmetry.move [thinSym0] (L := live481) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live491) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1] (L := live491) (V := live469) (by decide +kernel) (quotient469 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live500) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live500) (V := live367) (by decide +kernel) (quotient367 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 15 s)) (x := live501) (quotient501 h) <|
      PetersenLocalChildren.nil
end Full18
