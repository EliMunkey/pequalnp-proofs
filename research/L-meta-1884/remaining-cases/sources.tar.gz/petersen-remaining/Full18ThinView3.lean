import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP60 : steps60.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES60 : PetersenWordProjection.projectFast steps60 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG60 : PetersenWordProjection.projectFast steps60 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP61 : steps61.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES61 : PetersenWordProjection.projectFast steps61 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG61 : PetersenWordProjection.projectFast steps61 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP62 : steps62.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES62 : PetersenWordProjection.projectFast steps62 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG62 : PetersenWordProjection.projectFast steps62 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP63 : steps63.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES63 : PetersenWordProjection.projectFast steps63 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG63 : PetersenWordProjection.projectFast steps63 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP65 : steps65.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES65 : PetersenWordProjection.projectFast steps65 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG65 : PetersenWordProjection.projectFast steps65 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP66 : steps66.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES66 : PetersenWordProjection.projectFast steps66 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG66 : PetersenWordProjection.projectFast steps66 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP67 : steps67.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES67 : PetersenWordProjection.projectFast steps67 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG67 : PetersenWordProjection.projectFast steps67 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP68 : steps68.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES68 : PetersenWordProjection.projectFast steps68 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG68 : PetersenWordProjection.projectFast steps68 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP69 : steps69.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES69 : PetersenWordProjection.projectFast steps69 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG69 : PetersenWordProjection.projectFast steps69 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP70 : steps70.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES70 : PetersenWordProjection.projectFast steps70 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG70 : PetersenWordProjection.projectFast steps70 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP71 : steps71.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES71 : PetersenWordProjection.projectFast steps71 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG71 : PetersenWordProjection.projectFast steps71 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP72 : steps72.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES72 : PetersenWordProjection.projectFast steps72 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG72 : PetersenWordProjection.projectFast steps72 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP73 : steps73.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES73 : PetersenWordProjection.projectFast steps73 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG73 : PetersenWordProjection.projectFast steps73 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP76 : steps76.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES76 : PetersenWordProjection.projectFast steps76 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG76 : PetersenWordProjection.projectFast steps76 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP77 : steps77.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES77 : PetersenWordProjection.projectFast steps77 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG77 : PetersenWordProjection.projectFast steps77 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP78 : steps78.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES78 : PetersenWordProjection.projectFast steps78 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG78 : PetersenWordProjection.projectFast steps78 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP79 : steps79.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES79 : PetersenWordProjection.projectFast steps79 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG79 : PetersenWordProjection.projectFast steps79 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
end Full18
