import Q1020K12Closing
import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown1020G3X2175 : NoAtMost Orbits1020Cost12.s3_2175 Orbits1020Cost12.tgt 9 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(64,80),(18,19),(17,19),(18,22),(48,56),(17,49),(16,80),(16,144)] (by decide +kernel) (Orbits1020Cost12.b3_2175 ThetaCert.bound)
#print axioms theFirstLiveknown1020G3X2175
end PetersenLive8
