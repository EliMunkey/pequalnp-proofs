import HEX010G1
import HEX010G2
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r31 := EX010Cert.r31
abbrev stages31 := EX010Cert.stages31
theorem rowOk31 : PetersenWordProjection.check stages31 128 r31 = true := EX010Cert.rowOk31
theorem hot31 : forcedConst r31 tgt = false := EX010Cert.hot31
theorem match31 : PetersenPackedPin.project r31 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match31
abbrev r32 := EX010Cert.r32
abbrev stages32 := EX010Cert.stages32
theorem rowOk32 : PetersenWordProjection.check stages32 0 r32 = true := EX010Cert.rowOk32
theorem hot32 : forcedConst r32 tgt = false := EX010Cert.hot32
theorem match32 : PetersenPackedPin.project r32 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match32
abbrev r33 := EX010Cert.r33
abbrev stages33 := EX010Cert.stages33
theorem rowOk33 : PetersenWordProjection.check stages33 128 r33 = true := EX010Cert.rowOk33
theorem hot33 : forcedConst r33 tgt = false := EX010Cert.hot33
theorem match33 : PetersenPackedPin.project r33 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match33
abbrev r34 := EX010Cert.r34
abbrev stages34 := EX010Cert.stages34
theorem rowOk34 : PetersenWordProjection.check stages34 0 r34 = true := EX010Cert.rowOk34
theorem hot34 : forcedConst r34 tgt = false := EX010Cert.hot34
theorem match34 : PetersenPackedPin.project r34 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match34
abbrev r35 := EX010Cert.r35
abbrev stages35 := EX010Cert.stages35
theorem rowOk35 : PetersenWordProjection.check stages35 128 r35 = true := EX010Cert.rowOk35
theorem hot35 : forcedConst r35 tgt = false := EX010Cert.hot35
theorem match35 : PetersenPackedPin.project r35 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match35
def r36 (i : Fin 128) : Fin 256 := (#[0,2,64,66,16,18,80,82,128,130,192,194,144,146,208,210,4,6,68,70,20,22,84,86,132,134,196,198,148,150,212,214,1,3,65,67,17,19,81,83,129,131,193,195,145,147,209,211,5,7,69,71,21,23,85,87,133,135,197,199,149,151,213,215,8,10,72,74,24,26,88,90,136,138,200,202,152,154,216,218,12,14,76,78,28,30,92,94,140,142,204,206,156,158,220,222,9,11,73,75,25,27,89,91,137,139,201,203,153,155,217,219,13,15,77,79,29,31,93,95,141,143,205,207,157,159,221,223] : Array (Fin 256))[i.val]?.getD 0
def stages36 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x78,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00000000000000000000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff0000ff00ff00ff00ff00ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk36 : PetersenWordProjection.check stages36 0 r36 = true := by decide +kernel
theorem hot36 : forcedConst r36 tgt = false := by decide +kernel
theorem match36 : PetersenPackedPin.project r36 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
abbrev r37 := EX010Cert.r37
abbrev stages37 := EX010Cert.stages37
theorem rowOk37 : PetersenWordProjection.check stages37 128 r37 = true := EX010Cert.rowOk37
theorem hot37 : forcedConst r37 tgt = false := EX010Cert.hot37
theorem match37 : PetersenPackedPin.project r37 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match37
abbrev r38 := EX010Cert.r38
abbrev stages38 := EX010Cert.stages38
theorem rowOk38 : PetersenWordProjection.check stages38 0 r38 = true := EX010Cert.rowOk38
theorem hot38 : forcedConst r38 tgt = false := EX010Cert.hot38
theorem match38 : PetersenPackedPin.project r38 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match38
abbrev r39 := EX010Cert.r39
abbrev stages39 := EX010Cert.stages39
theorem rowOk39 : PetersenWordProjection.check stages39 128 r39 = true := EX010Cert.rowOk39
theorem hot39 : forcedConst r39 tgt = false := EX010Cert.hot39
theorem match39 : PetersenPackedPin.project r39 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match39
abbrev r40 := EX010Cert.r40
abbrev stages40 := EX010Cert.stages40
theorem rowOk40 : PetersenWordProjection.check stages40 0 r40 = true := EX010Cert.rowOk40
theorem hot40 : forcedConst r40 tgt = false := EX010Cert.hot40
theorem match40 : PetersenPackedPin.project r40 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match40
abbrev r41 := EX010Cert.r41
abbrev stages41 := EX010Cert.stages41
theorem rowOk41 : PetersenWordProjection.check stages41 128 r41 = true := EX010Cert.rowOk41
theorem hot41 : forcedConst r41 tgt = false := EX010Cert.hot41
theorem match41 : PetersenPackedPin.project r41 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match41
abbrev r42 := EX010Cert.r42
abbrev stages42 := EX010Cert.stages42
theorem rowOk42 : PetersenWordProjection.check stages42 128 r42 = true := EX010Cert.rowOk42
theorem hot42 : forcedConst r42 tgt = false := EX010Cert.hot42
theorem match42 : PetersenPackedPin.project r42 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match42
end MC161RCert
