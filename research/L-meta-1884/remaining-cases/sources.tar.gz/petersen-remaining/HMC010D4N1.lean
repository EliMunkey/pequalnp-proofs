import HMC010Hyp
import HMC010Sym
import HMC010W0
import HMC010W1
import HMC010W2
import HMC010W3
import first8.MixedPair
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def s4_4545 : List (BitVec 256) := [w110,w517,w572,w644,w680,w720,w778,w880]
private theorem p4_4545_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,1156,515,1412,1413,4627,515,1413,515,643,1156,4627]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,1156,259,4242,4754,4371,259,4754,259,387,1156,4371]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4240,518,1156,1156,4630,132,1156,518,132,4240,4630]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,1156,49352,3204,3212,8232,1164,3212,49352,1156,1156,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,1156,144,4240,4240,5252,144,4240,144,1156,1156,5252]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,1156,160,4272,8352,4401,160,8352,160,289,1156,4401]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w110,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,1156,706,4176,17604,4176,578,17604,706,578,1156,4176]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1030,8225,1030,259,515,259,3,515,1030,3,8225,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,515,518,9249,9253,33157,518,9253,518,515,515,33157]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,515,8232,2563,2571,16713,523,2571,8232,515,515,16713]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,515,144,400,4627,401,144,4627,144,145,515,401]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,515,160,416,8225,417,160,8225,160,161,515,417]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w517,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,515,706,1476,24673,1477,706,24673,706,515,515,1477]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,32900,518,1030,518,6,1030,32900,6,259,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,8232,2307,2315,8746,267,2315,8232,259,259,8746]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,259,144,656,4371,658,144,4371,144,146,259,658]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,259,160,672,9254,674,160,9254,160,162,259,674]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,1220,706,16450,706,194,16450,1220,194,259,706]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,518,8232,2566,2574,9260,526,2574,8232,518,518,9260]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,518,144,1168,4630,1172,144,4630,144,148,518,1172]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,518,160,1184,8742,1188,160,8742,160,164,518,1188]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,518,706,1220,49348,1220,196,49348,706,196,518,1220]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,8232,144,2192,12344,2200,144,12344,144,152,8232,2200]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,16456,160,2208,8232,2216,160,8232,160,168,16456,2216]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,8232,706,2248,16456,2248,200,16456,706,200,8232,2248]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,144,160,4385,24688,4401,160,24688,160,144,144,4401]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [144,144,706,4176,16464,4176,208,16464,706,144,144,4176]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4545_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4545 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,160,706,8770,16737,8802,224,16737,706,160,160,8802]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_4545 [Assumptions] : Blocked tgt 8 s4_4545 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w110,w517),(w110,w572),(w110,w644),(w110,w680),(w110,w720),(w110,w778),(w110,w880),(w517,w572),(w517,w644),(w517,w680),(w517,w720),(w517,w778),(w517,w880),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w680,w720),(w680,w778),(w680,w880),(w720,w778),(w720,w880),(w778,w880)], PetersenLocalChildren.PairOK tgt 7 s4_4545 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w517)) p4_4545_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w572)) p4_4545_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w644)) p4_4545_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w680)) p4_4545_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w720)) p4_4545_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w778)) p4_4545_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w110,w880)) p4_4545_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w572)) p4_4545_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w644)) p4_4545_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w680)) p4_4545_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w720)) p4_4545_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w778)) p4_4545_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w517,w880)) p4_4545_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w572,w644)) p4_4545_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w572,w680)) p4_4545_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w572,w720)) p4_4545_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w572,w778)) p4_4545_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w572,w880)) p4_4545_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w644,w680)) p4_4545_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w644,w720)) p4_4545_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w644,w778)) p4_4545_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w644,w880)) p4_4545_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w680,w720)) p4_4545_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w680,w778)) p4_4545_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w680,w880)) p4_4545_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w720,w778)) p4_4545_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w720,w880)) p4_4545_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4545) (x := (w778,w880)) p4_4545_27 <|
    PetersenLocalChildren.nil
def s4_4557 : List (BitVec 256) := [w112,w517,w572,w644,w680,w720,w778,w880]
private theorem p4_4557_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [643,1156,643,1412,1413,1412,515,1413,643,515,1156,1412]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [387,1156,1030,259,4754,259,1030,4754,1030,259,1156,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [389,4240,518,389,1156,8742,132,1156,518,132,4240,8742]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,1156,49352,1421,3212,8232,1164,3212,49352,1156,1156,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [401,1156,33169,401,4240,16464,144,4240,33169,144,1156,16464]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,1156,160,289,8352,289,160,8352,160,289,1156,289]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w112,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,1156,706,1477,17604,2377,578,17604,706,578,1156,2377]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1030,1157,1030,259,643,259,131,643,1030,131,1157,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [388,643,518,388,1157,33157,133,1157,518,133,643,33157]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [643,643,8232,1420,2699,16713,651,2699,8232,643,643,16713]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [400,643,16464,400,4241,16721,145,4241,16464,145,643,16721]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,643,160,289,8225,289,160,8225,160,161,643,289]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w517,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [643,643,706,2376,24673,2377,706,24673,706,643,643,2377]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,32900,518,1030,518,6,1030,32900,6,259,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,8232,2307,2315,8746,267,2315,8232,259,259,8746]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,16464,4355,4371,33426,275,4371,16464,259,259,33426]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,259,160,672,9254,674,160,9254,160,162,259,674]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,259,1220,706,16450,706,194,16450,1220,194,259,706]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,518,8232,2566,2574,9260,526,2574,8232,518,518,9260]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,518,16464,4614,4630,17492,534,4630,16464,518,518,17492]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,518,160,1184,8742,1188,160,8742,160,164,518,1188]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,518,706,1220,49348,1220,196,49348,706,196,518,1220]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,8232,16464,12328,12344,34968,8248,12344,16464,8232,8232,34968]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,16456,160,2208,8232,2216,160,8232,160,168,16456,2216]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,8232,706,2248,16456,2248,200,16456,706,200,8232,2248]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,16464,160,4256,24688,4272,160,24688,160,176,16464,4272]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,32912,706,4304,16464,4304,208,16464,706,208,32912,4304]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4557_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4557 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,160,706,8770,16737,8802,224,16737,706,160,160,8802]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_4557 [Assumptions] : Blocked tgt 8 s4_4557 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w112,w517),(w112,w572),(w112,w644),(w112,w680),(w112,w720),(w112,w778),(w112,w880),(w517,w572),(w517,w644),(w517,w680),(w517,w720),(w517,w778),(w517,w880),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w680,w720),(w680,w778),(w680,w880),(w720,w778),(w720,w880),(w778,w880)], PetersenLocalChildren.PairOK tgt 7 s4_4557 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w517)) p4_4557_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w572)) p4_4557_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w644)) p4_4557_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w680)) p4_4557_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w720)) p4_4557_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w778)) p4_4557_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w112,w880)) p4_4557_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w572)) p4_4557_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w644)) p4_4557_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w680)) p4_4557_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w720)) p4_4557_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w778)) p4_4557_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w517,w880)) p4_4557_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w572,w644)) p4_4557_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w572,w680)) p4_4557_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w572,w720)) p4_4557_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w572,w778)) p4_4557_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w572,w880)) p4_4557_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w644,w680)) p4_4557_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w644,w720)) p4_4557_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w644,w778)) p4_4557_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w644,w880)) p4_4557_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w680,w720)) p4_4557_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w680,w778)) p4_4557_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w680,w880)) p4_4557_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w720,w778)) p4_4557_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w720,w880)) p4_4557_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4557) (x := (w778,w880)) p4_4557_27 <|
    PetersenLocalChildren.nil
def s4_4571 : List (BitVec 256) := [w115,w517,w572,w644,w680,w720,w778,w880,w977]
private theorem p4_4571_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12337,515,12337,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [13366,9254,259,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12854,518,12854,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12344,8232,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,16464,32912,33426]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4401,2602,289,289]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4176,578,2120,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w115,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,1156,4754]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8225,515,515,8225]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,9249,518,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,2563,523,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4611,531,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4401,547,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4432,578,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w517,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,1412,643,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16450,518,8230,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,8744,8232,8234]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [9254,13366,13366,9254]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2600,2600,4401,2602]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2632,578,4176,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w572,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,1156,4754]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,2566,526,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4614,534,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5425,550,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5200,578,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w644,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12344,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4401,2602,554,554]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,2626,578,586]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w680,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,3204,1156,1164]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2602,4401,305,305]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,4176,80,80]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w720,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,8770,578,610]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w778,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,12432,160,160]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4571_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4571 (w880,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,33346,1156,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_4571 [Assumptions] : Blocked tgt 8 s4_4571 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w115,w517),(w115,w572),(w115,w644),(w115,w680),(w115,w720),(w115,w778),(w115,w880),(w115,w977),(w517,w572),(w517,w644),(w517,w680),(w517,w720),(w517,w778),(w517,w880),(w517,w977),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w572,w977),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w644,w977),(w680,w720),(w680,w778),(w680,w880),(w680,w977),(w720,w778),(w720,w880),(w720,w977),(w778,w880),(w778,w977),(w880,w977)], PetersenLocalChildren.PairOK tgt 7 s4_4571 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w517)) p4_4571_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w572)) p4_4571_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w644)) p4_4571_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w680)) p4_4571_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w720)) p4_4571_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w778)) p4_4571_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w880)) p4_4571_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w115,w977)) p4_4571_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w572)) p4_4571_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w644)) p4_4571_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w680)) p4_4571_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w720)) p4_4571_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w778)) p4_4571_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w880)) p4_4571_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w517,w977)) p4_4571_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w644)) p4_4571_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w680)) p4_4571_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w720)) p4_4571_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w778)) p4_4571_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w880)) p4_4571_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w572,w977)) p4_4571_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w644,w680)) p4_4571_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w644,w720)) p4_4571_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w644,w778)) p4_4571_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w644,w880)) p4_4571_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w644,w977)) p4_4571_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w680,w720)) p4_4571_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w680,w778)) p4_4571_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w680,w880)) p4_4571_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w680,w977)) p4_4571_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w720,w778)) p4_4571_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w720,w880)) p4_4571_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w720,w977)) p4_4571_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w778,w880)) p4_4571_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w778,w977)) p4_4571_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4571) (x := (w880,w977)) p4_4571_35 <|
    PetersenLocalChildren.nil
def s4_4592 : List (BitVec 256) := [w118,w517,w572,w625,w644,w680,w720,w778,w880]
private theorem p4_4592_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,1413,515,643]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,4754,259,387]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w625) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,1413,1413,1156]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,3204,1164,1156]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,8352,160,289]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w118,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,8416,578,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1286,515,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w625) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,8225]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,33157,518,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,2563,523,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4611,531,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,417,160,417]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w517,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,1477,706,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w625) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,1030]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,518,263,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,2307,267,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,4355,275,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,674,160,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [259,706,451,259]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w625,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [32900,518,32900,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w625,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,8746,8232,8746]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w625,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,16721,16464,16721]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w625,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,417,160,417]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w625,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1220,706,1220,706]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,2566,526,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4614,534,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,1184,160,164]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1220,196,196]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12328,8248,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,2208,160,168]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,2248,200,200]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,4256,160,176]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [706,4304,208,208]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_4592_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_4592 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [160,8770,224,160]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_4592 [Assumptions] : Blocked tgt 8 s4_4592 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w118,w517),(w118,w572),(w118,w625),(w118,w644),(w118,w680),(w118,w720),(w118,w778),(w118,w880),(w517,w572),(w517,w625),(w517,w644),(w517,w680),(w517,w720),(w517,w778),(w517,w880),(w572,w625),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w625,w644),(w625,w680),(w625,w720),(w625,w778),(w625,w880),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w680,w720),(w680,w778),(w680,w880),(w720,w778),(w720,w880),(w778,w880)], PetersenLocalChildren.PairOK tgt 7 s4_4592 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w517)) p4_4592_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w572)) p4_4592_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w625)) p4_4592_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w644)) p4_4592_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w680)) p4_4592_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w720)) p4_4592_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w778)) p4_4592_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w118,w880)) p4_4592_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w572)) p4_4592_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w625)) p4_4592_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w644)) p4_4592_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w680)) p4_4592_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w720)) p4_4592_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w778)) p4_4592_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w517,w880)) p4_4592_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w625)) p4_4592_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w644)) p4_4592_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w680)) p4_4592_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w720)) p4_4592_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w778)) p4_4592_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w572,w880)) p4_4592_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w625,w644)) p4_4592_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w625,w680)) p4_4592_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w625,w720)) p4_4592_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w625,w778)) p4_4592_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w625,w880)) p4_4592_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w644,w680)) p4_4592_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w644,w720)) p4_4592_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w644,w778)) p4_4592_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w644,w880)) p4_4592_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w680,w720)) p4_4592_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w680,w778)) p4_4592_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w680,w880)) p4_4592_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w720,w778)) p4_4592_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w720,w880)) p4_4592_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_4592) (x := (w778,w880)) p4_4592_35 <|
    PetersenLocalChildren.nil
end MC010Cert
