import Extra1020K12
import HMC010G0
import HMC010G1
import HMC010G2
import HMC010G3
import HMC010G4
import HMC010G5
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule518 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages22 s.steps 0 6 (0xcccccccc :: i6) p
theorem correct518 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule518 s p) tgt := by
  have small : NoAtMost (0xcccccccc :: i6) (PetersenPackedPin.project r22 tgt) 6 := by rw [match22]; exact Assumptions.h30
  intro d L hit
  exact PetersenRoutedPin.quick rowOk22 s small hot22 p hit
def rule519 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xa0a0a0a :: i5) p
theorem correct519 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule519 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h10
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule520 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xc0c0c0c :: i5) p
theorem correct520 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule520 s p) tgt := by
  have small : NoAtMost (0xc0c0c0c :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h11
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule521 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages4 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct521 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule521 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r4 tgt) 7 := by rw [match4]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk4 s small hot4 p hit
def rule522 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages40 s.steps 0 8 (0xffccffccffccffccffccffccffccffcc :: i7) p
theorem correct522 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule522 s p) tgt := by
  have small : NoAtMost (0xffccffccffccffccffccffccffccffcc :: i7) (PetersenPackedPin.project r40 tgt) 8 := by rw [match40]; exact Assumptions.h45
  intro d L hit
  exact PetersenRoutedPin.quick rowOk40 s small hot40 p hit
def rule523 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0x33330000 :: i5) p
theorem correct523 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule523 s p) tgt := by
  have small : NoAtMost (0x33330000 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h16
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule524 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xf000f0 :: i5) p
theorem correct524 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule524 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h8
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule525 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages116 s.steps 128 5 (0xf000f000f000f0 :: i6) p
theorem correct525 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule525 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r116 tgt) 5 := by rw [match116]; exact Assumptions.h40
  intro d L hit
  exact PetersenRoutedPin.quick rowOk116 s small hot116 p hit
def rule526 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xaa00aa :: i5) p
theorem correct526 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule526 s p) tgt := by
  have small : NoAtMost (0xaa00aa :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h6
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule527 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0x30303030 :: i5) p
theorem correct527 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule527 s p) tgt := by
  have small : NoAtMost (0x30303030 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h14
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule528 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages11 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct528 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule528 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r11 tgt) 7 := by rw [match11]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk11 s small hot11 p hit
def rule529 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) p
theorem correct529 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule529 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: i7) (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Assumptions.h50
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule530 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages74 s.steps 128 5 (0xa0a0a0a0a0a0a0a :: i6) p
theorem correct530 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule530 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a :: i6) (PetersenPackedPin.project r74 tgt) 5 := by rw [match74]; exact Assumptions.h41
  intro d L hit
  exact PetersenRoutedPin.quick rowOk74 s small hot74 p hit
def rule531 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xf000f0 :: i5) p
theorem correct531 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule531 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h8
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule532 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xf0f00000f0f00000f0f00000f0f0 :: i7) p
theorem correct532 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule532 s p) tgt := by
  have small : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h51
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule533 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xf000f000f000f000f000f000f000f0 :: i7) p
theorem correct533 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule533 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f000f000f000f000f0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h53
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule534 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages20 s.steps 0 6 (0xf0f0f0f00000000 :: i6) p
theorem correct534 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule534 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f00000000 :: i6) (PetersenPackedPin.project r20 tgt) 6 := by rw [match20]; exact Assumptions.h32
  intro d L hit
  exact PetersenRoutedPin.quick rowOk20 s small hot20 p hit
def rule535 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xf0f0000 :: i5) p
theorem correct535 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule535 s p) tgt := by
  have small : NoAtMost (0xf0f0000 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h13
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule536 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xfff0fff0 :: i5) p
theorem correct536 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule536 s p) tgt := by
  have small : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h23
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule537 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 (0x55550000 :: i5) p
theorem correct537 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule537 s p) tgt := by
  have small : NoAtMost (0x55550000 :: i5) (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact Assumptions.h19
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
end MC010Cert
