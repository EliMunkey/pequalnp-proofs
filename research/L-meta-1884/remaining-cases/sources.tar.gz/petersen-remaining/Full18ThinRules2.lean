import PetersenProjectedRule
import Full18FastBases
import Full18Data2
import Full18ThinView4
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound2398 (h : Needs) : Correct rule2398 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2398) (t := Root17.tgt) SEP94 ONES94 thinBasis23 TG94 (baseThin23 h) (by decide +kernel) [(false,(4,true),(2,true)),(false,(7,true),(4,true))] rfl (by decide +kernel)
theorem quickSound2406 (h : Needs) : Correct rule2406 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2406) (t := Root17.tgt) SEP94 ONES94 thinBasis1 TG94 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2409 (h : Needs) : Correct rule2409 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2409) (t := Root17.tgt) SEP94 ONES94 thinBasis1 TG94 (baseThin1 h) (by decide +kernel) [(false,(4,true),(2,true))] rfl (by decide +kernel)
theorem quickSound2418 (h : Needs) : Correct rule2418 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2418) (t := Root17.tgt) SEP94 ONES94 thinBasis24 TG94 (baseThin24 h) (by decide +kernel) [(false,(4,true),(2,true)),(false,(7,true),(4,true))] rfl (by decide +kernel)
theorem quickSound2433 (h : Needs) : Correct rule2433 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2433) (t := Root17.tgt) SEP120 ONES120 thinBasis5 TG120 (baseThin5 h) (by decide +kernel) [(false,(6,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2434 (h : Needs) : Correct rule2434 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2434) (t := Root17.tgt) SEP120 ONES120 thinBasis5 TG120 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2481 (h : Needs) : Correct rule2481 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2481) (t := Root17.tgt) SEP91 ONES91 thinBasis2 TG91 (baseThin2 h) (by decide +kernel) [(false,(2,true),(8,true)),(false,(7,true),(8,true)),(false,(10,true),(9,true))] rfl (by decide +kernel)
theorem quickSound2484 (h : Needs) : Correct rule2484 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2484) (t := Root17.tgt) SEP91 ONES91 thinBasis2 TG91 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true)),(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound2486 (h : Needs) : Correct rule2486 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2486) (t := Root17.tgt) SEP91 ONES91 thinBasis2 TG91 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2502 (h : Needs) : Correct rule2502 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2502) (t := Root17.tgt) SEP91 ONES91 thinBasis4 TG91 (baseThin4 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2522 (h : Needs) : Correct rule2522 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2522) (t := Root17.tgt) SEP120 ONES120 thinBasis2 TG120 (baseThin2 h) (by decide +kernel) [(false,(3,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2529 (h : Needs) : Correct rule2529 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2529) (t := Root17.tgt) SEP120 ONES120 thinBasis2 TG120 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2556 (h : Needs) : Correct rule2556 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2556) (t := Root17.tgt) SEP120 ONES120 thinBasis13 TG120 (baseThin13 h) (by decide +kernel) [(false,(2,true),(8,true)),(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2558 (h : Needs) : Correct rule2558 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2558) (t := Root17.tgt) SEP120 ONES120 thinBasis13 TG120 (baseThin13 h) (by decide +kernel) [(false,(1,true),(8,true)),(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2560 (h : Needs) : Correct rule2560 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2560) (t := Root17.tgt) SEP120 ONES120 thinBasis13 TG120 (baseThin13 h) (by decide +kernel) [(false,(1,true),(8,true)),(false,(3,true),(9,true)),(false,(4,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2564 (h : Needs) : Correct rule2564 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2564) (t := Root17.tgt) SEP120 ONES120 thinBasis13 TG120 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true)),(false,(6,true),(7,true)),(false,(8,true),(9,true))] rfl (by decide +kernel)
theorem quickSound2631 (h : Needs) : Correct rule2631 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2631) (t := Root17.tgt) SEP158 ONES158 thinBasis5 TG158 (baseThin5 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound2633 (h : Needs) : Correct rule2633 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2633) (t := Root17.tgt) SEP158 ONES158 thinBasis5 TG158 (baseThin5 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2638 (h : Needs) : Correct rule2638 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2638) (t := Root17.tgt) SEP158 ONES158 thinBasis5 TG158 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2654 (h : Needs) : Correct rule2654 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2654) (t := Root17.tgt) SEP162 ONES162 thinBasis5 TG162 (baseThin5 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2732 (h : Needs) : Correct rule2732 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2732) (t := Root17.tgt) SEP158 ONES158 thinBasis2 TG158 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2790 (h : Needs) : Correct rule2790 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2790) (t := Root17.tgt) SEP154 ONES154 thinBasis2 TG154 (baseThin2 h) (by decide +kernel) [(false,(5,true),(4,true)),(false,(4,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2812 (h : Needs) : Correct rule2812 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2812) (t := Root17.tgt) SEP154 ONES154 thinBasis2 TG154 (baseThin2 h) (by decide +kernel) [(false,(4,true),(0,true)),(false,(9,true),(1,true))] rfl (by decide +kernel)
theorem quickSound2815 (h : Needs) : Correct rule2815 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2815) (t := Root17.tgt) SEP154 ONES154 thinBasis2 TG154 (baseThin2 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound2827 (h : Needs) : Correct rule2827 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2827) (t := Root17.tgt) SEP154 ONES154 thinBasis2 TG154 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound2897 (h : Needs) : Correct rule2897 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2897) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(0,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2918 (h : Needs) : Correct rule2918 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2918) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound2938 (h : Needs) : Correct rule2938 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2938) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(5,true),(2,true))] rfl (by decide +kernel)
theorem quickSound2943 (h : Needs) : Correct rule2943 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2943) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2951 (h : Needs) : Correct rule2951 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2951) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(7,true),(6,true))] rfl (by decide +kernel)
theorem quickSound2953 (h : Needs) : Correct rule2953 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2953) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [(false,(7,true),(8,true))] rfl (by decide +kernel)
theorem quickSound2956 (h : Needs) : Correct rule2956 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule2956) (t := Root17.tgt) SEP93 ONES93 thinBasis13 TG93 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
