import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules8
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot112718
import Full18Quot112934
import Full18Quot113205
import PetersenProjectedRule
import Full18StepS21503
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21503 (h : Needs) : Blocked Root17.tgt 14 live21503 := by
  apply stepS21503
  · change ∀ r ∈ [rule3052,rule3064,rule8051,rule3290,rule3251,rule5317,rule7992,rule2943,rule2434,rule7443,rule6716,rule8054,rule5825,rule6590,rule3706,rule3063,rule6082,rule8064,rule8067,rule7469,rule2827], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3290) (quickSound3290 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5317) (quickSound5317 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7992) (quickSound7992 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2943) (quickSound2943 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2434) (quickSound2434 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6716) (quickSound6716 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8054) (quickSound8054 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5825) (quickSound5825 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3706) (quickSound3706 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8064) (quickSound8064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8067) (quickSound8067 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2827) (quickSound2827 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live121580,live115093,live112934], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live121580) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live121580) (V := live113205) (by decide +kernel) (quotient113205 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live115093) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym3] (L := live115093) (V := live112718) (by decide +kernel) (quotient112718 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112934) (quotient112934 h) <|
      PetersenLocalChildren.nil
end Full18
