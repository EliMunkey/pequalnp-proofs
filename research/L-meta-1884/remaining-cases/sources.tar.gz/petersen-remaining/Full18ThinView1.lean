import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP20 : steps20.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES20 : PetersenWordProjection.projectFast steps20 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG20 : PetersenWordProjection.projectFast steps20 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP21 : steps21.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES21 : PetersenWordProjection.projectFast steps21 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG21 : PetersenWordProjection.projectFast steps21 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP22 : steps22.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES22 : PetersenWordProjection.projectFast steps22 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG22 : PetersenWordProjection.projectFast steps22 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP23 : steps23.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES23 : PetersenWordProjection.projectFast steps23 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG23 : PetersenWordProjection.projectFast steps23 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP24 : steps24.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES24 : PetersenWordProjection.projectFast steps24 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG24 : PetersenWordProjection.projectFast steps24 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP25 : steps25.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES25 : PetersenWordProjection.projectFast steps25 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG25 : PetersenWordProjection.projectFast steps25 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP26 : steps26.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES26 : PetersenWordProjection.projectFast steps26 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG26 : PetersenWordProjection.projectFast steps26 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP28 : steps28.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES28 : PetersenWordProjection.projectFast steps28 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG28 : PetersenWordProjection.projectFast steps28 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP29 : steps29.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES29 : PetersenWordProjection.projectFast steps29 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG29 : PetersenWordProjection.projectFast steps29 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP30 : steps30.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES30 : PetersenWordProjection.projectFast steps30 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG30 : PetersenWordProjection.projectFast steps30 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP31 : steps31.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES31 : PetersenWordProjection.projectFast steps31 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG31 : PetersenWordProjection.projectFast steps31 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP32 : steps32.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES32 : PetersenWordProjection.projectFast steps32 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG32 : PetersenWordProjection.projectFast steps32 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP33 : steps33.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES33 : PetersenWordProjection.projectFast steps33 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG33 : PetersenWordProjection.projectFast steps33 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP34 : steps34.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES34 : PetersenWordProjection.projectFast steps34 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG34 : PetersenWordProjection.projectFast steps34 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP35 : steps35.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES35 : PetersenWordProjection.projectFast steps35 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG35 : PetersenWordProjection.projectFast steps35 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP36 : steps36.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES36 : PetersenWordProjection.projectFast steps36 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG36 : PetersenWordProjection.projectFast steps36 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP37 : steps37.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES37 : PetersenWordProjection.projectFast steps37 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG37 : PetersenWordProjection.projectFast steps37 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP38 : steps38.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES38 : PetersenWordProjection.projectFast steps38 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG38 : PetersenWordProjection.projectFast steps38 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP39 : steps39.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES39 : PetersenWordProjection.projectFast steps39 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG39 : PetersenWordProjection.projectFast steps39 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
end Full18
