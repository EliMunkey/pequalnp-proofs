import PetersenProjectedRule
import Full18FastBases
import Full18Data4
import Full18Data5
import Full18ThinView5
import Full18ThinView6
import Full18ThinView8
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound4367 (h : Needs) : Correct rule4367 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4367) (t := Root17.tgt) SEP176 ONES176 thinBasis2 TG176 (baseThin2 h) (by decide +kernel) [(false,(4,true),(2,true))] rfl (by decide +kernel)
theorem quickSound4381 (h : Needs) : Correct rule4381 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4381) (t := Root17.tgt) SEP122 ONES122 thinBasis2 TG122 (baseThin2 h) (by decide +kernel) [(false,(4,true),(3,true)),(false,(7,true),(4,true))] rfl (by decide +kernel)
theorem quickSound4396 (h : Needs) : Correct rule4396 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4396) (t := Root17.tgt) SEP122 ONES122 thinBasis2 TG122 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4976 (h : Needs) : Correct rule4976 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4976) (t := Root17.tgt) SEP101 ONES101 thinBasis5 TG101 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4984 (h : Needs) : Correct rule4984 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4984) (t := Root17.tgt) SEP101 ONES101 thinBasis14 TG101 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4989 (h : Needs) : Correct rule4989 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4989) (t := Root17.tgt) SEP101 ONES101 thinBasis13 TG101 (baseThin13 h) (by decide +kernel) [(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound4991 (h : Needs) : Correct rule4991 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4991) (t := Root17.tgt) SEP101 ONES101 thinBasis13 TG101 (baseThin13 h) (by decide +kernel) [(false,(2,true),(5,true))] rfl (by decide +kernel)
theorem quickSound4994 (h : Needs) : Correct rule4994 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4994) (t := Root17.tgt) SEP101 ONES101 thinBasis13 TG101 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound4997 (h : Needs) : Correct rule4997 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4997) (t := Root17.tgt) SEP105 ONES105 thinBasis5 TG105 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound4998 (h : Needs) : Correct rule4998 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule4998) (t := Root17.tgt) SEP105 ONES105 thinBasis5 TG105 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5005 (h : Needs) : Correct rule5005 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5005) (t := Root17.tgt) SEP101 ONES101 thinBasis1 TG101 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5006 (h : Needs) : Correct rule5006 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5006) (t := Root17.tgt) SEP101 ONES101 thinBasis1 TG101 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5025 (h : Needs) : Correct rule5025 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5025) (t := Root17.tgt) SEP118 ONES118 thinBasis5 TG118 (baseThin5 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5032 (h : Needs) : Correct rule5032 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5032) (t := Root17.tgt) SEP118 ONES118 thinBasis5 TG118 (baseThin5 h) (by decide +kernel) [(false,(7,true),(6,true)),(false,(7,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5033 (h : Needs) : Correct rule5033 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5033) (t := Root17.tgt) SEP118 ONES118 thinBasis5 TG118 (baseThin5 h) (by decide +kernel) [(false,(7,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5039 (h : Needs) : Correct rule5039 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5039) (t := Root17.tgt) SEP118 ONES118 thinBasis5 TG118 (baseThin5 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5040 (h : Needs) : Correct rule5040 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5040) (t := Root17.tgt) SEP118 ONES118 thinBasis5 TG118 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5048 (h : Needs) : Correct rule5048 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5048) (t := Root17.tgt) SEP118 ONES118 thinBasis14 TG118 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5054 (h : Needs) : Correct rule5054 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5054) (t := Root17.tgt) SEP181 ONES181 thinBasis1 TG181 (baseThin1 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound5057 (h : Needs) : Correct rule5057 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5057) (t := Root17.tgt) SEP181 ONES181 thinBasis1 TG181 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5061 (h : Needs) : Correct rule5061 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5061) (t := Root17.tgt) SEP138 ONES138 thinBasis1 TG138 (baseThin1 h) (by decide +kernel) [(false,(0,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5077 (h : Needs) : Correct rule5077 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5077) (t := Root17.tgt) SEP138 ONES138 thinBasis1 TG138 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5099 (h : Needs) : Correct rule5099 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5099) (t := Root17.tgt) SEP101 ONES101 thinBasis2 TG101 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound5104 (h : Needs) : Correct rule5104 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5104) (t := Root17.tgt) SEP101 ONES101 thinBasis2 TG101 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5107 (h : Needs) : Correct rule5107 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5107) (t := Root17.tgt) SEP101 ONES101 thinBasis2 TG101 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5115 (h : Needs) : Correct rule5115 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5115) (t := Root17.tgt) SEP101 ONES101 thinBasis7 TG101 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5156 (h : Needs) : Correct rule5156 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5156) (t := Root17.tgt) SEP101 ONES101 thinBasis4 TG101 (baseThin4 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5164 (h : Needs) : Correct rule5164 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5164) (t := Root17.tgt) SEP101 ONES101 thinBasis16 TG101 (baseThin16 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5174 (h : Needs) : Correct rule5174 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5174) (t := Root17.tgt) SEP118 ONES118 thinBasis2 TG118 (baseThin2 h) (by decide +kernel) [(false,(0,false),(5,true))] rfl (by decide +kernel)
theorem quickSound5180 (h : Needs) : Correct rule5180 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5180) (t := Root17.tgt) SEP118 ONES118 thinBasis2 TG118 (baseThin2 h) (by decide +kernel) [(false,(0,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5209 (h : Needs) : Correct rule5209 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5209) (t := Root17.tgt) SEP118 ONES118 thinBasis2 TG118 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5218 (h : Needs) : Correct rule5218 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5218) (t := Root17.tgt) SEP118 ONES118 thinBasis7 TG118 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
