import PetersenProjectedRule
import Full18FastBases
import Full18Data9
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound9225 (h : Needs) : Correct rule9225 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule9225) (t := Root17.tgt) SEP186 ONES186 thinBasis21 TG186 (baseThin21 h) (by decide +kernel) [(false,(7,true),(1,true)),(false,(0,false),(9,true))] rfl (by decide +kernel)
theorem quickSound9238 (h : Needs) : Correct rule9238 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule9238) (t := Root17.tgt) SEP186 ONES186 thinBasis21 TG186 (baseThin21 h) (by decide +kernel) [(false,(7,true),(1,true)),(false,(0,false),(9,true)),(false,(8,true),(0,true))] rfl (by decide +kernel)
theorem quickSound9966 (h : Needs) : Correct rule9966 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule9966) (t := Root17.tgt) SEP187 ONES187 thinBasis21 TG187 (baseThin21 h) (by decide +kernel) [(false,(1,true),(7,true)),(false,(3,true),(6,true)),(false,(1,false),(10,true)),(false,(1,false),(9,true)),(false,(0,true),(1,true))] rfl (by decide +kernel)
end Full18
