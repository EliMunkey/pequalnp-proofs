import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules10
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot41835
import Full18Quot112934
import Full18Quot112991
import PetersenProjectedRule
import Full18StepS21362
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21362 (h : Needs) : Blocked Root17.tgt 14 live21362 := by
  apply stepS21362
  · change ∀ r ∈ [rule3052,rule8051,rule3064,rule6590,rule7496,rule6725,rule3611,rule3063,rule8054,rule7558,rule3261,rule2522,rule2633,rule8059,rule5861], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7496) (quickSound7496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3611) (quickSound3611 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8054) (quickSound8054 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7558) (quickSound7558 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2522) (quickSound2522 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2633) (quickSound2633 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8059) (quickSound8059 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5861) (quickSound5861 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live120911,live114822,live114867,live75741,live113389], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live120911) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3] (L := live120911) (V := live112991) (by decide +kernel) (quotient112991 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live114822) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live114822) (V := live112934) (by decide +kernel) (quotient112934 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live114867) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live114867) (V := live112934) (by decide +kernel) (quotient112934 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live75741) (PetersenFastSymmetry.move [thinSym2,thinSym3] (L := live75741) (V := live41835) (by decide +kernel) (quotient41835 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live113389) (PetersenFastSymmetry.move [thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3] (L := live113389) (V := live112991) (by decide +kernel) (quotient112991 h)) <|
      PetersenLocalChildren.nil
end Full18
