import HMC010Hyp
import HMC010ThetaRoutes
import M191StartPreferredCheckedF0X2Z1
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold54_0 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_2_1

theorem hold55_0 : NoAtMost (0x50505050505050505050505050505050 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0x50505050505050505050505050505050) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_2_1
end MC010Cert
