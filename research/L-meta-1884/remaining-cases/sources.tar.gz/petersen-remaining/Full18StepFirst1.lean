import PetersenProjectedRule
import PetersenRuleMoves
import Full18States
import Full18Data4
import Full18Data7
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
def rsFirst1 : Array (Rule 1024) := #[rule7991,rule4971]
def nsFirst1 : Array (List (BitVec 1024)) := #[live6]
def packetsFirst1 : List Nat := [12307,49204,12307,0,3082,6154,3082,2,10,6154,12307,0,10,49204,3082,3]
theorem stepFirst1 (valid : ∀ r∈rsFirst1.toList, Correct r Root17.tgt)
    (next : ∀ s∈nsFirst1.toList, Blocked Root17.tgt 16 s) : PetersenRootOrbit.DeadPair Root17.tgt 17 Root17.primary.toFinset (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 1024) (0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc : BitVec 1024) := by
  apply PetersenRuleMoves.rootPair (test := PetersenRuleMoves.bank rsFirst1) (next := nsFirst1) (hs := packetsFirst1)
  · intro j s; exact PetersenRuleMoves.bank_sound valid j 16 s
  · exact next
  · decide +kernel
end Full18
