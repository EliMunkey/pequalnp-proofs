import PetersenProjectedRule
import Full18FastBases
import Full18Data5
import Full18Data6
import Full18ThinView0
import Full18ThinView1
import Full18ThinView2
import Full18ThinView3
import Full18ThinView5
import Full18ThinView7
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound5878 (h : Needs) : Correct rule5878 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5878) (t := Root17.tgt) SEP115 ONES115 thinBasis4 TG115 (baseThin4 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5881 (h : Needs) : Correct rule5881 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5881) (t := Root17.tgt) SEP150 ONES150 thinBasis2 TG150 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5907 (h : Needs) : Correct rule5907 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5907) (t := Root17.tgt) SEP15 ONES15 thinBasis15 TG15 (baseThin15 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5914 (h : Needs) : Correct rule5914 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5914) (t := Root17.tgt) SEP31 ONES31 thinBasis15 TG31 (baseThin15 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5932 (h : Needs) : Correct rule5932 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5932) (t := Root17.tgt) SEP15 ONES15 thinBasis19 TG15 (baseThin19 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5944 (h : Needs) : Correct rule5944 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5944) (t := Root17.tgt) SEP16 ONES16 thinBasis8 TG16 (baseThin8 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5945 (h : Needs) : Correct rule5945 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5945) (t := Root17.tgt) SEP16 ONES16 thinBasis19 TG16 (baseThin19 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5956 (h : Needs) : Correct rule5956 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5956) (t := Root17.tgt) SEP15 ONES15 thinBasis17 TG15 (baseThin17 h) (by decide +kernel) [(false,(0,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))] rfl (by decide +kernel)
theorem quickSound5999 (h : Needs) : Correct rule5999 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5999) (t := Root17.tgt) SEP15 ONES15 thinBasis17 TG15 (baseThin17 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6004 (h : Needs) : Correct rule6004 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6004) (t := Root17.tgt) SEP17 ONES17 thinBasis15 TG17 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6009 (h : Needs) : Correct rule6009 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6009) (t := Root17.tgt) SEP60 ONES60 thinBasis15 TG60 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6014 (h : Needs) : Correct rule6014 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6014) (t := Root17.tgt) SEP17 ONES17 thinBasis11 TG17 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6017 (h : Needs) : Correct rule6017 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6017) (t := Root17.tgt) SEP17 ONES17 thinBasis20 TG17 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6021 (h : Needs) : Correct rule6021 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6021) (t := Root17.tgt) SEP17 ONES17 thinBasis3 TG17 (baseThin3 h) (by decide +kernel) [(false,(4,true),(7,true))] rfl (by decide +kernel)
theorem quickSound6026 (h : Needs) : Correct rule6026 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6026) (t := Root17.tgt) SEP17 ONES17 thinBasis9 TG17 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6031 (h : Needs) : Correct rule6031 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6031) (t := Root17.tgt) SEP18 ONES18 thinBasis10 TG18 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6032 (h : Needs) : Correct rule6032 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6032) (t := Root17.tgt) SEP18 ONES18 thinBasis9 TG18 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6037 (h : Needs) : Correct rule6037 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6037) (t := Root17.tgt) SEP18 ONES18 thinBasis20 TG18 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6048 (h : Needs) : Correct rule6048 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6048) (t := Root17.tgt) SEP19 ONES19 thinBasis10 TG19 (baseThin10 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound6049 (h : Needs) : Correct rule6049 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6049) (t := Root17.tgt) SEP19 ONES19 thinBasis10 TG19 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6050 (h : Needs) : Correct rule6050 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6050) (t := Root17.tgt) SEP42 ONES42 thinBasis9 TG42 (baseThin9 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound6054 (h : Needs) : Correct rule6054 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6054) (t := Root17.tgt) SEP19 ONES19 thinBasis8 TG19 (baseThin8 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound6063 (h : Needs) : Correct rule6063 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6063) (t := Root17.tgt) SEP20 ONES20 thinBasis15 TG20 (baseThin15 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound6066 (h : Needs) : Correct rule6066 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6066) (t := Root17.tgt) SEP20 ONES20 thinBasis15 TG20 (baseThin15 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound6068 (h : Needs) : Correct rule6068 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6068) (t := Root17.tgt) SEP20 ONES20 thinBasis15 TG20 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6073 (h : Needs) : Correct rule6073 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6073) (t := Root17.tgt) SEP78 ONES78 thinBasis15 TG78 (baseThin15 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound6074 (h : Needs) : Correct rule6074 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6074) (t := Root17.tgt) SEP78 ONES78 thinBasis15 TG78 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6078 (h : Needs) : Correct rule6078 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6078) (t := Root17.tgt) SEP20 ONES20 thinBasis11 TG20 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6082 (h : Needs) : Correct rule6082 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6082) (t := Root17.tgt) SEP20 ONES20 thinBasis10 TG20 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6084 (h : Needs) : Correct rule6084 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6084) (t := Root17.tgt) SEP20 ONES20 thinBasis9 TG20 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6087 (h : Needs) : Correct rule6087 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6087) (t := Root17.tgt) SEP21 ONES21 thinBasis10 TG21 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6089 (h : Needs) : Correct rule6089 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6089) (t := Root17.tgt) SEP21 ONES21 thinBasis9 TG21 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
