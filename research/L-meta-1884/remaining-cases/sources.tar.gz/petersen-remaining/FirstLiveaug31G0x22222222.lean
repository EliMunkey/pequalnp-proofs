import M31StartLabeled
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveaug31G0x22222222 : NoAtMost (0x22222222 :: inputs 5) PetersenSmallStarts.M31.tgt 6 := PetersenSmallStarts.M31.all_forbidden 0x22222222 (by decide +kernel)
#print axioms theFirstLiveaug31G0x22222222
end PetersenLive8
