import M127StartL8B1
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown127G991 : NoAtMost PetersenSmallStarts.M127.s991 PetersenSmallStarts.M127.tgt 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(1,33),(32,33),(1,3),(34,38),(36,44),(1,17),(34,98)] (by decide +kernel) PetersenSmallStarts.M127.b991
#print axioms theFirstLiveknown127G991
end PetersenLive8
