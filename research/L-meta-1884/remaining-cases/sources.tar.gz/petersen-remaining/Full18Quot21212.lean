import Full18ThinRules1
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18Quot108850
import PetersenProjectedRule
import Full18StepS21212
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21212 (h : Needs) : Blocked Root17.tgt 14 live21212 := by
  apply stepS21212
  · change ∀ r ∈ [rule3052,rule8051,rule3064,rule6084,rule3259,rule7568,rule8022,rule3946,rule2225,rule8052,rule8064,rule8067,rule7449,rule7443,rule8059,rule5944,rule6590,rule8069,rule8072,rule7485,rule8044], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6084) (quickSound6084 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3259) (quickSound3259 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7568) (quickSound7568 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3946) (quickSound3946 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2225) (quickSound2225 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8052) (quickSound8052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8064) (quickSound8064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8067) (quickSound8067 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7449) (quickSound7449 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8059) (quickSound8059 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8069) (quickSound8069 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8072) (quickSound8072 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7485) (quickSound7485 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8044) (quickSound8044 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live108850], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108850) (quotient108850 h) <|
      PetersenLocalChildren.nil
end Full18
