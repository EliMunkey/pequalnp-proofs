import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import PetersenProjectedRule
import Full18StepS20527
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient20527 (h : Needs) : Blocked Root17.tgt 14 live20527 := by
  apply stepS20527
  · change ∀ r ∈ [rule3052,rule8051,rule3862,rule3064,rule2406,rule4989,rule7428,rule6082,rule1905,rule3063,rule3070,rule8030,rule4221,rule3073,rule8081,rule8010,rule6637,rule7443,rule8000,rule2225,rule8052,rule8064,rule6712,rule6674,rule8059,rule8062,rule6109,rule8044], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3862) (quickSound3862 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2406) (quickSound2406 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4989) (quickSound4989 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7428) (quickSound7428 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1905) (quickSound1905 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8030) (quickSound8030 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4221) (quickSound4221 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8081) (quickSound8081 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8010) (quickSound8010 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6637) (quickSound6637 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2225) (quickSound2225 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8052) (quickSound8052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8064) (quickSound8064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6712) (quickSound6712 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8059) (quickSound8059 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8062) (quickSound8062 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6109) (quickSound6109 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8044) (quickSound8044 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [], Blocked Root17.tgt 13 s
    exact PetersenLocalChildren.nil
end Full18
