import Full18ThinRules0
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules14
import PetersenProjectedRule
import Full18StepS168479
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient168479 (h : Needs) : Blocked Root17.tgt 12 live168479 := by
  apply stepS168479
  · change ∀ r ∈ [rule3251,rule2560,rule3070,rule3052,rule1358,rule3057,rule3073,rule3064,rule7515,rule4058,rule3467,rule7510], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2560) (quickSound2560 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1358) (quickSound1358 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3057) (quickSound3057 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7515) (quickSound7515 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4058) (quickSound4058 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3467) (quickSound3467 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7510) (quickSound7510 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [], Blocked Root17.tgt 11 s
    exact PetersenLocalChildren.nil
end Full18
