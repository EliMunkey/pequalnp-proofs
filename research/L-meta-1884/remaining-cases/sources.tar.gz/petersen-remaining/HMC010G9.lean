import HEX010G7
import HEX010G8
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r346 := EX010Cert.r346
abbrev stages346 := EX010Cert.stages346
theorem rowOk346 : PetersenWordProjection.check stages346 128 r346 = true := EX010Cert.rowOk346
theorem hot346 : forcedConst r346 tgt = false := EX010Cert.hot346
theorem match346 : PetersenPackedPin.project r346 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match346
abbrev r347 := EX010Cert.r347
abbrev stages347 := EX010Cert.stages347
theorem rowOk347 : PetersenWordProjection.check stages347 64 r347 = true := EX010Cert.rowOk347
theorem hot347 : forcedConst r347 tgt = false := EX010Cert.hot347
theorem match347 : PetersenPackedPin.project r347 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match347
abbrev r348 := EX010Cert.r348
abbrev stages348 := EX010Cert.stages348
theorem rowOk348 : PetersenWordProjection.check stages348 32 r348 = true := EX010Cert.rowOk348
theorem hot348 : forcedConst r348 tgt = false := EX010Cert.hot348
theorem match348 : PetersenPackedPin.project r348 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match348
abbrev r354 := EX010Cert.r354
abbrev stages354 := EX010Cert.stages354
theorem rowOk354 : PetersenWordProjection.check stages354 128 r354 = true := EX010Cert.rowOk354
theorem hot354 : forcedConst r354 tgt = false := EX010Cert.hot354
theorem match354 : PetersenPackedPin.project r354 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match354
abbrev r358 := EX010Cert.r358
abbrev stages358 := EX010Cert.stages358
theorem rowOk358 : PetersenWordProjection.check stages358 0 r358 = true := EX010Cert.rowOk358
theorem hot358 : forcedConst r358 tgt = false := EX010Cert.hot358
theorem match358 : PetersenPackedPin.project r358 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match358
abbrev r366 := EX010Cert.r366
abbrev stages366 := EX010Cert.stages366
theorem rowOk366 : PetersenWordProjection.check stages366 32 r366 = true := EX010Cert.rowOk366
theorem hot366 : forcedConst r366 tgt = false := EX010Cert.hot366
theorem match366 : PetersenPackedPin.project r366 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match366
abbrev r368 := EX010Cert.r368
abbrev stages368 := EX010Cert.stages368
theorem rowOk368 : PetersenWordProjection.check stages368 128 r368 = true := EX010Cert.rowOk368
theorem hot368 : forcedConst r368 tgt = false := EX010Cert.hot368
theorem match368 : PetersenPackedPin.project r368 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match368
abbrev r369 := EX010Cert.r369
abbrev stages369 := EX010Cert.stages369
theorem rowOk369 : PetersenWordProjection.check stages369 64 r369 = true := EX010Cert.rowOk369
theorem hot369 : forcedConst r369 tgt = false := EX010Cert.hot369
theorem match369 : PetersenPackedPin.project r369 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match369
abbrev r370 := EX010Cert.r370
abbrev stages370 := EX010Cert.stages370
theorem rowOk370 : PetersenWordProjection.check stages370 32 r370 = true := EX010Cert.rowOk370
theorem hot370 : forcedConst r370 tgt = false := EX010Cert.hot370
theorem match370 : PetersenPackedPin.project r370 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match370
abbrev r374 := EX010Cert.r374
abbrev stages374 := EX010Cert.stages374
theorem rowOk374 : PetersenWordProjection.check stages374 64 r374 = true := EX010Cert.rowOk374
theorem hot374 : forcedConst r374 tgt = false := EX010Cert.hot374
theorem match374 : PetersenPackedPin.project r374 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match374
abbrev r380 := EX010Cert.r380
abbrev stages380 := EX010Cert.stages380
theorem rowOk380 : PetersenWordProjection.check stages380 32 r380 = true := EX010Cert.rowOk380
theorem hot380 : forcedConst r380 tgt = false := EX010Cert.hot380
theorem match380 : PetersenPackedPin.project r380 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match380
def r381 (i : Fin 32) : Fin 256 := (#[0,2,64,66,16,18,80,82,1,3,65,67,17,19,81,83,4,6,68,70,20,22,84,86,5,7,69,71,21,23,85,87] : Array (Fin 256))[i.val]?.getD 0
def stages381 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x3e,0xcccccccccccccccc0000000000000000cccccccccccccccc,0x3333333333333333000000000000000033333333333333330000000000000000,0xcccccccccccccccc3333333333333333cccccccccccccccc3333333333333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk381 : PetersenWordProjection.check stages381 0 r381 = true := by decide +kernel
theorem hot381 : forcedConst r381 tgt = false := by decide +kernel
theorem match381 : PetersenPackedPin.project r381 tgt = (0xeaeaeac8 : BitVec 32) := by decide +kernel
end MC010Cert
