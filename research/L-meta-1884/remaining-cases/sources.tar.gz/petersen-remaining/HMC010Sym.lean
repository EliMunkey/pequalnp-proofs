import Q1020Symmetry
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev tgt := Q1020Symmetry.target
abbrev sym1 := Q1020Symmetry.sym1
theorem fix1 : sym1.word tgt = tgt := Q1020Symmetry.fix1
abbrev sym2 := Q1020Symmetry.sym2
theorem fix2 : sym2.word tgt = tgt := Q1020Symmetry.fix2
abbrev sym3 := Q1020Symmetry.sym3
theorem fix3 : sym3.word tgt = tgt := Q1020Symmetry.fix3
abbrev sym4 := Q1020Symmetry.sym4
theorem fix4 : sym4.word tgt = tgt := Q1020Symmetry.fix4
abbrev sym5 := Q1020Symmetry.sym5
theorem fix5 : sym5.word tgt = tgt := Q1020Symmetry.fix5
abbrev sym6 := Q1020Symmetry.sym6
theorem fix6 : sym6.word tgt = tgt := Q1020Symmetry.fix6
abbrev sym7 := Q1020Symmetry.sym7
theorem fix7 : sym7.word tgt = tgt := Q1020Symmetry.fix7
end MC010Cert
