import HMC161RHyp
import HMC161RThetaRoutes
import M191StartPreferredCheckedF0X3Z3
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold45_0 : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0xf0f00000f0f00000f0f00000f0f00000) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_3
end MC161RCert
