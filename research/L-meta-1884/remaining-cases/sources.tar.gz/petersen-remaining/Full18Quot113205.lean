import Full18ThinRules0
import Full18ThinRules3
import Full18ThinRules12
import Full18ThinRules14
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot176567
import Full18Quot178493
import PetersenProjectedRule
import Full18StepS113205
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient113205 (h : Needs) : Blocked Root17.tgt 13 live113205 := by
  apply stepS113205
  · change ∀ r ∈ [rule3064,rule3073,rule3052,rule8000,rule3255,rule1199,rule7999,rule3070,rule6662,rule1153,rule6108], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1199) (quickSound1199 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7999) (quickSound7999 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6662) (quickSound6662 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1153) (quickSound1153 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6108) (quickSound6108 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live187158,live176576], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187158) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3] (L := live187158) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live176576) (PetersenFastSymmetry.move [thinSym0] (L := live176576) (V := live176567) (by decide +kernel) (quotient176567 h)) <|
      PetersenLocalChildren.nil
end Full18
