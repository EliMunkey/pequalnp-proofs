import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules7
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot112934
import Full18Quot113205
import Full18Quot115094
import Full18Quot121574
import PetersenProjectedRule
import Full18StepS21644
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21644 (h : Needs) : Blocked Root17.tgt 14 live21644 := by
  apply stepS21644
  · change ∀ r ∈ [rule3052,rule8051,rule3064,rule3251,rule7546,rule7443,rule7469,rule5360,rule5549,rule5557,rule3063,rule8054,rule5571,rule7468,rule2943,rule4991,rule2529,rule8064,rule8067,rule2638,rule8069,rule8072,rule2827], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7546) (quickSound7546 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5360) (quickSound5360 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5549) (quickSound5549 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5557) (quickSound5557 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8054) (quickSound8054 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5571) (quickSound5571 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7468) (quickSound7468 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2943) (quickSound2943 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4991) (quickSound4991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2529) (quickSound2529 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8064) (quickSound8064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8067) (quickSound8067 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2638) (quickSound2638 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8069) (quickSound8069 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8072) (quickSound8072 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2827) (quickSound2827 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live122059,live121385,live121571,live115112,live115113,live113492,live112934], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live122059) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym3] (L := live122059) (V := live121574) (by decide +kernel) (quotient121574 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live121385) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym0,thinSym3] (L := live121385) (V := live113205) (by decide +kernel) (quotient113205 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live121571) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3] (L := live121571) (V := live115094) (by decide +kernel) (quotient115094 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live115112) (PetersenFastSymmetry.move [thinSym0] (L := live115112) (V := live115094) (by decide +kernel) (quotient115094 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live115113) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live115113) (V := live113205) (by decide +kernel) (quotient113205 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live113492) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0,thinSym3,thinSym2] (L := live113492) (V := live112934) (by decide +kernel) (quotient112934 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112934) (quotient112934 h) <|
      PetersenLocalChildren.nil
end Full18
