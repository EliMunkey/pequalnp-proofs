import HEX010G2
import HEX010G3
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r40 := EX010Cert.r40
abbrev stages40 := EX010Cert.stages40
theorem rowOk40 : PetersenWordProjection.check stages40 0 r40 = true := EX010Cert.rowOk40
theorem hot40 : forcedConst r40 tgt = false := EX010Cert.hot40
theorem match40 : PetersenPackedPin.project r40 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match40
abbrev r41 := EX010Cert.r41
abbrev stages41 := EX010Cert.stages41
theorem rowOk41 : PetersenWordProjection.check stages41 128 r41 = true := EX010Cert.rowOk41
theorem hot41 : forcedConst r41 tgt = false := EX010Cert.hot41
theorem match41 : PetersenPackedPin.project r41 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match41
abbrev r42 := EX010Cert.r42
abbrev stages42 := EX010Cert.stages42
theorem rowOk42 : PetersenWordProjection.check stages42 128 r42 = true := EX010Cert.rowOk42
theorem hot42 : forcedConst r42 tgt = false := EX010Cert.hot42
theorem match42 : PetersenPackedPin.project r42 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match42
abbrev r43 := EX010Cert.r43
abbrev stages43 := EX010Cert.stages43
theorem rowOk43 : PetersenWordProjection.check stages43 64 r43 = true := EX010Cert.rowOk43
theorem hot43 : forcedConst r43 tgt = false := EX010Cert.hot43
theorem match43 : PetersenPackedPin.project r43 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match43
abbrev r44 := EX010Cert.r44
abbrev stages44 := EX010Cert.stages44
theorem rowOk44 : PetersenWordProjection.check stages44 128 r44 = true := EX010Cert.rowOk44
theorem hot44 : forcedConst r44 tgt = false := EX010Cert.hot44
theorem match44 : PetersenPackedPin.project r44 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match44
abbrev r45 := EX010Cert.r45
abbrev stages45 := EX010Cert.stages45
theorem rowOk45 : PetersenWordProjection.check stages45 64 r45 = true := EX010Cert.rowOk45
theorem hot45 : forcedConst r45 tgt = false := EX010Cert.hot45
theorem match45 : PetersenPackedPin.project r45 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match45
abbrev r47 := EX010Cert.r47
abbrev stages47 := EX010Cert.stages47
theorem rowOk47 : PetersenWordProjection.check stages47 128 r47 = true := EX010Cert.rowOk47
theorem hot47 : forcedConst r47 tgt = false := EX010Cert.hot47
theorem match47 : PetersenPackedPin.project r47 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match47
def r48 (i : Fin 64) : Fin 256 := (#[1,5,129,133,17,21,145,149,65,69,193,197,81,85,209,213,3,7,131,135,19,23,147,151,67,71,195,199,83,87,211,215,33,37,161,165,49,53,177,181,97,101,225,229,113,117,241,245,35,39,163,167,51,55,179,183,99,103,227,231,115,119,243,247] : Array (Fin 256))[i.val]?.getD 0
def stages48 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x70,0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff00000000000000000000000000000000,0xffff0000ffff0000ffff0000ffff00000000ffff0000ffff0000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x3,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x5050505050505050505050505050505050505050505050505050505050505050,0xa5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5⟩]
theorem rowOk48 : PetersenWordProjection.check stages48 64 r48 = true := by decide +kernel
theorem hot48 : forcedConst r48 tgt = false := by decide +kernel
theorem match48 : PetersenPackedPin.project r48 tgt = (0xfffffffffffff8c8 : BitVec 64) := by decide +kernel
abbrev r53 := EX010Cert.r53
abbrev stages53 := EX010Cert.stages53
theorem rowOk53 : PetersenWordProjection.check stages53 128 r53 = true := EX010Cert.rowOk53
theorem hot53 : forcedConst r53 tgt = false := EX010Cert.hot53
theorem match53 : PetersenPackedPin.project r53 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match53
abbrev r54 := EX010Cert.r54
abbrev stages54 := EX010Cert.stages54
theorem rowOk54 : PetersenWordProjection.check stages54 64 r54 = true := EX010Cert.rowOk54
theorem hot54 : forcedConst r54 tgt = false := EX010Cert.hot54
theorem match54 : PetersenPackedPin.project r54 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match54
abbrev r61 := EX010Cert.r61
abbrev stages61 := EX010Cert.stages61
theorem rowOk61 : PetersenWordProjection.check stages61 128 r61 = true := EX010Cert.rowOk61
theorem hot61 : forcedConst r61 tgt = false := EX010Cert.hot61
theorem match61 : PetersenPackedPin.project r61 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match61
abbrev r62 := EX010Cert.r62
abbrev stages62 := EX010Cert.stages62
theorem rowOk62 : PetersenWordProjection.check stages62 64 r62 = true := EX010Cert.rowOk62
theorem hot62 : forcedConst r62 tgt = false := EX010Cert.hot62
theorem match62 : PetersenPackedPin.project r62 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match62
end MC010Cert
