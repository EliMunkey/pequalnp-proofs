import M127StartL7B32
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown127G1148 : NoAtMost PetersenSmallStarts.M127.s1148 PetersenSmallStarts.M127.tgt 7 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(65,97),(96,97),(34,98),(65,3),(34,38),(100,108),(65,81)] (by decide +kernel) PetersenSmallStarts.M127.b1148
#print axioms theFirstLiveknown127G1148
end PetersenLive8
