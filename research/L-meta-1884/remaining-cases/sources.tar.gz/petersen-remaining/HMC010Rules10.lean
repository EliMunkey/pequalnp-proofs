import Extra1020K12
import HMC010G0
import HMC010G2
import HMC010G5
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule498 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages9 s.steps 0 7 (0xaaaaaaaa :: i6) p
theorem correct498 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule498 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa :: i6) (PetersenPackedPin.project r9 tgt) 7 := by rw [match9]; exact Assumptions.h35
  intro d L hit
  exact PetersenRoutedPin.quick rowOk9 s small hot9 p hit
def rule499 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xaa00aa00aa00aa00aa00aa00aa00aa00 :: i7) p
theorem correct499 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule499 s p) tgt := by
  have small : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa00 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h57
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule500 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages28 s.steps 0 8 (0xffccffccffccffccffccffccffccffcc :: i7) p
theorem correct500 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule500 s p) tgt := by
  have small : NoAtMost (0xffccffccffccffccffccffccffccffcc :: i7) (PetersenPackedPin.project r28 tgt) 8 := by rw [match28]; exact Assumptions.h45
  intro d L hit
  exact PetersenRoutedPin.quick rowOk28 s small hot28 p hit
def rule501 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages7 s.steps 0 7 (0xaaaa0000aaaa0000 :: i6) p
theorem correct501 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule501 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000 :: i6) (PetersenPackedPin.project r7 tgt) 7 := by rw [match7]; exact Assumptions.h37
  intro d L hit
  exact PetersenRoutedPin.quick rowOk7 s small hot7 p hit
def rule502 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) p
theorem correct502 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule502 s p) tgt := by
  have small : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h62
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule503 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) p
theorem correct503 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule503 s p) tgt := by
  have small : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h66
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule504 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xcccc :: i5) p
theorem correct504 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule504 s p) tgt := by
  have small : NoAtMost (0xcccc :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h4
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule505 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 (0xcccc0000 :: i5) p
theorem correct505 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule505 s p) tgt := by
  have small : NoAtMost (0xcccc0000 :: i5) (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact Assumptions.h20
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule506 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 (0xfcfcfcfc :: i5) p
theorem correct506 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule506 s p) tgt := by
  have small : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact Assumptions.h22
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule507 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xcccc :: i5) p
theorem correct507 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule507 s p) tgt := by
  have small : NoAtMost (0xcccc :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h4
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule508 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xcc00cc :: i5) p
theorem correct508 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule508 s p) tgt := by
  have small : NoAtMost (0xcc00cc :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h7
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule509 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xf000f0 :: i5) p
theorem correct509 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule509 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h8
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule510 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) p
theorem correct510 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule510 s p) tgt := by
  have small : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h61
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule511 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages15 s.steps 0 7 (0xaaaa0000aaaa0000 :: i6) p
theorem correct511 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule511 s p) tgt := by
  have small : NoAtMost (0xaaaa0000aaaa0000 :: i6) (PetersenPackedPin.project r15 tgt) 7 := by rw [match15]; exact Assumptions.h37
  intro d L hit
  exact PetersenRoutedPin.quick rowOk15 s small hot15 p hit
def rule512 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xffffff00ffffff00ffffff00ffffff00 :: i7) p
theorem correct512 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule512 s p) tgt := by
  have small : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h63
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule513 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) p
theorem correct513 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule513 s p) tgt := by
  have small : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h61
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule514 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 (0xfcfcfcfc :: i5) p
theorem correct514 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule514 s p) tgt := by
  have small : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact Assumptions.h22
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule515 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xffffffffffffffffffff0000ffff0000 :: i7) p
theorem correct515 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule515 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h67
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule516 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages108 s.steps 64 5 (0xf000f000f000f0 :: i6) p
theorem correct516 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule516 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r108 tgt) 5 := by rw [match108]; exact Assumptions.h39
  intro d L hit
  exact PetersenRoutedPin.quick rowOk108 s small hot108 p hit
def rule517 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages116 s.steps 128 5 (0x4444444444444444 :: i6) p
theorem correct517 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule517 s p) tgt := by
  have small : NoAtMost (0x4444444444444444 :: i6) (PetersenPackedPin.project r116 tgt) 5 := by rw [match116]; exact Assumptions.h43
  intro d L hit
  exact PetersenRoutedPin.quick rowOk116 s small hot116 p hit
end MC010Cert
