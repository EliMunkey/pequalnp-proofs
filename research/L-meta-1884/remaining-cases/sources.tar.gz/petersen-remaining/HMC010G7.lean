import HEX010G5
import HEX010G6
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r189 := EX010Cert.r189
abbrev stages189 := EX010Cert.stages189
theorem rowOk189 : PetersenWordProjection.check stages189 128 r189 = true := EX010Cert.rowOk189
theorem hot189 : forcedConst r189 tgt = false := EX010Cert.hot189
theorem match189 : PetersenPackedPin.project r189 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match189
abbrev r190 := EX010Cert.r190
abbrev stages190 := EX010Cert.stages190
theorem rowOk190 : PetersenWordProjection.check stages190 64 r190 = true := EX010Cert.rowOk190
theorem hot190 : forcedConst r190 tgt = false := EX010Cert.hot190
theorem match190 : PetersenPackedPin.project r190 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match190
abbrev r191 := EX010Cert.r191
abbrev stages191 := EX010Cert.stages191
theorem rowOk191 : PetersenWordProjection.check stages191 32 r191 = true := EX010Cert.rowOk191
theorem hot191 : forcedConst r191 tgt = false := EX010Cert.hot191
theorem match191 : PetersenPackedPin.project r191 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match191
def r195 (i : Fin 32) : Fin 256 := (#[8,10,12,14,136,138,140,142,24,26,28,30,152,154,156,158,40,42,44,46,168,170,172,174,56,58,60,62,184,186,188,190] : Array (Fin 256))[i.val]?.getD 0
def stages195 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x10,0xffff000000000000ffff000000000000ffff000000000000ffff0000,0xffff000000000000ffff000000000000ffff000000000000ffff00000000,0xffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x7c,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00000000000000000000000000000000,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f⟩,⟨0x2,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c,0x3030303030303030303030303030303030303030303030303030303030303030,0xc3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk195 : PetersenWordProjection.check stages195 64 r195 = true := by decide +kernel
theorem hot195 : forcedConst r195 tgt = false := by decide +kernel
theorem match195 : PetersenPackedPin.project r195 tgt = (0xfffff8c8 : BitVec 32) := by decide +kernel
def r198 (i : Fin 16) : Fin 256 := (#[0,4,2,6,64,68,66,70,16,20,18,22,80,84,82,86] : Array (Fin 256))[i.val]?.getD 0
def stages198 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩,⟨0x3,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x5050505050505050505050505050505050505050505050505050505050505050,0xa5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5⟩]
theorem rowOk198 : PetersenWordProjection.check stages198 0 r198 = true := by decide +kernel
theorem hot198 : forcedConst r198 tgt = false := by decide +kernel
theorem match198 : PetersenPackedPin.project r198 tgt = (0xf8c8 : BitVec 16) := by decide +kernel
def r206 (i : Fin 32) : Fin 256 := (#[0,4,2,6,64,68,66,70,8,12,10,14,72,76,74,78,128,132,130,134,192,196,194,198,136,140,138,142,200,204,202,206] : Array (Fin 256))[i.val]?.getD 0
def stages206 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x70,0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff00000000000000000000000000000000,0xffff0000ffff0000ffff0000ffff00000000ffff0000ffff0000ffff0000ffff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩,⟨0x3,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x5050505050505050505050505050505050505050505050505050505050505050,0xa5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5⟩]
theorem rowOk206 : PetersenWordProjection.check stages206 0 r206 = true := by decide +kernel
theorem hot206 : forcedConst r206 tgt = false := by decide +kernel
theorem match206 : PetersenPackedPin.project r206 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
def r211 (i : Fin 32) : Fin 256 := (#[0,4,128,132,32,36,160,164,8,12,136,140,40,44,168,172,2,6,130,134,34,38,162,166,10,14,138,142,42,46,170,174] : Array (Fin 256))[i.val]?.getD 0
def stages211 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x70,0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff00000000000000000000000000000000,0xffff0000ffff0000ffff0000ffff00000000ffff0000ffff0000ffff0000ffff⟩,⟨0x1c,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f0,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f00000000,0xf0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0f⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x3,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x5050505050505050505050505050505050505050505050505050505050505050,0xa5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5⟩]
theorem rowOk211 : PetersenWordProjection.check stages211 0 r211 = true := by decide +kernel
theorem hot211 : forcedConst r211 tgt = false := by decide +kernel
theorem match211 : PetersenPackedPin.project r211 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
abbrev r216 := EX010Cert.r216
abbrev stages216 := EX010Cert.stages216
theorem rowOk216 : PetersenWordProjection.check stages216 0 r216 = true := EX010Cert.rowOk216
theorem hot216 : forcedConst r216 tgt = false := EX010Cert.hot216
theorem match216 : PetersenPackedPin.project r216 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match216
abbrev r221 := EX010Cert.r221
abbrev stages221 := EX010Cert.stages221
theorem rowOk221 : PetersenWordProjection.check stages221 0 r221 = true := EX010Cert.rowOk221
theorem hot221 : forcedConst r221 tgt = false := EX010Cert.hot221
theorem match221 : PetersenPackedPin.project r221 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match221
abbrev r228 := EX010Cert.r228
abbrev stages228 := EX010Cert.stages228
theorem rowOk228 : PetersenWordProjection.check stages228 64 r228 = true := EX010Cert.rowOk228
theorem hot228 : forcedConst r228 tgt = false := EX010Cert.hot228
theorem match228 : PetersenPackedPin.project r228 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match228
def r236 (i : Fin 32) : Fin 256 := (#[0,16,128,144,32,48,160,176,1,17,129,145,33,49,161,177,64,80,192,208,96,112,224,240,65,81,193,209,97,113,225,241] : Array (Fin 256))[i.val]?.getD 0
def stages236 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x1c,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f0,0xf0f0f0f000000000f0f0f0f000000000f0f0f0f000000000f0f0f0f00000000,0xf0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0ff0f0f0f00f0f0f0f⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0xf,0xaaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa,0x5555000055550000555500005555000055550000555500005555000055550000,0xaaaa5555aaaa5555aaaa5555aaaa5555aaaa5555aaaa5555aaaa5555aaaa5555⟩]
theorem rowOk236 : PetersenWordProjection.check stages236 0 r236 = true := by decide +kernel
theorem hot236 : forcedConst r236 tgt = false := by decide +kernel
theorem match236 : PetersenPackedPin.project r236 tgt = (0xfaeaf8c8 : BitVec 32) := by decide +kernel
abbrev r242 := EX010Cert.r242
abbrev stages242 := EX010Cert.stages242
theorem rowOk242 : PetersenWordProjection.check stages242 64 r242 = true := EX010Cert.rowOk242
theorem hot242 : forcedConst r242 tgt = false := EX010Cert.hot242
theorem match242 : PetersenPackedPin.project r242 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match242
end MC010Cert
