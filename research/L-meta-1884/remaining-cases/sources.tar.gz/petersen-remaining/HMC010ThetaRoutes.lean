import SmallStartRelabel
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
private def i7 : List (BitVec 128) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
def thetaRows0 (r: Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[r.val]?.getD 0
theorem thetaInputs0 : i7.all (fun q => i7.contains (PetersenPackedPin.project thetaRows0 q))=true := by decide +kernel
theorem thetaTarget0 : PetersenPackedPin.project thetaRows0 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128)=0xfffffffffffaf8f8ffeafaeaffeaf8c8 := by decide +kernel
def thetaRows1 (r: Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[r.val]?.getD 0
theorem thetaInputs1 : i7.all (fun q => i7.contains (PetersenPackedPin.project thetaRows1 q))=true := by decide +kernel
theorem thetaTarget1 : PetersenPackedPin.project thetaRows1 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128)=0xfffffffffffaf8f8ffeafaeaffeaf8c8 := by decide +kernel
def thetaRows2 (r: Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[r.val]?.getD 0
theorem thetaInputs2 : i7.all (fun q => i7.contains (PetersenPackedPin.project thetaRows2 q))=true := by decide +kernel
theorem thetaTarget2 : PetersenPackedPin.project thetaRows2 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128)=0xfffffffffffaf8f8ffeafaeaffeaf8c8 := by decide +kernel
def thetaRows3 (r: Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[r.val]?.getD 0
theorem thetaInputs3 : i7.all (fun q => i7.contains (PetersenPackedPin.project thetaRows3 q))=true := by decide +kernel
theorem thetaTarget3 : PetersenPackedPin.project thetaRows3 (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128)=0xfffffffffffaf8f8ffeafaeaffeaf8c8 := by decide +kernel
end MC010Cert
