import PetersenProjectedRule
import Full18FastBases
import Full18Data5
import Full18ThinView5
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound5239 (h : Needs) : Correct rule5239 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5239) (t := Root17.tgt) SEP118 ONES118 thinBasis13 TG118 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5244 (h : Needs) : Correct rule5244 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5244) (t := Root17.tgt) SEP118 ONES118 thinBasis13 TG118 (baseThin13 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5245 (h : Needs) : Correct rule5245 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5245) (t := Root17.tgt) SEP118 ONES118 thinBasis13 TG118 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5257 (h : Needs) : Correct rule5257 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5257) (t := Root17.tgt) SEP123 ONES123 thinBasis5 TG123 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5263 (h : Needs) : Correct rule5263 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5263) (t := Root17.tgt) SEP181 ONES181 thinBasis5 TG181 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5275 (h : Needs) : Correct rule5275 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5275) (t := Root17.tgt) SEP138 ONES138 thinBasis5 TG138 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5277 (h : Needs) : Correct rule5277 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5277) (t := Root17.tgt) SEP140 ONES140 thinBasis5 TG140 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5284 (h : Needs) : Correct rule5284 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5284) (t := Root17.tgt) SEP177 ONES177 thinBasis2 TG177 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5292 (h : Needs) : Correct rule5292 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5292) (t := Root17.tgt) SEP138 ONES138 thinBasis2 TG138 (baseThin2 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5294 (h : Needs) : Correct rule5294 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5294) (t := Root17.tgt) SEP138 ONES138 thinBasis2 TG138 (baseThin2 h) (by decide +kernel) [(false,(4,true),(2,true))] rfl (by decide +kernel)
theorem quickSound5296 (h : Needs) : Correct rule5296 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5296) (t := Root17.tgt) SEP138 ONES138 thinBasis2 TG138 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5297 (h : Needs) : Correct rule5297 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5297) (t := Root17.tgt) SEP138 ONES138 thinBasis2 TG138 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5308 (h : Needs) : Correct rule5308 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5308) (t := Root17.tgt) SEP102 ONES102 thinBasis5 TG102 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5314 (h : Needs) : Correct rule5314 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5314) (t := Root17.tgt) SEP102 ONES102 thinBasis14 TG102 (baseThin14 h) (by decide +kernel) [(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound5316 (h : Needs) : Correct rule5316 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5316) (t := Root17.tgt) SEP102 ONES102 thinBasis14 TG102 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5317 (h : Needs) : Correct rule5317 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5317) (t := Root17.tgt) SEP102 ONES102 thinBasis13 TG102 (baseThin13 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5321 (h : Needs) : Correct rule5321 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5321) (t := Root17.tgt) SEP102 ONES102 thinBasis13 TG102 (baseThin13 h) (by decide +kernel) [(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound5326 (h : Needs) : Correct rule5326 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5326) (t := Root17.tgt) SEP102 ONES102 thinBasis13 TG102 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5327 (h : Needs) : Correct rule5327 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5327) (t := Root17.tgt) SEP104 ONES104 thinBasis5 TG104 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5334 (h : Needs) : Correct rule5334 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5334) (t := Root17.tgt) SEP102 ONES102 thinBasis1 TG102 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5335 (h : Needs) : Correct rule5335 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5335) (t := Root17.tgt) SEP102 ONES102 thinBasis1 TG102 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5347 (h : Needs) : Correct rule5347 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5347) (t := Root17.tgt) SEP155 ONES155 thinBasis5 TG155 (baseThin5 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5348 (h : Needs) : Correct rule5348 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5348) (t := Root17.tgt) SEP155 ONES155 thinBasis5 TG155 (baseThin5 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5360 (h : Needs) : Correct rule5360 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5360) (t := Root17.tgt) SEP155 ONES155 thinBasis5 TG155 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5368 (h : Needs) : Correct rule5368 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5368) (t := Root17.tgt) SEP155 ONES155 thinBasis14 TG155 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5373 (h : Needs) : Correct rule5373 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5373) (t := Root17.tgt) SEP165 ONES165 thinBasis1 TG165 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5384 (h : Needs) : Correct rule5384 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5384) (t := Root17.tgt) SEP130 ONES130 thinBasis1 TG130 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5385 (h : Needs) : Correct rule5385 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5385) (t := Root17.tgt) SEP130 ONES130 thinBasis1 TG130 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5386 (h : Needs) : Correct rule5386 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5386) (t := Root17.tgt) SEP102 ONES102 thinBasis2 TG102 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound5391 (h : Needs) : Correct rule5391 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5391) (t := Root17.tgt) SEP102 ONES102 thinBasis2 TG102 (baseThin2 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5394 (h : Needs) : Correct rule5394 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5394) (t := Root17.tgt) SEP102 ONES102 thinBasis2 TG102 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5403 (h : Needs) : Correct rule5403 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5403) (t := Root17.tgt) SEP102 ONES102 thinBasis7 TG102 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
