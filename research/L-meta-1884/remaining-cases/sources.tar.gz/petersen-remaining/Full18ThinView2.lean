import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP40 : steps40.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES40 : PetersenWordProjection.projectFast steps40 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG40 : PetersenWordProjection.projectFast steps40 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP41 : steps41.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES41 : PetersenWordProjection.projectFast steps41 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG41 : PetersenWordProjection.projectFast steps41 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP42 : steps42.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES42 : PetersenWordProjection.projectFast steps42 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG42 : PetersenWordProjection.projectFast steps42 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP43 : steps43.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES43 : PetersenWordProjection.projectFast steps43 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG43 : PetersenWordProjection.projectFast steps43 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP44 : steps44.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES44 : PetersenWordProjection.projectFast steps44 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG44 : PetersenWordProjection.projectFast steps44 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP45 : steps45.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES45 : PetersenWordProjection.projectFast steps45 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG45 : PetersenWordProjection.projectFast steps45 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP46 : steps46.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES46 : PetersenWordProjection.projectFast steps46 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG46 : PetersenWordProjection.projectFast steps46 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP47 : steps47.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES47 : PetersenWordProjection.projectFast steps47 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG47 : PetersenWordProjection.projectFast steps47 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP48 : steps48.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES48 : PetersenWordProjection.projectFast steps48 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG48 : PetersenWordProjection.projectFast steps48 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP50 : steps50.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES50 : PetersenWordProjection.projectFast steps50 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG50 : PetersenWordProjection.projectFast steps50 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP51 : steps51.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES51 : PetersenWordProjection.projectFast steps51 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG51 : PetersenWordProjection.projectFast steps51 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP52 : steps52.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES52 : PetersenWordProjection.projectFast steps52 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG52 : PetersenWordProjection.projectFast steps52 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP53 : steps53.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES53 : PetersenWordProjection.projectFast steps53 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG53 : PetersenWordProjection.projectFast steps53 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP55 : steps55.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES55 : PetersenWordProjection.projectFast steps55 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG55 : PetersenWordProjection.projectFast steps55 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP57 : steps57.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES57 : PetersenWordProjection.projectFast steps57 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG57 : PetersenWordProjection.projectFast steps57 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP59 : steps59.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES59 : PetersenWordProjection.projectFast steps59 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG59 : PetersenWordProjection.projectFast steps59 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
end Full18
