import HMC010Hyp
import M31StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem hold5_0 : NoAtMost (0xff00 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xff00 (by decide +kernel)
end MC010Cert
