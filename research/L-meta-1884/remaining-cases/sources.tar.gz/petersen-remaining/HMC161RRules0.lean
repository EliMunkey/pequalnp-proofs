import Extra1020K12
import HMC161RG0
import HMC161RG1
import HMC161RG2
import HMC161RHyp
import HMC161RPinData
import HMC161RRoutes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule0 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages0 s.steps 0 6 i5 p
theorem correct0 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule0 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r0 tgt) 6 := by rw [match0]; exact PetersenCycleFive.no_six_gates
  intro d L hit
  exact PetersenRoutedPin.quick rowOk0 s small hot0 p hit
def rule1 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages1 s.steps 0 6 i5 p
theorem correct1 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule1 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r1 tgt) 6 := by rw [match1]; exact PetersenCycleFive.no_six_gates
  intro d L hit
  exact PetersenRoutedPin.quick rowOk1 s small hot1 p hit
def rule2 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages2 s.steps 0 6 i5 p
theorem correct2 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule2 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r2 tgt) 6 := by rw [match2]; exact PetersenCycleFive.no_six_gates
  intro d L hit
  exact PetersenRoutedPin.quick rowOk2 s small hot2 p hit
def rule3 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages3 s.steps 0 6 i5 p
theorem correct3 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule3 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r3 tgt) 6 := by rw [match3]; exact PetersenCycleFive.no_six_gates
  intro d L hit
  exact PetersenRoutedPin.quick rowOk3 s small hot3 p hit
def rule16 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages16 s.steps 0 6 i6 p
theorem correct16 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule16 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r16 tgt) 6 := by rw [match16]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk16 s small hot16 p hit
def rule17 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages17 s.steps 0 6 i6 p
theorem correct17 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule17 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r17 tgt) 6 := by rw [match17]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk17 s small hot17 p hit
def rule18 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages18 s.steps 0 6 i6 p
theorem correct18 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule18 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r18 tgt) 6 := by rw [match18]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk18 s small hot18 p hit
def rule19 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages19 s.steps 0 6 i6 p
theorem correct19 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule19 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r19 tgt) 6 := by rw [match19]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk19 s small hot19 p hit
def rule20 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages20 s.steps 0 6 i6 p
theorem correct20 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule20 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r20 tgt) 6 := by rw [match20]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk20 s small hot20 p hit
def rule21 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages21 s.steps 0 6 i6 p
theorem correct21 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule21 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r21 tgt) 6 := by rw [match21]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk21 s small hot21 p hit
def rule22 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages22 s.steps 0 6 i6 p
theorem correct22 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule22 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r22 tgt) 6 := by rw [match22]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk22 s small hot22 p hit
def rule23 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages23 s.steps 0 6 i6 p
theorem correct23 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule23 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r23 tgt) 6 := by rw [match23]; exact PetersenGraphCosts.M111.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk23 s small hot23 p hit
def rule26 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages26 s.steps 0 10 i7 p
theorem correct26 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule26 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r26 tgt) 10 := by rw [match26]; exact Extra1020K12.b191_0 ThetaCert.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk26 s small hot26 p hit
def rule27 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages27 s.steps 128 6 i7 p
theorem correct27 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule27 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r27 tgt) 6 := by rw [match27]; exact Extra1020K12.b47_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk27 s small hot27 p hit
def rule29 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages29 s.steps 128 6 i7 p
theorem correct29 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule29 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r29 tgt) 6 := by rw [match29]; exact Extra1020K12.b15_3
  intro d L hit
  exact PetersenRoutedPin.quick rowOk29 s small hot29 p hit
def rule30 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 i7 p
theorem correct30 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule30 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Extra1020K12.b191_0 ThetaCert.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule31 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages31 s.steps 128 6 i7 p
theorem correct31 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule31 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r31 tgt) 6 := by rw [match31]; exact Extra1020K12.b47_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk31 s small hot31 p hit
def rule32 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 i7 p
theorem correct32 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule32 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Extra1020K12.b191_0 ThetaCert.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule33 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages33 s.steps 128 6 i7 p
theorem correct33 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule33 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r33 tgt) 6 := by rw [match33]; exact Extra1020K12.b47_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk33 s small hot33 p hit
def rule34 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 i7 p
theorem correct34 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule34 s p) tgt := by
  have small : NoAtMost i7 (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Extra1020K12.b191_0 ThetaCert.bound
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
end MC161RCert
