import HMC161RHyp
import M15StartLabeled
import M31StartLabeled
import M47StartLabeled
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold0_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)

theorem hold1_0 : NoAtMost (0xaaaa :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xaaaa (by decide +kernel)

theorem hold2_0 : NoAtMost (0xf000f0 :: inputs 5) 0xfaeaf8c8 4 := by
  exact PetersenSmallStarts.M47.all_forbidden 0xf000f0 (by decide +kernel)

theorem hold3_0 : NoAtMost (0xaaaa :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xaaaa (by decide +kernel)

theorem hold4_0 : NoAtMost (0xcccc :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xcccc (by decide +kernel)

theorem hold5_0 : NoAtMost (0xf0f0 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xf0f0 (by decide +kernel)

theorem hold6_0 : NoAtMost (0xff00 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xff00 (by decide +kernel)

theorem hold7_0 : NoAtMost (0xaa00aa :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xaa00aa (by decide +kernel)

theorem hold8_0 : NoAtMost (0xcc00cc :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xcc00cc (by decide +kernel)

theorem hold9_0 : NoAtMost (0xff0000 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xff0000 (by decide +kernel)

theorem hold10_0 : NoAtMost (0xa0a0a0a :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a (by decide +kernel)

theorem hold11_0 : NoAtMost (0xc0c0c0c :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xc0c0c0c (by decide +kernel)
end MC161RCert
