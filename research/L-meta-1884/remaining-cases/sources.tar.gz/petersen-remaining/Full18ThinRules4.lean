import PetersenProjectedRule
import Full18FastBases
import Full18Data3
import Full18ThinView0
import Full18ThinView4
import Full18ThinView5
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound3258 (h : Needs) : Correct rule3258 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3258) (t := Root17.tgt) SEP13 ONES13 thinBasis12 TG13 (baseThin12 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound3259 (h : Needs) : Correct rule3259 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3259) (t := Root17.tgt) SEP13 ONES13 thinBasis12 TG13 (baseThin12 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3260 (h : Needs) : Correct rule3260 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3260) (t := Root17.tgt) SEP14 ONES14 thinBasis12 TG14 (baseThin12 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound3261 (h : Needs) : Correct rule3261 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3261) (t := Root17.tgt) SEP14 ONES14 thinBasis12 TG14 (baseThin12 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3288 (h : Needs) : Correct rule3288 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3288) (t := Root17.tgt) SEP98 ONES98 thinBasis5 TG98 (baseThin5 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3290 (h : Needs) : Correct rule3290 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3290) (t := Root17.tgt) SEP98 ONES98 thinBasis5 TG98 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3294 (h : Needs) : Correct rule3294 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3294) (t := Root17.tgt) SEP98 ONES98 thinBasis14 TG98 (baseThin14 h) (by decide +kernel) [(false,(1,true),(4,true)),(false,(4,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3302 (h : Needs) : Correct rule3302 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3302) (t := Root17.tgt) SEP98 ONES98 thinBasis14 TG98 (baseThin14 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3308 (h : Needs) : Correct rule3308 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3308) (t := Root17.tgt) SEP98 ONES98 thinBasis13 TG98 (baseThin13 h) (by decide +kernel) [(false,(1,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3319 (h : Needs) : Correct rule3319 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3319) (t := Root17.tgt) SEP98 ONES98 thinBasis13 TG98 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3357 (h : Needs) : Correct rule3357 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3357) (t := Root17.tgt) SEP127 ONES127 thinBasis5 TG127 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3375 (h : Needs) : Correct rule3375 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3375) (t := Root17.tgt) SEP127 ONES127 thinBasis14 TG127 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3379 (h : Needs) : Correct rule3379 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3379) (t := Root17.tgt) SEP168 ONES168 thinBasis1 TG168 (baseThin1 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound3390 (h : Needs) : Correct rule3390 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3390) (t := Root17.tgt) SEP168 ONES168 thinBasis1 TG168 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3407 (h : Needs) : Correct rule3407 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3407) (t := Root17.tgt) SEP159 ONES159 thinBasis1 TG159 (baseThin1 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound3421 (h : Needs) : Correct rule3421 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3421) (t := Root17.tgt) SEP159 ONES159 thinBasis1 TG159 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3443 (h : Needs) : Correct rule3443 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3443) (t := Root17.tgt) SEP98 ONES98 thinBasis2 TG98 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3457 (h : Needs) : Correct rule3457 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3457) (t := Root17.tgt) SEP98 ONES98 thinBasis2 TG98 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3467 (h : Needs) : Correct rule3467 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3467) (t := Root17.tgt) SEP98 ONES98 thinBasis7 TG98 (baseThin7 h) (by decide +kernel) [(false,(3,true),(7,true)),(false,(4,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3471 (h : Needs) : Correct rule3471 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3471) (t := Root17.tgt) SEP98 ONES98 thinBasis7 TG98 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3479 (h : Needs) : Correct rule3479 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3479) (t := Root17.tgt) SEP103 ONES103 thinBasis7 TG103 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3545 (h : Needs) : Correct rule3545 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3545) (t := Root17.tgt) SEP98 ONES98 thinBasis16 TG98 (baseThin16 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3592 (h : Needs) : Correct rule3592 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3592) (t := Root17.tgt) SEP98 ONES98 thinBasis0 TG98 (baseThin0 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3601 (h : Needs) : Correct rule3601 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3601) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(3,true),(0,true))] rfl (by decide +kernel)
theorem quickSound3608 (h : Needs) : Correct rule3608 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3608) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(3,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3611 (h : Needs) : Correct rule3611 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3611) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3625 (h : Needs) : Correct rule3625 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3625) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound3633 (h : Needs) : Correct rule3633 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3633) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(4,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3636 (h : Needs) : Correct rule3636 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3636) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(4,true),(5,true)),(false,(5,true),(1,false))] rfl (by decide +kernel)
theorem quickSound3637 (h : Needs) : Correct rule3637 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3637) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound3638 (h : Needs) : Correct rule3638 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3638) (t := Root17.tgt) SEP127 ONES127 thinBasis2 TG127 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3657 (h : Needs) : Correct rule3657 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3657) (t := Root17.tgt) SEP127 ONES127 thinBasis7 TG127 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
