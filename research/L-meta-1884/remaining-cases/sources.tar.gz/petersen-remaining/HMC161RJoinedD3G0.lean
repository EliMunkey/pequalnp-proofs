import HMC161RHyp
import HMC161RJoinedD4G0
import HMC161RRules0
import HMC161RRules1
import HMC161RRules2
import HMC161RRules3
import HMC161RRules4
import HMC161RRules5
import HMC161RRules6
import HMC161RRules7
import HMC161RRules9
import HMC161RSym
import HMC161RW0
import HMC161RW1
import PetersenSymmetry
import Q1020K12Closing
import first8.MixedNode
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 150000
set_option maxHeartbeats 0
set_option linter.concreteInstances false

def s3_1067 : List (BitVec 256) := [w22,w212,w298,w341,w379,w423,w456,w501,w537]
private def c3_1067 : Array (PetersenProjectedRule.Rule 256) := #[rule33 route0 [],rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(7,true)),(false,(7,true),(0,true))],rule94 route3 [],rule27 route5 [],rule32 route3 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule2 route0 [(false,(4,false),(0,true))],rule288 route3 [],rule27 route4 [],rule2 route3 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule26 route3 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule34 route0 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))],rule83 route3 [],rule30 route3 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))],rule1 route3 [],rule3 route6 [],rule0 route3 [(false,(3,false),(4,true))],rule0 route0 [],rule110 route3 [],rule383 route0 [],rule95 route0 [],rule98 route0 [],rule2 route7 [(false,(4,false),(0,true))],rule0 route0 [(false,(4,false),(3,true))],rule117 route0 [],rule97 route0 [],rule100 route0 []]
private def m3_1067 : Array (List (BitVec 256)) := #[[w0,w212,w298,w341,w379,w423,w456,w501,w537],[w211,w212,w298,w341,w379,w423,w456,w501,w537],[w212,w298,w341,w379,w423,w456,w501,w537,w545]]
private def hs3_1067 : List (List Nat) := [[8262,27,49382,8262,28,0],[545,1,545,8255,2,8255,545,3,545,8255,4,8255],[289,5,289,9284,6,9284,289,7,289,9284,8,9284],[548,9,548,8772,6,8772,548,3,548,8772,10,8772],[32942,11,32942,16494,12,16494,32942,0,32942,16494,13,16494],[70,5,70,16767,14,16767,70,15,70,16767,16,16767],[102,17,102,8832,18,8832,102,5,102,8832,14,8832],[1186,27,1186,8382,29,0],[545,49382,545,8255,49639,8255,545,49639,545,8255,49382,8255],[289,49382,289,9284,19,9284,289,0,289,9284,49382,9284],[548,49382,548,8772,19,8772,548,0,548,8772,49382,8772],[32942,49382,32942,16494,20,16494,32942,0,32942,16494,49382,16494],[70,49382,70,16767,21,16767,70,22,70,16767,49382,16767],[102,23,102,8832,49382,8832,102,49382,102,8832,23,8832],[1186,0,1186,49382,49382,0,49254,24,0],[1060,8255,1060,289,545,289,33,545,1060,33,8255,289],[545,545,548,9279,9283,33187,548,9283,548,545,545,33187],[545,545,16494,4641,4657,16751,561,4657,16494,545,545,16751],[70,545,70,326,8255,327,70,8255,70,71,545,327],[102,545,102,358,24703,359,102,24703,102,103,545,359],[545,545,1186,1442,33441,1443,673,33441,1186,545,545,1443],[289,289,32930,548,1060,548,36,1060,32930,36,289,548],[289,289,16494,4385,4401,33456,305,4401,16494,289,289,33456],[70,289,70,582,9284,584,70,9284,70,72,289,584],[102,289,102,608,24704,608,96,24704,102,96,289,608],[289,289,1186,4782,33185,4784,417,33185,1186,289,289,4784],[548,548,16494,4644,4660,17522,564,4660,16494,548,548,17522],[70,548,70,1094,8772,1098,70,8772,70,74,548,1098],[102,548,102,1126,49378,1130,102,49378,102,106,548,1130],[548,548,4270,1186,32930,1186,162,32930,4270,162,548,1186],[70,16494,70,4166,24718,4182,70,24718,70,86,16494,4182],[102,32942,102,4198,16494,4214,102,16494,102,118,32942,4214],[1186,16494,1186,4270,32942,4270,174,32942,1186,174,16494,4270],[70,70,102,8832,16767,8832,102,16767,102,70,70,8832],[70,70,1186,32838,32966,25,198,32966,1186,70,70,25],[102,102,1186,32870,32998,26,230,32998,1186,102,102,26]]
theorem node3_1067 [Assumptions] : Blocked tgt 9 s3_1067 := by
  refine PetersenMixedNode.close (cut := c3_1067) (more := m3_1067) (hs := hs3_1067) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route0 []) (correct33 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(7,true)),(false,(7,true),(0,true))]) (correct26 route0 [(false,(0,false),(4,true)),(false,(0,true),(7,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule94 route3 []) (correct94 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route5 []) (correct27 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route3 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route3 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,false),(0,true))]) (correct2 route0 [(false,(4,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule288 route3 []) (correct288 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route4 []) (correct27 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct2 route3 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct30 route0 [(false,(2,false),(3,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route3 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route3 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) (correct34 route0 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule83 route3 []) (correct83 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route3 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route3 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route3 []) (correct1 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route6 []) (correct3 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route3 [(false,(3,false),(4,true))]) (correct0 route3 [(false,(3,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route3 []) (correct110 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule383 route0 []) (correct383 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule95 route0 []) (correct95 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule98 route0 []) (correct98 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route7 [(false,(4,false),(0,true))]) (correct2 route7 [(false,(4,false),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(4,false),(3,true))]) (correct0 route0 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route0 []) (correct117 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route0 []) (correct97 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule100 route0 []) (correct100 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w212,w298,w341,w379,w423,w456,w501,w537]) (via sym3 fix3 (by decide +kernel) (Orbits1020Cost12.b4_0 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w211,w212,w298,w341,w379,w423,w456,w501,w537]) (via sym3 fix3 (by decide +kernel) (Orbits1020Cost12.b4_1415 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w212,w298,w341,w379,w423,w456,w501,w537,w545]) (via sym3 fix3 (by decide +kernel) (Orbits1020Cost12.b4_1691 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_1101 : List (BitVec 256) := [w25,w91,w219,w298,w341,w379,w423,w456,w501,w537]
private def c3_1101 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route0 [],rule255 route1 [],rule33 route0 [],rule2 route3 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule383 route0 [],rule100 route0 []]
private def m3_1101 : Array (List (BitVec 256)) := #[]
private def hs3_1101 : List (List Nat) := [[0,1,2,3],[8238,8238],[521,8231,521,8231],[49352,16456,49352,16456],[524,8748,524,8748],[32918,16470,32918,16470],[46,16743,46,16743],[78,12406,78,12406],[1162,8358],[49358,4,49358,2],[8231,521,8231,521],[265,265],[32906,524,32906,524],[16470,33432,16470,33432],[46,560,46,560],[78,592],[1162,4760,1162,4760],[521,8231,521,8231],[49358,16456,5,16456],[524,8748,524,8748],[32918,16470,32918,16470],[46,16743,46,16743],[78,12406,78,12406],[1162,49358,49230],[8231,521,521,8231],[521,9255,524,521],[521,4617,537,521],[46,302,46,47],[78,334,78,79],[521,1418,649,521],[16456,524,16460,524],[16456,33432,16470,16456],[46,560,46,560],[78,16456,80],[1162,4760,1162,4760],[524,4620,540,524],[46,1070,46,50],[78,1102,78,82],[524,1162,138,138],[46,4142,46,62],[78,4174,78,94],[1162,4246,150,150],[46,12374,78,46],[46,32814,174,46],[78,32846,206,78]]
theorem node3_1101 [Assumptions] : Blocked tgt 9 s3_1101 := by
  refine PetersenMixedNode.close (cut := c3_1101) (more := m3_1101) (hs := hs3_1101) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule255 route1 []) (correct255 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route0 []) (correct33 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route3 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule383 route0 []) (correct383 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule100 route0 []) (correct100 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_1103 : List (BitVec 256) := [w25,w140,w219,w298,w341,w379,w423,w456,w501]
private def c3_1103 : Array (PetersenProjectedRule.Rule 256) := #[rule109 route2 [],rule98 route0 [],rule1 route0 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule346 route2 [],rule54 route5 [],rule2 route0 [],rule1 route2 [],rule2 route2 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule97 route0 [],rule99 route0 [],rule100 route7 [],rule37 route0 [(false,(5,true),(6,true))],rule41 route2 [(false,(5,true),(6,true))],rule32 route0 [(false,(2,false),(6,true)),(false,(5,true),(7,true)),(false,(0,true),(4,true))]]
private def m3_1103 : Array (List (BitVec 256)) := #[[w140,w218,w219,w298,w341,w379,w423,w456,w501],[w25,w219,w298,w341,w379,w423,w456,w501,w566],[w25,w74,w219,w298,w341,w379,w423,w456,w501]]
private def hs3_1103 : List (List Nat) := [[1173,8369,1173,17621,0,1],[8249,8369,49369,8249,14,2],[532,8369,532,8242,3,8242,532,4,532,8242,8369,8242],[276,8369,276,8371,8883,9271,276,8883,276,8369,8369,9271],[535,8369,535,8373,9397,8759,535,9397,535,8369,8369,8759],[8369,8369,32929,8385,12481,16481,12465,12481,32929,8369,8369,16481],[57,5,57,8369,8369,16754,57,8369,57,16754,6,16754],[89,8369,89,8433,24817,8819,89,24817,89,8369,8369,8819],[1173,1173,7,49369,8,49369,49241,8,2,1173,1173,49369],[532,1173,532,1429,1430,33428,532,1430,532,660,1173,33428],[276,1173,276,4769,4771,33172,276,4771,276,404,1173,33172],[535,4257,535,1173,1173,32917,149,1173,535,149,4257,32917],[1173,1173,16481,4257,4257,32929,161,4257,16481,161,1173,32929],[57,1173,57,32825,15,8],[89,1173,89,32857,9,32985,89,16,89,217,1173,32985],[532,49369,532,8242,49626,8242,532,49626,532,8242,49369,8242],[276,49369,276,9271,8,9271,276,10,276,9271,49369,9271],[535,49369,535,8759,8,8759,535,1,535,8759,49369,8759],[32929,49369,32929,16481,8,16481,32929,1,32929,16481,49369,16481],[57,49369,57,16754,11,16754,57,12,57,177,49369,16754],[89,1,89,8819,49369,8819,89,49369,89,8819,13,8819],[1047,8242,1047,276,532,276,20,532,1047,20,8242,276],[532,532,535,9266,9270,33174,535,9270,535,532,532,33174],[532,532,16481,4628,4644,16738,548,4644,16481,532,532,16738],[57,532,57,313,8242,314,57,8242,57,58,532,314],[89,532,89,345,24690,346,89,24690,89,90,532,346],[276,276,32917,535,1047,535,23,1047,32917,23,276,535],[276,276,16481,4372,4388,33443,292,4388,16481,276,276,33443],[57,276,57,569,9271,571,57,9271,57,59,276,571],[89,276,89,601,16467,603,89,16467,89,91,276,603],[535,535,16481,4631,4647,17509,551,4647,16481,535,535,17509],[57,535,57,1081,8759,1085,57,8759,57,61,535,1085],[89,535,89,1113,49365,1117,89,49365,89,93,535,1117],[57,16481,57,4153,24705,4169,57,24705,57,73,16481,4169],[89,32929,89,4185,16481,4201,89,16481,89,105,32929,4201],[57,57,89,8787,16754,8819,89,16754,89,57,57,8819]]
theorem node3_1103 [Assumptions] : Blocked tgt 9 s3_1103 := by
  refine PetersenMixedNode.close (cut := c3_1103) (more := m3_1103) (hs := hs3_1103) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route2 []) (correct109 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule98 route0 []) (correct98 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct1 route0 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule346 route2 []) (correct346 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule54 route5 []) (correct54 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route2 []) (correct1 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route2 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route2 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route0 []) (correct97 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route0 []) (correct99 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule100 route7 []) (correct100 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 [(false,(5,true),(6,true))]) (correct37 route0 [(false,(5,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route2 [(false,(5,true),(6,true))]) (correct41 route2 [(false,(5,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(2,false),(6,true)),(false,(5,true),(7,true)),(false,(0,true),(4,true))]) (correct32 route0 [(false,(2,false),(6,true)),(false,(5,true),(7,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w140,w218,w219,w298,w341,w379,w423,w456,w501]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_923 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w219,w298,w341,w379,w423,w456,w501,w566]) (Orbits1020Cost12.b4_372 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w74,w219,w298,w341,w379,w423,w456,w501]) (via sym3 fix3 (by decide +kernel) (Orbits1020Cost12.b4_68 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_1110 : List (BitVec 256) := [w25,w215,w298,w341,w379,w423,w456,w501,w537]
private def c3_1110 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [(false,(4,false),(3,true))],rule26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))],rule83 route2 [],rule27 route5 [],rule30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))],rule33 route0 [],rule397 route2 [],rule74 route2 [],rule30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))],rule26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule94 route2 [],rule32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule32 route0 [(false,(6,false),(2,true)),(false,(0,true),(5,true))],rule110 route2 [],rule0 route2 [(false,(3,false),(4,true))],rule1 route2 [],rule383 route0 [],rule33 route7 [],rule95 route0 [],rule1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule98 route0 [],rule99 route0 []]
private def m3_1110 : Array (List (BitVec 256)) := #[[w0,w215,w298,w341,w379,w423,w456,w501,w537],[w213,w215,w298,w341,w379,w423,w456,w501,w537],[w215,w298,w341,w379,w423,w456,w501,w502,w537],[w2,w215,w298,w341,w379,w423,w456,w501,w537],[w215,w298,w341,w379,w423,w456,w501,w537,w547],[w25,w298,w341,w379,w423,w456,w469,w501,w537],[w25,w115,w298,w341,w379,w423,w456,w501,w537],[w25,w214,w298,w341,w379,w423,w456,w501,w537],[w25,w298,w341,w379,w387,w423,w456,w501,w537]]
private def hs3_1110 : List (List Nat) := [[8264,23,49384,8264,24,0],[547,1,547,8257,2,8257,547,3,547,8257,4,8257],[291,5,291,9286,6,9286,291,3,291,9286,7,9286],[550,8,550,8774,6,8774,550,3,550,8774,9,8774],[32944,10,32944,16496,11,16496,32944,5,32944,16496,12,16496],[72,13,72,16769,14,16769,72,15,72,16769,16,16769],[104,0,104,8834,25,8834,104,26,104,8834,15,8834],[1188,23,1188,17636,27,5],[547,49384,547,8257,49641,8257,547,49641,547,8257,49384,8257],[291,49384,291,9286,17,9286,291,18,291,9286,49384,9286],[550,49384,550,8774,17,8774,550,5,550,8774,49384,8774],[32944,49384,32944,16496,19,16496,32944,5,32944,16496,49384,16496],[72,49384,72,16769,28,16769,72,29,72,16769,49384,16769],[104,30,104,8834,49384,8834,104,49384,104,8834,31,8834],[1188,0,1188,49384,49384,5,49256,20,5],[1062,8257,1062,291,547,291,35,547,1062,35,8257,291],[547,547,550,9281,9285,33189,550,9285,550,547,547,33189],[547,547,16496,4643,4659,16753,563,4659,16496,547,547,16753],[72,547,72,328,8257,329,72,8257,72,73,547,329],[104,547,104,360,24705,361,104,24705,104,105,547,361],[547,547,1188,1444,33443,1445,675,33443,1188,547,547,1445],[291,291,32932,550,1062,550,38,1062,32932,38,291,550],[291,291,16496,4387,4403,33458,307,4403,16496,291,291,33458],[72,291,72,584,9286,586,72,9286,72,74,291,586],[104,291,104,616,16482,618,104,16482,104,106,291,618],[291,291,1188,4784,33187,4786,419,33187,1188,291,291,4786],[550,550,16496,4646,4662,17524,566,4662,16496,550,550,17524],[72,550,72,1096,8774,1100,72,8774,72,76,550,1100],[104,550,104,1128,49380,1132,104,49380,104,108,550,1132],[550,550,4272,1188,32932,1188,164,32932,4272,164,550,1188],[72,16496,72,4168,24720,4184,72,24720,72,88,16496,4184],[104,32944,104,4200,16496,4216,104,16496,104,120,32944,4216],[1188,16496,1188,4272,32944,4272,176,32944,1188,176,16496,4272],[72,72,104,8802,16769,8834,104,16769,104,72,72,8834],[72,72,1188,32840,32960,21,192,32960,1188,72,72,21],[104,104,1188,32872,33000,22,232,33000,1188,104,104,22]]
theorem node3_1110 [Assumptions] : Blocked tgt 9 s3_1110 := by
  refine PetersenMixedNode.close (cut := c3_1110) (more := m3_1110) (hs := hs3_1110) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(4,false),(3,true))]) (correct0 route0 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))]) (correct26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule83 route2 []) (correct83 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route5 []) (correct27 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route0 []) (correct33 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule397 route2 []) (correct397 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule74 route2 []) (correct74 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) (correct30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule94 route2 []) (correct94 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true)),(false,(0,true),(5,true))]) (correct32 route0 [(false,(6,false),(2,true)),(false,(0,true),(5,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route2 []) (correct110 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route2 [(false,(3,false),(4,true))]) (correct0 route2 [(false,(3,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route2 []) (correct1 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule383 route0 []) (correct383 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route7 []) (correct33 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule95 route0 []) (correct95 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule98 route0 []) (correct98 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route0 []) (correct99 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w215,w298,w341,w379,w423,w456,w501,w537]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_0 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w213,w215,w298,w341,w379,w423,w456,w501,w537]) (via sym3 fix3 (by decide +kernel) (Orbits1020Cost12.b4_1430 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w215,w298,w341,w379,w423,w456,w501,w502,w537]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1725 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w2,w215,w298,w341,w379,w423,w456,w501,w537]) (Orbits1020Cost12.b4_34 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w215,w298,w341,w379,w423,w456,w501,w537,w547]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1718 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w298,w341,w379,w423,w456,w469,w501,w537]) (Orbits1020Cost12.b4_390 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w115,w298,w341,w379,w423,w456,w501,w537]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_258 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w214,w298,w341,w379,w423,w456,w501,w537]) (Orbits1020Cost12.b4_366 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w25,w298,w341,w379,w387,w423,w456,w501,w537]) (Orbits1020Cost12.b4_382 ThetaCert.bound) <|
      PetersenLocalChildren.nil

def s3_1129 : List (BitVec 256) := [w29,w140,w298,w341,w379,w391,w423,w501,w553]
private def c3_1129 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule41 route0 [],rule76 route0 [],rule69 route6 [],rule76 route5 [],rule69 route0 []]
private def m3_1129 : Array (List (BitVec 256)) := #[[w152,w298,w341,w379,w391,w423,w501,w553],[w140,w298,w341,w379,w391,w423,w501,w553,w576]]
private def hs3_1129 : List (List Nat) := [[297,297,32936,6,0,1],[523,2096,523,297,297,8233,41,297,523,41,2096,8233],[267,297,267,2608,2610,9262,267,2610,267,297,297,9262],[297,297,526,1321,1325,8750,301,1325,526,297,297,8750],[297,297,16464,2096,2096,8240,48,2096,16464,48,297,8240],[297,297,16472,4393,4409,24696,313,4409,16472,297,297,24696],[297,297,2128,12376,16745,12408,361,16745,2128,297,297,12408],[168,297,168,8360,7,1],[523,32936,523,32937,33193,33419,523,33193,523,32936,32936,33419],[267,32936,267,32938,33450,33163,267,33450,267,32936,32936,33163],[526,32936,526,32908,2,32908,526,3,526,32908,32936,32908],[8240,32936,8240,32944,34992,49360,8240,34992,8240,32936,32936,49360],[16472,32936,16472,32920,4,32920,16472,0,16472,32920,32936,32920],[2128,32936,2128,33000,49384,33482,2128,49384,2128,32936,32936,33482],[168,32936,168,1164,1,5],[1038,8233,1038,267,523,267,11,523,1038,11,8233,267],[523,523,526,9257,9261,33165,526,9261,526,523,523,33165],[523,523,8240,2571,2579,16721,531,2579,8240,523,523,16721],[523,523,16472,4619,4635,16729,539,4635,16472,523,523,16729],[523,523,2128,2384,24681,2385,2128,24681,2128,523,523,2385],[168,523,168,424,33419,425,168,33419,168,169,523,425],[267,267,32908,526,1038,526,14,1038,32908,14,267,526],[267,267,8240,2315,2323,8754,275,2323,8240,267,267,8754],[267,267,16472,4363,4379,33434,283,4379,16472,267,267,33434],[267,267,2128,2640,49354,33482,2128,49354,2128,267,267,33482],[168,267,168,680,33163,682,168,33163,168,170,267,682],[526,526,8240,2574,2582,9268,534,2582,8240,526,526,9268],[526,526,16472,4622,4638,17500,542,4638,16472,526,526,17500],[526,526,2128,3152,49356,3156,2128,49356,2128,526,526,3156],[168,526,168,1192,32908,1196,168,32908,168,172,526,1196],[8240,8240,16472,12336,12352,34976,8256,12352,16472,8240,8240,34976],[4184,8240,4184,2128,16464,2128,80,16464,4184,80,8240,2128],[168,8240,168,2216,49360,2224,168,49360,168,176,8240,2224],[2128,32920,2128,4184,16472,4184,88,16472,2128,88,32920,4184],[168,16472,168,4264,32920,4280,168,32920,168,184,16472,4280],[168,2128,168,16552,33482,16616,168,33482,168,232,2128,16616]]
theorem node3_1129 [Assumptions] : Blocked tgt 9 s3_1129 := by
  refine PetersenMixedNode.close (cut := c3_1129) (more := m3_1129) (hs := hs3_1129) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route0 []) (correct76 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route5 []) (correct76 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w152,w298,w341,w379,w391,w423,w501,w553]) (via sym2 fix2 (by decide +kernel) node4_1677) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w140,w298,w341,w379,w391,w423,w501,w553,w576]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_973 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_2090 : List (BitVec 256) := [w41,w144,w298,w341,w379,w391,w423,w501,w537]
private def c3_2090 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route6 [],rule41 route0 [],rule39 route1 [],rule37 route6 [],rule109 route0 [],rule97 route2 []]
private def m3_2090 : Array (List (BitVec 256)) := #[[w153,w298,w341,w379,w391,w423,w501,w537]]
private def hs3_2090 : List (List Nat) := [[296,296,16744,6,0,1],[522,2095,522,296,296,8232,40,296,522,40,2095,8232],[266,296,266,2607,2609,9261,266,2609,266,296,296,9261],[296,296,525,1320,1324,8749,300,1324,525,296,296,8749],[296,296,16463,2095,2095,8239,47,2095,16463,47,296,8239],[296,296,16471,4392,4408,1,312,4408,16471,296,296,1],[296,296,360,8777,0,8809,360,2,360,296,296,8809],[167,296,167,8359,3,1],[522,32935,522,16488,16744,33418,522,16744,522,32935,32935,33418],[266,16744,266,16457,33449,33162,266,33449,266,16744,16744,33162],[525,16744,525,16748,17772,32907,525,17772,525,16744,16744,32907],[8239,16744,8239,16463,34991,16463,8239,34991,8239,16463,16744,16463],[16503,16744,24695,16471,4,16471,24663,5,24695,16471,16744,16471],[360,32935,360,16744,16744,33481,360,16744,360,2127,32935,33481],[167,16744,167,16615,32935,17611,167,32935,167,1163,16744,17611],[1037,8232,1037,266,522,266,10,522,1037,10,8232,266],[522,522,525,9256,9260,33164,525,9260,525,522,522,33164],[522,522,8239,2570,2578,16720,530,2578,8239,522,522,16720],[522,522,16471,4618,4634,16728,538,4634,16471,522,522,16728],[522,522,585,360,24680,360,104,24680,585,104,522,360],[167,522,167,423,33418,424,167,33418,167,168,522,424],[266,266,32907,525,1037,525,13,1037,32907,13,266,525],[266,266,8239,2314,2322,8753,274,2322,8239,266,266,8753],[266,266,16471,4362,4378,33433,282,4378,16471,266,266,33433],[266,266,360,585,24649,585,73,24649,360,73,266,585],[167,266,167,679,33162,681,167,33162,167,169,266,681],[525,525,8239,2573,2581,9267,533,2581,8239,525,525,9267],[525,525,16471,4621,4637,17499,541,4637,16471,525,525,17499],[360,525,360,1384,49355,1388,360,49355,360,364,525,1388],[167,525,167,1191,32907,1195,167,32907,167,171,525,1195],[8239,8239,16471,12335,12351,34975,8255,12351,16471,8239,8239,34975],[360,8239,360,2159,16463,2159,111,16463,360,111,8239,2159],[167,8239,167,2215,49359,2223,167,49359,167,175,8239,2223],[360,32919,360,4215,16471,4215,119,16471,360,119,32919,4215],[167,16471,167,4263,32919,4279,167,32919,167,183,16471,4279],[167,360,167,17547,33481,17611,167,33481,167,231,360,17611]]
theorem node3_2090 [Assumptions] : Blocked tgt 9 s3_2090 := by
  refine PetersenMixedNode.close (cut := c3_2090) (more := m3_2090) (hs := hs3_2090) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route6 []) (correct37 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route0 []) (correct109 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w153,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) node4_1703) <|
      PetersenLocalChildren.nil
def s3_2097 : List (BitVec 256) := [w41,w192,w298,w341,w379,w391,w456,w501,w537]
private def c3_2097 : Array (PetersenProjectedRule.Rule 256) := #[rule107 route1 [],rule41 route0 [],rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))],rule412 route1 [(false,(0,true),(1,true)),(false,(0,false),(6,false)),(false,(4,true),(1,true))],rule41 route5 [],rule26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule116 route1 [],rule39 route1 [],rule2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))],rule99 route1 [],rule32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))],rule354 route1 [],rule30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))],rule0 route0 [],rule1 route1 [],rule109 route0 [],rule97 route2 []]
private def m3_2097 : Array (List (BitVec 256)) := #[[w0,w192,w298,w341,w379,w391,w456,w501,w537],[w200,w298,w341,w379,w391,w456,w501,w537],[w192,w298,w341,w379,w391,w452,w456,w501,w537]]
private def hs3_2097 : List (List Nat) := [[16487,20,16487,21,0,1],[538,2,538,8248,3,8248,538,4,538,8248,5,8248],[282,6,282,9277,7,9277,282,8,282,9277,9,9277],[541,10,541,8765,11,8765,541,4,541,8765,12,8765],[16479,13,16479,8255,14,8255,16479,1,16479,8255,15,8255],[312,20,16760,312,22,1],[103,16,103,8327,7,8825,103,8,103,8825,17,8825],[167,20,167,8391,8,1],[538,16487,538,16488,16744,24696,538,16744,538,16487,16487,24696],[282,16487,282,16473,33449,33178,282,33449,282,16487,16487,33178],[541,16487,541,16491,17515,32923,541,17515,541,16487,16487,32923],[8255,16487,8255,16479,34991,16479,8255,34991,8255,16479,16487,16479],[16487,16487,18,16519,24711,16760,24679,24711,19,16487,16487,16760],[103,32935,103,16487,16487,33497,103,16487,103,2143,32935,33497],[167,16487,167,16615,32935,17627,167,32935,167,1179,16487,17627],[1053,8248,1053,282,538,282,26,538,1053,26,8248,282],[538,538,541,9272,9276,33180,541,9276,541,538,538,33180],[538,538,8255,2586,2594,16736,546,2594,8255,538,538,16736],[538,538,32951,8248,8248,16760,8248,8248,32951,538,538,16760],[103,538,103,359,24696,360,103,24696,103,104,538,360],[167,538,167,423,33434,424,167,33434,167,168,538,424],[282,282,32923,541,1053,541,29,1053,32923,29,282,541],[282,282,8255,2330,2338,8769,290,2338,8255,282,282,8769],[282,282,16760,9277,9277,33465,9277,9277,16760,282,282,33465],[103,282,103,601,49369,601,89,49369,103,89,282,601],[167,282,167,679,33178,681,167,33178,167,169,282,681],[541,541,8255,2589,2597,9283,549,2597,8255,541,541,9283],[541,541,16760,8765,8765,17788,8765,8765,16760,541,541,17788],[103,541,103,1127,49371,1131,103,49371,103,107,541,1131],[167,541,167,1191,32923,1195,167,32923,167,171,541,1195],[16479,16479,16760,8255,8255,35007,8255,8255,16760,16479,16479,35007],[103,8255,103,2151,16479,2159,103,16479,103,111,8255,2159],[167,8255,167,2215,49375,2223,167,49375,167,175,8255,2223],[103,32951,103,8825,16760,8825,103,16760,103,135,32951,8825],[167,16760,167,24823,32951,24823,167,32951,167,199,16760,24823],[103,103,167,17563,33497,17627,167,33497,167,103,103,17627]]
theorem node3_2097 [Assumptions] : Blocked tgt 9 s3_2097 := by
  refine PetersenMixedNode.close (cut := c3_2097) (more := m3_2097) (hs := hs3_2097) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route1 []) (correct107 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route1 [(false,(0,true),(1,true)),(false,(0,false),(6,false)),(false,(4,true),(1,true))]) (correct412 route1 [(false,(0,true),(1,true)),(false,(0,false),(6,false)),(false,(4,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route5 []) (correct41 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route1 []) (correct116 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route1 []) (correct99 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) (correct26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule354 route1 []) (correct354 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route1 []) (correct1 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route0 []) (correct109 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w192,w298,w341,w379,w391,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_0 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w200,w298,w341,w379,w391,w456,w501,w537]) node4_3129 <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w192,w298,w341,w379,w391,w452,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_1689 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_2423 : List (BitVec 256) := [w44,w215,w298,w341,w379,w423,w456,w501,w537]
private def c3_2423 : Array (PetersenProjectedRule.Rule 256) := #[rule33 route0 [],rule107 route2 [],rule42 route5 [],rule35 route3 [],rule26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))],rule513 route2 [],rule75 route5 [],rule30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))],rule1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))],rule412 route2 [(false,(5,false),(7,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))],rule26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule274 route2 [],rule74 route0 [],rule32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule2 route0 [],rule116 route2 [],rule74 route2 [],rule1 route2 [],rule0 route0 [(false,(4,false),(3,true))],rule39 route2 [],rule39 route0 [],rule0 route2 [(false,(3,false),(4,true))],rule411 route0 [(false,(4,false),(6,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))],rule288 route0 [],rule117 route0 [],rule3 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))],rule117 route7 []]
private def m3_2423 : Array (List (BitVec 256)) := #[[w0,w215,w298,w341,w379,w423,w456,w501,w537],[w215,w298,w333,w341,w379,w423,w456,w501,w537],[w215,w298,w341,w379,w427,w456,w501,w537],[w215,w298,w341,w379,w423,w456,w501,w537,w555]]
private def hs3_2423 : List (List Nat) := [[8265,0,8265,8779,1,8779,8265,2,8265,8779,3,8779],[8258,4,8258,548,5,548,8258,6,8258,548,7,548],[292,29,33188,292,30,8],[32933,9,32933,551,10,551,32933,6,32933,551,11,551],[16497,12,16497,31,13,14,16497,14,16497,15,15,14],[73,16,73,587,17,587,73,18,73,587,19,587],[105,20,105,619,21,619,105,22,105,619,23,619],[1189,29,1189,4787,32,14],[548,8265,548,8258,16746,8258,548,16746,548,8258,8265,8258],[8265,8265,33188,8779,8779,49379,8779,8779,33188,8265,8265,49379],[551,8265,551,8269,9293,8775,551,9293,551,8265,8265,8775],[8265,8265,32945,8281,12377,16497,12361,12377,32945,8265,8265,16497],[73,16489,73,8265,8265,16770,73,8265,73,322,16489,16770],[105,8265,105,8329,16489,8835,105,16489,105,611,8265,8835],[1189,8265,1189,8385,49385,17637,1189,49385,1189,8265,8265,17637],[8258,8258,49379,548,548,33188,548,548,49379,8258,8258,33188],[548,548,551,9282,9286,33190,551,9286,551,548,548,33190],[548,548,16497,4644,4660,16754,564,4660,16497,548,548,16754],[73,548,73,329,8258,330,73,8258,73,74,548,330],[105,548,105,361,24706,362,105,24706,105,106,548,362],[548,548,1189,1445,33444,1446,1189,33444,1189,548,548,1446],[32933,33188,32933,551,24,551,32933,14,32933,551,33188,551],[16497,33188,16497,33457,25,33459,16497,14,16497,32947,33188,33459],[73,33188,73,587,26,587,73,18,73,587,33188,587],[105,33188,105,619,49379,619,105,49379,105,619,33188,619],[1189,8,1189,33188,33188,14,420,27,28],[551,551,16497,4647,4663,17525,567,4663,16497,551,551,17525],[73,551,73,1097,8775,1101,73,8775,73,77,551,1101],[105,551,105,1129,49381,1133,105,49381,105,109,551,1133],[551,551,4273,1189,32933,1189,165,32933,4273,165,551,1189],[73,16497,73,4169,24721,4185,73,24721,73,89,16497,4185],[105,32945,105,4201,16497,4217,105,16497,105,121,32945,4217],[1189,16497,1189,4273,32945,4273,177,32945,1189,177,16497,4273],[73,73,105,8803,16770,8835,105,16770,105,73,73,8835],[73,73,1189,24833,32961,24833,193,32961,1189,73,73,24833],[105,105,1189,17637,33001,17637,233,33001,1189,105,105,17637]]
theorem node3_2423 [Assumptions] : Blocked tgt 9 s3_2423 := by
  refine PetersenMixedNode.close (cut := c3_2423) (more := m3_2423) (hs := hs3_2423) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule33 route0 []) (correct33 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route2 []) (correct107 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule42 route5 []) (correct42 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route3 []) (correct35 route3 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))]) (correct26 route0 [(false,(6,false),(2,true)),(false,(0,true),(1,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule513 route2 []) (correct513 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route5 []) (correct75 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route2 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct1 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) (correct30 route0 [(false,(0,false),(5,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route2 [(false,(5,false),(7,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))]) (correct412 route2 [(false,(5,false),(7,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route2 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct34 route0 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule274 route2 []) (correct274 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule74 route0 []) (correct74 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route2 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route2 []) (correct116 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule74 route2 []) (correct74 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route2 []) (correct1 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(4,false),(3,true))]) (correct0 route0 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route2 []) (correct39 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route2 [(false,(3,false),(4,true))]) (correct0 route2 [(false,(3,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule411 route0 [(false,(4,false),(6,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))]) (correct411 route0 [(false,(4,false),(6,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule288 route0 []) (correct288 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route0 []) (correct117 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) (correct3 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route7 []) (correct117 route7 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w215,w298,w341,w379,w423,w456,w501,w537]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_0 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w215,w298,w333,w341,w379,w423,w456,w501,w537]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1687 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w215,w298,w341,w379,w427,w456,w501,w537]) (via sym2 fix2 (by decide +kernel) node4_2700) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w215,w298,w341,w379,w423,w456,w501,w537,w555]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1720 ThetaCert.bound)) <|
      PetersenLocalChildren.nil

def s3_2568 : List (BitVec 256) := [w44,w280,w350,w379,w391,w423,w456,w501,w537]
private def c3_2568 : Array (PetersenProjectedRule.Rule 256) := #[rule98 route5 [],rule108 route7 [],rule116 route6 [],rule69 route0 [],rule354 route6 [],rule2 route0 [],rule1 route6 [],rule29 route0 [],rule26 route0 [(false,(6,false),(2,true)),(false,(5,false),(3,true)),(false,(1,true),(6,true))],rule117 route0 [],rule3 route2 [(false,(2,false),(1,true))],rule1 route0 [(false,(4,true),(1,true)),(false,(1,true),(0,true))],rule3 route7 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]]
private def m3_2568 : Array (List (BitVec 256)) := #[[w280,w350,w379,w391,w423,w456,w501,w537,w555],[w44,w296,w350,w379,w391,w423,w456,w501,w537]]
private def hs3_2568 : List (List Nat) := [[8240,0,8240,530,9269,530,8240,9269,8240,530,1,530],[18,9269,32914,18,2,3],[24689,24689,32915,533,9269,533,8245,9269,32915,533,24689,533],[8247,9269,8247,8759,4,8761,8247,3,8247,8249,9269,8761],[9269,9269,16479,13365,13381,3,9285,13381,16479,9269,9269,3],[2615,5,32943,2615,9269,2617,9269,9269,32943,2617,6,2617],[2135,9269,2135,593,24689,593,2135,24689,2135,593,9269,593],[1171,9269,1171,4769,13,7],[530,530,32914,49361,14,8],[530,530,32915,533,9268,533,9264,9268,32915,530,530,533],[530,530,16471,538,2586,8247,2578,2586,16471,530,530,8247],[530,530,16479,546,4642,24703,4626,4642,16479,530,530,24703],[530,530,32943,562,8240,2617,8240,8240,32943,530,530,2617],[530,530,2135,593,24688,593,2135,24688,2135,530,530,593],[530,530,1171,8369,33426,8369,1171,33426,1171,530,530,8369],[32914,32914,32915,533,9,533,32915,3,32915,533,32914,533],[16471,32914,16471,8247,34970,8247,16471,34970,16471,8247,32914,8247],[16479,32914,16479,24703,9,24703,16479,3,16479,24703,32914,24703],[32914,32914,32943,2617,3,2617,48,10,32943,48,32914,2617],[2135,32914,2135,593,49362,593,2135,49362,2135,593,32914,593],[1171,11,1171,8369,32914,8369,146,32914,1171,146,12,8369],[533,533,8247,2581,2589,9275,541,2589,8247,533,533,9275],[533,533,16479,4629,4645,17507,549,4645,16479,533,533,17507],[533,533,2617,8725,8757,9,565,8757,2617,533,533,3],[533,533,593,3159,49363,3163,593,49363,593,533,533,3163],[533,533,4255,1171,32915,1171,147,32915,4255,147,533,1171],[8247,8247,16479,12343,12359,34983,8263,12359,16479,8247,8247,34983],[16471,16471,32943,2617,8247,2617,569,8247,32943,569,16471,2617],[593,8247,593,2135,16471,2135,87,16471,593,87,8247,2135],[1171,8247,1171,3219,49367,3227,1171,49367,1171,1179,8247,3227],[2617,16479,2617,6713,24703,6729,2617,24703,2617,2633,16479,6729],[593,32927,593,4191,16479,4191,95,16479,593,95,32927,4191],[1171,16479,1171,4255,32927,4255,159,32927,1171,159,16479,4255],[593,2617,593,8785,49391,8817,593,49391,593,625,2617,8817],[1171,2617,1171,8369,32943,8369,175,32943,1171,175,2617,8369],[593,593,1171,17555,33489,17619,1171,33489,1171,593,593,17619]]
theorem node3_2568 [Assumptions] : Blocked tgt 9 s3_2568 := by
  refine PetersenMixedNode.close (cut := c3_2568) (more := m3_2568) (hs := hs3_2568) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule98 route5 []) (correct98 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule108 route7 []) (correct108 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route6 []) (correct116 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route0 []) (correct69 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule354 route6 []) (correct354 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route6 []) (correct1 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route0 []) (correct29 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(6,false),(2,true)),(false,(5,false),(3,true)),(false,(1,true),(6,true))]) (correct26 route0 [(false,(6,false),(2,true)),(false,(5,false),(3,true)),(false,(1,true),(6,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route0 []) (correct117 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route2 [(false,(2,false),(1,true))]) (correct3 route2 [(false,(2,false),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) (correct1 route0 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route7 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route7 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w280,w350,w379,w391,w423,w456,w501,w537,w555]) (via sym6 fix6 (by decide +kernel) (Orbits1020Cost12.b4_1747 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w44,w296,w350,w379,w391,w423,w456,w501,w537]) (Orbits1020Cost12.b4_693 ThetaCert.bound) <|
      PetersenLocalChildren.nil
def s3_3047 : List (BitVec 256) := [w47,w264,w298,w341,w379,w391,w423,w456,w501,w537]
private def c3_3047 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route4 [],rule75 route5 [],rule2 route0 [(false,(2,true),(0,false))],rule0 route7 [(false,(4,false),(3,true))],rule26 route7 [(false,(6,false),(2,true))]]
private def m3_3047 : Array (List (BitVec 256)) := #[]
private def hs3_3047 : List (List Nat) := [[0,1,2,3],[12342,520,12342,520],[33160,9259,264,264],[32905,523,32905,523],[12349,8237,12349,8237],[16469,24693,16469,4],[4406,2607,294,294],[33479,583,33479,583],[1161,4759],[520,24678,520,24678],[9259,24679],[523,49353,523,49353],[8237,16461,8237,16461],[32917,16469,32917,16469],[2607,49381,2607,49381],[583,2125],[1161,17609,1161,17609],[8230,520,520,8230],[520,9254,523,520],[520,2568,528,520],[520,4616,536,520],[520,4406,552,520],[520,24678,583,520],[520,1417,1161,520],[32905,523,8235,523],[8237,8749,8237,8239],[9259,33429,9275,9259],[2605,2605,4406,2607],[9259,583,8295],[1161,33160,392,392],[523,2571,531,523],[523,4619,539,523],[523,5430,555,523],[523,49353,583,523],[523,1161,137,137],[8237,12349,8767,8237],[4406,2607,559,559],[583,2631,583,591],[1161,3209,1161,1169],[2607,4406,310,310],[583,4679,583,599],[1161,4245,149,149],[583,8775,583,615],[1161,12437,165,165],[583,17609,1161,583]]
theorem node3_3047 [Assumptions] : Blocked tgt 9 s3_3047 := by
  refine PetersenMixedNode.close (cut := c3_3047) (more := m3_3047) (hs := hs3_3047) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 []) (correct2 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route5 []) (correct75 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(2,true),(0,false))]) (correct2 route0 [(false,(2,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 [(false,(4,false),(3,true))]) (correct0 route7 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route7 [(false,(6,false),(2,true))]) (correct26 route7 [(false,(6,false),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3048 : List (BitVec 256) := [w48,w264,w298,w341,w379,w391,w423,w456,w501,w537]
private def c3_3048 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route4 [],rule75 route5 [],rule2 route0 [(false,(2,true),(0,false))],rule0 route7 [(false,(4,false),(3,true))]]
private def m3_3048 : Array (List (BitVec 256)) := #[]
private def hs3_3048 : List (List Nat) := [[0,1,2,3],[33415,519,33415,519],[33159,9258,263,263],[32904,522,32904,522],[8236,8236,16460,8750],[16468,24692,16468,24692],[2092,2606,293,293],[33478,582,33478,582],[1160,4758],[519,24677,519,24677],[9258,24678],[522,49352,522,49352],[8750,16460,8750,16460],[32916,16468,32916,16468],[2092,49380,2092,49380],[582,2124],[1160,17608,1160,17608],[8229,519,519,8229],[519,9253,522,519],[519,2567,527,519],[519,4615,535,519],[519,2348,551,519],[519,24677,582,519],[519,1416,1160,519],[32904,522,8234,522],[9258,8750,8238,8238],[9258,13354,9274,9258],[2092,2606,2092,2606],[9258,582,8294],[1160,33159,391,391],[522,2570,530,522],[522,4618,538,522],[522,3116,554,522],[522,49352,582,522],[522,1160,136,136],[8750,12846,8766,8750],[16460,2092,44,44],[582,2630,582,590],[1160,3208,1160,1168],[2092,6188,2092,2108],[582,4678,582,598],[1160,4244,148,148],[582,8774,582,614],[1160,32932,164,164],[582,17608,1160,582]]
theorem node3_3048 [Assumptions] : Blocked tgt 9 s3_3048 := by
  refine PetersenMixedNode.close (cut := c3_3048) (more := m3_3048) (hs := hs3_3048) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 []) (correct2 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route5 []) (correct75 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(2,true),(0,false))]) (correct2 route0 [(false,(2,true),(0,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route7 [(false,(4,false),(3,true))]) (correct0 route7 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3697 : List (BitVec 256) := [w56,w91,w150,w298,w341,w379,w391,w423,w501,w537]
private def c3_3697 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3697 : Array (List (BitVec 256)) := #[]
private def hs3_3697 : List (List Nat) := [[289,2602,2602,289],[289,16737],[515,289,33,33],[289,2602,2602,289],[289,1313,293,289],[289,2088,40,40],[289,4385,305,289],[289,12400,353,289],[160,8352],[32928,33442,32928,33442],[8225,515,8225,515],[259,259],[32900,518,32900,518],[8232,8746,8232,8746],[16464,33426,16464,33426],[8802,8802],[160,674,160,674],[515,32929,515,32928],[24674,16450,24674,16450],[518,32900,518,32900],[8232,16456,8232,16456],[24688,16464,24688,16464],[12400,32992,2120,2120],[160,16608,160,1156],[8225,515,515,8225],[515,9249,518,515],[515,2563,523,515],[515,4611,531,515],[515,24609,8289,515],[160,416,160,161],[16450,518,16454,518],[8232,8746,8232,8746],[16450,33426,16464,16450],[12400,16450,8290],[160,674,160,674],[518,2566,526,518],[518,4614,534,518],[518,13424,12400,518],[160,1184,160,164],[8232,12328,8248,8232],[8232,16456,8296,8232],[160,2208,160,168],[32912,12400,8304,8304],[160,4256,160,176],[160,17540,160,224]]
theorem node3_3697 [Assumptions] : Blocked tgt 9 s3_3697 := by
  refine PetersenMixedNode.close (cut := c3_3697) (more := m3_3697) (hs := hs3_3697) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_3699 : List (BitVec 256) := [w56,w91,w195,w298,w341,w379,w391,w456,w501,w537]
private def c3_3699 : Array (PetersenProjectedRule.Rule 256) := #[rule501 route0 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule2 route3 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]]
private def m3_3699 : Array (List (BitVec 256)) := #[[w5,w195,w298,w341,w379,w391,w456,w501,w537]]
private def hs3_3699 : List (List Nat) := [[3,0,1,2],[16468,24692,16468,24692],[519,8229,519,8229],[16454,24678,16454,24678],[522,8746,522,8746],[16460,8236,16460,8236],[293,293],[84,8308,84,8308],[148,8372],[16468,33430,16468,33430],[8229,519,8229,519],[263,263],[32904,522,32904,522],[8236,8750,8236,8750],[32932,33446,32932,33446],[84,598],[148,662,148,662],[519,16469,519,16468],[16468,16454,33430,16454],[522,16472,522,16468],[8236,16460,8236,16460],[16468,24692,24692,16468],[84,16468,84,2124],[148,16596,148,1160],[8229,519,519,8229],[519,9253,522,519],[519,2567,527,519],[519,8229,8229,519],[84,340,84,85],[148,404,148,149],[16454,522,16458,522],[8236,8750,8236,8750],[16454,24678,24678,16454],[84,16454,86],[148,662,148,662],[522,2570,530,522],[522,8746,8746,522],[84,1108,84,88],[148,1172,148,152],[16460,8236,8236,16460],[84,2132,84,92],[148,2196,148,156],[84,8308,84,8308],[148,32932,180],[84,17544,148,84]]
theorem node3_3699 [Assumptions] : Blocked tgt 9 s3_3699 := by
  refine PetersenMixedNode.close (cut := c3_3699) (more := m3_3699) (hs := hs3_3699) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule501 route0 []) (correct501 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route3 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w5,w195,w298,w341,w379,w391,w456,w501,w537]) (Orbits1020Cost12.b4_63 ThetaCert.bound) <|
      PetersenLocalChildren.nil
def s3_3743 : List (BitVec 256) := [w56,w105,w237,w298,w341,w391,w423,w456,w501,w537]
private def c3_3743 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route1 [],rule117 route1 [],rule2 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule69 route3 []]
private def m3_3743 : Array (List (BitVec 256)) := #[]
private def hs3_3743 : List (List Nat) := [[0,1,2,3],[522,8746,522,8746],[519,8229,519,8229],[16458,24682,16458,24682],[16460,8236,16460,8236],[16468,24692,16468,24692],[293,293],[2124,12404,2124,12404],[4758,8870],[49352,522,49352,522],[8229,519,8229,519],[16458,33159,10,10],[8236,8750,8236,8750],[16468,32916,16468,32916],[49380,32932,49380,32932],[582,582],[16584,4758,136,136],[522,519,8229,519],[16458,522,522,16454],[522,530,2570,522],[522,538,4618,522],[522,8746,8746,522],[522,49352,2124,522],[522,650,16584,522],[8229,519,519,8229],[519,2567,527,519],[519,4615,535,519],[519,8229,8229,519],[519,2380,2124,519],[519,16840,647,519],[8236,8750,8236,8750],[16458,33428,16468,16458],[16458,24682,24682,16458],[2124,16458,74,74],[4756,4756,16584,4758],[8236,12332,8252,8236],[16460,8236,8236,16460],[4180,2124,76,76],[4758,6806,4758,4766],[16468,24692,24692,16468],[2124,4180,84,84],[16468,4758,662,662],[2124,12404,2124,12404],[4758,32932,678],[2124,16584,200,200]]
theorem node3_3743 [Assumptions] : Blocked tgt 9 s3_3743 := by
  refine PetersenMixedNode.close (cut := c3_3743) (more := m3_3743) (hs := hs3_3743) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule117 route1 []) (correct117 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route3 []) (correct69 route3 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3749 : List (BitVec 256) := [w56,w105,w298,w341,w379,w391,w423,w456,w521,w537]
private def c3_3749 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3749 : Array (List (BitVec 256)) := #[[w56,w298,w341,w379,w391,w423,w456,w501,w537]]
private def hs3_3749 : List (List Nat) := [[579,8803,579,8803],[516,8226,516,8226],[16451,24675,16451,24675],[519,8743,519,8743],[16457,8233,16457,8233],[16465,24689,16465,24689],[290,290],[2121,12401,2121,12401],[4755,8867],[579,516,8226,516],[16451,579,579,2633],[579,519,49349,519],[579,587,2627,579],[579,595,4675,579],[579,8803,8803,579],[2121,579,579,0],[579,707,1157,579],[8226,516,516,8226],[516,9250,519,516],[516,2564,524,516],[516,4612,532,516],[516,8226,8226,516],[2121,516,516,2122],[516,17861,644,516],[16451,519,16455,519],[8233,8747,8233,8747],[16451,33427,16465,16451],[16451,24675,24675,16451],[67,67],[16451,4755,16579,4755],[519,2567,527,519],[519,4615,535,519],[519,8743,8743,519],[2121,519,519,2125],[519,17605,647,519],[8233,12329,8249,8233],[16457,8233,8233,16457],[4177,2121,73,73],[4755,6803,4755,4763],[16465,24689,24689,16465],[2121,4177,81,81],[16465,4755,659,659],[2121,12401,2121,12401],[4755,32929,675],[2121,4755,1221,1221]]
theorem node3_3749 [Assumptions] : Blocked tgt 9 s3_3749 := by
  refine PetersenMixedNode.close (cut := c3_3749) (more := m3_3749) (hs := hs3_3749) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w456,w501,w537]) (fun m le c => (Orbits1020Cost12.b1_3 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_3756 : List (BitVec 256) := [w56,w106,w298,w341,w379,w391,w423,w456,w501,w537]
private def c3_3756 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route1 [],rule75 route1 [],rule0 route5 [(false,(4,false),(3,true))],rule2 route3 [(false,(2,true),(0,false))]]
private def m3_3756 : Array (List (BitVec 256)) := #[]
private def hs3_3756 : List (List Nat) := [[0,1,2,3],[519,8743,519,8743],[263,24678,263,24678],[522,8746,522,8746],[16460,8236,16460,8236],[16468,24692,16468,24692],[293,293],[2124,12404,2124,12404],[1417,8870],[24677,519,8229,519],[16454,263,1034,263],[49352,522,49352,522],[8236,8750,8236,8750],[16468,32916,16468,32916],[49380,32932,49380,32932],[582,582],[17608,1417,1160,1160],[1290,263,519,263],[519,25701,522,519],[519,2567,527,519],[519,4615,535,519],[519,8743,8743,519],[519,24677,2124,519],[519,1416,647,519],[263,522,267,263],[263,2311,271,263],[263,4359,279,263],[263,24678,24678,263],[263,16454,70,70],[263,4756,391,263],[522,2570,530,522],[522,4618,538,522],[522,8746,8746,522],[522,3148,2124,522],[522,1417,393,393],[8236,12332,8252,8236],[16460,8236,8236,16460],[4180,2124,76,76],[1417,3465,1417,1425],[16468,24692,24692,16468],[2124,4180,84,84],[1417,4501,405,405],[2124,12404,2124,12404],[1417,32932,421],[1417,17608,1224,1224]]
theorem node3_3756 [Assumptions] : Blocked tgt 9 s3_3756 := by
  refine PetersenMixedNode.close (cut := c3_3756) (more := m3_3756) (hs := hs3_3756) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 []) (correct2 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route1 []) (correct75 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route5 [(false,(4,false),(3,true))]) (correct0 route5 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route3 [(false,(2,true),(0,false))]) (correct2 route3 [(false,(2,true),(0,false))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_3865 : List (BitVec 256) := [w56,w141,w298,w341,w379,w391,w423,w501,w537]
private def c3_3865 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule41 route0 [],rule39 route4 [],rule37 route0 [],rule76 route0 [],rule97 route6 [],rule92 route5 []]
private def m3_3865 : Array (List (BitVec 256)) := #[[w141,w298,w341,w379,w391,w423,w501,w537,w566],[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_3865 : List (List Nat) := [[299,299,32938,2612,0,1],[525,2098,525,299,299,8235,43,299,525,43,2098,8235],[299,299,16460,9264,0,9264,301,2,16460,299,299,9264],[299,299,528,1323,1327,8752,303,1327,528,299,299,8752],[299,299,16466,2098,2098,8242,50,2098,16466,50,299,8242],[299,299,16474,4395,4411,24698,315,4411,16474,299,299,24698],[299,299,2130,8780,16747,8812,363,16747,2130,299,299,8812],[170,299,170,8362,7,3],[8235,32938,8235,525,33195,525,8235,33195,8235,525,32938,525],[9264,32938,9264,32940,33452,33165,269,33452,9264,269,32938,33165],[8752,32938,8752,528,4,528,8752,5,8752,528,32938,528],[8242,32938,8242,32946,34994,49362,8242,34994,8242,32938,32938,49362],[16474,32938,16474,32922,6,32922,16474,0,16474,32922,32938,32922],[588,32938,2130,588,49386,33484,2130,49386,2130,32938,32938,33484],[170,8,170,684,32938,4764,170,32938,170,1166,9,4764],[8235,8235,9264,525,525,16717,525,525,9264,8235,8235,16717],[525,525,528,9259,9263,33167,528,9263,528,525,525,33167],[525,525,8242,2573,2581,16723,533,2581,8242,525,525,16723],[525,525,16474,4621,4637,16731,541,4637,16474,525,525,16731],[525,525,2130,2386,24683,2387,2130,24683,2130,525,525,2387],[170,525,170,426,33421,427,170,33421,170,171,525,427],[16460,16460,32910,528,9264,528,8240,9264,32910,528,16460,528],[8242,9264,8242,8754,35221,8756,8242,35221,8242,8244,9264,8756],[9264,9264,16474,13360,13376,33436,9280,13376,16474,9264,9264,33436],[2130,9264,2130,8812,16460,8812,76,16460,2130,76,9264,8812],[170,9264,170,4762,33165,4764,170,33165,170,172,9264,4764],[528,528,8242,2576,2584,9270,536,2584,8242,528,528,9270],[528,528,16474,4624,4640,17502,544,4640,16474,528,528,17502],[528,528,2130,3154,49358,3158,2130,49358,2130,528,528,3158],[170,528,170,1194,32910,1198,170,32910,170,174,528,1198],[8242,8242,16474,12338,12354,34978,8258,12354,16474,8242,8242,34978],[4186,8242,4186,2130,16466,2130,82,16466,4186,82,8242,2130],[170,8242,170,2218,49362,2226,170,49362,170,178,8242,2226],[2130,32922,2130,4186,16474,4186,90,16474,2130,90,32922,4186],[170,16474,170,4266,32922,4282,170,32922,170,186,16474,4282],[170,2130,170,16554,33484,16618,170,33484,170,234,2130,16618]]
theorem node3_3865 [Assumptions] : Blocked tgt 9 s3_3865 := by
  refine PetersenMixedNode.close (cut := c3_3865) (more := m3_3865) (hs := hs3_3865) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route4 []) (correct39 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route0 []) (correct76 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route6 []) (correct97 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route5 []) (correct92 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w141,w298,w341,w379,w391,w423,w501,w537,w566]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1007 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_3868 : List (BitVec 256) := [w56,w142,w298,w341,w379,w391,w423,w501,w537]
private def c3_3868 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule2 route0 [(false,(0,true),(2,true))],rule37 route2 [],rule76 route0 [],rule97 route6 [],rule92 route5 []]
private def m3_3868 : Array (List (BitVec 256)) := #[[w157,w298,w341,w379,w391,w423,w501,w537],[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_3868 : List (List Nat) := [[298,298,32937,6,0,1],[524,2097,524,298,298,8234,42,298,524,42,2097,8234],[298,298,2324,2609,2611,9263,300,2611,2324,298,298,9263],[298,298,527,1322,1326,8751,302,1326,527,298,298,8751],[298,298,16465,2097,2097,8241,49,2097,16465,49,298,8241],[298,298,16473,4394,4410,24697,314,4410,16473,298,298,24697],[298,298,587,8811,16746,8811,362,16746,587,298,298,8811],[169,298,169,8361,2,1],[2580,32937,2580,524,33194,524,2580,33194,2580,524,32937,524],[2324,32937,2324,32939,33451,33164,268,33451,2324,268,32937,33164],[2583,32937,2583,527,3,527,2583,4,2583,527,32937,527],[8241,32937,8241,32945,34993,49361,8241,34993,8241,32937,32937,49361],[16473,32937,16473,32921,5,32921,16473,0,16473,32921,32937,32921],[2129,32937,2129,587,49385,587,2129,49385,2129,587,32937,587],[169,7,169,683,32937,4763,169,32937,169,1165,8,4763],[3095,8234,3095,524,524,2324,524,524,3095,2068,8234,2324],[524,524,527,9258,9262,33166,527,9262,527,524,524,33166],[524,524,8241,2580,2580,16722,2580,2580,8241,524,524,16722],[524,524,16473,4620,4636,16730,540,4636,16473,524,524,16730],[524,524,587,2385,24682,2386,587,24682,587,524,524,2386],[169,524,169,425,33420,426,169,33420,169,170,524,426],[2324,2324,32909,527,3095,527,2071,3095,32909,527,2324,527],[8241,9263,8241,2324,2324,8755,276,2324,8241,276,9263,8755],[2324,2324,16473,6420,6436,33435,2340,6436,16473,2324,2324,33435],[2129,2324,2129,587,24683,587,2129,24683,2129,587,2324,587],[169,2324,169,2737,33164,2739,169,33164,169,171,2324,2739],[527,527,8241,2583,2583,9269,2583,2583,8241,527,527,9269],[527,527,16473,4623,4639,17501,543,4639,16473,527,527,17501],[527,527,587,3153,49357,3157,587,49357,587,527,527,3157],[169,527,169,1193,32909,1197,169,32909,169,173,527,1197],[8241,8241,16473,12337,12353,34977,8257,12353,16473,8241,8241,34977],[587,8241,587,2129,16465,2129,81,16465,587,81,8241,2129],[169,8241,169,2217,49361,2225,169,49361,169,177,8241,2225],[587,32921,587,4185,16473,4185,89,16473,587,89,32921,4185],[169,16473,169,4265,32921,4281,169,32921,169,185,16473,4281],[169,587,169,16553,33483,16617,169,33483,169,233,587,16617]]
theorem node3_3868 [Assumptions] : Blocked tgt 9 s3_3868 := by
  refine PetersenMixedNode.close (cut := c3_3868) (more := m3_3868) (hs := hs3_3868) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,true),(2,true))]) (correct2 route0 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route2 []) (correct37 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route0 []) (correct76 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route6 []) (correct97 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route5 []) (correct92 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w157,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) node4_1705) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_3871 : List (BitVec 256) := [w56,w143,w298,w341,w379,w391,w423,w501,w537]
private def c3_3871 : Array (PetersenProjectedRule.Rule 256) := #[rule111 route2 [],rule2 route0 [(false,(4,true),(2,true))],rule107 route2 [],rule3 route1 [(false,(2,true),(4,true))],rule37 route2 [],rule92 route0 [],rule69 route6 [],rule76 route5 [],rule97 route2 []]
private def m3_3871 : Array (List (BitVec 256)) := #[[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_3871 : List (List Nat) := [[300,300,32939,16748,0,1],[526,2099,526,300,300,8236,44,300,526,44,2099,8236],[270,300,270,2611,2613,9265,270,2613,270,300,300,9265],[300,300,529,1324,1328,8753,304,1328,529,300,300,8753],[300,300,49363,2099,2099,8243,51,2099,49363,51,300,8243],[300,300,16475,4396,4412,24699,316,4412,16475,300,300,24699],[300,300,2131,8813,2,8813,364,3,2131,300,300,8813],[171,300,171,8363,4,1],[526,32939,526,32940,33196,33422,526,33196,526,32939,32939,33422],[270,32939,270,16461,33453,16461,270,33453,270,16461,32939,16461],[529,32939,529,32911,5,32911,529,6,529,32911,32939,32911],[8243,32939,8243,16467,34995,49363,8243,34995,8243,32939,32939,49363],[24699,32939,24699,16475,7,16475,24699,8,24699,16475,32939,16475],[2131,32939,2131,33003,49387,33485,589,49387,2131,589,32939,33485],[171,9,171,16619,32939,17615,171,32939,171,1167,10,17615],[1041,8236,1041,270,526,270,14,526,1041,14,8236,270],[526,526,529,9260,9264,33168,529,9264,529,526,526,33168],[526,526,8243,2574,2582,49620,534,2582,8243,526,526,49620],[526,526,16475,4622,4638,16732,542,4638,16475,526,526,16732],[526,526,2131,2387,24684,2388,2131,24684,2131,526,526,2388],[171,526,171,427,33422,428,171,33422,171,172,526,428],[270,270,32911,529,1041,529,17,1041,32911,17,270,529],[270,270,8243,2318,2326,8757,278,2326,8243,270,270,8757],[270,270,16475,4366,4382,33437,286,4382,16475,270,270,33437],[270,270,2131,2643,16461,2645,2131,16461,2131,270,270,2645],[171,270,171,683,33166,685,171,33166,171,173,270,685],[529,529,8243,2577,2585,9271,537,2585,8243,529,529,9271],[529,529,16475,4625,4641,17503,545,4641,16475,529,529,17503],[529,529,2131,3155,49359,3159,2131,49359,2131,529,529,3159],[171,529,171,1195,32911,1199,171,32911,171,175,529,1199],[8243,8243,16475,12339,12355,34979,8259,12355,16475,8243,8243,34979],[8243,8243,8813,2131,24691,2131,83,24691,8813,83,8243,2131],[171,8243,171,2219,49363,2227,171,49363,171,179,8243,2227],[2131,32923,2131,6227,16475,6243,2131,16475,2131,2147,32923,6243],[171,16475,171,4267,32923,4283,171,32923,171,187,16475,4283],[171,2131,171,17551,33485,17615,171,33485,171,235,2131,17615]]
theorem node3_3871 [Assumptions] : Blocked tgt 9 s3_3871 := by
  refine PetersenMixedNode.close (cut := c3_3871) (more := m3_3871) (hs := hs3_3871) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule111 route2 []) (correct111 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true))]) (correct2 route0 [(false,(4,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route2 []) (correct107 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 [(false,(2,true),(4,true))]) (correct3 route1 [(false,(2,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route2 []) (correct37 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route5 []) (correct76 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_3880 : List (BitVec 256) := [w56,w145,w298,w341,w379,w391,w423,w501,w537]
private def c3_3880 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule41 route0 [],rule37 route0 [],rule76 route0 [],rule69 route6 [],rule76 route5 [],rule2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]]
private def m3_3880 : Array (List (BitVec 256)) := #[[w158,w298,w341,w379,w391,w423,w501,w537],[w145,w298,w341,w379,w391,w423,w501,w537,w566],[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_3880 : List (List Nat) := [[300,300,32939,7,0,1],[526,2099,526,300,300,8236,44,300,526,44,2099,8236],[270,300,270,2611,2613,9265,270,2613,270,300,300,9265],[300,300,529,1324,1328,8753,304,1328,529,300,300,8753],[300,300,16467,2099,2099,8243,51,2099,16467,51,300,8243],[300,300,16475,4396,4412,24699,316,4412,16475,300,300,24699],[300,300,2131,8813,16748,8813,364,16748,2131,300,300,8813],[171,300,171,8363,8,2],[526,32939,526,32940,33196,33422,526,33196,526,32939,32939,33422],[270,32939,270,32941,33453,33166,270,33453,270,16461,32939,33166],[529,32939,529,32911,3,32911,529,4,529,32911,32939,32911],[8243,32939,8243,32947,34995,49363,8243,34995,8243,32939,32939,49363],[16475,32939,16475,32923,5,32923,16475,0,16475,32923,32939,32923],[2131,32939,2131,33003,49387,33485,589,49387,2131,589,32939,33485],[171,9,171,32939,32939,1,171,32939,171,1167,10,6],[1041,8236,1041,270,526,270,14,526,1041,14,8236,270],[526,526,529,9260,9264,33168,529,9264,529,526,526,33168],[526,526,8243,2574,2582,16724,534,2582,8243,526,526,16724],[526,526,16475,4622,4638,16732,542,4638,16475,526,526,16732],[526,526,2131,2387,24684,2388,2131,24684,2131,526,526,2388],[171,526,171,427,33422,428,171,33422,171,172,526,428],[270,270,32911,529,1041,529,17,1041,32911,17,270,529],[270,270,8243,2318,2326,8757,278,2326,8243,270,270,8757],[270,270,16475,4366,4382,33437,286,4382,16475,270,270,33437],[270,270,2131,2643,24685,8813,2131,24685,2131,270,270,8813],[171,270,171,683,33166,685,171,33166,171,173,270,685],[529,529,8243,2577,2585,9271,537,2585,8243,529,529,9271],[529,529,16475,4625,4641,17503,545,4641,16475,529,529,17503],[529,529,2131,3155,49359,3159,2131,49359,2131,529,529,3159],[171,529,171,1195,32911,1199,171,32911,171,175,529,1199],[8243,8243,16475,12339,12355,34979,8259,12355,16475,8243,8243,34979],[4187,8243,4187,2131,16467,2131,83,16467,4187,83,8243,2131],[171,8243,171,2219,49363,2227,171,49363,171,179,8243,2227],[2131,32923,2131,4187,16475,4187,91,16475,2131,91,32923,4187],[171,16475,171,4267,32923,4283,171,32923,171,187,16475,4283],[171,2131,171,16555,33485,16619,171,33485,171,235,2131,16619]]
theorem node3_3880 [Assumptions] : Blocked tgt 9 s3_3880 := by
  refine PetersenMixedNode.close (cut := c3_3880) (more := m3_3880) (hs := hs3_3880) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route0 []) (correct76 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route5 []) (correct76 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]) (correct2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w158,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) node4_1706) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w145,w298,w341,w379,w391,w423,w501,w537,w566]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1023 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil

def s3_3882 : List (BitVec 256) := [w56,w145,w298,w341,w379,w391,w423,w501,w553]
private def c3_3882 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule41 route0 [],rule37 route0 [],rule76 route0 [],rule69 route6 [],rule76 route5 [],rule2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]]
private def m3_3882 : Array (List (BitVec 256)) := #[[w158,w298,w341,w379,w391,w423,w501,w553],[w145,w298,w341,w379,w391,w423,w501,w553,w576],[w29,w145,w298,w341,w379,w391,w423,w501,w553],[w56,w298,w341,w379,w391,w423,w454,w501,w553]]
private def hs3_3882 : List (List Nat) := [[300,300,32939,7,0,1],[526,2099,526,300,300,8236,44,300,526,44,2099,8236],[270,300,270,2611,2613,9265,270,2613,270,300,300,9265],[300,300,529,1324,1328,8753,304,1328,529,300,300,8753],[300,300,16467,2099,2099,8243,51,2099,16467,51,300,8243],[300,300,16475,4396,4412,24699,316,4412,16475,300,300,24699],[300,300,2131,12379,16748,12411,364,16748,2131,300,300,12411],[171,300,171,8363,8,2,171,9,171,300,300,1],[526,32939,526,32940,33196,33422,526,33196,526,32939,32939,33422],[270,32939,270,32941,33453,33166,270,33453,270,32939,32939,33166],[529,32939,529,32911,3,32911,529,4,529,32911,32939,32911],[8243,32939,8243,32947,34995,49363,8243,34995,8243,32939,32939,49363],[16475,32939,16475,32923,5,32923,16475,0,16475,32923,32939,32923],[2131,32939,2131,33003,49387,33357,2131,49387,2131,32939,32939,33357],[171,32939,171,1167,10,6],[1041,8236,1041,270,526,270,14,526,1041,14,8236,270],[526,526,529,9260,9264,33168,529,9264,529,526,526,33168],[526,526,8243,2574,2582,16724,534,2582,8243,526,526,16724],[526,526,16475,4622,4638,16732,542,4638,16475,526,526,16732],[526,526,2131,2387,24684,2388,2131,24684,2131,526,526,2388],[171,526,171,427,33422,428,171,33422,171,172,526,428],[270,270,32911,529,1041,529,17,1041,32911,17,270,529],[270,270,8243,2318,2326,8757,278,2326,8243,270,270,8757],[270,270,16475,4366,4382,33437,286,4382,16475,270,270,33437],[270,270,2131,2643,49229,33357,2131,49229,2131,270,270,33357],[171,270,171,683,33166,685,171,33166,171,173,270,685],[529,529,8243,2577,2585,9271,537,2585,8243,529,529,9271],[529,529,16475,4625,4641,17503,545,4641,16475,529,529,17503],[529,529,2131,3155,49359,3159,2131,49359,2131,529,529,3159],[171,529,171,1195,32911,1199,171,32911,171,175,529,1199],[8243,8243,16475,12339,12355,34979,8259,12355,16475,8243,8243,34979],[4187,8243,4187,2131,16467,2131,83,16467,4187,83,8243,2131],[171,8243,171,2219,49363,2227,171,49363,171,179,8243,2227],[2131,32923,2131,4187,16475,4187,91,16475,2131,91,32923,4187],[171,16475,171,4267,32923,4283,171,32923,171,187,16475,4283],[171,2131,171,16555,33357,16619,171,33357,171,235,2131,16619]]
theorem node3_3882 [Assumptions] : Blocked tgt 9 s3_3882 := by
  refine PetersenMixedNode.close (cut := c3_3882) (more := m3_3882) (hs := hs3_3882) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route0 []) (correct76 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule76 route5 []) (correct76 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]) (correct2 route0 [(false,(0,false),(4,false)),(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w158,w298,w341,w379,w391,w423,w501,w553]) (via sym2 fix2 (by decide +kernel) node4_1707) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w145,w298,w341,w379,w391,w423,w501,w553,w576]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1029 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w29,w145,w298,w341,w379,w391,w423,w501,w553]) (Orbits1020Cost12.b4_398 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w454,w501,w553]) (Orbits1020Cost12.b4_959 ThetaCert.bound) <|
      PetersenLocalChildren.nil
def s3_3896 : List (BitVec 256) := [w56,w146,w214,w298,w341,w379,w391,w423,w501,w537]
private def c3_3896 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3896 : Array (List (BitVec 256)) := #[]
private def hs3_3896 : List (List Nat) := [[289,2602],[289,16737,16737,289],[515,289,33,33],[289,9254,291,289],[289,1313,293,289],[289,2088,40,40],[289,4385,305,289],[289,16737,2120,289],[160,8352],[32928,49376,49376,32928],[8225,515,8225,515],[9254,32930,259,259],[8742,518,8742,518],[8232,32936,8232,32928],[16464,32912,16464,32912],[2120,2634,2120,2634],[160,674,160,1156],[515,24673,515,24673],[9254,24674,9254,24674],[518,49348,518,49348],[8232,16456],[32912,16464,32912,16464],[578,578],[160,16608,160,16608],[8225,515,515,8225],[515,9249,518,515],[515,2563,523,515],[515,4611,531,515],[515,2376,2120,515],[160,416,160,161],[24674,518,8230,518],[8232,8744,8232,8234],[9254,13350,9270,9254],[2120,2634,2120,2634],[160,4752,160,162],[518,2566,526,518],[518,4614,534,518],[518,3144,2120,518],[160,1184,160,164],[8232,12328,8248,8232],[8232,2120,72],[160,2208,160,168],[2120,6216,2120,2136],[160,4256,160,176],[160,16608,160,2120]]
theorem node3_3896 [Assumptions] : Blocked tgt 9 s3_3896 := by
  refine PetersenMixedNode.close (cut := c3_3896) (more := m3_3896) (hs := hs3_3896) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3909 : List (BitVec 256) := [w56,w146,w237,w298,w341,w391,w423,w501,w537]
private def c3_3909 : Array (PetersenProjectedRule.Rule 256) := #[rule69 route2 [],rule41 route0 [],rule42 route2 [],rule29 route2 [],rule39 route4 [],rule92 route5 []]
private def m3_3909 : Array (List (BitVec 256)) := #[[w146,w237,w298,w341,w391,w423,w501,w537,w566],[w56,w116,w237,w298,w341,w391,w423,w501,w537],[w56,w231,w237,w298,w341,w391,w423,w501,w537],[w56,w140,w237,w298,w341,w391,w423,w501,w537],[w56,w237,w298,w341,w391,w423,w450,w501,w537]]
private def hs3_3909 : List (List Nat) := [[300,300,32939,2613,0,1],[300,300,529,8753,2,8753,529,1,529,300,300,8753],[526,2099,526,300,300,8236,44,300,526,44,2099,8236],[300,300,33166,8241,3,8241,49,4,33166,49,300,8241],[300,300,16467,2099,2099,8243,51,2099,16467,51,300,8243],[300,300,16475,4396,4412,24699,316,4412,16475,300,300,24699],[300,300,589,8813,16748,8813,364,16748,589,300,300,8813],[175,300,175,8367,6,1],[8753,7,8753,529,32939,529,8753,32939,8753,529,8,529],[8236,32939,8236,526,33196,526,8236,33196,8236,526,32939,526],[8241,32939,8241,32941,33453,33166,17,33453,8241,17,32939,33166],[8243,32939,8243,32947,34995,49363,8243,34995,8243,32939,32939,49363],[16475,32939,16475,32923,5,32923,16475,0,16475,32923,32939,32923],[2131,32939,2131,589,49387,589,2131,49387,2131,589,32939,589],[175,9,175,685,32939,4765,143,32939,175,143,10,4765],[529,529,8236,526,33168,526,8236,33168,8236,526,529,526],[8241,32911,8241,529,529,33166,529,529,8241,24685,32911,33166],[529,529,8243,537,2585,8757,2577,2585,8243,529,529,8757],[529,529,16475,545,4641,32923,4625,4641,16475,529,529,32923],[529,529,2131,589,49359,589,2131,49359,2131,529,529,589],[175,529,175,657,32911,4765,171,32911,175,171,529,4765],[8236,8236,8241,526,526,33166,526,526,8241,8236,8236,33166],[526,526,8243,2574,2582,16724,534,2582,8243,526,526,16724],[526,526,16475,4622,4638,16732,542,4638,16475,526,526,16732],[526,526,589,2387,24684,2388,589,24684,589,526,526,2388],[175,526,175,431,33422,432,175,33422,175,176,526,432],[8241,8241,8243,8757,35222,8757,8243,35222,8243,8241,8241,8757],[8241,8241,16475,12337,12353,33437,8257,12353,16475,8241,8241,33437],[2131,8241,2131,589,24689,589,2131,24689,2131,589,8241,589],[175,8241,175,4763,33166,4765,175,33166,175,177,8241,4765],[8243,8243,16475,12339,12355,34979,8259,12355,16475,8243,8243,34979],[589,8243,589,2131,16467,2131,83,16467,589,83,8243,2131],[175,8243,175,2223,49363,2231,175,49363,175,183,8243,2231],[589,32923,589,4187,16475,4187,91,16475,589,91,32923,4187],[175,16475,175,4271,32923,4287,175,32923,175,191,16475,4287],[175,589,175,16559,33485,16623,175,33485,175,239,589,16623]]
theorem node3_3909 [Assumptions] : Blocked tgt 9 s3_3909 := by
  refine PetersenMixedNode.close (cut := c3_3909) (more := m3_3909) (hs := hs3_3909) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route2 []) (correct69 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule42 route2 []) (correct42 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route4 []) (correct39 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route5 []) (correct92 route5 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w146,w237,w298,w341,w391,w423,w501,w537,w566]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1070 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w116,w237,w298,w341,w391,w423,w501,w537]) (via sym6 fix6 (by decide +kernel) (Orbits1020Cost12.b4_361 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w231,w237,w298,w341,w391,w423,w501,w537]) (via sym5 fix5 (by decide +kernel) (Orbits1020Cost12.b4_923 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w237,w298,w341,w391,w423,w501,w537]) (via sym5 fix5 (by decide +kernel) (Orbits1020Cost12.b4_906 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w237,w298,w341,w391,w423,w450,w501,w537]) (via sym5 fix5 (by decide +kernel) (Orbits1020Cost12.b4_935 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_3915 : List (BitVec 256) := [w56,w146,w285,w298,w341,w379,w391,w423,w501,w537]
private def c3_3915 : Array (PetersenProjectedRule.Rule 256) := #[rule116 route2 [],rule2 route0 [(false,(0,true),(2,true))]]
private def m3_3915 : Array (List (BitVec 256)) := #[]
private def hs3_3915 : List (List Nat) := [[291,2604],[291,0,1,291],[517,291,35,35],[291,9256,293,291],[291,1315,295,291],[291,2090,42,42],[291,4387,307,291],[291,16675,355,291],[162,8354],[32930,49378,49378,32930],[8227,517,8227,517],[9256,32932,261,261],[8744,520,8744,520],[8234,32938,8234,32930],[16466,32914,16466,32914],[2379,33251,2379,32930],[162,676,162,1158],[517,24675],[9256,24676,9256,24676],[520,49350,520,49350],[8234,16458,8234,16458],[16723,16466,16723,16466],[580,580],[162,16610,162,16610],[8227,517,517,8227],[517,9251,520,517],[517,2565,525,517],[517,4613,533,517],[517,2379,581],[162,418,162,163],[24676,520,8232,520],[8234,8746,8234,8236],[9256,13352,9272,9256],[2379,24676,2379,9256],[162,4754,162,164],[520,2568,528,520],[520,4616,536,520],[520,3403,2379,520],[162,1186,162,166],[8234,12330,8250,8234],[4435,2379,331,331],[162,2210,162,170],[2379,4435,339,339],[162,4258,162,178],[162,16610,162,483]]
theorem node3_3915 [Assumptions] : Blocked tgt 9 s3_3915 := by
  refine PetersenMixedNode.close (cut := c3_3915) (more := m3_3915) (hs := hs3_3915) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route2 []) (correct116 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,true),(2,true))]) (correct2 route0 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_3966 : List (BitVec 256) := [w56,w146,w298,w341,w379,w391,w406,w423,w501,w537]
private def c3_3966 : Array (PetersenProjectedRule.Rule 256) := #[rule29 route2 []]
private def m3_3966 : Array (List (BitVec 256)) := #[]
private def hs3_3966 : List (List Nat) := [[290,2603],[516,290,34,34],[290,0,2091,290],[290,1314,294,290],[290,2089,2089,290],[290,2089,2089,290],[290,4386,306,290],[290,8803,354,290],[161,8353],[8226,516,8226,516],[32929,33443,2316,2316],[8743,519,8743,519],[8747,33451,8747,32929],[32929,33443,33443,32929],[16465,32913,16465,32913],[2121,579,2121,579],[161,675,161,1157],[8226,516,516,8226],[516,9250,519,516],[516,2564,524,516],[8226,516,516,8226],[516,4612,532,516],[516,2377,579,516],[161,417,161,162],[32901,519,32901,519],[8745,35212,8747],[9255,9255],[16465,33427,16465,33427],[2121,579,2121,579],[161,4755,161,2219],[519,2567,527,519],[32901,519,519,32901],[519,4615,535,519],[519,3145,579,519],[161,1185,161,165],[8233,8233],[8747,12843,8763,8747],[579,2121,579,587],[161,2217,161,2217],[16465,33427,16465,33427],[4177,579,4177,579],[161,2217,161,2217],[579,4177,81,81],[161,4257,161,177],[161,16545,161,225]]
theorem node3_3966 [Assumptions] : Blocked tgt 9 s3_3966 := by
  refine PetersenMixedNode.close (cut := c3_3966) (more := m3_3966) (hs := hs3_3966) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3990 : List (BitVec 256) := [w56,w146,w298,w341,w379,w391,w423,w501,w513,w537]
private def c3_3990 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3990 : Array (List (BitVec 256)) := #[]
private def hs3_3990 : List (List Nat) := [[289,2602],[2088,289,289,2088],[289,9254,291,289],[289,1313,293,289],[289,2088,40,40],[289,4385,305,289],[289,16673,353,289],[2088,289,289,2088],[160,8352],[24673,33185,24673,32928],[9254,32930,259,259],[8742,518,8742,518],[8232,32936,8232,32928],[16464,32912,16464,32912],[2377,33249,2377,32928],[32928,33185,33185,32928],[160,674,160,1156],[9254,33155,9254,24673],[518,25697,518,24673],[8232,16712,8232,16457],[16464,16720,16464,16465],[2376,24673,2377],[515,515],[160,417,160,417],[24674,518,8230,518],[8232,8744,8232,8234],[9254,13350,9270,9254],[2377,24674,2377,9254],[9254,24674,24674,9254],[160,4752,160,162],[518,2566,526,518],[518,4614,534,518],[518,3401,2377,518],[518,33157,33157,518],[160,1184,160,164],[8232,12328,8248,8232],[4433,2377,329,329],[8232,16456,16456,8232],[160,2208,160,168],[2377,4433,337,337],[32912,16464,16464,32912],[160,4256,160,176],[578,578],[160,16608,160,481],[160,417,160,417]]
theorem node3_3990 [Assumptions] : Blocked tgt 9 s3_3990 := by
  refine PetersenMixedNode.close (cut := c3_3990) (more := m3_3990) (hs := hs3_3990) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3991 : List (BitVec 256) := [w56,w146,w298,w341,w379,w391,w423,w501,w521,w537]
private def c3_3991 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3991 : Array (List (BitVec 256)) := #[]
private def hs3_3991 : List (List Nat) := [[289,2602],[515,289,33,33],[289,24674,16482,289],[289,1313,293,289],[289,2088,40,40],[289,4385,305,289],[289,8802,578,289],[289,16737,16737,289],[160,8352],[8225,515,8225,515],[24674,33442,16450,16450],[8742,518,8742,518],[8232,32936,8232,32928],[16464,32912,16464,32912],[8802,578,8802,578],[32928,33442,33442,32928],[160,674,160,1156],[8225,515,515,8225],[515,9249,518,515],[515,2563,523,515],[515,4611,531,515],[515,24673,578,515],[8225,515,515,8225],[160,416,160,161],[24674,518,24678,518],[8232,8746,8232,8746],[16464,33426,16464,24674],[12912,24674,578],[9254,9254],[160,4754,160,4754],[518,2566,526,518],[518,4614,534,518],[518,49348,578,518],[32900,518,518,32900],[160,1184,160,164],[8232,12328,8248,8232],[578,2626,578,586],[8232,8746,8746,8232],[160,2208,160,168],[578,4674,578,594],[32912,16464,16464,32912],[160,4256,160,176],[578,2120],[160,16608,160,578],[160,4754,160,4754]]
theorem node3_3991 [Assumptions] : Blocked tgt 9 s3_3991 := by
  refine PetersenMixedNode.close (cut := c3_3991) (more := m3_3991) (hs := hs3_3991) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_3993 : List (BitVec 256) := [w56,w146,w298,w341,w379,w391,w423,w501,w528,w537]
private def c3_3993 : Array (PetersenProjectedRule.Rule 256) := #[]
private def m3_3993 : Array (List (BitVec 256)) := #[]
private def hs3_3993 : List (List Nat) := [[289,2602],[515,289,33,33],[289,9254,291,289],[289,1313,293,289],[289,2088,2088,289],[289,4385,305,289],[289,16737,2120,289],[289,2088,2088,289],[160,8352],[8225,515,8225,515],[9254,32930,259,259],[8742,518,8742,518],[16456,34984,16456,32928],[16464,32912,16464,32912],[2120,2634,2120,2634],[32928,34984,34984,32928],[160,674,160,1156],[8225,515,515,8225],[515,9249,518,515],[515,2571,2571,515],[515,4611,531,515],[515,2376,2120,515],[515,2571,2571,515],[160,416,160,161],[24674,518,8230,518],[9254,35211,16456,9254],[9254,13350,9270,9254],[2120,2634,2120,2634],[9254,24674,24674,9254],[160,4752,160,162],[518,2574,2574,518],[518,4614,534,518],[518,3144,2120,518],[518,2574,2574,518],[160,1184,160,164],[16456,34968,16464,16456],[2626,16456,2120],[8232,8232],[160,2216,160,2216],[2120,6216,2120,2136],[32912,16464,16464,32912],[160,4256,160,176],[578,578],[160,16608,160,2120],[160,2216,160,2216]]
theorem node3_3993 [Assumptions] : Blocked tgt 9 s3_3993 := by
  refine PetersenMixedNode.close (cut := c3_3993) (more := m3_3993) (hs := hs3_3993) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_4018 : List (BitVec 256) := [w56,w147,w298,w341,w379,w391,w423,w501,w537]
private def c3_4018 : Array (PetersenProjectedRule.Rule 256) := #[rule93 route2 [],rule2 route0 [(false,(0,true),(2,true))],rule30 route2 [(false,(5,false),(0,true)),(false,(4,true),(1,true)),(false,(7,true),(0,true))],rule32 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(8,true),(0,true))],rule29 route2 [],rule3 route4 [(false,(2,true),(4,true))],rule26 route5 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))],rule34 route2 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))],rule116 route2 [],rule3 route1 [(false,(1,true),(4,true))],rule37 route2 [],rule54 route0 [],rule97 route6 [],rule92 route5 [],rule97 route2 []]
private def m3_4018 : Array (List (BitVec 256)) := #[[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_4018 : List (List Nat) := [[306,2105,32945,306,0,1],[532,2105,532,8242,2,8242,50,3,532,50,2105,8242],[276,2105,276,9271,4,9271,276,5,276,1079,2105,9271],[535,2105,535,3129,3133,8759,535,3133,535,2105,2105,8759],[16473,6,16473,2105,2105,8249,57,2105,16473,57,7,8249],[2105,2105,16481,6201,6217,24705,2121,6217,16481,2105,2105,24705],[595,2105,595,8819,8,8819,595,9,595,2105,2105,8819],[177,2105,177,8369,10,1],[8242,32945,8242,532,33202,532,8242,33202,8242,532,32945,532],[9271,32945,9271,276,33459,276,1047,33459,9271,276,32945,276],[8759,32945,8759,535,11,535,8759,12,8759,535,32945,535],[8249,32945,8249,16730,35001,16730,8249,35001,8249,16730,32945,16730],[16481,32945,16481,16738,13,16738,16481,14,16481,16738,32945,16738],[2137,32945,2137,595,49393,595,2137,49393,2137,595,32945,595],[177,15,177,434,32945,1430,177,32945,177,1173,16,1430],[1303,8242,9271,276,532,276,532,532,9271,276,8242,276],[532,532,535,9266,9270,33174,535,9270,535,532,532,33174],[532,532,8249,2580,2588,16730,540,2588,8249,532,532,16730],[532,532,16481,4628,4644,16738,548,4644,16481,532,532,16738],[532,532,595,2394,24690,2394,595,24690,595,532,532,2394],[177,532,177,1429,33428,1430,177,33428,177,178,532,1430],[276,276,32917,535,1304,535,280,1304,32917,276,276,535],[276,276,8249,2324,2332,8763,284,2332,8249,276,276,8763],[276,276,16481,4372,4388,33443,292,4388,16481,276,276,33443],[276,276,2137,595,16724,595,340,16724,2137,276,276,595],[177,276,177,4769,33172,4771,177,33172,177,179,276,4771],[535,535,8249,2583,2591,9277,543,2591,8249,535,535,9277],[535,535,16481,4631,4647,17509,551,4647,16481,535,535,17509],[535,535,595,3161,49365,3165,595,49365,595,535,535,3165],[177,535,177,1201,32917,1205,177,32917,177,181,535,1205],[8249,8249,16481,12345,12361,34985,8265,12361,16481,8249,8249,34985],[595,8249,595,2137,16473,2137,89,16473,595,89,8249,2137],[177,8249,177,2225,49369,2233,177,49369,177,185,8249,2233],[595,32929,595,4193,16481,4193,97,16481,595,97,32929,4193],[177,16481,177,4273,32929,4289,177,32929,177,193,16481,4289],[177,595,177,16561,33491,16625,177,33491,177,241,595,16625]]
theorem node3_4018 [Assumptions] : Blocked tgt 9 s3_4018 := by
  refine PetersenMixedNode.close (cut := c3_4018) (more := m3_4018) (hs := hs3_4018) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule93 route2 []) (correct93 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,true),(2,true))]) (correct2 route0 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 [(false,(5,false),(0,true)),(false,(4,true),(1,true)),(false,(7,true),(0,true))]) (correct30 route2 [(false,(5,false),(0,true)),(false,(4,true),(1,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(8,true),(0,true))]) (correct32 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 [(false,(2,true),(4,true))]) (correct3 route4 [(false,(2,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) (correct26 route5 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) (correct34 route2 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route2 []) (correct116 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 [(false,(1,true),(4,true))]) (correct3 route1 [(false,(1,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route2 []) (correct37 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule54 route0 []) (correct54 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route6 []) (correct97 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route5 []) (correct92 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_4021 : List (BitVec 256) := [w56,w148,w298,w341,w379,w391,w423,w501,w537]
private def c3_4021 : Array (PetersenProjectedRule.Rule 256) := #[rule110 route2 [],rule2 route0 [(false,(0,true),(2,true))],rule26 route0 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))],rule30 route2 [(false,(6,true),(3,true)),(false,(0,false),(1,true)),(false,(7,true),(0,true))],rule29 route2 [],rule3 route4 [(false,(2,true),(4,true))],rule34 route2 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))],rule32 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))],rule37 route2 [],rule92 route0 [],rule97 route6 [],rule54 route5 [],rule97 route2 []]
private def m3_4021 : Array (List (BitVec 256)) := #[[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_4021 : List (List Nat) := [[304,304,32943,2103,0,1],[530,2,530,304,304,8240,48,304,530,48,3,8240],[304,304,2330,9269,4,9269,306,5,2330,304,304,9269],[304,304,533,1328,1332,8757,308,1332,533,304,304,8757],[304,304,49367,8247,6,8247,55,7,49367,55,304,8247],[304,304,16479,4400,4416,24703,320,4416,16479,304,304,24703],[304,304,593,8817,16752,8817,368,16752,593,304,304,8817],[175,304,175,8367,8,1],[8240,32943,8240,530,33200,530,8240,33200,8240,530,32943,530],[9269,32943,9269,2330,33457,2330,274,33457,9269,274,32943,2330],[8757,32943,8757,533,9,533,8757,10,8757,533,32943,533],[8247,32943,8247,32951,34999,49367,8247,34999,8247,16471,32943,49367],[16479,32943,16479,32927,11,32927,16479,12,16479,32927,32943,32927],[4191,32943,4191,593,49391,593,4191,49391,4191,593,32943,593],[175,13,175,689,32943,3227,175,32943,175,1171,14,3227],[3101,8240,3101,530,530,2330,530,530,3101,2074,8240,2330],[530,530,533,9264,9268,33172,533,9268,533,530,530,33172],[530,530,8247,2578,2586,49624,538,2586,8247,530,530,49624],[530,530,16479,4626,4642,16736,546,4642,16479,530,530,16736],[530,530,593,2391,24688,2392,593,24688,593,530,530,2392],[175,530,175,431,33426,432,175,33426,175,176,530,432],[2330,2330,32915,533,3101,533,2077,3101,32915,533,2330,533],[2322,9269,8247,2322,2330,8761,2330,2330,8247,8249,9269,8761],[2330,2330,16479,6426,6442,33441,2346,6442,16479,2330,2330,33441],[2135,2330,2135,593,24689,593,2135,24689,2135,593,2330,593],[175,2330,175,4767,33170,4769,175,33170,175,177,2330,4769],[533,533,8247,2581,2589,9275,541,2589,8247,533,533,9275],[533,533,16479,4629,4645,17507,549,4645,16479,533,533,17507],[533,533,593,3159,49363,3163,593,49363,593,533,533,3163],[175,533,175,1199,32915,1203,175,32915,175,179,533,1203],[8247,8247,16479,12343,12359,34983,8263,12359,16479,8247,8247,34983],[593,8247,593,2135,24695,2135,593,24695,593,601,8247,2135],[175,8247,175,3219,49367,3227,175,49367,175,183,8247,3227],[593,32927,593,4191,16479,4191,95,16479,593,95,32927,4191],[175,16479,175,4271,32927,4287,175,32927,175,191,16479,4287],[175,593,175,16559,33489,16623,175,33489,175,239,593,16623]]
theorem node3_4021 [Assumptions] : Blocked tgt 9 s3_4021 := by
  refine PetersenMixedNode.close (cut := c3_4021) (more := m3_4021) (hs := hs3_4021) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route2 []) (correct110 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,true),(2,true))]) (correct2 route0 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) (correct26 route0 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route2 [(false,(6,true),(3,true)),(false,(0,false),(1,true)),(false,(7,true),(0,true))]) (correct30 route2 [(false,(6,true),(3,true)),(false,(0,false),(1,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 [(false,(2,true),(4,true))]) (correct3 route4 [(false,(2,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule34 route2 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))]) (correct34 route2 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))]) (correct32 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route2 []) (correct37 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route6 []) (correct97 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule54 route5 []) (correct54 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil
def s3_4024 : List (BitVec 256) := [w56,w151,w298,w341,w379,w391,w423,w501,w521,w537]
private def c3_4024 : Array (PetersenProjectedRule.Rule 256) := #[rule29 route2 [],rule37 route1 []]
private def m3_4024 : Array (List (BitVec 256)) := #[]
private def hs3_4024 : List (List Nat) := [[291,2604],[517,291,35,35],[291,24676,16452,291],[291,1315,295,291],[291,2090,42,42],[291,4387,307,291],[291,8804,580,291],[291,0,1,291],[162,8354],[8227,517,8227,517],[24676,16452,24676,16452],[8744,520,8744,520],[8234,16458,8234,16458],[24690,16466,24690,16466],[8804,580,8804,580],[32930,33444,33444,32930],[162,676,162,1158],[8227,517,517,8227],[517,9251,520,517],[517,2565,525,517],[517,4613,533,517],[517,24675,580,517],[8227,517,517,8227],[162,418,162,163],[16452,520,16456,520],[8234,8748,8234,8748],[16452,33428,16466,16452],[2634,16452,580],[9256,9256],[162,4756,162,4756],[520,2568,528,520],[520,4616,536,520],[520,49350,580,520],[32902,520,520,32902],[162,1186,162,166],[8234,12330,8250,8234],[580,2628,580,588],[8234,8748,8748,8234],[162,2210,162,170],[580,4676,580,596],[32914,16466,16466,32914],[162,4258,162,178],[580,12402],[162,17606,162,580],[162,4756,162,4756]]
theorem node3_4024 [Assumptions] : Blocked tgt 9 s3_4024 := by
  refine PetersenMixedNode.close (cut := c3_4024) (more := m3_4024) (hs := hs3_4024) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route1 []) (correct37 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4025 : List (BitVec 256) := [w56,w151,w298,w341,w379,w391,w423,w501,w537]
private def c3_4025 : Array (PetersenProjectedRule.Rule 256) := #[rule116 route2 [],rule41 route0 [],rule29 route2 [],rule39 route4 [],rule29 route6 [],rule39 route1 [],rule37 route0 [],rule92 route0 [],rule97 route6 [],rule92 route5 [],rule97 route2 []]
private def m3_4025 : Array (List (BitVec 256)) := #[[w151,w298,w341,w379,w391,w423,w501,w537,w566],[w56,w140,w298,w341,w379,w391,w423,w501,w537],[w56,w298,w341,w379,w391,w423,w450,w501,w537]]
private def hs3_4025 : List (List Nat) := [[303,303,32942,2616,0,1],[529,2102,529,303,303,8239,47,303,529,47,2102,8239],[303,303,16464,9268,2,9268,305,3,16464,303,303,9268],[303,303,532,1327,1331,8756,307,1331,532,303,303,8756],[303,303,16470,2102,2102,8246,54,2102,16470,54,303,8246],[303,303,16478,4399,4415,24702,319,4415,16478,303,303,24702],[303,303,592,8816,4,8816,367,5,592,303,303,8816],[174,303,174,8366,11,6],[8239,32942,8239,529,33199,529,8239,33199,8239,529,32942,529],[9268,32942,9268,16464,33456,16464,273,33456,9268,273,32942,16464],[8756,32942,8756,532,7,532,8756,8,8756,532,32942,532],[8246,32942,8246,16470,34998,16470,8246,34998,8246,16470,32942,16470],[24702,32942,24702,16478,9,16478,24702,10,24702,16478,32942,16478],[8816,32942,8816,592,49390,592,2134,49390,8816,592,32942,592],[174,12,174,688,32942,4768,174,32942,174,1170,13,4768],[8239,8239,9268,529,529,16721,529,529,9268,8239,8239,16721],[529,529,532,9263,9267,33171,532,9267,532,529,529,33171],[529,529,8246,2577,2585,16727,537,2585,8246,529,529,16727],[529,529,16478,4625,4641,16735,545,4641,16478,529,529,16735],[529,529,592,24623,24687,35287,592,24687,592,529,529,35287],[174,529,174,430,33425,431,174,33425,174,175,529,431],[16464,16464,32914,532,9268,532,8244,9268,32914,532,16464,532],[8246,9268,8246,8758,35225,8760,8246,35225,8246,8248,9268,8760],[9268,9268,16478,13364,13380,33440,9284,13380,16478,9268,9268,33440],[2646,9268,12414,592,16464,592,8304,16464,12414,592,9268,592],[174,9268,174,4766,33169,4768,174,33169,174,176,9268,4768],[532,532,8246,2580,2588,9274,540,2588,8246,532,532,9274],[532,532,16478,4628,4644,17506,548,4644,16478,532,532,17506],[532,532,592,13438,49362,13442,592,49362,592,532,532,13442],[174,532,174,1198,32914,1202,174,32914,174,178,532,1202],[8246,8246,16478,12342,12358,34982,8262,12358,16478,8246,8246,34982],[592,8246,592,2640,16470,2648,592,16470,592,600,8246,2648],[174,8246,174,2222,49366,2230,174,49366,174,182,8246,2230],[592,32926,592,4688,16478,4704,592,16478,592,608,32926,4704],[174,16478,174,4270,32926,4286,174,32926,174,190,16478,4286],[174,592,174,17554,33488,17618,174,33488,174,238,592,17618]]
theorem node3_4025 [Assumptions] : Blocked tgt 9 s3_4025 := by
  refine PetersenMixedNode.close (cut := c3_4025) (more := m3_4025) (hs := hs3_4025) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route2 []) (correct116 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route2 []) (correct29 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route4 []) (correct39 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route6 []) (correct29 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule37 route0 []) (correct37 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route6 []) (correct97 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route5 []) (correct92 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w151,w298,w341,w379,w391,w423,w501,w537,w566]) (via sym2 fix2 (by decide +kernel) (Orbits1020Cost12.b4_1181 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w140,w298,w341,w379,w391,w423,w501,w537]) (via sym2 fix2 (by decide +kernel) (fun m le c => (Orbits1020Cost12.b2_220 ThetaCert.bound) m (by omega) c)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w56,w298,w341,w379,w391,w423,w450,w501,w537]) (fun m le c => (Orbits1020Cost12.b2_267 ThetaCert.bound) m (by omega) c) <|
      PetersenLocalChildren.nil

def s3_4105 : List (BitVec 256) := [w56,w167,w195,w298,w341,w379,w391,w456,w501,w537]
private def c3_4105 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule504 route0 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule27 route7 [],rule502 route6 [],rule98 route2 []]
private def m3_4105 : Array (List (BitVec 256)) := #[]
private def hs3_4105 : List (List Nat) := [[0,1,2,3],[16727,4,16727,3],[521,8231,521,8231],[265,9260,265,9260],[524,8748,524,8748],[16462,8238,16462,8238],[295,295],[86,8310,86,8310],[150,8374],[16470,16470],[521,24679],[265,16456,265,16456],[524,32906,524,32906],[8238,16462,8238,16462],[33191,32934,33191,32934],[86,33480,86,33480],[150,17610,150,17610],[521,16727,16726],[265,16456,265,16456],[524,16731,524,16727],[8238,16462,8238,16462],[16727,32934,5,16727],[86,16727,86,2383],[150,16855,150,1419],[1036,265,9,9],[521,9255,524,521],[521,2569,529,521],[521,8231,8231,521],[86,342,86,87],[150,406,150,151],[265,524,12,12],[265,2313,273,265],[265,9260,9260,265],[86,598,86,88],[150,662,150,152],[524,2572,532,524],[524,8748,8748,524],[86,1110,86,90],[150,1174,150,154],[16462,8238,8238,16462],[86,2134,86,94],[150,2198,150,158],[86,8310,86,8310],[150,32934,182],[86,17546,150,86]]
theorem node3_4105 [Assumptions] : Blocked tgt 9 s3_4105 := by
  refine PetersenMixedNode.close (cut := c3_4105) (more := m3_4105) (hs := hs3_4105) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route0 []) (correct504 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule27 route7 []) (correct27 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule502 route6 []) (correct502 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule98 route2 []) (correct98 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4128 : List (BitVec 256) := [w56,w172,w195,w298,w341,w379,w391,w456,w501,w537]
private def c3_4128 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule504 route0 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule475 route0 [],rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))],rule41 route0 [],rule1 route0 []]
private def m3_4128 : Array (List (BitVec 256)) := #[]
private def hs3_4128 : List (List Nat) := [[0,1,2,3],[16472,24696,16472,24696],[523,8233,523,8233],[267,9262,267,9262],[526,8750,526,8750],[16464,8240,16464,8240],[297,297],[88,8312,88,8312],[152,8376],[16472,33434],[523,33419,523,33419],[267,16458],[526,33422,526,33422],[8240,4,8240,5],[32936,33450,32936,33450],[88,33482,88,33482],[152,6,152,7],[523,16473,523,16472],[16474,267,16472],[526,16476,526,16472],[8240,16464,8240,16464],[16472,24696,24696,16472],[88,16472,88,2128],[152,16600,152,1164],[1038,267,11,11],[523,9257,526,523],[523,2571,531,523],[523,8233,8233,523],[88,344,88,89],[152,408,152,153],[267,526,14,14],[267,2315,275,267],[267,9262,9262,267],[88,600,88,90],[152,664,152,154],[526,2574,534,526],[526,8750,8750,526],[88,1112,88,92],[152,1176,152,156],[16464,8240,8240,16464],[88,2136,88,96],[152,2200,152,160],[88,8312,88,8312],[152,32936,184],[88,17548,152,88]]
theorem node3_4128 [Assumptions] : Blocked tgt 9 s3_4128 := by
  refine PetersenMixedNode.close (cut := c3_4128) (more := m3_4128) (hs := hs3_4128) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route0 []) (correct504 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule475 route0 []) (correct475 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) (correct32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 []) (correct1 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4296 : List (BitVec 256) := [w56,w182,w298,w341,w379,w391,w427,w456,w501,w537]
private def c3_4296 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route4 [(false,(2,false),(4,true))],rule288 route0 [],rule2 route0 [(false,(0,false),(2,true)),(false,(0,true),(4,true))],rule0 route0 [(false,(1,false),(3,true))],rule35 route0 [],rule20 route0 [],rule110 route0 []]
private def m3_4296 : Array (List (BitVec 256)) := #[]
private def hs3_4296 : List (List Nat) := [[0,1,2,3],[522,8232,522,8232],[4362,13357,4362,13357],[525,8749,525,8749],[16463,8239,16463,8239],[32919,4,32919,5],[296,296],[585,8809,585,8809],[665,8359],[522,24680,522,24680],[4362,49353,4362,49353],[525,49355,525,49355],[8239,16463,8239,16463],[16471,16471],[32935,49383,32935,49383],[585,2127],[665,17611,665,17611],[5133,522,522,4106],[522,9256,525,522],[522,2570,530,522],[8232,522,522,8232],[522,8232,8232,522],[522,4439,585,522],[522,1419,665,522],[4362,525,4109,525],[4362,6410,4370,4362],[32919,4362,266,266],[4362,13357,13357,4362],[599,585,4169,585],[663,663,394,394],[525,2573,533,525],[32907,525,525,32907],[525,8749,8749,525],[525,5207,585,525],[525,1163,139,139],[8239,8753,8255,8239],[16463,8239,8239,16463],[585,2633,585,593],[665,2713,665,673],[32919,6,32935,32919],[32919,585,87],[1163,665,151,151],[585,8809,585,8809],[665,32935,167],[585,17611,665,585]]
theorem node3_4296 [Assumptions] : Blocked tgt 9 s3_4296 := by
  refine PetersenMixedNode.close (cut := c3_4296) (more := m3_4296) (hs := hs3_4296) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 [(false,(2,false),(4,true))]) (correct2 route4 [(false,(2,false),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule288 route0 []) (correct288 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(0,false),(2,true)),(false,(0,true),(4,true))]) (correct2 route0 [(false,(0,false),(2,true)),(false,(0,true),(4,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(1,false),(3,true))]) (correct0 route0 [(false,(1,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule20 route0 []) (correct20 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule110 route0 []) (correct110 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4367 : List (BitVec 256) := [w56,w191,w298,w341,w379,w391,w456,w501,w537]
private def c3_4367 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule107 route1 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule1 route1 [],rule26 route0 [(false,(5,true),(0,false)),(false,(0,true),(3,true)),(false,(3,true),(0,true))],rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule26 route1 [(false,(3,true),(2,false)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule504 route1 [],rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))],rule354 route1 [],rule30 route0 [(false,(1,true),(2,false)),(false,(0,true),(6,true)),(false,(8,true),(0,true))],rule99 route1 [],rule32 route1 [(false,(1,true),(2,false)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))],rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))],rule30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))],rule0 route1 [(false,(2,true),(3,false))],rule1 route0 [(false,(3,true),(2,false))],rule92 route1 [],rule39 route1 [],rule97 route2 [],rule92 route0 []]
private def m3_4367 : Array (List (BitVec 256)) := #[]
private def hs3_4367 : List (List Nat) := [[16488,0,16488,24712,1,24712,16488,2,16488,24712,3,24712],[539,4,539,8249,5,8249,539,2,539,8249,6,8249],[283,7,283,9278,8,9278,283,9,283,9278,10,9278],[542,11,542,8766,12,8766,542,2,542,8766,13,8766],[49376,14,49376,8256,15,8256,49376,16,49376,8256,17,8256],[313,6,32952,313,18,19],[104,2,104,8328,20,8328,104,5,104,8328,3,8328],[168,6,168,8392,21,7],[539,16488,539,16489,16745,24697,539,16745,539,16488,16488,24697],[283,16488,283,16474,33450,16474,283,33450,283,16474,16488,16474],[542,16488,542,16492,17516,32924,542,17516,542,16488,16488,32924],[8256,16488,8256,16480,34992,49376,8256,34992,8256,16488,16488,49376],[16488,16488,7,24712,24712,32952,24712,24712,22,16488,16488,32952],[104,32936,104,16488,16488,33498,104,16488,104,602,32936,33498],[168,16488,168,16616,32936,17628,168,32936,168,1180,16488,17628],[1054,8249,1054,283,539,283,27,539,1054,27,8249,283],[539,539,542,9273,9277,33181,542,9277,542,539,539,33181],[539,539,8256,2587,2595,49633,547,2595,8256,539,539,49633],[539,539,32952,8249,8249,33209,8249,8249,32952,539,539,33209],[104,539,104,360,24697,361,104,24697,104,105,539,361],[168,539,168,424,33435,425,168,33435,168,169,539,425],[283,283,32924,542,1054,542,30,1054,32924,30,283,542],[283,283,8256,2331,2339,8770,291,2339,8256,283,283,8770],[283,283,32952,9278,9278,33466,9278,9278,32952,283,283,33466],[104,283,104,616,16474,618,104,16474,104,106,283,618],[168,283,168,680,33179,682,168,33179,168,170,283,682],[542,542,8256,2590,2598,9284,550,2598,8256,542,542,9284],[542,542,32952,8766,8766,23,8766,8766,32952,542,542,2],[104,542,104,1128,49372,1132,104,49372,104,108,542,1132],[168,542,168,1192,32924,1196,168,32924,168,172,542,1196],[32952,49376,32952,8256,8256,35008,8256,8256,32952,32960,49376,35008],[104,8256,104,2144,49376,2144,96,49376,104,96,8256,2144],[168,8256,168,2216,49376,2224,168,49376,168,176,8256,2224],[104,32952,104,8328,49400,8328,104,49400,104,8328,32952,8328],[168,19,168,32952,32952,7,200,19,7],[104,104,168,17564,33498,17628,168,33498,168,104,104,17628]]
theorem node3_4367 [Assumptions] : Blocked tgt 9 s3_4367 := by
  refine PetersenMixedNode.close (cut := c3_4367) (more := m3_4367) (hs := hs3_4367) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route1 []) (correct107 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route1 []) (correct1 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(5,true),(0,false)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(5,true),(0,false)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(3,true),(2,false)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route1 [(false,(3,true),(2,false)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route1 []) (correct504 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) (correct3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule354 route1 []) (correct354 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(1,true),(2,false)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(1,true),(2,false)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route1 []) (correct99 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route1 [(false,(1,true),(2,false)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route1 [(false,(1,true),(2,false)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) (correct32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))]) (correct30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route1 [(false,(2,true),(3,false))]) (correct0 route1 [(false,(2,true),(3,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(3,true),(2,false))]) (correct1 route0 [(false,(3,true),(2,false))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route1 []) (correct92 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_4370 : List (BitVec 256) := [w56,w192,w298,w341,w379,w391,w456,w501,w537]
private def c3_4370 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route4 [],rule107 route1 [],rule41 route0 [],rule1 route1 [],rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))],rule412 route1 [(false,(5,false),(1,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))],rule41 route5 [],rule26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule510 route1 [],rule39 route4 [],rule2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))],rule99 route1 [],rule32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))],rule26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))],rule417 route1 [],rule30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))],rule1 route0 [(false,(2,false),(1,true))],rule3 route5 [],rule116 route1 [],rule39 route1 [],rule109 route0 [],rule97 route2 [],rule92 route0 [],rule109 route5 [],rule116 route0 []]
private def m3_4370 : Array (List (BitVec 256)) := #[[w0,w192,w298,w341,w379,w391,w456,w501,w537],[w192,w298,w341,w379,w391,w450,w456,w501,w537],[w192,w298,w341,w379,w391,w456,w501,w537,w566]]
private def hs3_4370 : List (List Nat) := [[16494,0,16494,24718,1,24718,16494,2,16494,24718,3,24718],[545,4,545,8255,5,8255,545,6,545,8255,7,8255],[289,8,289,9284,9,9284,289,10,289,9284,11,9284],[548,12,548,8772,13,8772,548,6,548,8772,14,8772],[16486,15,16486,8262,16,8262,16486,2,16486,8262,17,8262],[319,27,32958,319,28,18],[110,19,110,8334,20,8334,110,21,110,8334,3,8334],[174,27,174,8398,29,2],[545,16494,545,16495,16751,24703,545,16751,545,16494,16494,24703],[289,16494,289,16480,33456,33185,289,33456,289,16494,16494,33185],[548,16494,548,16498,17522,32930,548,17522,548,16494,16494,32930],[8262,16494,8262,16486,34998,16486,8262,34998,8262,16486,16494,16486],[16494,16494,22,24718,24718,32958,24718,24718,23,16494,16494,32958],[110,32942,110,16494,16494,33504,110,16494,110,2150,32942,33504],[174,16494,174,16622,32942,17634,174,32942,174,1186,16494,17634],[1060,8255,1060,289,545,289,33,545,1060,33,8255,289],[545,545,548,9279,9283,33187,548,9283,548,545,545,33187],[545,545,8262,2593,2601,16743,553,2601,8262,545,545,16743],[545,545,32958,8255,8255,33215,8255,8255,32958,545,545,33215],[110,545,110,366,24703,367,110,24703,110,111,545,367],[174,545,174,430,33441,431,174,33441,174,175,545,431],[289,289,32930,548,1060,548,36,1060,32930,36,289,548],[289,289,8262,2337,2345,8776,297,2345,8262,289,289,8776],[289,289,32958,9284,9284,33472,9284,9284,32958,289,289,33472],[110,289,110,608,49376,608,96,49376,110,96,289,608],[174,289,174,686,33185,688,174,33185,174,176,289,688],[548,548,8262,2596,2604,9290,556,2604,8262,548,548,9290],[548,548,32958,8772,8772,24,8772,8772,32958,548,548,25],[110,548,110,1134,49378,1138,110,49378,110,114,548,1138],[174,548,174,1198,32930,1202,174,32930,174,178,548,1202],[16486,16486,32958,8262,8262,35014,8262,8262,32958,16486,16486,35014],[110,8262,110,2158,16486,2166,110,16486,110,118,8262,2166],[174,8262,174,2222,49382,2230,174,49382,174,182,8262,2230],[110,32958,110,8334,49406,8334,110,49406,110,8334,32958,8334],[174,18,174,32958,32958,2,206,18,26],[110,110,174,17570,33504,17634,174,33504,174,110,110,17634]]
theorem node3_4370 [Assumptions] : Blocked tgt 9 s3_4370 := by
  refine PetersenMixedNode.close (cut := c3_4370) (more := m3_4370) (hs := hs3_4370) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route4 []) (correct2 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route1 []) (correct107 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route1 []) (correct1 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(0,false),(4,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule412 route1 [(false,(5,false),(1,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))]) (correct412 route1 [(false,(5,false),(1,true)),(false,(1,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route5 []) (correct41 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) (correct26 route1 [(false,(2,false),(6,true)),(false,(0,true),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule510 route1 []) (correct510 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route4 []) (correct39 route4 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct2 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(2,false),(3,true)),(false,(0,true),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route1 []) (correct99 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) (correct32 route1 [(false,(2,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) (correct26 route5 [(false,(4,false),(0,true)),(false,(0,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule417 route1 []) (correct417 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route1 [(false,(5,false),(0,true)),(false,(0,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(2,false),(1,true))]) (correct1 route0 [(false,(2,false),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 []) (correct3 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route1 []) (correct116 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route0 []) (correct109 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route5 []) (correct109 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route0 []) (correct116 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w192,w298,w341,w379,w391,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_0 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w192,w298,w341,w379,w391,w450,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_1688 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w192,w298,w341,w379,w391,w456,w501,w537,w566]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_1730 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_4391 : List (BitVec 256) := [w56,w195,w279,w298,w341,w379,w391,w456,w501,w537]
private def c3_4391 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route5 [(false,(1,true),(3,true)),(false,(3,true),(0,true))],rule504 route0 [],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule1 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))],rule26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule428 route5 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule509 route6 [],rule0 route6 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]]
private def m3_4391 : Array (List (BitVec 256)) := #[]
private def hs3_4391 : List (List Nat) := [[16472,24696,16472,24696],[0,1,2,3],[4,8233,5,8233],[267,6,267,7],[526,8750,526,8750],[16464,8240,16464,8240],[297,297],[88,8312,88,8312],[152,8376],[16472,33434,33434,16472],[8233,16473,8233,16472],[267,16715,267,16472],[526,16476,526,16472],[8240,16464,8240,16464],[16472,24696,24696,16472],[88,16472,88,586],[152,16600,152,1164],[523,523],[267,1038],[32908,526,32908,526],[8240,8754,8240,8754],[32936,33450,32936,33450],[88,602,88,602],[152,666,152,666],[8233,267,11],[526,9257,526,8233],[8233,16720,8240,8233],[32936,8233,8233,32937],[88,344,88,89],[152,408,152,153],[267,526,271,267],[267,2315,275,267],[267,33450,32936,267],[88,602,88,267],[152,666,152,267],[526,2574,534,526],[526,8750,8750,526],[88,1112,88,92],[152,1176,152,156],[16464,8240,8240,16464],[88,2136,88,96],[152,2200,152,160],[88,8312,88,8312],[152,32936,184],[88,17548,152,88]]
theorem node3_4391 [Assumptions] : Blocked tgt 9 s3_4391 := by
  refine PetersenMixedNode.close (cut := c3_4391) (more := m3_4391) (hs := hs3_4391) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route5 [(false,(1,true),(3,true)),(false,(3,true),(0,true))]) (correct0 route5 [(false,(1,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route0 []) (correct504 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) (correct1 route7 [(false,(4,true),(1,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule428 route5 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct428 route5 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule509 route6 []) (correct509 route6 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route6 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) (correct0 route6 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4397 : List (BitVec 256) := [w56,w195,w293,w298,w341,w379,w391,w456,w501,w537]
private def c3_4397 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule504 route0 [],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule69 route7 [],rule509 route7 [],rule69 route6 []]
private def m3_4397 : Array (List (BitVec 256)) := #[]
private def hs3_4397 : List (List Nat) := [[16470,24694,16470,24694],[0,1,2,3],[521,8231,521,8231],[265,9260,265,9260],[524,8748,524,8748],[16462,8238,16462,8238],[295,295],[343,4,343,5],[407,24806],[16727,16470,16470,16727],[521,16727,521,16470],[265,16456,265,16456],[524,16474,524,16470],[8238,16462,8238,16462],[16470,24694,24694,16470],[343,16470,343,2383],[407,16598,407,1419],[521,24679],[265,16456,265,16456],[524,32906,524,32906],[8238,16462,8238,16462],[33191,32934,33191,32934],[343,33480,86,86],[407,17610,150,150],[1036,265,9,9],[521,9255,524,521],[521,2569,529,521],[521,8231,8231,521],[521,343,87,87],[521,407,151,151],[265,524,12,12],[265,2313,273,265],[265,9260,9260,265],[265,16456,343,265],[265,33161,407,265],[524,2572,532,524],[524,8748,8748,524],[343,1367,343,347],[407,1431,407,411],[16462,8238,8238,16462],[343,2391,343,351],[407,2455,407,415],[343,49318,343,32934],[407,32934,439],[343,17546,407,343]]
theorem node3_4397 [Assumptions] : Blocked tgt 9 s3_4397 := by
  refine PetersenMixedNode.close (cut := c3_4397) (more := m3_4397) (hs := hs3_4397) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route0 []) (correct504 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route7 []) (correct69 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule509 route7 []) (correct509 route7 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule69 route6 []) (correct69 route6 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4416 : List (BitVec 256) := [w56,w195,w298,w340,w341,w379,w391,w456,w501,w537]
private def c3_4416 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule504 route0 [],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule475 route0 [],rule26 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))],rule41 route0 []]
private def m3_4416 : Array (List (BitVec 256)) := #[]
private def hs3_4416 : List (List Nat) := [[16471,24695,16471,24695],[522,8232,522,8232],[0,1,2,3],[266,9261,266,9261],[525,8749,525,8749],[16463,8239,16463,8239],[296,296],[87,8311,87,8311],[151,8375],[522,16472,522,16471],[16471,33433,33433,16471],[266,33433,266,16471],[525,16475,525,16471],[8239,16463,8239,16463],[16471,24695,24695,16471],[87,16471,87,2127],[151,16599,151,1163],[522,33418,33418,522],[1037,266,10,10],[522,9256,525,522],[522,2570,530,522],[522,8232,8232,522],[87,343,87,88],[151,407,151,152],[266,16457],[525,33421,525,33421],[8239,4,8239,5],[32935,33449,32935,33449],[87,33481,87,601],[151,6,151,665],[266,525,13,13],[266,2314,274,266],[266,9261,9261,266],[87,599,87,266],[151,663,151,266],[525,2573,533,525],[525,8749,8749,525],[87,1111,87,91],[151,1175,151,155],[16463,8239,8239,16463],[87,2135,87,95],[151,2199,151,159],[87,8311,87,8311],[151,32935,183],[87,17547,151,87]]
theorem node3_4416 [Assumptions] : Blocked tgt 9 s3_4416 := by
  refine PetersenMixedNode.close (cut := c3_4416) (more := m3_4416) (hs := hs3_4416) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route0 []) (correct504 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule475 route0 []) (correct475 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) (correct26 route5 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil

def s3_4419 : List (BitVec 256) := [w56,w195,w298,w341,w374,w379,w391,w456,w501,w537]
private def c3_4419 : Array (PetersenProjectedRule.Rule 256) := #[rule504 route1 [],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule501 route0 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]]
private def m3_4419 : Array (List (BitVec 256)) := #[]
private def hs3_4419 : List (List Nat) := [[16469,24693,16469,24693],[520,8744,520,8744],[264,0,264,1],[2,3,4,1],[523,8747,523,8747],[16461,8237,16461,8237],[294,294],[85,8309,85,8309],[149,8373],[520,16726,520,16469],[264,16712,264,16469],[16469,16726,16726,16469],[523,16473,523,16469],[8237,16461,8237,16461],[16469,24693,24693,16469],[85,16469,85,583],[149,16597,149,1161],[1291,520,264],[520,8230],[520,33162,523,520],[520,2568,528,520],[520,8744,8744,520],[85,342,85,342],[149,406,149,406],[264,1035],[264,523,268,264],[264,2312,272,264],[264,33447,32933,264],[85,599,85,264],[149,663,149,264],[32905,523,32905,523],[8237,8751,8237,8751],[32933,33190,32933,33190],[85,342,85,342],[149,406,149,406],[523,2571,531,523],[523,8747,8747,523],[85,1109,85,89],[149,1173,149,153],[16461,8237,8237,16461],[85,2133,85,93],[149,2197,149,157],[85,8309,85,8309],[149,32933,181],[85,17545,149,85]]
theorem node3_4419 [Assumptions] : Blocked tgt 9 s3_4419 := by
  refine PetersenMixedNode.close (cut := c3_4419) (more := m3_4419) (hs := hs3_4419) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule504 route1 []) (correct504 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule501 route0 []) (correct501 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4467 : List (BitVec 256) := [w56,w195,w298,w341,w379,w391,w456,w501,w521,w537]
private def c3_4467 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule39 route0 [],rule501 route1 []]
private def m3_4467 : Array (List (BitVec 256)) := #[[w4,w195,w298,w341,w379,w391,w456,w501,w537]]
private def hs3_4467 : List (List Nat) := [[16468,24692,16468,24692],[519,8229,519,8229],[16454,24678,16454,24678],[522,8746,522,8746],[16460,8236,16460,8236],[293,293],[598,8822,598,8822],[0,1,3,2],[148,8372],[519,16469,519,16468],[16468,16454,33430,16454],[522,16472,522,16468],[8236,16460,8236,16460],[16468,24692,24692,16468],[598,16468,582,582],[32916,16468,16468,32916],[148,16596,148,1160],[8229,519,519,8229],[519,9253,522,519],[519,2567,527,519],[519,8229,8229,519],[519,24677,598,519],[8229,519,519,8229],[148,404,148,149],[16454,522,16458,522],[8236,8750,8236,8750],[16454,24678,24678,16454],[596,16454,598],[263,263],[148,662,148,662],[522,2570,530,522],[522,8746,8746,522],[522,49352,598,522],[32904,522,522,32904],[148,1172,148,152],[16460,8236,8236,16460],[598,2646,598,606],[8236,8750,8750,8236],[148,2196,148,156],[598,8822,598,8822],[32932,33446,33446,32932],[148,32932,180],[84,84],[148,17608,148,598],[148,662,148,662]]
theorem node3_4467 [Assumptions] : Blocked tgt 9 s3_4467 := by
  refine PetersenMixedNode.close (cut := c3_4467) (more := m3_4467) (hs := hs3_4467) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule501 route1 []) (correct501 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w4,w195,w298,w341,w379,w391,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_17 ThetaCert.bound)) <|
      PetersenLocalChildren.nil
def s3_4494 : List (BitVec 256) := [w56,w196,w298,w341,w379,w391,w456,w501,w537]
private def c3_4494 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule107 route0 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule35 route1 [],rule26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule26 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))],rule32 route5 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))],rule26 route1 [(false,(2,true),(0,true)),(false,(2,true),(0,true))],rule140 route0 [],rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule30 route0 [(false,(4,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))],rule92 route0 [],rule26 route5 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))],rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule30 route1 [(false,(4,true),(5,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))],rule0 route1 [(false,(0,true),(3,true))],rule1 route0 [(false,(0,true),(2,true))],rule39 route0 [],rule0 route0 [(false,(0,true),(3,true))],rule39 route1 [],rule97 route2 []]
private def m3_4494 : Array (List (BitVec 256)) := #[]
private def hs3_4494 : List (List Nat) := [[16486,0,16486,24710,1,24710,16486,2,16486,24710,3,24710],[553,4,553,8263,5,8263,553,6,553,8263,7,8263],[281,0,281,9276,8,9276,281,9,281,9276,10,9276],[540,11,540,8764,12,8764,540,2,540,8764,11,8764],[16478,13,16478,8254,14,8254,16478,0,16478,8254,15,8254],[311,4,32950,311,16,17],[102,2,102,8326,18,8326,102,14,102,8326,19,8326],[166,4,166,8390,20,0],[553,16486,553,16487,16743,24695,537,16743,553,537,16486,24695],[297,16486,1052,281,33448,281,1052,33448,1052,281,16486,281],[540,16486,540,16490,17514,32922,540,17514,540,16486,16486,32922],[8254,16486,8254,16478,34990,16478,8254,34990,8254,16478,16486,16478],[16486,16486,0,24710,24710,32950,24710,24710,21,16486,16486,32950],[102,32934,102,359,16486,2399,102,16486,102,600,32934,2399],[166,16486,166,423,32934,1435,166,32934,166,1178,16486,1435],[1052,8263,1052,281,553,281,41,553,1052,41,8263,281],[540,553,540,9287,9291,33179,540,9291,540,553,553,33179],[553,553,8254,2601,2609,16735,561,2609,8254,553,553,16735],[553,553,32950,8263,8263,33207,8263,8263,32950,553,553,33207],[102,553,102,2398,24695,2399,102,24695,102,103,553,2399],[166,553,166,1434,33433,1435,166,33433,166,167,553,1435],[281,281,32922,540,1052,540,28,1052,32922,28,281,540],[281,281,8254,2329,2337,8768,289,2337,8254,281,281,8768],[281,281,32950,9276,9276,33464,9276,9276,32950,281,281,33464],[102,281,102,614,16472,616,102,16472,102,104,281,616],[166,281,166,678,33177,680,166,33177,166,168,281,680],[540,540,8254,2588,2596,9282,548,2596,8254,540,540,9282],[540,540,32950,8764,8764,12,8764,8764,32950,540,540,2],[102,540,102,1126,49370,1130,102,49370,102,106,540,1130],[166,540,166,1190,32922,1194,166,32922,166,170,540,1194],[16478,16478,32950,8254,8254,35006,8254,8254,32950,16478,16478,35006],[102,8254,102,2150,16478,2158,102,16478,102,110,8254,2158],[166,8254,166,2214,49374,2222,166,49374,166,174,8254,2222],[102,32950,102,8326,49398,8326,102,49398,102,8326,32950,8326],[166,17,166,32950,32950,0,198,17,0],[102,102,166,17562,33496,17626,166,33496,166,102,102,17626]]
theorem node3_4494 [Assumptions] : Blocked tgt 9 s3_4494 := by
  refine PetersenMixedNode.close (cut := c3_4494) (more := m3_4494) (hs := hs3_4494) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route0 []) (correct107 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route1 []) (correct35 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct26 route0 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route5 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))]) (correct32 route5 [(false,(6,false),(2,true)),(false,(1,true),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(2,true),(0,true)),(false,(2,true),(0,true))]) (correct26 route1 [(false,(2,true),(0,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule140 route0 []) (correct140 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) (correct3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(4,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(4,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) (correct26 route5 [(false,(5,true),(4,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(4,true),(5,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) (correct30 route1 [(false,(4,true),(5,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route1 [(false,(0,true),(3,true))]) (correct0 route1 [(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(0,true),(2,true))]) (correct1 route0 [(false,(0,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(0,true),(3,true))]) (correct0 route0 [(false,(0,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_4497 : List (BitVec 256) := [w56,w197,w298,w341,w379,w391,w456,w501,w521,w537]
private def c3_4497 : Array (PetersenProjectedRule.Rule 256) := #[rule41 route0 [],rule29 route0 [],rule514 route0 []]
private def m3_4497 : Array (List (BitVec 256)) := #[[w4,w197,w298,w341,w379,w391,w456,w501,w537]]
private def hs3_4497 : List (List Nat) := [[16468,24692,16468,24692],[519,8229,519,8229],[16454,24678,16454,24678],[522,8746,522,8746],[16460,8236,16460,8236],[293,293],[582,8806,582,8806],[0,1,3,2],[148,8372],[535,519,4615,519],[16468,16454,33430,16454],[538,522,4618,522],[8236,8750,8236,8750],[16468,24692,24692,16468],[598,582,4678,582],[32916,16468,16468,32916],[148,662,148,1160],[8229,519,519,8229],[519,9253,522,519],[519,2567,527,519],[519,8229,8229,519],[519,24677,582,519],[8229,519,519,8229],[148,404,148,149],[16454,522,16458,522],[8236,8750,8236,8750],[16454,24678,24678,16454],[2636,16454,582],[279,279],[148,4758,148,4758],[522,2570,530,522],[522,8746,8746,522],[522,49352,582,522],[32904,522,522,32904],[148,1172,148,152],[16460,8236,8236,16460],[582,2630,582,590],[8236,8750,8750,8236],[148,2196,148,156],[582,8806,582,8806],[32932,33446,33446,32932],[148,32932,180],[84,84],[148,17608,148,582],[148,4758,148,4758]]
theorem node3_4497 [Assumptions] : Blocked tgt 9 s3_4497 := by
  refine PetersenMixedNode.close (cut := c3_4497) (more := m3_4497) (hs := hs3_4497) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route0 []) (correct29 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule514 route0 []) (correct514 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w4,w197,w298,w341,w379,w391,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_18 ThetaCert.bound)) <|
      PetersenLocalChildren.nil

def s3_4498 : List (BitVec 256) := [w56,w197,w298,w341,w379,w391,w456,w501,w537]
private def c3_4498 : Array (PetersenProjectedRule.Rule 256) := #[rule35 route0 [],rule107 route0 [],rule41 route5 [],rule35 route1 [],rule26 route0 [(false,(0,true),(4,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))],rule458 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))],rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule29 route0 [],rule30 route0 [(false,(2,true),(3,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))],rule92 route0 [],rule26 route5 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))],rule432 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(6,true),(0,true))],rule41 route0 [],rule32 route0 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))],rule1 route0 [(false,(2,true),(1,true))],rule3 route5 [(false,(4,true),(2,true))],rule39 route0 [],rule0 route0 [(false,(1,true),(3,true))],rule109 route0 [],rule97 route2 [],rule109 route5 [],rule116 route0 []]
private def m3_4498 : Array (List (BitVec 256)) := #[[w28,w197,w298,w341,w379,w391,w456,w501,w537],[w0,w197,w298,w341,w379,w391,w456,w501,w537],[w197,w298,w341,w379,w391,w450,w456,w501,w537],[w7,w197,w298,w341,w379,w391,w456,w501,w537],[w197,w298,w341,w379,w391,w456,w501,w537,w566]]
private def hs3_4498 : List (List Nat) := [[16491,0,16491,24715,1,24715,16491,2,16491,24715,3,24715],[542,4,542,8252,5,8252,542,2,542,8252,4,8252],[302,6,302,9297,7,9297,302,22,302,9297,6,9297],[545,8,545,8769,9,8769,545,2,545,8769,8,8769],[16483,10,16483,8259,11,8259,16483,12,16483,8259,13,8259],[316,23,32955,316,24,14],[107,15,107,8331,16,8331,107,25,107,8331,17,8331],[171,23,171,8395,26,12],[558,16491,4654,542,16748,542,4638,16748,4654,542,16491,542],[302,16491,302,16477,33453,16477,286,33453,302,286,16491,16477],[561,16491,4657,545,17519,545,4641,17519,4657,545,16491,545],[8259,16491,8259,8773,34995,8773,8259,34995,8259,8773,16491,8773],[16491,16491,18,24715,24715,32955,24715,24715,19,16491,16491,32955],[107,32939,107,605,16491,605,107,16491,107,605,32939,605],[171,16491,171,685,32939,17631,171,32939,171,1183,16491,17631],[1073,8252,1073,302,542,302,46,542,1073,46,8252,302],[542,542,545,9276,9280,33184,545,9280,545,542,542,33184],[542,542,8259,2590,2598,16740,550,2598,8259,542,542,16740],[542,542,32955,8252,8252,33212,8252,8252,32955,542,542,33212],[107,542,107,363,24700,364,107,24700,107,108,542,364],[171,542,171,427,33438,428,171,33438,171,172,542,428],[302,302,32927,545,1073,545,49,1073,32927,49,302,545],[302,302,8259,2350,2358,8773,310,2358,8259,302,302,8773],[302,302,32955,9297,9297,33469,9297,9297,32955,302,302,33469],[107,302,107,605,16477,605,107,16477,107,109,302,605],[171,302,171,4779,33182,4781,171,33182,171,173,302,4781],[545,545,8259,2593,2601,9287,553,2601,8259,545,545,9287],[545,545,32955,8769,8769,9,8769,8769,32955,545,545,20],[107,545,107,1131,49375,1135,107,49375,107,111,545,1135],[171,545,171,1195,32927,1199,171,32927,171,175,545,1199],[16483,16483,32955,8259,8259,35011,8259,8259,32955,16483,16483,35011],[107,8259,107,2155,16483,2163,107,16483,107,115,8259,2163],[171,8259,171,2219,49379,2227,171,49379,171,179,8259,2227],[107,32955,107,8331,49403,8331,107,49403,107,8331,32955,8331],[171,14,171,32955,32955,12,203,14,21],[107,107,171,17567,33501,17631,171,33501,171,107,107,17631]]
theorem node3_4498 [Assumptions] : Blocked tgt 9 s3_4498 := by
  refine PetersenMixedNode.close (cut := c3_4498) (more := m3_4498) (hs := hs3_4498) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route0 []) (correct35 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule107 route0 []) (correct107 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route5 []) (correct41 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule35 route1 []) (correct35 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(0,true),(4,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(0,true),(4,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule458 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))]) (correct458 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct3 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule29 route0 []) (correct29 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(2,true),(3,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(2,true),(3,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) (correct26 route5 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule432 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(6,true),(0,true))]) (correct432 route0 [(false,(7,false),(3,true)),(false,(1,true),(4,true)),(false,(6,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route0 []) (correct41 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) (correct32 route0 [(false,(4,true),(0,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(2,true),(1,true))]) (correct1 route0 [(false,(2,true),(1,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route5 [(false,(4,true),(2,true))]) (correct3 route5 [(false,(4,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route0 []) (correct39 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 [(false,(1,true),(3,true))]) (correct0 route0 [(false,(1,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route0 []) (correct109 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule109 route5 []) (correct109 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route0 []) (correct116 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w28,w197,w298,w341,w379,w391,w456,w501,w537]) (via sym4 fix4 (by decide +kernel) (Orbits1020Cost12.b4_81 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w0,w197,w298,w341,w379,w391,w456,w501,w537]) (Orbits1020Cost12.b4_2 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w197,w298,w341,w379,w391,w450,w456,w501,w537]) (Orbits1020Cost12.b4_2177 ThetaCert.bound) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w7,w197,w298,w341,w379,w391,w456,w501,w537]) (via sym1 fix1 (by decide +kernel) (Orbits1020Cost12.b4_78 ThetaCert.bound)) <|
      PetersenLocalChildren.push (P := Blocked tgt 8) (x := [w197,w298,w341,w379,w391,w456,w501,w537,w566]) (Orbits1020Cost12.b4_2214 ThetaCert.bound) <|
      PetersenLocalChildren.nil
def s3_4501 : List (BitVec 256) := [w56,w198,w298,w341,w379,w391,w456,w501,w537]
private def c3_4501 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule84 route1 [],rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))],rule1 route1 [],rule26 route0 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))],rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))],rule26 route1 [(false,(3,true),(2,true)),(false,(0,false),(1,true)),(false,(3,true),(0,true))],rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule515 route1 [],rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))],rule116 route1 [],rule30 route0 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))],rule99 route1 [],rule32 route1 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(5,true),(0,true))],rule26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))],rule30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))],rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))],rule30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))],rule0 route1 [(false,(2,true),(3,true))],rule1 route0 [(false,(3,true),(2,true))],rule41 route1 [],rule39 route1 [],rule97 route2 [],rule92 route0 []]
private def m3_4501 : Array (List (BitVec 256)) := #[]
private def hs3_4501 : List (List Nat) := [[16488,0,16488,24712,1,24712,16488,2,16488,24712,3,24712],[539,4,539,8249,5,8249,539,2,539,8249,6,8249],[283,7,283,9278,8,9278,283,9,283,9278,10,9278],[542,11,542,8766,12,8766,542,2,542,8766,13,8766],[16480,14,16480,8272,15,8272,16480,16,16480,8272,17,8272],[313,6,32952,313,18,19],[104,2,104,8328,20,8328,104,5,104,8328,3,8328],[168,6,168,8392,21,7],[539,16488,539,2595,16745,2595,539,16745,539,2595,16488,2595],[283,16488,283,2339,33450,2339,283,33450,283,2339,16488,2339],[542,16488,542,2598,17516,2598,542,17516,542,2598,16488,2598],[8272,16488,8272,16480,34992,16480,8256,34992,8272,8256,16488,16480],[16488,16488,7,24712,24712,32952,24712,24712,22,16488,16488,32952],[104,32936,104,2144,16488,2144,104,16488,104,602,32936,2144],[168,16488,168,2224,32936,3236,168,32936,168,1180,16488,3236],[1054,8249,1054,283,539,283,27,539,1054,27,8249,283],[539,539,542,9273,9277,33181,542,9277,542,539,539,33181],[539,539,8272,2595,2595,16737,563,2595,8272,539,539,16737],[539,539,32952,8249,8249,33209,8249,8249,32952,539,539,33209],[104,539,104,360,24697,361,104,24697,104,105,539,361],[168,539,168,424,33435,425,168,33435,168,169,539,425],[283,283,32924,542,1054,542,30,1054,32924,30,283,542],[283,283,8272,2339,2339,8786,307,2339,8272,283,283,8786],[283,283,32952,9278,9278,33466,9278,9278,32952,283,283,33466],[104,283,104,616,16474,618,104,16474,104,106,283,618],[168,283,168,680,33179,682,168,33179,168,170,283,682],[542,542,8272,2598,2598,9300,566,2598,8272,542,542,9300],[542,542,32952,8766,8766,23,8766,8766,32952,542,542,2],[104,542,104,1128,49372,1132,104,49372,104,108,542,1132],[168,542,168,1192,32924,1196,168,32924,168,172,542,1196],[16480,16480,32952,8272,8272,35008,8272,8272,32952,16480,16480,35008],[104,8272,104,2144,16480,2144,104,16480,104,112,8272,2144],[168,8272,168,3228,49376,3236,168,49376,168,176,8272,3236],[104,32952,104,8328,49400,8328,104,49400,104,8328,32952,8328],[168,19,168,32952,32952,7,200,19,7],[104,104,168,17564,33498,17628,168,33498,168,104,104,17628]]
theorem node3_4501 [Assumptions] : Blocked tgt 9 s3_4501 := by
  refine PetersenMixedNode.close (cut := c3_4501) (more := m3_4501) (hs := hs3_4501) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule84 route1 []) (correct84 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) (correct2 route5 [(false,(0,true),(2,true)),(false,(2,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route1 []) (correct1 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route0 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))]) (correct26 route0 [(false,(5,true),(0,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) (correct3 route1 [(false,(2,true),(4,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route1 [(false,(3,true),(2,true)),(false,(0,false),(1,true)),(false,(3,true),(0,true))]) (correct26 route1 [(false,(3,true),(2,true)),(false,(0,false),(1,true)),(false,(3,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct2 route0 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule515 route1 []) (correct515 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) (correct3 route4 [(false,(1,true),(4,true)),(false,(1,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule116 route1 []) (correct116 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route0 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) (correct30 route0 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule99 route1 []) (correct99 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route1 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(5,true),(0,true))]) (correct32 route1 [(false,(1,true),(2,true)),(false,(0,false),(5,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) (correct26 route5 [(false,(4,true),(2,true)),(false,(4,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))]) (correct30 route1 [(false,(3,false),(2,true)),(false,(6,true),(3,true)),(false,(8,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) (correct32 route0 [(false,(6,false),(2,true)),(false,(5,true),(3,true)),(false,(5,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))]) (correct30 route1 [(false,(5,true),(2,true)),(false,(7,true),(0,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route1 [(false,(2,true),(3,true))]) (correct0 route1 [(false,(2,true),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule1 route0 [(false,(3,true),(2,true))]) (correct1 route0 [(false,(3,true),(2,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule41 route1 []) (correct41 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule39 route1 []) (correct39 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule97 route2 []) (correct97 route2 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule92 route0 []) (correct92 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_5010 : List (BitVec 256) := [w56,w298,w300,w341,w379,w391,w423,w456,w501,w537]
private def c3_5010 : Array (PetersenProjectedRule.Rule 256) := #[rule2 route0 [],rule75 route1 [],rule0 route5 [(false,(4,false),(3,true))],rule2 route1 [(false,(2,true),(4,false))]]
private def m3_5010 : Array (List (BitVec 256)) := #[]
private def hs3_5010 : List (List Nat) := [[519,8229,519,8229],[0,1,2,3],[16454,24678,16454,24678],[522,8746,522,8746],[16460,8236,16460,8236],[16468,24692,16468,24692],[293,293],[2124,12404,2124,12404],[4758,8870],[8229,519,519,8229],[8229,519,519,8229],[519,9253,522,519],[519,2567,527,519],[519,4615,535,519],[519,8229,8229,519],[519,2380,583,519],[519,17864,647,519],[16454,33159,263,263],[49352,522,49352,522],[8236,8750,8236,8750],[16468,32916,16468,32916],[49380,32932,49380,32932],[582,582,2124,35277],[17608,4758,1160,1160],[16454,522,16458,522],[8236,8750,8236,8750],[16454,33428,16468,16454],[16454,24678,24678,16454],[2124,16454,70,70],[4756,4756,16582,4758],[522,2570,530,522],[522,4618,538,522],[522,8746,8746,522],[522,3148,2124,522],[522,17608,650,522],[8236,12332,8252,8236],[16460,8236,8236,16460],[4180,2124,76,76],[4758,6806,4758,4766],[16468,24692,24692,16468],[2124,4180,84,84],[16468,4758,662,662],[2124,12404,2124,12404],[4758,32932,678],[2124,17608,1224,1224]]
theorem node3_5010 [Assumptions] : Blocked tgt 9 s3_5010 := by
  refine PetersenMixedNode.close (cut := c3_5010) (more := m3_5010) (hs := hs3_5010) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route0 []) (correct2 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route1 []) (correct75 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route5 [(false,(4,false),(3,true))]) (correct0 route5 [(false,(4,false),(3,true))]) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route1 [(false,(2,true),(4,false))]) (correct2 route1 [(false,(2,true),(4,false))]) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
def s3_5016 : List (BitVec 256) := [w56,w298,w301,w341,w379,w391,w423,w456,w501,w537]
private def c3_5016 : Array (PetersenProjectedRule.Rule 256) := #[rule0 route0 [],rule75 route1 [],rule2 route5 [],rule53 route1 []]
private def m3_5016 : Array (List (BitVec 256)) := #[]
private def hs3_5016 : List (List Nat) := [[519,8229,519,8229],[0,1,2,3],[263,9258,263,9258],[522,8746,522,8746],[16460,8236,16460,8236],[16468,24692,16468,24692],[293,293],[582,8806,582,8806],[4758,8870],[519,24677,24677,519],[1034,263,7,7],[519,9253,522,519],[519,2567,527,519],[519,4615,535,519],[519,8229,8229,519],[519,24677,582,519],[519,17864,4758,519],[263,16454,263,16711],[522,32904,522,32904],[8236,16460,8236,16460],[33430,16468,33430,16468],[33446,32932,33446,32932],[582,35020,582,2124],[4758,17608,1160,1160],[263,522,10,10],[263,2311,271,263],[263,4359,279,263],[263,9258,9258,263],[263,582,70,70],[263,4758,1162,263],[522,2570,530,522],[522,4618,538,522],[522,8746,8746,522],[522,49288,582,522],[522,17608,650,522],[8236,12332,8252,8236],[16460,8236,8236,16460],[582,2630,582,590],[4758,6806,4758,4766],[16468,24692,24692,16468],[582,4678,582,598],[16468,4758,662,662],[582,8806,582,8806],[4758,32932,678],[582,17544,710,582]]
theorem node3_5016 [Assumptions] : Blocked tgt 9 s3_5016 := by
  refine PetersenMixedNode.close (cut := c3_5016) (more := m3_5016) (hs := hs3_5016) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule0 route0 []) (correct0 route0 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule75 route1 []) (correct75 route1 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule2 route5 []) (correct2 route5 []) <|
      PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule53 route1 []) (correct53 route1 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
end MC161RCert
