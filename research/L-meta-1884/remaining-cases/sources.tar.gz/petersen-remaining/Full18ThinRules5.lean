import PetersenProjectedRule
import Full18FastBases
import Full18Data3
import Full18ThinView4
import Full18ThinView6
import Full18ThinView7
import Full18ThinView8
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound3688 (h : Needs) : Correct rule3688 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3688) (t := Root17.tgt) SEP127 ONES127 thinBasis13 TG127 (baseThin13 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3689 (h : Needs) : Correct rule3689 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3689) (t := Root17.tgt) SEP127 ONES127 thinBasis13 TG127 (baseThin13 h) (by decide +kernel) [(false,(7,true),(6,true)),(false,(6,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3691 (h : Needs) : Correct rule3691 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3691) (t := Root17.tgt) SEP127 ONES127 thinBasis13 TG127 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3703 (h : Needs) : Correct rule3703 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3703) (t := Root17.tgt) SEP133 ONES133 thinBasis1 TG133 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3704 (h : Needs) : Correct rule3704 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3704) (t := Root17.tgt) SEP127 ONES127 thinBasis1 TG127 (baseThin1 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3706 (h : Needs) : Correct rule3706 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3706) (t := Root17.tgt) SEP127 ONES127 thinBasis1 TG127 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3729 (h : Needs) : Correct rule3729 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3729) (t := Root17.tgt) SEP170 ONES170 thinBasis5 TG170 (baseThin5 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound3748 (h : Needs) : Correct rule3748 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3748) (t := Root17.tgt) SEP168 ONES168 thinBasis5 TG168 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3754 (h : Needs) : Correct rule3754 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3754) (t := Root17.tgt) SEP168 ONES168 thinBasis14 TG168 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3768 (h : Needs) : Correct rule3768 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3768) (t := Root17.tgt) SEP161 ONES161 thinBasis1 TG161 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3769 (h : Needs) : Correct rule3769 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3769) (t := Root17.tgt) SEP159 ONES159 thinBasis5 TG159 (baseThin5 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound3770 (h : Needs) : Correct rule3770 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3770) (t := Root17.tgt) SEP159 ONES159 thinBasis5 TG159 (baseThin5 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3778 (h : Needs) : Correct rule3778 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3778) (t := Root17.tgt) SEP159 ONES159 thinBasis5 TG159 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3783 (h : Needs) : Correct rule3783 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3783) (t := Root17.tgt) SEP159 ONES159 thinBasis14 TG159 (baseThin14 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound3786 (h : Needs) : Correct rule3786 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3786) (t := Root17.tgt) SEP159 ONES159 thinBasis14 TG159 (baseThin14 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3809 (h : Needs) : Correct rule3809 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3809) (t := Root17.tgt) SEP168 ONES168 thinBasis7 TG168 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3821 (h : Needs) : Correct rule3821 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3821) (t := Root17.tgt) SEP159 ONES159 thinBasis2 TG159 (baseThin2 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound3832 (h : Needs) : Correct rule3832 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3832) (t := Root17.tgt) SEP159 ONES159 thinBasis2 TG159 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3858 (h : Needs) : Correct rule3858 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3858) (t := Root17.tgt) SEP99 ONES99 thinBasis5 TG99 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true)),(false,(8,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3862 (h : Needs) : Correct rule3862 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3862) (t := Root17.tgt) SEP99 ONES99 thinBasis5 TG99 (baseThin5 h) (by decide +kernel) [(false,(6,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3864 (h : Needs) : Correct rule3864 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3864) (t := Root17.tgt) SEP99 ONES99 thinBasis5 TG99 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound3868 (h : Needs) : Correct rule3868 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3868) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(0,false),(8,true))] rfl (by decide +kernel)
theorem quickSound3884 (h : Needs) : Correct rule3884 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3884) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(1,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3894 (h : Needs) : Correct rule3894 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3894) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(2,true),(8,true)),(false,(7,true),(8,true)),(false,(9,true),(10,true))] rfl (by decide +kernel)
theorem quickSound3898 (h : Needs) : Correct rule3898 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3898) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(3,true),(0,false))] rfl (by decide +kernel)
theorem quickSound3905 (h : Needs) : Correct rule3905 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3905) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(4,true),(0,true))] rfl (by decide +kernel)
theorem quickSound3906 (h : Needs) : Correct rule3906 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3906) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(4,true),(3,true))] rfl (by decide +kernel)
theorem quickSound3911 (h : Needs) : Correct rule3911 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3911) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(4,true),(8,true))] rfl (by decide +kernel)
theorem quickSound3915 (h : Needs) : Correct rule3915 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3915) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true)),(false,(5,true),(4,true))] rfl (by decide +kernel)
theorem quickSound3919 (h : Needs) : Correct rule3919 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3919) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(6,true),(7,true))] rfl (by decide +kernel)
theorem quickSound3921 (h : Needs) : Correct rule3921 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3921) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound3922 (h : Needs) : Correct rule3922 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule3922) (t := Root17.tgt) SEP99 ONES99 thinBasis2 TG99 (baseThin2 h) (by decide +kernel) [(false,(7,true),(4,true))] rfl (by decide +kernel)
end Full18
