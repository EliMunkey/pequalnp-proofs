import HMC010Hyp
import HMC010ThetaRoutes
import M191StartPreferredCheckedF0X4Z1
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold47_0 : NoAtMost (0xf0f0f0f0f0f0f0f0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows1 thetaInputs1 thetaTarget1 (g:=0xf0f0f0f0f0f0f0f0) (a:=0xaaaa0000aaaa0000aaaa0000aaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_1

theorem hold48_0 : NoAtMost (0xaaaaaaaa00000000aaaaaaaa :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows0 thetaInputs0 thetaTarget0 (g:=0xaaaaaaaa00000000aaaaaaaa) (a:=0xaaaa0000aaaa0000aaaa0000aaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_1

theorem hold50_0 : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xaaaa0000aaaa0000aaaa0000aaaa) (a:=0xaaaa0000aaaa0000aaaa0000aaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_1

theorem hold53_0 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0xf000f000f000f000f000f000f000f0) (a:=0xaaaa0000aaaa0000aaaa0000aaaa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_4_1
end MC010Cert
