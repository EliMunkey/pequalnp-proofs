import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import PetersenProjectedRule
import Full18StepS18964
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient18964 (h : Needs) : Blocked Root17.tgt 14 live18964 := by
  apply stepS18964
  · change ∀ r ∈ [rule3064,rule2953,rule7519,rule3070,rule1507,rule1508,rule6109,rule6004,rule3063,rule6009,rule6054,rule3254,rule3241,rule6082,rule6105,rule3259,rule6014,rule7459,rule3255,rule6716,rule3052,rule5944], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2953) (quickSound2953 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7519) (quickSound7519 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1507) (quickSound1507 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1508) (quickSound1508 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6109) (quickSound6109 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6004) (quickSound6004 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6009) (quickSound6009 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6054) (quickSound6054 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3254) (quickSound3254 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3241) (quickSound3241 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6105) (quickSound6105 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3259) (quickSound3259 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6014) (quickSound6014 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7459) (quickSound7459 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6716) (quickSound6716 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [], Blocked Root17.tgt 13 s
    exact PetersenLocalChildren.nil
end Full18
