import PetersenProjectedRule
import Full18FastBases
import Full18Data8
import Full18ThinView3
import Full18ThinView4
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound8022 (h : Needs) : Correct rule8022 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8022) (t := Root17.tgt) SEP71 ONES71 thinBasis10 TG71 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8023 (h : Needs) : Correct rule8023 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8023) (t := Root17.tgt) SEP71 ONES71 thinBasis9 TG71 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8030 (h : Needs) : Correct rule8030 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8030) (t := Root17.tgt) SEP69 ONES69 thinBasis15 TG69 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8033 (h : Needs) : Correct rule8033 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8033) (t := Root17.tgt) SEP70 ONES70 thinBasis20 TG70 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8041 (h : Needs) : Correct rule8041 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8041) (t := Root17.tgt) SEP76 ONES76 thinBasis15 TG76 (baseThin15 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8044 (h : Needs) : Correct rule8044 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8044) (t := Root17.tgt) SEP76 ONES76 thinBasis15 TG76 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8048 (h : Needs) : Correct rule8048 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8048) (t := Root17.tgt) SEP82 ONES82 thinBasis15 TG82 (baseThin15 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8051 (h : Needs) : Correct rule8051 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8051) (t := Root17.tgt) SEP82 ONES82 thinBasis15 TG82 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8052 (h : Needs) : Correct rule8052 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8052) (t := Root17.tgt) SEP76 ONES76 thinBasis20 TG76 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8053 (h : Needs) : Correct rule8053 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8053) (t := Root17.tgt) SEP76 ONES76 thinBasis10 TG76 (baseThin10 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8054 (h : Needs) : Correct rule8054 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8054) (t := Root17.tgt) SEP76 ONES76 thinBasis10 TG76 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8057 (h : Needs) : Correct rule8057 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8057) (t := Root17.tgt) SEP76 ONES76 thinBasis9 TG76 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8058 (h : Needs) : Correct rule8058 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8058) (t := Root17.tgt) SEP77 ONES77 thinBasis10 TG77 (baseThin10 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8059 (h : Needs) : Correct rule8059 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8059) (t := Root17.tgt) SEP77 ONES77 thinBasis10 TG77 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8062 (h : Needs) : Correct rule8062 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8062) (t := Root17.tgt) SEP77 ONES77 thinBasis9 TG77 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8064 (h : Needs) : Correct rule8064 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8064) (t := Root17.tgt) SEP82 ONES82 thinBasis10 TG82 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8067 (h : Needs) : Correct rule8067 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8067) (t := Root17.tgt) SEP82 ONES82 thinBasis9 TG82 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8069 (h : Needs) : Correct rule8069 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8069) (t := Root17.tgt) SEP83 ONES83 thinBasis10 TG83 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8071 (h : Needs) : Correct rule8071 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8071) (t := Root17.tgt) SEP83 ONES83 thinBasis9 TG83 (baseThin9 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8072 (h : Needs) : Correct rule8072 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8072) (t := Root17.tgt) SEP83 ONES83 thinBasis9 TG83 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8073 (h : Needs) : Correct rule8073 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8073) (t := Root17.tgt) SEP76 ONES76 thinBasis19 TG76 (baseThin19 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound8074 (h : Needs) : Correct rule8074 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8074) (t := Root17.tgt) SEP76 ONES76 thinBasis8 TG76 (baseThin8 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound8075 (h : Needs) : Correct rule8075 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8075) (t := Root17.tgt) SEP76 ONES76 thinBasis8 TG76 (baseThin8 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8081 (h : Needs) : Correct rule8081 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8081) (t := Root17.tgt) SEP76 ONES76 thinBasis8 TG76 (baseThin8 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8082 (h : Needs) : Correct rule8082 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8082) (t := Root17.tgt) SEP77 ONES77 thinBasis8 TG77 (baseThin8 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8083 (h : Needs) : Correct rule8083 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8083) (t := Root17.tgt) SEP77 ONES77 thinBasis8 TG77 (baseThin8 h) (by decide +kernel) [(false,(7,true),(4,true)),(false,(2,true),(4,true))] rfl (by decide +kernel)
theorem quickSound8087 (h : Needs) : Correct rule8087 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8087) (t := Root17.tgt) SEP77 ONES77 thinBasis8 TG77 (baseThin8 h) (by decide +kernel) [(false,(4,true),(1,true)),(false,(2,true),(4,true))] rfl (by decide +kernel)
theorem quickSound8088 (h : Needs) : Correct rule8088 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8088) (t := Root17.tgt) SEP77 ONES77 thinBasis8 TG77 (baseThin8 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8094 (h : Needs) : Correct rule8094 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8094) (t := Root17.tgt) SEP76 ONES76 thinBasis17 TG76 (baseThin17 h) (by decide +kernel) [(false,(0,true),(2,true)),(false,(7,true),(0,true))] rfl (by decide +kernel)
theorem quickSound8098 (h : Needs) : Correct rule8098 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8098) (t := Root17.tgt) SEP76 ONES76 thinBasis17 TG76 (baseThin17 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound8101 (h : Needs) : Correct rule8101 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8101) (t := Root17.tgt) SEP76 ONES76 thinBasis17 TG76 (baseThin17 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound8105 (h : Needs) : Correct rule8105 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8105) (t := Root17.tgt) SEP85 ONES85 thinBasis6 TG85 (baseThin6 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
