import EightReducedCX010Final
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem complete0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :: inputs 8) tgt 12 := PetersenLiveReduced.CX010.complete0_1_0
#print axioms complete0_1_0
end MC010Cert
