import HEX010G0
import HEX010G1
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r16 := EX010Cert.r16
abbrev stages16 := EX010Cert.stages16
theorem rowOk16 : PetersenWordProjection.check stages16 0 r16 = true := EX010Cert.rowOk16
theorem hot16 : forcedConst r16 tgt = false := EX010Cert.hot16
theorem match16 : PetersenPackedPin.project r16 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match16
abbrev r17 := EX010Cert.r17
abbrev stages17 := EX010Cert.stages17
theorem rowOk17 : PetersenWordProjection.check stages17 0 r17 = true := EX010Cert.rowOk17
theorem hot17 : forcedConst r17 tgt = false := EX010Cert.hot17
theorem match17 : PetersenPackedPin.project r17 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match17
abbrev r18 := EX010Cert.r18
abbrev stages18 := EX010Cert.stages18
theorem rowOk18 : PetersenWordProjection.check stages18 0 r18 = true := EX010Cert.rowOk18
theorem hot18 : forcedConst r18 tgt = false := EX010Cert.hot18
theorem match18 : PetersenPackedPin.project r18 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match18
abbrev r19 := EX010Cert.r19
abbrev stages19 := EX010Cert.stages19
theorem rowOk19 : PetersenWordProjection.check stages19 0 r19 = true := EX010Cert.rowOk19
theorem hot19 : forcedConst r19 tgt = false := EX010Cert.hot19
theorem match19 : PetersenPackedPin.project r19 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match19
abbrev r20 := EX010Cert.r20
abbrev stages20 := EX010Cert.stages20
theorem rowOk20 : PetersenWordProjection.check stages20 0 r20 = true := EX010Cert.rowOk20
theorem hot20 : forcedConst r20 tgt = false := EX010Cert.hot20
theorem match20 : PetersenPackedPin.project r20 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match20
abbrev r21 := EX010Cert.r21
abbrev stages21 := EX010Cert.stages21
theorem rowOk21 : PetersenWordProjection.check stages21 0 r21 = true := EX010Cert.rowOk21
theorem hot21 : forcedConst r21 tgt = false := EX010Cert.hot21
theorem match21 : PetersenPackedPin.project r21 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match21
abbrev r22 := EX010Cert.r22
abbrev stages22 := EX010Cert.stages22
theorem rowOk22 : PetersenWordProjection.check stages22 0 r22 = true := EX010Cert.rowOk22
theorem hot22 : forcedConst r22 tgt = false := EX010Cert.hot22
theorem match22 : PetersenPackedPin.project r22 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match22
abbrev r23 := EX010Cert.r23
abbrev stages23 := EX010Cert.stages23
theorem rowOk23 : PetersenWordProjection.check stages23 0 r23 = true := EX010Cert.rowOk23
theorem hot23 : forcedConst r23 tgt = false := EX010Cert.hot23
theorem match23 : PetersenPackedPin.project r23 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match23
def r24 (i : Fin 64) : Fin 256 := (#[0,1,16,17,64,65,80,81,2,3,18,19,66,67,82,83,32,33,48,49,96,97,112,113,34,35,50,51,98,99,114,115,128,129,144,145,192,193,208,209,130,131,146,147,194,195,210,211,160,161,176,177,224,225,240,241,162,163,178,179,226,227,242,243] : Array (Fin 256))[i.val]?.getD 0
def stages24 : List PetersenWordProjection.Stage := [⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x10,0xffff000000000000ffff000000000000ffff000000000000ffff0000,0xffff000000000000ffff000000000000ffff000000000000ffff00000000,0xffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffff⟩,⟨0x8,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff000000ff000000ff000000ff000000ff0000,0xff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩,⟨0xe,0xcccc0000cccc0000cccc0000cccc0000cccc0000cccc0000cccc0000cccc,0x3333000033330000333300003333000033330000333300003333000033330000,0xcccc3333cccc3333cccc3333cccc3333cccc3333cccc3333cccc3333cccc3333⟩]
theorem rowOk24 : PetersenWordProjection.check stages24 0 r24 = true := by decide +kernel
theorem hot24 : forcedConst r24 tgt = false := by decide +kernel
theorem match24 : PetersenPackedPin.project r24 tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
def r25 (i : Fin 64) : Fin 256 := (#[0,2,32,34,8,10,40,42,64,66,96,98,72,74,104,106,4,6,36,38,12,14,44,46,68,70,100,102,76,78,108,110,128,130,160,162,136,138,168,170,192,194,224,226,200,202,232,234,132,134,164,166,140,142,172,174,196,198,228,230,204,206,236,238] : Array (Fin 256))[i.val]?.getD 0
def stages25 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x60,0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000000000000000000000000000,0xffffffff00000000ffffffff0000000000000000ffffffff00000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0x4,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f0,0xf000f000f000f000f000f000f000f000f000f000f000f000f000f000f000f00,0xf00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00f⟩,⟨0x1e,0xcccccccc00000000cccccccc00000000cccccccc00000000cccccccc,0x3333333300000000333333330000000033333333000000003333333300000000,0xcccccccc33333333cccccccc33333333cccccccc33333333cccccccc33333333⟩,⟨0x1,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x9999999999999999999999999999999999999999999999999999999999999999⟩]
theorem rowOk25 : PetersenWordProjection.check stages25 0 r25 = true := by decide +kernel
theorem hot25 : forcedConst r25 tgt = false := by decide +kernel
theorem match25 : PetersenPackedPin.project r25 tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
abbrev r26 := EX010Cert.r26
abbrev stages26 := EX010Cert.stages26
theorem rowOk26 : PetersenWordProjection.check stages26 0 r26 = true := EX010Cert.rowOk26
theorem hot26 : forcedConst r26 tgt = false := EX010Cert.hot26
theorem match26 : PetersenPackedPin.project r26 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match26
abbrev r27 := EX010Cert.r27
abbrev stages27 := EX010Cert.stages27
theorem rowOk27 : PetersenWordProjection.check stages27 128 r27 = true := EX010Cert.rowOk27
theorem hot27 : forcedConst r27 tgt = false := EX010Cert.hot27
theorem match27 : PetersenPackedPin.project r27 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match27
end MC010Cert
