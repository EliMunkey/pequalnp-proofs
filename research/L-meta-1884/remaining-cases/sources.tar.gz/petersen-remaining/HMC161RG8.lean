import HEX010G8
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r380 := EX010Cert.r380
abbrev stages380 := EX010Cert.stages380
theorem rowOk380 : PetersenWordProjection.check stages380 32 r380 = true := EX010Cert.rowOk380
theorem hot380 : forcedConst r380 tgt = false := EX010Cert.hot380
theorem match380 : PetersenPackedPin.project r380 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match380
abbrev r383 := EX010Cert.r383
abbrev stages383 := EX010Cert.stages383
theorem rowOk383 : PetersenWordProjection.check stages383 64 r383 = true := EX010Cert.rowOk383
theorem hot383 : forcedConst r383 tgt = false := EX010Cert.hot383
theorem match383 : PetersenPackedPin.project r383 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match383
abbrev r391 := EX010Cert.r391
abbrev stages391 := EX010Cert.stages391
theorem rowOk391 : PetersenWordProjection.check stages391 0 r391 = true := EX010Cert.rowOk391
theorem hot391 : forcedConst r391 tgt = false := EX010Cert.hot391
theorem match391 : PetersenPackedPin.project r391 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match391
abbrev r397 := EX010Cert.r397
abbrev stages397 := EX010Cert.stages397
theorem rowOk397 : PetersenWordProjection.check stages397 128 r397 = true := EX010Cert.rowOk397
theorem hot397 : forcedConst r397 tgt = false := EX010Cert.hot397
theorem match397 : PetersenPackedPin.project r397 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match397
abbrev r404 := EX010Cert.r404
abbrev stages404 := EX010Cert.stages404
theorem rowOk404 : PetersenWordProjection.check stages404 32 r404 = true := EX010Cert.rowOk404
theorem hot404 : forcedConst r404 tgt = false := EX010Cert.hot404
theorem match404 : PetersenPackedPin.project r404 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match404
end MC161RCert
