import PetersenProjectedRule
import Full18FastBases
import Full18Data0
import Full18Data1
import Full18ThinView4
import Full18ThinView5
import Full18ThinView8
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound986 (h : Needs) : Correct rule986 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule986) (t := Root17.tgt) SEP86 ONES86 thinBasis5 TG86 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound991 (h : Needs) : Correct rule991 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule991) (t := Root17.tgt) SEP86 ONES86 thinBasis5 TG86 (baseThin5 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1005 (h : Needs) : Correct rule1005 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1005) (t := Root17.tgt) SEP86 ONES86 thinBasis5 TG86 (baseThin5 h) (by decide +kernel) [(false,(7,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1006 (h : Needs) : Correct rule1006 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1006) (t := Root17.tgt) SEP86 ONES86 thinBasis5 TG86 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound1047 (h : Needs) : Correct rule1047 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1047) (t := Root17.tgt) SEP108 ONES108 thinBasis5 TG108 (baseThin5 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1070 (h : Needs) : Correct rule1070 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1070) (t := Root17.tgt) SEP86 ONES86 thinBasis2 TG86 (baseThin2 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1140 (h : Needs) : Correct rule1140 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1140) (t := Root17.tgt) SEP167 ONES167 thinBasis5 TG167 (baseThin5 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1143 (h : Needs) : Correct rule1143 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1143) (t := Root17.tgt) SEP167 ONES167 thinBasis14 TG167 (baseThin14 h) (by decide +kernel) [(false,(3,true),(5,true)),(false,(9,true),(2,true))] rfl (by decide +kernel)
theorem quickSound1153 (h : Needs) : Correct rule1153 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1153) (t := Root17.tgt) SEP171 ONES171 thinBasis5 TG171 (baseThin5 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1160 (h : Needs) : Correct rule1160 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1160) (t := Root17.tgt) SEP167 ONES167 thinBasis1 TG167 (baseThin1 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1180 (h : Needs) : Correct rule1180 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1180) (t := Root17.tgt) SEP180 ONES180 thinBasis5 TG180 (baseThin5 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1199 (h : Needs) : Correct rule1199 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1199) (t := Root17.tgt) SEP167 ONES167 thinBasis2 TG167 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1247 (h : Needs) : Correct rule1247 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1247) (t := Root17.tgt) SEP179 ONES179 thinBasis2 TG179 (baseThin2 h) (by decide +kernel) [(false,(5,true),(4,true)),(false,(9,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1248 (h : Needs) : Correct rule1248 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1248) (t := Root17.tgt) SEP179 ONES179 thinBasis2 TG179 (baseThin2 h) (by decide +kernel) [(false,(5,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1256 (h : Needs) : Correct rule1256 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1256) (t := Root17.tgt) SEP180 ONES180 thinBasis7 TG180 (baseThin7 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1272 (h : Needs) : Correct rule1272 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1272) (t := Root17.tgt) SEP87 ONES87 thinBasis5 TG87 (baseThin5 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1295 (h : Needs) : Correct rule1295 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1295) (t := Root17.tgt) SEP87 ONES87 thinBasis5 TG87 (baseThin5 h) (by decide +kernel) [(false,(0,true),(8,true))] rfl (by decide +kernel)
theorem quickSound1317 (h : Needs) : Correct rule1317 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1317) (t := Root17.tgt) SEP87 ONES87 thinBasis5 TG87 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound1358 (h : Needs) : Correct rule1358 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1358) (t := Root17.tgt) SEP107 ONES107 thinBasis5 TG107 (baseThin5 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1379 (h : Needs) : Correct rule1379 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1379) (t := Root17.tgt) SEP92 ONES92 thinBasis7 TG92 (baseThin7 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1385 (h : Needs) : Correct rule1385 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1385) (t := Root17.tgt) SEP87 ONES87 thinBasis4 TG87 (baseThin4 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1401 (h : Needs) : Correct rule1401 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1401) (t := Root17.tgt) SEP107 ONES107 thinBasis2 TG107 (baseThin2 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1404 (h : Needs) : Correct rule1404 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1404) (t := Root17.tgt) SEP113 ONES113 thinBasis7 TG113 (baseThin7 h) (by decide +kernel) [(false,(4,true),(1,true))] rfl (by decide +kernel)
theorem quickSound1439 (h : Needs) : Correct rule1439 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1439) (t := Root17.tgt) SEP174 ONES174 thinBasis5 TG174 (baseThin5 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1443 (h : Needs) : Correct rule1443 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1443) (t := Root17.tgt) SEP174 ONES174 thinBasis14 TG174 (baseThin14 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1448 (h : Needs) : Correct rule1448 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1448) (t := Root17.tgt) SEP178 ONES178 thinBasis5 TG178 (baseThin5 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1451 (h : Needs) : Correct rule1451 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1451) (t := Root17.tgt) SEP178 ONES178 thinBasis14 TG178 (baseThin14 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1453 (h : Needs) : Correct rule1453 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1453) (t := Root17.tgt) SEP174 ONES174 thinBasis1 TG174 (baseThin1 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound1460 (h : Needs) : Correct rule1460 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1460) (t := Root17.tgt) SEP172 ONES172 thinBasis5 TG172 (baseThin5 h) (by decide +kernel) [(false,(5,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1463 (h : Needs) : Correct rule1463 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1463) (t := Root17.tgt) SEP172 ONES172 thinBasis14 TG172 (baseThin14 h) (by decide +kernel) [(false,(5,true),(4,true))] rfl (by decide +kernel)
theorem quickSound1470 (h : Needs) : Correct rule1470 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1470) (t := Root17.tgt) SEP164 ONES164 thinBasis5 TG164 (baseThin5 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
theorem quickSound1474 (h : Needs) : Correct rule1474 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule1474) (t := Root17.tgt) SEP164 ONES164 thinBasis14 TG164 (baseThin14 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
end Full18
