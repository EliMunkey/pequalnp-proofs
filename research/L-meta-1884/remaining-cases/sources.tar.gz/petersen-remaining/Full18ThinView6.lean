import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP120 : steps120.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES120 : PetersenWordProjection.projectFast steps120 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG120 : PetersenWordProjection.projectFast steps120 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP121 : steps121.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES121 : PetersenWordProjection.projectFast steps121 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG121 : PetersenWordProjection.projectFast steps121 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP122 : steps122.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES122 : PetersenWordProjection.projectFast steps122 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG122 : PetersenWordProjection.projectFast steps122 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP123 : steps123.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES123 : PetersenWordProjection.projectFast steps123 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG123 : PetersenWordProjection.projectFast steps123 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP126 : steps126.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES126 : PetersenWordProjection.projectFast steps126 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG126 : PetersenWordProjection.projectFast steps126 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP127 : steps127.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES127 : PetersenWordProjection.projectFast steps127 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG127 : PetersenWordProjection.projectFast steps127 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP128 : steps128.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES128 : PetersenWordProjection.projectFast steps128 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG128 : PetersenWordProjection.projectFast steps128 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP129 : steps129.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES129 : PetersenWordProjection.projectFast steps129 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG129 : PetersenWordProjection.projectFast steps129 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP130 : steps130.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES130 : PetersenWordProjection.projectFast steps130 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG130 : PetersenWordProjection.projectFast steps130 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP131 : steps131.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES131 : PetersenWordProjection.projectFast steps131 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG131 : PetersenWordProjection.projectFast steps131 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP132 : steps132.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES132 : PetersenWordProjection.projectFast steps132 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG132 : PetersenWordProjection.projectFast steps132 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP133 : steps133.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES133 : PetersenWordProjection.projectFast steps133 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG133 : PetersenWordProjection.projectFast steps133 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP134 : steps134.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES134 : PetersenWordProjection.projectFast steps134 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG134 : PetersenWordProjection.projectFast steps134 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP135 : steps135.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES135 : PetersenWordProjection.projectFast steps135 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG135 : PetersenWordProjection.projectFast steps135 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP136 : steps136.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES136 : PetersenWordProjection.projectFast steps136 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG136 : PetersenWordProjection.projectFast steps136 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP137 : steps137.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES137 : PetersenWordProjection.projectFast steps137 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG137 : PetersenWordProjection.projectFast steps137 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP138 : steps138.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES138 : PetersenWordProjection.projectFast steps138 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG138 : PetersenWordProjection.projectFast steps138 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
end Full18
