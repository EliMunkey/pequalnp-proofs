import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot98164
import PetersenProjectedRule
import Full18StepS4001
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient4001 (h : Needs) : Blocked Root17.tgt 14 live4001 := by
  apply stepS4001
  · change ∀ r ∈ [rule7443,rule3255,rule6590,rule8075,rule6082,rule6093,rule6725,rule6582,rule3997,rule5944,rule3254,rule3259,rule8051,rule3261,rule3064,rule3063,rule5579,rule6648,rule6054,rule6606,rule8053,rule6741,rule3205,rule4294,rule8058,rule5622,rule5625], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8075) (quickSound8075 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6082) (quickSound6082 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6093) (quickSound6093 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6725) (quickSound6725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6582) (quickSound6582 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3997) (quickSound3997 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3254) (quickSound3254 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3259) (quickSound3259 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5579) (quickSound5579 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6648) (quickSound6648 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6054) (quickSound6054 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6606) (quickSound6606 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8053) (quickSound8053 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6741) (quickSound6741 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3205) (quickSound3205 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4294) (quickSound4294 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8058) (quickSound8058 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5622) (quickSound5622 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5625) (quickSound5625 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live108846], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108846) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym2,thinSym0] (L := live108846) (V := live98164) (by decide +kernel) (quotient98164 h)) <|
      PetersenLocalChildren.nil
end Full18
