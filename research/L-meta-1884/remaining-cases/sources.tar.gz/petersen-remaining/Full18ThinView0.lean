import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP1 : steps1.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES1 : PetersenWordProjection.projectFast steps1 64 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG1 : PetersenWordProjection.projectFast steps1 64 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP2 : steps2.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES2 : PetersenWordProjection.projectFast steps2 64 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG2 : PetersenWordProjection.projectFast steps2 64 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP4 : steps4.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES4 : PetersenWordProjection.projectFast steps4 64 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG4 : PetersenWordProjection.projectFast steps4 64 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP5 : steps5.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES5 : PetersenWordProjection.projectFast steps5 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG5 : PetersenWordProjection.projectFast steps5 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP6 : steps6.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES6 : PetersenWordProjection.projectFast steps6 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG6 : PetersenWordProjection.projectFast steps6 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP7 : steps7.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES7 : PetersenWordProjection.projectFast steps7 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG7 : PetersenWordProjection.projectFast steps7 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP8 : steps8.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES8 : PetersenWordProjection.projectFast steps8 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG8 : PetersenWordProjection.projectFast steps8 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP9 : steps9.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES9 : PetersenWordProjection.projectFast steps9 256 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG9 : PetersenWordProjection.projectFast steps9 256 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP10 : steps10.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES10 : PetersenWordProjection.projectFast steps10 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG10 : PetersenWordProjection.projectFast steps10 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP11 : steps11.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES11 : PetersenWordProjection.projectFast steps11 128 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG11 : PetersenWordProjection.projectFast steps11 128 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP12 : steps12.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES12 : PetersenWordProjection.projectFast steps12 256 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG12 : PetersenWordProjection.projectFast steps12 256 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP13 : steps13.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES13 : PetersenWordProjection.projectFast steps13 512 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG13 : PetersenWordProjection.projectFast steps13 512 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP14 : steps14.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES14 : PetersenWordProjection.projectFast steps14 512 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 64)) := by decide +kernel
theorem TG14 : PetersenWordProjection.projectFast steps14 512 Root17.tgt = (0xfffffeccfaeafac0 : BitVec 64) := by decide +kernel
theorem SEP15 : steps15.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES15 : PetersenWordProjection.projectFast steps15 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG15 : PetersenWordProjection.projectFast steps15 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP16 : steps16.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES16 : PetersenWordProjection.projectFast steps16 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG16 : PetersenWordProjection.projectFast steps16 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP17 : steps17.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES17 : PetersenWordProjection.projectFast steps17 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG17 : PetersenWordProjection.projectFast steps17 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP18 : steps18.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES18 : PetersenWordProjection.projectFast steps18 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG18 : PetersenWordProjection.projectFast steps18 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
theorem SEP19 : steps19.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES19 : PetersenWordProjection.projectFast steps19 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 128)) := by decide +kernel
theorem TG19 : PetersenWordProjection.projectFast steps19 0 Root17.tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
end Full18
