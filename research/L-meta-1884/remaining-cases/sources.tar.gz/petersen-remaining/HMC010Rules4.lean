import Extra1020K12
import HMC010G7
import HMC010G8
import HMC010G9
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule221 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages221 s.steps 0 3 i4 p
theorem correct221 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule221 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r221 tgt) 3 := by rw [match221]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk221 s small hot221 p hit
def rule228 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages228 s.steps 64 4 i5 p
theorem correct228 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule228 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r228 tgt) 4 := by rw [match228]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk228 s small hot228 p hit
def rule236 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages236 s.steps 0 4 i5 p
theorem correct236 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule236 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r236 tgt) 4 := by rw [match236]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk236 s small hot236 p hit
def rule242 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages242 s.steps 64 4 i5 p
theorem correct242 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule242 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r242 tgt) 4 := by rw [match242]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk242 s small hot242 p hit
def rule246 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages246 s.steps 0 3 i4 p
theorem correct246 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule246 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r246 tgt) 3 := by rw [match246]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk246 s small hot246 p hit
def rule255 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages255 s.steps 32 4 i5 p
theorem correct255 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule255 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r255 tgt) 4 := by rw [match255]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk255 s small hot255 p hit
def rule257 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages257 s.steps 64 4 i5 p
theorem correct257 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule257 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r257 tgt) 4 := by rw [match257]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk257 s small hot257 p hit
def rule260 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages260 s.steps 0 3 i4 p
theorem correct260 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule260 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r260 tgt) 3 := by rw [match260]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk260 s small hot260 p hit
def rule268 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages268 s.steps 0 3 i4 p
theorem correct268 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule268 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r268 tgt) 3 := by rw [match268]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk268 s small hot268 p hit
def rule274 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages274 s.steps 128 4 i5 p
theorem correct274 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule274 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r274 tgt) 4 := by rw [match274]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk274 s small hot274 p hit
def rule288 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages288 s.steps 128 4 i5 p
theorem correct288 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule288 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r288 tgt) 4 := by rw [match288]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk288 s small hot288 p hit
def rule292 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages292 s.steps 0 3 i4 p
theorem correct292 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule292 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r292 tgt) 3 := by rw [match292]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk292 s small hot292 p hit
def rule319 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages319 s.steps 0 4 i5 p
theorem correct319 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule319 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r319 tgt) 4 := by rw [match319]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk319 s small hot319 p hit
def rule324 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages324 s.steps 0 4 i5 p
theorem correct324 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule324 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r324 tgt) 4 := by rw [match324]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk324 s small hot324 p hit
def rule334 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages334 s.steps 0 3 i4 p
theorem correct334 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule334 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r334 tgt) 3 := by rw [match334]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk334 s small hot334 p hit
def rule343 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages343 s.steps 64 4 i5 p
theorem correct343 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule343 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r343 tgt) 4 := by rw [match343]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk343 s small hot343 p hit
def rule346 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages346 s.steps 128 4 i5 p
theorem correct346 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule346 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r346 tgt) 4 := by rw [match346]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk346 s small hot346 p hit
def rule347 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages347 s.steps 64 4 i5 p
theorem correct347 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule347 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r347 tgt) 4 := by rw [match347]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk347 s small hot347 p hit
def rule348 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages348 s.steps 32 4 i5 p
theorem correct348 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule348 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r348 tgt) 4 := by rw [match348]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk348 s small hot348 p hit
def rule354 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages354 s.steps 128 4 i5 p
theorem correct354 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule354 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r354 tgt) 4 := by rw [match354]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk354 s small hot354 p hit
end MC010Cert
