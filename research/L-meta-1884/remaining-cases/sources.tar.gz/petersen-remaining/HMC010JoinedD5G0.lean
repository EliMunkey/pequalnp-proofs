import HMC010Hyp
import HMC010Rules1
import HMC010Sym
import HMC010W0
import HMC010W1
import HMC010W2
import HMC010W3
import PetersenSymmetry
import first8.MixedNode
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 150000
set_option maxHeartbeats 0
set_option linter.concreteInstances false

def s5_96 : List (BitVec 256) := [w287,w517,w644,w698,w778,w821,w880,w977]
private def c5_96 : Array (PetersenProjectedRule.Rule 256) := #[rule61 route0 []]
private def m5_96 : Array (List (BitVec 256)) := #[]
private def hs5_96 : List (List Nat) := [[516,9254,516,9254],[2583,16469,2567,2567],[8233,9255,8233,9255],[2601,24689,2601,16465],[260,3079,260,3079],[81,1109,81,2121],[145,1157,145,1157],[516,9254,2583,516],[516,2564,524,516],[516,8196,546,516],[3079,260,4,4],[81,337,81,82],[145,401,145,146],[8233,2583,535,535],[2583,0,2601,2583],[260,2583,260,2071],[81,3145,81,85],[145,1157,145,149],[9223,2601,553,553],[260,2308,260,268],[81,2129,81,89],[145,2193,145,153],[260,290],[81,8305,81,625],[145,8369,145,689],[81,593,81,260],[145,657,145,260],[81,17541,145,81]]
theorem node5_96 [Assumptions] : Blocked tgt 7 s5_96 := by
  refine PetersenMixedNode.close (cut := c5_96) (more := m5_96) (hs := hs5_96) (by decide +kernel) (by decide +kernel) ?_ ?_
  ·
    exact PetersenLocalChildren.push (P := (fun r => PetersenProjectedRule.Correct r tgt)) (x := rule61 route0 []) (correct61 route0 []) <|
      PetersenLocalChildren.nil
  ·
    exact PetersenLocalChildren.nil
end MC010Cert
