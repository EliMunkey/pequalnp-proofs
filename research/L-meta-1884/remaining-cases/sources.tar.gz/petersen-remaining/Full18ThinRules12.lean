import PetersenProjectedRule
import Full18FastBases
import Full18Data6
import Full18ThinView1
import Full18ThinView2
import Full18ThinView3
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound6093 (h : Needs) : Correct rule6093 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6093) (t := Root17.tgt) SEP21 ONES21 thinBasis20 TG21 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6094 (h : Needs) : Correct rule6094 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6094) (t := Root17.tgt) SEP79 ONES79 thinBasis20 TG79 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6104 (h : Needs) : Correct rule6104 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6104) (t := Root17.tgt) SEP22 ONES22 thinBasis10 TG22 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6105 (h : Needs) : Correct rule6105 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6105) (t := Root17.tgt) SEP68 ONES68 thinBasis9 TG68 (baseThin9 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound6108 (h : Needs) : Correct rule6108 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6108) (t := Root17.tgt) SEP22 ONES22 thinBasis8 TG22 (baseThin8 h) (by decide +kernel) [(false,(1,true),(4,true)),(false,(7,true),(4,true))] rfl (by decide +kernel)
theorem quickSound6109 (h : Needs) : Correct rule6109 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6109) (t := Root17.tgt) SEP22 ONES22 thinBasis8 TG22 (baseThin8 h) (by decide +kernel) [(false,(1,true),(4,true))] rfl (by decide +kernel)
theorem quickSound6557 (h : Needs) : Correct rule6557 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6557) (t := Root17.tgt) SEP183 ONES183 thinBasis21 TG183 (baseThin21 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6568 (h : Needs) : Correct rule6568 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6568) (t := Root17.tgt) SEP23 ONES23 thinBasis15 TG23 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6575 (h : Needs) : Correct rule6575 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6575) (t := Root17.tgt) SEP73 ONES73 thinBasis15 TG73 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6579 (h : Needs) : Correct rule6579 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6579) (t := Root17.tgt) SEP23 ONES23 thinBasis11 TG23 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6581 (h : Needs) : Correct rule6581 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6581) (t := Root17.tgt) SEP23 ONES23 thinBasis20 TG23 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6582 (h : Needs) : Correct rule6582 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6582) (t := Root17.tgt) SEP23 ONES23 thinBasis10 TG23 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6584 (h : Needs) : Correct rule6584 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6584) (t := Root17.tgt) SEP23 ONES23 thinBasis9 TG23 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6590 (h : Needs) : Correct rule6590 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6590) (t := Root17.tgt) SEP24 ONES24 thinBasis10 TG24 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6592 (h : Needs) : Correct rule6592 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6592) (t := Root17.tgt) SEP24 ONES24 thinBasis9 TG24 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6595 (h : Needs) : Correct rule6595 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6595) (t := Root17.tgt) SEP73 ONES73 thinBasis20 TG73 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6606 (h : Needs) : Correct rule6606 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6606) (t := Root17.tgt) SEP47 ONES47 thinBasis10 TG47 (baseThin10 h) (by decide +kernel) [(false,(2,true),(7,true))] rfl (by decide +kernel)
theorem quickSound6610 (h : Needs) : Correct rule6610 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6610) (t := Root17.tgt) SEP55 ONES55 thinBasis10 TG55 (baseThin10 h) (by decide +kernel) [(false,(2,true),(7,true))] rfl (by decide +kernel)
theorem quickSound6615 (h : Needs) : Correct rule6615 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6615) (t := Root17.tgt) SEP25 ONES25 thinBasis10 TG25 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6616 (h : Needs) : Correct rule6616 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6616) (t := Root17.tgt) SEP40 ONES40 thinBasis10 TG40 (baseThin10 h) (by decide +kernel) [(false,(7,true),(2,true))] rfl (by decide +kernel)
theorem quickSound6626 (h : Needs) : Correct rule6626 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6626) (t := Root17.tgt) SEP26 ONES26 thinBasis10 TG26 (baseThin10 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound6628 (h : Needs) : Correct rule6628 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6628) (t := Root17.tgt) SEP66 ONES66 thinBasis10 TG66 (baseThin10 h) (by decide +kernel) [(false,(7,true),(2,true))] rfl (by decide +kernel)
theorem quickSound6637 (h : Needs) : Correct rule6637 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6637) (t := Root17.tgt) SEP28 ONES28 thinBasis10 TG28 (baseThin10 h) (by decide +kernel) [(false,(0,true),(3,true))] rfl (by decide +kernel)
theorem quickSound6639 (h : Needs) : Correct rule6639 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6639) (t := Root17.tgt) SEP28 ONES28 thinBasis10 TG28 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6647 (h : Needs) : Correct rule6647 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6647) (t := Root17.tgt) SEP28 ONES28 thinBasis8 TG28 (baseThin8 h) (by decide +kernel) [(false,(5,true),(6,true)),(false,(8,true),(5,true))] rfl (by decide +kernel)
theorem quickSound6648 (h : Needs) : Correct rule6648 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6648) (t := Root17.tgt) SEP28 ONES28 thinBasis8 TG28 (baseThin8 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound6653 (h : Needs) : Correct rule6653 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6653) (t := Root17.tgt) SEP29 ONES29 thinBasis15 TG29 (baseThin15 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound6655 (h : Needs) : Correct rule6655 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6655) (t := Root17.tgt) SEP29 ONES29 thinBasis10 TG29 (baseThin10 h) (by decide +kernel) [(false,(5,true),(6,true))] rfl (by decide +kernel)
theorem quickSound6656 (h : Needs) : Correct rule6656 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6656) (t := Root17.tgt) SEP29 ONES29 thinBasis10 TG29 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound6662 (h : Needs) : Correct rule6662 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6662) (t := Root17.tgt) SEP29 ONES29 thinBasis8 TG29 (baseThin8 h) (by decide +kernel) [(false,(5,true),(6,true)),(false,(5,true),(8,true))] rfl (by decide +kernel)
theorem quickSound6664 (h : Needs) : Correct rule6664 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6664) (t := Root17.tgt) SEP30 ONES30 thinBasis8 TG30 (baseThin8 h) (by decide +kernel) [(false,(6,true),(5,true)),(false,(2,true),(4,true))] rfl (by decide +kernel)
theorem quickSound6673 (h : Needs) : Correct rule6673 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule6673) (t := Root17.tgt) SEP32 ONES32 thinBasis15 TG32 (baseThin15 h) (by decide +kernel) [(false,(5,true),(3,true))] rfl (by decide +kernel)
end Full18
