import HMC010Hyp
import HMC010ThetaRoutes
import HMC010Holds0
import HMC010Holds1
import HMC010Holds2
import HMC010Holds3
import HMC010Holds4
import HMC010Holds5
import HMC010Holds6
import HMC010Holds7
import HMC010Holds8
import HMC010Holds9
import HMC010LowerPack0
import HMC010LowerPack1
import HMC010LowerPack2
import HMC010LowerPack3
import HMC010LowerPack4
import HMC010LowerPack5
import HMC010LowerPack6
import HMC010LowerPack7
import HMC010LowerPack8
import HMC010LowerPack9
import HMC010LowerPack10
import HMC010Holds69
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
instance proven : Assumptions where
  h0 := by rw [rawInput5_eq]; exact hold0_0
  h1 := by rw [rawInput5_eq]; exact hold1_0
  h2 := by rw [rawInput5_eq]; exact hold2_0
  h3 := by rw [rawInput5_eq]; exact hold3_0
  h4 := by rw [rawInput5_eq]; exact hold4_0
  h5 := by rw [rawInput5_eq]; exact hold5_0
  h6 := by rw [rawInput5_eq]; exact hold6_0
  h7 := by rw [rawInput5_eq]; exact hold7_0
  h8 := by rw [rawInput5_eq]; exact hold8_0
  h9 := by rw [rawInput5_eq]; exact hold9_0
  h10 := by rw [rawInput5_eq]; exact hold10_0
  h11 := by rw [rawInput5_eq]; exact hold11_0
  h12 := by rw [rawInput5_eq]; exact hold12_0
  h13 := by rw [rawInput5_eq]; exact hold13_0
  h14 := by rw [rawInput5_eq]; exact hold14_0
  h15 := by rw [rawInput5_eq]; exact hold15_0
  h16 := by rw [rawInput5_eq]; exact hold16_0
  h17 := by rw [rawInput5_eq]; exact hold17_0
  h18 := by rw [rawInput5_eq]; exact hold18_0
  h19 := by rw [rawInput5_eq]; exact hold19_0
  h20 := by rw [rawInput5_eq]; exact hold20_0
  h21 := by rw [rawInput5_eq]; exact hold21_0
  h22 := by rw [rawInput5_eq]; exact hold22_0
  h23 := by rw [rawInput5_eq]; exact hold23_0
  h24 := by rw [rawInput5_eq]; exact hold24_0
  h25 := by rw [rawInput5_eq]; exact hold25_0
  h26 := by rw [rawInput5_eq]; exact hold26_1
  h27 := by rw [rawInput5_eq]; exact hold27_1
  h28 := by rw [rawInput5_eq]; exact hold28_1
  h29 := by rw [rawInput5_eq]; exact hold29_1
  h30 := by rw [rawInput6_eq]; exact hold30_0
  h31 := by rw [rawInput6_eq]; exact hold31_0
  h32 := by rw [rawInput6_eq]; exact hold32_0
  h33 := by rw [rawInput6_eq]; exact hold33_0
  h34 := by rw [rawInput6_eq]; exact hold34_0
  h35 := by rw [rawInput6_eq]; exact hold35_0
  h36 := by rw [rawInput6_eq]; exact hold36_0
  h37 := by rw [rawInput6_eq]; exact hold37_0
  h38 := by rw [rawInput6_eq]; exact hold38_1
  h39 := by rw [rawInput6_eq]; exact hold39_1
  h40 := by rw [rawInput6_eq]; exact hold40_2
  h41 := by rw [rawInput6_eq]; exact hold41_2
  h42 := by rw [rawInput6_eq]; exact hold42_2
  h43 := by rw [rawInput6_eq]; exact hold43_2
  h44 := by rw [rawInput7_eq]; exact hold44_0
  h45 := by rw [rawInput7_eq]; exact hold45_0
  h46 := by rw [rawInput7_eq]; exact hold46_0
  h47 := by rw [rawInput7_eq]; exact hold47_0
  h48 := by rw [rawInput7_eq]; exact hold48_0
  h49 := by rw [rawInput7_eq]; exact hold49_0
  h50 := by rw [rawInput7_eq]; exact hold50_0
  h51 := by rw [rawInput7_eq]; exact hold51_0
  h52 := by rw [rawInput7_eq]; exact hold52_0
  h53 := by rw [rawInput7_eq]; exact hold53_0
  h54 := by rw [rawInput7_eq]; exact hold54_0
  h55 := by rw [rawInput7_eq]; exact hold55_0
  h56 := by rw [rawInput7_eq]; exact hold56_0
  h57 := by rw [rawInput7_eq]; exact hold57_0
  h58 := by rw [rawInput7_eq]; exact hold58_0
  h59 := by rw [rawInput7_eq]; exact hold59_0
  h60 := by rw [rawInput7_eq]; exact hold60_0
  h61 := by rw [rawInput7_eq]; exact hold61_0
  h62 := by rw [rawInput7_eq]; exact hold62_0
  h63 := by rw [rawInput7_eq]; exact hold63_0
  h64 := by rw [rawInput7_eq]; exact hold64_0
  h65 := by rw [rawInput7_eq]; exact hold65_0
  h66 := by rw [rawInput7_eq]; exact hold66_0
  h67 := by rw [rawInput7_eq]; exact hold67_0
  h68 := by rw [rawInput7_eq]; exact hold68_0
  h69 := by rw [rawInput7_eq]; exact hold69_3
end MC010Cert
