import HEX010G3
import HEX010G4
import HMC010PinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
abbrev r69 := EX010Cert.r69
abbrev stages69 := EX010Cert.stages69
theorem rowOk69 : PetersenWordProjection.check stages69 0 r69 = true := EX010Cert.rowOk69
theorem hot69 : forcedConst r69 tgt = false := EX010Cert.hot69
theorem match69 : PetersenPackedPin.project r69 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match69
def r73 (i : Fin 64) : Fin 256 := (#[0,32,128,160,4,36,132,164,1,33,129,161,5,37,133,165,8,40,136,168,12,44,140,172,9,41,137,169,13,45,141,173,16,48,144,176,20,52,148,180,17,49,145,177,21,53,149,181,24,56,152,184,28,60,156,188,25,57,153,185,29,61,157,189] : Array (Fin 256))[i.val]?.getD 0
def stages73 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x10,0xffff000000000000ffff000000000000ffff000000000000ffff0000,0xffff000000000000ffff000000000000ffff000000000000ffff00000000,0xffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffff⟩,⟨0x18,0xff00ff0000000000ff00ff0000000000ff00ff0000000000ff00ff00,0xff00ff0000000000ff00ff0000000000ff00ff0000000000ff00ff00000000,0xff00ff0000ff00ffff00ff0000ff00ffff00ff0000ff00ffff00ff0000ff00ff⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x1f,0xaaaaaaaa00000000aaaaaaaa00000000aaaaaaaa00000000aaaaaaaa,0x5555555500000000555555550000000055555555000000005555555500000000,0xaaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555⟩]
theorem rowOk73 : PetersenWordProjection.check stages73 0 r73 = true := by decide +kernel
theorem hot73 : forcedConst r73 tgt = false := by decide +kernel
theorem match73 : PetersenPackedPin.project r73 tgt = (0xeeeeeecceaeaeac8 : BitVec 64) := by decide +kernel
abbrev r74 := EX010Cert.r74
abbrev stages74 := EX010Cert.stages74
theorem rowOk74 : PetersenWordProjection.check stages74 128 r74 = true := EX010Cert.rowOk74
theorem hot74 : forcedConst r74 tgt = false := EX010Cert.hot74
theorem match74 : PetersenPackedPin.project r74 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match74
abbrev r75 := EX010Cert.r75
abbrev stages75 := EX010Cert.stages75
theorem rowOk75 : PetersenWordProjection.check stages75 64 r75 = true := EX010Cert.rowOk75
theorem hot75 : forcedConst r75 tgt = false := EX010Cert.hot75
theorem match75 : PetersenPackedPin.project r75 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match75
abbrev r76 := EX010Cert.r76
abbrev stages76 := EX010Cert.stages76
theorem rowOk76 : PetersenWordProjection.check stages76 0 r76 = true := EX010Cert.rowOk76
theorem hot76 : forcedConst r76 tgt = false := EX010Cert.hot76
theorem match76 : PetersenPackedPin.project r76 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match76
abbrev r83 := EX010Cert.r83
abbrev stages83 := EX010Cert.stages83
theorem rowOk83 : PetersenWordProjection.check stages83 128 r83 = true := EX010Cert.rowOk83
theorem hot83 : forcedConst r83 tgt = false := EX010Cert.hot83
theorem match83 : PetersenPackedPin.project r83 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match83
abbrev r84 := EX010Cert.r84
abbrev stages84 := EX010Cert.stages84
theorem rowOk84 : PetersenWordProjection.check stages84 64 r84 = true := EX010Cert.rowOk84
theorem hot84 : forcedConst r84 tgt = false := EX010Cert.hot84
theorem match84 : PetersenPackedPin.project r84 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match84
abbrev r92 := EX010Cert.r92
abbrev stages92 := EX010Cert.stages92
theorem rowOk92 : PetersenWordProjection.check stages92 128 r92 = true := EX010Cert.rowOk92
theorem hot92 : forcedConst r92 tgt = false := EX010Cert.hot92
theorem match92 : PetersenPackedPin.project r92 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match92
abbrev r93 := EX010Cert.r93
abbrev stages93 := EX010Cert.stages93
theorem rowOk93 : PetersenWordProjection.check stages93 64 r93 = true := EX010Cert.rowOk93
theorem hot93 : forcedConst r93 tgt = false := EX010Cert.hot93
theorem match93 : PetersenPackedPin.project r93 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match93
abbrev r94 := EX010Cert.r94
abbrev stages94 := EX010Cert.stages94
theorem rowOk94 : PetersenWordProjection.check stages94 128 r94 = true := EX010Cert.rowOk94
theorem hot94 : forcedConst r94 tgt = false := EX010Cert.hot94
theorem match94 : PetersenPackedPin.project r94 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match94
abbrev r95 := EX010Cert.r95
abbrev stages95 := EX010Cert.stages95
theorem rowOk95 : PetersenWordProjection.check stages95 64 r95 = true := EX010Cert.rowOk95
theorem hot95 : forcedConst r95 tgt = false := EX010Cert.hot95
theorem match95 : PetersenPackedPin.project r95 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match95
abbrev r97 := EX010Cert.r97
abbrev stages97 := EX010Cert.stages97
theorem rowOk97 : PetersenWordProjection.check stages97 128 r97 = true := EX010Cert.rowOk97
theorem hot97 : forcedConst r97 tgt = false := EX010Cert.hot97
theorem match97 : PetersenPackedPin.project r97 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match97
end MC010Cert
