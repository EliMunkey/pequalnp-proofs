import Extra1020K12
import HMC010G4
import HMC010G5
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule76 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages76 s.steps 0 4 i5 p
theorem correct76 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule76 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r76 tgt) 4 := by rw [match76]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk76 s small hot76 p hit
def rule83 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages83 s.steps 128 5 i6 p
theorem correct83 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule83 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r83 tgt) 5 := by rw [match83]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk83 s small hot83 p hit
def rule84 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages84 s.steps 64 5 i6 p
theorem correct84 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule84 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r84 tgt) 5 := by rw [match84]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk84 s small hot84 p hit
def rule92 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages92 s.steps 128 5 i6 p
theorem correct92 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule92 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r92 tgt) 5 := by rw [match92]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk92 s small hot92 p hit
def rule93 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages93 s.steps 64 5 i6 p
theorem correct93 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule93 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r93 tgt) 5 := by rw [match93]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk93 s small hot93 p hit
def rule94 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages94 s.steps 128 5 i6 p
theorem correct94 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule94 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r94 tgt) 5 := by rw [match94]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk94 s small hot94 p hit
def rule95 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages95 s.steps 64 5 i6 p
theorem correct95 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule95 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r95 tgt) 5 := by rw [match95]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk95 s small hot95 p hit
def rule97 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages97 s.steps 128 5 i6 p
theorem correct97 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule97 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r97 tgt) 5 := by rw [match97]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk97 s small hot97 p hit
def rule98 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages98 s.steps 64 5 i6 p
theorem correct98 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule98 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r98 tgt) 5 := by rw [match98]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk98 s small hot98 p hit
def rule99 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages99 s.steps 128 5 i6 p
theorem correct99 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule99 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r99 tgt) 5 := by rw [match99]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk99 s small hot99 p hit
def rule100 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages100 s.steps 64 5 i6 p
theorem correct100 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule100 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r100 tgt) 5 := by rw [match100]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk100 s small hot100 p hit
def rule107 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages107 s.steps 128 5 i6 p
theorem correct107 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule107 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r107 tgt) 5 := by rw [match107]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk107 s small hot107 p hit
def rule108 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages108 s.steps 64 5 i6 p
theorem correct108 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule108 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r108 tgt) 5 := by rw [match108]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk108 s small hot108 p hit
def rule109 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages109 s.steps 128 5 i6 p
theorem correct109 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule109 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r109 tgt) 5 := by rw [match109]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk109 s small hot109 p hit
def rule110 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages110 s.steps 64 5 i6 p
theorem correct110 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule110 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r110 tgt) 5 := by rw [match110]; exact Extra1020K12.b47_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk110 s small hot110 p hit
def rule111 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages111 s.steps 0 4 i5 p
theorem correct111 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule111 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r111 tgt) 4 := by rw [match111]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk111 s small hot111 p hit
def rule115 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages115 s.steps 0 5 i6 p
theorem correct115 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule115 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r115 tgt) 5 := by rw [match115]; exact Extra1020K12.b119_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk115 s small hot115 p hit
def rule116 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages116 s.steps 128 5 i6 p
theorem correct116 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule116 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r116 tgt) 5 := by rw [match116]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk116 s small hot116 p hit
def rule117 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages117 s.steps 64 5 i6 p
theorem correct117 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule117 s p) tgt := by
  have small : NoAtMost i6 (PetersenPackedPin.project r117 tgt) 5 := by rw [match117]; exact Extra1020K12.b15_2
  intro d L hit
  exact PetersenRoutedPin.quick rowOk117 s small hot117 p hit
def rule118 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages118 s.steps 0 4 i5 p
theorem correct118 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule118 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r118 tgt) 4 := by rw [match118]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk118 s small hot118 p hit
end MC010Cert
