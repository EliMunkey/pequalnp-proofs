import Full18ThinRules0
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules6
import Full18ThinRules14
import Full18Quot168479
import PetersenProjectedRule
import Full18StepS97875
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient97875 (h : Needs) : Blocked Root17.tgt 13 live97875 := by
  apply stepS97875
  · change ∀ r ∈ [rule3251,rule991,rule3073,rule3070,rule3052,rule1358,rule3255,rule2560,rule3057,rule1272,rule2556,rule1385,rule7507,rule3064,rule7515,rule4061,rule4071,rule7510,rule4269,rule1460,rule1463,rule1160], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule991) (quickSound991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1358) (quickSound1358 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2560) (quickSound2560 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3057) (quickSound3057 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1272) (quickSound1272 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2556) (quickSound2556 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1385) (quickSound1385 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7507) (quickSound7507 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7515) (quickSound7515 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4061) (quickSound4061 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4071) (quickSound4071 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7510) (quickSound7510 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4269) (quickSound4269 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1460) (quickSound1460 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1463) (quickSound1463 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1160) (quickSound1160 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live168479], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live168479) (quotient168479 h) <|
      PetersenLocalChildren.nil
end Full18
