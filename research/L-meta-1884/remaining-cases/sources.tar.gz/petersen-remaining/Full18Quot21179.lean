import Full18ThinRules0
import Full18ThinRules3
import Full18ThinRules5
import Full18ThinRules7
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot41826
import Full18Quot105746
import PetersenProjectedRule
import Full18StepS21179
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient21179 (h : Needs) : Blocked Root17.tgt 14 live21179 := by
  apply stepS21179
  · change ∀ r ∈ [rule3052,rule3073,rule8051,rule8030,rule3063,rule3255,rule5005,rule986,rule7531,rule6626,rule6637,rule8022,rule5845,rule7517,rule7443,rule5944,rule4997,rule8033,rule3858,rule6639], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8030) (quickSound8030 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5005) (quickSound5005 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule986) (quickSound986 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7531) (quickSound7531 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6626) (quickSound6626 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6637) (quickSound6637 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5845) (quickSound5845 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7517) (quickSound7517 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7443) (quickSound7443 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4997) (quickSound4997 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8033) (quickSound8033 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3858) (quickSound3858 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6639) (quickSound6639 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live78399,live108385], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live78399) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live78399) (V := live41826) (by decide +kernel) (quotient41826 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live108385) (PetersenFastSymmetry.move [thinSym0,thinSym2] (L := live108385) (V := live105746) (by decide +kernel) (quotient105746 h)) <|
      PetersenLocalChildren.nil
end Full18
