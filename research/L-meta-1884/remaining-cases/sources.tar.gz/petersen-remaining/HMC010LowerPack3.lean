import HMC010Hyp
import HMC010ThetaRoutes
import M191StartPreferredCheckedF0X3Z1
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold46_0 : NoAtMost (0xaaaaaaaaaaaaaaaa :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows0 thetaInputs0 thetaTarget0 (g:=0xaaaaaaaaaaaaaaaa) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_1

theorem hold49_0 : NoAtMost (0xf0f0f0f000000000f0f0f0f0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows1 thetaInputs1 thetaTarget1 (g:=0xf0f0f0f000000000f0f0f0f0) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_1

theorem hold51_0 : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0xf0f00000f0f00000f0f00000f0f0) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_1

theorem hold52_0 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xaa00aa00aa00aa00aa00aa00aa00aa) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_1
end MC010Cert
