import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules9
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules15
import Full18ThinSym3
import Full18Quot168022
import PetersenProjectedRule
import Full18StepS97318
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient97318 (h : Needs) : Blocked Root17.tgt 13 live97318 := by
  apply stepS97318
  · change ∀ r ∈ [rule3066,rule6590,rule6084,rule3070,rule3255,rule5583,rule3258,rule6582,rule6584,rule3911,rule6579,rule6074,rule5683,rule2564,rule8087,rule5725,rule5688,rule3064,rule3073,rule6595,rule5944], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3066) (quickSound3066 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6590) (quickSound6590 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6084) (quickSound6084 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5583) (quickSound5583 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3258) (quickSound3258 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6582) (quickSound6582 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6584) (quickSound6584 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3911) (quickSound3911 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6579) (quickSound6579 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6074) (quickSound6074 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5683) (quickSound5683 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2564) (quickSound2564 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8087) (quickSound8087 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5725) (quickSound5725 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5688) (quickSound5688 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6595) (quickSound6595 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live168379], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live168379) (PetersenFastSymmetry.move [thinSym3] (L := live168379) (V := live168022) (by decide +kernel) (quotient168022 h)) <|
      PetersenLocalChildren.nil
end Full18
