import HMC010Hyp
import M111StartLabeled
import M15StartLabeled
import M31StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold22_0 : NoAtMost (0xfcfcfcfc :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xfcfcfcfc (by decide +kernel)

theorem hold23_0 : NoAtMost (0xfff0fff0 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xfff0fff0 (by decide +kernel)

theorem hold24_0 : NoAtMost (0xffffaaaa :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xffffaaaa (by decide +kernel)

theorem hold25_0 : NoAtMost (0xffffff00 :: inputs 5) 0xffeaf8c8 6 := by
  exact PetersenSmallStarts.M31.all_forbidden 0xffffff00 (by decide +kernel)

theorem hold26_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold26_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold26_0 <;> decide +kernel

theorem hold27_0 : NoAtMost (0xa0a :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xa0a (by decide +kernel)
theorem hold27_1 : NoAtMost (0xa0a0a0a :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold27_0 <;> decide +kernel

theorem hold28_0 : NoAtMost (0x3300 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hold28_1 : NoAtMost (0x33003300 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold28_0 <;> decide +kernel

theorem hold29_0 : NoAtMost (0x4444 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hold29_1 : NoAtMost (0x44444444 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold29_0 <;> decide +kernel

theorem hold30_0 : NoAtMost (0xcccccccc :: inputs 6) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenSmallStarts.M111.all_forbidden 0xcccccccc (by decide +kernel)

theorem hold31_0 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenSmallStarts.M111.all_forbidden 0xf000f000f000f0 (by decide +kernel)

theorem hold32_0 : NoAtMost (0xf0f0f0f00000000 :: inputs 6) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenSmallStarts.M111.all_forbidden 0xf0f0f0f00000000 (by decide +kernel)

theorem hold33_0 : NoAtMost (0xeeeeeeeeeeeeeeee :: inputs 6) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenSmallStarts.M111.all_forbidden 0xeeeeeeeeeeeeeeee (by decide +kernel)
end MC010Cert
