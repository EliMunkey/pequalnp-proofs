import Extra1020K12
import HMC010G10
import HMC010G2
import HMC010G9
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule358 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages358 s.steps 0 3 i4 p
theorem correct358 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule358 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r358 tgt) 3 := by rw [match358]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk358 s small hot358 p hit
def rule366 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages366 s.steps 32 4 i5 p
theorem correct366 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule366 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r366 tgt) 4 := by rw [match366]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk366 s small hot366 p hit
def rule368 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages368 s.steps 128 4 i5 p
theorem correct368 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule368 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r368 tgt) 4 := by rw [match368]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk368 s small hot368 p hit
def rule369 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages369 s.steps 64 4 i5 p
theorem correct369 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule369 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r369 tgt) 4 := by rw [match369]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk369 s small hot369 p hit
def rule370 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages370 s.steps 32 4 i5 p
theorem correct370 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule370 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r370 tgt) 4 := by rw [match370]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk370 s small hot370 p hit
def rule374 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages374 s.steps 64 4 i5 p
theorem correct374 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule374 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r374 tgt) 4 := by rw [match374]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk374 s small hot374 p hit
def rule380 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages380 s.steps 32 4 i5 p
theorem correct380 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule380 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r380 tgt) 4 := by rw [match380]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk380 s small hot380 p hit
def rule383 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages383 s.steps 64 4 i5 p
theorem correct383 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule383 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r383 tgt) 4 := by rw [match383]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk383 s small hot383 p hit
def rule386 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages386 s.steps 0 3 i4 p
theorem correct386 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule386 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r386 tgt) 3 := by rw [match386]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk386 s small hot386 p hit
def rule391 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages391 s.steps 0 3 i4 p
theorem correct391 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule391 s p) tgt := by
  have small : NoAtMost i4 (PetersenPackedPin.project r391 tgt) 3 := by rw [match391]; exact Extra1020K12.b15_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk391 s small hot391 p hit
def rule397 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages397 s.steps 128 4 i5 p
theorem correct397 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule397 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r397 tgt) 4 := by rw [match397]; exact Extra1020K12.b15_1
  intro d L hit
  exact PetersenRoutedPin.quick rowOk397 s small hot397 p hit
def rule404 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages404 s.steps 32 4 i5 p
theorem correct404 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule404 s p) tgt := by
  have small : NoAtMost i5 (PetersenPackedPin.project r404 tgt) 4 := by rw [match404]; exact Extra1020K12.b47_0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk404 s small hot404 p hit
def rule410 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xaaaaaaaaaaaaaaaa :: i7) p
theorem correct410 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule410 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaaaaaaaaaa :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h46
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule411 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xf0f0f0f0f0f0f0f0 :: i7) p
theorem correct411 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule411 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h47
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule412 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) p
theorem correct412 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule412 s p) tgt := by
  have small : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h54
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule413 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xaaaaaaaa00000000aaaaaaaa :: i7) p
theorem correct413 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule413 s p) tgt := by
  have small : NoAtMost (0xaaaaaaaa00000000aaaaaaaa :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h48
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
def rule414 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages32 s.steps 0 10 (0xaa00aa00aa00aa00aa00aa00aa00aa :: i7) p
theorem correct414 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule414 s p) tgt := by
  have small : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa :: i7) (PetersenPackedPin.project r32 tgt) 10 := by rw [match32]; exact Assumptions.h52
  intro d L hit
  exact PetersenRoutedPin.quick rowOk32 s small hot32 p hit
def rule415 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xffffffffffffffffffffffff00000000 :: i7) p
theorem correct415 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule415 s p) tgt := by
  have small : NoAtMost (0xffffffffffffffffffffffff00000000 :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h68
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule416 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages34 s.steps 0 10 (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) p
theorem correct416 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule416 s p) tgt := by
  have small : NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: i7) (PetersenPackedPin.project r34 tgt) 10 := by rw [match34]; exact Assumptions.h64
  intro d L hit
  exact PetersenRoutedPin.quick rowOk34 s small hot34 p hit
def rule417 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages30 s.steps 0 10 (0xf0f0f0f0f0f0f0f0 :: i7) p
theorem correct417 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule417 s p) tgt := by
  have small : NoAtMost (0xf0f0f0f0f0f0f0f0 :: i7) (PetersenPackedPin.project r30 tgt) 10 := by rw [match30]; exact Assumptions.h47
  intro d L hit
  exact PetersenRoutedPin.quick rowOk30 s small hot30 p hit
end MC010Cert
