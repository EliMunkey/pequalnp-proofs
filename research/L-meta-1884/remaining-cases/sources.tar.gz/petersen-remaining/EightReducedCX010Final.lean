import EightReducedCX010Root
import HMC010Assumed
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
open MC010Cert
namespace PetersenLiveReduced.CX010
set_option maxRecDepth 300000
set_option maxHeartbeats 0
set_option linter.concreteInstances false
theorem complete0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :: inputs 8) tgt 12 := reject0_1_0
#print axioms complete0_1_0
end PetersenLiveReduced.CX010
