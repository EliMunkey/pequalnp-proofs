import HMC010Hyp
import M15StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem hold69_0 : NoAtMost (0xf0 :: inputs 4) 0xf8c8 3 := by
  exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hold69_1 : NoAtMost (0xf000f0 :: inputs 5) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) hold69_0 <;> decide +kernel
theorem hold69_2 : NoAtMost (0xf000f000f000f0 :: inputs 6) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) hold69_1 <;> decide +kernel
theorem hold69_3 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: inputs 7) 0xfffffffffffffffffffffffffffff8c8 6 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) hold69_2 <;> decide +kernel
end MC010Cert
