import PetersenProjectedRule
import Full18FastBases
import Full18Data5
import Full18ThinView5
import Full18ThinView6
import Full18ThinView7
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound5663 (h : Needs) : Correct rule5663 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5663) (t := Root17.tgt) SEP149 ONES149 thinBasis16 TG149 (baseThin16 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound5683 (h : Needs) : Correct rule5683 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5683) (t := Root17.tgt) SEP110 ONES110 thinBasis5 TG110 (baseThin5 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5688 (h : Needs) : Correct rule5688 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5688) (t := Root17.tgt) SEP110 ONES110 thinBasis13 TG110 (baseThin13 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5689 (h : Needs) : Correct rule5689 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5689) (t := Root17.tgt) SEP116 ONES116 thinBasis14 TG116 (baseThin14 h) (by decide +kernel) [(false,(8,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5692 (h : Needs) : Correct rule5692 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5692) (t := Root17.tgt) SEP110 ONES110 thinBasis1 TG110 (baseThin1 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5696 (h : Needs) : Correct rule5696 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5696) (t := Root17.tgt) SEP110 ONES110 thinBasis2 TG110 (baseThin2 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5704 (h : Needs) : Correct rule5704 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5704) (t := Root17.tgt) SEP110 ONES110 thinBasis4 TG110 (baseThin4 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5724 (h : Needs) : Correct rule5724 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5724) (t := Root17.tgt) SEP145 ONES145 thinBasis2 TG145 (baseThin2 h) (by decide +kernel) [(false,(7,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5725 (h : Needs) : Correct rule5725 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5725) (t := Root17.tgt) SEP151 ONES151 thinBasis7 TG151 (baseThin7 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound5731 (h : Needs) : Correct rule5731 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5731) (t := Root17.tgt) SEP132 ONES132 thinBasis5 TG132 (baseThin5 h) (by decide +kernel) [(false,(6,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5744 (h : Needs) : Correct rule5744 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5744) (t := Root17.tgt) SEP136 ONES136 thinBasis2 TG136 (baseThin2 h) (by decide +kernel) [(false,(6,true),(3,true))] rfl (by decide +kernel)
theorem quickSound5751 (h : Needs) : Correct rule5751 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5751) (t := Root17.tgt) SEP116 ONES116 thinBasis4 TG116 (baseThin4 h) (by decide +kernel) [(false,(8,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5756 (h : Needs) : Correct rule5756 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5756) (t := Root17.tgt) SEP151 ONES151 thinBasis16 TG151 (baseThin16 h) (by decide +kernel) [(false,(8,true),(4,true))] rfl (by decide +kernel)
theorem quickSound5785 (h : Needs) : Correct rule5785 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5785) (t := Root17.tgt) SEP111 ONES111 thinBasis5 TG111 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5787 (h : Needs) : Correct rule5787 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5787) (t := Root17.tgt) SEP111 ONES111 thinBasis13 TG111 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5794 (h : Needs) : Correct rule5794 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5794) (t := Root17.tgt) SEP115 ONES115 thinBasis5 TG115 (baseThin5 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5796 (h : Needs) : Correct rule5796 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5796) (t := Root17.tgt) SEP111 ONES111 thinBasis1 TG111 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5802 (h : Needs) : Correct rule5802 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5802) (t := Root17.tgt) SEP141 ONES141 thinBasis1 TG141 (baseThin1 h) (by decide +kernel) [(false,(7,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5804 (h : Needs) : Correct rule5804 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5804) (t := Root17.tgt) SEP141 ONES141 thinBasis1 TG141 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5807 (h : Needs) : Correct rule5807 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5807) (t := Root17.tgt) SEP150 ONES150 thinBasis1 TG150 (baseThin1 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5813 (h : Needs) : Correct rule5813 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5813) (t := Root17.tgt) SEP111 ONES111 thinBasis2 TG111 (baseThin2 h) (by decide +kernel) [(false,(2,true),(4,true))] rfl (by decide +kernel)
theorem quickSound5815 (h : Needs) : Correct rule5815 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5815) (t := Root17.tgt) SEP111 ONES111 thinBasis2 TG111 (baseThin2 h) (by decide +kernel) [(false,(3,true),(6,true))] rfl (by decide +kernel)
theorem quickSound5817 (h : Needs) : Correct rule5817 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5817) (t := Root17.tgt) SEP111 ONES111 thinBasis2 TG111 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5819 (h : Needs) : Correct rule5819 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5819) (t := Root17.tgt) SEP111 ONES111 thinBasis7 TG111 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5823 (h : Needs) : Correct rule5823 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5823) (t := Root17.tgt) SEP129 ONES129 thinBasis2 TG129 (baseThin2 h) (by decide +kernel) [(false,(3,true),(1,true))] rfl (by decide +kernel)
theorem quickSound5825 (h : Needs) : Correct rule5825 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5825) (t := Root17.tgt) SEP129 ONES129 thinBasis2 TG129 (baseThin2 h) (by decide +kernel) [(false,(3,true),(5,true))] rfl (by decide +kernel)
theorem quickSound5830 (h : Needs) : Correct rule5830 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5830) (t := Root17.tgt) SEP129 ONES129 thinBasis2 TG129 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5834 (h : Needs) : Correct rule5834 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5834) (t := Root17.tgt) SEP129 ONES129 thinBasis7 TG129 (baseThin7 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5844 (h : Needs) : Correct rule5844 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5844) (t := Root17.tgt) SEP129 ONES129 thinBasis13 TG129 (baseThin13 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound5845 (h : Needs) : Correct rule5845 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5845) (t := Root17.tgt) SEP131 ONES131 thinBasis1 TG131 (baseThin1 h) (by decide +kernel) [(false,(1,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5861 (h : Needs) : Correct rule5861 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5861) (t := Root17.tgt) SEP137 ONES137 thinBasis2 TG137 (baseThin2 h) (by decide +kernel) [(false,(3,true),(7,true))] rfl (by decide +kernel)
theorem quickSound5864 (h : Needs) : Correct rule5864 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule5864) (t := Root17.tgt) SEP137 ONES137 thinBasis2 TG137 (baseThin2 h) (by decide +kernel) [] rfl (by decide +kernel)
end Full18
