import HEX010G2
import HEX010G3
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r43 := EX010Cert.r43
abbrev stages43 := EX010Cert.stages43
theorem rowOk43 : PetersenWordProjection.check stages43 64 r43 = true := EX010Cert.rowOk43
theorem hot43 : forcedConst r43 tgt = false := EX010Cert.hot43
theorem match43 : PetersenPackedPin.project r43 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match43
abbrev r45 := EX010Cert.r45
abbrev stages45 := EX010Cert.stages45
theorem rowOk45 : PetersenWordProjection.check stages45 64 r45 = true := EX010Cert.rowOk45
theorem hot45 : forcedConst r45 tgt = false := EX010Cert.hot45
theorem match45 : PetersenPackedPin.project r45 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match45
abbrev r53 := EX010Cert.r53
abbrev stages53 := EX010Cert.stages53
theorem rowOk53 : PetersenWordProjection.check stages53 128 r53 = true := EX010Cert.rowOk53
theorem hot53 : forcedConst r53 tgt = false := EX010Cert.hot53
theorem match53 : PetersenPackedPin.project r53 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match53
abbrev r54 := EX010Cert.r54
abbrev stages54 := EX010Cert.stages54
theorem rowOk54 : PetersenWordProjection.check stages54 64 r54 = true := EX010Cert.rowOk54
theorem hot54 : forcedConst r54 tgt = false := EX010Cert.hot54
theorem match54 : PetersenPackedPin.project r54 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match54
abbrev r61 := EX010Cert.r61
abbrev stages61 := EX010Cert.stages61
theorem rowOk61 : PetersenWordProjection.check stages61 128 r61 = true := EX010Cert.rowOk61
theorem hot61 : forcedConst r61 tgt = false := EX010Cert.hot61
theorem match61 : PetersenPackedPin.project r61 tgt = (0xfffffffffaeaf8c8 : BitVec 64) := EX010Cert.match61
abbrev r62 := EX010Cert.r62
abbrev stages62 := EX010Cert.stages62
theorem rowOk62 : PetersenWordProjection.check stages62 64 r62 = true := EX010Cert.rowOk62
theorem hot62 : forcedConst r62 tgt = false := EX010Cert.hot62
theorem match62 : PetersenPackedPin.project r62 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match62
abbrev r69 := EX010Cert.r69
abbrev stages69 := EX010Cert.stages69
theorem rowOk69 : PetersenWordProjection.check stages69 0 r69 = true := EX010Cert.rowOk69
theorem hot69 : forcedConst r69 tgt = false := EX010Cert.hot69
theorem match69 : PetersenPackedPin.project r69 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match69
def r73 (i : Fin 64) : Fin 256 := (#[0,32,128,160,4,36,132,164,1,33,129,161,5,37,133,165,8,40,136,168,12,44,140,172,9,41,137,169,13,45,141,173,16,48,144,176,20,52,148,180,17,49,145,177,21,53,149,181,24,56,152,184,28,60,156,188,25,57,153,185,29,61,157,189] : Array (Fin 256))[i.val]?.getD 0
def stages73 : List PetersenWordProjection.Stage := [⟨0x40,0xffffffffffffffff0000000000000000,0xffffffffffffffff00000000000000000000000000000000,0xffffffffffffffff00000000000000000000000000000000ffffffffffffffff⟩,⟨0x10,0xffff000000000000ffff000000000000ffff000000000000ffff0000,0xffff000000000000ffff000000000000ffff000000000000ffff00000000,0xffff00000000ffffffff00000000ffffffff00000000ffffffff00000000ffff⟩,⟨0x18,0xff00ff0000000000ff00ff0000000000ff00ff0000000000ff00ff00,0xff00ff0000000000ff00ff0000000000ff00ff0000000000ff00ff00000000,0xff00ff0000ff00ffff00ff0000ff00ffff00ff0000ff00ffff00ff0000ff00ff⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x1f,0xaaaaaaaa00000000aaaaaaaa00000000aaaaaaaa00000000aaaaaaaa,0x5555555500000000555555550000000055555555000000005555555500000000,0xaaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555⟩]
theorem rowOk73 : PetersenWordProjection.check stages73 0 r73 = true := by decide +kernel
theorem hot73 : forcedConst r73 tgt = false := by decide +kernel
theorem match73 : PetersenPackedPin.project r73 tgt = (0xeeeeeecceaeaeac8 : BitVec 64) := by decide +kernel
abbrev r74 := EX010Cert.r74
abbrev stages74 := EX010Cert.stages74
theorem rowOk74 : PetersenWordProjection.check stages74 128 r74 = true := EX010Cert.rowOk74
theorem hot74 : forcedConst r74 tgt = false := EX010Cert.hot74
theorem match74 : PetersenPackedPin.project r74 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match74
abbrev r75 := EX010Cert.r75
abbrev stages75 := EX010Cert.stages75
theorem rowOk75 : PetersenWordProjection.check stages75 64 r75 = true := EX010Cert.rowOk75
theorem hot75 : forcedConst r75 tgt = false := EX010Cert.hot75
theorem match75 : PetersenPackedPin.project r75 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match75
abbrev r76 := EX010Cert.r76
abbrev stages76 := EX010Cert.stages76
theorem rowOk76 : PetersenWordProjection.check stages76 0 r76 = true := EX010Cert.rowOk76
theorem hot76 : forcedConst r76 tgt = false := EX010Cert.hot76
theorem match76 : PetersenPackedPin.project r76 tgt = (0xfaeaf8c8 : BitVec 32) := EX010Cert.match76
abbrev r83 := EX010Cert.r83
abbrev stages83 := EX010Cert.stages83
theorem rowOk83 : PetersenWordProjection.check stages83 128 r83 = true := EX010Cert.rowOk83
theorem hot83 : forcedConst r83 tgt = false := EX010Cert.hot83
theorem match83 : PetersenPackedPin.project r83 tgt = (0xfffffffffffff8c8 : BitVec 64) := EX010Cert.match83
end MC161RCert
