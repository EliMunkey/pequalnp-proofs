import HMC161RHyp
import HMC161RThetaRoutes
import M191StartPreferredCheckedF3X4Z0
open PetersenWordCost
namespace MC161RCert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold48_0 : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xffffff00ffffff00ffffff00ffffff00) (a:=0xffffff00ffffff00ffffff00ffffff00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_3_4_0
end MC161RCert
