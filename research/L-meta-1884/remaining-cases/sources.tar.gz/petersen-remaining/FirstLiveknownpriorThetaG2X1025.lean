import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknownpriorThetaG2X1025 : NoAtMost ThetaCert.s2_1025 0xfffffffffffaf8f8ffeafaeaffeaf8c8 8 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(67,66),(65,67),(65,69),(4,12),(65,81),(65,97),(4,68)] (by decide +kernel) ThetaCert.b2_1025
#print axioms theFirstLiveknownpriorThetaG2X1025
end PetersenLive8
