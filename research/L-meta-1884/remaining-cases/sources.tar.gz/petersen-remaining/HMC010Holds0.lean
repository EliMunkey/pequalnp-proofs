import HMC010Hyp
import M55StartLabeled
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 100000
theorem hold0_0 : NoAtMost (0xaaaa0000 :: inputs 5) 0xeaeaeac8 4 := by
  exact PetersenSmallStarts.M55.all_forbidden 0xaaaa0000 (by decide +kernel)
end MC010Cert
