import HMC010Hyp
import HMC010ThetaRoutes
import M191StartPreferredCheckedF0X3Z3
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold57_0 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa00 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_3

theorem hold58_0 : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows0 thetaInputs0 thetaTarget0 (g:=0xaaaaaaaaaaaaaaaa0000000000000000) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_3

theorem hold59_0 : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows3 thetaInputs3 thetaTarget3 (g:=0xf0f00000f0f00000f0f00000f0f00000) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_3

theorem hold60_0 : NoAtMost (0xf0f0f0f000000000f0f0f0f000000000 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows1 thetaInputs1 thetaTarget1 (g:=0xf0f0f0f000000000f0f0f0f000000000) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_3_3
end MC010Cert
