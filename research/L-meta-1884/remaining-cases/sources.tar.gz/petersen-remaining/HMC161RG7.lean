import HEX010G7
import HEX010G8
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r288 := EX010Cert.r288
abbrev stages288 := EX010Cert.stages288
theorem rowOk288 : PetersenWordProjection.check stages288 128 r288 = true := EX010Cert.rowOk288
theorem hot288 : forcedConst r288 tgt = false := EX010Cert.hot288
theorem match288 : PetersenPackedPin.project r288 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match288
abbrev r292 := EX010Cert.r292
abbrev stages292 := EX010Cert.stages292
theorem rowOk292 : PetersenWordProjection.check stages292 0 r292 = true := EX010Cert.rowOk292
theorem hot292 : forcedConst r292 tgt = false := EX010Cert.hot292
theorem match292 : PetersenPackedPin.project r292 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match292
def r334 (i : Fin 16) : Fin 256 := (#[0,1,2,3,64,65,66,67,8,9,10,11,72,73,74,75] : Array (Fin 256))[i.val]?.getD 0
def stages334 : List PetersenWordProjection.Stage := [⟨0x20,0xffffffff000000000000000000000000ffffffff00000000,0xffffffff000000000000000000000000ffffffff0000000000000000,0xffffffff0000000000000000ffffffffffffffff0000000000000000ffffffff⟩,⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x3c,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f00000000000000000f0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00f0f0f0f0f0f0f0ff0f0f0f0f0f0f0f00f0f0f0f0f0f0f0f⟩]
theorem rowOk334 : PetersenWordProjection.check stages334 0 r334 = true := by decide +kernel
theorem hot334 : forcedConst r334 tgt = false := by decide +kernel
theorem match334 : PetersenPackedPin.project r334 tgt = (0xf8c8 : BitVec 16) := by decide +kernel
abbrev r343 := EX010Cert.r343
abbrev stages343 := EX010Cert.stages343
theorem rowOk343 : PetersenWordProjection.check stages343 64 r343 = true := EX010Cert.rowOk343
theorem hot343 : forcedConst r343 tgt = false := EX010Cert.hot343
theorem match343 : PetersenPackedPin.project r343 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match343
abbrev r346 := EX010Cert.r346
abbrev stages346 := EX010Cert.stages346
theorem rowOk346 : PetersenWordProjection.check stages346 128 r346 = true := EX010Cert.rowOk346
theorem hot346 : forcedConst r346 tgt = false := EX010Cert.hot346
theorem match346 : PetersenPackedPin.project r346 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match346
abbrev r354 := EX010Cert.r354
abbrev stages354 := EX010Cert.stages354
theorem rowOk354 : PetersenWordProjection.check stages354 128 r354 = true := EX010Cert.rowOk354
theorem hot354 : forcedConst r354 tgt = false := EX010Cert.hot354
theorem match354 : PetersenPackedPin.project r354 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match354
abbrev r358 := EX010Cert.r358
abbrev stages358 := EX010Cert.stages358
theorem rowOk358 : PetersenWordProjection.check stages358 0 r358 = true := EX010Cert.rowOk358
theorem hot358 : forcedConst r358 tgt = false := EX010Cert.hot358
theorem match358 : PetersenPackedPin.project r358 tgt = (0xf8c8 : BitVec 16) := EX010Cert.match358
abbrev r366 := EX010Cert.r366
abbrev stages366 := EX010Cert.stages366
theorem rowOk366 : PetersenWordProjection.check stages366 32 r366 = true := EX010Cert.rowOk366
theorem hot366 : forcedConst r366 tgt = false := EX010Cert.hot366
theorem match366 : PetersenPackedPin.project r366 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match366
abbrev r368 := EX010Cert.r368
abbrev stages368 := EX010Cert.stages368
theorem rowOk368 : PetersenWordProjection.check stages368 128 r368 = true := EX010Cert.rowOk368
theorem hot368 : forcedConst r368 tgt = false := EX010Cert.hot368
theorem match368 : PetersenPackedPin.project r368 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match368
abbrev r369 := EX010Cert.r369
abbrev stages369 := EX010Cert.stages369
theorem rowOk369 : PetersenWordProjection.check stages369 64 r369 = true := EX010Cert.rowOk369
theorem hot369 : forcedConst r369 tgt = false := EX010Cert.hot369
theorem match369 : PetersenPackedPin.project r369 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match369
abbrev r370 := EX010Cert.r370
abbrev stages370 := EX010Cert.stages370
theorem rowOk370 : PetersenWordProjection.check stages370 32 r370 = true := EX010Cert.rowOk370
theorem hot370 : forcedConst r370 tgt = false := EX010Cert.hot370
theorem match370 : PetersenPackedPin.project r370 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match370
abbrev r374 := EX010Cert.r374
abbrev stages374 := EX010Cert.stages374
theorem rowOk374 : PetersenWordProjection.check stages374 64 r374 = true := EX010Cert.rowOk374
theorem hot374 : forcedConst r374 tgt = false := EX010Cert.hot374
theorem match374 : PetersenPackedPin.project r374 tgt = (0xfffff8c8 : BitVec 32) := EX010Cert.match374
end MC161RCert
