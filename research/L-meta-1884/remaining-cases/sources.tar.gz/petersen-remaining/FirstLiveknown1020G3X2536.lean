import Q1020K12Closing
import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown1020G3X2536 : NoAtMost Orbits1020Cost12.s3_2536 Orbits1020Cost12.tgt 9 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(2,3),(36,38),(2,6),(32,40),(65,81),(193,224),(34,98),(10,42),(5,133)] (by decide +kernel) (Orbits1020Cost12.b3_2536 ThetaCert.bound)
#print axioms theFirstLiveknown1020G3X2536
end PetersenLive8
