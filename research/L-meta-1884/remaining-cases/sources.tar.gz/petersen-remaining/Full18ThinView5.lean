import PetersenProjectedRule
import Full18Stages
import PetersenImplicitRows
import RSWord
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem SEP100 : steps100.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES100 : PetersenWordProjection.projectFast steps100 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG100 : PetersenWordProjection.projectFast steps100 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP101 : steps101.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES101 : PetersenWordProjection.projectFast steps101 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG101 : PetersenWordProjection.projectFast steps101 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP102 : steps102.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES102 : PetersenWordProjection.projectFast steps102 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG102 : PetersenWordProjection.projectFast steps102 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP103 : steps103.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES103 : PetersenWordProjection.projectFast steps103 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG103 : PetersenWordProjection.projectFast steps103 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP104 : steps104.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES104 : PetersenWordProjection.projectFast steps104 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG104 : PetersenWordProjection.projectFast steps104 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP105 : steps105.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES105 : PetersenWordProjection.projectFast steps105 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG105 : PetersenWordProjection.projectFast steps105 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP107 : steps107.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES107 : PetersenWordProjection.projectFast steps107 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG107 : PetersenWordProjection.projectFast steps107 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP108 : steps108.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES108 : PetersenWordProjection.projectFast steps108 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG108 : PetersenWordProjection.projectFast steps108 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP109 : steps109.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES109 : PetersenWordProjection.projectFast steps109 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG109 : PetersenWordProjection.projectFast steps109 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP110 : steps110.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES110 : PetersenWordProjection.projectFast steps110 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG110 : PetersenWordProjection.projectFast steps110 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP111 : steps111.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES111 : PetersenWordProjection.projectFast steps111 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG111 : PetersenWordProjection.projectFast steps111 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP112 : steps112.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES112 : PetersenWordProjection.projectFast steps112 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG112 : PetersenWordProjection.projectFast steps112 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP113 : steps113.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES113 : PetersenWordProjection.projectFast steps113 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG113 : PetersenWordProjection.projectFast steps113 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP115 : steps115.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES115 : PetersenWordProjection.projectFast steps115 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG115 : PetersenWordProjection.projectFast steps115 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP116 : steps116.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES116 : PetersenWordProjection.projectFast steps116 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG116 : PetersenWordProjection.projectFast steps116 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
theorem SEP118 : steps118.all PetersenImplicitRows.separate = true := by decide +kernel
theorem ONES118 : PetersenWordProjection.projectFast steps118 0 (~~~(0 : BitVec 1024)) = (~~~(0 : BitVec 256)) := by decide +kernel
theorem TG118 : PetersenWordProjection.projectFast steps118 0 Root17.tgt = (0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 : BitVec 256) := by decide +kernel
end Full18
