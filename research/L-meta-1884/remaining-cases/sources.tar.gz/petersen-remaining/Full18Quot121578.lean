import Full18ThinRules3
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules8
import Full18ThinRules12
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot168022
import Full18Quot168479
import Full18Quot178493
import PetersenProjectedRule
import Full18StepS121578
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient121578 (h : Needs) : Blocked Root17.tgt 13 live121578 := by
  apply stepS121578
  · change ∀ r ∈ [rule3052,rule3064,rule4998,rule3894,rule3073,rule5006,rule6648,rule8098,rule8051,rule4025,rule4051,rule5257,rule5077,rule5115,rule7505,rule8000,rule8016,rule5218,rule3255,rule5277,rule4072,rule3172,rule4272], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4998) (quickSound4998 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3894) (quickSound3894 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5006) (quickSound5006 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6648) (quickSound6648 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8098) (quickSound8098 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4025) (quickSound4025 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4051) (quickSound4051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5257) (quickSound5257 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5077) (quickSound5077 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5115) (quickSound5115 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7505) (quickSound7505 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8000) (quickSound8000 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8016) (quickSound8016 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5218) (quickSound5218 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5277) (quickSound5277 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4072) (quickSound4072 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3172) (quickSound3172 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4272) (quickSound4272 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live187156,live187139,live187147,live187831,live187102,live187111,live187158,live187164,live187114,live187155], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187156) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live187156) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187139) (PetersenFastSymmetry.move [thinSym0,thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym3] (L := live187139) (V := live168022) (by decide +kernel) (quotient168022 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187147) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live187147) (V := live168479) (by decide +kernel) (quotient168479 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187831) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3] (L := live187831) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187102) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live187102) (V := live168479) (by decide +kernel) (quotient168479 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187111) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym2] (L := live187111) (V := live168022) (by decide +kernel) (quotient168022 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187158) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3] (L := live187158) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187164) (PetersenFastSymmetry.move [thinSym3,thinSym1,thinSym2,thinSym3] (L := live187164) (V := live178493) (by decide +kernel) (quotient178493 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187114) (PetersenFastSymmetry.move [thinSym1,thinSym3,thinSym1,thinSym2,thinSym3] (L := live187114) (V := live168022) (by decide +kernel) (quotient168022 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live187155) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym2] (L := live187155) (V := live168022) (by decide +kernel) (quotient168022 h)) <|
      PetersenLocalChildren.nil
end Full18
