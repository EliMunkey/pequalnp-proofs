import HEX010G0
import HEX010G1
import HMC161RPinData
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC161RCert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
abbrev r17 := EX010Cert.r17
abbrev stages17 := EX010Cert.stages17
theorem rowOk17 : PetersenWordProjection.check stages17 0 r17 = true := EX010Cert.rowOk17
theorem hot17 : forcedConst r17 tgt = false := EX010Cert.hot17
theorem match17 : PetersenPackedPin.project r17 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match17
abbrev r18 := EX010Cert.r18
abbrev stages18 := EX010Cert.stages18
theorem rowOk18 : PetersenWordProjection.check stages18 0 r18 = true := EX010Cert.rowOk18
theorem hot18 : forcedConst r18 tgt = false := EX010Cert.hot18
theorem match18 : PetersenPackedPin.project r18 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match18
abbrev r19 := EX010Cert.r19
abbrev stages19 := EX010Cert.stages19
theorem rowOk19 : PetersenWordProjection.check stages19 0 r19 = true := EX010Cert.rowOk19
theorem hot19 : forcedConst r19 tgt = false := EX010Cert.hot19
theorem match19 : PetersenPackedPin.project r19 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match19
abbrev r20 := EX010Cert.r20
abbrev stages20 := EX010Cert.stages20
theorem rowOk20 : PetersenWordProjection.check stages20 0 r20 = true := EX010Cert.rowOk20
theorem hot20 : forcedConst r20 tgt = false := EX010Cert.hot20
theorem match20 : PetersenPackedPin.project r20 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match20
abbrev r21 := EX010Cert.r21
abbrev stages21 := EX010Cert.stages21
theorem rowOk21 : PetersenWordProjection.check stages21 0 r21 = true := EX010Cert.rowOk21
theorem hot21 : forcedConst r21 tgt = false := EX010Cert.hot21
theorem match21 : PetersenPackedPin.project r21 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match21
abbrev r22 := EX010Cert.r22
abbrev stages22 := EX010Cert.stages22
theorem rowOk22 : PetersenWordProjection.check stages22 0 r22 = true := EX010Cert.rowOk22
theorem hot22 : forcedConst r22 tgt = false := EX010Cert.hot22
theorem match22 : PetersenPackedPin.project r22 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match22
abbrev r23 := EX010Cert.r23
abbrev stages23 := EX010Cert.stages23
theorem rowOk23 : PetersenWordProjection.check stages23 0 r23 = true := EX010Cert.rowOk23
theorem hot23 : forcedConst r23 tgt = false := EX010Cert.hot23
theorem match23 : PetersenPackedPin.project r23 tgt = (0xfeeefcccfaeaf8c8 : BitVec 64) := EX010Cert.match23
abbrev r26 := EX010Cert.r26
abbrev stages26 := EX010Cert.stages26
theorem rowOk26 : PetersenWordProjection.check stages26 0 r26 = true := EX010Cert.rowOk26
theorem hot26 : forcedConst r26 tgt = false := EX010Cert.hot26
theorem match26 : PetersenPackedPin.project r26 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match26
abbrev r27 := EX010Cert.r27
abbrev stages27 := EX010Cert.stages27
theorem rowOk27 : PetersenWordProjection.check stages27 128 r27 = true := EX010Cert.rowOk27
theorem hot27 : forcedConst r27 tgt = false := EX010Cert.hot27
theorem match27 : PetersenPackedPin.project r27 tgt = (0xfffffffffffffffffffffffffaeaf8c8 : BitVec 128) := EX010Cert.match27
def r28 (i : Fin 128) : Fin 256 := (#[0,32,128,160,16,48,144,176,64,96,192,224,80,112,208,240,8,40,136,168,24,56,152,184,72,104,200,232,88,120,216,248,1,33,129,161,17,49,145,177,65,97,193,225,81,113,209,241,9,41,137,169,25,57,153,185,73,105,201,233,89,121,217,249,4,36,132,164,20,52,148,180,68,100,196,228,84,116,212,244,12,44,140,172,28,60,156,188,76,108,204,236,92,124,220,252,5,37,133,165,21,53,149,181,69,101,197,229,85,117,213,245,13,45,141,173,29,61,157,189,77,109,205,237,93,125,221,253] : Array (Fin 256))[i.val]?.getD 0
def stages28 : List PetersenWordProjection.Stage := [⟨0x30,0xffff0000ffff00000000000000000000ffff0000ffff0000,0xffff0000ffff00000000000000000000ffff0000ffff0000000000000000,0xffff0000ffff00000000ffff0000ffffffff0000ffff00000000ffff0000ffff⟩,⟨0x38,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff00,0xff00ff00ff00ff000000000000000000ff00ff00ff00ff0000000000000000,0xff00ff00ff00ff0000ff00ff00ff00ffff00ff00ff00ff0000ff00ff00ff00ff⟩,⟨0xc,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f00000f0f0000,0xf0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0ff0f00f0f⟩,⟨0x7e,0xcccccccccccccccccccccccccccccccc,0x3333333333333333333333333333333300000000000000000000000000000000,0xcccccccccccccccccccccccccccccccc33333333333333333333333333333333⟩,⟨0x1f,0xaaaaaaaa00000000aaaaaaaa00000000aaaaaaaa00000000aaaaaaaa,0x5555555500000000555555550000000055555555000000005555555500000000,0xaaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555aaaaaaaa55555555⟩]
theorem rowOk28 : PetersenWordProjection.check stages28 0 r28 = true := by decide +kernel
theorem hot28 : forcedConst r28 tgt = false := by decide +kernel
theorem match28 : PetersenPackedPin.project r28 tgt = (0xffeefeeeffeefcccffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
abbrev r29 := EX010Cert.r29
abbrev stages29 := EX010Cert.stages29
theorem rowOk29 : PetersenWordProjection.check stages29 128 r29 = true := EX010Cert.rowOk29
theorem hot29 : forcedConst r29 tgt = false := EX010Cert.hot29
theorem match29 : PetersenPackedPin.project r29 tgt = (0xfffffffffffffffffffffffffffff8c8 : BitVec 128) := EX010Cert.match29
abbrev r30 := EX010Cert.r30
abbrev stages30 := EX010Cert.stages30
theorem rowOk30 : PetersenWordProjection.check stages30 0 r30 = true := EX010Cert.rowOk30
theorem hot30 : forcedConst r30 tgt = false := EX010Cert.hot30
theorem match30 : PetersenPackedPin.project r30 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := EX010Cert.match30
end MC161RCert
