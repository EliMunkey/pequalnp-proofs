import HMC010Hyp
import HMC010Sym
import HMC010W0
import HMC010W1
import HMC010W2
import HMC010W3
import first8.MixedPair
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def s4_775 : List (BitVec 256) := [w34,w572,w644,w680,w720,w778,w880,w905,w977]
private theorem p4_775_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,9254,3,9254]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4630,518,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12344,8232,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,24688]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,2602,33,2602]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [579,578,4690,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w34,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,8352]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,518,7,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,2051,11,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,4099,19,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,2600,33,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,578,8290,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,4627,5142,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w572,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [3,4754,131,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,2566,526,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4630,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,1057,33,37]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,13424,578,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4627,518,518,13361]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w644,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12344,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,2081,33,41]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,2626,578,586]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w680,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4627,4635,4627,6675]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w680,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,3204,1156,1164]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,4129,33,49]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,4675,578,4690]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w720,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [32912,4627,4611,4611]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w720,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,8770,578,33]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w778,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,2602,2602,33]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w778,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [33,12464,161,33]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w880,w905) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,2120]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w880,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,17604,1156,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_775_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_775 (w905,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,1156,4627]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_775 [Assumptions] : Blocked tgt 8 s4_775 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w34,w572),(w34,w644),(w34,w680),(w34,w720),(w34,w778),(w34,w880),(w34,w905),(w34,w977),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w572,w905),(w572,w977),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w644,w905),(w644,w977),(w680,w720),(w680,w778),(w680,w880),(w680,w905),(w680,w977),(w720,w778),(w720,w880),(w720,w905),(w720,w977),(w778,w880),(w778,w905),(w778,w977),(w880,w905),(w880,w977),(w905,w977)], PetersenLocalChildren.PairOK tgt 7 s4_775 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w572)) p4_775_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w644)) p4_775_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w680)) p4_775_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w720)) p4_775_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w778)) p4_775_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w880)) p4_775_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w905)) p4_775_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w34,w977)) p4_775_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w644)) p4_775_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w680)) p4_775_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w720)) p4_775_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w778)) p4_775_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w880)) p4_775_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w905)) p4_775_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w572,w977)) p4_775_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w680)) p4_775_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w720)) p4_775_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w778)) p4_775_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w880)) p4_775_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w905)) p4_775_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w644,w977)) p4_775_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w680,w720)) p4_775_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w680,w778)) p4_775_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w680,w880)) p4_775_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w680,w905)) p4_775_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w680,w977)) p4_775_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w720,w778)) p4_775_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w720,w880)) p4_775_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w720,w905)) p4_775_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w720,w977)) p4_775_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w778,w880)) p4_775_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w778,w905)) p4_775_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w778,w977)) p4_775_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w880,w905)) p4_775_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w880,w977)) p4_775_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_775) (x := (w905,w977)) p4_775_35 <|
    PetersenLocalChildren.nil
def s4_1362 : List (BitVec 256) := [w46,w330,w517,w572,w644,w720,w778,w880,w977]
private theorem p4_1362_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w330) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12344,8232,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4627,515,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4379,9254,267,267]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4630,518,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,16464]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4152,2602,40,40]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4184,578,72,72]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w46,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,8352]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w517) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [523,515,2563,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4379,8234,4371,4371]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [526,518,2566,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12344,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [554,554,2602,4401]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [586,578,2626,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w330,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,1156,4754]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [5150,515,515,4123]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,9249,518,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4627,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4408,547,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4440,578,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w517,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,1412,1156,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4379,518,4126,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [9254,4379,283,283]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2600,2600,4152,2602]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2632,578,4184,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w572,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,395,395]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4630,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5176,550,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5208,578,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w644,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2602,4152,56,56]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,4184,88,88]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w720,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,8770,578,610]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w778,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,12464,168,168]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1362_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1362 (w880,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,32968,200,200]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_1362 [Assumptions] : Blocked tgt 8 s4_1362 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w46,w330),(w46,w517),(w46,w572),(w46,w644),(w46,w720),(w46,w778),(w46,w880),(w46,w977),(w330,w517),(w330,w572),(w330,w644),(w330,w720),(w330,w778),(w330,w880),(w330,w977),(w517,w572),(w517,w644),(w517,w720),(w517,w778),(w517,w880),(w517,w977),(w572,w644),(w572,w720),(w572,w778),(w572,w880),(w572,w977),(w644,w720),(w644,w778),(w644,w880),(w644,w977),(w720,w778),(w720,w880),(w720,w977),(w778,w880),(w778,w977),(w880,w977)], PetersenLocalChildren.PairOK tgt 7 s4_1362 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w330)) p4_1362_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w517)) p4_1362_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w572)) p4_1362_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w644)) p4_1362_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w720)) p4_1362_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w778)) p4_1362_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w880)) p4_1362_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w46,w977)) p4_1362_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w517)) p4_1362_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w572)) p4_1362_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w644)) p4_1362_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w720)) p4_1362_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w778)) p4_1362_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w880)) p4_1362_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w330,w977)) p4_1362_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w572)) p4_1362_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w644)) p4_1362_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w720)) p4_1362_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w778)) p4_1362_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w880)) p4_1362_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w517,w977)) p4_1362_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w572,w644)) p4_1362_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w572,w720)) p4_1362_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w572,w778)) p4_1362_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w572,w880)) p4_1362_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w572,w977)) p4_1362_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w644,w720)) p4_1362_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w644,w778)) p4_1362_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w644,w880)) p4_1362_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w644,w977)) p4_1362_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w720,w778)) p4_1362_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w720,w880)) p4_1362_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w720,w977)) p4_1362_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w778,w880)) p4_1362_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w778,w977)) p4_1362_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1362) (x := (w880,w977)) p4_1362_35 <|
    PetersenLocalChildren.nil
def s4_1365 : List (BitVec 256) := [w46,w490,w572,w644,w680,w720,w778,w880,w977]
private theorem p4_1365_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w490) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4627,515,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4115,9254,3,3]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4630,518,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12344,8232,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,16464]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4145,2602,33,33]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4177,578,2121,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w46,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,8352]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4115,515,515,5142]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,518,9249,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,523,2563,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4627,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,547,4145,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,578,4176,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w490,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4754,1156,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4115,518,4119,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4115,6163,4123,4115]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [9254,4115,19,19]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2600,2600,4145,2602]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2632,578,4177,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w572,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4754,131,131]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,2566,526,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4630,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5169,550,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5201,578,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w644,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12344,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4145,2602,554,554]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,2626,578,586]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w680,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,3204,1156,1164]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2602,4145,49,49]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,4177,81,81]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w720,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,8770,578,610]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w778,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,12464,161,161]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1365_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1365 (w880,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,33474,1156,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_1365 [Assumptions] : Blocked tgt 8 s4_1365 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w46,w490),(w46,w572),(w46,w644),(w46,w680),(w46,w720),(w46,w778),(w46,w880),(w46,w977),(w490,w572),(w490,w644),(w490,w680),(w490,w720),(w490,w778),(w490,w880),(w490,w977),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w572,w977),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w644,w977),(w680,w720),(w680,w778),(w680,w880),(w680,w977),(w720,w778),(w720,w880),(w720,w977),(w778,w880),(w778,w977),(w880,w977)], PetersenLocalChildren.PairOK tgt 7 s4_1365 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w490)) p4_1365_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w572)) p4_1365_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w644)) p4_1365_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w680)) p4_1365_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w720)) p4_1365_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w778)) p4_1365_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w880)) p4_1365_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w46,w977)) p4_1365_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w572)) p4_1365_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w644)) p4_1365_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w680)) p4_1365_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w720)) p4_1365_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w778)) p4_1365_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w880)) p4_1365_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w490,w977)) p4_1365_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w644)) p4_1365_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w680)) p4_1365_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w720)) p4_1365_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w778)) p4_1365_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w880)) p4_1365_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w572,w977)) p4_1365_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w644,w680)) p4_1365_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w644,w720)) p4_1365_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w644,w778)) p4_1365_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w644,w880)) p4_1365_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w644,w977)) p4_1365_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w680,w720)) p4_1365_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w680,w778)) p4_1365_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w680,w880)) p4_1365_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w680,w977)) p4_1365_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w720,w778)) p4_1365_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w720,w880)) p4_1365_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w720,w977)) p4_1365_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w778,w880)) p4_1365_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w778,w977)) p4_1365_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1365) (x := (w880,w977)) p4_1365_35 <|
    PetersenLocalChildren.nil
def s4_1367 : List (BitVec 256) := [w46,w512,w572,w644,w680,w720,w778,w880,w977]
private theorem p4_1367_0 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w512) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4627,515,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_1 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [5142,9254,1030,1030]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_2 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4630,518,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_3 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [12344,8232,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_4 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16464,16464]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_5 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [6200,2602,2088,2088]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_6 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [4176,578,2120,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_7 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w46,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,8352]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_8 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w572) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [5142,515,515,4115]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_9 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,9249,518,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_10 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,2563,523,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_11 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,4627,4627,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_12 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,8225,547,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_13 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,24609,578,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_14 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w512,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [515,33411,1156,515]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_15 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w644) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16450,518,4118,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_16 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [5142,7190,5150,5142]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_17 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [9254,5142,1046,1046]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_18 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2600,2600,5174,2602]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_19 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2632,578,4176,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_20 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w572,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4752,1156,1158]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_21 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w644,w680) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,2566,526,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_22 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w644,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,4630,4630,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_23 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w644,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,7224,550,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_24 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w644,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,5200,578,518]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_25 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w644,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [518,1156,132,132]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_26 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w680,w720) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [8232,12344,12344,8232]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_27 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w680,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [16456,2602,554,554]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_28 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w680,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,2626,578,586]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_29 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w680,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,3204,1156,1164]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_30 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w720,w778) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [2602,6200,2104,2104]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_31 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w720,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,4176,80,80]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_32 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w720,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,4240,144,144]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_33 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w778,w880) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,8770,578,610]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_34 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w778,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [1156,12432,160,160]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
private theorem p4_1367_35 [Assumptions] : PetersenLocalChildren.PairOK tgt 7 s4_1367 (w880,w977) := by
  refine PetersenMixedPair.valid (cut := #[]) (more := #[]) (hints := [578,33474,1156,578]) (by decide +kernel) ?_ ?_
  · change ∀ r∈[], PetersenProjectedRule.Correct r tgt
    exact PetersenLocalChildren.nil
  · change ∀ v∈[], Blocked tgt 7 v
    exact PetersenLocalChildren.nil
theorem node4_1367 [Assumptions] : Blocked tgt 8 s4_1367 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(w46,w512),(w46,w572),(w46,w644),(w46,w680),(w46,w720),(w46,w778),(w46,w880),(w46,w977),(w512,w572),(w512,w644),(w512,w680),(w512,w720),(w512,w778),(w512,w880),(w512,w977),(w572,w644),(w572,w680),(w572,w720),(w572,w778),(w572,w880),(w572,w977),(w644,w680),(w644,w720),(w644,w778),(w644,w880),(w644,w977),(w680,w720),(w680,w778),(w680,w880),(w680,w977),(w720,w778),(w720,w880),(w720,w977),(w778,w880),(w778,w977),(w880,w977)], PetersenLocalChildren.PairOK tgt 7 s4_1367 p
  exact PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w512)) p4_1367_0 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w572)) p4_1367_1 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w644)) p4_1367_2 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w680)) p4_1367_3 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w720)) p4_1367_4 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w778)) p4_1367_5 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w880)) p4_1367_6 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w46,w977)) p4_1367_7 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w572)) p4_1367_8 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w644)) p4_1367_9 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w680)) p4_1367_10 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w720)) p4_1367_11 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w778)) p4_1367_12 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w880)) p4_1367_13 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w512,w977)) p4_1367_14 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w644)) p4_1367_15 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w680)) p4_1367_16 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w720)) p4_1367_17 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w778)) p4_1367_18 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w880)) p4_1367_19 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w572,w977)) p4_1367_20 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w644,w680)) p4_1367_21 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w644,w720)) p4_1367_22 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w644,w778)) p4_1367_23 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w644,w880)) p4_1367_24 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w644,w977)) p4_1367_25 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w680,w720)) p4_1367_26 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w680,w778)) p4_1367_27 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w680,w880)) p4_1367_28 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w680,w977)) p4_1367_29 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w720,w778)) p4_1367_30 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w720,w880)) p4_1367_31 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w720,w977)) p4_1367_32 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w778,w880)) p4_1367_33 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w778,w977)) p4_1367_34 <|
    PetersenLocalChildren.push (P := PetersenLocalChildren.PairOK tgt 7 s4_1367) (x := (w880,w977)) p4_1367_35 <|
    PetersenLocalChildren.nil
end MC010Cert
