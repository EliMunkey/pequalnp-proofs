import M63StartL7B0
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown63G475 : NoAtMost PetersenSmallStarts.M63.s475 PetersenSmallStarts.M63.tgt 7 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(1,33),(32,33),(1,3),(34,38),(36,44),(1,17)] (by decide +kernel) PetersenSmallStarts.M63.b475
#print axioms theFirstLiveknown63G475
end PetersenLive8
