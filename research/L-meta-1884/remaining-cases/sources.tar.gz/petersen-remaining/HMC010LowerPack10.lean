import HMC010Hyp
import HMC010ThetaRoutes
import M191StartPreferredCheckedF3X5Z0
open PetersenWordCost
namespace MC010Cert
set_option maxHeartbeats 0
set_option maxRecDepth 200000

theorem hold65_0 : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows2 thetaInputs2 thetaTarget2 (g:=0xffffffffff00ff00ffffffffff00ff00) (a:=0xffffffffff00ff00ffffffffff00ff00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_3_5_0

theorem hold67_0 : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: inputs 7) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact PetersenSmallStarts.relabel_aux thetaRows0 thetaInputs0 thetaTarget0 (g:=0xffffffffffffffffffff0000ffff0000) (a:=0xffffffffff00ff00ffffffffff00ff00) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_3_5_0
end MC010Cert
