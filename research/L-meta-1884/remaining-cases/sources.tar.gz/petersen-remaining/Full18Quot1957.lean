import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules6
import Full18ThinRules7
import Full18ThinRules11
import Full18ThinRules13
import Full18ThinRules15
import Full18Quot29713
import PetersenProjectedRule
import Full18StepS1957
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient1957 (h : Needs) : Blocked Root17.tgt 14 live1957 := by
  apply stepS1957
  · change ∀ r ∈ [rule8051,rule7428,rule3052,rule5944,rule8044,rule6063,rule3064,rule6068,rule5174,rule7430,rule3213,rule4212,rule3259,rule3261], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7428) (quickSound7428 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8044) (quickSound8044 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6063) (quickSound6063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6068) (quickSound6068 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5174) (quickSound5174 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7430) (quickSound7430 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3213) (quickSound3213 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4212) (quickSound4212 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3259) (quickSound3259 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live29713], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live29713) (quotient29713 h) <|
      PetersenLocalChildren.nil
end Full18
