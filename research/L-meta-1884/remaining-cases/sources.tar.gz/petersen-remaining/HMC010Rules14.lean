import Extra1020K12
import HMC010G1
import HMC010G3
import HMC010G4
import HMC010G5
import HMC010G6
import HMC010G8
import HMC010G9
import HMC010Hyp
import HMC010PinData
import HMC010Routes
import M189Closing
import ThetaClosing
import higher.Exact1020
import PetersenSymmetry
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenSymmetry
namespace MC010Cert
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option linter.unusedVariables false
set_option linter.concreteInstances false
def rule578 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages255 s.steps 32 4 (0xf000f0 :: i5) p
theorem correct578 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule578 s p) tgt := by
  have small : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r255 tgt) 4 := by rw [match255]; exact Assumptions.h26
  intro d L hit
  exact PetersenRoutedPin.quick rowOk255 s small hot255 p hit
def rule579 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages18 s.steps 0 6 (0xf000f000f000f0 :: i6) p
theorem correct579 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule579 s p) tgt := by
  have small : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r18 tgt) 6 := by rw [match18]; exact Assumptions.h31
  intro d L hit
  exact PetersenRoutedPin.quick rowOk18 s small hot18 p hit
def rule580 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages143 s.steps 64 4 (0x33003300 :: i5) p
theorem correct580 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule580 s p) tgt := by
  have small : NoAtMost (0x33003300 :: i5) (PetersenPackedPin.project r143 tgt) 4 := by rw [match143]; exact Assumptions.h28
  intro d L hit
  exact PetersenRoutedPin.quick rowOk143 s small hot143 p hit
def rule581 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages381 s.steps 0 4 (0xaaaa0000 :: i5) p
theorem correct581 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule581 s p) tgt := by
  have small : NoAtMost (0xaaaa0000 :: i5) (PetersenPackedPin.project r381 tgt) 4 := by rw [match381]; exact Assumptions.h0
  intro d L hit
  exact PetersenRoutedPin.quick rowOk381 s small hot381 p hit
def rule582 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages74 s.steps 128 5 (0x3300330033003300 :: i6) p
theorem correct582 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule582 s p) tgt := by
  have small : NoAtMost (0x3300330033003300 :: i6) (PetersenPackedPin.project r74 tgt) 5 := by rw [match74]; exact Assumptions.h42
  intro d L hit
  exact PetersenRoutedPin.quick rowOk74 s small hot74 p hit
def rule583 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages117 s.steps 64 5 (0x3300330033003300 :: i6) p
theorem correct583 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule583 s p) tgt := by
  have small : NoAtMost (0x3300330033003300 :: i6) (PetersenPackedPin.project r117 tgt) 5 := by rw [match117]; exact Assumptions.h42
  intro d L hit
  exact PetersenRoutedPin.quick rowOk117 s small hot117 p hit
def rule584 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages16 s.steps 0 6 (0xffffffffcccccccc :: i6) p
theorem correct584 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule584 s p) tgt := by
  have small : NoAtMost (0xffffffffcccccccc :: i6) (PetersenPackedPin.project r16 tgt) 6 := by rw [match16]; exact Assumptions.h34
  intro d L hit
  exact PetersenRoutedPin.quick rowOk16 s small hot16 p hit
def rule585 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages17 s.steps 0 6 (0xeeeeeeeeeeeeeeee :: i6) p
theorem correct585 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule585 s p) tgt := by
  have small : NoAtMost (0xeeeeeeeeeeeeeeee :: i6) (PetersenPackedPin.project r17 tgt) 6 := by rw [match17]; exact Assumptions.h33
  intro d L hit
  exact PetersenRoutedPin.quick rowOk17 s small hot17 p hit
def rule586 (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Rule 256 := PetersenRoutedPin.make stages40 s.steps 0 8 (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) p
theorem correct586 [H : Assumptions] (s : PetersenRoutedPin.Quick tgt) (p : List Instr) : PetersenProjectedRule.Correct (rule586 s p) tgt := by
  have small : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: i7) (PetersenPackedPin.project r40 tgt) 8 := by rw [match40]; exact Assumptions.h44
  intro d L hit
  exact PetersenRoutedPin.quick rowOk40 s small hot40 p hit
end MC010Cert
