import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules13
import Full18Quot168022
import PetersenProjectedRule
import Full18StepS97909
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient97909 (h : Needs) : Blocked Root17.tgt 13 live97909 := by
  apply stepS97909
  · change ∀ r ∈ [rule3052,rule1916,rule3251,rule1598,rule3073,rule7447,rule6745,rule2481,rule3201,rule6716,rule6674,rule3261], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1916) (quickSound1916 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1598) (quickSound1598 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7447) (quickSound7447 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6745) (quickSound6745 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2481) (quickSound2481 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3201) (quickSound3201 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6716) (quickSound6716 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3261) (quickSound3261 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live168022], Blocked Root17.tgt 12 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 12 s)) (x := live168022) (quotient168022 h) <|
      PetersenLocalChildren.nil
end Full18
