import Full18ThinRules0
import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules6
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot92707
import Full18Quot97906
import PetersenProjectedRule
import Full18StepS18623
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient18623 (h : Needs) : Blocked Root17.tgt 14 live18623 := by
  apply stepS18623
  · change ∀ r ∈ [rule3052,rule991,rule8022,rule3070,rule3251,rule3064,rule3073,rule3255,rule1358,rule6004,rule2558,rule1272,rule3302,rule1401,rule1404,rule6662,rule1385,rule7507,rule7517,rule1379,rule6647,rule8098,rule7505,rule8001,rule6014,rule5391,rule6674,rule7510,rule8101,rule8023,rule4251,rule6017,rule5492,rule6701,rule1470,rule1439,rule1140,rule5944,rule1199,rule7501,rule6655,rule6648,rule1494,rule1474,rule3821,rule1453,rule6716,rule1248,rule1256,rule1460,rule1463,rule1448,rule1451,rule1180,rule5292,rule1160,rule6616,rule1443], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule991) (quickSound991 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8022) (quickSound8022 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3073) (quickSound3073 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3255) (quickSound3255 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1358) (quickSound1358 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6004) (quickSound6004 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2558) (quickSound2558 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1272) (quickSound1272 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3302) (quickSound3302 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1401) (quickSound1401 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1404) (quickSound1404 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6662) (quickSound6662 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1385) (quickSound1385 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7507) (quickSound7507 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7517) (quickSound7517 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1379) (quickSound1379 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6647) (quickSound6647 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8098) (quickSound8098 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7505) (quickSound7505 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8001) (quickSound8001 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6014) (quickSound6014 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5391) (quickSound5391 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6674) (quickSound6674 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7510) (quickSound7510 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8101) (quickSound8101 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8023) (quickSound8023 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule4251) (quickSound4251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6017) (quickSound6017 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5492) (quickSound5492 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6701) (quickSound6701 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1470) (quickSound1470 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1439) (quickSound1439 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1140) (quickSound1140 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1199) (quickSound1199 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7501) (quickSound7501 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6655) (quickSound6655 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6648) (quickSound6648 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1494) (quickSound1494 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1474) (quickSound1474 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3821) (quickSound3821 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1453) (quickSound1453 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6716) (quickSound6716 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1248) (quickSound1248 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1256) (quickSound1256 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1460) (quickSound1460 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1463) (quickSound1463 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1448) (quickSound1448 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1451) (quickSound1451 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1180) (quickSound1180 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5292) (quickSound5292 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1160) (quickSound1160 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6616) (quickSound6616 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule1443) (quickSound1443 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live120614,live119449,live92707,live92718,live113151,live112910,live98060,live97906,live92728], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live120614) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym3] (L := live120614) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live119449) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym3] (L := live119449) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live92707) (quotient92707 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live92718) (PetersenFastSymmetry.move [thinSym0] (L := live92718) (V := live92707) (by decide +kernel) (quotient92707 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live113151) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live113151) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112910) (PetersenFastSymmetry.move [thinSym0,thinSym1,thinSym2,thinSym3,thinSym1,thinSym2] (L := live112910) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live98060) (PetersenFastSymmetry.move [thinSym3] (L := live98060) (V := live97906) (by decide +kernel) (quotient97906 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live97906) (quotient97906 h) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live92728) (PetersenFastSymmetry.move [thinSym1,thinSym2,thinSym3,thinSym1,thinSym2,thinSym0] (L := live92728) (V := live92707) (by decide +kernel) (quotient92707 h)) <|
      PetersenLocalChildren.nil
end Full18
