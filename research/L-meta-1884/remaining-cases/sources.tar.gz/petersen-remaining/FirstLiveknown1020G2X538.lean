import Q1020K12Closing
import ThetaClosing
import first8.LiveProgram
open PetersenLayerCheck PetersenWordCost PetersenPackedPin
namespace PetersenLive8
set_option maxRecDepth 300000
set_option maxHeartbeats 0
theorem theFirstLiveknown1020G2X538 : NoAtMost Orbits1020Cost12.s2_538 Orbits1020Cost12.tgt 10 :=
  PetersenLiveCofactor.lower (by decide) (by decide +kernel) (by decide +kernel) 3 (by decide +kernel)
    [(18,19),(19,17),(18,22),(32,40),(64,80),(1,33),(18,82),(18,146)] (by decide +kernel) (Orbits1020Cost12.b2_538 ThetaCert.bound)
#print axioms theFirstLiveknown1020G2X538
end PetersenLive8
