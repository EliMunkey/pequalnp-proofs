import PetersenProjectedRule
import Full18FastBases
import Full18Data7
import Full18Data8
import Full18ThinView2
import Full18ThinView3
import Full18ThinView9
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quickSound7469 (h : Needs) : Correct rule7469 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7469) (t := Root17.tgt) SEP43 ONES43 thinBasis11 TG43 (baseThin11 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7474 (h : Needs) : Correct rule7474 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7474) (t := Root17.tgt) SEP43 ONES43 thinBasis9 TG43 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7476 (h : Needs) : Correct rule7476 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7476) (t := Root17.tgt) SEP44 ONES44 thinBasis9 TG44 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7485 (h : Needs) : Correct rule7485 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7485) (t := Root17.tgt) SEP45 ONES45 thinBasis8 TG45 (baseThin8 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound7486 (h : Needs) : Correct rule7486 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7486) (t := Root17.tgt) SEP45 ONES45 thinBasis8 TG45 (baseThin8 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound7493 (h : Needs) : Correct rule7493 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7493) (t := Root17.tgt) SEP45 ONES45 thinBasis8 TG45 (baseThin8 h) (by decide +kernel) [(false,(6,true),(3,true)),(false,(2,true),(4,true))] rfl (by decide +kernel)
theorem quickSound7496 (h : Needs) : Correct rule7496 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7496) (t := Root17.tgt) SEP45 ONES45 thinBasis8 TG45 (baseThin8 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7501 (h : Needs) : Correct rule7501 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7501) (t := Root17.tgt) SEP46 ONES46 thinBasis15 TG46 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7505 (h : Needs) : Correct rule7505 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7505) (t := Root17.tgt) SEP46 ONES46 thinBasis10 TG46 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7506 (h : Needs) : Correct rule7506 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7506) (t := Root17.tgt) SEP46 ONES46 thinBasis9 TG46 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7507 (h : Needs) : Correct rule7507 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7507) (t := Root17.tgt) SEP62 ONES62 thinBasis9 TG62 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7510 (h : Needs) : Correct rule7510 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7510) (t := Root17.tgt) SEP62 ONES62 thinBasis20 TG62 (baseThin20 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7515 (h : Needs) : Correct rule7515 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7515) (t := Root17.tgt) SEP62 ONES62 thinBasis3 TG62 (baseThin3 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7517 (h : Needs) : Correct rule7517 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7517) (t := Root17.tgt) SEP46 ONES46 thinBasis8 TG46 (baseThin8 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7519 (h : Needs) : Correct rule7519 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7519) (t := Root17.tgt) SEP46 ONES46 thinBasis17 TG46 (baseThin17 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound7527 (h : Needs) : Correct rule7527 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7527) (t := Root17.tgt) SEP48 ONES48 thinBasis17 TG48 (baseThin17 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7531 (h : Needs) : Correct rule7531 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7531) (t := Root17.tgt) SEP50 ONES50 thinBasis10 TG50 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7536 (h : Needs) : Correct rule7536 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7536) (t := Root17.tgt) SEP51 ONES51 thinBasis10 TG51 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7546 (h : Needs) : Correct rule7546 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7546) (t := Root17.tgt) SEP52 ONES52 thinBasis10 TG52 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7550 (h : Needs) : Correct rule7550 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7550) (t := Root17.tgt) SEP52 ONES52 thinBasis19 TG52 (baseThin19 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound7558 (h : Needs) : Correct rule7558 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7558) (t := Root17.tgt) SEP53 ONES53 thinBasis8 TG53 (baseThin8 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound7568 (h : Needs) : Correct rule7568 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7568) (t := Root17.tgt) SEP53 ONES53 thinBasis8 TG53 (baseThin8 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7991 (h : Needs) : Correct rule7991 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7991) (t := Root17.tgt) SEP184 ONES184 thinBasis21 TG184 (baseThin21 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7992 (h : Needs) : Correct rule7992 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7992) (t := Root17.tgt) SEP57 ONES57 thinBasis10 TG57 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7993 (h : Needs) : Correct rule7993 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7993) (t := Root17.tgt) SEP57 ONES57 thinBasis9 TG57 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound7999 (h : Needs) : Correct rule7999 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule7999) (t := Root17.tgt) SEP63 ONES63 thinBasis15 TG63 (baseThin15 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8000 (h : Needs) : Correct rule8000 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8000) (t := Root17.tgt) SEP59 ONES59 thinBasis10 TG59 (baseThin10 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8001 (h : Needs) : Correct rule8001 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8001) (t := Root17.tgt) SEP59 ONES59 thinBasis9 TG59 (baseThin9 h) (by decide +kernel) [] rfl (by decide +kernel)
theorem quickSound8010 (h : Needs) : Correct rule8010 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8010) (t := Root17.tgt) SEP59 ONES59 thinBasis19 TG59 (baseThin19 h) (by decide +kernel) [(false,(0,true),(2,true))] rfl (by decide +kernel)
theorem quickSound8011 (h : Needs) : Correct rule8011 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8011) (t := Root17.tgt) SEP59 ONES59 thinBasis19 TG59 (baseThin19 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
theorem quickSound8016 (h : Needs) : Correct rule8016 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8016) (t := Root17.tgt) SEP59 ONES59 thinBasis17 TG59 (baseThin17 h) (by decide +kernel) [(false,(4,true),(5,true))] rfl (by decide +kernel)
theorem quickSound8018 (h : Needs) : Correct rule8018 Root17.tgt :=
  PetersenImplicitRows.fixed (z := rule8018) (t := Root17.tgt) SEP65 ONES65 thinBasis15 TG65 (baseThin15 h) (by decide +kernel) [(false,(1,true),(3,true))] rfl (by decide +kernel)
end Full18
