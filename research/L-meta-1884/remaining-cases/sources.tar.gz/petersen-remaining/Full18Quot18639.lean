import Full18ThinRules1
import Full18ThinRules2
import Full18ThinRules3
import Full18ThinRules4
import Full18ThinRules5
import Full18ThinRules8
import Full18ThinRules9
import Full18ThinRules10
import Full18ThinRules11
import Full18ThinRules12
import Full18ThinRules13
import Full18ThinRules14
import Full18ThinRules15
import Full18ThinSym0
import Full18ThinSym1
import Full18ThinSym2
import Full18ThinSym3
import Full18Quot92707
import Full18Quot97280
import Full18Quot97318
import PetersenProjectedRule
import Full18StepS18639
import Full18Needs
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
theorem quotient18639 (h : Needs) : Blocked Root17.tgt 14 live18639 := by
  apply stepS18639
  · change ∀ r ∈ [rule3052,rule7469,rule3064,rule8101,rule5724,rule8051,rule3251,rule5314,rule5321,rule3063,rule3249,rule3308,rule6616,rule3070,rule6610,rule2232,rule7992,rule7476,rule6664,rule5348,rule3611,rule6615,rule3601,rule7486,rule5813,rule2486,rule5547,rule3704,rule2502,rule5944,rule3770,rule3783,rule6655,rule7496,rule6716,rule2654], Correct r Root17.tgt
    exact
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3052) (quickSound3052 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7469) (quickSound7469 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3064) (quickSound3064 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8101) (quickSound8101 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5724) (quickSound5724 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule8051) (quickSound8051 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3251) (quickSound3251 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5314) (quickSound5314 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5321) (quickSound5321 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3063) (quickSound3063 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3249) (quickSound3249 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3308) (quickSound3308 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6616) (quickSound6616 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3070) (quickSound3070 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6610) (quickSound6610 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2232) (quickSound2232 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7992) (quickSound7992 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7476) (quickSound7476 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6664) (quickSound6664 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5348) (quickSound5348 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3611) (quickSound3611 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6615) (quickSound6615 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3601) (quickSound3601 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7486) (quickSound7486 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5813) (quickSound5813 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2486) (quickSound2486 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5547) (quickSound5547 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3704) (quickSound3704 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2502) (quickSound2502 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule5944) (quickSound5944 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3770) (quickSound3770 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule3783) (quickSound3783 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6655) (quickSound6655 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule7496) (quickSound7496 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule6716) (quickSound6716 h) <|
      PetersenLocalChildren.push (P := (fun r => Correct r Root17.tgt)) (x := rule2654) (quickSound2654 h) <|
      PetersenLocalChildren.nil
  · change ∀ s ∈ [live120628,live119435,live110961,live112925,live92718], Blocked Root17.tgt 13 s
    exact
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live120628) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0] (L := live120628) (V := live97318) (by decide +kernel) (quotient97318 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live119435) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2,thinSym0] (L := live119435) (V := live97280) (by decide +kernel) (quotient97280 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live110961) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live110961) (V := live97280) (by decide +kernel) (quotient97280 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live112925) (PetersenFastSymmetry.move [thinSym2,thinSym0,thinSym3,thinSym1,thinSym2] (L := live112925) (V := live97318) (by decide +kernel) (quotient97318 h)) <|
      PetersenLocalChildren.push (P := (fun s => Blocked Root17.tgt 13 s)) (x := live92718) (PetersenFastSymmetry.move [thinSym0] (L := live92718) (V := live92707) (by decide +kernel) (quotient92707 h)) <|
      PetersenLocalChildren.nil
end Full18
