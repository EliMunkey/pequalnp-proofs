import PetersenProjectedRule
import PetersenRuleMoves
import Full18States
import Full18Data6
import Full18Data7
open PetersenWordCost PetersenPackedPin PetersenProjectedRule PetersenLayerCheck
namespace Full18
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 2048
def rsFirst2 : Array (Rule 1024) := #[rule7991,rule6557]
def nsFirst2 : Array (List (BitVec 1024)) := #[live7]
def packetsFirst2 : List Nat := [6154,6154,6163,0,27685,61504,27688,2,6163,61504,6163,0,6154,6154,27688,3]
theorem stepFirst2 (valid : ∀ r∈rsFirst2.toList, Correct r Root17.tgt)
    (next : ∀ s∈nsFirst2.toList, Blocked Root17.tgt 16 s) : PetersenRootOrbit.DeadPair Root17.tgt 17 Root17.primary.toFinset (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 1024) (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 1024) := by
  apply PetersenRuleMoves.rootPair (test := PetersenRuleMoves.bank rsFirst2) (next := nsFirst2) (hs := packetsFirst2)
  · intro j s; exact PetersenRuleMoves.bank_sound valid j 16 s
  · exact next
  · decide +kernel
end Full18
