import first8.FirstNonadjExtra
import higher.UpperTable
import M189Closing
open PetersenWordCost PetersenPackedPin PetersenInducedCostTable
namespace NonadjEightStarts
set_option maxHeartbeats 0
set_option maxRecDepth 200000
def tgt : BitVec 256 := 0xfffffffffffffffcfffffffffffff0f0ffffffccffffffccffeaffc0eaeac0c0
def i7 : List (BitVec 128) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000]
def i8 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
theorem original : PetersenLayerCheck.Blocked tgt 11 i8 := by
  have eq : PetersenPackedPin.project id tgt = tgt := by decide +kernel
  have cost : NoAtMost i8 (PetersenPackedPin.project id tgt) 11 := by rw [eq];exact EightVertexLifts.mask1018_ge12
  intro m le c
  apply rejects_sound id i8 11 tgt cost (by decide +kernel) [] i8 11 _ le
  decide +kernel
def extra17 (r : Fin 128) : Fin 256 := (#[0,64,16,80,128,192,144,208,4,68,20,84,132,196,148,212,2,66,18,82,130,194,146,210,6,70,22,86,134,198,150,214,8,72,24,88,136,200,152,216,12,76,28,92,140,204,156,220,10,74,26,90,138,202,154,218,14,78,30,94,142,206,158,222,32,96,48,112,160,224,176,240,36,100,52,116,164,228,180,244,34,98,50,114,162,226,178,242,38,102,54,118,166,230,182,246,40,104,56,120,168,232,184,248,44,108,60,124,172,236,188,252,42,106,58,122,170,234,186,250,46,110,62,126,174,238,190,254] : Array (Fin 256))[r.val]?.getD 0
theorem small17 : NoAtMost i7 (PetersenPackedPin.project extra17 tgt) 10 := by
  have e : PetersenPackedPin.project extra17 tgt = (0xfffffffffffaf8f8ffeafaeaffeaf8c8 : BitVec 128) := by decide +kernel
  rw [e];exact FirstNonadjExtra.b191_0 ThetaCert.bound
theorem hot17 : forcedConst extra17 tgt = false := by decide +kernel
end NonadjEightStarts
