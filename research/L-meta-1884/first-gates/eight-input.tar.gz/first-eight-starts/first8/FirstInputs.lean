import PetersenFastNode
open PetersenWordCost PetersenPackedFrontier PetersenFrontierSearch PetersenFrontier PetersenLayerCheck
namespace PetersenFirstInputs
theorem reorder {w k : Nat} {t : BitVec w} {L V : List (BitVec w)}
    (eq : same L V = true) (h : Blocked t k V) : Blocked t k L := by
  intro m le c r
  exact h m le c (same_spec eq ▸ r)

/-- The auxiliary first-gate signal may be unused or share operands. Every initial live subset is checked. -/
theorem root {w K : Nat} {I : List (BitVec w)} {t : BitVec w} (hw : 0<w)
    (normI : ∀ a ∈ I, a.getLsbD 0 = false) (normT : t.getLsbD 0 = false)
    (hot : nonconstant (read t)) (bank : Array (List (BitVec w))) (hints : List Nat)
    (test : PetersenFastNode.walk t bank (I.sublists.map fun L => ((0 : BitVec w),L,0)) hints = true)
    (closed : ∀ b∈bank.toList, Blocked t K b) : NoAtMost I t K := by
  intro k hk W r out
  obtain ⟨U,sub,m,hm,c,tr,_⟩ := realize hw I t normI normT hot r out
  let L := I.filter (fun x => decide (x∈U))
  have eq : L.toFinset = U := by
    ext x
    simp only [L,List.mem_toFinset,List.mem_filter,decide_eq_true_eq]
    exact ⟨And.right,fun hx => ⟨List.mem_toFinset.mp (sub hx),hx⟩⟩
  have mem : L ∈ I.sublists := List.mem_sublists.mpr (List.filter_sublist ..)
  have rr : Tail signedWordGate L.toFinset m c {t} := eq ▸ to_tail tr
  have member : ((0 : BitVec w),L,0) ∈ I.sublists.map (fun l => ((0:BitVec w),l,0)) :=
    List.mem_map.mpr ⟨L,mem,rfl⟩
  exact PetersenFastNode.covers test closed member m (by omega) c rr
#print axioms root
end PetersenFirstInputs
