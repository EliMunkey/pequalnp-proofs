import first8.F0_1_1
import first8.F0_1_3
import first8.F0_2_1
import first8.F0_2_3
import first8.F0_4_1
import first8.F0_4_3
import first8.F0_6_1
import first8.F0_6_3
import first8.N0_1_0
import first8.N0_1_1
import first8.N0_1_2
import first8.N0_1_3
import first8.N0_4_0
import first8.N0_4_1
import first8.N0_4_3
import first8.N0_6_1
import first8.N0_6_2
import first8.N0_6_3
open PetersenWordCost
namespace PetersenFirstGateSurvey
set_option maxRecDepth 200000
def adjacentStarts : List (BitVec 256) := [0x2222222222222222222222222222222222222222222222222222222222222222,0x8888888888888888888888888888888888888888888888888888888888888888,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0,0xaaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa,0xaaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000,0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa0000000000000000]
theorem adjacent (g : BitVec 256) (mem : g∈adjacentStarts) : NoAtMost (g :: inputs 8) Orbits1020Cost12.tgt 12 := by
  simp only [adjacentStarts,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact PetersenEightStarts.F0_1_1
  · exact PetersenEightStarts.F0_1_3
  · exact PetersenEightStarts.F0_2_1
  · exact PetersenEightStarts.F0_2_3
  · exact PetersenEightStarts.F0_4_1
  · exact PetersenEightStarts.F0_4_3
  · exact PetersenEightStarts.F0_6_1
  · exact PetersenEightStarts.F0_6_3
#print axioms adjacent
def nonadjacentStarts : List (BitVec 256) := [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0x2222222222222222222222222222222222222222222222222222222222222222,0x4444444444444444444444444444444444444444444444444444444444444444,0x8888888888888888888888888888888888888888888888888888888888888888,0xffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaaffffaaaa,0xaaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa,0xaaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000aaaa0000,0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0x5555555555555555000000000000000055555555555555550000000000000000,0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa0000000000000000]
theorem nonadjacent (g : BitVec 256) (mem : g∈nonadjacentStarts) : NoAtMost (g :: inputs 8) NonadjEightStarts.tgt 11 := by
  simp only [nonadjacentStarts,List.mem_cons,List.not_mem_nil,or_false] at mem
  rcases mem with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact NonadjEightStarts.N0_1_0
  · exact NonadjEightStarts.N0_1_1
  · exact NonadjEightStarts.N0_1_2
  · exact NonadjEightStarts.N0_1_3
  · exact NonadjEightStarts.N0_4_0
  · exact NonadjEightStarts.N0_4_1
  · exact NonadjEightStarts.N0_4_3
  · exact NonadjEightStarts.N0_6_1
  · exact NonadjEightStarts.N0_6_2
  · exact NonadjEightStarts.N0_6_3
#print axioms nonadjacent
end PetersenFirstGateSurvey
