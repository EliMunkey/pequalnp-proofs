import first8.FirstInputs
import Q1020K12Closing
import ThetaClosing
open PetersenWordCost PetersenLayerCheck PetersenPackedPin PetersenFastNode
namespace PetersenEightStarts
open Orbits1020Cost12
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private def F0_1_3live0 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem F0_1_3closed0 : Blocked tgt 12 F0_1_3live0 := by
  exact Orbits1020Cost12.b0_0 ThetaCert.bound
private def F0_1_3live1 : List (BitVec 256) := [0x8888888888888888888888888888888888888888888888888888888888888888,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem F0_1_3closed1 : Blocked tgt 12 F0_1_3live1 := by
  intro m le c
  apply rejects_sound extra26 i7 10 tgt (small26 ThetaCert.bound) hot26 [] F0_1_3live1 12 _ le
  decide +kernel
theorem F0_1_3 : NoAtMost (0x8888888888888888888888888888888888888888888888888888888888888888 :: inputs 8) tgt 12 := by
  change NoAtMost [0x8888888888888888888888888888888888888888888888888888888888888888,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] tgt 12
  apply PetersenFirstInputs.root (by decide) (by
    intro w hw; simp only [List.mem_cons,List.not_mem_nil,or_false] at hw
    rcases hw with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro x; have e := congrFun x (3:Fin 256);change true = false at e; contradiction
    · intro x; have e := congrFun x (0:Fin 256);change false = true at e; contradiction)
    #[F0_1_3live0,F0_1_3live1] [5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,82,82,5,35,68,68,35,35,82,82,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,134,134,5,35,68,68,35,35,162,162,5,8,8,8,74,74,74,74,5,68,68,68,74,74,74,74,5,8,8,8,82,82,82,82,5,68,68,68,82,82,82,82,5,8,8,8,74,74,74,74,5,68,68,68,74,74,74,74,5,8,8,8,134,134,134,134,5,68,68,68,517,580,580,580,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,134,134,5,35,146,146,35,35,146,146,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,134,134,5,35,162,162,35,35,162,162,5,8,8,8,134,134,134,134,5,146,146,146,146,146,146,146,5,8,8,8,134,134,134,134,5,146,146,146,146,146,146,146,5,8,8,8,134,134,134,134,5,1032,261,1032,517,1158,1158,1158,5,8,8,8,134,134,134,134,5,1032,261,1032,517,1158,1158,1158,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,82,82,5,35,68,68,35,35,82,82,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,291,291,5,35,68,68,35,35,291,291,5,8,8,8,74,74,74,74,5,68,68,68,74,74,74,74,5,8,8,8,82,82,82,82,5,68,68,68,82,82,82,82,5,8,8,8,74,74,74,74,5,68,68,68,74,74,74,74,5,8,8,8,517,520,520,520,5,68,68,68,517,580,580,580,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,291,291,5,35,261,291,35,35,291,291,5,8,8,8,35,35,42,42,5,35,42,42,35,35,42,42,5,8,8,8,35,35,291,291,5,35,261,291,35,35,291,291,5,8,8,8,517,520,520,520,5,1032,261,1032,517,8227,8234,8234,5,8,8,8,517,520,520,520,5,1032,261,1032,517,8227,16466,16466,5,8,8,8,517,520,520,520,5,1032,261,1032,517,8227,8234,8234,5,8,8,8,517,520,520,520,5,1032,261,1032,517,8227,0,1] (by decide +kernel)
  change ∀ b ∈ [F0_1_3live0,F0_1_3live1], Blocked tgt 12 b
  intro b h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl
  · exact F0_1_3closed0
  · exact F0_1_3closed1
#print axioms F0_1_3
end PetersenEightStarts
