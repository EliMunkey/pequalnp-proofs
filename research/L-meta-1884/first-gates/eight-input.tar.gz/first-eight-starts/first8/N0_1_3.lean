import first8.FirstInputs
import first8.FirstNonadjBasis
open PetersenWordCost PetersenLayerCheck PetersenPackedPin
namespace NonadjEightStarts
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private def N0_1_3L0 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem N0_1_3pf0 : Blocked tgt 11 N0_1_3L0 := by
  exact original
private def N0_1_3L1 : List (BitVec 256) := [0x8888888888888888888888888888888888888888888888888888888888888888,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem N0_1_3pf1 : Blocked tgt 11 N0_1_3L1 := by
  intro m le c
  apply rejects_sound extra17 i7 10 tgt small17 hot17 [] N0_1_3L1 11 _ le
  decide +kernel
theorem N0_1_3 : NoAtMost (0x8888888888888888888888888888888888888888888888888888888888888888 :: inputs 8) tgt 11 := by
  change NoAtMost [0x8888888888888888888888888888888888888888888888888888888888888888,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] tgt 11
  apply PetersenFirstInputs.root (by decide) (by
    intro w hw; simp only [List.mem_cons,List.not_mem_nil,or_false] at hw
    rcases hw with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro x; have e := congrFun x (6:Fin 256);change true = false at e; contradiction
    · intro x; have e := congrFun x (0:Fin 256);change false = true at e; contradiction)
    #[N0_1_3L0,N0_1_3L1] [8,8,8,8,19,19,42,42,19,19,42,42,19,19,42,42,8,8,8,8,19,19,82,82,19,19,68,68,19,19,82,82,8,8,8,8,42,42,42,42,42,42,42,42,42,42,42,42,8,8,8,8,134,134,134,134,68,68,68,68,162,162,162,162,8,8,8,8,19,19,74,74,19,19,68,68,19,19,74,74,8,8,8,8,19,19,82,82,19,19,68,68,19,19,82,82,8,8,8,8,74,74,74,74,68,68,68,68,74,74,74,74,8,8,8,8,134,134,134,134,68,68,68,68,580,580,580,580,8,8,8,8,19,19,42,42,19,19,42,42,19,19,42,42,8,8,8,8,19,19,134,134,19,19,146,146,19,19,146,146,8,8,8,8,42,42,42,42,42,42,42,42,42,42,42,42,8,8,8,8,134,134,134,134,162,162,162,162,162,162,162,162,8,8,8,8,19,19,134,134,19,19,146,146,19,19,146,146,8,8,8,8,19,19,134,134,19,19,146,146,19,19,146,146,8,8,8,8,134,134,134,134,1032,1032,1032,1032,1158,1158,1158,1158,8,8,8,8,134,134,134,134,1032,1032,1032,1032,1158,1158,1158,1158,8,8,8,8,19,19,42,42,19,19,42,42,19,19,42,42,8,8,8,8,19,19,82,82,19,19,68,68,19,19,82,82,8,8,8,8,42,42,42,42,42,42,42,42,42,42,42,42,8,8,8,8,520,520,520,520,68,68,68,68,580,580,580,580,8,8,8,8,19,19,74,74,19,19,68,68,19,19,74,74,8,8,8,8,19,19,82,82,19,19,68,68,19,19,82,82,8,8,8,8,74,74,74,74,68,68,68,68,74,74,74,74,8,8,8,8,520,520,520,520,68,68,68,68,580,580,580,580,8,8,8,8,19,19,42,42,19,19,42,42,19,19,42,42,8,8,8,8,19,19,275,275,19,19,275,275,19,19,275,275,8,8,8,8,42,42,42,42,42,42,42,42,42,42,42,42,8,8,8,8,520,520,520,520,1032,1032,1032,1032,2090,2090,2090,2090,8,8,8,8,19,19,275,275,19,19,275,275,19,19,275,275,8,8,8,8,19,19,275,275,19,19,275,275,19,19,275,275,8,8,8,8,520,520,520,520,1032,1032,1032,1032,4115,4115,8234,8234,8,8,8,8,520,520,520,520,1032,1032,1032,1032,4115,4115,0,1] (by decide +kernel)
  change ∀ b ∈ [N0_1_3L0,N0_1_3L1], Blocked tgt 11 b
  intro b h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl
  · exact N0_1_3pf0
  · exact N0_1_3pf1
#print axioms N0_1_3
end NonadjEightStarts
