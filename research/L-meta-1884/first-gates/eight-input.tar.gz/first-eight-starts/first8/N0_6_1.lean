import first8.FirstInputs
import first8.FirstNonadjBasis
open PetersenWordCost PetersenLayerCheck PetersenPackedPin
namespace NonadjEightStarts
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private def N0_6_1L0 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem N0_6_1pf0 : Blocked tgt 11 N0_6_1L0 := by
  intro m le c
  apply rejects_sound extra17 i7 10 tgt small17 hot17 [] N0_6_1L0 11 _ le
  decide +kernel
private def N0_6_1L1 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem N0_6_1pf1 : Blocked tgt 11 N0_6_1L1 := by
  exact original
private def N0_6_1L2 : List (BitVec 256) := [0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000]
private theorem N0_6_1pf2 : Blocked tgt 11 N0_6_1L2 := by
  intro m le c
  apply rejects_sound extra17 i7 10 tgt small17 hot17 [] N0_6_1L2 11 _ le
  decide +kernel
theorem N0_6_1 : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa :: inputs 8) tgt 11 := by
  change NoAtMost [0xaaaaaaaaaaaaaaaa0000000000000000aaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] tgt 11
  apply PetersenFirstInputs.root (by decide) (by
    intro w hw; simp only [List.mem_cons,List.not_mem_nil,or_false] at hw
    rcases hw with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro x; have e := congrFun x (6:Fin 256);change true = false at e; contradiction
    · intro x; have e := congrFun x (0:Fin 256);change false = true at e; contradiction)
    #[N0_6_1L0,N0_6_1L1,N0_6_1L2] [9,9,9,9,20,43,43,43,20,43,43,43,20,43,43,43,9,9,9,9,20,83,83,83,20,69,69,69,20,83,83,83,9,9,9,9,43,43,43,43,43,43,43,43,43,43,43,43,9,9,9,9,135,135,135,135,69,69,69,69,163,163,163,163,9,9,9,9,20,75,75,75,20,69,69,69,20,75,75,75,9,9,9,9,20,83,83,83,20,69,69,69,20,83,83,83,9,9,9,9,75,75,75,75,69,69,69,69,75,75,75,75,9,9,9,9,135,135,135,135,69,69,69,69,581,581,581,581,9,9,9,9,20,43,43,43,20,43,43,43,20,43,43,43,9,9,9,9,20,135,135,135,20,147,147,147,20,147,147,147,9,9,9,9,43,43,43,43,43,43,43,43,43,43,43,43,9,9,9,9,135,135,135,135,163,163,163,163,163,163,163,163,9,9,9,9,20,135,135,135,20,147,147,147,20,147,147,147,9,9,9,9,20,135,135,135,20,147,147,147,20,147,147,147,9,9,9,9,135,135,135,135,1033,1033,1033,1033,1159,1159,1159,1159,9,9,9,9,135,135,135,135,1033,1033,1033,1033,1159,1159,1159,1159,9,9,9,9,20,43,43,43,20,43,43,43,20,43,43,43,9,9,9,9,20,83,83,83,20,69,69,69,20,83,83,83,9,9,9,9,43,43,43,43,43,43,43,43,43,43,43,43,9,9,9,9,521,521,521,521,69,69,69,69,581,581,581,581,9,9,9,9,20,75,75,75,20,69,69,69,20,75,75,75,9,9,9,9,20,83,83,83,20,69,69,69,20,83,83,83,9,9,9,9,75,75,75,75,69,69,69,69,75,75,75,75,9,9,9,9,521,521,521,521,69,69,69,69,581,581,581,581,9,9,9,9,20,43,43,43,20,43,43,43,20,43,43,43,9,9,9,9,20,276,276,276,20,276,276,276,20,276,276,276,9,9,9,9,43,43,43,43,43,43,43,43,43,43,43,43,9,9,9,9,521,521,521,521,1033,1033,1033,1033,2091,2091,2091,2091,9,9,9,9,20,276,276,276,20,276,276,276,20,276,276,276,9,9,9,9,20,276,276,276,20,276,276,276,20,276,276,276,9,9,9,9,521,521,521,521,1033,1033,1033,1033,4116,8235,8235,8235,9,9,9,9,521,521,521,521,1033,1033,1033,1033,4116,0,1,2] (by decide +kernel)
  change ∀ b ∈ [N0_6_1L0,N0_6_1L1,N0_6_1L2], Blocked tgt 11 b
  intro b h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl
  · exact N0_6_1pf0
  · exact N0_6_1pf1
  · exact N0_6_1pf2
#print axioms N0_6_1
end NonadjEightStarts
