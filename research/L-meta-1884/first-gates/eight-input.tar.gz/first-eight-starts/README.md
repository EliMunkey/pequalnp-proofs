# Optimal first gates of two induced Petersen edge predicates

The Lean entry module proves two unconditional signed binary-circuit lower bounds. For the graph obtained by deleting adjacent Petersen vertices, the eight specified auxiliary truth tables leave the minimum cost at 13 gates. For deletion of nonadjacent vertices, the ten specified auxiliary truth tables leave the minimum cost at 12. Each table is an orbit representative under relabeling. The circuit may use constants, fan-out and complements freely. The final source states the exact tables.

Run `python3 replay.py /path/to/pequalnp-proofs --jobs 2` with the pinned public Lean 4.36.0 project and its mathlib dependencies. The script checks source hashes, builds the dependency closure and prints the final module's axiom audit.
