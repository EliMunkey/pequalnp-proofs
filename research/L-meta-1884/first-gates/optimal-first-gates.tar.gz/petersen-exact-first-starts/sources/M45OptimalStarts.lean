import StartClassification
import M45StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_3_3 : ¬NoAtMost (0xaa00 :: inputs 4) tgt 2 :=
  PetersenStartClassification.possible (0xaa00 :: inputs 4) tgt 2 [(false,(2,false),(3,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_2_3 : ¬NoAtMost (0xc0c0 :: inputs 4) tgt 2 :=
  PetersenStartClassification.possible (0xc0c0 :: inputs 4) tgt 2 [(false,(1,false),(4,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 16) := [0xaa00,0xc0c0]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 4) tgt 2 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 2) (x:=0xaa00) w_0_3_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 2) (x:=0xc0c0) w_1_2_3 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 16) (h : g ∈ PetersenStartClassification.firstWords 4) :
    NoAtMost (g::inputs 4) tgt 2 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M45
