import StartClassification
import M250StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_4_3 : ¬NoAtMost (0xaaaa0000aaaa0000 :: inputs 6) tgt 4 :=
  PetersenStartClassification.possible (0xaaaa0000aaaa0000 :: inputs 6) tgt 4 [(false,(2,false),(3,false)),(false,(5,false),(7,false)),(true,(2,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_2_3 : ¬NoAtMost (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 4 :=
  PetersenStartClassification.possible (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 4 [(false,(1,false),(5,false)),(false,(5,false),(7,false)),(true,(2,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_3_5_3 : ¬NoAtMost (0xff00ff0000000000 :: inputs 6) tgt 4 :=
  PetersenStartClassification.possible (0xff00ff0000000000 :: inputs 6) tgt 4 [(false,(1,false),(5,false)),(false,(3,false),(4,false)),(true,(2,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 64) := [0xaaaa0000aaaa0000,0xc0c0c0c0c0c0c0c0,0xff00ff0000000000]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 6) tgt 4 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 4) (x:=0xaaaa0000aaaa0000) w_0_4_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 4) (x:=0xc0c0c0c0c0c0c0c0) w_1_2_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 4) (x:=0xff00ff0000000000) w_3_5_3 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 64) (h : g ∈ PetersenStartClassification.firstWords 6) :
    NoAtMost (g::inputs 6) tgt 4 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M250
