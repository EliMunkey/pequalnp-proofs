import StartClassification
import M51StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_1_2_0 : ¬NoAtMost (0xfcfc :: inputs 4) tgt 2 :=
  PetersenStartClassification.possible (0xfcfc :: inputs 4) tgt 2 [(true,(4,false),(0,false)),(false,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffcc :: inputs 4) tgt 2 :=
  PetersenStartClassification.possible (0xffcc :: inputs 4) tgt 2 [(true,(3,false),(0,false)),(false,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_3_0 : ¬NoAtMost (0xfff0 :: inputs 4) tgt 2 :=
  PetersenStartClassification.possible (0xfff0 :: inputs 4) tgt 2 [(true,(2,false),(0,false)),(false,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 16) := [0xfcfc,0xffcc,0xfff0]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 4) tgt 2 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 2) (x:=0xfcfc) w_1_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 2) (x:=0xffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 2) (x:=0xfff0) w_2_3_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 16) (h : g ∈ PetersenStartClassification.firstWords 4) :
    NoAtMost (g::inputs 4) tgt 2 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M51
