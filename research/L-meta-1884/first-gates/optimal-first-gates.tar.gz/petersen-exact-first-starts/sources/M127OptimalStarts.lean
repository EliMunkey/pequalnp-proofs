import StartClassification
import M127StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafafafafafafafafafafafafafa :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xfafafafafafafafafafafafafafafafa :: inputs 7) tgt 8 [(true,(7,false),(0,false)),(false,(3,false),(0,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(true,(9,false),(10,false)),(false,(6,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_6_0 : ¬NoAtMost (0xffffffffffffffffaaaaaaaaaaaaaaaa :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xffffffffffffffffaaaaaaaaaaaaaaaa :: inputs 7) tgt 8 [(true,(3,false),(0,false)),(false,(3,false),(0,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(true,(9,false),(10,false)),(false,(6,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffccccffffccccffffccccffffcccc :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xffffccccffffccccffffccccffffcccc :: inputs 7) tgt 8 [(true,(6,false),(0,false)),(false,(2,false),(0,false)),(true,(7,false),(5,false)),(false,(7,false),(0,false)),(true,(7,false),(11,false)),(false,(7,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_5_0 : ¬NoAtMost (0xffffffffccccccccffffffffcccccccc :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xffffffffccccccccffffffffcccccccc :: inputs 7) tgt 8 [(true,(5,false),(0,false)),(false,(2,false),(0,false)),(true,(7,false),(5,false)),(false,(7,false),(0,false)),(true,(7,false),(11,false)),(false,(7,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_4_0 : ¬NoAtMost (0xfffff0f0fffff0f0fffff0f0fffff0f0 :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xfffff0f0fffff0f0fffff0f0fffff0f0 :: inputs 7) tgt 8 [(true,(3,false),(7,false)),(false,(5,false),(1,false)),(true,(7,false),(8,false)),(true,(4,false),(2,false)),(false,(5,false),(1,false)),(false,(7,false),(1,false)),(true,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_6_0 : ¬NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: inputs 7) tgt 8 [(true,(1,false),(0,false)),(false,(3,false),(0,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(true,(9,false),(10,false)),(false,(6,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_4_5_0 : ¬NoAtMost (0xffffffffffff0000ffffffffffff0000 :: inputs 7) tgt 8 :=
  PetersenStartClassification.possible (0xffffffffffff0000ffffffffffff0000 :: inputs 7) tgt 8 [(true,(2,false),(0,false)),(false,(2,false),(0,false)),(true,(7,false),(5,false)),(false,(7,false),(0,false)),(true,(7,false),(11,false)),(false,(7,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 128) := [0xfafafafafafafafafafafafafafafafa,0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffffccccffffccccffffccccffffcccc,0xffffffffccccccccffffffffcccccccc,0xfffff0f0fffff0f0fffff0f0fffff0f0,0xfffffffffffffffff0f0f0f0f0f0f0f0,0xffffffffffff0000ffffffffffff0000]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 7) tgt 8 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xfafafafafafafafafafafafafafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xffffffffffffffffaaaaaaaaaaaaaaaa) w_0_6_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xffffccccffffccccffffccccffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xffffffffccccccccffffffffcccccccc) w_1_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xfffff0f0fffff0f0fffff0f0fffff0f0) w_2_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xfffffffffffffffff0f0f0f0f0f0f0f0) w_2_6_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 8) (x:=0xffffffffffff0000ffffffffffff0000) w_4_5_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 128) (h : g ∈ PetersenStartClassification.firstWords 7) :
    NoAtMost (g::inputs 7) tgt 8 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M127
