import StartClassification
import M119StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafafafafafa :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xfafafafafafafafa :: inputs 6) tgt 5 [(true,(4,false),(5,false)),(false,(2,false),(0,false)),(true,(4,false),(0,false)),(true,(9,false),(3,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_5_0 : ¬NoAtMost (0xffffffffaaaaaaaa :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xffffffffaaaaaaaa :: inputs 6) tgt 5 [(true,(4,false),(5,false)),(false,(2,false),(0,false)),(true,(4,false),(0,false)),(true,(6,false),(3,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffccffccffccffcc :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xffccffccffccffcc :: inputs 6) tgt 5 [(true,(3,false),(6,false)),(false,(3,false),(0,false)),(true,(3,false),(0,false)),(true,(8,false),(3,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffccccffffcccc :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xffffccccffffcccc :: inputs 6) tgt 5 [(true,(3,false),(6,false)),(false,(3,false),(0,false)),(true,(3,false),(0,false)),(true,(7,false),(3,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_5_0 : ¬NoAtMost (0xfffffffff0f0f0f0 :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xfffffffff0f0f0f0 :: inputs 6) tgt 5 [(true,(4,false),(5,false)),(true,(2,false),(1,false)),(false,(3,false),(1,false)),(false,(5,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_3_4_0 : ¬NoAtMost (0xffffff00ffffff00 :: inputs 6) tgt 5 :=
  PetersenStartClassification.possible (0xffffff00ffffff00 :: inputs 6) tgt 5 [(true,(3,false),(6,false)),(true,(3,false),(1,false)),(false,(4,false),(1,false)),(false,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 64) := [0xfafafafafafafafa,0xffffffffaaaaaaaa,0xffccffccffccffcc,0xffffccccffffcccc,0xfffffffff0f0f0f0,0xffffff00ffffff00]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 6) tgt 5 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xfafafafafafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xffffffffaaaaaaaa) w_0_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xffccffccffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xffffccccffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xfffffffff0f0f0f0) w_2_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 5) (x:=0xffffff00ffffff00) w_3_4_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 64) (h : g ∈ PetersenStartClassification.firstWords 6) :
    NoAtMost (g::inputs 6) tgt 5 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M119
