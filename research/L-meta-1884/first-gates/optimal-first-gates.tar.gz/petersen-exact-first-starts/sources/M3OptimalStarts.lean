import StartClassification
import M3StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_1_3 : ¬NoAtMost (0x8 :: inputs 2) tgt 0 :=
  PetersenStartClassification.possible (0x8 :: inputs 2) tgt 0 [] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 4) := [0x8]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 2) tgt 0 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 2) tgt 0) (x:=0x8) w_0_1_3 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 4) (h : g ∈ PetersenStartClassification.firstWords 2) :
    NoAtMost (g::inputs 2) tgt 0 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M3
