import StartClassification
import M251StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafafafafafafafafafafafafafa :: inputs 7) tgt 7 :=
  PetersenStartClassification.possible (0xfafafafafafafafafafafafafafafafa :: inputs 7) tgt 7 [(false,(4,false),(0,false)),(true,(2,false),(7,false)),(true,(3,false),(9,false)),(false,(5,false),(1,false)),(false,(9,false),(1,false)),(true,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_5_0 : ¬NoAtMost (0xffffffffaaaaaaaaffffffffaaaaaaaa :: inputs 7) tgt 7 :=
  PetersenStartClassification.possible (0xffffffffaaaaaaaaffffffffaaaaaaaa :: inputs 7) tgt 7 [(false,(2,false),(0,false)),(true,(2,false),(4,false)),(true,(3,false),(9,false)),(false,(7,false),(1,false)),(false,(9,false),(1,false)),(true,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_6_0 : ¬NoAtMost (0xffffffffffffffffaaaaaaaaaaaaaaaa :: inputs 7) tgt 7 :=
  PetersenStartClassification.possible (0xffffffffffffffffaaaaaaaaaaaaaaaa :: inputs 7) tgt 7 [(false,(5,false),(0,false)),(true,(2,false),(7,false)),(true,(3,false),(5,false)),(false,(5,false),(1,false)),(false,(8,false),(1,false)),(true,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 128) := [0xfafafafafafafafafafafafafafafafa,0xffffffffaaaaaaaaffffffffaaaaaaaa,0xffffffffffffffffaaaaaaaaaaaaaaaa]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 7) tgt 7 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 7) (x:=0xfafafafafafafafafafafafafafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 7) (x:=0xffffffffaaaaaaaaffffffffaaaaaaaa) w_0_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 7) tgt 7) (x:=0xffffffffffffffffaaaaaaaaaaaaaaaa) w_0_6_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 128) (h : g ∈ PetersenStartClassification.firstWords 7) :
    NoAtMost (g::inputs 7) tgt 7 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M251
