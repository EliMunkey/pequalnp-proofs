import StartClassification
import M111StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafafafafafa :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xfafafafafafafafa :: inputs 6) tgt 6 [(false,(1,false),(5,false)),(true,(3,false),(0,false)),(false,(5,false),(6,false)),(true,(9,false),(3,false)),(true,(2,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_4_3 : ¬NoAtMost (0xaaaa0000aaaa0000 :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xaaaa0000aaaa0000 :: inputs 6) tgt 6 [(true,(1,false),(6,false)),(true,(3,false),(1,false)),(false,(5,false),(6,false)),(true,(6,false),(2,false)),(true,(2,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_5_0 : ¬NoAtMost (0xffffffffaaaaaaaa :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xffffffffaaaaaaaa :: inputs 6) tgt 6 [(false,(1,false),(5,false)),(true,(3,false),(0,false)),(false,(5,false),(6,false)),(true,(6,false),(3,false)),(true,(2,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffccffccffccffcc :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xffccffccffccffcc :: inputs 6) tgt 6 [(false,(3,false),(0,false)),(false,(2,false),(6,false)),(true,(3,false),(8,false)),(true,(5,false),(1,false)),(false,(1,false),(0,false)),(true,(4,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffccccffffcccc :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xffffccccffffcccc :: inputs 6) tgt 6 [(false,(1,false),(0,false)),(false,(4,false),(5,false)),(true,(5,false),(8,false)),(true,(5,false),(1,false)),(false,(1,false),(0,false)),(true,(4,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_5_3 : ¬NoAtMost (0xcccccccc00000000 :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xcccccccc00000000 :: inputs 6) tgt 6 [(true,(1,false),(0,false)),(true,(3,false),(5,false)),(true,(4,false),(7,false)),(false,(6,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_3_3 : ¬NoAtMost (0xf000f000f000f000 :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xf000f000f000f000 :: inputs 6) tgt 6 [(true,(3,false),(6,false)),(true,(3,false),(1,false)),(false,(3,false),(7,false)),(true,(4,false),(2,false)),(true,(2,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_5_0 : ¬NoAtMost (0xfffffffff0f0f0f0 :: inputs 6) tgt 6 :=
  PetersenStartClassification.possible (0xfffffffff0f0f0f0 :: inputs 6) tgt 6 [(false,(3,false),(4,false)),(true,(3,false),(0,false)),(false,(3,false),(7,false)),(true,(4,false),(3,false)),(true,(2,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 64) := [0xfafafafafafafafa,0xaaaa0000aaaa0000,0xffffffffaaaaaaaa,0xffccffccffccffcc,0xffffccccffffcccc,0xcccccccc00000000,0xf000f000f000f000,0xfffffffff0f0f0f0]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 6) tgt 6 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xfafafafafafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xaaaa0000aaaa0000) w_0_4_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xffffffffaaaaaaaa) w_0_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xffccffccffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xffffccccffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xcccccccc00000000) w_1_5_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xf000f000f000f000) w_2_3_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 6) (x:=0xfffffffff0f0f0f0) w_2_5_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 64) (h : g ∈ PetersenStartClassification.firstWords 6) :
    NoAtMost (g::inputs 6) tgt 6 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M111
