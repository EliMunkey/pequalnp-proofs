import StartClassification
import M47StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_1_3_0 : ¬NoAtMost (0xffccffcc :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xffccffcc :: inputs 5) tgt 4 [(true,(2,false),(5,false)),(false,(2,false),(0,false)),(false,(5,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffcccc :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xffffcccc :: inputs 5) tgt 4 [(true,(2,false),(4,false)),(false,(4,false),(0,false)),(false,(3,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 32) := [0xffccffcc,0xffffcccc]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 5) tgt 4 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xffffcccc) w_1_4_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 32) (h : g ∈ PetersenStartClassification.firstWords 5) :
    NoAtMost (g::inputs 5) tgt 4 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M47
