import StartClassification
import M15StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_1_3 : ¬NoAtMost (0x8888 :: inputs 4) tgt 3 :=
  PetersenStartClassification.possible (0x8888 :: inputs 4) tgt 3 [(true,(2,false),(4,false)),(true,(4,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_2_0 : ¬NoAtMost (0xfafa :: inputs 4) tgt 3 :=
  PetersenStartClassification.possible (0xfafa :: inputs 4) tgt 3 [(false,(2,false),(0,false)),(false,(4,false),(5,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffcc :: inputs 4) tgt 3 :=
  PetersenStartClassification.possible (0xffcc :: inputs 4) tgt 3 [(false,(3,false),(0,false)),(false,(3,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_3_3 : ¬NoAtMost (0xf000 :: inputs 4) tgt 3 :=
  PetersenStartClassification.possible (0xf000 :: inputs 4) tgt 3 [(true,(3,false),(1,false)),(true,(3,false),(1,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 16) := [0x8888,0xfafa,0xffcc,0xf000]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 4) tgt 3 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 3) (x:=0x8888) w_0_1_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 3) (x:=0xfafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 3) (x:=0xffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 4) tgt 3) (x:=0xf000) w_2_3_3 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 16) (h : g ∈ PetersenStartClassification.firstWords 4) :
    NoAtMost (g::inputs 4) tgt 3 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M15
