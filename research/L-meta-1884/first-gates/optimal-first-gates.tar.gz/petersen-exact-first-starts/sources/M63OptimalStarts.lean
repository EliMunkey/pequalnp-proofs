import StartClassification
import M63StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafafafafafa :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xfafafafafafafafa :: inputs 6) tgt 7 [(false,(2,false),(0,false)),(true,(4,false),(6,false)),(false,(6,false),(0,false)),(true,(8,false),(9,false)),(false,(5,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_3_0 : ¬NoAtMost (0xffaaffaaffaaffaa :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xffaaffaaffaaffaa :: inputs 6) tgt 7 [(false,(5,false),(0,false)),(true,(5,false),(3,false)),(false,(5,false),(0,false)),(true,(5,false),(9,false)),(false,(5,false),(0,false)),(true,(4,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_2_3 : ¬NoAtMost (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 7 [(true,(1,false),(0,false)),(true,(3,false),(7,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(true,(9,false),(2,false)),(false,(4,false),(0,false)),(true,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffccffccffccffcc :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xffccffccffccffcc :: inputs 6) tgt 7 [(true,(2,false),(6,false)),(false,(4,false),(1,false)),(true,(3,false),(6,false)),(false,(4,false),(2,false)),(false,(9,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffccccffffcccc :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xffffccccffffcccc :: inputs 6) tgt 7 [(true,(6,false),(0,false)),(false,(2,false),(0,false)),(false,(4,false),(5,false)),(true,(6,false),(8,false)),(true,(8,false),(1,false)),(false,(1,false),(0,false)),(true,(4,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_5_0 : ¬NoAtMost (0xffffffffcccccccc :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xffffffffcccccccc :: inputs 6) tgt 7 [(false,(1,false),(0,false)),(true,(6,false),(0,false)),(true,(3,false),(6,false)),(true,(5,false),(7,false)),(false,(7,false),(0,false)),(false,(3,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_4_0 : ¬NoAtMost (0xfffff0f0fffff0f0 :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xfffff0f0fffff0f0 :: inputs 6) tgt 7 [(true,(5,false),(6,false)),(false,(5,false),(1,false)),(true,(3,false),(5,false)),(false,(4,false),(2,false)),(false,(6,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_3_4_3 : ¬NoAtMost (0xff000000ff000000 :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xff000000ff000000 :: inputs 6) tgt 7 [(true,(1,false),(0,false)),(true,(6,false),(7,false)),(true,(6,false),(4,false)),(false,(6,false),(0,false)),(true,(6,false),(2,false)),(false,(4,false),(0,false)),(true,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_4_5_0 : ¬NoAtMost (0xffffffffffff0000 :: inputs 6) tgt 7 :=
  PetersenStartClassification.possible (0xffffffffffff0000 :: inputs 6) tgt 7 [(false,(1,false),(0,false)),(true,(3,false),(0,false)),(true,(3,false),(5,false)),(true,(8,false),(6,false)),(false,(8,false),(0,false)),(false,(3,false),(2,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 64) := [0xfafafafafafafafa,0xffaaffaaffaaffaa,0xc0c0c0c0c0c0c0c0,0xffccffccffccffcc,0xffffccccffffcccc,0xffffffffcccccccc,0xfffff0f0fffff0f0,0xff000000ff000000,0xffffffffffff0000]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 6) tgt 7 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xfafafafafafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xffaaffaaffaaffaa) w_0_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xc0c0c0c0c0c0c0c0) w_1_2_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xffccffccffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xffffccccffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xffffffffcccccccc) w_1_5_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xfffff0f0fffff0f0) w_2_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xff000000ff000000) w_3_4_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 6) tgt 7) (x:=0xffffffffffff0000) w_4_5_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 64) (h : g ∈ PetersenStartClassification.firstWords 6) :
    NoAtMost (g::inputs 6) tgt 7 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M63
