import StartClassification
import M31StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_1_3 : ¬NoAtMost (0x88888888 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0x88888888 :: inputs 5) tgt 6 [(true,(3,false),(0,false)),(true,(2,false),(5,false)),(true,(4,false),(6,false)),(false,(8,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafa :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xfafafafa :: inputs 5) tgt 6 [(false,(2,false),(0,false)),(true,(2,false),(5,false)),(false,(5,false),(6,false)),(false,(8,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_3_0 : ¬NoAtMost (0xffaaffaa :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xffaaffaa :: inputs 5) tgt 6 [(false,(5,false),(0,false)),(true,(2,false),(4,false)),(false,(6,false),(5,false)),(false,(5,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_0_4_3 : ¬NoAtMost (0xaaaa0000 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xaaaa0000 :: inputs 5) tgt 6 [(true,(4,false),(0,false)),(true,(2,false),(4,false)),(true,(7,false),(5,false)),(false,(5,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_2_3 : ¬NoAtMost (0xc0c0c0c0 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xc0c0c0c0 :: inputs 5) tgt 6 [(true,(4,false),(0,false)),(true,(3,false),(6,false)),(true,(5,false),(7,false)),(false,(4,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffccffcc :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xffccffcc :: inputs 5) tgt 6 [(false,(3,false),(0,false)),(true,(3,false),(6,false)),(false,(6,false),(7,false)),(false,(4,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffcccc :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xffffcccc :: inputs 5) tgt 6 [(false,(1,false),(0,false)),(true,(3,false),(5,false)),(false,(7,false),(6,false)),(false,(6,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_3_3 : ¬NoAtMost (0xf000f000 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xf000f000 :: inputs 5) tgt 6 [(true,(5,false),(0,false)),(true,(4,false),(2,false)),(true,(6,false),(3,false)),(false,(5,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_2_4_0 : ¬NoAtMost (0xfffff0f0 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xfffff0f0 :: inputs 5) tgt 6 [(false,(4,false),(0,false)),(true,(4,false),(2,false)),(false,(7,false),(3,false)),(false,(5,false),(1,false)),(true,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_3_4_3 : ¬NoAtMost (0xff000000 :: inputs 5) tgt 6 :=
  PetersenStartClassification.possible (0xff000000 :: inputs 5) tgt 6 [(true,(1,false),(0,false)),(true,(5,false),(3,false)),(true,(7,false),(4,false)),(false,(6,false),(1,false)),(false,(3,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 32) := [0x88888888,0xfafafafa,0xffaaffaa,0xaaaa0000,0xc0c0c0c0,0xffccffcc,0xffffcccc,0xf000f000,0xfffff0f0,0xff000000]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 5) tgt 6 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0x88888888) w_0_1_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xfafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xffaaffaa) w_0_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xaaaa0000) w_0_4_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xc0c0c0c0) w_1_2_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xf000f000) w_2_3_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xfffff0f0) w_2_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 6) (x:=0xff000000) w_3_4_3 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 32) (h : g ∈ PetersenStartClassification.firstWords 5) :
    NoAtMost (g::inputs 5) tgt 6 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M31
