import StartClassification
import M55StartLabeled
open PetersenPackedPin PetersenWordCost PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
private theorem w_0_2_0 : ¬NoAtMost (0xfafafafa :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xfafafafa :: inputs 5) tgt 4 [(false,(2,false),(0,false)),(true,(5,false),(6,false)),(false,(3,false),(0,false)),(true,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_2_3 : ¬NoAtMost (0xc0c0c0c0 :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xc0c0c0c0 :: inputs 5) tgt 4 [(true,(1,false),(0,false)),(true,(3,false),(5,false)),(true,(7,false),(0,false)),(false,(2,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_3_0 : ¬NoAtMost (0xffccffcc :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xffccffcc :: inputs 5) tgt 4 [(false,(2,false),(3,false)),(true,(2,false),(0,false)),(true,(7,false),(2,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_1_4_0 : ¬NoAtMost (0xffffcccc :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xffffcccc :: inputs 5) tgt 4 [(false,(2,false),(3,false)),(true,(2,false),(0,false)),(true,(6,false),(2,false)),(false,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
private theorem w_3_4_0 : ¬NoAtMost (0xffffff00 :: inputs 5) tgt 4 :=
  PetersenStartClassification.possible (0xffffff00 :: inputs 5) tgt 4 [(true,(1,false),(3,false)),(false,(2,false),(1,false)),(false,(4,false),(1,false)),(true,(1,false),(0,false))] (by decide +kernel) (by decide +kernel)
def possibleStarts : List (BitVec 32) := [0xfafafafa,0xc0c0c0c0,0xffccffcc,0xffffcccc,0xffffff00]
theorem possible_of_mem : ∀ g ∈ possibleStarts, ¬NoAtMost (g::inputs 5) tgt 4 :=
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xfafafafa) w_0_2_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xc0c0c0c0) w_1_2_3 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xffccffcc) w_1_3_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xffffcccc) w_1_4_0 <|
  PetersenLocalChildren.push (P:=fun g => ¬NoAtMost (g::inputs 5) tgt 4) (x:=0xffffff00) w_3_4_0 <|
  PetersenLocalChildren.nil
theorem optimal_starts (g : BitVec 32) (h : g ∈ PetersenStartClassification.firstWords 5) :
    NoAtMost (g::inputs 5) tgt 4 ↔ g ∈ forbidden :=
  PetersenStartClassification.classify (good:=possibleStarts) (by decide +kernel) all_forbidden possible_of_mem g h
#print axioms optimal_starts
end PetersenSmallStarts.M55
