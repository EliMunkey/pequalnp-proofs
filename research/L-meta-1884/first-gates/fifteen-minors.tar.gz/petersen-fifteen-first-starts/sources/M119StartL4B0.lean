import M119StartData
import M119StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b10 : Blocked tgt 4 s10 := by
  apply PetersenFastNode.node (nxt := #[s11]) (hints := [195,195,2918,2534,2469,2534,2658,2914,2662,2658,838,2886,870,838,2469,2534,2469,2534,387,2661,387,707,707,869,2179,707,2274,2278,2530,2274,454,486,2502,454,387,0,2179,387]) (by decide +kernel)
  change ∀ b ∈ [s11], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.nil
theorem b12 : Blocked tgt 4 s12 := by
  apply PetersenFastNode.node (nxt := #[s11]) (hints := [1235,1235,838,454,1429,454,838,1350,0,838,578,834,582,578,1429,454,1429,454,707,1350,1731,1350,1427,1621,1427,1747,454,405,1350,454,194,198,450,194,1090,1094,1346,1090]) (by decide +kernel)
  change ∀ b ∈ [s11], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M119
