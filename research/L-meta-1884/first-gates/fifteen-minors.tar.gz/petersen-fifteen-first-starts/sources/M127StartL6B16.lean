import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b457 : Blocked tgt 6 s457 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s457 6 _ le
  decide +kernel
theorem b458 : Blocked tgt 6 s458 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s458 6 _ le
  decide +kernel
theorem b459 : Blocked tgt 6 s459 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s459 6 _ le
  decide +kernel
theorem b460 : Blocked tgt 6 s460 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s460 6 _ le
  decide +kernel
theorem b461 : Blocked tgt 6 s461 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s461 6 _ le
  decide +kernel
theorem b462 : Blocked tgt 6 s462 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s462 6 _ le
  decide +kernel
theorem b463 : Blocked tgt 6 s463 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s463 6 _ le
  decide +kernel
theorem b464 : Blocked tgt 6 s464 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,6578,6836,13610,901,901,13610,5930,5672,5930,1669,7474,1669,7474,2693,7466,2693,7466,4741,13578,4741,9482,6836,6578,6578,6836,5930,6324,5930,6058,6578,4522,7474,6578,7466,4530,7466,4514,2450,2482,6546,2450,8577,5930,9089,5930,1669,7474,1669,7474,2693,7466,2693,7466,4741,11060,4741,9093,6962,4906,7474,6962,5930,4914,7466,5930,1802,1834,5898,1802,1669,7466,7458,7458,3346,3378,7442,3346,3338,3370,7434,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b465 : Blocked tgt 6 s465 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s465 6 _ le
  decide +kernel
theorem b466 : Blocked tgt 6 s466 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s466 6 _ le
  decide +kernel
theorem b467 : Blocked tgt 6 s467 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s467 6 _ le
  decide +kernel
theorem b468 : Blocked tgt 6 s468 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s468 6 _ le
  decide +kernel
theorem b469 : Blocked tgt 6 s469 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s469 6 _ le
  decide +kernel
theorem b470 : Blocked tgt 6 s470 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s470 6 _ le
  decide +kernel
theorem b483 : Blocked tgt 6 s483 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s483 6 _ le
  decide +kernel
theorem b484 : Blocked tgt 6 s484 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s484 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
