import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B17
import M127StartL6B18
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b523 : Blocked tgt 7 s523 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s523 7 _ le
  decide +kernel
theorem b524 : Blocked tgt 7 s524 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s524 7 _ le
  decide +kernel
theorem b525 : Blocked tgt 7 s525 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s525 7 _ le
  decide +kernel
theorem b526 : Blocked tgt 7 s526 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s526 7 _ le
  decide +kernel
theorem b527 : Blocked tgt 7 s527 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s527 7 _ le
  decide +kernel
theorem b528 : Blocked tgt 7 s528 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s528 7 _ le
  decide +kernel
theorem b529 : Blocked tgt 7 s529 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s529 7 _ le
  decide +kernel
theorem b530 : Blocked tgt 7 s530 := by
  apply PetersenFastNode.node (nxt := #[s531,s532,s533]) (hints := [1421,1421,13000,9160,11095,9160,13516,9932,12488,9932,13000,9928,12492,9928,13000,0,13000,10952,3341,10952,4744,12936,4808,4744,11095,9160,11095,9160,1805,9932,1805,9932,4493,5517,9928,5517,6549,3341,10952,3341,10952,5517,5323,9485,5517,9676,8648,9932,9676,9160,8652,9928,9160,11095,9160,9160,11095,9160,9047,10952,9160,904,968,9096,904,2837,9928,9924,9924,2837,9932,9932,2837,9932,10440,11468,9932,1676,1740,9868,1676,9928,3349,9928,10444,10952,9928,1672,1736,9864,1672,1,10952,2,10952,10517,9485,10517,9485,2696,2760,10888,2696]) (by decide +kernel)
  change ∀ b ∈ [s531,s532,s533], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s531) b531 <|
    PetersenLocalChildren.push (x := s532) b532 <|
    PetersenLocalChildren.push (x := s533) b533 <|
    PetersenLocalChildren.nil
theorem b534 : Blocked tgt 7 s534 := by
  apply PetersenFastNode.node (nxt := #[s535,s536,s537,s538,s539]) (hints := [15225,906,15225,906,5935,1678,5935,5357,9738,5357,1674,6905,6905,7471,2698,7471,2698,0,4746,5325,4746,5551,5551,1422,394,1678,1422,906,398,1674,906,15225,906,906,15225,906,13177,2698,906,906,11129,4746,906,6969,906,906,6969,6967,1674,1670,1670,6967,1678,1678,6967,1678,2186,3214,1678,1678,4234,5262,1678,5935,1678,1678,5935,1674,7479,1674,2190,2698,1674,1674,4238,4746,1674,14647,1674,1674,13615,1,2698,2,2698,3,4746,4,4746,14647,13615,14647,13615,2698,3375,4746,2698,7471,2698,2698,7471,9487,4746,4746,13583]) (by decide +kernel)
  change ∀ b ∈ [s535,s536,s537,s538,s539], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s535) b535 <|
    PetersenLocalChildren.push (x := s536) b536 <|
    PetersenLocalChildren.push (x := s537) b537 <|
    PetersenLocalChildren.push (x := s538) b538 <|
    PetersenLocalChildren.push (x := s539) b539 <|
    PetersenLocalChildren.nil
theorem b540 : Blocked tgt 7 s540 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s540 7 _ le
  decide +kernel
theorem b541 : Blocked tgt 7 s541 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s541 7 _ le
  decide +kernel
theorem b542 : Blocked tgt 7 s542 := by
  apply PetersenFastNode.node (nxt := #[s543]) (hints := [4523,9798,4523,13545,9158,8650,5931,9926,9922,9922,9926,15989,9926,10442,10950,9926,9926,12490,12998,9926,1670,1734,9862,1670,13545,9158,15221,13545,13545,9802,13929,13545,13545,6579,13545,11338,15465,13545,395,13514,13513,13513,5289,5353,13481,5289,9930,8646,9930,8642,15221,9158,9158,15221,11466,13173,11466,9158,13514,11125,13514,9158,902,966,9094,902,6963,9930,9930,6963,9930,10438,11466,9930,9930,9833,13514,9930,1674,1738,9866,1674,0,11466,7459,11466,3347,13514,7443,13514,7475,12587,14643,7475,11466,11369,13514,11466,3210,3274,11402,3210,5258,5322,13450,5258]) (by decide +kernel)
  change ∀ b ∈ [s543], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s543) b543 <|
    PetersenLocalChildren.nil
theorem b544 : Blocked tgt 7 s544 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s544 7 _ le
  decide +kernel
theorem b545 : Blocked tgt 7 s545 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s545 7 _ le
  decide +kernel
theorem b546 : Blocked tgt 7 s546 := by
  apply PetersenFastNode.node (nxt := #[s547,s548,s549,s550]) (hints := [5550,13548,5550,15096,9161,9161,5934,9933,5934,9933,7478,9929,7478,9929,7470,10953,7470,10953,0,13001,1,13001,13614,2,13614,3,13548,5550,15224,13548,13548,9805,13932,13548,9801,9801,13548,9929,13548,10953,15468,10953,1422,13001,13516,13001,5292,5356,13484,5292,9933,5934,9933,5934,9929,7478,9929,15224,10953,13176,10953,13160,13001,11128,13001,11096,6968,7032,15160,6968,6966,9929,9925,9925,9933,10441,11469,9933,9933,12489,13517,9933,1677,1741,9869,1677,9929,10445,10953,9929,9929,12493,13001,9929,1673,1737,9865,1673,10953,11372,13001,10953,2697,2761,10889,2697,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s547,s548,s549,s550], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s547) b547 <|
    PetersenLocalChildren.push (x := s548) b548 <|
    PetersenLocalChildren.push (x := s549) b549 <|
    PetersenLocalChildren.push (x := s550) b550 <|
    PetersenLocalChildren.nil
theorem b551 : Blocked tgt 7 s551 := by
  apply PetersenFastNode.node (nxt := #[s552,s556,s557,s558,s548]) (hints := [11129,1423,11129,9709,1423,9806,1807,1423,399,1423,9930,1423,2455,1423,10954,3343,1423,0,1423,1423,13002,1423,5357,9487,1423,9934,1807,9934,9581,9930,9581,9930,11129,11129,9581,9581,11129,10954,9081,10954,9065,9162,9162,2873,2937,11065,2873,2839,9930,9926,9926,2839,9934,9934,2839,9934,10442,11470,9934,9934,12490,13518,9934,1678,1742,9870,1678,9930,3351,9930,10446,10954,9930,9930,12494,13002,9930,1674,1738,9866,1674,1,10954,2,10954,3,13002,4,13002,10519,9487,10519,9487,10954,3343,13002,10954,2698,2762,10890,2698,4746,4810,12938,4746]) (by decide +kernel)
  change ∀ b ∈ [s552,s556,s557,s558,s548], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s552) b552 <|
    PetersenLocalChildren.push (x := s556) b556 <|
    PetersenLocalChildren.push (x := s557) b557 <|
    PetersenLocalChildren.push (x := s558) b558 <|
    PetersenLocalChildren.push (x := s548) b548 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
