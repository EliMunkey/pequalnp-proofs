import M127StartData
import M127StartPins0
import M127StartL6B9
import M127StartL6B8
import M127StartL6B7
import M127StartL6B10
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b279 : Blocked tgt 7 s279 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s279 7 _ le
  decide +kernel
theorem b280 : Blocked tgt 7 s280 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s280 7 _ le
  decide +kernel
theorem b281 : Blocked tgt 7 s281 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s281 7 _ le
  decide +kernel
theorem b282 : Blocked tgt 7 s282 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s282 7 _ le
  decide +kernel
theorem b283 : Blocked tgt 7 s283 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s283 7 _ le
  decide +kernel
theorem b284 : Blocked tgt 7 s284 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s284 7 _ le
  decide +kernel
theorem b285 : Blocked tgt 7 s285 := by
  apply PetersenFastNode.node (nxt := #[s286,s272,s287,s229]) (hints := [13614,0,13614,5550,1,5550,6968,6968,1677,5934,1677,5934,1673,7478,1673,7478,2697,7470,2697,7470,4745,13582,4745,9486,5550,6840,9097,9097,5934,1677,5934,1677,7478,1673,7478,1673,7470,2697,7470,2697,2,4745,3,4745,15160,5550,15288,5550,1677,5934,5550,6582,4526,7478,6582,5550,4534,7470,5550,1422,1454,5518,1422,1677,5934,1677,5934,1673,7478,1673,7478,2697,7470,2697,7470,4745,11064,4745,11032,6966,4910,7478,6966,5934,4918,7470,5934,1806,1838,5902,1806,1673,7470,7462,7462,3350,3382,7446,3350,3342,3374,7438,3342]) (by decide +kernel)
  change ∀ b ∈ [s286,s272,s287,s229], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s286) b286 <|
    PetersenLocalChildren.push (x := s272) b272 <|
    PetersenLocalChildren.push (x := s287) b287 <|
    PetersenLocalChildren.push (x := s229) b229 <|
    PetersenLocalChildren.nil
theorem b288 : Blocked tgt 7 s288 := by
  apply PetersenFastNode.node (nxt := #[s289,s231,s201,s290,s260,s291]) (hints := [5552,6842,907,907,5742,1743,5742,1743,7480,1675,7480,1675,7472,2699,7472,2699,0,4747,1,4747,13616,2,13616,3,6970,5552,7098,5552,1743,5742,1743,6584,1675,7480,1675,5552,2699,7472,2699,1424,4747,5520,4747,5552,4,13616,5552,1743,6970,1743,5998,1675,7224,1675,6970,2699,4922,2699,4906,4747,2874,4747,2842,5,6970,6970,13614,7480,1675,1735,1675,1743,2699,3791,1743,1743,4747,5839,1743,1679,1679,1675,10447,2699,1675,1675,12495,4747,1675,7480,1675,1675,7480,2699,3376,4747,2699,3215,2699,2699,3215,5263,4747,4747,5263]) (by decide +kernel)
  change ∀ b ∈ [s289,s231,s201,s290,s260,s291], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s289) b289 <|
    PetersenLocalChildren.push (x := s231) b231 <|
    PetersenLocalChildren.push (x := s201) b201 <|
    PetersenLocalChildren.push (x := s290) b290 <|
    PetersenLocalChildren.push (x := s260) b260 <|
    PetersenLocalChildren.push (x := s291) b291 <|
    PetersenLocalChildren.nil
theorem b293 : Blocked tgt 7 s293 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s293 7 _ le
  decide +kernel
theorem b294 : Blocked tgt 7 s294 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s294 7 _ le
  decide +kernel
theorem b295 : Blocked tgt 7 s295 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s295 7 _ le
  decide +kernel
theorem b297 : Blocked tgt 7 s297 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s297 7 _ le
  decide +kernel
theorem b298 : Blocked tgt 7 s298 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s298 7 _ le
  decide +kernel
theorem b299 : Blocked tgt 7 s299 := by
  apply PetersenFastNode.node (nxt := #[s300,s301,s302,s303,s304,s305,s306,s307,s308,s309,s310,s311,s312,s313]) (hints := [15106,15106,15234,8659,0,8659,14850,1,15234,14850,15106,8659,5944,13558,5944,9815,15106,9943,5560,15106,5944,5560,13558,9943,7488,15106,7488,9811,13558,9939,7488,13558,7488,15106,15106,9939,7480,13042,7480,13058,15106,10963,7480,15106,7480,13042,13042,10963,10978,10978,2,11010,15106,13011,15074,15106,3,10978,10978,13011,13624,6850,13624,6914,15106,4,13624,15106,13624,6850,6850,5,9943,13686,9943,8659,8659,5944,9687,8659,9943,9687,13686,5944,8659,8659,9939,7232,13686,7488,9683,13686,9939,8659,8659,7488,8659,8659,10963,13186,15234,7480,10707,15234,10963,8659,8659,7480,8659,8659,13011,11138,15234,6,12755,15234,13011,8659,8659,7,403,403,8,467,8659,13624,8595,8659,9,403,403,13624,6976,6976,7488,9939,9943,9939,9935,9943,7488,9935,6976,9939,9943,9943,11479,10451,6976,10963,11479,6976,11479,9943,9943,10963,9943,9943,13527,12499,5944,13011,13527,5944,13527,9943,9943,13011,1687,1687,13624,1751,9943,10,9879,9943,13624,1687,1687,11,9939,9939,10963,10455,7488,11479,10963,7488,10963,9939,9939,11479,9939,9939,13011,12503,7488,13527,13011,7488,13011,9939,9939,13527,1683,1683,14656,1747,9939,13624,9875,9939,14656,1683,1683,13624,10963,10963,13011,3384,7480,12,13011,7480,13011,10963,10963,13,2707,2707,13624,2771,10963,14656,10899,10963,13624,2707,2707,14656,4755,4755,9496,4819,13011,13624,12947,13011,9496,4755,4755,13624]) (by decide +kernel)
  change ∀ b ∈ [s300,s301,s302,s303,s304,s305,s306,s307,s308,s309,s310,s311,s312,s313], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s300) b300 <|
    PetersenLocalChildren.push (x := s301) b301 <|
    PetersenLocalChildren.push (x := s302) b302 <|
    PetersenLocalChildren.push (x := s303) b303 <|
    PetersenLocalChildren.push (x := s304) b304 <|
    PetersenLocalChildren.push (x := s305) b305 <|
    PetersenLocalChildren.push (x := s306) b306 <|
    PetersenLocalChildren.push (x := s307) b307 <|
    PetersenLocalChildren.push (x := s308) b308 <|
    PetersenLocalChildren.push (x := s309) b309 <|
    PetersenLocalChildren.push (x := s310) b310 <|
    PetersenLocalChildren.push (x := s311) b311 <|
    PetersenLocalChildren.push (x := s312) b312 <|
    PetersenLocalChildren.push (x := s313) b313 <|
    PetersenLocalChildren.nil
theorem b314 : Blocked tgt 7 s314 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s314 7 _ le
  decide +kernel
theorem b315 : Blocked tgt 7 s315 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s315 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
