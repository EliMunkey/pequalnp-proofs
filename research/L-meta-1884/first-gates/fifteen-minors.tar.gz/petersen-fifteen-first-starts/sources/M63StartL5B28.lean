import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1053 : Blocked tgt 5 s1053 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1053 5 _ le
  decide +kernel
theorem b1054 : Blocked tgt 5 s1054 := by
  apply PetersenFastNode.node (nxt := #[s1055]) (hints := [2665,2667,2793,2665,1235,2795,2795,1235,1235,2795,2795,1235,1707,1235,1707,1771,715,747,2763,715,454,714,838,454,194,714,714,194,714,454,842,714,714,405,2634,714,838,1683,1451,838,838,842,838,2634,1350,838,0,842,1427,842,1094,2634,2114,2634,842,1350,1610,842]) (by decide +kernel)
  change ∀ b ∈ [s1055], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1055) b1055 <|
    PetersenLocalChildren.nil
theorem b1060 : Blocked tgt 5 s1060 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3762,3314,2274,3314,837,453,193,453,833,837,833,3506,837,1349,1089,837,837,2373,2113,837,3444,389,3508,3444,3314,3188,3506,3314,2404,3314,3314,2404,1234,1266,3282,1234,193,453,453,3504,453,2484,1349,453,453,1460,2373,453,1093,1093,3506,1349,1426,2373,3474,2373,1349,1698,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1062 : Blocked tgt 5 s1062 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1706,1770,1234,1706,193,453,193,453,1706,841,1426,841,1682,837,1682,837,1349,1349,1089,2373,2404,389,2468,2404,2794,777,2986,2794,2404,2794,2794,2404,714,746,2762,714,713,453,841,713,453,713,837,453,453,420,2373,453,2474,837,841,837,841,2373,2633,841,837,2633,2373,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1069 : Blocked tgt 5 s1069 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1069 5 _ le
  decide +kernel
theorem b1073 : Blocked tgt 5 s1073 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1073 5 _ le
  decide +kernel
theorem b1074 : Blocked tgt 5 s1074 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3508,3444,389,3444,713,841,197,713,453,837,201,453,453,1349,2484,453,453,2373,1460,453,3188,841,3444,841,3444,837,3956,3444,2404,2420,3428,2404,1364,1396,3412,1364,3504,837,833,833,841,1093,1609,841,841,2117,2633,841,837,1097,1349,837,837,2121,2373,837,1349,1576,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1075 : Blocked tgt 5 s1075 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1075 5 _ le
  decide +kernel
theorem b1076 : Blocked tgt 5 s1076 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1076 5 _ le
  decide +kernel
theorem b1085 : Blocked tgt 5 s1085 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,389,1428,1364,2794,777,2986,2794,1234,2282,1682,1234,1706,1234,1706,1770,714,746,2762,714,713,453,841,713,453,201,705,453,713,453,453,713,453,404,1349,453,1426,841,833,833,841,1426,1706,841,841,1093,2633,841,837,837,1682,1698,1349,2121,1349,1861,2633,1349,1609,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1093 : Blocked tgt 5 s1093 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1093 5 _ le
  decide +kernel
theorem b1094 : Blocked tgt 5 s1094 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2274,2404,2274,2404,837,453,193,453,833,2466,837,1349,1089,837,837,2373,2113,837,2404,389,2468,2404,2274,2404,2404,2274,2404,1349,3428,2404,194,2373,2372,2372,193,453,453,193,453,3618,1349,453,453,420,2373,453,833,1349,1089,1349,833,2373,2113,2373,1349,1698,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1102 : Blocked tgt 5 s1102 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [837,1093,2994,837,3314,3188,3314,3506,837,3506,3504,3504,3506,2466,1426,1458,3474,1426,2404,2420,2404,3428,453,2484,453,1349,1349,1089,1349,2962,2373,1349,3444,389,3508,3444,2274,3444,3444,2274,1364,1396,3412,1364,193,3508,3508,193,1428,1460,3476,1428,833,2373,2113,2373]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1103 : Blocked tgt 5 s1103 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1103 5 _ le
  decide +kernel
theorem b1104 : Blocked tgt 5 s1104 := by
  apply PetersenFastNode.node (nxt := #[s1105]) (hints := [2795,1109,2795,1427,714,454,714,454,838,838,842,1443,2634,1094,2634,1350,1365,390,1429,1365,1365,2283,1683,1365,1707,1365,1365,1771,715,1350,1349,1349,454,202,706,454,714,454,454,714,454,405,1350,454,0,842,834,834,1350,2122,1350,2626,842,1350,1610,1350]) (by decide +kernel)
  change ∀ b ∈ [s1105], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1105) b1105 <|
    PetersenLocalChildren.nil
theorem b1108 : Blocked tgt 5 s1108 := by
  apply PetersenFastNode.node (nxt := #[s1109]) (hints := [838,454,194,454,3507,3507,3315,3445,3315,3445,838,1350,2869,838,838,2374,805,838,194,454,454,194,3445,390,3445,3509,454,2485,1350,454,454,1461,2374,454,3315,3445,3315,3445,2979,1350,1090,1350,899,2374,2947,2374,2405,2421,3429,2405,1365,1397,3413,1365,1350,0,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s1109], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1109) b1109 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
