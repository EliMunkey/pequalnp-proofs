import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b912 : Blocked tgt 5 s912 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s912 5 _ le
  decide +kernel
theorem b913 : Blocked tgt 5 s913 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s913 5 _ le
  decide +kernel
theorem b914 : Blocked tgt 5 s914 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s914 5 _ le
  decide +kernel
theorem b929 : Blocked tgt 5 s929 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s929 5 _ le
  decide +kernel
theorem b930 : Blocked tgt 5 s930 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s930 5 _ le
  decide +kernel
theorem b938 : Blocked tgt 5 s938 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(true,(0,false),(4,false))] s938 5 _ le
  decide +kernel
theorem b939 : Blocked tgt 5 s939 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s939 5 _ le
  decide +kernel
theorem b940 : Blocked tgt 5 s940 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(true,(0,false),(4,false))] s940 5 _ le
  decide +kernel
theorem b941 : Blocked tgt 5 s941 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2274,1428,1364,2274,777,2466,2274,1234,2274,1682,1234,1698,1234,1698,1762,194,226,2242,194,201,2466,457,201,837,201,453,453,201,1428,1428,201,2373,1428,2373,201,1426,837,833,833,841,1426,1698,841,841,2117,2633,841,837,1682,1682,837,837,2121,2373,837,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b942 : Blocked tgt 5 s942 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(true,(0,false),(4,false))] s942 5 _ le
  decide +kernel
theorem b946 : Blocked tgt 5 s946 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(false,(0,true),(4,false))] s946 5 _ le
  decide +kernel
theorem b947 : Blocked tgt 5 s947 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s947 5 _ le
  decide +kernel
theorem b948 : Blocked tgt 5 s948 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s948 5 _ le
  decide +kernel
theorem b949 : Blocked tgt 5 s949 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s949 5 _ le
  decide +kernel
theorem b950 : Blocked tgt 5 s950 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s950 5 _ le
  decide +kernel
theorem b951 : Blocked tgt 5 s951 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s951 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
