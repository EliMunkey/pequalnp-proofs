import M111StartData
import M111StartL6B1
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_1 : NoAtMost (0xcccccccc :: inputs 6) tgt 6 := by
  change NoAtMost [0xcccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s104,s0,s134] [195,197,196,389,197,197,836,389,391,197,456,840,197,197,840,840,715,717,716,909,717,717,844,909,391,717,456,1352,717,717,1352,1352,1107,1237,196,1429,1237,1237,836,1429,1367,1237,456,840,1237,1237,840,840,1627,1757,716,1949,1757,1757,844,1949,1367,1757,456,2504,1757,1757,3741,0,2211,197,2276,389,197,197,2916,389,2471,197,2536,2536,197,197,2920,2920,2731,717,2796,909,717,717,2924,909,2471,717,2536,2536,717,717,3432,3432,3187,1237,2276,1429,1237,1237,2916,1429,3447,1237,2536,2536,1237,1237,2920,2920,3707,1757,2796,1949,1757,1757,2924,1949,3447,1757,2536,2536,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s104,s0,s134], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s104) b104 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s134) b134 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_1
end PetersenSmallStarts.M111
