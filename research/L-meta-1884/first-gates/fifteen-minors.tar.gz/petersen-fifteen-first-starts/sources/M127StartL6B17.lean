import M127StartData
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b485 : Blocked tgt 6 s485 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s485 6 _ le
  decide +kernel
theorem b486 : Blocked tgt 6 s486 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s486 6 _ le
  decide +kernel
theorem b487 : Blocked tgt 6 s487 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s487 6 _ le
  decide +kernel
theorem b488 : Blocked tgt 6 s488 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s488 6 _ le
  decide +kernel
theorem b489 : Blocked tgt 6 s489 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s489 6 _ le
  decide +kernel
theorem b490 : Blocked tgt 6 s490 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(true,(0,false),(5,false))] s490 6 _ le
  decide +kernel
theorem b491 : Blocked tgt 6 s491 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s491 6 _ le
  decide +kernel
theorem b492 : Blocked tgt 6 s492 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s492 6 _ le
  decide +kernel
theorem b493 : Blocked tgt 6 s493 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s493 6 _ le
  decide +kernel
theorem b512 : Blocked tgt 6 s512 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,9093,1417,901,901,1673,1673,5672,5930,1669,7474,1669,7474,2693,3209,2693,3209,4741,5257,4741,5257,5290,5290,5546,1417,5546,6836,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,1417,5930,1929,1417,385,393,1409,385,1417,7466,3209,1417,1417,11060,5257,1417,6962,4906,7474,6962,3209,4914,3209,5930,5257,1834,5257,1802,2177,2185,2177,3201,4225,4233,4225,5249,3209,3370,5257,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b513 : Blocked tgt 6 s513 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,5288,773,5290,773,1417,5546,1673,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,6836,1417,6964,1417,13610,5930,5672,5930,14642,7474,12586,7474,13610,3209,12594,3209,9482,5257,9514,5257,1417,5802,773,1417,385,393,1409,385,1417,7466,3209,1417,1417,11060,5257,1417,6962,4906,7474,6962,3209,4914,3209,5930,5257,1834,5257,1802,2177,2185,2177,3201,4225,4233,4225,5249,3209,3370,5257,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b531 : Blocked tgt 6 s531 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s531 6 _ le
  decide +kernel
theorem b532 : Blocked tgt 6 s532 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s532 6 _ le
  decide +kernel
theorem b533 : Blocked tgt 6 s533 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3338,10949,12997,10949,1418,1418,12997,9157,9544,9157,13513,9929,12485,9929,12997,9925,12489,9925,4741,12933,4805,4741,3338,10949,10949,3338,10949,9157,9028,9157,11465,9929,10437,9929,10949,9925,10441,9925,2693,10885,2757,2693,9544,9157,9544,9157,1802,9929,1802,9929,4490,9925,5514,9925,5514,5320,9482,5514,9673,8645,9929,9673,9157,8649,9925,9157,901,965,9093,901,770,9925,9921,9921,1673,1737,9865,1673,1669,1733,9861,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b535 : Blocked tgt 6 s535 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s535 6 _ le
  decide +kernel
theorem b536 : Blocked tgt 6 s536 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(true,(0,false),(5,false))] s536 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
