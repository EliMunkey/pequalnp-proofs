import M127StartData
import M127StartL8B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :: inputs 7) tgt 8 := by
  change NoAtMost [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 8
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1] [386,387,387,387,388,388,1667,1667,774,775,903,903,388,388,1671,1671,1418,1419,1419,1419,1420,1420,1675,1675,774,775,903,903,1420,1420,2695,2695,2194,2196,387,387,2452,2452,1667,1667,2710,775,903,903,2452,2452,1671,1671,1418,1419,1419,1419,1420,1420,1675,1675,2710,775,903,903,1420,1420,4743,4743,4258,4260,387,387,4516,4516,1667,1667,4774,775,903,903,4516,4516,1671,1671,5290,5292,1419,1419,5548,5548,1675,1675,4774,775,903,903,5548,5548,2695,2695,6322,6324,387,387,6580,6580,1667,1667,6838,775,903,903,6580,6580,1671,1671,5290,5292,1419,1419,5548,5548,1675,1675,6838,775,903,903,5548,5548,13612,13612,8514,8515,8643,8643,388,388,9923,9923,9030,9031,9159,9159,388,388,9927,9927,9546,9547,9675,9675,1420,1420,9931,9931,9030,9031,9159,9159,1420,1420,10951,10951,10450,2196,8643,8643,2452,2452,9923,9923,10966,9031,9159,9159,2452,2452,9927,9927,9546,9547,9675,9675,1420,1420,9931,9931,10966,9031,9159,9159,1420,1420,12999,12999,12514,4260,8643,8643,4516,4516,9923,9923,13030,9031,9159,9159,4516,4516,9927,9927,13546,5292,9675,9675,5548,5548,9931,9931,13030,9031,9159,9159,5548,5548,10951,10951,14578,6324,8643,8643,6580,6580,9923,9923,15094,9031,9159,9159,6580,6580,9927,9927,13546,5292,9675,9675,5548,5548,9931,9931,15094,9031,9159,9159,5548,5548,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 8 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_0
end PetersenSmallStarts.M127
