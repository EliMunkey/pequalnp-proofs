import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_5_2 : NoAtMost (0xf0f0f0f00000000 :: inputs 6) tgt 7 := by
  change NoAtMost [0xf0f0f0f00000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1236] [194,2146,195,3618,196,2276,835,3748,390,2146,455,3618,196,2276,839,3748,714,2666,715,3626,716,2796,843,3756,390,2666,455,3626,716,2796,1351,3756,1106,3186,195,3634,1236,3316,835,3764,1366,3186,455,3634,1236,3316,839,3764,714,2666,715,715,716,2796,843,843,1366,2666,455,455,716,2796,2375,2375,2146,2146,195,3618,2276,2276,835,3748,2406,2146,455,3618,2276,2276,839,3748,2666,2666,715,3626,2796,2796,843,3756,2406,2666,455,3626,2796,2796,1351,3756,3186,3186,195,3634,3316,3316,835,3764,3446,3186,455,3634,3316,3316,839,3764,2666,2666,715,715,2796,2796,843,843,3446,2666,455,455,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1236], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1236) b1236 <|
    PetersenLocalChildren.nil
#print axioms gate_2_5_2
end PetersenSmallStarts.M63
