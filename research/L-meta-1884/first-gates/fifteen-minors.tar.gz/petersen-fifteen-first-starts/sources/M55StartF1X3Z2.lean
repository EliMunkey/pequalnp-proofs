import M55StartData
import M55StartL4B1
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_2 : NoAtMost (0x33003300 :: inputs 5) tgt 4 := by
  change NoAtMost [0x33003300,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s23,s0,s24] [99,299,100,100,101,299,292,548,199,431,232,232,101,431,424,680,299,299,100,100,365,299,548,548,431,431,232,232,365,431,680,680,563,827,100,100,629,827,292,725,695,959,232,232,629,959,424,0,827,827,100,100,893,827,989,989,959,959,232,232,893,959,1,2] (by decide +kernel)
  change ∀ b ∈ [s23,s0,s24], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_2
end PetersenSmallStarts.M55
