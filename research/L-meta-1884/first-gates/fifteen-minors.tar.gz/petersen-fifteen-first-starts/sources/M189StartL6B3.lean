import M189StartData
import M189StartPins0
import M189StartL5B1
import M189StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b67 : Blocked tgt 6 s67 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s67 6 _ le
  decide +kernel
theorem b68 : Blocked tgt 6 s68 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s68 6 _ le
  decide +kernel
theorem b69 : Blocked tgt 6 s69 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s69 6 _ le
  decide +kernel
theorem b70 : Blocked tgt 6 s70 := by
  apply PetersenFastNode.node (nxt := #[s71,s72]) (hints := [1430,618,1430,2439,1756,2503,1430,1756,1430,1494,618,2503,1756,1756,1948,389,0,453,1948,1,1948,1756,1756,453,1236,1236,1814,1244,1756,709,1748,1756,1814,1236,1236,709,716,716,3366,732,1756,1221,1740,1756,3366,716,716,1221,1756,1756,3740,2181,618,2245,3740,618,3740,1756,1756,2245,2243,2243,1818,2247,2503,453,2499,2503,1818,2243,2243,453,839,2503,839,709,2730,709,839,2730,839,2503,2503,709,1351,2503,1351,1221,1430,1221,1351,1430,1351,2503,2503,1221,455,1430,3350,455,2503,2245,2503,2503,3350,2245,1430,2245,453,453,709,583,1948,839,709,1948,709,453,453,839,453,453,1221,1095,1948,1351,1221,1948,1221,453,453,1351,453,453,2245,810,2858,3350,2245,2858,2245,453,453,3350,709,709,1221,790,1814,3626,1221,1814,1221,709,709,3626,709,709,2245,839,839,3740,2245,839,2245,709,709,3740,1221,1221,2245,1351,1351,3740,2245,1351,2245,1221,1221,3740]) (by decide +kernel)
  change ∀ b ∈ [s71,s72], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.push (x := s72) b72 <|
    PetersenLocalChildren.nil
theorem b73 : Blocked tgt 6 s73 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,2469,1428,1492,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,616,2664,1754,1754,2664,1364,1754,2273,2277,2529,2273,2533,707,2917,2533,2533,1219,3429,2533,1428,2533,2501,2501,453,2533,2533,1428,451,2661,707,451,451,3173,1219,451,451,2856,2856,451,451,2856,2856,451,707,788,1219,707,707,869,2885,707,707,2917,2917,707,1219,1381,3397,1219,1219,3429,3429,1219,2243,2243]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b74 : Blocked tgt 6 s74 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s74 6 _ le
  decide +kernel
theorem b75 : Blocked tgt 6 s75 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s75 6 _ le
  decide +kernel
theorem b76 : Blocked tgt 6 s76 := by
  apply PetersenFastNode.node (nxt := #[s77,s78]) (hints := [2470,1366,2470,391,1756,455,2470,1756,2470,2534,1366,455,1756,1756,3740,2181,0,2245,3740,1,3740,1756,1756,2245,1756,1756,1948,389,1366,453,1948,1366,1948,1756,1756,453,1236,1236,2854,1244,1756,709,1748,1756,2854,1236,1236,709,716,716,3366,732,1756,1221,1740,1756,3366,716,716,1221,455,455,3350,2245,2470,2245,2503,2470,3350,455,455,2245,2730,2730,2858,453,455,453,451,455,2858,451,2730,453,455,455,839,581,2730,709,839,2730,839,455,455,709,455,455,1351,1093,1430,1221,1351,1430,1351,455,455,1221,453,2245,453,810,3350,2858,453,3350,453,2245,2245,2858,709,2245,709,3228,3740,2854,709,3740,709,2245,2245,2854,1221,2245,1221,2716,3740,3366,1221,3740,1221,2245,2245,3366,453,453,709,583,1948,839,709,1948,709,453,453,839,453,453,1221,1095,1948,1351,1221,1948,1221,453,453,1351,709,709,1221,3114,1814,3626,1221,1814,1221,709,709,3626]) (by decide +kernel)
  change ∀ b ∈ [s77,s78], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.push (x := s78) b78 <|
    PetersenLocalChildren.nil
theorem b79 : Blocked tgt 6 s79 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s79 6 _ le
  decide +kernel
theorem b80 : Blocked tgt 6 s80 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s80 6 _ le
  decide +kernel
theorem b81 : Blocked tgt 6 s81 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s81 6 _ le
  decide +kernel
theorem b82 : Blocked tgt 6 s82 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s82 6 _ le
  decide +kernel
theorem b83 : Blocked tgt 6 s83 := by
  apply PetersenFastNode.node (nxt := #[s57,s71]) (hints := [1366,2471,389,1110,389,0,1756,1626,709,2855,709,1366,1221,3367,1221,3430,2245,1,2245,1366,1238,1238,1430,389,2730,1430,1430,1754,2919,709,2919,1430,3431,406,3431,2470,1430,422,3350,1430,1756,1948,2659,2663,2659,2915,3171,3175,3171,3427,389,3350,2245,389,1236,2919,1748,2919,716,3431,1740,3431,1756,2181,3740,1756,2919,790,3431,2919,839,871,2887,839,1351,1383,3399,1351]) (by decide +kernel)
  change ∀ b ∈ [s57,s71], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b84 : Blocked tgt 6 s84 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s84 6 _ le
  decide +kernel
theorem b85 : Blocked tgt 6 s85 := by
  apply PetersenFastNode.node (nxt := #[s51,s77]) (hints := [1430,2471,1948,0,1948,2666,709,2855,709,2918,1221,3367,1221,3430,2181,618,2181,1,1756,1366,1818,1820,1818,1946,2919,2218,2919,1430,3431,406,3431,2470,1430,486,2470,1430,1430,2470,1494,1430,2659,2663,2659,2915,3171,3175,3171,3427,1948,2858,2181,1948,1756,389,1756,1948,2919,790,3431,2919,839,871,2887,839,1236,2919,2919,1748,1351,1383,3399,1351,716,3431,3431,1740,1756,3740]) (by decide +kernel)
  change ∀ b ∈ [s51,s77], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.nil
theorem b86 : Blocked tgt 6 s86 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s86 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
