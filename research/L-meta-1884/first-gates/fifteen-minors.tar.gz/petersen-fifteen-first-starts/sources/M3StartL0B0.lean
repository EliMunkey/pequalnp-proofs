import M3StartData
import M3StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 0 s0 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s0 0 _ le
  decide +kernel
theorem b1 : Blocked tgt 0 s1 := by
  exact PetersenSmallStarts.zero (by decide +kernel)
theorem b2 : Blocked tgt 0 s2 := by
  exact PetersenSmallStarts.zero (by decide +kernel)
theorem b3 : Blocked tgt 0 s3 := by
  exact PetersenSmallStarts.zero (by decide +kernel)
end PetersenSmallStarts.M3
