import M31StartData
import M31StartPins0
import M31StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 5 s2 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s2 5 _ le
  decide +kernel
theorem b3 : Blocked tgt 5 s3 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s3 5 _ le
  decide +kernel
theorem b4 : Blocked tgt 5 s4 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s4 5 _ le
  decide +kernel
theorem b5 : Blocked tgt 5 s5 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s5 5 _ le
  decide +kernel
theorem b6 : Blocked tgt 5 s6 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s6 5 _ le
  decide +kernel
theorem b7 : Blocked tgt 5 s7 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s7 5 _ le
  decide +kernel
theorem b8 : Blocked tgt 5 s8 := by
  apply PetersenFastNode.node (nxt := #[s9]) (hints := [693,725,362,102,426,362,563,198,198,363,198,106,422,198,198,843,678,198,394,394,693,426,0,363,693,363,693,851,917,851,777,843,677,843,363,459,851,422,851,418,843,550,843,426,627,107,851,627,363,115,843,363,422,843,835,835]) (by decide +kernel)
  change ∀ b ∈ [s9], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.nil
theorem b10 : Blocked tgt 5 s10 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [197,361,197,361,362,560,362,425,626,106,850,626,362,114,842,362,361,724,361,426,197,361,97,105,353,97,361,842,809,361,392,458,392,458,692,850,916,850,776,809,676,809,722,202,850,722,809,210,809,458,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b11 : Blocked tgt 5 s11 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s11 5 _ le
  decide +kernel
theorem b12 : Blocked tgt 5 s12 := by
  apply PetersenFastNode.node (nxt := #[s13]) (hints := [693,693,363,426,459,363,563,422,819,422,363,115,811,363,198,198,363,230,393,426,393,426,725,422,917,422,213,213,725,843,0,230,725,230,723,422,418,418,426,211,843,426,362,102,362,426,422,843,835,422,230,106,230,422,230,678]) (by decide +kernel)
  change ∀ b ∈ [s13], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.nil
theorem b14 : Blocked tgt 5 s14 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [197,197,229,362,229,196,361,101,425,361,229,105,421,229,229,842,362,692,362,425,458,362,98,106,354,98,362,677,562,362,392,458,392,458,724,421,916,421,776,677,708,677,194,202,450,194,458,549,809,458,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b15 : Blocked tgt 5 s15 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s15 5 _ le
  decide +kernel
theorem b16 : Blocked tgt 5 s16 := by
  apply PetersenFastNode.node (nxt := #[s17]) (hints := [693,198,725,693,363,394,459,363,363,561,627,107,851,627,363,115,843,363,362,102,426,362,230,0,230,106,422,230,230,213,678,230,426,393,723,422,418,418,426,550,810,426,785,422,785,422,777,678,777,678,422,554,678,422]) (by decide +kernel)
  change ∀ b ∈ [s17], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
theorem b18 : Blocked tgt 5 s18 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,362,692,362,229,361,229,361,425,425,421,850,421,850,677,809,677,809,562,361,362,361,362,692,392,362,626,106,850,626,362,114,842,362,361,229,229,361,97,105,353,97,361,842,809,361,850,421,850,421,809,677,809,677,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b19 : Blocked tgt 5 s19 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s19 5 _ le
  decide +kernel
theorem b20 : Blocked tgt 5 s20 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s20 5 _ le
  decide +kernel
end PetersenSmallStarts.M31
