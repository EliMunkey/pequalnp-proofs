import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_2 : NoAtMost (0x5500550055005500 :: inputs 6) tgt 5 := by
  change NoAtMost [0x5500550055005500,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s14] [194,906,195,906,196,908,579,908,390,910,455,910,196,2700,839,2700,586,906,195,906,716,908,1091,908,846,910,455,910,716,2700,1351,2700,1106,1946,195,1946,1236,1948,579,1948,1366,1950,455,1950,1236,3740,839,3740,1626,1946,195,1946,1756,1948,1948,1948,1886,1950,455,1950,1756,3740,3740,3740,2210,2730,2275,2730,196,908,2659,908,2470,2990,2535,2990,196,196,2919,2919,2666,2730,2275,2730,716,908,3171,908,2926,2990,2535,2990,716,196,3431,3431,3186,3770,2275,3770,1236,1948,2659,1948,3446,4030,2535,4030,1236,1236,2919,2919,3706,3770,2275,3770,1756,1948,1948,1948,3966,4030,2535,4030,1756,1236,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s14], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_2
end PetersenSmallStarts.M119
