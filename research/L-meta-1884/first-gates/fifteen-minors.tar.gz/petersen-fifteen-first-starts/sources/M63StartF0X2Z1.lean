import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) tgt 7 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s319] [194,195,195,195,196,1091,835,1091,390,195,455,195,196,1091,839,1091,714,715,715,715,716,1611,843,1611,390,715,455,715,716,1611,1351,1611,1106,195,195,195,1236,2115,835,2115,1366,195,455,195,1236,2115,839,2115,714,715,715,715,716,2635,843,2635,1366,715,455,715,716,2635,2375,2635,2146,195,195,195,2276,1091,835,1091,2406,195,455,195,2276,1091,839,1091,2666,715,715,715,2796,1611,843,1611,2406,715,455,715,2796,1611,1351,1611,3186,195,195,195,3316,3508,835,839,3446,195,455,195,3316,3764,839,839,2666,715,715,715,2796,2988,843,2988,3446,715,455,715,2796,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s319], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s319) b319 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M63
