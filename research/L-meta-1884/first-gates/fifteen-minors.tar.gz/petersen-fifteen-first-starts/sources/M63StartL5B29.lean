import M63StartData
import M63StartL4B2
import M63StartL4B1
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1110 : Blocked tgt 5 s1110 := by
  apply PetersenFastNode.node (nxt := #[s1111]) (hints := [3315,3445,3315,3445,838,454,194,454,834,3507,838,1350,1090,838,838,2374,2114,838,3445,390,3509,3445,3315,3445,3445,3315,2405,2421,3429,2405,1365,1397,3413,1365,194,454,454,194,454,2485,1350,454,454,1461,2374,454,834,1350,1090,1350,834,2374,2114,2374,1350,0,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s1111], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1111) b1111 <|
    PetersenLocalChildren.nil
theorem b1112 : Blocked tgt 5 s1112 := by
  apply PetersenFastNode.node (nxt := #[s1109,s1111]) (hints := [1236,1366,1236,1366,839,455,195,455,835,1428,839,1814,839,1351,1091,839,1366,391,1430,1366,1236,1366,1366,1236,1366,0,1684,1366,196,1351,1350,1350,195,455,455,195,455,1556,1554,455,455,406,1351,455,835,1,1684,835,835,1351,1091,1351,1351,1603]) (by decide +kernel)
  change ∀ b ∈ [s1109,s1111], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1109) b1109 <|
    PetersenLocalChildren.push (x := s1111) b1111 <|
    PetersenLocalChildren.nil
theorem b1115 : Blocked tgt 5 s1115 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1115 5 _ le
  decide +kernel
theorem b1119 : Blocked tgt 5 s1119 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1119 5 _ le
  decide +kernel
theorem b1120 : Blocked tgt 5 s1120 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(1,false),(0,false))] s1120 5 _ le
  decide +kernel
theorem b1121 : Blocked tgt 5 s1121 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(1,false),(0,false))] s1121 5 _ le
  decide +kernel
theorem b1122 : Blocked tgt 5 s1122 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,1426,777,1426,777,714,714,1682,773,1682,773,1674,1349,1674,1349,713,197,777,713,1428,453,453,1428,453,201,773,453,453,404,1349,453,2762,777,777,2954,1426,773,769,769,777,1093,1609,777,1682,773,1682,773,1674,1349,1674,1349,773,1097,1349,773]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1123 : Blocked tgt 5 s1123 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1123 5 _ le
  decide +kernel
theorem b1124 : Blocked tgt 5 s1124 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(1,false),(0,false))] s1124 5 _ le
  decide +kernel
theorem b1127 : Blocked tgt 5 s1127 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(1,false),(0,false))] s1127 5 _ le
  decide +kernel
theorem b1128 : Blocked tgt 5 s1128 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1128 5 _ le
  decide +kernel
theorem b1129 : Blocked tgt 5 s1129 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1129 5 _ le
  decide +kernel
theorem b1131 : Blocked tgt 5 s1131 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1131 5 _ le
  decide +kernel
theorem b1132 : Blocked tgt 5 s1132 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1132 5 _ le
  decide +kernel
theorem b1133 : Blocked tgt 5 s1133 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1133 5 _ le
  decide +kernel
theorem b1134 : Blocked tgt 5 s1134 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(1,false),(0,true))] s1134 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
