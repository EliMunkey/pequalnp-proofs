import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b992 : Blocked tgt 5 s992 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s992 5 _ le
  decide +kernel
theorem b1005 : Blocked tgt 5 s1005 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1005 5 _ le
  decide +kernel
theorem b1006 : Blocked tgt 5 s1006 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1006 5 _ le
  decide +kernel
theorem b1007 : Blocked tgt 5 s1007 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1007 5 _ le
  decide +kernel
theorem b1027 : Blocked tgt 5 s1027 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1027 5 _ le
  decide +kernel
theorem b1028 : Blocked tgt 5 s1028 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3508,3444,389,3444,713,841,197,713,453,837,201,453,453,1349,2484,453,453,2373,1460,453,2664,777,2856,2664,3444,773,3892,3444,2404,2420,3428,2404,1364,1396,3412,1364,3636,837,833,833,841,1093,1609,841,841,2117,2633,841,837,1097,1349,837,837,2121,2373,837,1349,1576,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1029 : Blocked tgt 5 s1029 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1029 5 _ le
  decide +kernel
theorem b1030 : Blocked tgt 5 s1030 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3754,2794,2274,2794,1349,453,2484,453,1609,841,1093,841,1349,837,1097,837,1349,2373,1706,1349,2404,389,2468,2404,2794,777,2986,2794,2282,2282,2794,2404,714,746,2762,714,713,197,841,713,453,201,837,453,453,420,2373,453,2474,837,833,833,841,2117,2633,841,837,2121,2373,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1031 : Blocked tgt 5 s1031 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1031 5 _ le
  decide +kernel
theorem b1032 : Blocked tgt 5 s1032 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1032 5 _ le
  decide +kernel
theorem b1034 : Blocked tgt 5 s1034 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1034 5 _ le
  decide +kernel
theorem b1035 : Blocked tgt 5 s1035 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1035 5 _ le
  decide +kernel
theorem b1038 : Blocked tgt 5 s1038 := by
  apply PetersenFastNode.node (nxt := #[s1039]) (hints := [395,778,395,459,1461,774,1461,1525,1235,3445,3445,1235,2405,2421,3429,2405,1365,1397,3413,1365,1717,838,842,838,842,1427,842,1350,1610,842,714,2374,458,458,0,838,838,1683,838,1610,1350,838,838,714,454,454,1090,1350,1090,1350,202,2374,2114,2374,1350,1547,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s1039], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1039) b1039 <|
    PetersenLocalChildren.nil
theorem b1040 : Blocked tgt 5 s1040 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1040 5 _ le
  decide +kernel
theorem b1043 : Blocked tgt 5 s1043 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1460,1524,714,1460,906,841,906,841,1460,837,1682,837,1089,1349,1089,1349,453,453,193,2373,2664,777,2856,2664,3444,773,3892,3444,2404,2420,3428,2404,1364,1396,3412,1364,3636,837,841,837,841,1349,1609,841,841,2373,2633,841,837,1609,1349,837,837,2633,2373,837,1349,1576,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1045 : Blocked tgt 5 s1045 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1045 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
