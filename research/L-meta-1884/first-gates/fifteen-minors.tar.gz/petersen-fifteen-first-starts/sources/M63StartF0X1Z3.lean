import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888888888888888 :: inputs 6) tgt 7 := by
  change NoAtMost [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s211] [194,386,195,835,196,388,835,835,390,390,455,839,196,1668,839,839,714,778,715,843,716,908,843,843,390,390,455,1351,716,1676,1351,1351,1106,1106,195,835,1236,1428,835,835,1366,1366,455,839,1236,1684,839,839,714,778,715,843,716,908,843,843,1366,1366,455,2375,716,1366,2375,2375,2146,2146,195,835,2276,2468,835,835,2406,2406,455,839,2276,3748,839,839,2666,2666,715,843,2796,2988,843,843,2406,2406,455,1351,2796,3756,1351,1351,3186,3186,195,835,3316,3508,835,835,3446,3446,455,839,3316,3764,839,839,2666,2666,715,843,2796,2988,843,843,3446,3446,455,3510,2796,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s211], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s211) b211 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M63
