import M250StartData
import M250StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222222222222222 :: inputs 6) tgt 4 := by
  change NoAtMost [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s2] [386,1091,451,1091,388,1091,453,1091,390,1351,455,1351,1220,1351,1221,1351,906,1611,971,1611,908,1611,973,1611,910,1871,975,1871,1740,1871,1741,1871,1106,2627,451,2627,1236,2627,453,2627,1366,2887,455,2887,1236,2887,2757,2887,1626,2635,971,2635,1756,2635,973,2635,1886,2895,975,2895,1756,2895,2765,2895,2466,2659,2531,2659,2468,2659,2533,2659,2470,2919,2535,2919,2724,2919,2789,2919,906,1611,971,1611,908,1611,973,1611,910,1871,975,1871,1740,1871,1741,1871,3186,2659,2531,2659,3316,2659,2533,2659,3446,2919,2535,2919,3316,2919,2789,2919,1626,1754,971,973,1756,1756,973,973,1886,1950,975,1950,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s2], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M250
