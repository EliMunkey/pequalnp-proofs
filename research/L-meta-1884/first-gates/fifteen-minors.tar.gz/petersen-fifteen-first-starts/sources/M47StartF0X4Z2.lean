import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_2 : NoAtMost (0x55550000 :: inputs 5) tgt 4 := by
  change NoAtMost [0x55550000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s15] [98,722,99,722,100,724,419,724,198,726,231,726,100,918,423,918,362,922,363,922,364,988,427,988,198,726,231,726,364,364,679,679,562,722,99,722,628,724,419,724,694,726,231,726,628,918,423,918,826,922,363,922,892,988,427,988,694,726,231,726,892,364,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s15], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_2
end PetersenSmallStarts.M47
