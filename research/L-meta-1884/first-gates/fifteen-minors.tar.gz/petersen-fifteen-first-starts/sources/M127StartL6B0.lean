import M127StartData
import M127StartL5B0
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b9 : Blocked tgt 6 s9 := by
  apply PetersenFastNode.node (nxt := #[s10]) (hints := [9802,9802,11125,9930,9577,11125,11125,9577,11125,9798,12149,11125,9061,9077,11109,9061,10965,10997,11093,10965,2869,2933,11061,2869,1419,1803,3347,9926,9922,9922,9930,10438,11466,9930,9674,8646,9674,9930,1674,1738,9866,1674,2451,9926,3347,9926,1419,10950,3339,10950,9546,9030,1419,9030,1419,0,9483,1419,9926,10442,10950,9926,9030,8650,9030,9926,1670,1734,9862,1670,9030,3339,9030,10950,2694,2758,10886,2694,774,838,8966,774]) (by decide +kernel)
  change ∀ b ∈ [s10], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.nil
theorem b11 : Blocked tgt 6 s11 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s11 6 _ le
  decide +kernel
theorem b12 : Blocked tgt 6 s12 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12 6 _ le
  decide +kernel
theorem b14 : Blocked tgt 6 s14 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s14 6 _ le
  decide +kernel
theorem b15 : Blocked tgt 6 s15 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s15 6 _ le
  decide +kernel
theorem b18 : Blocked tgt 6 s18 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s18 6 _ le
  decide +kernel
theorem b19 : Blocked tgt 6 s19 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s19 6 _ le
  decide +kernel
theorem b20 : Blocked tgt 6 s20 := by
  apply PetersenFastNode.node (nxt := #[s21,s22]) (hints := [4743,903,0,903,2774,2774,1804,1675,1804,1675,3348,1671,3348,1671,3340,2695,3340,2695,1420,1420,903,7126,1419,391,1675,1419,903,395,1671,903,903,3340,2695,903,5260,903,903,5516,5322,1675,5834,1675,6870,1671,7894,1671,4806,2695,6854,2695,1,5516,6806,5516,2836,1671,1667,1667,1675,2183,3211,1675,1804,1675,1675,1804,1671,2187,2695,1671,3348,1671,1671,3348,3340,2695,2695,3340]) (by decide +kernel)
  change ∀ b ∈ [s21,s22], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.nil
theorem b23 : Blocked tgt 6 s23 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s23 6 _ le
  decide +kernel
theorem b24 : Blocked tgt 6 s24 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4805,4741,12933,4741,9482,5514,6804,5514,9093,901,965,901,9865,1673,1737,1673,9861,1669,1733,1669,10885,2693,2757,2693,1418,1418,4741,901,11028,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,3338,2693,5258,901,5514,901,1802,1673,1802,1673,3346,1669,3346,1669,3338,2693,3338,2693,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b26 : Blocked tgt 6 s26 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s26 6 _ le
  decide +kernel
theorem b27 : Blocked tgt 6 s27 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s27 6 _ le
  decide +kernel
theorem b28 : Blocked tgt 6 s28 := by
  apply PetersenFastNode.node (nxt := #[s29]) (hints := [5353,5931,5865,5931,6901,1670,7925,6901,5109,5109,6901,4837,4837,6901,6901,4837,2773,2805,6869,2773,6965,6901,6837,6837,6963,4907,7475,6963,5931,4915,7467,5931,1418,5931,5931,1674,1803,1835,5899,1803,5547,1674,5547,5931,1670,7467,7459,1670,902,7475,902,1670,1670,3379,4742,1670,6323,1670,1670,7347,902,2694,4742,3371,4742,3339,5547,4531,5547,7339,902,0,4742,902,774,774,902,5547,1419,4742,4742,5515]) (by decide +kernel)
  change ∀ b ∈ [s29], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.nil
theorem b30 : Blocked tgt 6 s30 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s30 6 _ le
  decide +kernel
theorem b31 : Blocked tgt 6 s31 := by
  apply PetersenFastNode.node (nxt := #[s32,s21,s33,s34,s10,s35,s29,s36,s37,s38,s39,s40]) (hints := [1524,1524,13940,1814,3072,1814,2036,3072,13940,1524,1524,1814,3072,3072,16000,1681,1524,1681,4096,1524,16000,3072,3072,1681,1008,1008,15476,1024,3072,2705,3056,3072,15476,1008,1008,2705,2784,2784,0,2816,3072,913,3040,3072,1,2784,2784,913,2880,2880,2,2944,3072,1430,3008,3072,3,2880,2880,1430,2846,2846,3358,790,1814,1681,3358,1814,3358,2846,2846,1681,1814,1814,3350,798,2846,2705,3350,2846,3350,1814,1814,2705,1429,1685,1429,1814,1814,913,1429,1814,1429,1685,1685,913,1430,1814,1430,1685,1685,4,1430,1685,1430,1814,1814,5,1681,1681,2705,3350,3358,3350,2705,3358,2705,1681,1681,3350,913,1681,913,3358,3358,1429,913,3358,913,1681,1681,1429,2462,3358,2462,1681,1681,1430,1681,1681,2462,3358,3358,1430,913,2705,913,3350,3350,6,913,3350,913,2705,2705,7,1430,3350,1430,2705,2705,2462,2705,2705,1430,3350,3350,2462,785,8,9,785,913,1430,913,913,10,1430,11,1430]) (by decide +kernel)
  change ∀ b ∈ [s32,s21,s33,s34,s10,s35,s29,s36,s37,s38,s39,s40], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s33) b33 <|
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.nil
theorem b41 : Blocked tgt 6 s41 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s41 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
