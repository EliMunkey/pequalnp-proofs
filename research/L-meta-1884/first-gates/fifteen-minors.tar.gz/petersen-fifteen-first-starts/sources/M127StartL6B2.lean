import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b61 : Blocked tgt 6 s61 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s61 6 _ le
  decide +kernel
theorem b62 : Blocked tgt 6 s62 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s62 6 _ le
  decide +kernel
theorem b65 : Blocked tgt 6 s65 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s65 6 _ le
  decide +kernel
theorem b66 : Blocked tgt 6 s66 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s66 6 _ le
  decide +kernel
theorem b67 : Blocked tgt 6 s67 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s67 6 _ le
  decide +kernel
theorem b68 : Blocked tgt 6 s68 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s68 6 _ le
  decide +kernel
theorem b69 : Blocked tgt 6 s69 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s69 6 _ le
  decide +kernel
theorem b70 : Blocked tgt 6 s70 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s70 6 _ le
  decide +kernel
theorem b71 : Blocked tgt 6 s71 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s71 6 _ le
  decide +kernel
theorem b76 : Blocked tgt 6 s76 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s76 6 _ le
  decide +kernel
theorem b77 : Blocked tgt 6 s77 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s77 6 _ le
  decide +kernel
theorem b79 : Blocked tgt 6 s79 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s79 6 _ le
  decide +kernel
theorem b81 : Blocked tgt 6 s81 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s81 6 _ le
  decide +kernel
theorem b82 : Blocked tgt 6 s82 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s82 6 _ le
  decide +kernel
theorem b83 : Blocked tgt 6 s83 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s83 6 _ le
  decide +kernel
theorem b84 : Blocked tgt 6 s84 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s84 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
