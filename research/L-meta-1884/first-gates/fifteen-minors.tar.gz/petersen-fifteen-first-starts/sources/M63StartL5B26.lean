import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b952 : Blocked tgt 5 s952 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(false,(0,true),(4,false))] s952 5 _ le
  decide +kernel
theorem b953 : Blocked tgt 5 s953 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s953 5 _ le
  decide +kernel
theorem b954 : Blocked tgt 5 s954 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true)),(false,(0,true),(4,false))] s954 5 _ le
  decide +kernel
theorem b958 : Blocked tgt 5 s958 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s958 5 _ le
  decide +kernel
theorem b959 : Blocked tgt 5 s959 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s959 5 _ le
  decide +kernel
theorem b963 : Blocked tgt 5 s963 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s963 5 _ le
  decide +kernel
theorem b964 : Blocked tgt 5 s964 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s964 5 _ le
  decide +kernel
theorem b965 : Blocked tgt 5 s965 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s965 5 _ le
  decide +kernel
theorem b966 : Blocked tgt 5 s966 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s966 5 _ le
  decide +kernel
theorem b967 : Blocked tgt 5 s967 := by
  apply PetersenFastNode.node (nxt := #[s968]) (hints := [715,778,907,715,3445,203,3635,3445,3445,715,3509,3445,2405,2421,3429,2405,1365,1397,3413,1365,3507,842,842,3507,0,842,842,3505,842,1094,1610,842,714,2118,714,842,838,838,1350,1226,1350,1610,2374,202,2374,714,1350,1610,1350,1478,2374,714,454,454,1350,1547,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s968], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s968) b968 <|
    PetersenLocalChildren.nil
theorem b969 : Blocked tgt 5 s969 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s969 5 _ le
  decide +kernel
theorem b970 : Blocked tgt 5 s970 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(4,true))] s970 5 _ le
  decide +kernel
theorem b980 : Blocked tgt 5 s980 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s980 5 _ le
  decide +kernel
theorem b986 : Blocked tgt 5 s986 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s986 5 _ le
  decide +kernel
theorem b987 : Blocked tgt 5 s987 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s987 5 _ le
  decide +kernel
theorem b991 : Blocked tgt 5 s991 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s991 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
