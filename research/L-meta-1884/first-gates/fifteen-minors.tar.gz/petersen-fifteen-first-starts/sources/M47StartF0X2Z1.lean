import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a :: inputs 5) tgt 4 := by
  change NoAtMost [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s6] [98,99,99,99,100,547,419,547,198,99,231,99,100,547,423,547,362,363,363,363,364,811,427,811,198,363,231,363,364,811,679,811,562,99,99,99,628,724,419,423,694,99,231,99,628,694,423,423,826,363,363,363,892,988,427,988,694,363,231,363,892,694,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s6], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M47
