import M250StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 64) : Fin 64 := (#[0,2,1,3,16,18,17,19,8,10,9,11,24,26,25,27,4,6,5,7,20,22,21,23,12,14,13,15,28,30,29,31,32,34,33,35,48,50,49,51,40,42,41,43,56,58,57,59,36,38,37,39,52,54,53,55,44,46,45,47,60,62,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover0 : i6.all (fun q => i6.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
private def a1 (x : Fin 64) : Fin 64 := (#[0,1,4,5,2,3,6,7,8,9,12,13,10,11,14,15,16,17,20,21,18,19,22,23,24,25,28,29,26,27,30,31,32,33,36,37,34,35,38,39,40,41,44,45,42,43,46,47,48,49,52,53,50,51,54,55,56,57,60,61,58,59,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover1 : i6.all (fun q => i6.contains (PetersenPackedPin.project a1 q)) = true := by decide +kernel
private theorem same1 : PetersenPackedPin.project a1 tgt=tgt := by decide +kernel
private def a2 (x : Fin 64) : Fin 64 := (#[0,4,1,5,16,20,17,21,8,12,9,13,24,28,25,29,2,6,3,7,18,22,19,23,10,14,11,15,26,30,27,31,32,36,33,37,48,52,49,53,40,44,41,45,56,60,57,61,34,38,35,39,50,54,51,55,42,46,43,47,58,62,59,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover2 : i6.all (fun q => i6.contains (PetersenPackedPin.project a2 q)) = true := by decide +kernel
private theorem same2 : PetersenPackedPin.project a2 tgt=tgt := by decide +kernel
private def a3 (x : Fin 64) : Fin 64 := (#[0,1,8,9,32,33,40,41,2,3,10,11,34,35,42,43,16,17,24,25,48,49,56,57,18,19,26,27,50,51,58,59,4,5,12,13,36,37,44,45,6,7,14,15,38,39,46,47,20,21,28,29,52,53,60,61,22,23,30,31,54,55,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover3 : i6.all (fun q => i6.contains (PetersenPackedPin.project a3 q)) = true := by decide +kernel
private theorem same3 : PetersenPackedPin.project a3 tgt=tgt := by decide +kernel
private def a4 (x : Fin 64) : Fin 64 := (#[0,8,1,9,16,24,17,25,2,10,3,11,18,26,19,27,32,40,33,41,48,56,49,57,34,42,35,43,50,58,51,59,4,12,5,13,20,28,21,29,6,14,7,15,22,30,23,31,36,44,37,45,52,60,53,61,38,46,39,47,54,62,55,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover4 : i6.all (fun q => i6.contains (PetersenPackedPin.project a4 q)) = true := by decide +kernel
private theorem same4 : PetersenPackedPin.project a4 tgt=tgt := by decide +kernel
private def a5 (x : Fin 64) : Fin 64 := (#[0,16,2,18,4,20,6,22,8,24,10,26,12,28,14,30,1,17,3,19,5,21,7,23,9,25,11,27,13,29,15,31,32,48,34,50,36,52,38,54,40,56,42,58,44,60,46,62,33,49,35,51,37,53,39,55,41,57,43,59,45,61,47,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover5 : i6.all (fun q => i6.contains (PetersenPackedPin.project a5 q)) = true := by decide +kernel
private theorem same5 : PetersenPackedPin.project a5 tgt=tgt := by decide +kernel
private def a6 (x : Fin 64) : Fin 64 := (#[0,1,32,33,8,9,40,41,2,3,34,35,10,11,42,43,16,17,48,49,24,25,56,57,18,19,50,51,26,27,58,59,4,5,36,37,12,13,44,45,6,7,38,39,14,15,46,47,20,21,52,53,28,29,60,61,22,23,54,55,30,31,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover6 : i6.all (fun q => i6.contains (PetersenPackedPin.project a6 q)) = true := by decide +kernel
private theorem same6 : PetersenPackedPin.project a6 tgt=tgt := by decide +kernel
private def a7 (x : Fin 64) : Fin 64 := (#[0,32,1,33,16,48,17,49,2,34,3,35,18,50,19,51,8,40,9,41,24,56,25,57,10,42,11,43,26,58,27,59,4,36,5,37,20,52,21,53,6,38,7,39,22,54,23,55,12,44,13,45,28,60,29,61,14,46,15,47,30,62,31,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover7 : i6.all (fun q => i6.contains (PetersenPackedPin.project a7 q)) = true := by decide +kernel
private theorem same7 : PetersenPackedPin.project a7 tgt=tgt := by decide +kernel
private def a8 (x : Fin 64) : Fin 64 := (#[0,2,8,10,32,34,40,42,1,3,9,11,33,35,41,43,4,6,12,14,36,38,44,46,5,7,13,15,37,39,45,47,16,18,24,26,48,50,56,58,17,19,25,27,49,51,57,59,20,22,28,30,52,54,60,62,21,23,29,31,53,55,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover8 : i6.all (fun q => i6.contains (PetersenPackedPin.project a8 q)) = true := by decide +kernel
private theorem same8 : PetersenPackedPin.project a8 tgt=tgt := by decide +kernel
private def a9 (x : Fin 64) : Fin 64 := (#[0,8,2,10,4,12,6,14,1,9,3,11,5,13,7,15,32,40,34,42,36,44,38,46,33,41,35,43,37,45,39,47,16,24,18,26,20,28,22,30,17,25,19,27,21,29,23,31,48,56,50,58,52,60,54,62,49,57,51,59,53,61,55,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover9 : i6.all (fun q => i6.contains (PetersenPackedPin.project a9 q)) = true := by decide +kernel
private theorem same9 : PetersenPackedPin.project a9 tgt=tgt := by decide +kernel
private def a10 (x : Fin 64) : Fin 64 := (#[0,2,16,18,1,3,17,19,8,10,24,26,9,11,25,27,4,6,20,22,5,7,21,23,12,14,28,30,13,15,29,31,32,34,48,50,33,35,49,51,40,42,56,58,41,43,57,59,36,38,52,54,37,39,53,55,44,46,60,62,45,47,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover10 : i6.all (fun q => i6.contains (PetersenPackedPin.project a10 q)) = true := by decide +kernel
private theorem same10 : PetersenPackedPin.project a10 tgt=tgt := by decide +kernel
private def a11 (x : Fin 64) : Fin 64 := (#[0,2,32,34,8,10,40,42,1,3,33,35,9,11,41,43,4,6,36,38,12,14,44,46,5,7,37,39,13,15,45,47,16,18,48,50,24,26,56,58,17,19,49,51,25,27,57,59,20,22,52,54,28,30,60,62,21,23,53,55,29,31,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover11 : i6.all (fun q => i6.contains (PetersenPackedPin.project a11 q)) = true := by decide +kernel
private theorem same11 : PetersenPackedPin.project a11 tgt=tgt := by decide +kernel
private def a12 (x : Fin 64) : Fin 64 := (#[0,32,2,34,4,36,6,38,1,33,3,35,5,37,7,39,8,40,10,42,12,44,14,46,9,41,11,43,13,45,15,47,16,48,18,50,20,52,22,54,17,49,19,51,21,53,23,55,24,56,26,58,28,60,30,62,25,57,27,59,29,61,31,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover12 : i6.all (fun q => i6.contains (PetersenPackedPin.project a12 q)) = true := by decide +kernel
private theorem same12 : PetersenPackedPin.project a12 tgt=tgt := by decide +kernel
private def a13 (x : Fin 64) : Fin 64 := (#[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15,32,40,36,44,34,42,38,46,33,41,37,45,35,43,39,47,16,24,20,28,18,26,22,30,17,25,21,29,19,27,23,31,48,56,52,60,50,58,54,62,49,57,53,61,51,59,55,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover13 : i6.all (fun q => i6.contains (PetersenPackedPin.project a13 q)) = true := by decide +kernel
private theorem same13 : PetersenPackedPin.project a13 tgt=tgt := by decide +kernel
private def a14 (x : Fin 64) : Fin 64 := (#[0,4,8,12,32,36,40,44,1,5,9,13,33,37,41,45,2,6,10,14,34,38,42,46,3,7,11,15,35,39,43,47,16,20,24,28,48,52,56,60,17,21,25,29,49,53,57,61,18,22,26,30,50,54,58,62,19,23,27,31,51,55,59,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover14 : i6.all (fun q => i6.contains (PetersenPackedPin.project a14 q)) = true := by decide +kernel
private theorem same14 : PetersenPackedPin.project a14 tgt=tgt := by decide +kernel
private def a15 (x : Fin 64) : Fin 64 := (#[0,4,16,20,1,5,17,21,8,12,24,28,9,13,25,29,2,6,18,22,3,7,19,23,10,14,26,30,11,15,27,31,32,36,48,52,33,37,49,53,40,44,56,60,41,45,57,61,34,38,50,54,35,39,51,55,42,46,58,62,43,47,59,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover15 : i6.all (fun q => i6.contains (PetersenPackedPin.project a15 q)) = true := by decide +kernel
private theorem same15 : PetersenPackedPin.project a15 tgt=tgt := by decide +kernel
private def a16 (x : Fin 64) : Fin 64 := (#[0,16,4,20,2,18,6,22,8,24,12,28,10,26,14,30,1,17,5,21,3,19,7,23,9,25,13,29,11,27,15,31,32,48,36,52,34,50,38,54,40,56,44,60,42,58,46,62,33,49,37,53,35,51,39,55,41,57,45,61,43,59,47,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover16 : i6.all (fun q => i6.contains (PetersenPackedPin.project a16 q)) = true := by decide +kernel
private theorem same16 : PetersenPackedPin.project a16 tgt=tgt := by decide +kernel
private def a17 (x : Fin 64) : Fin 64 := (#[0,32,4,36,2,34,6,38,1,33,5,37,3,35,7,39,8,40,12,44,10,42,14,46,9,41,13,45,11,43,15,47,16,48,20,52,18,50,22,54,17,49,21,53,19,51,23,55,24,56,28,60,26,58,30,62,25,57,29,61,27,59,31,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover17 : i6.all (fun q => i6.contains (PetersenPackedPin.project a17 q)) = true := by decide +kernel
private theorem same17 : PetersenPackedPin.project a17 tgt=tgt := by decide +kernel
private def a18 (x : Fin 64) : Fin 64 := (#[0,4,32,36,8,12,40,44,1,5,33,37,9,13,41,45,2,6,34,38,10,14,42,46,3,7,35,39,11,15,43,47,16,20,48,52,24,28,56,60,17,21,49,53,25,29,57,61,18,22,50,54,26,30,58,62,19,23,51,55,27,31,59,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover18 : i6.all (fun q => i6.contains (PetersenPackedPin.project a18 q)) = true := by decide +kernel
private theorem same18 : PetersenPackedPin.project a18 tgt=tgt := by decide +kernel
private def a19 (x : Fin 64) : Fin 64 := (#[0,8,16,24,1,9,17,25,2,10,18,26,3,11,19,27,32,40,48,56,33,41,49,57,34,42,50,58,35,43,51,59,4,12,20,28,5,13,21,29,6,14,22,30,7,15,23,31,36,44,52,60,37,45,53,61,38,46,54,62,39,47,55,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover19 : i6.all (fun q => i6.contains (PetersenPackedPin.project a19 q)) = true := by decide +kernel
private theorem same19 : PetersenPackedPin.project a19 tgt=tgt := by decide +kernel
private def a20 (x : Fin 64) : Fin 64 := (#[0,16,8,24,32,48,40,56,2,18,10,26,34,50,42,58,1,17,9,25,33,49,41,57,3,19,11,27,35,51,43,59,4,20,12,28,36,52,44,60,6,22,14,30,38,54,46,62,5,21,13,29,37,53,45,61,7,23,15,31,39,55,47,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover20 : i6.all (fun q => i6.contains (PetersenPackedPin.project a20 q)) = true := by decide +kernel
private theorem same20 : PetersenPackedPin.project a20 tgt=tgt := by decide +kernel
private def a21 (x : Fin 64) : Fin 64 := (#[0,32,16,48,1,33,17,49,2,34,18,50,3,35,19,51,8,40,24,56,9,41,25,57,10,42,26,58,11,43,27,59,4,36,20,52,5,37,21,53,6,38,22,54,7,39,23,55,12,44,28,60,13,45,29,61,14,46,30,62,15,47,31,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover21 : i6.all (fun q => i6.contains (PetersenPackedPin.project a21 q)) = true := by decide +kernel
private theorem same21 : PetersenPackedPin.project a21 tgt=tgt := by decide +kernel
private def a22 (x : Fin 64) : Fin 64 := (#[0,16,32,48,8,24,40,56,2,18,34,50,10,26,42,58,1,17,33,49,9,25,41,57,3,19,35,51,11,27,43,59,4,20,36,52,12,28,44,60,6,22,38,54,14,30,46,62,5,21,37,53,13,29,45,61,7,23,39,55,15,31,47,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover22 : i6.all (fun q => i6.contains (PetersenPackedPin.project a22 q)) = true := by decide +kernel
private theorem same22 : PetersenPackedPin.project a22 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x4444444444444444 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x4444444444444444) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_0 : NoAtMost (0xfafafafafafafafa :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xfafafafafafafafa) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xa0a0a0a0a0a0a0a) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_2 : NoAtMost (0x5050505050505050 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x5050505050505050) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_3 : NoAtMost (0xa0a0a0a0a0a0a0a0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xa0a0a0a0a0a0a0a0) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_0_3_0 : NoAtMost (0xffaaffaaffaaffaa :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xffaaffaaffaaffaa) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_3_1 : NoAtMost (0xaa00aa00aa00aa :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xaa00aa00aa00aa) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_3_2 : NoAtMost (0x5500550055005500 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0x5500550055005500) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_3_3 : NoAtMost (0xaa00aa00aa00aa00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xaa00aa00aa00aa00) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_0_4_2 : NoAtMost (0x5555000055550000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0x5555000055550000) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_0_5_0 : NoAtMost (0xffffffffaaaaaaaa :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xffffffffaaaaaaaa) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_5_1 : NoAtMost (0xaaaaaaaa :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xaaaaaaaa) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_5_2 : NoAtMost (0x5555555500000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a7 cover7 same7 (g:=0x5555555500000000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_5_3 : NoAtMost (0xaaaaaaaa00000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xaaaaaaaa00000000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfcfcfcfcfc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfcfcfcfcfcfcfc) (a:=0xffffaaaaffffaaaa) (by decide +kernel) gate_0_4_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c0c0c0c0c :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_1_2_2 : NoAtMost (0x3030303030303030 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x3030303030303030) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_1_3_0 : NoAtMost (0xffccffccffccffcc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a8 cover8 same8 (g:=0xffccffccffccffcc) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_3_1 : NoAtMost (0xcc00cc00cc00cc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a8 cover8 same8 (g:=0xcc00cc00cc00cc) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_3_2 : NoAtMost (0x3300330033003300 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a9 cover9 same9 (g:=0x3300330033003300) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_3_3 : NoAtMost (0xcc00cc00cc00cc00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a8 cover8 same8 (g:=0xcc00cc00cc00cc00) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_1_4_0 : NoAtMost (0xffffccccffffcccc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a10 cover10 same10 (g:=0xffffccccffffcccc) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_4_1 : NoAtMost (0xcccc0000cccc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a10 cover10 same10 (g:=0xcccc0000cccc) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_4_2 : NoAtMost (0x3333000033330000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0x3333000033330000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_4_3 : NoAtMost (0xcccc0000cccc0000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a10 cover10 same10 (g:=0xcccc0000cccc0000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_1_5_0 : NoAtMost (0xffffffffcccccccc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a11 cover11 same11 (g:=0xffffffffcccccccc) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_5_1 : NoAtMost (0xcccccccc :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a11 cover11 same11 (g:=0xcccccccc) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_5_2 : NoAtMost (0x3333333300000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a12 cover12 same12 (g:=0x3333333300000000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_5_3 : NoAtMost (0xcccccccc00000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a11 cover11 same11 (g:=0xcccccccc00000000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_2_3_0 : NoAtMost (0xfff0fff0fff0fff0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a13 cover13 same13 (g:=0xfff0fff0fff0fff0) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_3_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a14 cover14 same14 (g:=0xf000f000f000f0) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_3_2 : NoAtMost (0xf000f000f000f00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a13 cover13 same13 (g:=0xf000f000f000f00) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_3_3 : NoAtMost (0xf000f000f000f000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a13 cover13 same13 (g:=0xf000f000f000f000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_2_4_0 : NoAtMost (0xfffff0f0fffff0f0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a15 cover15 same15 (g:=0xfffff0f0fffff0f0) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_4_1 : NoAtMost (0xf0f00000f0f0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a15 cover15 same15 (g:=0xf0f00000f0f0) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_4_2 : NoAtMost (0xf0f00000f0f0000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a16 cover16 same16 (g:=0xf0f00000f0f0000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_4_3 : NoAtMost (0xf0f00000f0f00000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a15 cover15 same15 (g:=0xf0f00000f0f00000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_2_5_0 : NoAtMost (0xfffffffff0f0f0f0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a17 cover17 same17 (g:=0xfffffffff0f0f0f0) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_5_1 : NoAtMost (0xf0f0f0f0 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a18 cover18 same18 (g:=0xf0f0f0f0) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_5_2 : NoAtMost (0xf0f0f0f00000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a17 cover17 same17 (g:=0xf0f0f0f00000000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_5_3 : NoAtMost (0xf0f0f0f000000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a17 cover17 same17 (g:=0xf0f0f0f000000000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_3_4_0 : NoAtMost (0xffffff00ffffff00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a19 cover19 same19 (g:=0xffffff00ffffff00) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_3_4_1 : NoAtMost (0xff000000ff00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a19 cover19 same19 (g:=0xff000000ff00) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_3_4_2 : NoAtMost (0xff000000ff0000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a20 cover20 same20 (g:=0xff000000ff0000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_3_4_3 : NoAtMost (0xff000000ff000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a19 cover19 same19 (g:=0xff000000ff000000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_3_5_0 : NoAtMost (0xffffffffff00ff00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xffffffffff00ff00) (a:=0xffffaaaaffffaaaa) (by decide +kernel) gate_0_4_0
theorem labeled_3_5_1 : NoAtMost (0xff00ff00 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff00ff00) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_3_5_2 : NoAtMost (0xff00ff00000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a7 cover7 same7 (g:=0xff00ff00000000) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_4_5_0 : NoAtMost (0xffffffffffff0000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a21 cover21 same21 (g:=0xffffffffffff0000) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_4_5_1 : NoAtMost (0xffff0000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a22 cover22 same22 (g:=0xffff0000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_4_5_2 : NoAtMost (0xffff00000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a21 cover21 same21 (g:=0xffff00000000) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_4_5_3 : NoAtMost (0xffff000000000000 :: inputs 6) tgt 4 :=
  PetersenSmallStarts.relabel_aux a21 cover21 same21 (g:=0xffff000000000000) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
def forbidden : List (BitVec 64) := [0xeeeeeeeeeeeeeeee,0x2222222222222222,0x4444444444444444,0x8888888888888888,0xfafafafafafafafa,0xa0a0a0a0a0a0a0a,0x5050505050505050,0xa0a0a0a0a0a0a0a0,0xffaaffaaffaaffaa,0xaa00aa00aa00aa,0x5500550055005500,0xaa00aa00aa00aa00,0xffffaaaaffffaaaa,0xaaaa0000aaaa,0x5555000055550000,0xffffffffaaaaaaaa,0xaaaaaaaa,0x5555555500000000,0xaaaaaaaa00000000,0xfcfcfcfcfcfcfcfc,0xc0c0c0c0c0c0c0c,0x3030303030303030,0xffccffccffccffcc,0xcc00cc00cc00cc,0x3300330033003300,0xcc00cc00cc00cc00,0xffffccccffffcccc,0xcccc0000cccc,0x3333000033330000,0xcccc0000cccc0000,0xffffffffcccccccc,0xcccccccc,0x3333333300000000,0xcccccccc00000000,0xfff0fff0fff0fff0,0xf000f000f000f0,0xf000f000f000f00,0xf000f000f000f000,0xfffff0f0fffff0f0,0xf0f00000f0f0,0xf0f00000f0f0000,0xf0f00000f0f00000,0xfffffffff0f0f0f0,0xf0f0f0f0,0xf0f0f0f00000000,0xf0f0f0f000000000,0xffffff00ffffff00,0xff000000ff00,0xff000000ff0000,0xff000000ff000000,0xffffffffff00ff00,0xff00ff00,0xff00ff00000000,0xffffffffffff0000,0xffff0000,0xffff00000000,0xffff000000000000]
theorem all_forbidden (g : BitVec 64) (h : g∈forbidden) : NoAtMost (g::inputs 6) tgt 4 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 6) tgt 4 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xeeeeeeeeeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x2222222222222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x4444444444444444) labeled_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x8888888888888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xfafafafafafafafa) labeled_0_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xa0a0a0a0a0a0a0a) labeled_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x5050505050505050) labeled_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xa0a0a0a0a0a0a0a0) labeled_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffaaffaaffaaffaa) labeled_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xaa00aa00aa00aa) labeled_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x5500550055005500) labeled_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xaa00aa00aa00aa00) labeled_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffaaaaffffaaaa) gate_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xaaaa0000aaaa) gate_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x5555000055550000) labeled_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffffffaaaaaaaa) labeled_0_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xaaaaaaaa) labeled_0_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x5555555500000000) labeled_0_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xaaaaaaaa00000000) labeled_0_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xfcfcfcfcfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xc0c0c0c0c0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x3030303030303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffccffccffccffcc) labeled_1_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcc00cc00cc00cc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x3300330033003300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcc00cc00cc00cc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffccccffffcccc) labeled_1_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcccc0000cccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x3333000033330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcccc0000cccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffffffcccccccc) labeled_1_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcccccccc) labeled_1_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0x3333333300000000) labeled_1_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xcccccccc00000000) labeled_1_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xfff0fff0fff0fff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf000f000f000f0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf000f000f000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf000f000f000f000) labeled_2_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xfffff0f0fffff0f0) labeled_2_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f00000f0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f00000f0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f00000f0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xfffffffff0f0f0f0) labeled_2_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f0f0f0) labeled_2_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f0f0f00000000) labeled_2_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xf0f0f0f000000000) labeled_2_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffff00ffffff00) labeled_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xff000000ff00) labeled_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xff000000ff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xff000000ff000000) labeled_3_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffffffff00ff00) labeled_3_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xff00ff00) labeled_3_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xff00ff00000000) labeled_3_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffffffffffff0000) labeled_4_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffff0000) labeled_4_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffff00000000) labeled_4_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 4) (x:=0xffff000000000000) labeled_4_5_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M250
