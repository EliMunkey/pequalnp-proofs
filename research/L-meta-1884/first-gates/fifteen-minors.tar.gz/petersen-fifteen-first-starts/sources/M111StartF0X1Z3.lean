import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888888888888888 :: inputs 6) tgt 6 := by
  change NoAtMost [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s24] [194,386,195,835,196,388,835,835,390,390,455,839,196,2180,839,839,714,778,715,843,716,908,843,843,390,390,455,1351,716,2700,1351,1351,1106,1106,195,835,1236,1428,835,835,1366,1366,455,839,1236,3220,839,839,1626,1626,715,843,1756,1948,843,843,1366,1366,455,1430,1756,3740,3740,3740,2210,2210,2275,2915,196,388,2915,2915,2470,2470,2535,2919,196,2854,2919,2919,2730,2730,2795,2923,716,908,2923,2923,2470,2470,2535,3431,716,3430,3431,3431,3186,3186,2275,2915,1236,1428,2915,2915,3446,3446,2535,2919,1236,3446,2919,2919,3706,3706,2795,2923,1756,1948,2923,2923,3446,3446,2535,3510,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s24], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M111
