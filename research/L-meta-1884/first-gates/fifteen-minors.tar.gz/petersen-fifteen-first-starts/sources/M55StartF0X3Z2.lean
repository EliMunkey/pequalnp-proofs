import M55StartData
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_2 : NoAtMost (0x55005500 :: inputs 5) tgt 4 := by
  change NoAtMost [0x55005500,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s14] [98,458,99,458,100,460,291,460,198,462,231,462,100,100,423,423,298,458,99,458,364,460,547,460,430,462,231,462,364,100,679,679,562,986,99,986,628,988,291,988,694,990,231,990,628,628,423,423,826,986,99,986,892,988,988,988,958,990,231,990,892,628,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s14], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_2
end PetersenSmallStarts.M55
