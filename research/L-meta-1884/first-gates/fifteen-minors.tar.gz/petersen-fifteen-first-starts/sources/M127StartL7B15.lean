import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B19
import M127StartL6B17
import M127StartL6B18
import M127StartL6B5
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b579 : Blocked tgt 7 s579 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s579 7 _ le
  decide +kernel
theorem b580 : Blocked tgt 7 s580 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s580 7 _ le
  decide +kernel
theorem b581 : Blocked tgt 7 s581 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s581 7 _ le
  decide +kernel
theorem b582 : Blocked tgt 7 s582 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s582 7 _ le
  decide +kernel
theorem b583 : Blocked tgt 7 s583 := by
  apply PetersenFastNode.node (nxt := #[s584,s585,s586,s533,s537,s587,s557,s588,s589,s563,s590,s591]) (hints := [7478,7478,6574,5558,10961,5558,4526,10961,6574,5558,7478,5558,10961,10961,13168,9169,7478,9169,13168,7478,13168,9169,10961,9169,11477,11477,4910,9941,10961,9941,10449,10961,4910,9941,11477,9941,10961,10961,7470,9937,11477,9937,10453,11477,7470,9937,10961,9937,10961,10961,0,13009,7478,13009,3382,7478,1,10961,10961,13009,2705,2705,12590,10897,10961,13622,2769,10961,12590,2705,2705,13622,13556,13556,13684,9169,5558,9169,13684,5558,13684,9169,13556,9169,5558,5558,5942,9813,15088,9941,5942,15088,5942,5558,5558,9941,4534,6574,7470,4534,5558,9937,5558,5558,7470,9937,6574,9937,1430,1430,2,1462,5558,13009,5526,5558,3,1430,1430,13009,5558,5558,13622,5364,13556,4,13622,13556,13622,5558,5558,5,9685,9685,9941,8657,9169,5942,9941,9169,9941,9685,9685,5942,9169,9169,9937,8661,9685,7470,9937,9685,9937,9169,9169,7470,9169,9169,13009,9588,13684,6,13009,13684,13009,9169,9169,7,913,913,8,977,9169,13622,9105,9169,9,913,913,13622,4910,4910,7470,9937,9941,9937,9933,9941,7470,9933,4910,9937,9941,9941,13525,12497,5942,13009,13525,5942,13525,9941,9941,13009,1685,1685,13622,1749,9941,10,9877,9941,13622,1685,1685,11,9937,9937,13009,12501,7470,13525,13009,7470,13009,9937,9937,13525,1681,1681,12590,1745,9937,13622,9873,9937,12590,1681,1681,13622,4753,4753,9494,4817,13009,13622,12945,13009,9494,4753,4753,13622]) (by decide +kernel)
  change ∀ b ∈ [s584,s585,s586,s533,s537,s587,s557,s588,s589,s563,s590,s591], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s584) b584 <|
    PetersenLocalChildren.push (x := s585) b585 <|
    PetersenLocalChildren.push (x := s586) b586 <|
    PetersenLocalChildren.push (x := s533) b533 <|
    PetersenLocalChildren.push (x := s537) b537 <|
    PetersenLocalChildren.push (x := s587) b587 <|
    PetersenLocalChildren.push (x := s557) b557 <|
    PetersenLocalChildren.push (x := s588) b588 <|
    PetersenLocalChildren.push (x := s589) b589 <|
    PetersenLocalChildren.push (x := s563) b563 <|
    PetersenLocalChildren.push (x := s590) b590 <|
    PetersenLocalChildren.push (x := s591) b591 <|
    PetersenLocalChildren.nil
theorem b592 : Blocked tgt 7 s592 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s592 7 _ le
  decide +kernel
theorem b593 : Blocked tgt 7 s593 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s593 7 _ le
  decide +kernel
theorem b594 : Blocked tgt 7 s594 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s594 7 _ le
  decide +kernel
theorem b595 : Blocked tgt 7 s595 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s595 7 _ le
  decide +kernel
theorem b596 : Blocked tgt 7 s596 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s596 7 _ le
  decide +kernel
theorem b597 : Blocked tgt 7 s597 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s597 7 _ le
  decide +kernel
theorem b598 : Blocked tgt 7 s598 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s598 7 _ le
  decide +kernel
theorem b599 : Blocked tgt 7 s599 := by
  apply PetersenFastNode.node (nxt := #[s149,s150,s600,s548,s601,s602,s539,s603,s604,s565,s605,s606]) (hints := [5526,0,5558,1430,13009,1430,1462,13009,5558,1430,1,1430,13009,13009,11104,9169,2,9169,11104,3,11104,9169,13009,9169,13525,13525,5942,9941,13009,9941,12497,13009,5942,9941,13525,9941,13009,13009,7454,9937,13525,9937,12501,13525,7454,9937,13009,9937,13009,13009,7478,10961,4,10961,3382,5,7478,10961,13009,10961,4753,4753,13622,12945,13009,9494,4817,13009,13622,4753,4753,9494,9556,15072,9556,9169,1430,9169,9556,1430,9556,9169,15072,9169,1430,1430,1814,9813,15072,9941,1814,15072,1814,1430,1430,9941,406,6558,7454,406,1430,9937,1430,1430,7454,9937,6558,9937,1430,1430,3350,10961,6558,10961,3350,6558,3350,1430,1430,10961,1430,1430,9494,6880,15072,6,9494,15072,9494,1430,1430,7,9685,9685,9941,8657,9169,1814,9941,9169,9941,9685,9685,1814,9169,9169,9937,8661,9685,7454,9937,9685,9937,9169,9169,7454,9169,9169,10961,3094,11104,3350,10961,11104,10961,9169,9169,3350,913,913,8,977,9169,9494,9105,9169,9,913,913,9494,2846,2846,7454,9937,9941,9937,9933,9941,7454,9933,2846,9937,9941,9941,11477,10449,2846,10961,11477,2846,11477,9941,9941,10961,1685,1685,9494,1749,9941,10,9877,9941,9494,1685,1685,11,9937,9937,10961,10453,7454,11477,10961,7454,10961,9937,9937,11477,1681,1681,10526,1745,9937,9494,9873,9937,10526,1681,1681,9494,2705,2705,9494,2769,10961,10526,10897,10961,9494,2705,2705,10526]) (by decide +kernel)
  change ∀ b ∈ [s149,s150,s600,s548,s601,s602,s539,s603,s604,s565,s605,s606], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s149) b149 <|
    PetersenLocalChildren.push (x := s150) b150 <|
    PetersenLocalChildren.push (x := s600) b600 <|
    PetersenLocalChildren.push (x := s548) b548 <|
    PetersenLocalChildren.push (x := s601) b601 <|
    PetersenLocalChildren.push (x := s602) b602 <|
    PetersenLocalChildren.push (x := s539) b539 <|
    PetersenLocalChildren.push (x := s603) b603 <|
    PetersenLocalChildren.push (x := s604) b604 <|
    PetersenLocalChildren.push (x := s565) b565 <|
    PetersenLocalChildren.push (x := s605) b605 <|
    PetersenLocalChildren.push (x := s606) b606 <|
    PetersenLocalChildren.nil
theorem b607 : Blocked tgt 7 s607 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s607 7 _ le
  decide +kernel
theorem b608 : Blocked tgt 7 s608 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s608 7 _ le
  decide +kernel
theorem b609 : Blocked tgt 7 s609 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s609 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
