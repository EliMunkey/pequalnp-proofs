import M3StartData
import M3StartL0B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_0 : NoAtMost (0xe :: inputs 2) tgt 0 := by
  change NoAtMost [0xe,0xa,0xc] tgt 0
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 4); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 4); change false=true at x; contradiction)
    #[s0,s1] [14,15,15,15,16,16,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 0 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_0
end PetersenSmallStarts.M3
