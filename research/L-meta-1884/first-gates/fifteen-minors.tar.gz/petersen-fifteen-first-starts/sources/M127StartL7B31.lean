import M127StartData
import M127StartPins0
import M127StartL6B32
import M127StartL6B7
import M127StartL6B29
import M127StartL6B31
import M127StartL6B27
import M127StartL6B0
import M127StartL6B33
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1074 : Blocked tgt 7 s1074 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1074 7 _ le
  decide +kernel
theorem b1075 : Blocked tgt 7 s1075 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1075 7 _ le
  decide +kernel
theorem b1076 : Blocked tgt 7 s1076 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1076 7 _ le
  decide +kernel
theorem b1077 : Blocked tgt 7 s1077 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1077 7 _ le
  decide +kernel
theorem b1078 : Blocked tgt 7 s1078 := by
  apply PetersenFastNode.node (nxt := #[s1079,s225,s1080,s1081]) (hints := [13001,0,10968,10968,13001,9161,1,9161,1806,9933,1806,9933,3350,9929,3350,9929,3342,10953,3342,10953,9486,12937,9486,4745,5518,5518,9161,11096,9933,1806,9933,1806,9929,3350,9929,3350,10953,3342,10953,3342,2,9486,3,9486,15064,9161,15320,1806,9933,1806,9933,3350,9929,3350,9929,3342,10953,3342,10953,9486,6872,9486,6808,9677,8649,9933,9677,9161,8653,9929,9161,9161,3342,10953,9161,905,969,9097,905,2838,9929,9925,9925,9933,10441,11469,9933,1677,1741,9869,1677,9929,10445,10953,9929,1673,1737,9865,1673,2697,2761,10889,2697]) (by decide +kernel)
  change ∀ b ∈ [s1079,s225,s1080,s1081], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1079) b1079 <|
    PetersenLocalChildren.push (x := s225) b225 <|
    PetersenLocalChildren.push (x := s1080) b1080 <|
    PetersenLocalChildren.push (x := s1081) b1081 <|
    PetersenLocalChildren.nil
theorem b1083 : Blocked tgt 7 s1083 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1083 7 _ le
  decide +kernel
theorem b1084 : Blocked tgt 7 s1084 := by
  apply PetersenFastNode.node (nxt := #[s1085,s1086,s1089]) (hints := [10967,10967,13000,9160,11095,9160,13516,9932,12488,9932,13000,0,13000,9928,12492,9928,13000,10952,3341,10952,4744,12936,4808,4744,11095,9160,11095,9160,14551,15063,9932,5517,5517,3349,9928,3349,9928,3341,10952,3341,10952,9485,6871,9485,6807,9676,8648,9932,9676,9547,9160,9160,9547,9160,8652,9928,9160,9160,9047,10952,9160,904,968,9096,904,9932,1805,3349,9928,9924,9924,9932,10440,11468,9932,1676,1740,9868,1676,3349,9928,3349,9928,3341,10952,3341,10952,9485,1,9485,2,9928,10444,10952,9928,1672,1736,9864,1672,2696,2760,10888,2696]) (by decide +kernel)
  change ∀ b ∈ [s1085,s1086,s1089], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1085) b1085 <|
    PetersenLocalChildren.push (x := s1086) b1086 <|
    PetersenLocalChildren.push (x := s1089) b1089 <|
    PetersenLocalChildren.nil
theorem b1090 : Blocked tgt 7 s1090 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1090 7 _ le
  decide +kernel
theorem b1091 : Blocked tgt 7 s1091 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1091 7 _ le
  decide +kernel
theorem b1092 : Blocked tgt 7 s1092 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1092 7 _ le
  decide +kernel
theorem b1093 : Blocked tgt 7 s1093 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1093 7 _ le
  decide +kernel
theorem b1094 : Blocked tgt 7 s1094 := by
  apply PetersenFastNode.node (nxt := #[s1095,s1096,s1002,s226,s1049,s924,s1097,s1098,s1099,s20,s1100,s1101,s1071,s1102,s1081,s1086,s1103]) (hints := [2789,4758,6885,2789,0,1,4758,4758,11109,918,2,918,11109,3,11109,918,4758,918,5274,5274,1819,1690,4758,1690,4246,4758,1819,1690,5274,1690,4758,4758,3363,1686,5274,1686,4250,5274,3363,1686,4758,1686,4758,4758,3355,2710,4,2710,3355,5,3355,2710,4758,2710,4758,4758,9499,6,7,8,6885,6885,11109,918,9,918,7141,10,11109,918,6885,918,1819,5337,1819,1690,6885,1690,1819,6885,1819,1690,5337,1690,3363,6885,3363,1686,5337,1686,3363,5337,3363,1686,6885,1686,3355,4821,3355,2710,6885,2710,3355,6885,3355,2710,4821,2710,5531,6885,9499,5531,11,12,1434,1434,1690,406,918,1819,1690,918,1690,1434,1434,1819,918,918,1686,410,1434,3363,1686,1434,1686,918,918,3363,918,918,2710,9061,11109,3355,2710,11109,2710,918,918,3355,2853,2853,13,918,918,9499,918,918,14,2853,2853,9499,2851,2851,3363,1686,1690,1686,1682,1690,3363,1682,2851,1686,1690,1690,3226,2198,2851,2710,3226,2851,3226,1690,1690,2710,1819,1819,9499,1690,1690,15,1690,1690,9499,1819,1819,16,1686,1686,2710,2202,3363,3226,2710,3363,2710,1686,1686,3226,3363,3363,10531,1686,1686,9499,1686,1686,10531,3363,3363,9499,3355,3355,9499,2710,2710,10531,2710,2710,9499,3355,3355,10531]) (by decide +kernel)
  change ∀ b ∈ [s1095,s1096,s1002,s226,s1049,s924,s1097,s1098,s1099,s20,s1100,s1101,s1071,s1102,s1081,s1086,s1103], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1095) b1095 <|
    PetersenLocalChildren.push (x := s1096) b1096 <|
    PetersenLocalChildren.push (x := s1002) b1002 <|
    PetersenLocalChildren.push (x := s226) b226 <|
    PetersenLocalChildren.push (x := s1049) b1049 <|
    PetersenLocalChildren.push (x := s924) b924 <|
    PetersenLocalChildren.push (x := s1097) b1097 <|
    PetersenLocalChildren.push (x := s1098) b1098 <|
    PetersenLocalChildren.push (x := s1099) b1099 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s1100) b1100 <|
    PetersenLocalChildren.push (x := s1101) b1101 <|
    PetersenLocalChildren.push (x := s1071) b1071 <|
    PetersenLocalChildren.push (x := s1102) b1102 <|
    PetersenLocalChildren.push (x := s1081) b1081 <|
    PetersenLocalChildren.push (x := s1086) b1086 <|
    PetersenLocalChildren.push (x := s1103) b1103 <|
    PetersenLocalChildren.nil
theorem b1104 : Blocked tgt 7 s1104 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1104 7 _ le
  decide +kernel
theorem b1105 : Blocked tgt 7 s1105 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1105 7 _ le
  decide +kernel
theorem b1106 : Blocked tgt 7 s1106 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1106 7 _ le
  decide +kernel
theorem b1107 : Blocked tgt 7 s1107 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1107 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
