import M251StartData
import M251StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee :: inputs 7) tgt 7 := by
  change NoAtMost [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1] [386,387,387,387,388,388,1155,1155,902,903,903,903,904,904,1671,1671,1162,1164,387,387,1420,1420,2179,2179,902,903,903,903,904,904,2695,2695,2194,2196,387,387,2452,2452,1155,1155,2710,2712,903,903,2968,2968,1671,1671,3226,3228,387,387,3484,3484,3868,3868,2710,2712,903,903,2968,2968,6936,6936,4386,4387,4515,4515,388,388,5283,5283,4902,4903,5031,5031,904,904,5799,5799,5290,1164,4515,4515,1420,1420,6307,6307,4902,4903,5031,5031,904,904,6823,6823,6322,2196,4515,4515,2452,2452,5283,5283,6838,2712,5031,5031,2968,2968,5799,5799,7354,3228,4515,4515,3484,3484,3868,3868,6838,2712,5031,5031,2968,2968,11032,11032,8642,8643,8643,8643,8644,8644,9411,9411,9158,9159,9159,9159,9160,9160,9927,9927,9418,9420,8643,8643,9676,9676,10435,10435,9158,9159,9159,9159,9160,9160,10951,10951,2194,2196,8643,8643,2452,2452,9411,9411,2710,2712,9159,9159,2968,2968,9927,9927,3226,3228,8643,8643,3484,3484,3868,3868,2710,2712,9159,9159,2968,2968,6936,6936,12642,12643,12771,12771,8644,8644,13539,13539,13158,13159,13287,13287,9160,9160,14055,14055,13546,9420,12771,12771,9676,9676,14563,14563,13158,13159,13287,13287,9160,9160,15079,15079,6322,2196,12771,12771,2452,2452,13539,13539,6838,2712,13287,13287,2968,2968,14055,14055,7354,3228,12771,12771,3484,3484,3868,3868,6838,2712,13287,13287,2968,2968,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_0
end PetersenSmallStarts.M251
