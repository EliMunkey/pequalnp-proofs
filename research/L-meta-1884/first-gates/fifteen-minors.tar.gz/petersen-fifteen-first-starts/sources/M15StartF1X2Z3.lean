import M15StartData
import M15StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_3 : NoAtMost (0xc0c0 :: inputs 4) tgt 3 := by
  change NoAtMost [0xc0c0,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 3
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s14] [50,50,51,51,52,52,211,211,102,198,119,215,52,52,215,215,186,186,187,187,188,188,219,219,102,186,119,187,188,188,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s14], Blocked tgt 3 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_3
end PetersenSmallStarts.M15
