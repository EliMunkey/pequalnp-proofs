import M111StartData
import M111StartL6B0
import M111StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_1 : NoAtMost (0xcc00cc00cc00cc :: inputs 6) tgt 6 := by
  change NoAtMost [0xcc00cc00cc00cc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s79] [194,196,195,388,196,196,835,388,390,196,455,2180,196,196,839,2180,714,196,715,388,716,196,843,388,390,196,455,2180,716,196,1351,2180,1106,1236,195,1428,1236,1236,835,1428,1366,1236,455,3220,1236,1236,839,3220,1626,1236,715,1428,1756,1236,843,1428,1366,1236,455,3220,1756,1236,3740,3220,2210,196,2275,388,196,196,2915,388,2470,196,2535,2919,196,196,2919,2919,2730,196,2795,388,716,196,2923,388,2470,196,2535,3431,716,196,3431,3431,3186,1236,2275,1428,1236,1236,2915,1428,3446,1236,2535,2919,1236,1236,2919,2919,3706,1236,2795,1428,1756,1236,2923,1428,3446,1236,2535,2795,1756,1236,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s79], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_1
end PetersenSmallStarts.M111
