import M45StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 4) : Fin 16 := (#[0,2,4,6] : Array (Fin 16))[x.val]?.getD 0
theorem small0 : NoAtMost i2 (PetersenPackedPin.project r0 tgt) 0 := by
  have a : PetersenPackedPin.project r0 tgt = table 12 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 12 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
end PetersenSmallStarts.M45
