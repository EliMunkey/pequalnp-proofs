import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b10 : Blocked tgt 5 s10 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s10 5 _ le
  decide +kernel
theorem b21 : Blocked tgt 5 s21 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s21 5 _ le
  decide +kernel
theorem b22 : Blocked tgt 5 s22 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s22 5 _ le
  decide +kernel
theorem b29 : Blocked tgt 5 s29 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s29 5 _ le
  decide +kernel
theorem b32 : Blocked tgt 5 s32 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s32 5 _ le
  decide +kernel
theorem b33 : Blocked tgt 5 s33 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s33 5 _ le
  decide +kernel
theorem b34 : Blocked tgt 5 s34 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s34 5 _ le
  decide +kernel
theorem b35 : Blocked tgt 5 s35 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s35 5 _ le
  decide +kernel
theorem b36 : Blocked tgt 5 s36 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s36 5 _ le
  decide +kernel
theorem b37 : Blocked tgt 5 s37 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s37 5 _ le
  decide +kernel
theorem b38 : Blocked tgt 5 s38 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s38 5 _ le
  decide +kernel
theorem b39 : Blocked tgt 5 s39 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s39 5 _ le
  decide +kernel
theorem b40 : Blocked tgt 5 s40 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s40 5 _ le
  decide +kernel
theorem b51 : Blocked tgt 5 s51 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s51 5 _ le
  decide +kernel
theorem b58 : Blocked tgt 5 s58 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s58 5 _ le
  decide +kernel
theorem b59 : Blocked tgt 5 s59 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s59 5 _ le
  decide +kernel
end PetersenSmallStarts.M127
