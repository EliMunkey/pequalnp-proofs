import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_2 : NoAtMost (0x5050505050505050 :: inputs 6) tgt 7 := by
  change NoAtMost [0x5050505050505050,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s377] [194,390,195,390,196,774,835,774,390,390,455,390,196,774,839,774,714,390,715,390,716,716,843,843,390,390,455,390,716,716,1351,1351,1106,1430,195,1430,1236,1814,835,1814,1366,1430,455,1430,1236,1814,839,1814,714,1430,715,1430,716,716,843,843,1366,1430,455,1430,716,716,2375,2375,2146,2470,195,2470,2276,2854,835,2854,2406,2470,455,2470,2276,2854,839,2854,2666,2470,715,2470,2796,2796,843,843,2406,2470,455,2470,2796,2796,1351,1351,3186,3510,195,3510,3316,3894,835,3894,3446,3510,455,3510,3316,3894,839,3894,2666,3510,715,3510,2796,2796,843,843,3446,3510,455,3510,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s377], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s377) b377 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_2
end PetersenSmallStarts.M63
