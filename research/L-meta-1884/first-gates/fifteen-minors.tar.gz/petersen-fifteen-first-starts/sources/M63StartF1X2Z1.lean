import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_1 : NoAtMost (0xc0c0c0c0c0c0c0c :: inputs 6) tgt 7 := by
  change NoAtMost [0xc0c0c0c0c0c0c0c,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s676] [194,196,195,1668,196,196,835,1668,390,196,455,1668,196,196,839,1668,714,716,715,1676,716,716,843,1676,390,716,455,1676,716,716,1351,1676,1106,1236,195,1684,1236,1236,835,1684,1366,1236,455,1684,1236,1236,839,1684,714,716,715,843,716,716,843,843,1366,716,455,455,716,716,2375,2375,2146,2276,195,3748,2276,2276,835,3748,2406,2276,455,3748,2276,2276,839,3748,2666,2796,715,3756,2796,2796,843,3756,2406,2796,455,3756,2796,2796,1351,3756,3186,3316,195,3764,3316,3316,835,3764,3446,3316,455,3764,3316,3316,839,3764,2666,2796,715,843,2796,2796,843,843,3446,2796,455,455,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s676], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s676) b676 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_1
end PetersenSmallStarts.M63
