import M119StartData
import M119StartPins0
import M119StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 5 s0 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s0 5 _ le
  decide +kernel
theorem b1 : Blocked tgt 5 s1 := by
  intro k le c
  apply rejects_sound r9 i2 0 tgt small9 hot9 [] s1 5 _ le
  decide +kernel
theorem b2 : Blocked tgt 5 s2 := by
  intro k le c
  apply rejects_sound r9 i2 0 tgt small9 hot9 [] s2 5 _ le
  decide +kernel
theorem b3 : Blocked tgt 5 s3 := by
  intro k le c
  apply rejects_sound r9 i2 0 tgt small9 hot9 [] s3 5 _ le
  decide +kernel
theorem b4 : Blocked tgt 5 s4 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s4 5 _ le
  decide +kernel
theorem b5 : Blocked tgt 5 s5 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s5 5 _ le
  decide +kernel
theorem b6 : Blocked tgt 5 s6 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s6 5 _ le
  decide +kernel
theorem b7 : Blocked tgt 5 s7 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s7 5 _ le
  decide +kernel
theorem b8 : Blocked tgt 5 s8 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s8 5 _ le
  decide +kernel
theorem b9 : Blocked tgt 5 s9 := by
  apply PetersenFastNode.node (nxt := #[s10,s12]) (hints := [1236,1236,2919,2535,3510,2535,2659,2915,2663,2659,2919,3431,0,2919,839,2887,871,839,3510,2535,3510,2535,1428,3702,1428,1748,708,3431,1732,3431,1748,1910,3220,1748,2275,2279,2531,2275,2535,2486,3431,2535,455,487,2503,455,3171,3175,3171,3427,1428,1,3220,1428,1351,1383,3399,1351]) (by decide +kernel)
  change ∀ b ∈ [s10,s12], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.nil
theorem b13 : Blocked tgt 5 s13 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s13 5 _ le
  decide +kernel
theorem b14 : Blocked tgt 5 s14 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s14 5 _ le
  decide +kernel
theorem b15 : Blocked tgt 5 s15 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s15 5 _ le
  decide +kernel
theorem b16 : Blocked tgt 5 s16 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s16 5 _ le
  decide +kernel
theorem b17 : Blocked tgt 5 s17 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s17 5 _ le
  decide +kernel
theorem b18 : Blocked tgt 5 s18 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s18 5 _ le
  decide +kernel
end PetersenSmallStarts.M119
