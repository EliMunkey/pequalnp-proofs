import M55StartData
import M55StartL3B0
import M55StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b18 : Blocked tgt 4 s18 := by
  apply PetersenFastNode.node (nxt := #[s19]) (hints := [987,891,825,891,98,98,290,979,290,723,546,971,546,459,825,891,891,825,627,635,883,627,363,379,875,363,226,729,290,226,226,473,546,226,290,0,546,290]) (by decide +kernel)
  change ∀ b ∈ [s19], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.nil
theorem b20 : Blocked tgt 4 s20 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s20 4 _ le
  decide +kernel
theorem b21 : Blocked tgt 4 s21 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s21 4 _ le
  decide +kernel
theorem b22 : Blocked tgt 4 s22 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s22 4 _ le
  decide +kernel
theorem b23 : Blocked tgt 4 s23 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s23 4 _ le
  decide +kernel
theorem b24 : Blocked tgt 4 s24 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s24 4 _ le
  decide +kernel
theorem b25 : Blocked tgt 4 s25 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s25 4 _ le
  decide +kernel
theorem b26 : Blocked tgt 4 s26 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s26 4 _ le
  decide +kernel
theorem b27 : Blocked tgt 4 s27 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s27 4 _ le
  decide +kernel
theorem b28 : Blocked tgt 4 s28 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s28 4 _ le
  decide +kernel
theorem b29 : Blocked tgt 4 s29 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s29 4 _ le
  decide +kernel
theorem b30 : Blocked tgt 4 s30 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s30 4 _ le
  decide +kernel
theorem b31 : Blocked tgt 4 s31 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s31 4 _ le
  decide +kernel
theorem b32 : Blocked tgt 4 s32 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s32 4 _ le
  decide +kernel
end PetersenSmallStarts.M55
