import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_3 : NoAtMost (0xaa00aa00 :: inputs 5) tgt 4 := by
  change NoAtMost [0xaa00aa00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s11] [98,363,99,363,100,427,419,427,198,363,231,363,100,811,423,811,362,363,363,363,364,427,427,427,198,363,231,363,364,811,679,811,562,363,99,363,628,427,419,427,694,363,231,363,628,628,423,918,826,363,363,363,892,427,427,427,694,363,231,363,892,628,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s11], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_3
end PetersenSmallStarts.M47
