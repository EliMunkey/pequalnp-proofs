import M127StartData
import M127StartPins0
import M127StartL7B0
import M127StartL7B1
import M127StartL7B2
import M127StartL7B3
import M127StartL7B4
import M127StartL7B5
import M127StartL7B6
import M127StartL7B7
import M127StartL7B8
import M127StartL7B9
import M127StartL7B10
import M127StartL7B11
import M127StartL7B12
import M127StartL7B13
import M127StartL7B14
import M127StartL7B15
import M127StartL7B16
import M127StartL7B17
import M127StartL7B18
import M127StartL7B19
import M127StartL7B20
import M127StartL7B21
import M127StartL7B22
import M127StartL7B23
import M127StartL7B24
import M127StartL7B25
import M127StartL7B26
import M127StartL7B27
import M127StartL7B28
import M127StartL7B29
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 8 s0 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s0 8 _ le
  decide +kernel
theorem b1 : Blocked tgt 8 s1 := by
  apply PetersenFastNode.node (nxt := #[s2,s3,s4,s5,s6,s7,s8,s13,s16,s17,s25,s63,s64,s72,s73,s74,s75,s78,s80,s103,s104,s113,s114,s115,s116,s120,s121,s126,s129,s130,s131,s132,s133,s134,s135,s140,s143,s144,s145,s146,s147,s148,s157,s158,s162,s163,s164,s165,s166,s167,s176,s177,s180,s181,s184,s185,s188]) (hints := [9086,0,1,5603,5603,2,9214,3,9214,5603,5603,4,15149,3,5,5603,5603,5987,9986,6,9986,5987,7,5987,5603,5603,9986,6635,6635,7531,4579,5603,9982,7531,5603,7531,6635,6635,9982,5603,5603,7523,4587,6635,11006,7523,6635,7523,5603,5603,11006,1475,1475,8,1507,5603,13054,5571,5603,9,1475,1475,13054,5603,5603,13667,10,11,12,13667,13,13667,5603,5603,14,9214,9214,4,15277,2,15,9730,9730,9986,8702,9214,5987,9986,9214,9986,9730,9730,5987,9214,9214,9982,8706,9730,7531,9982,9730,9982,9214,9214,7531,9214,9214,11006,7523,16,7523,11006,17,11006,9214,9214,7523,9214,9214,13054,18,19,20,13054,21,13054,9214,9214,22,958,958,23,1022,9214,13667,9150,9214,24,958,958,13667,13985,25,13985,9986,26,9986,13985,27,13985,9986,28,9986,16045,29,16045,9982,30,9982,16045,31,16045,9982,32,9982,15521,33,15521,11006,34,11006,15521,35,15521,11006,36,11006,37,38,39,13054,40,13054,41,42,43,13054,44,13054,45,46,47,13667,48,13667,49,50,51,13667,52,13667,7019,7019,7531,9982,9986,9982,9978,9986,7531,9978,7019,9982,9986,9986,11522,10494,7019,11006,11522,7019,11522,9986,9986,11006,9986,9986,13570,12542,5987,13054,13570,5987,13570,9986,9986,13054,1730,1730,13667,1794,9986,53,9922,9986,13667,1730,1730,54,9982,9982,11006,10498,7531,11522,11006,7531,11006,9982,9982,11522,9982,9982,13054,12546,7531,13570,13054,7531,13054,9982,9982,13570,1726,1726,14699,1790,9982,13667,9918,9982,14699,1726,1726,13667,11006,11006,13054,3427,7523,55,13054,7523,13054,11006,11006,56,2750,2750,13667,2814,11006,14699,10942,11006,13667,2750,2750,14699,4798,4798,9539,4862,13054,13667,12990,13054,9539,4798,4798,13667]) (by decide +kernel)
  change ∀ b ∈ [s2,s3,s4,s5,s6,s7,s8,s13,s16,s17,s25,s63,s64,s72,s73,s74,s75,s78,s80,s103,s104,s113,s114,s115,s116,s120,s121,s126,s129,s130,s131,s132,s133,s134,s135,s140,s143,s144,s145,s146,s147,s148,s157,s158,s162,s163,s164,s165,s166,s167,s176,s177,s180,s181,s184,s185,s188], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.push (x := s63) b63 <|
    PetersenLocalChildren.push (x := s64) b64 <|
    PetersenLocalChildren.push (x := s72) b72 <|
    PetersenLocalChildren.push (x := s73) b73 <|
    PetersenLocalChildren.push (x := s74) b74 <|
    PetersenLocalChildren.push (x := s75) b75 <|
    PetersenLocalChildren.push (x := s78) b78 <|
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s103) b103 <|
    PetersenLocalChildren.push (x := s104) b104 <|
    PetersenLocalChildren.push (x := s113) b113 <|
    PetersenLocalChildren.push (x := s114) b114 <|
    PetersenLocalChildren.push (x := s115) b115 <|
    PetersenLocalChildren.push (x := s116) b116 <|
    PetersenLocalChildren.push (x := s120) b120 <|
    PetersenLocalChildren.push (x := s121) b121 <|
    PetersenLocalChildren.push (x := s126) b126 <|
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.push (x := s130) b130 <|
    PetersenLocalChildren.push (x := s131) b131 <|
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.push (x := s133) b133 <|
    PetersenLocalChildren.push (x := s134) b134 <|
    PetersenLocalChildren.push (x := s135) b135 <|
    PetersenLocalChildren.push (x := s140) b140 <|
    PetersenLocalChildren.push (x := s143) b143 <|
    PetersenLocalChildren.push (x := s144) b144 <|
    PetersenLocalChildren.push (x := s145) b145 <|
    PetersenLocalChildren.push (x := s146) b146 <|
    PetersenLocalChildren.push (x := s147) b147 <|
    PetersenLocalChildren.push (x := s148) b148 <|
    PetersenLocalChildren.push (x := s157) b157 <|
    PetersenLocalChildren.push (x := s158) b158 <|
    PetersenLocalChildren.push (x := s162) b162 <|
    PetersenLocalChildren.push (x := s163) b163 <|
    PetersenLocalChildren.push (x := s164) b164 <|
    PetersenLocalChildren.push (x := s165) b165 <|
    PetersenLocalChildren.push (x := s166) b166 <|
    PetersenLocalChildren.push (x := s167) b167 <|
    PetersenLocalChildren.push (x := s176) b176 <|
    PetersenLocalChildren.push (x := s177) b177 <|
    PetersenLocalChildren.push (x := s180) b180 <|
    PetersenLocalChildren.push (x := s181) b181 <|
    PetersenLocalChildren.push (x := s184) b184 <|
    PetersenLocalChildren.push (x := s185) b185 <|
    PetersenLocalChildren.push (x := s188) b188 <|
    PetersenLocalChildren.nil
theorem b189 : Blocked tgt 8 s189 := by
  apply PetersenFastNode.node (nxt := #[s6,s190,s191,s192,s4,s197,s198,s203,s204,s205,s206,s207,s208,s209,s210,s211,s212,s213,s214,s215,s216,s217,s235,s236,s237,s238,s239,s251,s252,s253,s254,s255,s256,s257,s258,s259,s261,s262,s263,s264,s278,s279,s280,s281,s282,s283,s284,s285,s288,s293,s294,s295]) (hints := [5598,0,5598,15144,1,2,9209,0,15272,9209,3,4,5982,5,5982,9981,6,9981,5982,7,5982,9981,8,9981,7526,9,7526,9977,10,9977,7526,11,7526,9977,12,9977,7518,13,7518,11001,14,11001,7518,15,7518,11001,16,11001,17,18,19,13049,20,13049,21,22,23,13049,24,13049,13662,25,13662,26,27,28,13662,29,13662,30,31,32,15272,2,15272,5598,5598,4,15400,33,34,5598,5598,5982,9981,35,9981,5982,36,5982,9981,5598,9981,6630,6630,7526,9977,5598,9977,7526,5598,7526,9977,6630,9977,5598,5598,7518,11001,6630,11001,7518,6630,7518,11001,5598,11001,1470,1470,37,13049,5598,13049,5566,5598,38,13049,1470,13049,5598,5598,13662,39,40,41,13662,42,13662,5598,5598,43,9981,13724,9981,5726,15272,5982,9981,15272,9981,13724,13724,5982,9977,15272,9977,7270,13724,7526,9977,13724,9977,15272,15272,7526,11001,13208,11001,13224,15272,7518,11001,15272,11001,13208,13208,7518,13049,11144,13049,11176,15272,44,13049,15272,13049,11144,11144,45,7016,7016,46,7080,15272,13662,15208,15272,47,7016,7016,13662,7014,7014,7526,9977,9981,9977,9973,9981,7526,9973,7014,9977,9981,9981,11517,10489,7014,11001,11517,7014,11517,9981,9981,11001,9981,9981,13565,12537,5982,13049,13565,5982,13565,9981,9981,13049,1725,1725,13662,1789,9981,48,9917,9981,13662,1725,1725,49,9977,9977,11001,10493,7526,11517,11001,7526,11001,9977,9977,11517,9977,9977,13049,12541,7526,13565,13049,7526,13049,9977,9977,13565,1721,1721,14694,1785,9977,13662,9913,9977,14694,1721,1721,13662,11001,11001,13049,3422,7518,50,13049,7518,13049,11001,11001,51,2745,2745,13662,2809,11001,14694,10937,11001,13662,2745,2745,14694,4793,4793,9534,4857,13049,13662,12985,13049,9534,4793,4793,13662]) (by decide +kernel)
  change ∀ b ∈ [s6,s190,s191,s192,s4,s197,s198,s203,s204,s205,s206,s207,s208,s209,s210,s211,s212,s213,s214,s215,s216,s217,s235,s236,s237,s238,s239,s251,s252,s253,s254,s255,s256,s257,s258,s259,s261,s262,s263,s264,s278,s279,s280,s281,s282,s283,s284,s285,s288,s293,s294,s295], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s190) b190 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.push (x := s192) b192 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s197) b197 <|
    PetersenLocalChildren.push (x := s198) b198 <|
    PetersenLocalChildren.push (x := s203) b203 <|
    PetersenLocalChildren.push (x := s204) b204 <|
    PetersenLocalChildren.push (x := s205) b205 <|
    PetersenLocalChildren.push (x := s206) b206 <|
    PetersenLocalChildren.push (x := s207) b207 <|
    PetersenLocalChildren.push (x := s208) b208 <|
    PetersenLocalChildren.push (x := s209) b209 <|
    PetersenLocalChildren.push (x := s210) b210 <|
    PetersenLocalChildren.push (x := s211) b211 <|
    PetersenLocalChildren.push (x := s212) b212 <|
    PetersenLocalChildren.push (x := s213) b213 <|
    PetersenLocalChildren.push (x := s214) b214 <|
    PetersenLocalChildren.push (x := s215) b215 <|
    PetersenLocalChildren.push (x := s216) b216 <|
    PetersenLocalChildren.push (x := s217) b217 <|
    PetersenLocalChildren.push (x := s235) b235 <|
    PetersenLocalChildren.push (x := s236) b236 <|
    PetersenLocalChildren.push (x := s237) b237 <|
    PetersenLocalChildren.push (x := s238) b238 <|
    PetersenLocalChildren.push (x := s239) b239 <|
    PetersenLocalChildren.push (x := s251) b251 <|
    PetersenLocalChildren.push (x := s252) b252 <|
    PetersenLocalChildren.push (x := s253) b253 <|
    PetersenLocalChildren.push (x := s254) b254 <|
    PetersenLocalChildren.push (x := s255) b255 <|
    PetersenLocalChildren.push (x := s256) b256 <|
    PetersenLocalChildren.push (x := s257) b257 <|
    PetersenLocalChildren.push (x := s258) b258 <|
    PetersenLocalChildren.push (x := s259) b259 <|
    PetersenLocalChildren.push (x := s261) b261 <|
    PetersenLocalChildren.push (x := s262) b262 <|
    PetersenLocalChildren.push (x := s263) b263 <|
    PetersenLocalChildren.push (x := s264) b264 <|
    PetersenLocalChildren.push (x := s278) b278 <|
    PetersenLocalChildren.push (x := s279) b279 <|
    PetersenLocalChildren.push (x := s280) b280 <|
    PetersenLocalChildren.push (x := s281) b281 <|
    PetersenLocalChildren.push (x := s282) b282 <|
    PetersenLocalChildren.push (x := s283) b283 <|
    PetersenLocalChildren.push (x := s284) b284 <|
    PetersenLocalChildren.push (x := s285) b285 <|
    PetersenLocalChildren.push (x := s288) b288 <|
    PetersenLocalChildren.push (x := s293) b293 <|
    PetersenLocalChildren.push (x := s294) b294 <|
    PetersenLocalChildren.push (x := s295) b295 <|
    PetersenLocalChildren.nil
theorem b296 : Blocked tgt 8 s296 := by
  apply PetersenFastNode.node (nxt := #[s6,s74,s191,s7,s297,s298,s299,s314,s315,s316,s317,s318,s319,s320,s321,s334,s335,s336,s337,s350,s351,s352,s353,s368,s369,s370,s371,s372,s373,s374,s375,s388,s389,s390,s391,s392,s393,s394,s395,s407,s408,s409,s410,s411,s412,s2,s3,s413,s414,s415,s416,s417,s418,s419,s420,s421,s422,s423,s424]) (hints := [5605,0,15151,5605,1,2,9216,0,15279,9216,3,4,9988,5,9988,6,7,8,9988,9,9988,10,11,12,9984,13,9984,14,15,16,9984,17,9984,18,19,20,11008,21,11008,22,23,24,11008,25,11008,26,27,28,13056,29,13056,30,31,32,13056,33,13056,34,35,36,13669,37,13669,38,39,40,13669,41,13669,42,43,44,9088,45,46,15279,2,15279,15151,15151,4,5989,13603,5989,9860,15151,9988,5989,15151,5989,13603,13603,9988,7533,15151,7533,9856,13603,9984,7533,13603,7533,15151,15151,9984,7525,13087,7525,13103,15151,11008,7525,15151,7525,13087,13087,11008,11023,11023,47,11055,15151,13056,15119,15151,48,11023,11023,13056,13669,6895,13669,6959,15151,49,13669,15151,13669,6895,6895,50,9988,13731,9988,5733,15279,5989,9988,15279,9988,13731,13731,5989,9984,15279,9984,7277,13731,7533,9984,13731,9984,15279,15279,7533,11008,13215,11008,13231,15279,7525,11008,15279,11008,13215,13215,7525,13056,11151,13056,11183,15279,51,13056,15279,13056,11151,11151,52,7023,7023,53,7087,15279,13669,15215,15279,54,7023,7023,13669,7021,7021,7533,9984,9988,9984,9980,9988,7533,9980,7021,9984,9988,9988,11524,10496,7021,11008,11524,7021,11524,9988,9988,11008,9988,9988,13572,12544,5989,13056,13572,5989,13572,9988,9988,13056,1732,1732,13669,1796,9988,55,9924,9988,13669,1732,1732,56,9984,9984,11008,10500,7533,11524,11008,7533,11008,9984,9984,11524,9984,9984,13056,12548,7533,13572,13056,7533,13056,9984,9984,13572,1728,1728,14701,1792,9984,13669,9920,9984,14701,1728,1728,13669,11008,11008,13056,3429,7525,57,13056,7525,13056,11008,11008,58,2752,2752,13669,2816,11008,14701,10944,11008,13669,2752,2752,14701,4800,4800,9541,4864,13056,13669,12992,13056,9541,4800,4800,13669]) (by decide +kernel)
  change ∀ b ∈ [s6,s74,s191,s7,s297,s298,s299,s314,s315,s316,s317,s318,s319,s320,s321,s334,s335,s336,s337,s350,s351,s352,s353,s368,s369,s370,s371,s372,s373,s374,s375,s388,s389,s390,s391,s392,s393,s394,s395,s407,s408,s409,s410,s411,s412,s2,s3,s413,s414,s415,s416,s417,s418,s419,s420,s421,s422,s423,s424], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s74) b74 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s297) b297 <|
    PetersenLocalChildren.push (x := s298) b298 <|
    PetersenLocalChildren.push (x := s299) b299 <|
    PetersenLocalChildren.push (x := s314) b314 <|
    PetersenLocalChildren.push (x := s315) b315 <|
    PetersenLocalChildren.push (x := s316) b316 <|
    PetersenLocalChildren.push (x := s317) b317 <|
    PetersenLocalChildren.push (x := s318) b318 <|
    PetersenLocalChildren.push (x := s319) b319 <|
    PetersenLocalChildren.push (x := s320) b320 <|
    PetersenLocalChildren.push (x := s321) b321 <|
    PetersenLocalChildren.push (x := s334) b334 <|
    PetersenLocalChildren.push (x := s335) b335 <|
    PetersenLocalChildren.push (x := s336) b336 <|
    PetersenLocalChildren.push (x := s337) b337 <|
    PetersenLocalChildren.push (x := s350) b350 <|
    PetersenLocalChildren.push (x := s351) b351 <|
    PetersenLocalChildren.push (x := s352) b352 <|
    PetersenLocalChildren.push (x := s353) b353 <|
    PetersenLocalChildren.push (x := s368) b368 <|
    PetersenLocalChildren.push (x := s369) b369 <|
    PetersenLocalChildren.push (x := s370) b370 <|
    PetersenLocalChildren.push (x := s371) b371 <|
    PetersenLocalChildren.push (x := s372) b372 <|
    PetersenLocalChildren.push (x := s373) b373 <|
    PetersenLocalChildren.push (x := s374) b374 <|
    PetersenLocalChildren.push (x := s375) b375 <|
    PetersenLocalChildren.push (x := s388) b388 <|
    PetersenLocalChildren.push (x := s389) b389 <|
    PetersenLocalChildren.push (x := s390) b390 <|
    PetersenLocalChildren.push (x := s391) b391 <|
    PetersenLocalChildren.push (x := s392) b392 <|
    PetersenLocalChildren.push (x := s393) b393 <|
    PetersenLocalChildren.push (x := s394) b394 <|
    PetersenLocalChildren.push (x := s395) b395 <|
    PetersenLocalChildren.push (x := s407) b407 <|
    PetersenLocalChildren.push (x := s408) b408 <|
    PetersenLocalChildren.push (x := s409) b409 <|
    PetersenLocalChildren.push (x := s410) b410 <|
    PetersenLocalChildren.push (x := s411) b411 <|
    PetersenLocalChildren.push (x := s412) b412 <|
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s413) b413 <|
    PetersenLocalChildren.push (x := s414) b414 <|
    PetersenLocalChildren.push (x := s415) b415 <|
    PetersenLocalChildren.push (x := s416) b416 <|
    PetersenLocalChildren.push (x := s417) b417 <|
    PetersenLocalChildren.push (x := s418) b418 <|
    PetersenLocalChildren.push (x := s419) b419 <|
    PetersenLocalChildren.push (x := s420) b420 <|
    PetersenLocalChildren.push (x := s421) b421 <|
    PetersenLocalChildren.push (x := s422) b422 <|
    PetersenLocalChildren.push (x := s423) b423 <|
    PetersenLocalChildren.push (x := s424) b424 <|
    PetersenLocalChildren.nil
theorem b425 : Blocked tgt 8 s425 := by
  apply PetersenFastNode.node (nxt := #[s6,s426,s427,s316,s428,s203,s432,s433,s434,s435,s436,s449,s450,s451,s452,s471,s472,s473,s474,s475,s476,s477,s478,s479,s480,s481,s482,s494,s495,s496,s497,s498,s499,s13,s261,s500,s501,s502,s503,s504,s505,s506,s507,s508,s509,s510,s511,s514,s515,s516,s517]) (hints := [5597,0,15143,5597,1,2,9208,3,9208,9724,4,9724,9208,5,9208,9724,6,9724,9980,0,5981,9980,7,8,9976,9,9976,10,11,12,9976,13,9976,14,15,16,11000,17,11000,11516,18,11516,11000,19,11000,11516,20,11516,13048,21,13048,13564,22,13564,13048,23,13048,13564,24,13564,13661,25,13661,26,27,28,13661,29,13661,30,31,32,15143,15143,15271,9724,33,9724,15271,34,15271,9724,15143,9724,5981,2,5981,15143,15143,8,6109,35,36,7525,15143,7525,9848,37,9976,7525,38,7525,15143,15143,9976,7517,13079,7517,11516,15143,11516,7517,15143,7517,11516,13079,11516,11015,11015,39,13564,15143,13564,15111,15143,40,13564,11015,13564,13661,6887,13661,6951,15143,41,13661,15143,13661,6887,6887,42,9724,9724,13979,9208,9208,5981,9208,9208,13979,9724,9724,5981,8692,8692,9976,8700,9724,7525,9716,9724,9976,8692,8692,7525,9724,9724,11516,13223,15271,7517,11516,15271,11516,9724,9724,7517,9724,9724,13564,11175,15271,43,13564,15271,13564,9724,9724,44,1468,1468,45,1532,9724,13661,9660,9724,46,1468,1468,13661,7013,7013,7525,9976,5981,9976,7525,5981,7525,9976,7013,9976,11516,5981,11516,11000,7013,11000,11516,7013,11516,11000,5981,11000,13564,1853,13564,13048,5981,13048,13564,5981,13564,13048,1853,13048,5981,5981,13661,5787,13979,47,13661,13979,13661,5981,5981,48,10484,9976,10484,10492,7525,11516,10484,7525,10484,11508,9976,11516,12532,9976,12532,12540,7525,13564,12532,7525,12532,13556,9976,13564,1720,1720,14693,1784,9976,13661,9912,9976,14693,1720,1720,13661,11516,11516,13564,3421,7517,49,13564,7517,13564,11516,11516,50,3260,3260,13661,3324,11516,14693,11452,11516,13661,3260,3260,14693,5308,5308,9533,5372,13564,13661,13500,13564,9533,5308,5308,13661]) (by decide +kernel)
  change ∀ b ∈ [s6,s426,s427,s316,s428,s203,s432,s433,s434,s435,s436,s449,s450,s451,s452,s471,s472,s473,s474,s475,s476,s477,s478,s479,s480,s481,s482,s494,s495,s496,s497,s498,s499,s13,s261,s500,s501,s502,s503,s504,s505,s506,s507,s508,s509,s510,s511,s514,s515,s516,s517], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s426) b426 <|
    PetersenLocalChildren.push (x := s427) b427 <|
    PetersenLocalChildren.push (x := s316) b316 <|
    PetersenLocalChildren.push (x := s428) b428 <|
    PetersenLocalChildren.push (x := s203) b203 <|
    PetersenLocalChildren.push (x := s432) b432 <|
    PetersenLocalChildren.push (x := s433) b433 <|
    PetersenLocalChildren.push (x := s434) b434 <|
    PetersenLocalChildren.push (x := s435) b435 <|
    PetersenLocalChildren.push (x := s436) b436 <|
    PetersenLocalChildren.push (x := s449) b449 <|
    PetersenLocalChildren.push (x := s450) b450 <|
    PetersenLocalChildren.push (x := s451) b451 <|
    PetersenLocalChildren.push (x := s452) b452 <|
    PetersenLocalChildren.push (x := s471) b471 <|
    PetersenLocalChildren.push (x := s472) b472 <|
    PetersenLocalChildren.push (x := s473) b473 <|
    PetersenLocalChildren.push (x := s474) b474 <|
    PetersenLocalChildren.push (x := s475) b475 <|
    PetersenLocalChildren.push (x := s476) b476 <|
    PetersenLocalChildren.push (x := s477) b477 <|
    PetersenLocalChildren.push (x := s478) b478 <|
    PetersenLocalChildren.push (x := s479) b479 <|
    PetersenLocalChildren.push (x := s480) b480 <|
    PetersenLocalChildren.push (x := s481) b481 <|
    PetersenLocalChildren.push (x := s482) b482 <|
    PetersenLocalChildren.push (x := s494) b494 <|
    PetersenLocalChildren.push (x := s495) b495 <|
    PetersenLocalChildren.push (x := s496) b496 <|
    PetersenLocalChildren.push (x := s497) b497 <|
    PetersenLocalChildren.push (x := s498) b498 <|
    PetersenLocalChildren.push (x := s499) b499 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s261) b261 <|
    PetersenLocalChildren.push (x := s500) b500 <|
    PetersenLocalChildren.push (x := s501) b501 <|
    PetersenLocalChildren.push (x := s502) b502 <|
    PetersenLocalChildren.push (x := s503) b503 <|
    PetersenLocalChildren.push (x := s504) b504 <|
    PetersenLocalChildren.push (x := s505) b505 <|
    PetersenLocalChildren.push (x := s506) b506 <|
    PetersenLocalChildren.push (x := s507) b507 <|
    PetersenLocalChildren.push (x := s508) b508 <|
    PetersenLocalChildren.push (x := s509) b509 <|
    PetersenLocalChildren.push (x := s510) b510 <|
    PetersenLocalChildren.push (x := s511) b511 <|
    PetersenLocalChildren.push (x := s514) b514 <|
    PetersenLocalChildren.push (x := s515) b515 <|
    PetersenLocalChildren.push (x := s516) b516 <|
    PetersenLocalChildren.push (x := s517) b517 <|
    PetersenLocalChildren.nil
theorem b518 : Blocked tgt 8 s518 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s518 8 _ le
  decide +kernel
theorem b519 : Blocked tgt 8 s519 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s519 8 _ le
  decide +kernel
theorem b520 : Blocked tgt 8 s520 := by
  apply PetersenFastNode.node (nxt := #[s521,s502,s522,s523,s524,s525,s6,s526,s527,s528,s529,s530,s534,s540,s541,s542,s544,s131,s545,s546,s551,s559,s560,s561,s566,s567,s568,s569,s570,s571,s572,s573,s574,s575,s576,s577,s578,s579,s580,s581,s582,s583,s592,s593,s594,s595,s596,s597,s598,s599,s607,s608,s609,s610,s611,s612,s613,s614,s615]) (hints := [15279,13603,15279,9216,5605,9216,15279,5605,15279,9216,13603,9216,5605,5605,5989,9860,0,9988,5989,1,5989,5605,5605,9988,4581,2,3,5605,5605,4,9984,5,9984,5605,5605,6,6637,5,7,5605,5605,7525,11008,8,11008,7525,9,7525,5605,5605,11008,1477,1477,10,1509,5605,13056,5573,5605,11,1477,1477,13056,5605,5605,13669,5411,13603,12,13669,13603,13669,5605,5605,13,9732,9732,9988,8704,9216,5989,9988,9216,9988,9732,9732,5989,9216,9216,9984,8708,9732,14,9984,9732,9984,9216,9216,15,15279,15279,16,9216,9216,17,9216,9216,18,15279,15279,19,9216,9216,11008,13231,15279,7525,11008,15279,11008,9216,9216,7525,9216,9216,13056,11183,15279,20,13056,15279,13056,9216,9216,21,960,960,22,1024,9216,13669,9152,9216,23,960,960,13669,7021,7021,24,9984,9988,9984,9980,9988,25,9980,7021,9984,7021,7021,26,9988,9988,27,9988,9988,28,7021,7021,29,9988,9988,11524,10496,7021,11008,11524,7021,11524,9988,9988,11008,9988,9988,13572,12544,5989,13056,13572,5989,13572,9988,9988,13056,1732,1732,13669,1796,9988,30,9924,9988,13669,1732,1732,31,9984,9984,6,7533,4,32,9984,9984,11008,10500,33,11524,11008,34,11008,9984,9984,11524,9984,9984,13056,12548,35,13572,13056,36,13056,9984,9984,13572,1728,1728,14701,1792,9984,13669,9920,9984,14701,1728,1728,13669,37,38,39,11008,40,11008,41,42,43,11008,44,11008,45,46,47,13056,48,13056,49,50,51,13056,52,13056,14701,53,14701,13669,54,13669,14701,55,14701,13669,56,13669,11008,11008,13056,3429,7525,57,13056,7525,13056,11008,11008,58,2752,2752,13669,2816,11008,14701,10944,11008,13669,2752,2752,14701,4800,4800,9541,4864,13056,13669,12992,13056,9541,4800,4800,13669]) (by decide +kernel)
  change ∀ b ∈ [s521,s502,s522,s523,s524,s525,s6,s526,s527,s528,s529,s530,s534,s540,s541,s542,s544,s131,s545,s546,s551,s559,s560,s561,s566,s567,s568,s569,s570,s571,s572,s573,s574,s575,s576,s577,s578,s579,s580,s581,s582,s583,s592,s593,s594,s595,s596,s597,s598,s599,s607,s608,s609,s610,s611,s612,s613,s614,s615], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s521) b521 <|
    PetersenLocalChildren.push (x := s502) b502 <|
    PetersenLocalChildren.push (x := s522) b522 <|
    PetersenLocalChildren.push (x := s523) b523 <|
    PetersenLocalChildren.push (x := s524) b524 <|
    PetersenLocalChildren.push (x := s525) b525 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s526) b526 <|
    PetersenLocalChildren.push (x := s527) b527 <|
    PetersenLocalChildren.push (x := s528) b528 <|
    PetersenLocalChildren.push (x := s529) b529 <|
    PetersenLocalChildren.push (x := s530) b530 <|
    PetersenLocalChildren.push (x := s534) b534 <|
    PetersenLocalChildren.push (x := s540) b540 <|
    PetersenLocalChildren.push (x := s541) b541 <|
    PetersenLocalChildren.push (x := s542) b542 <|
    PetersenLocalChildren.push (x := s544) b544 <|
    PetersenLocalChildren.push (x := s131) b131 <|
    PetersenLocalChildren.push (x := s545) b545 <|
    PetersenLocalChildren.push (x := s546) b546 <|
    PetersenLocalChildren.push (x := s551) b551 <|
    PetersenLocalChildren.push (x := s559) b559 <|
    PetersenLocalChildren.push (x := s560) b560 <|
    PetersenLocalChildren.push (x := s561) b561 <|
    PetersenLocalChildren.push (x := s566) b566 <|
    PetersenLocalChildren.push (x := s567) b567 <|
    PetersenLocalChildren.push (x := s568) b568 <|
    PetersenLocalChildren.push (x := s569) b569 <|
    PetersenLocalChildren.push (x := s570) b570 <|
    PetersenLocalChildren.push (x := s571) b571 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s573) b573 <|
    PetersenLocalChildren.push (x := s574) b574 <|
    PetersenLocalChildren.push (x := s575) b575 <|
    PetersenLocalChildren.push (x := s576) b576 <|
    PetersenLocalChildren.push (x := s577) b577 <|
    PetersenLocalChildren.push (x := s578) b578 <|
    PetersenLocalChildren.push (x := s579) b579 <|
    PetersenLocalChildren.push (x := s580) b580 <|
    PetersenLocalChildren.push (x := s581) b581 <|
    PetersenLocalChildren.push (x := s582) b582 <|
    PetersenLocalChildren.push (x := s583) b583 <|
    PetersenLocalChildren.push (x := s592) b592 <|
    PetersenLocalChildren.push (x := s593) b593 <|
    PetersenLocalChildren.push (x := s594) b594 <|
    PetersenLocalChildren.push (x := s595) b595 <|
    PetersenLocalChildren.push (x := s596) b596 <|
    PetersenLocalChildren.push (x := s597) b597 <|
    PetersenLocalChildren.push (x := s598) b598 <|
    PetersenLocalChildren.push (x := s599) b599 <|
    PetersenLocalChildren.push (x := s607) b607 <|
    PetersenLocalChildren.push (x := s608) b608 <|
    PetersenLocalChildren.push (x := s609) b609 <|
    PetersenLocalChildren.push (x := s610) b610 <|
    PetersenLocalChildren.push (x := s611) b611 <|
    PetersenLocalChildren.push (x := s612) b612 <|
    PetersenLocalChildren.push (x := s613) b613 <|
    PetersenLocalChildren.push (x := s614) b614 <|
    PetersenLocalChildren.push (x := s615) b615 <|
    PetersenLocalChildren.nil
theorem b616 : Blocked tgt 8 s616 := by
  apply PetersenFastNode.node (nxt := #[s6,s617,s618,s336,s619,s207,s623,s624,s625,s638,s639,s451,s640,s641,s642,s643,s524,s644,s645,s646,s647,s648,s649,s650,s651,s652,s653,s664,s665,s666,s667,s668,s669,s670,s503,s671,s672,s673,s674,s675,s676,s677,s678,s679,s680,s681,s682,s685,s686,s687,s688]) (hints := [5597,0,5597,6629,1,2,9724,3,9724,9208,4,9208,9724,5,9724,9208,6,9208,9980,7,9980,8,9,10,9980,11,9980,12,13,14,9976,0,7525,9976,15,16,11516,17,11516,11000,18,11000,11516,19,11516,11000,20,11000,13564,21,13564,13048,22,13048,13564,23,13564,13048,24,13048,13661,25,13661,26,27,28,13661,29,13661,30,31,32,15271,13595,15271,9208,5597,9208,15271,5597,15271,9208,13595,9208,5597,5597,5981,9852,33,9980,5981,34,5981,5597,5597,9980,7525,2,7525,5597,5597,16,7653,35,36,5597,5597,7517,11000,37,11000,7517,38,7517,11000,5597,11000,1469,1469,39,13048,5597,13048,5565,5597,40,13048,1469,13048,5597,5597,13661,5403,13595,41,13661,13595,13661,5597,5597,42,8692,8692,9980,8696,9208,5981,9204,9208,9980,8692,8692,5981,9208,9208,16039,9724,9724,7525,9724,9724,16039,9208,9208,7525,9208,9208,11000,13223,15271,7517,11000,15271,11000,9208,9208,7517,9208,9208,13048,11175,15271,43,13048,15271,13048,9208,9208,44,952,952,45,1016,9208,13661,9144,9208,46,952,952,13661,7013,7013,7525,9980,9980,16039,9980,9980,7525,7013,7013,16039,10484,9980,10484,10488,7013,11000,10484,7013,10484,10996,9980,11000,12532,9980,12532,12536,5981,13048,12532,5981,12532,13044,9980,13048,1724,1724,13661,1788,9980,47,9916,9980,13661,1724,1724,48,11000,13975,11000,11516,7525,11516,11000,7525,11000,11516,13975,11516,13048,3397,13048,13564,7525,13564,13048,7525,13048,13564,3397,13564,7525,7525,14693,12637,16039,13661,14693,16039,14693,7525,7525,13661,11000,11000,13048,3421,7517,49,13048,7517,13048,11000,11000,50,2744,2744,13661,2808,11000,14693,10936,11000,13661,2744,2744,14693,4792,4792,9533,4856,13048,13661,12984,13048,9533,4792,4792,13661]) (by decide +kernel)
  change ∀ b ∈ [s6,s617,s618,s336,s619,s207,s623,s624,s625,s638,s639,s451,s640,s641,s642,s643,s524,s644,s645,s646,s647,s648,s649,s650,s651,s652,s653,s664,s665,s666,s667,s668,s669,s670,s503,s671,s672,s673,s674,s675,s676,s677,s678,s679,s680,s681,s682,s685,s686,s687,s688], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s617) b617 <|
    PetersenLocalChildren.push (x := s618) b618 <|
    PetersenLocalChildren.push (x := s336) b336 <|
    PetersenLocalChildren.push (x := s619) b619 <|
    PetersenLocalChildren.push (x := s207) b207 <|
    PetersenLocalChildren.push (x := s623) b623 <|
    PetersenLocalChildren.push (x := s624) b624 <|
    PetersenLocalChildren.push (x := s625) b625 <|
    PetersenLocalChildren.push (x := s638) b638 <|
    PetersenLocalChildren.push (x := s639) b639 <|
    PetersenLocalChildren.push (x := s451) b451 <|
    PetersenLocalChildren.push (x := s640) b640 <|
    PetersenLocalChildren.push (x := s641) b641 <|
    PetersenLocalChildren.push (x := s642) b642 <|
    PetersenLocalChildren.push (x := s643) b643 <|
    PetersenLocalChildren.push (x := s524) b524 <|
    PetersenLocalChildren.push (x := s644) b644 <|
    PetersenLocalChildren.push (x := s645) b645 <|
    PetersenLocalChildren.push (x := s646) b646 <|
    PetersenLocalChildren.push (x := s647) b647 <|
    PetersenLocalChildren.push (x := s648) b648 <|
    PetersenLocalChildren.push (x := s649) b649 <|
    PetersenLocalChildren.push (x := s650) b650 <|
    PetersenLocalChildren.push (x := s651) b651 <|
    PetersenLocalChildren.push (x := s652) b652 <|
    PetersenLocalChildren.push (x := s653) b653 <|
    PetersenLocalChildren.push (x := s664) b664 <|
    PetersenLocalChildren.push (x := s665) b665 <|
    PetersenLocalChildren.push (x := s666) b666 <|
    PetersenLocalChildren.push (x := s667) b667 <|
    PetersenLocalChildren.push (x := s668) b668 <|
    PetersenLocalChildren.push (x := s669) b669 <|
    PetersenLocalChildren.push (x := s670) b670 <|
    PetersenLocalChildren.push (x := s503) b503 <|
    PetersenLocalChildren.push (x := s671) b671 <|
    PetersenLocalChildren.push (x := s672) b672 <|
    PetersenLocalChildren.push (x := s673) b673 <|
    PetersenLocalChildren.push (x := s674) b674 <|
    PetersenLocalChildren.push (x := s675) b675 <|
    PetersenLocalChildren.push (x := s676) b676 <|
    PetersenLocalChildren.push (x := s677) b677 <|
    PetersenLocalChildren.push (x := s678) b678 <|
    PetersenLocalChildren.push (x := s679) b679 <|
    PetersenLocalChildren.push (x := s680) b680 <|
    PetersenLocalChildren.push (x := s681) b681 <|
    PetersenLocalChildren.push (x := s682) b682 <|
    PetersenLocalChildren.push (x := s685) b685 <|
    PetersenLocalChildren.push (x := s686) b686 <|
    PetersenLocalChildren.push (x := s687) b687 <|
    PetersenLocalChildren.push (x := s688) b688 <|
    PetersenLocalChildren.nil
theorem b689 : Blocked tgt 8 s689 := by
  apply PetersenFastNode.node (nxt := #[s6,s643,s525,s690,s691,s133,s697,s698,s699,s700,s701,s617,s702,s703,s704,s705,s706,s707,s708,s718,s719,s720,s721,s722,s723,s724,s725,s726,s727,s671,s672,s728,s729,s732,s734,s735,s737,s738,s740,s741,s742,s744,s745,s746,s747,s748,s749,s750,s751,s752,s753]) (hints := [5597,0,6629,5597,1,2,9208,3,9208,13723,4,13723,9208,5,9208,13723,6,13723,9980,7,9980,5981,8,5981,9980,9,9980,5981,10,5981,9976,0,9976,7525,11,12,11000,13,11000,7517,14,7517,11000,15,11000,7517,16,7517,13048,17,13048,18,19,20,13048,21,13048,22,23,24,14693,25,14693,13661,26,13661,14693,27,14693,13661,28,13661,13723,15143,13723,9080,6629,9208,13723,6629,13723,15143,15143,9208,5981,6629,5981,9980,15143,9980,5981,15143,5981,6629,6629,9980,6629,6629,12,9976,2,9976,7653,29,30,7517,4565,7517,4581,6629,11000,7517,6629,7517,4565,4565,11000,2501,2501,31,2533,6629,13048,6597,6629,32,2501,2501,13048,13661,6629,13661,6951,15143,33,13661,15143,13661,6629,6629,34,13723,13723,13979,5725,9208,5981,13979,9208,13979,13723,13723,5981,9208,9208,9976,13723,13723,35,13723,13723,9976,9208,9208,36,13723,13723,15515,7261,15271,7517,15515,15271,15515,13723,13723,7517,9595,9595,13048,9627,13723,37,13691,13723,13048,9595,9595,38,952,952,39,13661,13723,13661,13659,13723,40,13659,952,13661,7013,7013,41,5981,5981,9976,5981,5981,42,9972,7013,9976,5981,5981,7517,10488,7013,11000,7517,7013,7517,5981,5981,11000,1853,1853,13564,1885,5981,13048,5949,5981,13564,1853,1853,13048,5981,5981,13661,5787,13979,43,13661,13979,13661,5981,5981,44,9976,9976,11000,7517,45,7517,11000,46,11000,7517,9976,7517,9976,9976,13048,12540,47,13564,13048,48,13048,9976,9976,13564,1720,1720,14693,13661,9976,13661,9912,9976,14693,13661,1720,13661,3389,3389,13048,3421,7517,49,7485,7517,13048,3389,3389,50,7517,7517,13661,7323,15515,14693,13661,15515,13661,7517,7517,14693,9533,4792,9533,9565,13048,13661,9533,13048,9533,13629,4792,13661]) (by decide +kernel)
  change ∀ b ∈ [s6,s643,s525,s690,s691,s133,s697,s698,s699,s700,s701,s617,s702,s703,s704,s705,s706,s707,s708,s718,s719,s720,s721,s722,s723,s724,s725,s726,s727,s671,s672,s728,s729,s732,s734,s735,s737,s738,s740,s741,s742,s744,s745,s746,s747,s748,s749,s750,s751,s752,s753], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s643) b643 <|
    PetersenLocalChildren.push (x := s525) b525 <|
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s691) b691 <|
    PetersenLocalChildren.push (x := s133) b133 <|
    PetersenLocalChildren.push (x := s697) b697 <|
    PetersenLocalChildren.push (x := s698) b698 <|
    PetersenLocalChildren.push (x := s699) b699 <|
    PetersenLocalChildren.push (x := s700) b700 <|
    PetersenLocalChildren.push (x := s701) b701 <|
    PetersenLocalChildren.push (x := s617) b617 <|
    PetersenLocalChildren.push (x := s702) b702 <|
    PetersenLocalChildren.push (x := s703) b703 <|
    PetersenLocalChildren.push (x := s704) b704 <|
    PetersenLocalChildren.push (x := s705) b705 <|
    PetersenLocalChildren.push (x := s706) b706 <|
    PetersenLocalChildren.push (x := s707) b707 <|
    PetersenLocalChildren.push (x := s708) b708 <|
    PetersenLocalChildren.push (x := s718) b718 <|
    PetersenLocalChildren.push (x := s719) b719 <|
    PetersenLocalChildren.push (x := s720) b720 <|
    PetersenLocalChildren.push (x := s721) b721 <|
    PetersenLocalChildren.push (x := s722) b722 <|
    PetersenLocalChildren.push (x := s723) b723 <|
    PetersenLocalChildren.push (x := s724) b724 <|
    PetersenLocalChildren.push (x := s725) b725 <|
    PetersenLocalChildren.push (x := s726) b726 <|
    PetersenLocalChildren.push (x := s727) b727 <|
    PetersenLocalChildren.push (x := s671) b671 <|
    PetersenLocalChildren.push (x := s672) b672 <|
    PetersenLocalChildren.push (x := s728) b728 <|
    PetersenLocalChildren.push (x := s729) b729 <|
    PetersenLocalChildren.push (x := s732) b732 <|
    PetersenLocalChildren.push (x := s734) b734 <|
    PetersenLocalChildren.push (x := s735) b735 <|
    PetersenLocalChildren.push (x := s737) b737 <|
    PetersenLocalChildren.push (x := s738) b738 <|
    PetersenLocalChildren.push (x := s740) b740 <|
    PetersenLocalChildren.push (x := s741) b741 <|
    PetersenLocalChildren.push (x := s742) b742 <|
    PetersenLocalChildren.push (x := s744) b744 <|
    PetersenLocalChildren.push (x := s745) b745 <|
    PetersenLocalChildren.push (x := s746) b746 <|
    PetersenLocalChildren.push (x := s747) b747 <|
    PetersenLocalChildren.push (x := s748) b748 <|
    PetersenLocalChildren.push (x := s749) b749 <|
    PetersenLocalChildren.push (x := s750) b750 <|
    PetersenLocalChildren.push (x := s751) b751 <|
    PetersenLocalChildren.push (x := s752) b752 <|
    PetersenLocalChildren.push (x := s753) b753 <|
    PetersenLocalChildren.nil
theorem b754 : Blocked tgt 8 s754 := by
  apply PetersenFastNode.node (nxt := #[s6,s574,s618,s320,s755,s205,s759,s760,s761,s435,s762,s526,s702,s763,s764,s765,s766,s767,s768,s769,s770,s771,s772,s783,s784,s785,s786,s787,s788,s522,s523,s789,s790,s791,s792,s793,s794,s795,s796,s798,s799,s800,s801]) (hints := [5589,0,6621,5589,1,2,9200,3,9200,9716,4,9716,9200,5,9200,9716,6,9716,5973,7,5973,9972,8,9972,5973,9,5973,9972,10,9972,9968,0,7517,9968,11,12,10992,13,10992,11508,14,11508,10992,15,10992,11508,16,11508,13040,17,13040,13556,18,13556,13040,19,13040,13556,20,13556,13653,21,13653,22,23,24,13653,25,13653,26,27,28,15135,15135,15263,9716,6621,9716,15263,6621,15263,9716,15135,9716,5973,6621,5973,9972,15135,9972,5973,15135,5973,9972,6621,9972,4565,29,30,7517,2,7517,6621,6621,12,7509,4557,7509,11508,6621,11508,7509,6621,7509,11508,4557,11508,2493,2493,31,13556,6621,13556,6589,6621,32,13556,2493,13556,13653,6621,13653,6943,15135,33,13653,15135,13653,6621,6621,34,9716,9716,9972,8688,9200,5973,9972,9200,9972,9716,9716,5973,9200,9200,16031,9716,9716,7517,9716,9716,16031,9200,9200,7517,9716,9716,11508,13215,15263,7509,11508,15263,11508,9716,9716,7509,9716,9716,13556,11167,15263,35,13556,15263,13556,9716,9716,36,1460,1460,37,1524,9716,13653,9652,9716,38,1460,1460,13653,7005,7005,7517,9972,9972,16031,9972,9972,7517,7005,7005,16031,9972,9972,11508,10480,7005,10992,11508,7005,11508,9972,9972,10992,9972,9972,13556,12528,5973,13040,13556,5973,13556,9972,9972,13040,1716,1716,13653,1780,9972,39,9908,9972,13653,1716,1716,40,10992,13967,10992,11508,7517,11508,10992,7517,10992,11508,13967,11508,13040,3389,13040,13556,7517,13556,13040,7517,13040,13556,3389,13556,7517,7517,14685,12629,16031,13653,14685,16031,14685,7517,7517,13653,11508,11508,13556,3413,7509,41,13556,7509,13556,11508,11508,42,3252,3252,13653,3316,11508,14685,11444,11508,13653,3252,3252,14685,5300,5300,9525,5364,13556,13653,13492,13556,9525,5300,5300,13653]) (by decide +kernel)
  change ∀ b ∈ [s6,s574,s618,s320,s755,s205,s759,s760,s761,s435,s762,s526,s702,s763,s764,s765,s766,s767,s768,s769,s770,s771,s772,s783,s784,s785,s786,s787,s788,s522,s523,s789,s790,s791,s792,s793,s794,s795,s796,s798,s799,s800,s801], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s574) b574 <|
    PetersenLocalChildren.push (x := s618) b618 <|
    PetersenLocalChildren.push (x := s320) b320 <|
    PetersenLocalChildren.push (x := s755) b755 <|
    PetersenLocalChildren.push (x := s205) b205 <|
    PetersenLocalChildren.push (x := s759) b759 <|
    PetersenLocalChildren.push (x := s760) b760 <|
    PetersenLocalChildren.push (x := s761) b761 <|
    PetersenLocalChildren.push (x := s435) b435 <|
    PetersenLocalChildren.push (x := s762) b762 <|
    PetersenLocalChildren.push (x := s526) b526 <|
    PetersenLocalChildren.push (x := s702) b702 <|
    PetersenLocalChildren.push (x := s763) b763 <|
    PetersenLocalChildren.push (x := s764) b764 <|
    PetersenLocalChildren.push (x := s765) b765 <|
    PetersenLocalChildren.push (x := s766) b766 <|
    PetersenLocalChildren.push (x := s767) b767 <|
    PetersenLocalChildren.push (x := s768) b768 <|
    PetersenLocalChildren.push (x := s769) b769 <|
    PetersenLocalChildren.push (x := s770) b770 <|
    PetersenLocalChildren.push (x := s771) b771 <|
    PetersenLocalChildren.push (x := s772) b772 <|
    PetersenLocalChildren.push (x := s783) b783 <|
    PetersenLocalChildren.push (x := s784) b784 <|
    PetersenLocalChildren.push (x := s785) b785 <|
    PetersenLocalChildren.push (x := s786) b786 <|
    PetersenLocalChildren.push (x := s787) b787 <|
    PetersenLocalChildren.push (x := s788) b788 <|
    PetersenLocalChildren.push (x := s522) b522 <|
    PetersenLocalChildren.push (x := s523) b523 <|
    PetersenLocalChildren.push (x := s789) b789 <|
    PetersenLocalChildren.push (x := s790) b790 <|
    PetersenLocalChildren.push (x := s791) b791 <|
    PetersenLocalChildren.push (x := s792) b792 <|
    PetersenLocalChildren.push (x := s793) b793 <|
    PetersenLocalChildren.push (x := s794) b794 <|
    PetersenLocalChildren.push (x := s795) b795 <|
    PetersenLocalChildren.push (x := s796) b796 <|
    PetersenLocalChildren.push (x := s798) b798 <|
    PetersenLocalChildren.push (x := s799) b799 <|
    PetersenLocalChildren.push (x := s800) b800 <|
    PetersenLocalChildren.push (x := s801) b801 <|
    PetersenLocalChildren.nil
theorem b802 : Blocked tgt 8 s802 := by
  apply PetersenFastNode.node (nxt := #[s527,s673,s803,s804,s805,s806,s6,s807,s808,s809,s810,s811,s812,s815,s816,s135,s817,s818,s819,s820,s821,s822,s827,s828,s836,s837,s838,s843,s844,s582,s705,s845,s846,s847,s868,s869,s870,s871,s872,s873,s874,s875,s876,s885,s886,s887,s888,s889,s890,s891]) (hints := [15142,15142,15270,9207,6628,9207,15270,6628,15270,15142,15142,9207,5980,6628,5980,9979,15142,9979,5980,15142,5980,6628,6628,9979,6628,6628,7524,9975,0,9975,7524,1,7524,6628,6628,9975,4580,2,3,6628,6628,4,10999,5,10999,5596,6628,6,5596,5,7,2500,2500,8,2532,6628,13047,6596,6628,9,2500,2500,13047,13660,6628,13660,6950,15142,10,13660,15142,13660,6628,6628,11,9723,9723,9979,8695,9207,5980,9979,9207,9979,9723,9723,5980,9207,9207,9975,8699,9723,7524,9975,9723,9975,9207,9207,7524,9207,9207,10999,15270,15270,12,10999,15270,10999,9207,9207,13,13206,13206,14,9207,9207,15,9207,9207,16,13206,13206,17,9207,9207,13047,11174,15270,18,13047,15270,13047,9207,9207,19,951,951,20,1015,9207,13660,9143,9207,21,951,951,13660,7012,7012,7524,9975,9979,9975,9971,9979,7524,9971,7012,9975,9979,9979,11515,10487,7012,10999,11515,7012,11515,9979,9979,10999,5980,5980,22,9979,9979,23,9979,9979,24,5980,5980,25,9979,9979,13563,12535,5980,13047,13563,5980,13563,9979,9979,13047,1723,1723,13660,1787,9979,26,9915,9979,13660,1723,1723,27,9975,9975,10999,10491,7524,11515,10999,7524,10999,9975,9975,11515,13974,13974,28,9975,9975,29,9975,9975,30,13974,13974,31,9975,9975,13047,12539,7524,13563,13047,7524,13047,9975,9975,13563,1719,1719,14692,1783,9975,13660,9911,9975,14692,1719,1719,13660,10999,10999,6,7516,4,32,10999,10999,13047,33,34,35,13047,36,13047,10999,10999,37,2743,2743,13660,2807,10999,14692,10935,10999,13660,2743,2743,14692,38,39,40,13047,41,13047,42,43,44,13047,45,13047,13660,46,13660,14692,47,14692,13660,48,13660,14692,49,14692,4791,4791,9532,4855,13047,13660,12983,13047,9532,4791,4791,13660]) (by decide +kernel)
  change ∀ b ∈ [s527,s673,s803,s804,s805,s806,s6,s807,s808,s809,s810,s811,s812,s815,s816,s135,s817,s818,s819,s820,s821,s822,s827,s828,s836,s837,s838,s843,s844,s582,s705,s845,s846,s847,s868,s869,s870,s871,s872,s873,s874,s875,s876,s885,s886,s887,s888,s889,s890,s891], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s527) b527 <|
    PetersenLocalChildren.push (x := s673) b673 <|
    PetersenLocalChildren.push (x := s803) b803 <|
    PetersenLocalChildren.push (x := s804) b804 <|
    PetersenLocalChildren.push (x := s805) b805 <|
    PetersenLocalChildren.push (x := s806) b806 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s807) b807 <|
    PetersenLocalChildren.push (x := s808) b808 <|
    PetersenLocalChildren.push (x := s809) b809 <|
    PetersenLocalChildren.push (x := s810) b810 <|
    PetersenLocalChildren.push (x := s811) b811 <|
    PetersenLocalChildren.push (x := s812) b812 <|
    PetersenLocalChildren.push (x := s815) b815 <|
    PetersenLocalChildren.push (x := s816) b816 <|
    PetersenLocalChildren.push (x := s135) b135 <|
    PetersenLocalChildren.push (x := s817) b817 <|
    PetersenLocalChildren.push (x := s818) b818 <|
    PetersenLocalChildren.push (x := s819) b819 <|
    PetersenLocalChildren.push (x := s820) b820 <|
    PetersenLocalChildren.push (x := s821) b821 <|
    PetersenLocalChildren.push (x := s822) b822 <|
    PetersenLocalChildren.push (x := s827) b827 <|
    PetersenLocalChildren.push (x := s828) b828 <|
    PetersenLocalChildren.push (x := s836) b836 <|
    PetersenLocalChildren.push (x := s837) b837 <|
    PetersenLocalChildren.push (x := s838) b838 <|
    PetersenLocalChildren.push (x := s843) b843 <|
    PetersenLocalChildren.push (x := s844) b844 <|
    PetersenLocalChildren.push (x := s582) b582 <|
    PetersenLocalChildren.push (x := s705) b705 <|
    PetersenLocalChildren.push (x := s845) b845 <|
    PetersenLocalChildren.push (x := s846) b846 <|
    PetersenLocalChildren.push (x := s847) b847 <|
    PetersenLocalChildren.push (x := s868) b868 <|
    PetersenLocalChildren.push (x := s869) b869 <|
    PetersenLocalChildren.push (x := s870) b870 <|
    PetersenLocalChildren.push (x := s871) b871 <|
    PetersenLocalChildren.push (x := s872) b872 <|
    PetersenLocalChildren.push (x := s873) b873 <|
    PetersenLocalChildren.push (x := s874) b874 <|
    PetersenLocalChildren.push (x := s875) b875 <|
    PetersenLocalChildren.push (x := s876) b876 <|
    PetersenLocalChildren.push (x := s885) b885 <|
    PetersenLocalChildren.push (x := s886) b886 <|
    PetersenLocalChildren.push (x := s887) b887 <|
    PetersenLocalChildren.push (x := s888) b888 <|
    PetersenLocalChildren.push (x := s889) b889 <|
    PetersenLocalChildren.push (x := s890) b890 <|
    PetersenLocalChildren.push (x := s891) b891 <|
    PetersenLocalChildren.nil
theorem b892 : Blocked tgt 8 s892 := by
  apply PetersenFastNode.node (nxt := #[s6,s893,s894,s370,s895,s211,s901,s902,s903,s475,s908,s765,s909,s646,s910,s911,s805,s912,s913,s914,s915,s916,s938,s939,s940,s941,s942,s954,s955,s956,s957,s958,s959,s528,s674,s960,s961,s962,s963,s964,s965,s966,s967,s968,s969,s972,s977,s978,s981,s982,s983,s986,s987]) (hints := [5599,0,6631,5599,1,2,15273,3,15273,9210,4,9210,15273,5,15273,9210,6,9210,5983,7,5983,9982,8,9982,5983,9,5983,9982,10,9982,7527,11,7527,9978,12,9978,7527,13,7527,9978,14,9978,11002,0,7519,11002,15,16,17,18,19,13050,20,13050,21,22,23,13050,24,13050,13663,25,13663,26,27,28,13663,29,13663,30,31,32,15145,15145,15273,9210,6631,9210,15273,6631,15273,9210,15145,9210,5983,6631,5983,9982,15145,9982,5983,15145,5983,9982,6631,9982,6631,6631,7527,9978,33,9978,7527,34,7527,9978,6631,9978,7519,2,7519,6631,6631,16,7647,35,36,2503,2503,37,13050,6631,13050,6599,6631,38,13050,2503,13050,13663,6631,13663,6953,15145,39,13663,15145,13663,6631,6631,40,9726,9726,9982,8698,9210,5983,9982,9210,9982,9726,9726,5983,9210,9210,9978,8702,9726,7527,9978,9726,9978,9210,9210,7527,9210,9210,15517,13225,15273,7519,15257,15273,15517,9210,9210,7519,9210,9210,13050,11177,15273,41,13050,15273,13050,9210,9210,42,954,954,43,1018,9210,13663,9146,9210,44,954,954,13663,7015,7015,7527,9978,9982,9978,9974,9982,7527,9974,7015,9978,9982,9982,7519,4967,7015,45,7519,7015,7519,9982,9982,46,9982,9982,13566,12538,5983,13050,13566,5983,13566,9982,9982,13050,1726,1726,13663,1790,9982,47,9918,9982,13663,1726,1726,48,9978,9978,49,7519,7527,7519,7511,7527,50,9978,9978,7519,9978,9978,13050,12542,7527,13566,13050,7527,13050,9978,9978,13566,1722,1722,14695,1786,9978,13663,9914,9978,14695,1722,1722,13663,13050,3391,13050,3423,7519,51,13050,7519,13050,3391,3391,52,7519,7519,13663,12647,15517,14695,13663,15517,13663,7519,7519,14695,4794,4794,9535,4858,13050,13663,12986,13050,9535,4794,4794,13663]) (by decide +kernel)
  change ∀ b ∈ [s6,s893,s894,s370,s895,s211,s901,s902,s903,s475,s908,s765,s909,s646,s910,s911,s805,s912,s913,s914,s915,s916,s938,s939,s940,s941,s942,s954,s955,s956,s957,s958,s959,s528,s674,s960,s961,s962,s963,s964,s965,s966,s967,s968,s969,s972,s977,s978,s981,s982,s983,s986,s987], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s893) b893 <|
    PetersenLocalChildren.push (x := s894) b894 <|
    PetersenLocalChildren.push (x := s370) b370 <|
    PetersenLocalChildren.push (x := s895) b895 <|
    PetersenLocalChildren.push (x := s211) b211 <|
    PetersenLocalChildren.push (x := s901) b901 <|
    PetersenLocalChildren.push (x := s902) b902 <|
    PetersenLocalChildren.push (x := s903) b903 <|
    PetersenLocalChildren.push (x := s475) b475 <|
    PetersenLocalChildren.push (x := s908) b908 <|
    PetersenLocalChildren.push (x := s765) b765 <|
    PetersenLocalChildren.push (x := s909) b909 <|
    PetersenLocalChildren.push (x := s646) b646 <|
    PetersenLocalChildren.push (x := s910) b910 <|
    PetersenLocalChildren.push (x := s911) b911 <|
    PetersenLocalChildren.push (x := s805) b805 <|
    PetersenLocalChildren.push (x := s912) b912 <|
    PetersenLocalChildren.push (x := s913) b913 <|
    PetersenLocalChildren.push (x := s914) b914 <|
    PetersenLocalChildren.push (x := s915) b915 <|
    PetersenLocalChildren.push (x := s916) b916 <|
    PetersenLocalChildren.push (x := s938) b938 <|
    PetersenLocalChildren.push (x := s939) b939 <|
    PetersenLocalChildren.push (x := s940) b940 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s942) b942 <|
    PetersenLocalChildren.push (x := s954) b954 <|
    PetersenLocalChildren.push (x := s955) b955 <|
    PetersenLocalChildren.push (x := s956) b956 <|
    PetersenLocalChildren.push (x := s957) b957 <|
    PetersenLocalChildren.push (x := s958) b958 <|
    PetersenLocalChildren.push (x := s959) b959 <|
    PetersenLocalChildren.push (x := s528) b528 <|
    PetersenLocalChildren.push (x := s674) b674 <|
    PetersenLocalChildren.push (x := s960) b960 <|
    PetersenLocalChildren.push (x := s961) b961 <|
    PetersenLocalChildren.push (x := s962) b962 <|
    PetersenLocalChildren.push (x := s963) b963 <|
    PetersenLocalChildren.push (x := s964) b964 <|
    PetersenLocalChildren.push (x := s965) b965 <|
    PetersenLocalChildren.push (x := s966) b966 <|
    PetersenLocalChildren.push (x := s967) b967 <|
    PetersenLocalChildren.push (x := s968) b968 <|
    PetersenLocalChildren.push (x := s969) b969 <|
    PetersenLocalChildren.push (x := s972) b972 <|
    PetersenLocalChildren.push (x := s977) b977 <|
    PetersenLocalChildren.push (x := s978) b978 <|
    PetersenLocalChildren.push (x := s981) b981 <|
    PetersenLocalChildren.push (x := s982) b982 <|
    PetersenLocalChildren.push (x := s983) b983 <|
    PetersenLocalChildren.push (x := s986) b986 <|
    PetersenLocalChildren.push (x := s987) b987 <|
    PetersenLocalChildren.nil
theorem b988 : Blocked tgt 8 s988 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s988 8 _ le
  decide +kernel
theorem b989 : Blocked tgt 8 s989 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s989 8 _ le
  decide +kernel
theorem b990 : Blocked tgt 8 s990 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s990 8 _ le
  decide +kernel
end PetersenSmallStarts.M127
