import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b584 : Blocked tgt 5 s584 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,3412,453,388,453,906,841,906,841,2242,837,2754,837,1674,1349,1674,1349,713,197,841,713,453,201,837,453,453,404,1349,453,386,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b587 : Blocked tgt 5 s587 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1234,714,714,1106,453,1234,453,1234,841,1426,1234,1234,837,1682,1234,210,210,1234,1349,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b588 : Blocked tgt 5 s588 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s588 5 _ le
  decide +kernel
theorem b591 : Blocked tgt 5 s591 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3282,714,1234,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,389,389,714,453,714,841,906,714,194,202,706,194,714,1349,1738,714,713,197,841,713,453,201,837,453,453,1428,1349,453,386,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b592 : Blocked tgt 5 s592 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s592 5 _ le
  decide +kernel
theorem b593 : Blocked tgt 5 s593 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,194,2373,201,1428,2373,2633,841,2117,841,2373,837,2121,837,2373,1349,1666,1349,1428,201,1428,201,386,841,386,841,1682,837,1682,837,1666,1349,1666,1349,201,386,457,201,837,201,453,453,1349,1428,1349,1477,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b594 : Blocked tgt 5 s594 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1234,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,1428,453,1426,841,1426,841,1682,837,1682,837,2242,1349,3266,1349,841,197,841,193,453,201,837,453,453,404,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b596 : Blocked tgt 5 s596 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1364,714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1364,453,1492,1364,1104,841,1360,841,1364,837,1812,1364,1545,1349,1364,1349,713,197,841,713,453,201,837,453,453,1674,1349,453,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b597 : Blocked tgt 5 s597 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s597 5 _ le
  decide +kernel
theorem b598 : Blocked tgt 5 s598 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1424,453,2633,841,2117,841,2373,837,2121,837,2373,1093,1674,1093,1424,453,1424,453,906,841,906,841,1682,837,1682,837,1674,1093,1674,1093,713,197,841,713,453,201,837,453,453,400,1093,453,1426,837,833,833,841,1093,1609,841,837,1674,1093,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b599 : Blocked tgt 5 s599 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2372,714,2633,841,2117,841,2373,453,388,453,2373,837,2121,837,2373,1609,1674,2373,906,841,906,841,388,453,388,453,772,837,772,837,2372,1609,1674,1609,713,197,713,841,1426,837,833,833,841,1093,1609,841,453,201,837,453,453,1546,1477,453,837,1097,1089,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b601 : Blocked tgt 5 s601 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,453,1428,453,2762,2373,714,714,2762,777,1426,2762,1682,2250,1682,3282,1674,2258,1674,2762,2373,453,453,1428,713,197,841,713,453,201,837,453,453,404,1349,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b602 : Blocked tgt 5 s602 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s602 5 _ le
  decide +kernel
theorem b603 : Blocked tgt 5 s603 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,1426,777,1426,841,714,714,1682,773,1682,837,1674,1349,1674,1349,713,197,841,713,1428,453,453,1428,453,201,837,453,453,404,1349,453,2762,841,841,906,1426,837,833,833,841,1093,1609,841,1682,837,1682,837,1674,1349,1674,1349,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b604 : Blocked tgt 5 s604 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s604 5 _ le
  decide +kernel
theorem b605 : Blocked tgt 5 s605 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,2633,2369,2117,2633,2373,453,1428,453,2373,2625,2121,2373,2373,1349,1674,1349,778,3156,778,2762,1428,453,1428,453,3412,2250,1682,3412,2372,1349,3396,1349,713,197,713,841,1426,394,1682,1426,1609,1093,1609,1345,453,201,837,453,453,404,1349,453,1349,1097,1349,1601]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
