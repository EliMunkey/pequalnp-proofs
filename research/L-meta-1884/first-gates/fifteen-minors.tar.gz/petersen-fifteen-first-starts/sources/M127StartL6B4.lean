import M127StartData
import M127StartPins0
import M127StartL5B0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b106 : Blocked tgt 6 s106 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s106 6 _ le
  decide +kernel
theorem b107 : Blocked tgt 6 s107 := by
  apply PetersenFastNode.node (nxt := #[s34,s108]) (hints := [5260,1420,0,1420,2870,2870,1675,1804,1675,1804,1671,3348,1671,3348,2695,3340,2695,3340,903,903,1420,6838,1420,1675,1804,1420,2452,396,3348,2452,1420,404,3340,1420,8967,1420,1420,4743,5674,1804,5674,1804,7734,3348,7734,3348,8998,3340,11046,3340,1,4743,11030,4743,2836,780,3348,2836,1804,788,3340,1804,1675,1804,1804,1675,1671,3340,3332,3332,1671,3348,3348,1671,2695,3340,3340,2695]) (by decide +kernel)
  change ∀ b ∈ [s34,s108], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s108) b108 <|
    PetersenLocalChildren.nil
theorem b109 : Blocked tgt 6 s109 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s109 6 _ le
  decide +kernel
theorem b110 : Blocked tgt 6 s110 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s110 6 _ le
  decide +kernel
theorem b111 : Blocked tgt 6 s111 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s111 6 _ le
  decide +kernel
theorem b112 : Blocked tgt 6 s112 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s112 6 _ le
  decide +kernel
theorem b117 : Blocked tgt 6 s117 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s117 6 _ le
  decide +kernel
theorem b118 : Blocked tgt 6 s118 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s118 6 _ le
  decide +kernel
theorem b119 : Blocked tgt 6 s119 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4741,9482,4741,13578,9482,1418,6804,1418,901,901,1673,1802,1673,1802,1669,3346,1669,3346,2693,3338,2693,3338,5514,1418,1450,1418,4741,9093,11028,4741,5898,1802,1834,1802,7442,3346,3378,3346,7434,3338,3370,3338,8965,1418,1418,9093,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1673,1802,1673,1802,1669,3346,1669,3346,2693,3338,2693,3338,2834,778,3346,2834,1802,786,3338,1802,1669,3338,3330,3330]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b122 : Blocked tgt 6 s122 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s122 6 _ le
  decide +kernel
theorem b123 : Blocked tgt 6 s123 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s123 6 _ le
  decide +kernel
theorem b124 : Blocked tgt 6 s124 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s124 6 _ le
  decide +kernel
theorem b125 : Blocked tgt 6 s125 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s125 6 _ le
  decide +kernel
theorem b127 : Blocked tgt 6 s127 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s127 6 _ le
  decide +kernel
theorem b128 : Blocked tgt 6 s128 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s128 6 _ le
  decide +kernel
theorem b136 : Blocked tgt 6 s136 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s136 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
