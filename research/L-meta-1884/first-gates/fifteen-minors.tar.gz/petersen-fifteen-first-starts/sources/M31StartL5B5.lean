import M31StartData
import M31StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b110 : Blocked tgt 5 s110 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s110 5 _ le
  decide +kernel
theorem b111 : Blocked tgt 5 s111 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s111 5 _ le
  decide +kernel
theorem b112 : Blocked tgt 5 s112 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,229,724,692,362,393,458,362,626,106,850,626,362,626,626,362,362,626,626,362,361,229,229,361,229,105,421,229,229,724,677,229,361,229,229,361,722,421,850,421,549,549,722,677,458,722,425,425,421,850,677,421,388,421,421,388,677,809]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b113 : Blocked tgt 5 s113 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s113 5 _ le
  decide +kernel
theorem b114 : Blocked tgt 5 s114 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s114 5 _ le
  decide +kernel
theorem b115 : Blocked tgt 5 s115 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s115 5 _ le
  decide +kernel
theorem b116 : Blocked tgt 5 s116 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s116 5 _ le
  decide +kernel
end PetersenSmallStarts.M31
