import M127StartData
import M127StartPins0
import M127StartL6B23
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b803 : Blocked tgt 7 s803 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s803 7 _ le
  decide +kernel
theorem b804 : Blocked tgt 7 s804 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s804 7 _ le
  decide +kernel
theorem b805 : Blocked tgt 7 s805 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s805 7 _ le
  decide +kernel
theorem b806 : Blocked tgt 7 s806 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s806 7 _ le
  decide +kernel
theorem b807 : Blocked tgt 7 s807 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s807 7 _ le
  decide +kernel
theorem b808 : Blocked tgt 7 s808 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s808 7 _ le
  decide +kernel
theorem b809 : Blocked tgt 7 s809 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s809 7 _ le
  decide +kernel
theorem b810 : Blocked tgt 7 s810 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s810 7 _ le
  decide +kernel
theorem b811 : Blocked tgt 7 s811 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s811 7 _ le
  decide +kernel
theorem b812 : Blocked tgt 7 s812 := by
  apply PetersenFastNode.node (nxt := #[s813,s814]) (hints := [15094,4532,13302,13302,5932,9931,5932,4532,4532,9927,5556,4532,5548,5548,13046,4532,4532,10951,404,436,4500,404,13612,6902,13612,4532,9931,5932,9931,5932,9927,7220,9927,15222,13174,13174,15222,7468,9159,9159,12999,11126,12999,11094,6966,7030,15158,6966,6964,9927,9923,9923,5932,9931,9931,5932,9931,10439,11467,9931,9931,12487,13515,9931,1675,1739,9867,1675,13926,9927,9927,7460,9927,10443,10951,9927,9927,12491,12999,9927,1671,1735,9863,1671,0,10951,7468,10951,3340,12999,7436,12999,7468,12596,13612,7468,10951,1,12999,10951,2695,2759,10887,2695,4743,4807,12935,4743]) (by decide +kernel)
  change ∀ b ∈ [s813,s814], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s813) b813 <|
    PetersenLocalChildren.push (x := s814) b814 <|
    PetersenLocalChildren.nil
theorem b815 : Blocked tgt 7 s815 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s815 7 _ le
  decide +kernel
theorem b816 : Blocked tgt 7 s816 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s816 7 _ le
  decide +kernel
theorem b817 : Blocked tgt 7 s817 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s817 7 _ le
  decide +kernel
theorem b818 : Blocked tgt 7 s818 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s818 7 _ le
  decide +kernel
theorem b819 : Blocked tgt 7 s819 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s819 7 _ le
  decide +kernel
theorem b820 : Blocked tgt 7 s820 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s820 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
