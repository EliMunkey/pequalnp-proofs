import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_2 : NoAtMost (0x3300330033003300 :: inputs 6) tgt 7 := by
  change NoAtMost [0x3300330033003300,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s863] [194,778,195,843,196,778,835,843,390,1546,455,1611,196,1546,839,1611,714,778,715,843,716,778,843,843,390,1546,455,1611,716,1546,1351,1611,1106,778,195,843,1236,778,835,843,1366,2634,455,2635,1236,2634,839,2635,714,778,715,843,716,778,843,843,1366,2634,455,2635,716,2634,2375,2635,2146,2666,195,843,2276,2666,835,843,2406,2666,455,1611,2276,2666,839,1611,2666,2666,715,843,2796,2666,843,843,2406,2666,455,1611,2796,2666,1351,1611,3186,2666,195,843,3316,2666,835,843,3446,2666,455,455,3316,2666,839,3764,2666,2666,715,843,2796,2666,843,843,3446,2666,455,455,2796,2666,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s863], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s863) b863 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_2
end PetersenSmallStarts.M63
