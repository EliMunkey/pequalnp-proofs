import M111StartData
import M111StartL6B0
import M111StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_3 : NoAtMost (0xcc00cc00cc00cc00 :: inputs 6) tgt 6 := by
  change NoAtMost [0xcc00cc00cc00cc00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s101] [194,716,195,195,196,716,835,835,390,716,455,455,196,716,839,839,714,716,715,843,716,716,843,843,390,716,455,455,716,716,1351,1351,1106,1756,195,195,1236,1756,835,835,1366,1756,455,455,1236,1756,839,839,1626,1756,715,843,1756,1756,843,843,1366,1756,455,455,1756,1756,3740,3740,2210,716,2275,2275,196,716,2915,2915,2470,716,2535,2535,196,716,2919,2919,2730,716,2795,2923,716,716,2923,2923,2470,716,2535,2535,716,716,3431,3431,3186,1756,2275,2275,1236,1756,2915,2915,3446,1756,2535,2535,1236,1756,2919,2919,3706,1756,2795,2923,1756,1756,2923,2923,3446,1756,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s101], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s101) b101 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_3
end PetersenSmallStarts.M111
