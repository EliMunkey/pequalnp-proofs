import M250StartData
import M250StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_1 : NoAtMost (0xaaaa0000aaaa :: inputs 6) tgt 4 := by
  change NoAtMost [0xaaaa0000aaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s5,s0,s6] [387,452,452,452,389,454,454,454,391,456,456,456,1221,2758,1222,2758,907,972,972,972,909,974,974,974,911,976,976,976,1741,2766,1742,2766,1107,452,452,452,1237,454,454,454,1367,456,456,456,1237,2758,2758,2758,1627,972,972,972,1757,974,974,974,1887,976,976,976,1757,2766,2766,2766,2467,2532,2532,2532,2469,2534,2534,2534,2471,2536,2536,2536,2725,2790,2790,2790,907,972,972,972,909,974,974,974,911,976,976,976,1741,1741,1742,0,3187,2532,2532,2532,3317,2534,2534,2534,3447,2536,2536,2536,3317,2790,2790,2790,1627,972,972,972,1757,974,974,974,1887,976,976,976,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s5,s0,s6], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_1
end PetersenSmallStarts.M250
