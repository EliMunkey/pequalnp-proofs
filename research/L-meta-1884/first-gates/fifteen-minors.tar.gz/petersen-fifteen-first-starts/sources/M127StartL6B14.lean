import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b386 : Blocked tgt 6 s386 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s386 6 _ le
  decide +kernel
theorem b387 : Blocked tgt 6 s387 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s387 6 _ le
  decide +kernel
theorem b396 : Blocked tgt 6 s396 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s396 6 _ le
  decide +kernel
theorem b397 : Blocked tgt 6 s397 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s397 6 _ le
  decide +kernel
theorem b398 : Blocked tgt 6 s398 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s398 6 _ le
  decide +kernel
theorem b399 : Blocked tgt 6 s399 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s399 6 _ le
  decide +kernel
theorem b400 : Blocked tgt 6 s400 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s400 6 _ le
  decide +kernel
theorem b401 : Blocked tgt 6 s401 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s401 6 _ le
  decide +kernel
theorem b402 : Blocked tgt 6 s402 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s402 6 _ le
  decide +kernel
theorem b403 : Blocked tgt 6 s403 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s403 6 _ le
  decide +kernel
theorem b404 : Blocked tgt 6 s404 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s404 6 _ le
  decide +kernel
theorem b405 : Blocked tgt 6 s405 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s405 6 _ le
  decide +kernel
theorem b406 : Blocked tgt 6 s406 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s406 6 _ le
  decide +kernel
theorem b429 : Blocked tgt 6 s429 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s429 6 _ le
  decide +kernel
theorem b430 : Blocked tgt 6 s430 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s430 6 _ le
  decide +kernel
theorem b431 : Blocked tgt 6 s431 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s431 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
