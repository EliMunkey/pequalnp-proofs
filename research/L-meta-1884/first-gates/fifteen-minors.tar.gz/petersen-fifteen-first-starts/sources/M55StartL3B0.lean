import M55StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b7 : Blocked tgt 3 s7 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [362,300,97,458,97,456,289,202,289,194,460,298,460,296,98,106,354,98,196,204,452,196]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
theorem b12 : Blocked tgt 3 s12 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [98,98,421,229,196,229,289,417,293,289,196,229,196,229,194,292,194,354,97,101,225,97]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
theorem b19 : Blocked tgt 3 s19 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [458,362,296,362,97,97,289,450,289,194,296,362,362,296,98,106,354,98,225,200,289,225]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M55
