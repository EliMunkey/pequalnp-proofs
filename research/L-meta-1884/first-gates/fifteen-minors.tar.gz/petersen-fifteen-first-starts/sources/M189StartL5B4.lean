import M189StartData
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b280 : Blocked tgt 5 s280 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s280 5 _ le
  decide +kernel
theorem b281 : Blocked tgt 5 s281 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s281 5 _ le
  decide +kernel
theorem b287 : Blocked tgt 5 s287 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s287 5 _ le
  decide +kernel
theorem b290 : Blocked tgt 5 s290 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s290 5 _ le
  decide +kernel
end PetersenSmallStarts.M189
