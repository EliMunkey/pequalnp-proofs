import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b606 : Blocked tgt 5 s606 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,714,714,1426,841,1426,841,1682,837,1682,837,1674,1349,1674,1349,1428,453,453,1428,713,197,841,713,453,201,837,453,453,404,1349,453,2762,841,1426,841,1682,837,1682,837,1674,1349,1674,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b607 : Blocked tgt 5 s607 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,2369,2117,2633,2373,2625,2121,2373,2373,1349,1674,1349,1428,453,1428,453,2762,3156,1426,2762,1682,2250,1682,3282,1674,1349,1674,1349,713,197,449,713,453,201,705,453,453,404,1349,453,1426,394,914,914,1609,1093,841,841,1349,1097,837,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b608 : Blocked tgt 5 s608 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,1349,1674,1349,1234,1234,1428,453,1428,453,1426,841,1426,841,1682,837,1682,837,1674,1349,1349,1674,453,404,453,1349,841,1093,841,1609,837,1097,837,1349,1428,453,1428,453,1426,841,1426,841,1682,837,1682,837,713,197,841,713,453,201,837,453,1426,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b613 : Blocked tgt 5 s613 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,453,1428,1364,2762,1364,714,714,906,841,906,2762,1682,2250,1682,3282,1674,2258,1674,2762,2373,453,453,388,713,197,841,713,453,201,837,453,453,1428,1349,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1682,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b614 : Blocked tgt 5 s614 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s614 5 _ le
  decide +kernel
theorem b616 : Blocked tgt 5 s616 := by
  apply PetersenFastNode.node (nxt := #[s530]) (hints := [1235,1235,2374,454,1429,454,2114,2370,2118,2114,2374,838,1683,838,2374,1350,0,1350,1429,454,1429,454,1427,3157,1427,3283,1683,838,1683,838,2243,1350,3267,1350,194,198,450,194,454,1555,838,454,454,405,1350,454,1427,838,834,834,1090,1094,1090,1346,838,1683,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s530], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s530) b530 <|
    PetersenLocalChildren.nil
theorem b617 : Blocked tgt 5 s617 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2113,837,2373,837,1234,1234,2373,453,1428,453,1426,2373,2373,833,2373,1349,1666,1349,1682,837,837,1682,837,453,193,453,833,837,833,1426,837,1349,1089,837,1428,453,1428,453,1426,833,1426,833,2372,1349,3282,1349,193,453,453,193,453,404,1349,453,1093,1093,1601,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b620 : Blocked tgt 5 s620 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1234,714,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1104,453,1232,453,1234,841,1490,1234,1234,837,1682,1234,210,210,1234,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1682,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b621 : Blocked tgt 5 s621 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s621 5 _ le
  decide +kernel
theorem b622 : Blocked tgt 5 s622 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1546,1349,1428,453,1428,453,906,841,906,841,1552,837,1552,837,1546,1349,1546,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1424,837,833,833,841,1349,1865,841,837,1546,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b623 : Blocked tgt 5 s623 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,1428,453,906,841,906,841,2242,837,2754,837,2762,1349,3396,1349,713,197,841,713,453,201,837,453,453,404,1349,453,386,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b625 : Blocked tgt 5 s625 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,453,1428,453,906,841,906,2762,2762,2373,714,714,3282,2250,2754,3282,2762,2258,3266,2762,713,197,841,713,2373,453,453,1428,453,201,837,453,453,404,1349,453,2633,841,841,2117,1426,837,833,833,841,1093,1609,841,2373,837,2121,837,2373,1349,1674,1349,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b626 : Blocked tgt 5 s626 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s626 5 _ le
  decide +kernel
theorem b627 : Blocked tgt 5 s627 := by
  apply PetersenFastNode.node (nxt := #[s533]) (hints := [2374,454,1429,454,907,842,907,842,2374,838,773,838,715,715,2374,1350,0,1350,714,198,842,714,454,202,838,454,1429,454,454,1429,454,405,1350,454,1427,838,834,834,907,842,842,907,842,1094,1610,842,3283,838,838,1683,838,1098,1350,838,2763,1350,1675,1350]) (by decide +kernel)
  change ∀ b ∈ [s533], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s533) b533 <|
    PetersenLocalChildren.nil
theorem b628 : Blocked tgt 5 s628 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s628 5 _ le
  decide +kernel
theorem b629 : Blocked tgt 5 s629 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,2633,841,2117,841,2373,837,2121,837,2373,453,1428,453,2373,1349,1546,1349,906,841,906,841,3412,837,772,837,1428,453,1428,453,2372,1349,3396,1349,1426,837,833,833,713,197,713,841,841,1093,1089,841,453,201,453,837,837,1097,1349,837,453,404,1349,453]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
