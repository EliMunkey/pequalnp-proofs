import M111StartData
import M111StartL4B0
import M111StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 5 s2 := by
  apply PetersenFastNode.node (nxt := #[s3,s4,s5]) (hints := [1399,1527,716,1949,844,1949,456,204,840,456,456,0,1352,456,392,392,456,1757,1659,1949,1915,1949,1399,840,1911,1399,1,1352,1383,1352,2,1757,1367,1757,1429,1437,1941,1429,909,925,1933,909,1757,844,1757,1949,840,1100,1352,840,1237,1245,1237,1749,717,733,717,1741]) (by decide +kernel)
  change ∀ b ∈ [s3,s4,s5], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.nil
theorem b6 : Blocked tgt 5 s6 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s6 5 _ le
  decide +kernel
theorem b7 : Blocked tgt 5 s7 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s7 5 _ le
  decide +kernel
theorem b8 : Blocked tgt 5 s8 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s8 5 _ le
  decide +kernel
theorem b9 : Blocked tgt 5 s9 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s9 5 _ le
  decide +kernel
theorem b10 : Blocked tgt 5 s10 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3738,1754,1364,1754,2501,453,485,453,2889,841,873,841,2885,837,869,837,3397,1349,1381,1349,389,389,1754,453,1754,841,1946,1754,1234,1242,1746,1234,714,730,1738,714,713,197,841,713,453,201,837,453,453,2452,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b13 : Blocked tgt 5 s13 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s13 5 _ le
  decide +kernel
theorem b14 : Blocked tgt 5 s14 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s14 5 _ le
  decide +kernel
theorem b15 : Blocked tgt 5 s15 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s15 5 _ le
  decide +kernel
theorem b16 : Blocked tgt 5 s16 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s16 5 _ le
  decide +kernel
theorem b17 : Blocked tgt 5 s17 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s17 5 _ le
  decide +kernel
theorem b18 : Blocked tgt 5 s18 := by
  apply PetersenFastNode.node (nxt := #[s19]) (hints := [1755,1755,454,1429,842,1947,842,1947,838,3731,838,3219,1350,3723,1350,2699,1365,454,1493,1365,1947,778,1947,1625,1365,774,1813,1365,0,1350,1349,1349,714,1947,842,1947,454,202,838,454,454,2453,1350,454,1427,1435,1939,1427,907,923,1931,907,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s19], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.nil
theorem b21 : Blocked tgt 5 s21 := by
  apply PetersenFastNode.node (nxt := #[s19,s22]) (hints := [716,1740,2470,2470,716,908,2858,716,196,708,204,196,716,2700,0,716,2534,1,2534,3430,908,3174,908,3690,2854,3178,2854,3430,2700,1382,2700,1350,2794,908,2858,908,2534,2282,2854,2534,454,2700,2502,2700,388,396,900,388,908,810,2700,908,2180,2188,2180,2692]) (by decide +kernel)
  change ∀ b ∈ [s19,s22], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.nil
theorem b23 : Blocked tgt 5 s23 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s23 5 _ le
  decide +kernel
theorem b33 : Blocked tgt 5 s33 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s33 5 _ le
  decide +kernel
theorem b34 : Blocked tgt 5 s34 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s34 5 _ le
  decide +kernel
end PetersenSmallStarts.M111
