import M251StartData
import M251StartPins0
import M251StartL6B0
import M251StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 7 s0 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s0 7 _ le
  decide +kernel
theorem b1 : Blocked tgt 7 s1 := by
  apply PetersenFastNode.node (nxt := #[s2,s3,s4]) (hints := [2713,2969,13288,2969,6839,3485,2457,3869,3485,2969,2461,3865,2969,9161,921,11081,9161,2969,0,6937,2969,2969,969,11033,2969,13288,6967,12772,12776,13284,12772,13288,3865,14056,13288,13288,11081,15080,13288,9160,9192,13256,9160,5032,5096,13224,5032,7739,3869,7739,3869,7735,14056,7735,14056,14951,15080,14951,15080,1,6937,2,6937,14903,11033,14903,11033,13540,13544,13540,14052,14564,14568,14564,15076,3869,6425,7453,3869,3869,1869,11549,3869,14056,1817,15080,14056,9928,9960,14024,9928,5800,5864,13992,5800,10952,10984,15048,10952,6824,6888,15016,6824,6937,4937,11033,6937]) (by decide +kernel)
  change ∀ b ∈ [s2,s3,s4], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.nil
theorem b5 : Blocked tgt 7 s5 := by
  apply PetersenFastNode.node (nxt := #[s6,s7,s8,s9,s10,s11,s12,s13]) (hints := [2974,6844,13293,13293,3874,0,3874,1,3870,14061,3870,14061,11086,15085,11086,15085,6942,2,6942,3,11038,4,11038,5,6972,2974,7100,3490,2462,3874,3490,2974,14061,3870,14061,9166,15085,11086,15085,2974,6,6942,2974,2974,974,11038,2974,7488,3618,7744,7488,14061,3614,14061,6972,15085,4924,15085,13164,7,6942,6940,6940,6972,10782,14908,6972,13545,13549,13545,14057,14569,14573,14569,15081,3874,6430,7458,3874,3874,1874,11554,3874,14061,1822,15085,14061,9933,9965,14029,9933,5805,5869,13997,5805,10957,10989,15053,10957,6829,6893,15021,6829,6942,4942,11038,6942]) (by decide +kernel)
  change ∀ b ∈ [s6,s7,s8,s9,s10,s11,s12,s13], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.nil
theorem b14 : Blocked tgt 7 s14 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s14 7 _ le
  decide +kernel
theorem b15 : Blocked tgt 7 s15 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s15 7 _ le
  decide +kernel
theorem b16 : Blocked tgt 7 s16 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s16 7 _ le
  decide +kernel
theorem b17 : Blocked tgt 7 s17 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s17 7 _ le
  decide +kernel
theorem b18 : Blocked tgt 7 s18 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s18 7 _ le
  decide +kernel
theorem b19 : Blocked tgt 7 s19 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s19 7 _ le
  decide +kernel
theorem b20 : Blocked tgt 7 s20 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s20 7 _ le
  decide +kernel
theorem b21 : Blocked tgt 7 s21 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s21 7 _ le
  decide +kernel
theorem b22 : Blocked tgt 7 s22 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s22 7 _ le
  decide +kernel
theorem b23 : Blocked tgt 7 s23 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s23 7 _ le
  decide +kernel
theorem b24 : Blocked tgt 7 s24 := by
  apply PetersenFastNode.node (nxt := #[s25,s26,s27,s28,s29,s30]) (hints := [6842,2972,2972,6842,3488,2460,3872,3488,2972,2464,3868,2972,6842,2972,2972,6842,9164,924,11084,9164,2972,2746,6940,2972,2972,972,11036,2972,7486,3616,7742,7486,3612,7486,3868,13291,13291,15083,11084,15083,11084,0,6940,7454,6940,14906,11036,14906,11036,1,3868,3864,3864,2,3872,3872,3,14567,14571,14567,15079,3872,6428,7456,3872,3872,1872,11552,3872,14059,14059,15083,1820,15083,10060,3868,6432,6940,3868,3868,1868,11036,3868,15083,11084,15083,11084,4,6940,5,6940,14906,11036,14906,11036,10955,10987,15051,10955,6827,6891,15019,6827,6940,4940,11036,6940]) (by decide +kernel)
  change ∀ b ∈ [s25,s26,s27,s28,s29,s30], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.nil
theorem b31 : Blocked tgt 7 s31 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s31 7 _ le
  decide +kernel
theorem b32 : Blocked tgt 7 s32 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s32 7 _ le
  decide +kernel
end PetersenSmallStarts.M251
