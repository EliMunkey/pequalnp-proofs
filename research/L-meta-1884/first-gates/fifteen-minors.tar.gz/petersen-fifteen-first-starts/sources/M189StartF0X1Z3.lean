import M189StartData
import M189StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888888888888888 :: inputs 6) tgt 7 := by
  change NoAtMost [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s87] [386,453,451,453,388,453,453,453,390,709,455,709,708,709,709,709,586,453,451,453,716,453,453,453,390,1221,455,1221,716,1221,1221,1221,1106,453,451,453,1236,453,453,453,1366,709,455,709,1236,709,709,709,1626,453,451,453,1756,453,453,453,1366,2245,455,2245,1756,2245,2245,2245,2210,453,2275,453,388,453,453,453,2470,709,2535,709,708,709,709,709,2666,453,2275,453,716,453,453,453,2470,1221,2535,1221,716,1221,1221,1221,1106,453,2275,453,1236,453,453,453,1366,709,2535,709,1236,709,709,709,1626,453,2275,453,1756,453,453,453,1366,1366,2535,1430,1756,1366,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s87], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s87) b87 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M189
