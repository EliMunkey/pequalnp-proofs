import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1334 : Blocked tgt 8 s1334 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1334 8 _ le
  decide +kernel
theorem b1335 : Blocked tgt 8 s1335 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1335 8 _ le
  decide +kernel
theorem b1336 : Blocked tgt 8 s1336 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1336 8 _ le
  decide +kernel
theorem b1337 : Blocked tgt 8 s1337 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1337 8 _ le
  decide +kernel
theorem b1338 : Blocked tgt 8 s1338 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1338 8 _ le
  decide +kernel
theorem b1339 : Blocked tgt 8 s1339 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1339 8 _ le
  decide +kernel
theorem b1340 : Blocked tgt 8 s1340 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1340 8 _ le
  decide +kernel
theorem b1341 : Blocked tgt 8 s1341 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1341 8 _ le
  decide +kernel
theorem b1342 : Blocked tgt 8 s1342 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1342 8 _ le
  decide +kernel
theorem b1343 : Blocked tgt 8 s1343 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1343 8 _ le
  decide +kernel
theorem b1344 : Blocked tgt 8 s1344 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1344 8 _ le
  decide +kernel
theorem b1345 : Blocked tgt 8 s1345 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1345 8 _ le
  decide +kernel
theorem b1346 : Blocked tgt 8 s1346 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1346 8 _ le
  decide +kernel
theorem b1347 : Blocked tgt 8 s1347 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1347 8 _ le
  decide +kernel
end PetersenSmallStarts.M127
