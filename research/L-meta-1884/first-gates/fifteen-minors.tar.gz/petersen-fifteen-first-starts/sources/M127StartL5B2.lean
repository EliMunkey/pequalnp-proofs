import M127StartData
import M127StartL4B0
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b932 : Blocked tgt 5 s932 := by
  apply PetersenFastNode.node (nxt := #[s931]) (hints := [387,387,10950,9158,9029,9158,10434,10946,10438,10434,10950,9926,3331,9926,2694,10886,2758,2694,9029,9158,9029,9158,771,10437,771,2435,2435,9926,3331,9926,2435,2757,8451,2435,8642,8646,9154,8642,9158,3075,9926,9158,902,966,9094,902,771,9926,9922,9922,771,0,8451,771,1670,1734,9862,1670]) (by decide +kernel)
  change ∀ b ∈ [s931], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s931) b931 <|
    PetersenLocalChildren.nil
theorem b975 : Blocked tgt 5 s975 := by
  apply PetersenFastNode.node (nxt := #[s931]) (hints := [4515,4515,2694,902,4901,902,2694,1670,7459,1670,2694,4742,0,2694,2178,2690,2182,2178,4901,902,4901,902,6563,1670,7459,1670,2435,4742,6531,4742,4899,6309,4899,6563,902,7203,1670,902,902,805,4742,902,386,390,898,386,1670,3363,4742,1670,4899,1670,1666,1666,4226,4230,4738,4226]) (by decide +kernel)
  change ∀ b ∈ [s931], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s931) b931 <|
    PetersenLocalChildren.nil
theorem b1003 : Blocked tgt 5 s1003 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1003 5 _ le
  decide +kernel
theorem b1004 : Blocked tgt 5 s1004 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1004 5 _ le
  decide +kernel
theorem b1005 : Blocked tgt 5 s1005 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1005 5 _ le
  decide +kernel
theorem b1011 : Blocked tgt 5 s1011 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1011 5 _ le
  decide +kernel
theorem b1020 : Blocked tgt 5 s1020 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1020 5 _ le
  decide +kernel
theorem b1024 : Blocked tgt 5 s1024 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1024 5 _ le
  decide +kernel
theorem b1033 : Blocked tgt 5 s1033 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2708,2708,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,3080,2693,2836,901,2836,901,1544,1673,1544,1673,3604,1669,3604,1669,4740,2693,6788,2693,1417,389,1673,1417,901,393,1669,901,901,788,2693,901,3088,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1082 : Blocked tgt 5 s1082 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5514,1418,2708,1418,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,8466,2693,773,773,1418,901,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1087 : Blocked tgt 5 s1087 := by
  intro k le c
  apply rejects_sound r23 i4 3 tgt small23 hot23 [] s1087 5 _ le
  decide +kernel
theorem b1088 : Blocked tgt 5 s1088 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2708,2708,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,3080,2693,2836,901,2836,901,1544,1673,1544,1673,3604,1669,3604,1669,4740,2693,6788,2693,1417,389,1673,1417,901,393,1669,901,901,788,2693,901,3088,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1111 : Blocked tgt 5 s1111 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1111 5 _ le
  decide +kernel
theorem b1119 : Blocked tgt 5 s1119 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,1418,2708,1418,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,8466,2693,2194,901,1418,901,1418,1673,1930,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,3346,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1141 : Blocked tgt 5 s1141 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,1418,2772,1418,4741,901,2900,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,8466,2693,2708,773,2836,2708,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,788,2693,901,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1157 : Blocked tgt 5 s1157 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1157 5 _ le
  decide +kernel
end PetersenSmallStarts.M127
