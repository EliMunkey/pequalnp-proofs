import M127StartData
import M127StartL6B5
import M127StartL6B21
import M127StartL6B22
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b708 : Blocked tgt 7 s708 := by
  apply PetersenFastNode.node (nxt := #[s150,s149,s709,s710,s693,s711,s712,s713,s714,s715,s716,s717]) (hints := [15104,15104,15232,9041,5526,9169,15232,5526,15232,15104,15104,9169,1814,5526,1814,9941,15104,9941,1814,15104,1814,5526,5526,9941,3390,6590,3390,4502,5526,9937,3390,5526,3390,6590,6590,9937,3350,5526,3350,4542,6590,10961,3350,6590,3350,5526,5526,10961,1430,2462,0,1430,5526,13009,5526,5526,1,2462,2462,13009,5526,5526,9494,6912,15104,2,9494,15104,9494,5526,5526,3,9685,9685,9941,8657,9169,1814,9941,9169,9941,9685,9685,1814,9169,9169,9937,8661,9685,3390,9937,9685,9937,9169,9169,3390,9169,9169,10961,13184,15232,3350,10961,15232,10961,9169,9169,3350,9169,9169,13009,11136,15232,4,13009,15232,13009,9169,9169,5,913,913,6,977,9169,9494,9105,9169,7,913,913,9494,3390,6974,3390,9937,9941,9937,9933,9941,3390,9933,6974,9937,9941,9941,11477,10449,6974,10961,11477,6974,11477,9941,9941,10961,9941,9941,13525,12497,1814,13009,13525,1814,13525,9941,9941,13009,1685,1685,9494,1749,9941,8,9877,9941,9494,1685,1685,9,9937,9937,10961,10453,3390,11477,10961,3390,10961,9937,9937,11477,9937,9937,13009,12501,3390,13525,13009,3390,13009,9937,9937,13525,1681,1681,14654,1745,9937,9494,9873,9937,14654,1681,1681,9494,10961,10961,13009,3350,3350,10,13009,3350,13009,10961,10961,11,2705,2705,9494,2769,10961,14654,10897,10961,9494,2705,2705,14654,4753,4753,10526,4817,13009,9494,12945,13009,10526,4753,4753,9494]) (by decide +kernel)
  change ∀ b ∈ [s150,s149,s709,s710,s693,s711,s712,s713,s714,s715,s716,s717], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s150) b150 <|
    PetersenLocalChildren.push (x := s149) b149 <|
    PetersenLocalChildren.push (x := s709) b709 <|
    PetersenLocalChildren.push (x := s710) b710 <|
    PetersenLocalChildren.push (x := s693) b693 <|
    PetersenLocalChildren.push (x := s711) b711 <|
    PetersenLocalChildren.push (x := s712) b712 <|
    PetersenLocalChildren.push (x := s713) b713 <|
    PetersenLocalChildren.push (x := s714) b714 <|
    PetersenLocalChildren.push (x := s715) b715 <|
    PetersenLocalChildren.push (x := s716) b716 <|
    PetersenLocalChildren.push (x := s717) b717 <|
    PetersenLocalChildren.nil
theorem b718 : Blocked tgt 7 s718 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s718 7 _ le
  decide +kernel
theorem b719 : Blocked tgt 7 s719 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s719 7 _ le
  decide +kernel
theorem b720 : Blocked tgt 7 s720 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s720 7 _ le
  decide +kernel
theorem b721 : Blocked tgt 7 s721 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s721 7 _ le
  decide +kernel
theorem b722 : Blocked tgt 7 s722 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s722 7 _ le
  decide +kernel
theorem b723 : Blocked tgt 7 s723 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s723 7 _ le
  decide +kernel
theorem b724 : Blocked tgt 7 s724 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s724 7 _ le
  decide +kernel
theorem b725 : Blocked tgt 7 s725 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s725 7 _ le
  decide +kernel
theorem b726 : Blocked tgt 7 s726 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s726 7 _ le
  decide +kernel
theorem b727 : Blocked tgt 7 s727 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s727 7 _ le
  decide +kernel
theorem b728 : Blocked tgt 7 s728 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s728 7 _ le
  decide +kernel
theorem b729 : Blocked tgt 7 s729 := by
  apply PetersenFastNode.node (nxt := #[s730]) (hints := [12998,0,2451,2451,9545,9158,9545,9158,1803,9930,1803,9930,12998,9926,12490,9926,3339,10950,3339,10950,9483,12934,9483,4742,5515,5515,9158,9545,9158,9545,9930,1803,9930,1803,9926,3347,10950,3339,10950,3339,10515,9483,10515,9483,9545,9158,9545,9158,1803,9930,1803,9930,6547,9926,7571,3339,10950,3339,10950,9483,6869,9483,6547,9674,8646,9930,9674,9158,8650,9926,9158,9158,3083,10950,9158,902,966,9094,902,2835,9926,9922,9922,9930,10438,11466,9930,1674,1738,9866,1674,9926,10442,10950,9926,1670,1734,9862,1670,2694,2758,10886,2694]) (by decide +kernel)
  change ∀ b ∈ [s730], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s730) b730 <|
    PetersenLocalChildren.nil
theorem b732 : Blocked tgt 7 s732 := by
  apply PetersenFastNode.node (nxt := #[s709,s733]) (hints := [6902,5354,903,13674,903,13674,1675,5932,1675,5932,1671,7476,2695,7468,2695,7468,4743,0,4743,1,14644,13612,14644,13612,13674,903,13674,6902,5932,1675,5932,1675,6902,1671,7926,7468,4854,7468,4838,2774,2806,6870,2774,13612,6580,13674,5676,13930,13674,903,13674,13674,903,13674,7212,15466,13674,9546,9578,13642,9546,6966,13612,13610,13610,6964,5932,5932,1667,5932,2183,7468,5932,1804,1836,5900,1804,5932,5738,13612,5932,1671,7468,2695,7468,1671,4235,4743,1671,14644,13612,1671,13612,3340,3372,7436,3340,7468,7274,13612,7468,9484,9516,9484,13580]) (by decide +kernel)
  change ∀ b ∈ [s709,s733], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s709) b709 <|
    PetersenLocalChildren.push (x := s733) b733 <|
    PetersenLocalChildren.nil
theorem b734 : Blocked tgt 7 s734 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s734 7 _ le
  decide +kernel
theorem b735 : Blocked tgt 7 s735 := by
  apply PetersenFastNode.node (nxt := #[s736]) (hints := [6579,4523,8650,7219,8650,13673,9930,4907,9930,7475,9926,15989,10950,7467,10950,7459,12998,3379,12998,3347,7475,12587,14643,7475,13673,6579,13673,15093,5931,9930,5931,6579,15093,6579,6579,15093,7467,4531,7467,4515,2451,2483,6547,2451,13611,6901,13611,6579,13673,5675,13929,13673,13673,9158,13673,7211,15465,13673,9545,9577,13641,9545,394,13611,13609,13609,0,5931,5931,9922,5931,10438,7467,5931,1803,1835,5899,1803,5931,5737,13611,5931,9926,7467,10950,7467,9926,12490,12998,9926,1670,13611,9862,13611,3339,3371,7435,3339,7467,7273,13611,7467,9483,9515,9483,13579]) (by decide +kernel)
  change ∀ b ∈ [s736], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s736) b736 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
