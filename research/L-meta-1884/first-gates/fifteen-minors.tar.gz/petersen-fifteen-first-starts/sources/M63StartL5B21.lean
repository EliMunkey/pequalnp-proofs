import M63StartData
import M63StartL4B1
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b745 : Blocked tgt 5 s745 := by
  apply PetersenFastNode.node (nxt := #[s746]) (hints := [1365,2667,1429,1365,2795,1109,2987,2795,1235,2283,1683,1235,1707,1235,1707,1771,715,747,2763,715,714,2987,970,714,838,202,838,194,454,454,1429,714,1350,1429,1350,1478,1427,838,1683,838,1707,1427,842,842,2634,1094,2634,1350,0,838,838,1699,838,2122,1350,838,2634,1350,1610,1350]) (by decide +kernel)
  change ∀ b ∈ [s746], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s746) b746 <|
    PetersenLocalChildren.nil
theorem b754 : Blocked tgt 5 s754 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s754 5 _ le
  decide +kernel
theorem b755 : Blocked tgt 5 s755 := by
  apply PetersenFastNode.node (nxt := #[s756]) (hints := [778,778,842,1461,842,2827,1461,838,834,834,842,1094,1610,842,714,198,714,842,3445,715,3445,774,3893,3445,2405,2421,3429,2405,1365,1397,3413,1365,1427,838,1683,838,907,1350,1675,1350,0,2374,905,2374,838,2869,1350,838,838,1845,2374,838,1350,1547,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s756], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s756) b756 <|
    PetersenLocalChildren.nil
theorem b759 : Blocked tgt 5 s759 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s759 5 _ le
  decide +kernel
theorem b760 : Blocked tgt 5 s760 := by
  apply PetersenFastNode.node (nxt := #[s761]) (hints := [1429,1365,715,1365,842,842,1429,838,1553,838,421,1429,405,405,454,454,714,2374,715,1365,1365,715,1365,774,1813,1365,2389,1365,1365,1381,0,1365,1365,2373,1425,838,1553,838,907,401,1547,907,714,2374,714,2374,838,1813,1813,838,838,1813,2374,838,1350,1350]) (by decide +kernel)
  change ∀ b ∈ [s761], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s761) b761 <|
    PetersenLocalChildren.nil
theorem b764 : Blocked tgt 5 s764 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s764 5 _ le
  decide +kernel
theorem b765 : Blocked tgt 5 s765 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s765 5 _ le
  decide +kernel
theorem b766 : Blocked tgt 5 s766 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s766 5 _ le
  decide +kernel
theorem b767 : Blocked tgt 5 s767 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s767 5 _ le
  decide +kernel
theorem b768 : Blocked tgt 5 s768 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s768 5 _ le
  decide +kernel
theorem b769 : Blocked tgt 5 s769 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s769 5 _ le
  decide +kernel
theorem b770 : Blocked tgt 5 s770 := by
  apply PetersenFastNode.node (nxt := #[s771]) (hints := [454,454,714,2374,1429,1365,390,1365,842,842,1429,838,1553,838,1610,1350,1610,1350,1365,3413,714,2374,2374,714,838,202,838,2374,1350,0,1350,2374,905,1365,1365,1105,1365,774,1813,1365,1545,1350,1349,1349,1425,838,1553,838,1610,1350,1610,1350,838,789,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s771], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s771) b771 <|
    PetersenLocalChildren.nil
theorem b772 : Blocked tgt 5 s772 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s772 5 _ le
  decide +kernel
theorem b773 : Blocked tgt 5 s773 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s773 5 _ le
  decide +kernel
theorem b774 : Blocked tgt 5 s774 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [453,453,2373,713,1364,2373,1364,2372,713,2373,2373,713,837,804,837,2373,1349,1546,420,484,714,420,906,2826,420,932,1552,420,420,1349,1609,420,714,2404,2404,714,2404,202,2852,2404,2404,1349,1348,2404,386,2852,898,2852,906,1349,1609,906,2852,788,1349,2852]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b780 : Blocked tgt 5 s780 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s780 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
