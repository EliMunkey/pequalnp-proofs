import M189StartData
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b71 : Blocked tgt 5 s71 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1236,1236,1428,2241,616,1428,1428,1752,1428,707,1812,1428,1349,404,1349,2437,1364,389,1364,1428,1754,1946,387,1812,707,387,387,1093,1219,387,387,1108,2243,387,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,707,788,1219,707,707,3226,2243,707,1219,2714,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b72 : Blocked tgt 5 s72 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s72 5 _ le
  decide +kernel
theorem b77 : Blocked tgt 5 s77 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s77 5 _ le
  decide +kernel
theorem b78 : Blocked tgt 5 s78 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s78 5 _ le
  decide +kernel
theorem b111 : Blocked tgt 5 s111 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s111 5 _ le
  decide +kernel
theorem b112 : Blocked tgt 5 s112 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1746,707,1234,1234,2917,2533,579,2533,707,451,2661,451,707,1219,788,707,707,2243,869,707,1364,2469,1428,1364,387,387,1364,451,3364,1219,3364,1219,1364,2243,3348,2243,2273,2277,2529,2273,2533,1091,3429,2533,453,485,2501,453,451,3173,1219,451,451,3348,2243,451,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b133 : Blocked tgt 5 s133 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s133 5 _ le
  decide +kernel
theorem b151 : Blocked tgt 5 s151 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s151 5 _ le
  decide +kernel
theorem b152 : Blocked tgt 5 s152 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s152 5 _ le
  decide +kernel
theorem b153 : Blocked tgt 5 s153 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s153 5 _ le
  decide +kernel
theorem b154 : Blocked tgt 5 s154 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s154 5 _ le
  decide +kernel
theorem b165 : Blocked tgt 5 s165 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s165 5 _ le
  decide +kernel
theorem b180 : Blocked tgt 5 s180 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s180 5 _ le
  decide +kernel
theorem b184 : Blocked tgt 5 s184 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1428,2468,1364,1754,1946,386,1754,1234,1746,1242,1234,714,1738,730,714,1754,3738,2178,1754,1816,1818,1816,1944,1428,2728,1812,1428,2728,1428,1428,2728,1428,3610,3348,1428,1426,1434,1938,1426,906,922,1930,906,1946,808,3738,1946,788,788,1812,3624,3218,3226,3218,3730,2698,2714,2698,3722]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b189 : Blocked tgt 5 s189 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s189 5 _ le
  decide +kernel
theorem b190 : Blocked tgt 5 s190 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1738,714,730,714,3429,2533,1091,2533,1219,451,3173,451,1219,707,772,707,1219,2243,1381,1219,2468,2469,2468,2532,714,451,906,714,2852,707,714,707,714,2179,2698,714,2273,2277,2529,2273,2533,579,2917,2533,453,485,2501,453,451,2661,707,451,451,808,2243,451,707,869,2243,707]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M189
