import SmallStartCore
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def tgt : BitVec 4 := 0x8
def i2 : List (BitVec 4) := [0xa,0xc]
theorem target_eq : tgt = graphTarget 2 [(0,1)] := by decide +kernel
def s0 : List (BitVec 4) := [0xa,0xc]
def s1 : List (BitVec 4) := [0xa,0xc,0xe]
def s2 : List (BitVec 4) := [0x2,0xa]
def s3 : List (BitVec 4) := [0x2,0xa,0xc]
end PetersenSmallStarts.M3
