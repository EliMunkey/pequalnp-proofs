import M45StartData
import M45StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_0 : NoAtMost (0xffaa :: inputs 4) tgt 2 := by
  change NoAtMost [0xffaa,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s4] [98,115,115,115,100,117,117,117,102,119,119,119,180,181,181,181,154,154,115,115,188,188,117,117,222,222,119,119,188,188,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s4], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_0
end PetersenSmallStarts.M45
