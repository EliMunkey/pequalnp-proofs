import M127StartData
import M127StartL6B0
import M127StartL6B2
import M127StartL6B3
import M127StartPins0
import M127StartL6B1
import M127StartL6B4
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b75 : Blocked tgt 7 s75 := by
  apply PetersenFastNode.node (nxt := #[s28,s76,s77]) (hints := [15095,15095,5549,9932,5933,5549,6325,9928,7349,9928,5549,4533,7341,5549,9032,9032,5549,9160,1421,13000,5517,13000,5549,0,13613,5549,13931,9932,13931,9932,15223,9928,15991,9928,13175,13175,15223,7469,1,9160,15223,9160,11095,13000,15191,13000,6967,7031,15159,6967,6965,9928,9924,9924,9932,4917,7469,9932,9676,8648,9676,9932,9932,12488,13516,9932,1676,1740,9868,1676,9928,7469,7461,9928,9160,8652,9160,9928,9928,12492,13000,9928,1672,1736,9864,1672,9160,10952,13000,3373,13000,3341,7469,12597,13613,7469,9160,2,13000,9160,904,968,9096,904,4744,4808,12936,4744]) (by decide +kernel)
  change ∀ b ∈ [s28,s76,s77], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s76) b76 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.nil
theorem b78 : Blocked tgt 7 s78 := by
  apply PetersenFastNode.node (nxt := #[s79,s30]) (hints := [9031,9031,9159,5548,9159,13158,9675,8647,9931,9675,9159,8651,9927,9159,9159,7468,9159,0,12999,9159,903,967,9095,903,5548,15094,5548,9931,5932,5548,4516,4524,5540,4516,5548,10951,6324,5548,1420,1452,5516,1420,5548,1,13612,5548,13930,5932,13930,5932,15222,9927,15990,9927,15466,10951,15206,10951,11094,12999,15190,12999,6966,13612,15158,13612,4900,4908,5924,4900,5932,10439,11467,5932,1804,1836,5900,1804,5932,1739,13612,5932,9927,10443,10951,9927,9927,12491,12999,9927,12580,12588,12580,13604,10951,11370,12999,10951,13612,2759,13612,2695,9484,9516,9484,13580]) (by decide +kernel)
  change ∀ b ∈ [s79,s30], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.nil
theorem b80 : Blocked tgt 7 s80 := by
  apply PetersenFastNode.node (nxt := #[s81,s82,s9,s15,s83,s84,s18,s85,s31,s86,s66,s87,s88,s89,s90,s91,s92,s93,s94,s96,s99,s77,s100,s101,s102]) (hints := [11149,1443,11149,11277,0,1,1443,1443,1827,9954,2,9954,1827,3,1827,1443,1443,9954,2475,2475,3371,9950,1443,9950,3371,1443,3371,9950,2475,9950,1443,1443,3363,10974,2475,10974,3363,2475,3363,10974,1443,10974,9054,4,5,9054,1443,9182,1443,1443,6,9182,7,9182,1443,1443,9507,8,9,10,9507,11,9507,1443,1443,12,9601,9601,13953,9954,11149,9954,10113,11149,13953,9954,9601,9954,11149,11149,16013,9950,9601,9950,12173,9601,16013,9950,11149,9950,9085,9085,15489,10974,11149,10974,11133,11149,15489,10974,9085,10974,13,14,15,9182,11149,9182,11117,11149,6,9182,16,9182,2893,2893,17,2957,11149,9507,11085,11149,18,2893,2893,9507,2859,2859,3371,9950,9954,9950,9946,9954,3371,9946,2859,9950,9954,9954,11490,10462,2859,10974,11490,2859,11490,9954,9954,10974,9698,9954,9698,8670,1827,9182,9698,1827,9698,9954,9954,9182,1698,1698,9507,1762,9954,19,9890,9954,9507,1698,1698,20,9950,9950,10974,10466,3371,11490,10974,3371,10974,9950,9950,11490,9182,9950,9182,8674,3371,9698,9182,3371,9182,9950,9950,9698,1694,1694,10539,1758,9950,9507,9886,9950,10539,1694,1694,9507,9182,10974,9182,3363,3363,21,9182,3363,9182,10974,10974,22,2718,2718,9507,2782,10974,10539,10910,10974,9507,2718,2718,10539,926,926,23,990,9182,9507,9118,9182,24,926,926,9507]) (by decide +kernel)
  change ∀ b ∈ [s81,s82,s9,s15,s83,s84,s18,s85,s31,s86,s66,s87,s88,s89,s90,s91,s92,s93,s94,s96,s99,s77,s100,s101,s102], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s82) b82 <|
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s83) b83 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s85) b85 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.push (x := s86) b86 <|
    PetersenLocalChildren.push (x := s66) b66 <|
    PetersenLocalChildren.push (x := s87) b87 <|
    PetersenLocalChildren.push (x := s88) b88 <|
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.push (x := s90) b90 <|
    PetersenLocalChildren.push (x := s91) b91 <|
    PetersenLocalChildren.push (x := s92) b92 <|
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.push (x := s99) b99 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.push (x := s100) b100 <|
    PetersenLocalChildren.push (x := s101) b101 <|
    PetersenLocalChildren.push (x := s102) b102 <|
    PetersenLocalChildren.nil
theorem b103 : Blocked tgt 7 s103 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s103 7 _ le
  decide +kernel
theorem b104 : Blocked tgt 7 s104 := by
  apply PetersenFastNode.node (nxt := #[s81,s105,s42,s106,s107,s109,s110,s111,s112]) (hints := [5267,1427,0,1427,15101,1427,9938,1811,1427,2459,403,3355,2459,1427,411,3347,1427,1,1427,1427,13006,1427,2,9491,1427,11133,11133,9938,1811,9938,1811,9934,3355,9934,3355,10958,3347,10958,3347,9166,9166,3,9491,4,9491,13937,9938,13937,9938,15997,9934,15997,9934,15473,10958,15473,10958,5,13006,6,13006,7,9491,8,9491,2843,9934,9930,9930,9938,10446,11474,9938,9938,12494,13522,9938,1682,1746,9874,1682,9934,10450,10958,9934,9934,12498,13006,9934,1678,1742,9870,1678,10958,3347,13006,10958,2702,2766,10894,2702,4750,4814,12942,4750]) (by decide +kernel)
  change ∀ b ∈ [s81,s105,s42,s106,s107,s109,s110,s111,s112], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s105) b105 <|
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.push (x := s106) b106 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s109) b109 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s111) b111 <|
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.nil
theorem b113 : Blocked tgt 7 s113 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s113 7 _ le
  decide +kernel
theorem b114 : Blocked tgt 7 s114 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s114 7 _ le
  decide +kernel
theorem b115 : Blocked tgt 7 s115 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s115 7 _ le
  decide +kernel
theorem b116 : Blocked tgt 7 s116 := by
  apply PetersenFastNode.node (nxt := #[s47,s117,s107,s118,s119]) (hints := [13615,5551,0,5551,906,906,13615,1,1678,5935,1678,5935,1674,7479,1674,7479,2698,7471,2698,7471,4746,13583,4746,9487,8970,5551,9098,5551,6841,5551,1678,5935,5551,6583,4527,7479,6583,5551,4535,7471,5551,1423,1455,5519,1423,9098,15161,1678,5935,1678,5935,1674,7479,1674,7479,2698,7471,2698,7471,4746,2,4746,9098,5677,5935,5677,5935,7737,7479,7737,7479,7213,7471,7213,7471,3,4746,4,4746,6967,4911,7479,6967,5935,4919,7471,5935,1807,1839,5903,1807,1674,7471,7463,7463,3351,3383,7447,3351,3343,3375,7439,3343]) (by decide +kernel)
  change ∀ b ∈ [s47,s117,s107,s118,s119], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s117) b117 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s118) b118 <|
    PetersenLocalChildren.push (x := s119) b119 <|
    PetersenLocalChildren.nil
theorem b120 : Blocked tgt 7 s120 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s120 7 _ le
  decide +kernel
theorem b121 : Blocked tgt 7 s121 := by
  apply PetersenFastNode.node (nxt := #[s122,s123,s124,s125]) (hints := [15096,9033,15224,15096,5550,9805,5934,5550,5550,13548,6582,4526,7478,6582,5550,4534,7470,5550,1422,1454,5518,1422,5550,6904,13614,5550,9677,8649,9933,9677,9161,13676,9161,8653,9929,9161,9161,13176,10953,9161,9161,11128,13001,9161,905,969,9097,905,9933,13932,6966,9929,9925,9925,9933,10441,11469,9933,9933,12489,13517,9933,1677,1741,9869,1677,15476,9929,15476,9929,15468,10953,15468,10953,0,13001,1,13001,2,13614,3,13614,9929,10445,10953,9929,9929,12493,13001,9929,1673,1737,9865,1673,10953,3374,13001,10953,2697,2761,10889,2697,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s122,s123,s124,s125], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s122) b122 <|
    PetersenLocalChildren.push (x := s123) b123 <|
    PetersenLocalChildren.push (x := s124) b124 <|
    PetersenLocalChildren.push (x := s125) b125 <|
    PetersenLocalChildren.nil
theorem b126 : Blocked tgt 7 s126 := by
  apply PetersenFastNode.node (nxt := #[s127,s128]) (hints := [15094,5548,15094,5548,9159,9675,9159,9675,9931,9931,9927,7476,9927,7476,10951,11467,10951,11467,12999,13515,12999,13515,0,13612,1,13612,5292,5292,5548,9675,5548,15094,13930,5548,6580,4524,7476,6580,5548,4532,7468,5548,1420,1452,5516,1420,5548,6902,13612,5548,9675,9159,9159,9675,8643,8651,9667,8643,9675,7468,11467,9675,9675,11126,13515,9675,1419,1483,9611,1419,7476,9927,7476,9927,11467,10951,11467,10951,13515,12999,13515,12999,13612,5738,13612,5674,10435,10443,10435,11459,12483,12491,12483,13507,7476,12588,14644,7476,11467,3372,13515,11467,3211,3275,11403,3211,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s127,s128], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s127) b127 <|
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.nil
theorem b129 : Blocked tgt 7 s129 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s129 7 _ le
  decide +kernel
theorem b130 : Blocked tgt 7 s130 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s130 7 _ le
  decide +kernel
theorem b131 : Blocked tgt 7 s131 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s131 7 _ le
  decide +kernel
theorem b132 : Blocked tgt 7 s132 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s132 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
