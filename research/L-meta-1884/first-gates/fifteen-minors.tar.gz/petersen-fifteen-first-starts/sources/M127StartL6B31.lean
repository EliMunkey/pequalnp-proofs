import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1048 : Blocked tgt 6 s1048 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1048 6 _ le
  decide +kernel
theorem b1049 : Blocked tgt 6 s1049 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1049 6 _ le
  decide +kernel
theorem b1050 : Blocked tgt 6 s1050 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s1050 6 _ le
  decide +kernel
theorem b1051 : Blocked tgt 6 s1051 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10964,5514,9172,9172,1802,9929,1802,5514,402,4490,1426,402,3338,402,1418,1418,12996,5514,5514,10949,5514,2772,9482,5514,9929,1802,9929,1802,9925,3090,9925,11092,12997,9044,12997,3338,9157,9157,2836,2900,11028,2836,2834,9925,9921,9921,13513,9929,9929,12485,9929,10437,11465,9929,1673,1737,9865,1673,12997,9925,9925,12489,9925,10441,10949,9925,1669,1733,9861,1669,12997,10949,3338,10949,4741,12933,4805,4741,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1052 : Blocked tgt 6 s1052 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1052 6 _ le
  decide +kernel
theorem b1053 : Blocked tgt 6 s1053 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1053 6 _ le
  decide +kernel
theorem b1054 : Blocked tgt 6 s1054 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s1054 6 _ le
  decide +kernel
theorem b1055 : Blocked tgt 6 s1055 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,5514,2708,5514,901,901,1673,1802,1673,1802,1669,3346,1669,3346,2693,10514,2693,9482,4741,10514,4741,9482,2708,5514,5514,2708,1802,1673,1802,5514,2450,4490,3346,2450,5514,402,2450,5514,5514,2450,1418,1418,1673,1802,1673,1802,1669,3346,1669,3346,2693,11028,2693,9093,4741,9093,4741,8964,2834,778,3346,2834,1802,2834,2834,1802,1802,2834,2834,1802,1669,3346,3346,1669,4741,3346,3346,4233,3338,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1056 : Blocked tgt 6 s1056 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2708,901,2836,2708,5514,1737,1608,5514,2450,4490,3346,2450,5514,402,2450,5514,5514,2450,1418,1418,5514,2708,9482,5514,1737,901,1737,1993,901,8649,1669,901,901,2836,2693,901,4741,901,901,772,1417,901,901,1417,3346,1669,1729,1669,1737,2693,3785,1737,5833,1737,1737,4741,1673,1673,1669,10441,2693,1669,4741,1669,1669,12489,3346,1669,1669,3346,2693,3338,3209,2693,2693,3209,5257,4741,4741,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1057 : Blocked tgt 6 s1057 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s1057 6 _ le
  decide +kernel
theorem b1063 : Blocked tgt 6 s1063 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1063 6 _ le
  decide +kernel
theorem b1064 : Blocked tgt 6 s1064 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1064 6 _ le
  decide +kernel
theorem b1065 : Blocked tgt 6 s1065 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1065 6 _ le
  decide +kernel
theorem b1066 : Blocked tgt 6 s1066 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1066 6 _ le
  decide +kernel
theorem b1067 : Blocked tgt 6 s1067 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1067 6 _ le
  decide +kernel
theorem b1068 : Blocked tgt 6 s1068 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1068 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
