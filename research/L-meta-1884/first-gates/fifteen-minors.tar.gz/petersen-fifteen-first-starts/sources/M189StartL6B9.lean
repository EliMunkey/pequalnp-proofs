import M189StartData
import M189StartL5B1
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b179 : Blocked tgt 6 s179 := by
  apply PetersenFastNode.node (nxt := #[s180]) (hints := [1429,2534,1429,2534,1243,452,1499,1243,1235,1235,715,731,1227,715,2854,1243,1243,708,1243,2244,3291,1243,2274,2278,2530,2274,1429,2534,2534,1429,2534,1429,1429,2534,2534,580,2918,2534,454,486,2502,454,1427,452,452,1427,452,923,1931,452,452,2662,708,452,452,809,2244,452,789,789,1813,3625,0,708,1813,708,3219,2244,3219,2244,708,1220,2244,2715,2244,3723,708,870,2244,708]) (by decide +kernel)
  change ∀ b ∈ [s180], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s180) b180 <|
    PetersenLocalChildren.nil
theorem b181 : Blocked tgt 6 s181 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s181 6 _ le
  decide +kernel
theorem b182 : Blocked tgt 6 s182 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s182 6 _ le
  decide +kernel
theorem b183 : Blocked tgt 6 s183 := by
  apply PetersenFastNode.node (nxt := #[s184]) (hints := [1365,2534,1429,1365,1755,452,1947,1755,1235,1243,1747,1235,715,731,1739,715,1755,0,1755,2244,3739,1755,2274,2278,2530,2274,2534,580,2918,2534,2534,1092,3430,2534,2469,2534,2534,2469,454,486,2502,454,452,2662,708,452,452,3174,1220,452,387,452,452,387,452,809,2244,452,708,789,1220,708,708,2853,708,870,2244,708,1220,3365,1220,1382,2244,1220,2179,2244,2179,2244]) (by decide +kernel)
  change ∀ b ∈ [s184], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s184) b184 <|
    PetersenLocalChildren.nil
theorem b185 : Blocked tgt 6 s185 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s185 6 _ le
  decide +kernel
theorem b186 : Blocked tgt 6 s186 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s186 6 _ le
  decide +kernel
theorem b187 : Blocked tgt 6 s187 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s187 6 _ le
  decide +kernel
theorem b188 : Blocked tgt 6 s188 := by
  apply PetersenFastNode.node (nxt := #[s189,s190]) (hints := [1430,2471,1430,2534,1756,453,1948,1756,1244,1244,1756,709,716,732,1740,716,1756,2181,3740,1756,1756,1236,2275,2279,2531,2275,2535,581,2919,2535,2535,1093,3431,2535,455,487,2503,455,1430,2535,2535,1430,453,2663,709,453,453,3175,1221,453,453,810,2245,453,1428,453,453,1428,709,3114,1221,709,709,871,2245,709,709,1814,1221,1383,2245,1221,0,1221,1221,1,2245,3220]) (by decide +kernel)
  change ∀ b ∈ [s189,s190], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s189) b189 <|
    PetersenLocalChildren.push (x := s190) b190 <|
    PetersenLocalChildren.nil
theorem b191 : Blocked tgt 6 s191 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s191 6 _ le
  decide +kernel
theorem b192 : Blocked tgt 6 s192 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s192 6 _ le
  decide +kernel
theorem b194 : Blocked tgt 6 s194 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s194 6 _ le
  decide +kernel
theorem b195 : Blocked tgt 6 s195 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s195 6 _ le
  decide +kernel
theorem b196 : Blocked tgt 6 s196 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,2469,1754,2533,1624,1754,1754,1364,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2533,1428,2273,2277,2529,2273,2533,707,3045,2533,2533,1091,3429,2533,453,485,2501,453,1816,451,1816,451,2917,707,1812,707,3364,1219,3364,1219,3348,2243,3348,2243,451,1434,707,451,451,3173,1219,451,451,808,2243,451,707,788,1219,707,707,3226,2243,707,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b197 : Blocked tgt 6 s197 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s197 6 _ le
  decide +kernel
theorem b198 : Blocked tgt 6 s198 := by
  apply PetersenFastNode.node (nxt := #[s112]) (hints := [1365,2470,1429,1365,388,388,1365,452,1755,1365,1235,1755,1365,1755,1747,1747,715,1220,1739,1220,1755,2244,3739,2244,2274,2278,2530,2274,2729,2534,2534,2729,2534,2217,2918,2534,2534,1092,3430,2534,454,486,2502,454,452,1947,452,2918,964,452,452,3174,1220,452,452,3349,2244,452,708,708,0,2918,3625,1220,3625,1220,3739,2244,3739,2244,1220,789,1220,2918,2244,870,2244,838,1220,1382,2244,1220]) (by decide +kernel)
  change ∀ b ∈ [s112], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.nil
theorem b199 : Blocked tgt 6 s199 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s199 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
