import M45StartData
import M45StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888 :: inputs 4) tgt 2 := by
  change NoAtMost [0x8888,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s3] [98,117,115,117,100,117,117,117,102,181,119,181,180,181,181,181,154,117,115,117,188,117,117,117,222,222,119,238,188,222,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s3], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M45
