import M47StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 32) : Fin 32 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover0 : i5.all (fun q => i5.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
theorem labeled_0_2_2 : NoAtMost (0x50505050 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x50505050) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfc :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfcfcfc) (a:=0xeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c) (a:=0x44444444) (by decide +kernel) gate_0_1_2
theorem labeled_1_2_2 : NoAtMost (0x30303030 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x30303030) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_2_3 : NoAtMost (0xc0c0c0c0 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0) (a:=0x88888888) (by decide +kernel) gate_0_1_3
theorem labeled_1_4_1 : NoAtMost (0xcccc :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc) (a:=0xcc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_1_4_2 : NoAtMost (0x33330000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33330000) (a:=0x33003300) (by decide +kernel) gate_1_3_2
theorem labeled_1_4_3 : NoAtMost (0xcccc0000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000) (a:=0xcc00cc00) (by decide +kernel) gate_1_3_3
theorem labeled_2_3_0 : NoAtMost (0xfff0fff0 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfff0fff0) (a:=0xffffaaaa) (by decide +kernel) gate_0_4_0
theorem labeled_2_3_1 : NoAtMost (0xf000f0 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f0) (a:=0xaaaa) (by decide +kernel) gate_0_4_1
theorem labeled_2_3_2 : NoAtMost (0xf000f00 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f00) (a:=0x55550000) (by decide +kernel) gate_0_4_2
theorem labeled_2_3_3 : NoAtMost (0xf000f000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000) (a:=0xaaaa0000) (by decide +kernel) gate_0_4_3
theorem labeled_2_4_0 : NoAtMost (0xfffff0f0 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfffff0f0) (a:=0xffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_2_4_1 : NoAtMost (0xf0f0 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0) (a:=0xaa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_2_4_2 : NoAtMost (0xf0f0000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0000) (a:=0x55005500) (by decide +kernel) gate_0_3_2
theorem labeled_2_4_3 : NoAtMost (0xf0f00000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f00000) (a:=0xaa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_3_4_2 : NoAtMost (0xff0000 :: inputs 5) tgt 4 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff0000) (a:=0xff00) (by decide +kernel) gate_3_4_1
def forbidden : List (BitVec 32) := [0xeeeeeeee,0x22222222,0x44444444,0x88888888,0xfafafafa,0xa0a0a0a,0x50505050,0xa0a0a0a0,0xffaaffaa,0xaa00aa,0x55005500,0xaa00aa00,0xffffaaaa,0xaaaa,0x55550000,0xaaaa0000,0xfcfcfcfc,0xc0c0c0c,0x30303030,0xc0c0c0c0,0xcc00cc,0x33003300,0xcc00cc00,0xcccc,0x33330000,0xcccc0000,0xfff0fff0,0xf000f0,0xf000f00,0xf000f000,0xfffff0f0,0xf0f0,0xf0f0000,0xf0f00000,0xffffff00,0xff00,0xff0000,0xff000000]
theorem all_forbidden (g : BitVec 32) (h : g∈forbidden) : NoAtMost (g::inputs 5) tgt 4 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 5) tgt 4 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x22222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x44444444) gate_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x88888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xfafafafa) gate_0_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xa0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x50505050) labeled_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xa0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xffaaffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xaa00aa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x55005500) gate_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xaa00aa00) gate_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xffffaaaa) gate_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xaaaa) gate_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x55550000) gate_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xaaaa0000) gate_0_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xc0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x30303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xc0c0c0c0) labeled_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xcc00cc) gate_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x33003300) gate_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xcc00cc00) gate_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xcccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0x33330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xcccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xfff0fff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf000f0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf000f000) labeled_2_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xfffff0f0) labeled_2_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xf0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xffffff00) gate_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xff00) gate_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 4) (x:=0xff000000) gate_3_4_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M47
