import M251StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 64) : Fin 128 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27,32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59,64,65,66,67,72,73,74,75,80,81,82,83,88,89,90,91,96,97,98,99,104,105,106,107,112,113,114,115,120,121,122,123] : Array (Fin 128))[x.val]?.getD 0
theorem small0 : NoAtMost i6 (PetersenPackedPin.project r0 tgt) 6 := by
  have a : PetersenPackedPin.project r0 tgt = table 243 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 243 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 64) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95] : Array (Fin 128))[x.val]?.getD 0
theorem small1 : NoAtMost i6 (PetersenPackedPin.project r1 tgt) 6 := by
  have a : PetersenPackedPin.project r1 tgt = table 187 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 187 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r2 (x : Fin 64) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63] : Array (Fin 128))[x.val]?.getD 0
theorem small2 : NoAtMost i6 (PetersenPackedPin.project r2 tgt) 6 := by
  have a : PetersenPackedPin.project r2 tgt = table 123 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 123 0 (by decide +kernel) (by decide +kernel)
theorem hot2 : forcedConst r2 tgt = false := by decide +kernel
def r4 (x : Fin 16) : Fin 128 := (#[0,1,8,9,16,17,24,25,64,65,72,73,80,81,88,89] : Array (Fin 128))[x.val]?.getD 0
theorem small4 : NoAtMost i4 (PetersenPackedPin.project r4 tgt) 3 := by
  have a : PetersenPackedPin.project r4 tgt = table 177 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 177 0 (by decide +kernel) (by decide +kernel)
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
def r5 (x : Fin 16) : Fin 128 := (#[32,33,40,41,48,49,56,57,96,97,104,105,112,113,120,121] : Array (Fin 128))[x.val]?.getD 0
theorem small5 : NoAtMost i4 (PetersenPackedPin.project r5 tgt) 3 := by
  have a : PetersenPackedPin.project r5 tgt = table 177 64 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 177 64 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
def r14 (x : Fin 16) : Fin 128 := (#[64,65,66,67,72,73,74,75,96,97,98,99,104,105,106,107] : Array (Fin 128))[x.val]?.getD 0
theorem small14 : NoAtMost i4 (PetersenPackedPin.project r14 tgt) 3 := by
  have a : PetersenPackedPin.project r14 tgt = table 83 128 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 83 128 (by decide +kernel) (by decide +kernel)
theorem hot14 : forcedConst r14 tgt = false := by decide +kernel
def r19 (x : Fin 16) : Fin 128 := (#[4,5,6,7,20,21,22,23,68,69,70,71,84,85,86,87] : Array (Fin 128))[x.val]?.getD 0
theorem small19 : NoAtMost i4 (PetersenPackedPin.project r19 tgt) 3 := by
  have a : PetersenPackedPin.project r19 tgt = table 163 8 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 163 8 (by decide +kernel) (by decide +kernel)
theorem hot19 : forcedConst r19 tgt = false := by decide +kernel
end PetersenSmallStarts.M251
