import M31StartData
import M31StartPins0
import M31StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b45 : Blocked tgt 5 s45 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s45 5 _ le
  decide +kernel
theorem b46 : Blocked tgt 5 s46 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s46 5 _ le
  decide +kernel
theorem b47 : Blocked tgt 5 s47 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s47 5 _ le
  decide +kernel
theorem b48 : Blocked tgt 5 s48 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,362,724,692,362,425,458,362,626,106,850,626,362,626,626,362,362,626,626,362,425,394,425,456,421,786,421,724,677,724,677,741,229,229,724,196,722,421,417,417,425,549,809,425,458,425,425,458,421,553,677,421,388,421,421,388,677,842]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b49 : Blocked tgt 5 s49 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s49 5 _ le
  decide +kernel
theorem b50 : Blocked tgt 5 s50 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s50 5 _ le
  decide +kernel
theorem b51 : Blocked tgt 5 s51 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s51 5 _ le
  decide +kernel
theorem b52 : Blocked tgt 5 s52 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s52 5 _ le
  decide +kernel
theorem b53 : Blocked tgt 5 s53 := by
  apply PetersenFastNode.node (nxt := #[s54,s55]) (hints := [694,199,395,395,694,427,364,562,852,391,852,694,844,679,844,678,427,630,427,0,1,726,726,362,423,788,423,726,679,214,679,198,427,460,852,423,419,419,427,551,811,427,628,423,852,423,364,679,844,679,423,555,679,423]) (by decide +kernel)
  change ∀ b ∈ [s54,s55], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s54) b54 <|
    PetersenLocalChildren.push (x := s55) b55 <|
    PetersenLocalChildren.nil
theorem b56 : Blocked tgt 5 s56 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s56 5 _ le
  decide +kernel
theorem b57 : Blocked tgt 5 s57 := by
  apply PetersenFastNode.node (nxt := #[s58,s59]) (hints := [694,694,231,231,363,427,103,363,99,423,107,423,363,679,778,679,726,0,726,758,362,427,394,427,918,423,918,423,362,679,778,679,427,458,423,1,423,726,679,214,679,198,786,423,419,419,427,551,811,427,423,555,679,423]) (by decide +kernel)
  change ∀ b ∈ [s58,s59], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s58) b58 <|
    PetersenLocalChildren.push (x := s59) b59 <|
    PetersenLocalChildren.nil
theorem b60 : Blocked tgt 5 s60 := by
  apply PetersenFastNode.node (nxt := #[s17,s54]) (hints := [363,0,231,231,694,694,363,491,458,363,918,423,918,423,363,679,778,679,726,758,362,726,427,427,726,423,786,423,811,679,811,679,362,1,458,362,918,423,918,423,362,679,778,679,722,423,786,423,811,679,811,679,423,555,679,423]) (by decide +kernel)
  change ∀ b ∈ [s17,s54], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s54) b54 <|
    PetersenLocalChildren.nil
theorem b61 : Blocked tgt 5 s61 := by
  apply PetersenFastNode.node (nxt := #[s62,s63]) (hints := [694,694,363,427,394,363,788,363,107,107,231,231,363,0,363,679,778,679,362,427,394,427,628,106,788,628,726,362,726,758,362,679,778,679,724,427,427,724,1,427,427,722,427,551,811,427,423,423,679,811,679,811,679,811,679,811]) (by decide +kernel)
  change ∀ b ∈ [s62,s63], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s62) b62 <|
    PetersenLocalChildren.push (x := s63) b63 <|
    PetersenLocalChildren.nil
theorem b64 : Blocked tgt 5 s64 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [229,229,724,626,756,724,425,722,425,720,421,786,677,212,677,196,626,692,722,425,722,361,485,421,361,421,361,677,776,677,626,425,722,626,626,421,916,626,98,114,610,98,722,421,417,722,194,210,706,194,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b66 : Blocked tgt 5 s66 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s66 5 _ le
  decide +kernel
theorem b67 : Blocked tgt 5 s67 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s67 5 _ le
  decide +kernel
end PetersenSmallStarts.M31
