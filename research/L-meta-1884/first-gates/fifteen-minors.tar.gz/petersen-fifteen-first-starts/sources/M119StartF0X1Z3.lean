import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888888888888888 :: inputs 6) tgt 5 := by
  change NoAtMost [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s3] [194,386,195,579,196,388,579,579,390,390,455,839,196,2180,839,839,586,586,195,1091,716,908,1091,1091,846,846,455,1351,716,2700,1351,1351,1106,1106,195,579,1236,1428,579,579,1366,1366,455,839,1236,3220,839,839,1626,1626,195,1946,1756,1948,1948,1948,1886,1886,455,1950,1756,3740,3740,3740,2210,2210,2275,2659,196,388,2659,2659,2470,2470,2535,2919,196,2918,2919,2919,2666,2666,2275,3171,716,908,3171,3171,2926,2926,2535,3431,716,2926,3431,3431,3186,3186,2275,2659,1236,1428,2659,2659,3446,3446,2535,2919,1236,3446,2919,2919,3706,3706,2275,3770,1756,1948,1948,1948,3966,3966,2535,4030,1756,3966,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s3], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M119
