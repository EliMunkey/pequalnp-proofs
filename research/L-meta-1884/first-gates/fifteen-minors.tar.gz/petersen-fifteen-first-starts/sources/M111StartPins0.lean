import M111StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 64) : Fin 64 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63] : Array (Fin 64))[x.val]?.getD 0
theorem small0 : NoAtMost i6 (PetersenPackedPin.project r0 tgt) 6 := by
  have a : PetersenPackedPin.project r0 tgt = table 111 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 111 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 16) : Fin 64 := (#[0,2,4,6,8,10,12,14,32,34,36,38,40,42,44,46] : Array (Fin 64))[x.val]?.getD 0
theorem small1 : NoAtMost i4 (PetersenPackedPin.project r1 tgt) 3 := by
  have a : PetersenPackedPin.project r1 tgt = table 78 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 78 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r2 (x : Fin 16) : Fin 64 := (#[16,18,20,22,24,26,28,30,48,50,52,54,56,58,60,62] : Array (Fin 64))[x.val]?.getD 0
theorem small2 : NoAtMost i4 (PetersenPackedPin.project r2 tgt) 3 := by
  have a : PetersenPackedPin.project r2 tgt = table 78 32 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 78 32 (by decide +kernel) (by decide +kernel)
theorem hot2 : forcedConst r2 tgt = false := by decide +kernel
def r3 (x : Fin 16) : Fin 64 := (#[0,1,2,3,16,17,18,19,32,33,34,35,48,49,50,51] : Array (Fin 64))[x.val]?.getD 0
theorem small3 : NoAtMost i4 (PetersenPackedPin.project r3 tgt) 3 := by
  have a : PetersenPackedPin.project r3 tgt = table 99 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 99 0 (by decide +kernel) (by decide +kernel)
theorem hot3 : forcedConst r3 tgt = false := by decide +kernel
def r4 (x : Fin 16) : Fin 64 := (#[8,9,10,11,24,25,26,27,40,41,42,43,56,57,58,59] : Array (Fin 64))[x.val]?.getD 0
theorem small4 : NoAtMost i4 (PetersenPackedPin.project r4 tgt) 3 := by
  have a : PetersenPackedPin.project r4 tgt = table 99 8 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 99 8 (by decide +kernel) (by decide +kernel)
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
def r5 (x : Fin 16) : Fin 64 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23] : Array (Fin 64))[x.val]?.getD 0
theorem small5 : NoAtMost i4 (PetersenPackedPin.project r5 tgt) 3 := by
  have a : PetersenPackedPin.project r5 tgt = table 39 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 39 0 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
def r8 (x : Fin 16) : Fin 64 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15] : Array (Fin 64))[x.val]?.getD 0
theorem small8 : NoAtMost i4 (PetersenPackedPin.project r8 tgt) 3 := by
  have a : PetersenPackedPin.project r8 tgt = table 15 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 15 0 (by decide +kernel) (by decide +kernel)
theorem hot8 : forcedConst r8 tgt = false := by decide +kernel
end PetersenSmallStarts.M111
