import M127StartData
import M127StartPins0
import M127StartL6B13
import M127StartL6B7
import M127StartL6B4
import M127StartL6B14
import M127StartL6B8
import M127StartL6B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b370 : Blocked tgt 7 s370 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s370 7 _ le
  decide +kernel
theorem b371 : Blocked tgt 7 s371 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s371 7 _ le
  decide +kernel
theorem b372 : Blocked tgt 7 s372 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s372 7 _ le
  decide +kernel
theorem b373 : Blocked tgt 7 s373 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s373 7 _ le
  decide +kernel
theorem b374 : Blocked tgt 7 s374 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s374 7 _ le
  decide +kernel
theorem b375 : Blocked tgt 7 s375 := by
  apply PetersenFastNode.node (nxt := #[s376,s377,s218,s110,s378,s379,s380,s381,s382,s383,s384,s385,s386,s387]) (hints := [15106,15106,15234,9043,1464,0,11266,1464,15234,11266,15106,1,1464,1464,5944,9815,15106,9943,1976,15106,5944,1464,1464,9943,2496,2496,7488,440,1464,9939,3520,1464,7488,2496,2496,9939,1464,1464,7480,448,2496,10963,3512,2496,7480,1464,1464,10963,10978,10978,2,1464,1464,13011,1432,1464,3,1432,10978,13011,1464,1464,13624,6914,15106,4,9656,15106,13624,1464,1464,5,9943,13686,9943,5688,15234,5944,9943,15234,9943,13686,13686,5944,9939,15234,9939,7232,13686,7488,9939,13686,9939,15234,15234,7488,10963,13170,10963,13186,15234,7480,10963,15234,10963,13170,13170,7480,13011,11106,13011,11138,15234,6,9171,15234,13011,9171,11106,7,6978,6978,8,7042,15234,13624,15170,15234,9,6978,6978,13624,6976,6976,7488,9939,9943,9939,9935,9943,7488,9935,6976,9939,9943,9943,11479,10451,6976,10963,11479,6976,11479,9943,9943,10963,9943,9943,13527,12499,5944,13011,13527,5944,13527,9943,9943,13011,1687,1687,13624,1751,9943,10,9879,9943,13624,1687,1687,11,9939,9939,10963,10455,7488,11479,10963,7488,10963,9939,9939,11479,9939,9939,13011,12503,7488,13527,13011,7488,13011,9939,9939,13527,1683,1683,14656,1747,9939,13624,9875,9939,14656,1683,1683,13624,10963,10963,13011,3384,7480,12,13011,7480,13011,10963,10963,13,2707,2707,13624,2771,10963,14656,10899,10963,13624,2707,2707,14656,4755,4755,9496,4819,13011,13624,12947,13011,9496,4755,4755,13624]) (by decide +kernel)
  change ∀ b ∈ [s376,s377,s218,s110,s378,s379,s380,s381,s382,s383,s384,s385,s386,s387], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s376) b376 <|
    PetersenLocalChildren.push (x := s377) b377 <|
    PetersenLocalChildren.push (x := s218) b218 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s378) b378 <|
    PetersenLocalChildren.push (x := s379) b379 <|
    PetersenLocalChildren.push (x := s380) b380 <|
    PetersenLocalChildren.push (x := s381) b381 <|
    PetersenLocalChildren.push (x := s382) b382 <|
    PetersenLocalChildren.push (x := s383) b383 <|
    PetersenLocalChildren.push (x := s384) b384 <|
    PetersenLocalChildren.push (x := s385) b385 <|
    PetersenLocalChildren.push (x := s386) b386 <|
    PetersenLocalChildren.push (x := s387) b387 <|
    PetersenLocalChildren.nil
theorem b388 : Blocked tgt 7 s388 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s388 7 _ le
  decide +kernel
theorem b389 : Blocked tgt 7 s389 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s389 7 _ le
  decide +kernel
theorem b390 : Blocked tgt 7 s390 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s390 7 _ le
  decide +kernel
theorem b391 : Blocked tgt 7 s391 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s391 7 _ le
  decide +kernel
theorem b392 : Blocked tgt 7 s392 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s392 7 _ le
  decide +kernel
theorem b393 : Blocked tgt 7 s393 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s393 7 _ le
  decide +kernel
theorem b394 : Blocked tgt 7 s394 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s394 7 _ le
  decide +kernel
theorem b395 : Blocked tgt 7 s395 := by
  apply PetersenFastNode.node (nxt := #[s396,s397,s398,s399,s242,s243,s400,s401,s402,s71,s403,s404,s405,s406]) (hints := [15106,15106,15234,979,0,979,7170,1,15234,7170,15106,979,5944,13558,5944,9815,15106,9943,5944,15106,5944,13558,13558,9943,7488,15106,7488,9811,13558,9939,7488,13558,7488,15106,15106,9939,7480,13042,7480,13058,15106,10963,7480,15106,7480,13042,13042,10963,10978,10978,2,11010,15106,13011,15074,15106,3,10978,10978,13011,13624,6850,13624,6914,15106,4,5560,15106,13624,5560,6850,5,1495,1495,9943,467,979,5944,2007,979,9943,1495,1495,5944,979,979,9939,471,1495,7488,2003,1495,9939,979,979,7488,979,979,10963,13186,15234,7480,3027,15234,10963,979,979,7480,979,979,13011,11138,15234,6,5075,15234,13011,979,979,7,6978,6978,8,979,979,13624,915,979,9,915,6978,13624,6976,6976,7488,9939,9943,9939,9935,9943,7488,9935,6976,9939,9943,9943,11479,10451,6976,10963,11479,6976,11479,9943,9943,10963,9943,9943,13527,12499,5944,13011,13527,5944,13527,9943,9943,13011,1687,1687,13624,1751,9943,10,9879,9943,13624,1687,1687,11,9939,9939,10963,10455,7488,11479,10963,7488,10963,9939,9939,11479,9939,9939,13011,12503,7488,13527,13011,7488,13011,9939,9939,13527,1683,1683,14656,1747,9939,13624,9875,9939,14656,1683,1683,13624,10963,10963,13011,3384,7480,12,13011,7480,13011,10963,10963,13,2707,2707,13624,2771,10963,14656,10899,10963,13624,2707,2707,14656,4755,4755,9496,4819,13011,13624,12947,13011,9496,4755,4755,13624]) (by decide +kernel)
  change ∀ b ∈ [s396,s397,s398,s399,s242,s243,s400,s401,s402,s71,s403,s404,s405,s406], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s396) b396 <|
    PetersenLocalChildren.push (x := s397) b397 <|
    PetersenLocalChildren.push (x := s398) b398 <|
    PetersenLocalChildren.push (x := s399) b399 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s400) b400 <|
    PetersenLocalChildren.push (x := s401) b401 <|
    PetersenLocalChildren.push (x := s402) b402 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.push (x := s403) b403 <|
    PetersenLocalChildren.push (x := s404) b404 <|
    PetersenLocalChildren.push (x := s405) b405 <|
    PetersenLocalChildren.push (x := s406) b406 <|
    PetersenLocalChildren.nil
theorem b407 : Blocked tgt 7 s407 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s407 7 _ le
  decide +kernel
theorem b408 : Blocked tgt 7 s408 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s408 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
