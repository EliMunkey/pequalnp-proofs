import M47StartData
import M47StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b16 : Blocked tgt 4 s16 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s16 4 _ le
  decide +kernel
theorem b17 : Blocked tgt 4 s17 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s17 4 _ le
  decide +kernel
theorem b18 : Blocked tgt 4 s18 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s18 4 _ le
  decide +kernel
theorem b19 : Blocked tgt 4 s19 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s19 4 _ le
  decide +kernel
theorem b20 : Blocked tgt 4 s20 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s20 4 _ le
  decide +kernel
theorem b21 : Blocked tgt 4 s21 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s21 4 _ le
  decide +kernel
theorem b22 : Blocked tgt 4 s22 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s22 4 _ le
  decide +kernel
theorem b23 : Blocked tgt 4 s23 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s23 4 _ le
  decide +kernel
theorem b24 : Blocked tgt 4 s24 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s24 4 _ le
  decide +kernel
end PetersenSmallStarts.M47
