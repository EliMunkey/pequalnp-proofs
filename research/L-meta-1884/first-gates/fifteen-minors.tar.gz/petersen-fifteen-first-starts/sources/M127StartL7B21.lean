import M127StartData
import M127StartPins0
import M127StartL6B21
import M127StartL6B22
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b737 : Blocked tgt 7 s737 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s737 7 _ le
  decide +kernel
theorem b738 : Blocked tgt 7 s738 := by
  apply PetersenFastNode.node (nxt := #[s693,s739]) (hints := [1420,1420,11126,9578,11126,9578,9931,1804,9931,1804,9927,3348,10951,3340,10951,3340,12999,0,12999,1,10516,9484,10516,9484,9578,2452,9578,11254,1804,9931,1804,2452,2452,9927,3476,3340,404,3340,388,10966,2452,2452,10966,9484,6902,9484,2452,9578,1804,10090,9578,9927,9578,9578,11126,9578,3340,11626,9578,9546,9546,2870,9484,9514,9484,2836,1804,1804,9923,1804,10439,3340,1804,9802,1804,1804,9802,1804,5738,9484,1804,9927,3340,10951,3340,9927,12491,12999,9927,1671,9484,9863,9484,11338,3340,3340,11338,3340,7274,9484,3340,4743,9484,12935,9484]) (by decide +kernel)
  change ∀ b ∈ [s693,s739], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s693) b693 <|
    PetersenLocalChildren.push (x := s739) b739 <|
    PetersenLocalChildren.nil
theorem b740 : Blocked tgt 7 s740 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s740 7 _ le
  decide +kernel
theorem b741 : Blocked tgt 7 s741 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s741 7 _ le
  decide +kernel
theorem b742 : Blocked tgt 7 s742 := by
  apply PetersenFastNode.node (nxt := #[s713,s743]) (hints := [14644,13612,13612,14644,13612,6580,6838,13612,13610,903,13612,5932,5674,5932,1671,13612,13612,14644,13612,7468,7210,7468,9484,13580,9516,9484,5548,5548,9095,13610,9095,13610,6964,5932,6964,5932,7476,7476,2695,7468,2695,7468,4743,0,4743,1,13610,6580,6580,6838,5932,1675,5932,6580,6580,1671,7604,7468,4532,7468,4516,2452,2484,6548,2452,5674,5932,5674,5932,1671,13610,13610,9095,7210,7468,7210,7468,9482,9514,13578,9482,6964,5932,5932,6964,5932,4916,7468,5932,1804,1836,5900,1804,1671,7468,2695,7468,1671,4235,4743,1671,3340,3372,7436,3340]) (by decide +kernel)
  change ∀ b ∈ [s713,s743], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s713) b713 <|
    PetersenLocalChildren.push (x := s743) b743 <|
    PetersenLocalChildren.nil
theorem b744 : Blocked tgt 7 s744 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s744 7 _ le
  decide +kernel
theorem b745 : Blocked tgt 7 s745 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s745 7 _ le
  decide +kernel
theorem b746 : Blocked tgt 7 s746 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s746 7 _ le
  decide +kernel
theorem b747 : Blocked tgt 7 s747 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s747 7 _ le
  decide +kernel
theorem b748 : Blocked tgt 7 s748 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s748 7 _ le
  decide +kernel
theorem b749 : Blocked tgt 7 s749 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s749 7 _ le
  decide +kernel
theorem b750 : Blocked tgt 7 s750 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s750 7 _ le
  decide +kernel
theorem b751 : Blocked tgt 7 s751 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s751 7 _ le
  decide +kernel
theorem b752 : Blocked tgt 7 s752 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s752 7 _ le
  decide +kernel
theorem b753 : Blocked tgt 7 s753 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s753 7 _ le
  decide +kernel
theorem b755 : Blocked tgt 7 s755 := by
  apply PetersenFastNode.node (nxt := #[s756,s757,s758]) (hints := [5293,5293,5549,9676,15095,5549,5549,15095,5549,9932,5933,5549,6581,4525,7477,6581,5549,4533,7469,5549,1421,1453,5517,1421,5549,6903,13613,5549,9160,9160,9676,5933,9932,9676,8652,8652,9676,7477,9676,7469,11468,9676,9676,0,13516,9676,1420,1484,9612,1420,13931,9932,13931,9932,15991,7477,9928,9928,10952,11468,10952,11468,13000,13516,13000,13516,1,13613,2,13613,6965,9932,9932,6965,9932,10440,11468,9932,9932,12488,13516,9932,1676,1740,9868,1676,10952,11468,10952,11468,13000,13516,13000,13516,7477,12589,14645,7477,11468,3373,13516,11468,3212,3276,11404,3212,5260,5324,13452,5260]) (by decide +kernel)
  change ∀ b ∈ [s756,s757,s758], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s756) b756 <|
    PetersenLocalChildren.push (x := s757) b757 <|
    PetersenLocalChildren.push (x := s758) b758 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
