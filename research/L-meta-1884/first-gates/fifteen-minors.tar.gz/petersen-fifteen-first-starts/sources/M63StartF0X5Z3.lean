import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_3 : NoAtMost (0xaaaaaaaa00000000 :: inputs 6) tgt 7 := by
  change NoAtMost [0xaaaaaaaa00000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s640,s0,s641] [195,195,196,196,197,197,836,836,391,391,456,456,197,197,840,840,715,715,716,716,717,717,844,844,391,391,456,456,717,717,1352,1352,1107,1107,196,196,1237,1237,836,836,1367,1367,456,456,1237,1237,840,840,715,715,716,716,717,717,844,844,1367,1367,456,456,717,717,2376,0,2147,2467,196,196,2277,2469,836,836,2407,2471,456,456,2277,3749,840,840,2667,2859,716,716,2797,2989,844,844,2407,2471,456,456,2797,3757,1352,1352,3187,3507,196,196,3317,3509,836,836,3447,3511,456,456,3317,3765,840,840,2667,2859,716,716,2797,2989,844,844,3447,3511,456,456,2797,717,1,2] (by decide +kernel)
  change ∀ b ∈ [s640,s0,s641], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s640) b640 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s641) b641 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_3
end PetersenSmallStarts.M63
