import M127StartData
import M127StartPins0
import M127StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1016 : Blocked tgt 6 s1016 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [773,773,1418,901,6804,1418,1418,2708,1418,1737,1608,1418,2450,394,3346,2450,1418,402,3338,1418,1418,6804,9482,1418,901,2836,1737,901,1737,1993,901,8649,1669,901,901,3338,2693,901,1417,901,901,1417,5833,1737,4741,1737,4741,1669,12489,1669,4741,2693,11336,2693,5257,4741,4741,5257,3346,1669,1729,1669,1737,2693,3785,1737,1673,1673,1669,10441,2693,1669,3346,1669,1669,3346,3209,2693,2693,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1017 : Blocked tgt 6 s1017 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1017 6 _ le
  decide +kernel
theorem b1019 : Blocked tgt 6 s1019 := by
  apply PetersenFastNode.node (nxt := #[s1020]) (hints := [8966,902,5515,902,15061,5515,5515,2773,1803,1674,1803,5515,3347,4491,3347,6547,3339,4499,3339,5515,5515,6869,1419,1419,902,11093,1418,390,1674,1418,902,394,1670,902,902,3339,2694,902,4998,902,902,9483,13450,1674,12422,1674,12934,1670,12426,1670,12934,2694,11337,2694,0,12934,4742,4742,2835,1670,1666,1666,1674,2182,3210,1674,1803,1674,1674,1803,1670,2186,2694,1670,3347,1670,1670,3347,3339,2694,2694,3339]) (by decide +kernel)
  change ∀ b ∈ [s1020], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1020) b1020 <|
    PetersenLocalChildren.nil
theorem b1021 : Blocked tgt 6 s1021 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1021 6 _ le
  decide +kernel
theorem b1022 : Blocked tgt 6 s1022 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1022 6 _ le
  decide +kernel
theorem b1023 : Blocked tgt 6 s1023 := by
  apply PetersenFastNode.node (nxt := #[s1024]) (hints := [4806,0,4742,4742,9483,5515,6805,5515,9094,902,966,902,9866,1674,1738,1674,9862,1670,1734,1670,10886,2694,2758,2694,1419,1419,4998,902,11029,902,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,6805,902,5515,902,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,1418,390,1674,1418,902,394,1670,902,902,3339,2694,902,2835,1670,1666,1666,1674,2182,3210,1674,1670,2186,2694,1670]) (by decide +kernel)
  change ∀ b ∈ [s1024], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1024) b1024 <|
    PetersenLocalChildren.nil
theorem b1027 : Blocked tgt 6 s1027 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1027 6 _ le
  decide +kernel
theorem b1028 : Blocked tgt 6 s1028 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1028 6 _ le
  decide +kernel
theorem b1029 : Blocked tgt 6 s1029 := by
  apply PetersenFastNode.node (nxt := #[s1024]) (hints := [4742,0,9483,5515,6805,5515,902,2837,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,5515,2709,4742,902,11029,902,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,6805,5515,5515,902,1803,1674,1803,5515,3347,4491,3347,6547,3339,4499,3339,5515,1418,1803,1674,1803,902,3347,1670,3347,902,3339,2694,3339,2835,779,3347,2835,1803,787,3339,1803,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s1024], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1024) b1024 <|
    PetersenLocalChildren.nil
theorem b1032 : Blocked tgt 6 s1032 := by
  apply PetersenFastNode.node (nxt := #[s1033]) (hints := [5515,2709,4742,902,2837,902,5770,1674,4742,1674,4742,1670,12426,1670,4742,2694,3339,2694,4742,5258,2837,902,2837,902,5515,1674,1609,1674,3347,1670,3347,1670,3339,2694,3339,2694,5515,6805,9483,5515,1418,390,1674,1418,902,394,1670,902,902,789,2694,902,0,902,902,9481,3347,1670,1666,1666,1674,2182,3210,1674,1674,1803,1670,2186,2694,1670,3347,1670,1670,3347,3339,2694,2694,3339]) (by decide +kernel)
  change ∀ b ∈ [s1033], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1033) b1033 <|
    PetersenLocalChildren.nil
theorem b1034 : Blocked tgt 6 s1034 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1034 6 _ le
  decide +kernel
theorem b1039 : Blocked tgt 6 s1039 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1039 6 _ le
  decide +kernel
theorem b1040 : Blocked tgt 6 s1040 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3338,10949,12997,10949,1418,1418,13513,9157,9544,9157,13513,9929,1802,9929,14021,9925,13513,9925,5257,13449,5321,5257,3338,10949,10949,3338,10949,9157,9028,9157,11465,9929,10437,9929,10949,9925,10441,9925,2693,10885,2757,2693,9544,9157,9544,9157,1802,9929,1802,9929,3330,9925,5514,9925,5514,5320,9482,5514,9673,8645,9929,9673,9157,8649,9925,9157,901,965,9093,901,770,9925,9921,9921,1673,1737,9865,1673,1669,1733,9861,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1045 : Blocked tgt 6 s1045 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1045 6 _ le
  decide +kernel
theorem b1046 : Blocked tgt 6 s1046 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1046 6 _ le
  decide +kernel
theorem b1047 : Blocked tgt 6 s1047 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1047 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
