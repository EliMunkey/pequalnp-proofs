import M189StartData
import M189StartPins0
import M189StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 6 s2 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s2 6 _ le
  decide +kernel
theorem b3 : Blocked tgt 6 s3 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s3 6 _ le
  decide +kernel
theorem b4 : Blocked tgt 6 s4 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s4 6 _ le
  decide +kernel
theorem b5 : Blocked tgt 6 s5 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s5 6 _ le
  decide +kernel
theorem b6 : Blocked tgt 6 s6 := by
  intro k le c
  apply rejects_sound r0 i6 7 tgt small0 hot0 [] s6 6 _ le
  decide +kernel
theorem b7 : Blocked tgt 6 s7 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s7 6 _ le
  decide +kernel
theorem b8 : Blocked tgt 6 s8 := by
  apply PetersenFastNode.node (nxt := #[s9]) (hints := [1365,1429,2274,2278,2466,2274,1627,2470,2470,1755,2470,580,2918,2470,2470,1092,3430,2470,390,422,2438,390,1109,388,1365,388,0,1755,1365,1755,1365,708,1813,708,3365,1220,3365,1220,1365,2244,3349,2244,1755,1947,388,2662,708,388,388,3174,1220,388,388,3349,2244,388,1235,1243,1747,1235,715,731,1739,715,1755,2180,3739,1755,708,789,1220,708,708,3227,2244,708,1220,2715,2244,1220]) (by decide +kernel)
  change ∀ b ∈ [s9], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.nil
theorem b10 : Blocked tgt 6 s10 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,1626,2469,2273,1754,1624,1754,387,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2273,1428,2273,1882,2469,2273,2273,579,2657,2273,2273,1091,3169,2273,389,2243,2241,2241,1816,1946,1816,1946,1364,707,1812,707,3364,1219,3364,1219,1364,2243,3348,2243,707,1434,707,1426,1219,922,1219,906,2243,808,2243,1946,707,788,1219,707,707,609,2243,707,1219,1121,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b11 : Blocked tgt 6 s11 := by
  apply PetersenFastNode.node (nxt := #[s12]) (hints := [1429,1429,2210,1947,2466,1947,2470,580,2918,2470,2470,1092,3430,2470,454,486,2438,454,390,2470,2470,1755,1817,1947,1817,1947,1813,708,1813,708,3365,1220,3365,1220,617,2180,2665,2180,0,1755,1365,1755,1427,1435,1939,1427,907,923,1931,907,1947,2857,2180,1947,1755,388,1755,1947,708,789,1220,708,708,870,2180,708,1235,1243,1235,1747,1220,1382,2180,1220,715,731,715,1739,1755,3739]) (by decide +kernel)
  change ∀ b ∈ [s12], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.nil
theorem b13 : Blocked tgt 6 s13 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,389,2469,453,1754,1364,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,453,1428,2209,451,449,449,453,579,837,453,453,1091,1349,453,453,421,2469,453,1816,451,1816,451,1812,707,1812,707,3364,1219,3364,1219,3348,3738,3348,3738,451,581,707,451,451,1093,1219,451,451,808,3738,451,707,788,1219,707,707,3226,3218,707,1219,2714,2698,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b14 : Blocked tgt 6 s14 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s14 6 _ le
  decide +kernel
theorem b15 : Blocked tgt 6 s15 := by
  apply PetersenFastNode.node (nxt := #[s16]) (hints := [1365,1365,1627,388,1883,1627,1235,1243,1619,1235,2470,2470,1627,2534,587,3430,1611,3430,1627,2180,3675,1627,1817,452,1817,452,2217,580,2729,580,0,2534,1429,2534,3365,3430,3365,3430,3349,2244,3349,2244,452,1435,580,452,2274,2278,2274,2530,452,3174,1220,452,452,809,2244,452,2534,2918,3430,3625,3430,580,580,3227,2244,580,2534,1092,3430,2534,454,486,2502,454,1350,1382,3398,1350]) (by decide +kernel)
  change ∀ b ∈ [s16], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.nil
theorem b17 : Blocked tgt 6 s17 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,2469,2533,1234,2533,1428,2273,2277,2529,2273,2533,579,2533,1091,3429,2533,453,485,2501,453,1234,1364,1234,387,1426,1234,1234,2917,1626,1234,586,1219,1218,1218,1234,2179,3218,1234,1816,451,1816,451,1812,2917,1812,2917,3364,1219,3364,1219,3348,2243,3348,2243,451,2661,2657,451,451,402,1219,451,451,808,2243,451,1219,788,1219,2917,2243,869,2243,837,1219,2194,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b18 : Blocked tgt 6 s18 := by
  apply PetersenFastNode.node (nxt := #[s19]) (hints := [1365,1365,1627,388,1883,1627,1107,2918,1619,2918,715,731,1611,715,2470,2470,1627,2534,1627,2180,3675,1627,1817,452,1817,452,1429,2918,1813,2918,405,1092,1429,1092,0,2534,1429,2534,1429,2244,3349,2244,452,2662,708,452,452,923,1092,452,2274,2278,2274,2530,452,809,2244,452,2918,1813,1092,2918,2534,580,2534,2918,838,870,2886,838,2534,3430,1092,2715,2244,1092,454,486,2502,454]) (by decide +kernel)
  change ∀ b ∈ [s19], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.nil
theorem b20 : Blocked tgt 6 s20 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,2469,2533,714,2533,2468,2273,2277,2529,2273,2533,579,2917,2533,2533,1091,453,485,2501,453,714,1364,714,387,906,714,1106,707,706,706,714,3429,1626,714,714,2179,2698,714,1816,451,1816,451,1428,707,1812,707,3364,3429,3364,3429,1428,2243,3348,2243,451,394,707,451,451,3173,3169,451,451,808,2243,451,707,788,3429,707,707,2186,2243,707,2243,1381,2243,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b21 : Blocked tgt 6 s21 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s21 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
