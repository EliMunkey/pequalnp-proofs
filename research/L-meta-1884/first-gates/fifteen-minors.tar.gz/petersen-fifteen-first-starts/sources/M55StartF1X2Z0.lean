import M55StartData
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_0 : NoAtMost (0xfcfcfcfc :: inputs 5) tgt 4 := by
  change NoAtMost [0xfcfcfcfc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s17] [98,100,99,103,100,100,291,423,198,198,231,231,100,100,423,423,298,364,99,103,364,364,547,679,430,430,231,231,364,364,679,679,562,628,99,103,628,628,291,423,694,694,231,231,628,628,423,423,826,892,99,103,892,892,988,988,958,958,231,231,892,892,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s17], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_0
end PetersenSmallStarts.M55
