import M127StartData
import M127StartPins0
import M127StartL6B27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1197 : Blocked tgt 7 s1197 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1197 7 _ le
  decide +kernel
theorem b1198 : Blocked tgt 7 s1198 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1418,1418,12997,9157,11092,9157,13513,9929,12485,9929,12997,13513,13513,12997,12997,11465,3338,12997,12997,13513,13513,12997,4741,12933,4805,4741,11092,9157,11092,9157,1802,9929,1802,9929,3346,5514,3346,6546,3338,11465,3338,11465,4482,5514,5514,4482,5514,6868,9482,5514,9673,8645,9929,9673,9157,9673,9673,9157,9157,11092,11465,9157,9157,9673,9673,9157,901,965,9093,901,2834,9929,9929,2834,9929,2834,11465,9929,770,9929,9929,770,1673,1737,9865,1673,10441,3346,11465,9925,9925,3346,9482,10514,3346,10949,10949,3209,3273,11401,3209,8450,9482,8450,9482]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1199 : Blocked tgt 7 s1199 := by
  apply PetersenFastNode.node (nxt := #[s937]) (hints := [12998,13514,13514,12998,1419,1419,13514,9674,9545,9674,13514,9930,1803,9930,12998,13514,13514,12998,13514,10950,0,13514,5258,13450,5322,5258,6547,5515,6547,5515,9158,9674,9158,9674,2835,9930,2835,9930,9926,9926,10950,11466,10515,9483,10515,9483,9545,9674,9545,9674,1803,9930,1803,9930,3347,5515,5515,6547,5515,10950,6531,10950,5515,5321,9483,5515,9674,8646,9930,9674,9158,9674,9674,9158,9674,9045,10950,9674,1418,1482,9610,1418,2835,9930,9930,2835,9930,10438,10434,9930,1674,1738,9866,1674,10950,3347,11974,3347,9483,10515,9483,2694,2758,10886,2694]) (by decide +kernel)
  change ∀ b ∈ [s937], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s937) b937 <|
    PetersenLocalChildren.nil
theorem b1200 : Blocked tgt 7 s1200 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1200 7 _ le
  decide +kernel
theorem b1201 : Blocked tgt 7 s1201 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1201 7 _ le
  decide +kernel
theorem b1202 : Blocked tgt 7 s1202 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1202 7 _ le
  decide +kernel
theorem b1203 : Blocked tgt 7 s1203 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1203 7 _ le
  decide +kernel
theorem b1204 : Blocked tgt 7 s1204 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1204 7 _ le
  decide +kernel
theorem b1205 : Blocked tgt 7 s1205 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1205 7 _ le
  decide +kernel
theorem b1206 : Blocked tgt 7 s1206 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1206 7 _ le
  decide +kernel
theorem b1207 : Blocked tgt 7 s1207 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1207 7 _ le
  decide +kernel
theorem b1208 : Blocked tgt 7 s1208 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1208 7 _ le
  decide +kernel
theorem b1218 : Blocked tgt 7 s1218 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1218 7 _ le
  decide +kernel
theorem b1219 : Blocked tgt 7 s1219 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1219 7 _ le
  decide +kernel
theorem b1220 : Blocked tgt 7 s1220 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1220 7 _ le
  decide +kernel
theorem b1221 : Blocked tgt 7 s1221 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6900,901,7156,6900,5930,1673,5930,5352,6900,1669,7924,6900,6384,6900,6900,6384,7466,4852,7466,4836,2772,2804,6868,2772,5546,5546,1417,901,1673,1417,901,1417,1669,901,385,901,901,385,901,13172,2693,901,901,11124,4741,901,6964,901,901,6964,4906,1673,1669,1673,6962,1673,2693,3209,1673,1673,4741,5257,1673,5930,1673,1673,5930,1669,7474,1669,3209,2693,1669,1669,5257,4741,1669,14642,1669,1669,13610,2177,2693,2177,2693,4225,4741,4225,4741,14642,13610,14642,13610,2693,3370,4741,2693,7466,2693,2693,7466,9482,4741,4741,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
