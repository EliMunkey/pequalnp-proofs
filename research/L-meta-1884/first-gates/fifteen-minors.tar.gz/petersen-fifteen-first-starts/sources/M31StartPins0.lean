import M31StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 32) : Fin 32 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 32))[x.val]?.getD 0
theorem small0 : NoAtMost i5 (PetersenPackedPin.project r0 tgt) 6 := by
  have a : PetersenPackedPin.project r0 tgt = table 31 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 31 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 16) : Fin 32 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30] : Array (Fin 32))[x.val]?.getD 0
theorem small1 : NoAtMost i4 (PetersenPackedPin.project r1 tgt) 3 := by
  have a : PetersenPackedPin.project r1 tgt = table 30 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 30 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r2 (x : Fin 16) : Fin 32 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29] : Array (Fin 32))[x.val]?.getD 0
theorem small2 : NoAtMost i4 (PetersenPackedPin.project r2 tgt) 3 := by
  have a : PetersenPackedPin.project r2 tgt = table 29 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 29 0 (by decide +kernel) (by decide +kernel)
theorem hot2 : forcedConst r2 tgt = false := by decide +kernel
def r3 (x : Fin 16) : Fin 32 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27] : Array (Fin 32))[x.val]?.getD 0
theorem small3 : NoAtMost i4 (PetersenPackedPin.project r3 tgt) 3 := by
  have a : PetersenPackedPin.project r3 tgt = table 27 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 27 0 (by decide +kernel) (by decide +kernel)
theorem hot3 : forcedConst r3 tgt = false := by decide +kernel
def r4 (x : Fin 16) : Fin 32 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23] : Array (Fin 32))[x.val]?.getD 0
theorem small4 : NoAtMost i4 (PetersenPackedPin.project r4 tgt) 3 := by
  have a : PetersenPackedPin.project r4 tgt = table 23 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 23 0 (by decide +kernel) (by decide +kernel)
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
def r5 (x : Fin 16) : Fin 32 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15] : Array (Fin 32))[x.val]?.getD 0
theorem small5 : NoAtMost i4 (PetersenPackedPin.project r5 tgt) 3 := by
  have a : PetersenPackedPin.project r5 tgt = table 15 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 15 0 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
end PetersenSmallStarts.M31
