import M251StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 128) : Fin 128 := (#[0,1,8,9,32,33,40,41,2,3,10,11,34,35,42,43,16,17,24,25,48,49,56,57,18,19,26,27,50,51,58,59,4,5,12,13,36,37,44,45,6,7,14,15,38,39,46,47,20,21,28,29,52,53,60,61,22,23,30,31,54,55,62,63,64,65,72,73,96,97,104,105,66,67,74,75,98,99,106,107,80,81,88,89,112,113,120,121,82,83,90,91,114,115,122,123,68,69,76,77,100,101,108,109,70,71,78,79,102,103,110,111,84,85,92,93,116,117,124,125,86,87,94,95,118,119,126,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover0 : i7.all (fun q => i7.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
private def a1 (x : Fin 128) : Fin 128 := (#[0,1,16,17,32,33,48,49,2,3,18,19,34,35,50,51,8,9,24,25,40,41,56,57,10,11,26,27,42,43,58,59,64,65,80,81,96,97,112,113,66,67,82,83,98,99,114,115,72,73,88,89,104,105,120,121,74,75,90,91,106,107,122,123,4,5,20,21,36,37,52,53,6,7,22,23,38,39,54,55,12,13,28,29,44,45,60,61,14,15,30,31,46,47,62,63,68,69,84,85,100,101,116,117,70,71,86,87,102,103,118,119,76,77,92,93,108,109,124,125,78,79,94,95,110,111,126,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover1 : i7.all (fun q => i7.contains (PetersenPackedPin.project a1 q)) = true := by decide +kernel
private theorem same1 : PetersenPackedPin.project a1 tgt=tgt := by decide +kernel
private def a2 (x : Fin 128) : Fin 128 := (#[0,1,2,3,64,65,66,67,16,17,18,19,80,81,82,83,8,9,10,11,72,73,74,75,24,25,26,27,88,89,90,91,32,33,34,35,96,97,98,99,48,49,50,51,112,113,114,115,40,41,42,43,104,105,106,107,56,57,58,59,120,121,122,123,4,5,6,7,68,69,70,71,20,21,22,23,84,85,86,87,12,13,14,15,76,77,78,79,28,29,30,31,92,93,94,95,36,37,38,39,100,101,102,103,52,53,54,55,116,117,118,119,44,45,46,47,108,109,110,111,60,61,62,63,124,125,126,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover2 : i7.all (fun q => i7.contains (PetersenPackedPin.project a2 q)) = true := by decide +kernel
private theorem same2 : PetersenPackedPin.project a2 tgt=tgt := by decide +kernel
private def a3 (x : Fin 128) : Fin 128 := (#[0,1,16,17,4,5,20,21,8,9,24,25,12,13,28,29,2,3,18,19,6,7,22,23,10,11,26,27,14,15,30,31,64,65,80,81,68,69,84,85,72,73,88,89,76,77,92,93,66,67,82,83,70,71,86,87,74,75,90,91,78,79,94,95,32,33,48,49,36,37,52,53,40,41,56,57,44,45,60,61,34,35,50,51,38,39,54,55,42,43,58,59,46,47,62,63,96,97,112,113,100,101,116,117,104,105,120,121,108,109,124,125,98,99,114,115,102,103,118,119,106,107,122,123,110,111,126,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover3 : i7.all (fun q => i7.contains (PetersenPackedPin.project a3 q)) = true := by decide +kernel
private theorem same3 : PetersenPackedPin.project a3 tgt=tgt := by decide +kernel
private def a4 (x : Fin 128) : Fin 128 := (#[0,1,8,9,64,65,72,73,16,17,24,25,80,81,88,89,2,3,10,11,66,67,74,75,18,19,26,27,82,83,90,91,4,5,12,13,68,69,76,77,20,21,28,29,84,85,92,93,6,7,14,15,70,71,78,79,22,23,30,31,86,87,94,95,32,33,40,41,96,97,104,105,48,49,56,57,112,113,120,121,34,35,42,43,98,99,106,107,50,51,58,59,114,115,122,123,36,37,44,45,100,101,108,109,52,53,60,61,116,117,124,125,38,39,46,47,102,103,110,111,54,55,62,63,118,119,126,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover4 : i7.all (fun q => i7.contains (PetersenPackedPin.project a4 q)) = true := by decide +kernel
private theorem same4 : PetersenPackedPin.project a4 tgt=tgt := by decide +kernel
theorem labeled_0_3_0 : NoAtMost (0xffaaffaaffaaffaaffaaffaaffaaffaa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffaaffaaffaaffaaffaaffaaffaaffaa) (a:=0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_3_1 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xaa00aa00aa00aa00aa00aa00aa00aa) (a:=0x22222222222222222222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_3_2 : NoAtMost (0x55005500550055005500550055005500 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x55005500550055005500550055005500) (a:=0x44444444444444444444444444444444) (by decide +kernel) gate_0_1_2
theorem labeled_0_3_3 : NoAtMost (0xaa00aa00aa00aa00aa00aa00aa00aa00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (a:=0x88888888888888888888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_0_4_0 : NoAtMost (0xffffaaaaffffaaaaffffaaaaffffaaaa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (a:=0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_4_1 : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xaaaa0000aaaa0000aaaa0000aaaa) (a:=0x22222222222222222222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_4_2 : NoAtMost (0x55550000555500005555000055550000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0x55550000555500005555000055550000) (a:=0x44444444444444444444444444444444) (by decide +kernel) gate_0_1_2
theorem labeled_0_4_3 : NoAtMost (0xaaaa0000aaaa0000aaaa0000aaaa0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xaaaa0000aaaa0000aaaa0000aaaa0000) (a:=0x88888888888888888888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_0_5_1 : NoAtMost (0xaaaaaaaa00000000aaaaaaaa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xaaaaaaaa00000000aaaaaaaa) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_5_2 : NoAtMost (0x55555555000000005555555500000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x55555555000000005555555500000000) (a:=0x50505050505050505050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_0_5_3 : NoAtMost (0xaaaaaaaa00000000aaaaaaaa00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xaaaaaaaa00000000aaaaaaaa00000000) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_0_6_1 : NoAtMost (0xaaaaaaaaaaaaaaaa :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaaaaaaaaaaaaaaaa) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_6_2 : NoAtMost (0x55555555555555550000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x55555555555555550000000000000000) (a:=0x50505050505050505050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_0_6_3 : NoAtMost (0xaaaaaaaaaaaaaaaa0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaaaaaaaaaaaaaaaa0000000000000000) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_3_2 : NoAtMost (0x33003300330033003300330033003300 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33003300330033003300330033003300) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_1_4_0 : NoAtMost (0xffffccccffffccccffffccccffffcccc :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffccccffffccccffffccccffffcccc) (a:=0xffccffccffccffccffccffccffccffcc) (by decide +kernel) gate_1_3_0
theorem labeled_1_4_1 : NoAtMost (0xcccc0000cccc0000cccc0000cccc :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xcccc0000cccc0000cccc0000cccc) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_1_4_2 : NoAtMost (0x33330000333300003333000033330000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0x33330000333300003333000033330000) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_1_4_3 : NoAtMost (0xcccc0000cccc0000cccc0000cccc0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xcccc0000cccc0000cccc0000cccc0000) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc00) (by decide +kernel) gate_1_3_3
theorem labeled_1_6_0 : NoAtMost (0xffffffffffffffffcccccccccccccccc :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffffffffffffffcccccccccccccccc) (a:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (by decide +kernel) gate_1_2_0
theorem labeled_1_6_1 : NoAtMost (0xcccccccccccccccc :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xcccccccccccccccc) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (by decide +kernel) gate_1_2_1
theorem labeled_1_6_2 : NoAtMost (0x33333333333333330000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x33333333333333330000000000000000) (a:=0x30303030303030303030303030303030) (by decide +kernel) gate_1_2_2
theorem labeled_1_6_3 : NoAtMost (0xcccccccccccccccc0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xcccccccccccccccc0000000000000000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (by decide +kernel) gate_1_2_3
theorem labeled_2_3_0 : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfff0fff0fff0fff0fff0fff0fff0fff0) (a:=0xffffffffccccccccffffffffcccccccc) (by decide +kernel) gate_1_5_0
theorem labeled_2_3_1 : NoAtMost (0xf000f000f000f000f000f000f000f0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f000f000f000f000f0) (a:=0x33333333000000003333333300000000) (by decide +kernel) gate_1_5_2
theorem labeled_2_3_2 : NoAtMost (0xf000f000f000f000f000f000f000f00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f000f000f000f000f00) (a:=0xcccccccc00000000cccccccc) (by decide +kernel) gate_1_5_1
theorem labeled_2_3_3 : NoAtMost (0xf000f000f000f000f000f000f000f000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f000f000f000f000f000) (a:=0xcccccccc00000000cccccccc00000000) (by decide +kernel) gate_1_5_3
theorem labeled_2_4_0 : NoAtMost (0xfffff0f0fffff0f0fffff0f0fffff0f0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xfffff0f0fffff0f0fffff0f0fffff0f0) (a:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (by decide +kernel) gate_1_2_0
theorem labeled_2_4_1 : NoAtMost (0xf0f00000f0f00000f0f00000f0f0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f00000f0f00000f0f00000f0f0) (a:=0x30303030303030303030303030303030) (by decide +kernel) gate_1_2_2
theorem labeled_2_4_2 : NoAtMost (0xf0f00000f0f00000f0f00000f0f0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f00000f0f00000f0f00000f0f0000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (by decide +kernel) gate_1_2_1
theorem labeled_2_4_3 : NoAtMost (0xf0f00000f0f00000f0f00000f0f00000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f00000f0f00000f0f00000f0f00000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (by decide +kernel) gate_1_2_3
theorem labeled_2_5_2 : NoAtMost (0xf0f0f0f000000000f0f0f0f00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0f0f000000000f0f0f0f00000000) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_2_6_0 : NoAtMost (0xfffffffffffffffff0f0f0f0f0f0f0f0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xfffffffffffffffff0f0f0f0f0f0f0f0) (a:=0xfffffffff0f0f0f0fffffffff0f0f0f0) (by decide +kernel) gate_2_5_0
theorem labeled_2_6_1 : NoAtMost (0xf0f0f0f0f0f0f0f0 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f0f0f0f0f0f0f0) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_2_6_2 : NoAtMost (0xf0f0f0f0f0f0f0f0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xf0f0f0f0f0f0f0f0000000000000000) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_2_6_3 : NoAtMost (0xf0f0f0f0f0f0f0f00000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f0f0f0f0f0f0f00000000000000000) (a:=0xf0f0f0f000000000f0f0f0f000000000) (by decide +kernel) gate_2_5_3
theorem labeled_3_4_0 : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xffffff00ffffff00ffffff00ffffff00) (a:=0xffccffccffccffccffccffccffccffcc) (by decide +kernel) gate_1_3_0
theorem labeled_3_4_1 : NoAtMost (0xff000000ff000000ff000000ff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff000000ff000000ff000000ff00) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_3_4_2 : NoAtMost (0xff000000ff000000ff000000ff0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xff000000ff000000ff000000ff0000) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_3_4_3 : NoAtMost (0xff000000ff000000ff000000ff000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xff000000ff000000ff000000ff000000) (a:=0xcc00cc00cc00cc00cc00cc00cc00cc00) (by decide +kernel) gate_1_3_3
theorem labeled_3_5_0 : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffffff00ff00ffffffffff00ff00) (a:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (by decide +kernel) gate_1_2_0
theorem labeled_3_5_1 : NoAtMost (0xff00ff0000000000ff00ff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff0000000000ff00ff00) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (by decide +kernel) gate_1_2_1
theorem labeled_3_5_2 : NoAtMost (0xff00ff0000000000ff00ff00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff0000000000ff00ff00000000) (a:=0x30303030303030303030303030303030) (by decide +kernel) gate_1_2_2
theorem labeled_3_5_3 : NoAtMost (0xff00ff0000000000ff00ff0000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff0000000000ff00ff0000000000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (by decide +kernel) gate_1_2_3
theorem labeled_3_6_0 : NoAtMost (0xffffffffffffffffff00ff00ff00ff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xffffffffffffffffff00ff00ff00ff00) (a:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (by decide +kernel) gate_1_2_0
theorem labeled_3_6_1 : NoAtMost (0xff00ff00ff00ff00 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff00ff00ff00ff00) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (by decide +kernel) gate_1_2_1
theorem labeled_3_6_2 : NoAtMost (0xff00ff00ff00ff0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff00ff00ff00ff0000000000000000) (a:=0x30303030303030303030303030303030) (by decide +kernel) gate_1_2_2
theorem labeled_3_6_3 : NoAtMost (0xff00ff00ff00ff000000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff00ff00ff00ff000000000000000000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (by decide +kernel) gate_1_2_3
theorem labeled_4_5_0 : NoAtMost (0xffffffffffff0000ffffffffffff0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffffffffffff0000ffffffffffff0000) (a:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (by decide +kernel) gate_1_2_0
theorem labeled_4_5_1 : NoAtMost (0xffff000000000000ffff0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff000000000000ffff0000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (by decide +kernel) gate_1_2_1
theorem labeled_4_5_2 : NoAtMost (0xffff000000000000ffff00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff000000000000ffff00000000) (a:=0x30303030303030303030303030303030) (by decide +kernel) gate_1_2_2
theorem labeled_4_5_3 : NoAtMost (0xffff000000000000ffff000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff000000000000ffff000000000000) (a:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (by decide +kernel) gate_1_2_3
theorem labeled_4_6_0 : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffffffffffffffffffff0000ffff0000) (a:=0xffffffffccccccccffffffffcccccccc) (by decide +kernel) gate_1_5_0
theorem labeled_4_6_1 : NoAtMost (0xffff0000ffff0000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff0000ffff0000) (a:=0xcccccccc00000000cccccccc) (by decide +kernel) gate_1_5_1
theorem labeled_4_6_2 : NoAtMost (0xffff0000ffff0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff0000ffff0000000000000000) (a:=0x33333333000000003333333300000000) (by decide +kernel) gate_1_5_2
theorem labeled_4_6_3 : NoAtMost (0xffff0000ffff00000000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffff0000ffff00000000000000000000) (a:=0xcccccccc00000000cccccccc00000000) (by decide +kernel) gate_1_5_3
theorem labeled_5_6_0 : NoAtMost (0xffffffffffffffffffffffff00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffffffffffffffffffffff00000000) (a:=0xfffffffff0f0f0f0fffffffff0f0f0f0) (by decide +kernel) gate_2_5_0
theorem labeled_5_6_1 : NoAtMost (0xffffffff00000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffffffff00000000) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_5_6_2 : NoAtMost (0xffffffff0000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffffff0000000000000000) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_5_6_3 : NoAtMost (0xffffffff000000000000000000000000 :: inputs 7) tgt 7 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffffff000000000000000000000000) (a:=0xf0f0f0f000000000f0f0f0f000000000) (by decide +kernel) gate_2_5_3
def forbidden : List (BitVec 128) := [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0x22222222222222222222222222222222,0x44444444444444444444444444444444,0x88888888888888888888888888888888,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0,0xffaaffaaffaaffaaffaaffaaffaaffaa,0xaa00aa00aa00aa00aa00aa00aa00aa,0x55005500550055005500550055005500,0xaa00aa00aa00aa00aa00aa00aa00aa00,0xffffaaaaffffaaaaffffaaaaffffaaaa,0xaaaa0000aaaa0000aaaa0000aaaa,0x55550000555500005555000055550000,0xaaaa0000aaaa0000aaaa0000aaaa0000,0xaaaaaaaa00000000aaaaaaaa,0x55555555000000005555555500000000,0xaaaaaaaa00000000aaaaaaaa00000000,0xaaaaaaaaaaaaaaaa,0x55555555555555550000000000000000,0xaaaaaaaaaaaaaaaa0000000000000000,0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c,0x30303030303030303030303030303030,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0,0xffccffccffccffccffccffccffccffcc,0xcc00cc00cc00cc00cc00cc00cc00cc,0x33003300330033003300330033003300,0xcc00cc00cc00cc00cc00cc00cc00cc00,0xffffccccffffccccffffccccffffcccc,0xcccc0000cccc0000cccc0000cccc,0x33330000333300003333000033330000,0xcccc0000cccc0000cccc0000cccc0000,0xffffffffccccccccffffffffcccccccc,0xcccccccc00000000cccccccc,0x33333333000000003333333300000000,0xcccccccc00000000cccccccc00000000,0xffffffffffffffffcccccccccccccccc,0xcccccccccccccccc,0x33333333333333330000000000000000,0xcccccccccccccccc0000000000000000,0xfff0fff0fff0fff0fff0fff0fff0fff0,0xf000f000f000f000f000f000f000f0,0xf000f000f000f000f000f000f000f00,0xf000f000f000f000f000f000f000f000,0xfffff0f0fffff0f0fffff0f0fffff0f0,0xf0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f0000,0xf0f00000f0f00000f0f00000f0f00000,0xfffffffff0f0f0f0fffffffff0f0f0f0,0xf0f0f0f000000000f0f0f0f0,0xf0f0f0f000000000f0f0f0f00000000,0xf0f0f0f000000000f0f0f0f000000000,0xfffffffffffffffff0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00000000000000000,0xffffff00ffffff00ffffff00ffffff00,0xff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff0000,0xff000000ff000000ff000000ff000000,0xffffffffff00ff00ffffffffff00ff00,0xff00ff0000000000ff00ff00,0xff00ff0000000000ff00ff00000000,0xff00ff0000000000ff00ff0000000000,0xffffffffffffffffff00ff00ff00ff00,0xff00ff00ff00ff00,0xff00ff00ff00ff0000000000000000,0xff00ff00ff00ff000000000000000000,0xffffffffffff0000ffffffffffff0000,0xffff000000000000ffff0000,0xffff000000000000ffff00000000,0xffff000000000000ffff000000000000,0xffffffffffffffffffff0000ffff0000,0xffff0000ffff0000,0xffff0000ffff0000000000000000,0xffff0000ffff00000000000000000000,0xffffffffffffffffffffffff00000000,0xffffffff00000000,0xffffffff0000000000000000,0xffffffff000000000000000000000000]
theorem all_forbidden (g : BitVec 128) (h : g∈forbidden) : NoAtMost (g::inputs 7) tgt 7 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 7) tgt 7 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x22222222222222222222222222222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x44444444444444444444444444444444) gate_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x88888888888888888888888888888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x50505050505050505050505050505050) gate_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffaaffaaffaaffaaffaaffaaffaaffaa) labeled_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaa00aa00aa00aa00aa00aa00aa00aa) labeled_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x55005500550055005500550055005500) labeled_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaa00aa00aa00aa00aa00aa00aa00aa00) labeled_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffaaaaffffaaaaffffaaaaffffaaaa) labeled_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaa0000aaaa0000aaaa0000aaaa) labeled_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x55550000555500005555000055550000) labeled_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaa0000aaaa0000aaaa0000aaaa0000) labeled_0_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaaaaaa00000000aaaaaaaa) labeled_0_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x55555555000000005555555500000000) labeled_0_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaaaaaa00000000aaaaaaaa00000000) labeled_0_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaaaaaaaaaaaaaa) labeled_0_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x55555555555555550000000000000000) labeled_0_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xaaaaaaaaaaaaaaaa0000000000000000) labeled_0_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) gate_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) gate_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x30303030303030303030303030303030) gate_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) gate_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffccffccffccffccffccffccffccffcc) gate_1_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcc00cc00cc00cc00cc00cc00cc00cc) gate_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x33003300330033003300330033003300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcc00cc00cc00cc00cc00cc00cc00cc00) gate_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffccccffffccccffffccccffffcccc) labeled_1_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccc0000cccc0000cccc0000cccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x33330000333300003333000033330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccc0000cccc0000cccc0000cccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffccccccccffffffffcccccccc) gate_1_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccccccc00000000cccccccc) gate_1_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x33333333000000003333333300000000) gate_1_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccccccc00000000cccccccc00000000) gate_1_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffffffffffcccccccccccccccc) labeled_1_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccccccccccccccc) labeled_1_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0x33333333333333330000000000000000) labeled_1_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xcccccccccccccccc0000000000000000) labeled_1_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xfff0fff0fff0fff0fff0fff0fff0fff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf000f000f000f000f000f000f000f0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf000f000f000f000f000f000f000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf000f000f000f000f000f000f000f000) labeled_2_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xfffff0f0fffff0f0fffff0f0fffff0f0) labeled_2_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f00000f0f00000f0f00000f0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f00000f0f00000f0f00000f0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f00000f0f00000f0f00000f0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xfffffffff0f0f0f0fffffffff0f0f0f0) gate_2_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f000000000f0f0f0f0) gate_2_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f000000000f0f0f0f00000000) labeled_2_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f000000000f0f0f0f000000000) gate_2_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xfffffffffffffffff0f0f0f0f0f0f0f0) labeled_2_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f0f0f0f0f0) labeled_2_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f0f0f0f0f0000000000000000) labeled_2_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xf0f0f0f0f0f0f0f00000000000000000) labeled_2_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffff00ffffff00ffffff00ffffff00) labeled_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff000000ff000000ff000000ff00) labeled_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff000000ff000000ff000000ff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff000000ff000000ff000000ff000000) labeled_3_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffff00ff00ffffffffff00ff00) labeled_3_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff0000000000ff00ff00) labeled_3_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff0000000000ff00ff00000000) labeled_3_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff0000000000ff00ff0000000000) labeled_3_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffffffffffff00ff00ff00ff00) labeled_3_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff00ff00ff00) labeled_3_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff00ff00ff0000000000000000) labeled_3_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xff00ff00ff00ff000000000000000000) labeled_3_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffffff0000ffffffffffff0000) labeled_4_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff000000000000ffff0000) labeled_4_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff000000000000ffff00000000) labeled_4_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff000000000000ffff000000000000) labeled_4_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffffffffffffff0000ffff0000) labeled_4_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff0000ffff0000) labeled_4_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff0000ffff0000000000000000) labeled_4_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffff0000ffff00000000000000000000) labeled_4_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffffffffffffffffffff00000000) labeled_5_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffff00000000) labeled_5_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffff0000000000000000) labeled_5_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 7) (x:=0xffffffff000000000000000000000000) labeled_5_6_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M251
