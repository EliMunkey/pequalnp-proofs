import M189StartData
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b9 : Blocked tgt 5 s9 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s9 5 _ le
  decide +kernel
theorem b12 : Blocked tgt 5 s12 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s12 5 _ le
  decide +kernel
theorem b16 : Blocked tgt 5 s16 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s16 5 _ le
  decide +kernel
theorem b19 : Blocked tgt 5 s19 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s19 5 _ le
  decide +kernel
theorem b23 : Blocked tgt 5 s23 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s23 5 _ le
  decide +kernel
theorem b24 : Blocked tgt 5 s24 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1746,1234,1242,1234,2917,2533,579,2533,707,451,2661,451,707,1219,788,707,707,2243,869,707,1364,2469,1428,1364,1234,387,1426,1234,3364,1219,1218,1218,1234,2179,3218,1234,2273,2277,2529,2273,2533,1091,3429,2533,453,485,2501,453,451,3173,1219,451,451,3348,2243,451,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b29 : Blocked tgt 5 s29 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s29 5 _ le
  decide +kernel
theorem b30 : Blocked tgt 5 s30 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1946,1754,387,1754,2529,2273,2277,2273,451,707,2661,451,451,1219,3173,451,451,2243,808,451,1624,1626,1752,1624,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2273,579,2657,2273,2273,1091,3169,2273,3608,2243,2241,2241,707,3624,1219,707,707,609,2243,707,1219,1121,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b35 : Blocked tgt 5 s35 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s35 5 _ le
  decide +kernel
theorem b36 : Blocked tgt 5 s36 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3738,1754,2179,1754,2501,453,485,453,2243,451,776,451,2243,707,869,707,2243,1219,1381,1219,1364,389,1428,1364,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1816,451,449,449,453,579,837,453,453,1091,1349,453,451,581,707,451,451,1093,1219,451,707,1812,1219,707]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b41 : Blocked tgt 5 s41 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s41 5 _ le
  decide +kernel
theorem b42 : Blocked tgt 5 s42 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1738,714,730,714,3429,2533,1091,2533,1219,451,3173,451,1219,707,772,707,1219,2243,1381,1219,2468,2469,2468,2532,714,387,906,714,2852,707,706,706,714,2179,2698,714,2273,2277,2529,2273,2533,579,2917,2533,453,485,2501,453,451,2661,707,451,451,2856,2243,451,707,869,2243,707]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b51 : Blocked tgt 5 s51 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1816,1818,1816,1944,1428,2216,1812,1428,2465,404,3169,2465,1428,481,2433,1428,1108,2465,1108,1428,1426,1434,1938,1426,906,922,1930,906,1946,616,2179,1946,1754,387,1754,1946,707,788,1219,707,707,609,2179,707,1234,1242,1234,1746,1219,1121,2179,1219,714,730,714,1738,1754,3738]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b52 : Blocked tgt 5 s52 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s52 5 _ le
  decide +kernel
theorem b57 : Blocked tgt 5 s57 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s57 5 _ le
  decide +kernel
theorem b58 : Blocked tgt 5 s58 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s58 5 _ le
  decide +kernel
end PetersenSmallStarts.M189
