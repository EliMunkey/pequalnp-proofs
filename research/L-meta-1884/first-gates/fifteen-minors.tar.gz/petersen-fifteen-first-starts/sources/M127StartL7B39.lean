import M127StartData
import M127StartPins0
import M127StartL6B36
import M127StartL6B37
import M127StartL6B35
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1294 : Blocked tgt 7 s1294 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1294 7 _ le
  decide +kernel
theorem b1295 : Blocked tgt 7 s1295 := by
  apply PetersenFastNode.node (nxt := #[s1296]) (hints := [2451,1419,2451,1419,11125,9577,11125,9577,9930,9930,9926,3347,10950,11466,10950,11466,12998,13514,12998,13514,10515,9483,10515,9483,9577,1419,9577,9705,1419,14581,2835,1419,2451,1419,1419,2451,1419,11338,3339,1419,10965,1419,1419,13513,1419,5353,9483,1419,9577,10613,11121,9577,9926,9577,9577,11125,11466,3339,11466,9577,9674,9674,2869,9483,9513,9483,2835,9926,9922,11466,10438,11466,10946,13514,12486,13514,12994,9483,0,9483,2835,9926,11466,10950,11466,9926,13514,12998,13514,1670,9483,9862,9483,11466,3339,13514,11466,3210,3274,11402,3210,5258,5322,13450,5258]) (by decide +kernel)
  change ∀ b ∈ [s1296], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1296) b1296 <|
    PetersenLocalChildren.nil
theorem b1299 : Blocked tgt 7 s1299 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1299 7 _ le
  decide +kernel
theorem b1300 : Blocked tgt 7 s1300 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1300 7 _ le
  decide +kernel
theorem b1301 : Blocked tgt 7 s1301 := by
  apply PetersenFastNode.node (nxt := #[s1291]) (hints := [14643,13611,13611,14643,13611,5547,5289,5547,1418,1418,13611,6963,0,13611,1670,13611,13611,14643,3210,7467,3210,7467,5258,13579,5258,9483,6579,5547,6579,5547,9094,9610,9094,9610,5931,5931,7475,7475,2694,7467,2694,7467,4742,5258,4742,5258,5289,5547,5547,5289,5547,6325,6963,5547,6579,5547,5547,6579,5547,4531,7467,5547,1419,1451,5515,1419,9610,6963,9090,6963,1670,9610,9610,9094,3210,7467,3210,7467,5258,9513,5258,9610,6963,1670,7987,7467,4915,7467,4899,2835,2867,6931,2835,1670,7467,2694,7467,1670,5258,4742,5258,3339,3371,7435,3339]) (by decide +kernel)
  change ∀ b ∈ [s1291], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1291) b1291 <|
    PetersenLocalChildren.nil
theorem b1302 : Blocked tgt 7 s1302 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1302 7 _ le
  decide +kernel
theorem b1303 : Blocked tgt 7 s1303 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1303 7 _ le
  decide +kernel
theorem b1304 : Blocked tgt 7 s1304 := by
  apply PetersenFastNode.node (nxt := #[s1305,s1306,s1307,s1308,s1309,s1310,s1311,s1312,s1313,s1169,s1282,s1314,s1315,s1316,s1296,s1317,s1318,s1291,s1320,s1321,s1322,s1323]) (hints := [6600,5758,6600,5568,1759,5568,6600,1759,6600,5568,5758,5568,1759,1759,923,2015,0,9695,923,1,923,1759,1759,9695,1691,1759,1691,7496,2,3,1759,1759,2715,3807,4,11487,2715,5,2715,1759,1759,11487,1759,1759,4763,5855,5758,13535,4763,5758,4763,1759,1759,13535,1695,6,6984,1695,1759,13632,1759,1759,6984,13632,7,13632,13566,13566,13694,5312,5568,9695,13694,5568,13694,13566,13566,9695,6600,6600,7754,5568,5568,1691,5568,5568,7754,6600,6600,1691,5568,5568,7488,11359,6600,11487,7488,6600,7488,5568,5568,11487,1440,1440,8,1472,5568,13535,5536,5568,9,1440,1440,13535,5568,5568,13632,5374,13566,10,13632,13566,13632,5568,5568,11,923,923,1691,9695,9695,12,9695,9695,1691,923,923,13,9695,9695,11487,7232,6986,7488,11487,6986,11487,9695,9695,7488,9695,9695,13535,9598,13694,14,13535,13694,13535,9695,9695,15,1439,1439,16,1503,9695,13632,9631,9695,17,1439,1439,13632,1691,1691,2715,11487,7754,11487,2715,7754,2715,11487,1691,11487,1691,1691,4763,13535,7754,13535,4763,7754,4763,13535,1691,13535,6984,18,6984,13632,1691,13632,1687,1691,6984,13632,19,13632,11487,11487,13535,3392,7488,20,13535,7488,13535,11487,11487,21,3231,3231,13632,3295,11487,6984,11423,11487,13632,3231,3231,6984,5279,5279,9504,5343,13535,13632,13471,13535,9504,5279,5279,13632]) (by decide +kernel)
  change ∀ b ∈ [s1305,s1306,s1307,s1308,s1309,s1310,s1311,s1312,s1313,s1169,s1282,s1314,s1315,s1316,s1296,s1317,s1318,s1291,s1320,s1321,s1322,s1323], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1305) b1305 <|
    PetersenLocalChildren.push (x := s1306) b1306 <|
    PetersenLocalChildren.push (x := s1307) b1307 <|
    PetersenLocalChildren.push (x := s1308) b1308 <|
    PetersenLocalChildren.push (x := s1309) b1309 <|
    PetersenLocalChildren.push (x := s1310) b1310 <|
    PetersenLocalChildren.push (x := s1311) b1311 <|
    PetersenLocalChildren.push (x := s1312) b1312 <|
    PetersenLocalChildren.push (x := s1313) b1313 <|
    PetersenLocalChildren.push (x := s1169) b1169 <|
    PetersenLocalChildren.push (x := s1282) b1282 <|
    PetersenLocalChildren.push (x := s1314) b1314 <|
    PetersenLocalChildren.push (x := s1315) b1315 <|
    PetersenLocalChildren.push (x := s1316) b1316 <|
    PetersenLocalChildren.push (x := s1296) b1296 <|
    PetersenLocalChildren.push (x := s1317) b1317 <|
    PetersenLocalChildren.push (x := s1318) b1318 <|
    PetersenLocalChildren.push (x := s1291) b1291 <|
    PetersenLocalChildren.push (x := s1320) b1320 <|
    PetersenLocalChildren.push (x := s1321) b1321 <|
    PetersenLocalChildren.push (x := s1322) b1322 <|
    PetersenLocalChildren.push (x := s1323) b1323 <|
    PetersenLocalChildren.nil
theorem b1324 : Blocked tgt 7 s1324 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1324 7 _ le
  decide +kernel
theorem b1325 : Blocked tgt 7 s1325 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1325 7 _ le
  decide +kernel
theorem b1326 : Blocked tgt 7 s1326 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1326 7 _ le
  decide +kernel
theorem b1327 : Blocked tgt 7 s1327 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1327 7 _ le
  decide +kernel
theorem b1328 : Blocked tgt 7 s1328 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1328 7 _ le
  decide +kernel
theorem b1329 : Blocked tgt 7 s1329 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1329 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
