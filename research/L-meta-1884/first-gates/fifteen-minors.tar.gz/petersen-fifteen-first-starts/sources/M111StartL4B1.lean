import M111StartData
import M111StartL3B0
import M111StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b93 : Blocked tgt 4 s93 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,3176,194,2852,2468,2216,386,2852,386,2848,2178,804,2178,772,3688,194,2468,3688,2856,3172,2856,3688,1608,1640,3656,1608,2856,2212,2856,2208,388,420,2436,388,776,808,2824,776]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b97 : Blocked tgt 4 s97 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3218,1234,1364,1234,837,201,453,453,3218,837,833,833,837,1097,1349,837,1618,1234,1234,1240,1234,777,1426,1234,194,210,1218,194,201,1426,457,201,201,2452,1225,201,841,402,1609,841]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b110 : Blocked tgt 4 s110 := by
  apply PetersenFastNode.node (nxt := #[s111]) (hints := [1427,1235,1105,1235,194,194,834,1939,1090,1411,1090,387,1105,1235,1235,1105,1235,770,1809,1235,195,211,1219,195,450,0,834,450,450,401,1090,450,834,785,1090,834]) (by decide +kernel)
  change ∀ b ∈ [s111], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s111) b111 <|
    PetersenLocalChildren.nil
theorem b113 : Blocked tgt 4 s113 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3218,1234,1104,1234,193,193,833,1426,833,1426,1089,3202,1089,2178,1104,1234,1234,1104,1234,769,1426,1234,194,210,1218,194,833,1426,833,1426,1089,2192,1089,2241,386,402,1410,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b116 : Blocked tgt 4 s116 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1348,714,388,388,2698,906,776,906,2178,2690,2186,2178,1348,714,714,1348,714,1092,906,714,194,202,706,194,776,906,776,906,772,2184,772,2436,386,394,898,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b119 : Blocked tgt 4 s119 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1348,714,1349,2698,453,453,841,1093,841,1609,837,1097,837,1349,1610,714,714,2500,714,777,906,714,194,202,706,194,841,906,841,906,837,2249,837,2501,386,394,898,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b120 : Blocked tgt 4 s120 := by
  apply PetersenFastNode.node (nxt := #[s20]) (hints := [1611,715,0,715,454,454,842,907,842,907,838,2691,838,2179,2437,715,715,1349,715,778,907,715,195,203,707,195,842,907,842,907,838,1098,838,1350,387,395,899,387]) (by decide +kernel)
  change ∀ b ∈ [s20], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
theorem b122 : Blocked tgt 4 s122 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s122 4 _ le
  decide +kernel
theorem b123 : Blocked tgt 4 s123 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3218,1234,1104,1234,193,193,833,1426,833,1426,1089,3202,1089,2178,1104,1234,1234,1104,1234,769,1426,1234,194,210,1218,194,833,1426,833,1426,1089,2192,1089,2241,386,402,1410,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b125 : Blocked tgt 4 s125 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s125 4 _ le
  decide +kernel
theorem b126 : Blocked tgt 4 s126 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1348,714,388,388,2698,906,776,906,2178,2690,2186,2178,1348,714,714,1348,714,1092,906,714,194,202,706,194,776,906,776,906,772,2184,772,2436,386,394,898,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b128 : Blocked tgt 4 s128 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1348,714,1349,404,453,453,841,1093,841,1609,837,1097,837,1349,404,714,404,468,714,1108,906,714,194,202,706,194,1802,906,920,906,404,2249,916,404,386,394,898,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b130 : Blocked tgt 4 s130 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1234,1234,1364,3218,1234,1234,1364,1234,1108,1426,1234,194,210,1218,194,837,3218,453,453,2241,2245,2497,2241,1349,2452,1349,2501,3218,837,833,833,837,3202,1349,837,1089,1093,1089,1345]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b131 : Blocked tgt 4 s131 := by
  apply PetersenFastNode.node (nxt := #[s111]) (hints := [1365,1235,1365,1235,1811,1427,0,1427,454,454,1350,3203,1350,2179,1235,1109,1427,1235,1365,1235,1235,1365,195,211,1219,195,2242,1427,1427,834,387,403,1411,387,838,789,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s111], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s111) b111 <|
    PetersenLocalChildren.nil
theorem b133 : Blocked tgt 4 s133 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3218,1234,773,1234,837,453,193,453,833,837,833,1426,837,1349,1089,837,1364,389,1428,1364,1234,1364,1426,1234,194,210,1218,194,197,197,453,1426,453,404,1349,453,386,1349,1410,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M111
