import M251StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b40 : Blocked tgt 5 s40 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6418,2450,2192,2450,8641,8641,9409,3858,9409,3858,10433,10562,10433,10562,6418,10514,4418,6418,2192,2450,2450,2192,2450,9409,3474,2450,8642,402,10562,8642,2450,450,10514,2450,9409,3858,9409,3858,10433,10562,10433,10562,4481,10514,12673,10514,10050,1810,10562,10050,3858,1858,10514,3858,2177,10514,10498,10498]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b43 : Blocked tgt 5 s43 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4870,902,1160,902,901,901,5386,1802,4358,1802,1669,1798,1669,1798,2693,11014,2693,4870,4868,902,902,4996,1418,390,1802,1418,902,394,1798,902,902,2693,2950,902,4481,1802,4993,1802,1669,1798,1669,1798,2693,11014,2693,11014,1153,1798,1794,1794,1802,10502,11530,1802,1798,10506,11014,1798]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M251
