import M63StartData
import M63StartL4B1
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b630 : Blocked tgt 5 s630 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,714,714,906,841,906,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,453,1428,713,197,841,713,453,201,837,453,453,404,1349,453,906,841,906,841,3282,837,2754,837,2762,1349,3266,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b631 : Blocked tgt 5 s631 := by
  apply PetersenFastNode.node (nxt := #[s534]) (hints := [715,715,2634,714,1429,714,2374,838,2122,838,2634,842,2118,842,2634,1350,0,2634,2633,714,2761,714,3283,838,2755,838,907,842,907,842,2763,1350,3267,1350,454,202,838,454,714,198,842,714,714,405,1350,714,1427,838,834,834,838,1098,1350,838,842,1094,1610,842]) (by decide +kernel)
  change ∀ b ∈ [s534], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s534) b534 <|
    PetersenLocalChildren.nil
theorem b632 : Blocked tgt 5 s632 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2633,841,2117,841,1364,1364,2373,453,1428,453,2373,837,772,837,2373,1349,1674,1349,906,841,841,906,713,197,713,841,1426,837,833,833,841,1093,1609,841,1428,453,1428,453,3412,837,772,837,2372,1349,3396,1349,453,201,837,453,453,404,1349,453,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b636 : Blocked tgt 5 s636 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1234,714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1364,453,1428,1364,1234,841,1426,1234,1234,837,1746,1234,210,210,1234,1349,713,197,841,713,453,201,837,453,453,1428,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b637 : Blocked tgt 5 s637 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s637 5 _ le
  decide +kernel
theorem b644 : Blocked tgt 5 s644 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s644 5 _ le
  decide +kernel
theorem b654 : Blocked tgt 5 s654 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s654 5 _ le
  decide +kernel
theorem b661 : Blocked tgt 5 s661 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2986,2794,777,2794,841,713,193,713,833,841,833,3506,841,1609,1089,841,841,2633,2113,841,2664,2666,2792,2664,3314,2282,3762,3314,2794,2290,3754,2794,714,746,2762,714,201,201,713,3762,713,3626,1609,713,713,1456,2633,713,833,1609,3746,1609,1682,2633,3730,2633,1609,1706,2633,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b666 : Blocked tgt 5 s666 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s666 5 _ le
  decide +kernel
theorem b667 : Blocked tgt 5 s667 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3762,3314,2282,3314,837,453,193,453,833,837,833,3506,837,1349,1089,837,837,2373,2113,837,3444,389,3508,3444,3314,3188,3506,3314,2274,2290,3298,2274,1234,1266,3282,1234,197,197,453,3504,453,2484,1349,453,453,1460,2373,453,1093,1093,3490,1349,1426,2373,3474,2373,1349,1706,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b678 : Blocked tgt 5 s678 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s678 5 _ le
  decide +kernel
theorem b679 : Blocked tgt 5 s679 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s679 5 _ le
  decide +kernel
theorem b690 : Blocked tgt 5 s690 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s690 5 _ le
  decide +kernel
theorem b691 : Blocked tgt 5 s691 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s691 5 _ le
  decide +kernel
theorem b696 : Blocked tgt 5 s696 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s696 5 _ le
  decide +kernel
theorem b697 : Blocked tgt 5 s697 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s697 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
