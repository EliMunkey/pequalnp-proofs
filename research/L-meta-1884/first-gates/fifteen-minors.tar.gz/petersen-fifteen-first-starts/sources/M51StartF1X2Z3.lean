import M51StartData
import M51StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_3 : NoAtMost (0xc0c0 :: inputs 4) tgt 2 := by
  change NoAtMost [0xc0c0,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s9] [50,120,51,51,52,120,83,83,86,120,51,51,120,120,147,147,154,256,51,51,188,256,83,83,222,256,51,51,256,256,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s9], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_3
end PetersenSmallStarts.M51
