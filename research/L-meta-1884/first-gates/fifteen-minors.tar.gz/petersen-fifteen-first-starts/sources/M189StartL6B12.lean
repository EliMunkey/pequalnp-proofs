import M189StartData
import M189StartPins0
import M189StartL5B3
import M189StartL5B4
import M189StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b267 : Blocked tgt 6 s267 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s267 6 _ le
  decide +kernel
theorem b268 : Blocked tgt 6 s268 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s268 6 _ le
  decide +kernel
theorem b269 : Blocked tgt 6 s269 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,3364,714,730,1219,1234,714,1219,714,1218,3364,1234,2533,3429,2533,1091,1219,1428,2533,1219,2533,3429,3429,1428,451,1219,451,3173,3429,1946,451,3429,451,1219,1219,1946,707,1219,707,788,3624,1812,707,3624,707,1219,1219,1812,1219,1219,2243,1381,3429,3738,2243,3429,2243,1219,1219,3738,1364,1364,1428,1106,1234,2533,1428,1234,1428,1364,1364,2533,1946,1234,1946,1108,1364,451,1946,1364,1946,1234,1234,451,1234,1234,1812,1242,714,707,1812,714,1812,1234,1234,707,3738,1234,3738,2179,2664,2243,3738,2664,3738,1234,1234,2243,1816,2273,1816,1818,1428,1946,1816,1428,1816,1944,2273,1946,1428,1428,1812,579,2728,707,1812,2728,1812,1428,1428,707,1428,1428,3348,3610,2533,3738,3348,2533,3348,1428,1428,3738,1426,1426,707,1434,1946,1812,1938,1946,707,1426,1426,1812,1946,1946,3738,3092,2856,3348,3738,2856,3738,1946,1946,3348,3218,1812,3218,3226,2917,3738,3218,2917,3218,3730,1812,3738]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b270 : Blocked tgt 6 s270 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s270 6 _ le
  decide +kernel
theorem b271 : Blocked tgt 6 s271 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s271 6 _ le
  decide +kernel
theorem b272 : Blocked tgt 6 s272 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s272 6 _ le
  decide +kernel
theorem b273 : Blocked tgt 6 s273 := by
  apply PetersenFastNode.node (nxt := #[s274,s275]) (hints := [1366,1366,1430,2471,1236,2535,1430,1236,1430,1366,1366,2535,1948,1236,1948,389,1366,453,1948,1366,1948,1236,1236,453,1236,1236,1814,1244,618,871,1814,618,1814,1236,1236,871,3366,618,3366,1221,1236,1221,1220,1236,3366,1220,618,1221,3740,1236,3740,2181,618,2245,1756,618,3740,1756,1236,2245,2275,2275,1818,2279,2535,453,2531,2535,1818,2275,2275,453,871,2535,871,2218,2730,0,871,2730,871,999,2535,1,2535,2535,3431,1093,1430,1221,3431,1430,3431,2535,2535,1221,455,455,3350,487,2535,2245,2503,2535,3350,455,455,2245,453,453,611,615,1948,871,611,1948,611,453,453,871,453,453,1221,3175,1948,3431,1221,1948,1221,453,453,3431,453,453,2245,810,2858,3350,2245,2858,2245,453,453,3350,1221,871,1221,790,1814,3626,1221,1814,1221,871,871,3626,2245,1814,2245,871,871,3740,709,871,2245,709,1814,3740,1221,1221,2245,1383,3431,3740,2245,3431,2245,1221,1221,3740]) (by decide +kernel)
  change ∀ b ∈ [s274,s275], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s274) b274 <|
    PetersenLocalChildren.push (x := s275) b275 <|
    PetersenLocalChildren.nil
theorem b276 : Blocked tgt 6 s276 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2469,1428,1364,1946,387,1946,1234,1234,1242,1812,1234,3364,1219,1218,1218,1234,616,2664,1234,1234,2664,1754,1754,2273,2277,2529,2273,2533,2216,2917,2533,2533,1091,3429,2533,453,2533,2533,453,453,2533,2533,453,451,2661,2657,451,451,3173,1219,451,451,2856,2856,451,451,2856,2856,451,1219,788,1219,2917,869,869,2917,1812,1812,2917,707,707,1219,3429,3429,1219,1219,3429,3429,1219,2243,2243]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b277 : Blocked tgt 6 s277 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s277 6 _ le
  decide +kernel
theorem b278 : Blocked tgt 6 s278 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s278 6 _ le
  decide +kernel
theorem b279 : Blocked tgt 6 s279 := by
  apply PetersenFastNode.node (nxt := #[s280,s281]) (hints := [1756,3740,1756,2181,2245,0,1756,2245,1756,3740,3740,1,455,3350,455,487,2245,2535,455,2245,455,2503,3350,2535,453,2245,453,810,3350,2858,453,3350,453,2245,2245,2858,709,2245,709,871,3740,2854,709,3740,709,2245,2245,2854,1221,2245,1221,1383,3740,3431,1221,3740,1221,2245,2245,3431,2470,1366,2470,2471,1756,2535,2470,1756,2470,2534,1366,2535,2858,1756,2858,389,1366,453,2858,1366,2858,1756,1756,453,2854,1236,2854,2855,1756,709,2854,1756,2854,1236,1236,709,3366,716,3366,3367,1756,3431,3366,1756,3366,3430,716,3431,2275,2275,2858,2279,2535,453,2531,2535,2858,2275,2275,453,2535,2535,2854,2218,2730,709,2854,2730,2854,2535,2535,709,2535,2535,3431,1093,1430,1221,3431,1430,3431,2535,2535,1221,453,453,709,2854,2858,2854,2850,2858,709,2850,453,2854,3171,2858,3171,3175,1948,3431,3171,1948,3171,3427,2858,3431,3431,2854,3431,3114,1814,3626,3431,1814,3431,2854,2854,3626]) (by decide +kernel)
  change ∀ b ∈ [s280,s281], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s280) b280 <|
    PetersenLocalChildren.push (x := s281) b281 <|
    PetersenLocalChildren.nil
theorem b282 : Blocked tgt 6 s282 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s282 6 _ le
  decide +kernel
theorem b283 : Blocked tgt 6 s283 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s283 6 _ le
  decide +kernel
theorem b284 : Blocked tgt 6 s284 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s284 6 _ le
  decide +kernel
theorem b285 : Blocked tgt 6 s285 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s285 6 _ le
  decide +kernel
theorem b286 : Blocked tgt 6 s286 := by
  apply PetersenFastNode.node (nxt := #[s224,s238,s258,s280,s287]) (hints := [1433,0,1433,2669,1951,1,1951,2669,712,712,1224,2,1224,2669,2184,621,2184,3,1759,1759,1821,1823,1821,1949,1433,2221,1817,1433,2473,409,3369,2473,1433,489,2442,1433,1369,2473,1369,1433,1431,1439,1943,1431,911,927,1935,911,1951,2861,2184,1951,1951,392,1239,1951,1224,793,1224,2857,2184,2857,2184,2696,1239,1247,1239,1817,1224,1385,2184,1224,4,1224,1223,1223,3743,3743]) (by decide +kernel)
  change ∀ b ∈ [s224,s238,s258,s280,s287], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s224) b224 <|
    PetersenLocalChildren.push (x := s238) b238 <|
    PetersenLocalChildren.push (x := s258) b258 <|
    PetersenLocalChildren.push (x := s280) b280 <|
    PetersenLocalChildren.push (x := s287) b287 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M189
