import M31StartData
import M31StartPins0
import M31StartL4B1
import M31StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b68 : Blocked tgt 5 s68 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s68 5 _ le
  decide +kernel
theorem b69 : Blocked tgt 5 s69 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [562,361,362,361,692,362,362,692,362,692,458,362,626,106,850,626,362,114,842,362,229,229,361,458,489,361,97,105,353,97,361,842,809,361,425,425,392,458,421,850,421,850,677,809,677,809,722,421,850,421,809,677,809,677,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b70 : Blocked tgt 5 s70 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s70 5 _ le
  decide +kernel
theorem b71 : Blocked tgt 5 s71 := by
  apply PetersenFastNode.node (nxt := #[s72,s17]) (hints := [694,199,726,694,395,694,427,364,364,852,391,852,694,844,679,844,678,363,103,427,363,0,231,231,1,231,107,423,231,231,214,679,231,427,460,852,423,419,419,427,551,811,427,852,423,852,423,844,679,844,679,423,555,679,423]) (by decide +kernel)
  change ∀ b ∈ [s72,s17], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s72) b72 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
theorem b73 : Blocked tgt 5 s73 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s73 5 _ le
  decide +kernel
theorem b74 : Blocked tgt 5 s74 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s74 5 _ le
  decide +kernel
theorem b75 : Blocked tgt 5 s75 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,692,724,197,106,229,724,106,724,692,692,229,106,106,458,385,692,417,458,692,458,106,106,417,850,692,850,106,106,421,626,106,850,626,692,421,106,106,842,677,692,677,618,692,842,106,106,677,97,97,417,229,229,458,417,229,417,97,97,458,229,229,421,97,97,850,421,97,421,229,229,850,229,229,677,212,724,842,677,724,677,229,229,842,722,722,850,417,417,421,417,417,850,421,722,421,417,417,545,677,722,677,545,722,545,417,417,677,421,421,677,545,850,545,677,850,677,421,421,545]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b76 : Blocked tgt 5 s76 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,197,724,692,362,393,458,362,106,106,362,692,692,362,362,626,362,677,842,362,361,229,425,361,229,105,353,229,229,361,361,229,229,212,677,229,722,425,417,417,722,425,425,722,425,677,809,425,421,421,677,553,677,801,677,809,677,809]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b77 : Blocked tgt 5 s77 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s77 5 _ le
  decide +kernel
theorem b78 : Blocked tgt 5 s78 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s78 5 _ le
  decide +kernel
theorem b79 : Blocked tgt 5 s79 := by
  apply PetersenFastNode.node (nxt := #[s80,s81,s82,s83,s84,s85]) (hints := [698,698,730,203,632,235,730,632,730,698,698,235,464,632,464,570,698,0,464,698,464,496,632,1,632,632,856,112,2,427,856,3,856,632,632,427,848,104,848,120,632,683,848,632,848,104,104,683,103,103,398,107,235,464,231,235,398,103,103,464,235,235,427,792,4,856,427,5,427,235,235,856,235,235,683,218,730,848,683,730,683,235,235,848,728,728,856,427,464,427,423,464,856,423,728,427,551,464,551,555,728,683,551,728,551,679,464,683,427,427,683,848,856,848,683,856,683,427,427,848]) (by decide +kernel)
  change ∀ b ∈ [s80,s81,s82,s83,s84,s85], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s82) b82 <|
    PetersenLocalChildren.push (x := s83) b83 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s85) b85 <|
    PetersenLocalChildren.nil
theorem b86 : Blocked tgt 5 s86 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s86 5 _ le
  decide +kernel
theorem b87 : Blocked tgt 5 s87 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s87 5 _ le
  decide +kernel
theorem b88 : Blocked tgt 5 s88 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s88 5 _ le
  decide +kernel
theorem b89 : Blocked tgt 5 s89 := by
  apply PetersenFastNode.node (nxt := #[s90]) (hints := [693,198,725,693,459,565,459,491,627,390,851,627,115,115,627,810,0,627,363,363,362,230,230,362,230,106,422,230,230,725,810,230,230,362,362,230,723,422,851,422,810,723,810,938,426,426,723,459,422,554,546,422,422,851,851,422,678,678]) (by decide +kernel)
  change ∀ b ∈ [s90], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s90) b90 <|
    PetersenLocalChildren.nil
theorem b91 : Blocked tgt 5 s91 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s91 5 _ le
  decide +kernel
end PetersenSmallStarts.M31
