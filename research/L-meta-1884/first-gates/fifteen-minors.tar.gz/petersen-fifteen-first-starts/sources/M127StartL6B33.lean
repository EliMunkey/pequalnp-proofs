import M127StartData
import M127StartPins0
import M127StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1100 : Blocked tgt 6 s1100 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1100 6 _ le
  decide +kernel
theorem b1101 : Blocked tgt 6 s1101 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1101 6 _ le
  decide +kernel
theorem b1102 : Blocked tgt 6 s1102 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1102 6 _ le
  decide +kernel
theorem b1103 : Blocked tgt 6 s1103 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1103 6 _ le
  decide +kernel
theorem b1110 : Blocked tgt 6 s1110 := by
  apply PetersenFastNode.node (nxt := #[s1111]) (hints := [1419,1419,4742,902,2837,902,5834,1738,4742,1738,4742,1670,12490,1670,4742,2694,3339,2694,5258,4742,4742,5258,2837,902,5515,902,1609,1738,5515,1738,3347,1670,3347,1670,3339,2694,3339,2694,1803,6805,1803,5515,1738,1994,902,3347,1670,902,902,3339,2694,902,390,390,902,1803,11285,1670,1730,1670,1738,2694,3786,1738,0,1738,1674,1674,1670,10442,2694,1670,2835,1670,1670,3347,3210,2694,2694,3210]) (by decide +kernel)
  change ∀ b ∈ [s1111], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1111) b1111 <|
    PetersenLocalChildren.nil
theorem b1112 : Blocked tgt 6 s1112 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1112 6 _ le
  decide +kernel
theorem b1113 : Blocked tgt 6 s1113 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4805,4741,12933,4741,9482,5514,6868,5514,9093,901,965,901,9865,1802,1673,1673,9861,1669,1733,1669,10885,2693,2757,2693,1418,1418,4741,901,2836,901,1802,4741,4741,5257,4741,1669,3346,1669,4741,2693,3338,2693,2836,901,2836,901,1802,6804,1802,5514,3346,1669,3346,1669,3338,2693,3338,2693,389,389,901,1802,901,3346,1669,901,901,788,2693,901,2834,1669,3346,1669,1802,2693,3338,2693,1669,3338,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1115 : Blocked tgt 6 s1115 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [15060,1418,10964,1418,12997,9157,11092,9157,13513,9929,12485,9929,12997,9925,12489,9925,12997,10949,11336,10949,4741,12933,4805,4741,9545,9157,1418,9157,1418,9929,1930,1418,2450,394,3346,2450,1418,402,3338,1418,1418,6868,9482,1418,9673,8645,9929,9673,9157,8649,9925,9157,9157,3338,10949,9157,901,965,9093,901,3346,9925,9921,9921,9929,10437,11465,9929,1673,1737,9865,1673,9925,10441,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1116 : Blocked tgt 6 s1116 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1116 6 _ le
  decide +kernel
theorem b1117 : Blocked tgt 6 s1117 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1117 6 _ le
  decide +kernel
theorem b1118 : Blocked tgt 6 s1118 := by
  apply PetersenFastNode.node (nxt := #[s1119]) (hints := [4742,0,4742,9483,9483,5515,6805,5515,902,1418,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,1419,1419,4742,902,2837,902,5258,1674,4230,1674,3347,1670,3347,1670,3339,2694,3339,2694,2837,5515,5515,902,5515,1674,1545,5515,3347,4491,3347,6547,3339,4499,3339,5515,1674,902,1674,1930,902,3347,1670,3347,902,3339,2694,3339,3347,1670,3347,1666,3339,2182,3339,1674,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s1119], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1119) b1119 <|
    PetersenLocalChildren.nil
theorem b1122 : Blocked tgt 6 s1122 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6546,1418,1418,2450,9545,9157,1418,9157,1418,9929,1802,1418,394,394,1418,9925,1418,10949,3338,1418,1418,6868,9482,1418,12997,9157,11092,9157,13513,9929,12485,9929,12997,9925,12489,9925,12997,10949,11336,10949,4741,12933,4805,4741,9673,8645,9929,9673,9157,8649,9925,9157,9157,3338,10949,9157,901,965,9093,901,2834,9925,9921,9921,9929,10437,11465,9929,1673,1737,9865,1673,9925,10441,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1123 : Blocked tgt 6 s1123 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1123 6 _ le
  decide +kernel
theorem b1125 : Blocked tgt 6 s1125 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1125 6 _ le
  decide +kernel
theorem b1126 : Blocked tgt 6 s1126 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [12481,9929,13513,9929,1418,1418,13513,9673,9544,9673,3346,13513,13513,9921,13513,11465,3338,11465,5257,13449,5321,5257,1802,9929,9929,1802,9929,9673,8641,9673,9921,9929,9921,2834,9929,11465,10433,9929,1673,9865,1737,1673,9544,9673,9544,9673,3346,9921,3346,9921,3338,11465,3338,11465,5514,5320,9482,5514,8649,8649,9673,9153,9673,3082,11465,9673,1417,1481,9609,1417,9921,11465,10433,11465,1665,1729,9857,1665,3209,3273,11401,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1127 : Blocked tgt 6 s1127 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1127 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
