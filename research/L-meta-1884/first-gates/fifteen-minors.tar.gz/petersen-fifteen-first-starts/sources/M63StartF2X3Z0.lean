import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_0 : NoAtMost (0xfff0fff0fff0fff0 :: inputs 6) tgt 7 := by
  change NoAtMost [0xfff0fff0fff0fff0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1024] [194,390,195,455,196,396,835,839,390,390,455,455,196,716,839,839,714,714,715,715,716,716,843,843,390,390,455,455,716,716,1351,1351,1106,1366,195,455,1236,396,835,839,1366,1366,455,455,1236,716,839,839,714,714,715,715,716,716,843,843,1366,1366,455,455,716,716,2375,2375,2146,2406,195,455,2276,2476,835,839,2406,2406,455,455,2276,2796,839,839,2666,2666,715,715,2796,2796,843,843,2406,2406,455,455,2796,2796,1351,1351,3186,3446,195,455,3316,2476,835,839,3446,3446,455,455,3316,2796,839,839,2666,2666,715,715,2796,2796,843,843,3446,3446,455,455,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1024], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1024) b1024 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_0
end PetersenSmallStarts.M63
