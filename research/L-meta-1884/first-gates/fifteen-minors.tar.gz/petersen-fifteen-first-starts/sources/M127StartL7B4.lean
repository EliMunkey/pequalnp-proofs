import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B7
import M127StartL6B5
import M127StartL6B0
import M127StartL6B8
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b205 : Blocked tgt 7 s205 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s205 7 _ le
  decide +kernel
theorem b206 : Blocked tgt 7 s206 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s206 7 _ le
  decide +kernel
theorem b207 : Blocked tgt 7 s207 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s207 7 _ le
  decide +kernel
theorem b208 : Blocked tgt 7 s208 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s208 7 _ le
  decide +kernel
theorem b209 : Blocked tgt 7 s209 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s209 7 _ le
  decide +kernel
theorem b210 : Blocked tgt 7 s210 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s210 7 _ le
  decide +kernel
theorem b211 : Blocked tgt 7 s211 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s211 7 _ le
  decide +kernel
theorem b212 : Blocked tgt 7 s212 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s212 7 _ le
  decide +kernel
theorem b213 : Blocked tgt 7 s213 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s213 7 _ le
  decide +kernel
theorem b214 : Blocked tgt 7 s214 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s214 7 _ le
  decide +kernel
theorem b215 : Blocked tgt 7 s215 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s215 7 _ le
  decide +kernel
theorem b216 : Blocked tgt 7 s216 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s216 7 _ le
  decide +kernel
theorem b217 : Blocked tgt 7 s217 := by
  apply PetersenFastNode.node (nxt := #[s218,s219,s151,s220,s221,s222,s223,s224,s18,s225,s226,s227,s228,s229,s231,s234]) (hints := [1434,13013,1434,10980,0,1,9173,13013,11108,9173,2,3,13529,13529,1818,9945,13013,9945,12501,13013,1818,9945,13529,9945,13013,13013,3362,9941,13529,9941,12505,13529,3362,9941,13013,9941,13013,13013,3354,10965,4,10965,3354,5,3354,10965,13013,10965,4757,4757,9498,12949,13013,6,4821,13013,9498,4757,4757,7,11108,15076,11108,1434,1434,8,11108,1434,11108,11236,15076,9,1434,1434,1818,9945,15076,9945,1818,15076,1818,9945,1434,9945,2466,2466,3362,9941,1434,9941,3362,1434,3362,9941,2466,9941,1434,1434,3354,10965,2466,10965,3354,2466,3354,10965,1434,10965,1434,1434,9498,6884,15076,10,9498,15076,9498,1434,1434,11,9945,9560,9945,1562,11108,1818,9945,11108,9945,9560,9560,1818,9941,11108,9941,3106,9560,3362,9941,9560,9941,11108,11108,3362,10965,9044,10965,9060,11108,3354,10965,11108,10965,9044,9044,3354,2852,2852,12,2916,11108,9498,11044,11108,13,2852,2852,9498,2850,2850,3362,9941,9945,9941,9937,9945,3362,9937,2850,9941,9945,9945,11481,10453,2850,10965,11481,2850,11481,9945,9945,10965,1689,1689,9498,1753,9945,14,9881,9945,9498,1689,1689,15,9941,9941,10965,10457,3362,11481,10965,3362,10965,9941,9941,11481,1685,1685,10530,1749,9941,9498,9877,9941,10530,1685,1685,9498,2709,2709,9498,2773,10965,10530,10901,10965,9498,2709,2709,10530]) (by decide +kernel)
  change ∀ b ∈ [s218,s219,s151,s220,s221,s222,s223,s224,s18,s225,s226,s227,s228,s229,s231,s234], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s218) b218 <|
    PetersenLocalChildren.push (x := s219) b219 <|
    PetersenLocalChildren.push (x := s151) b151 <|
    PetersenLocalChildren.push (x := s220) b220 <|
    PetersenLocalChildren.push (x := s221) b221 <|
    PetersenLocalChildren.push (x := s222) b222 <|
    PetersenLocalChildren.push (x := s223) b223 <|
    PetersenLocalChildren.push (x := s224) b224 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s225) b225 <|
    PetersenLocalChildren.push (x := s226) b226 <|
    PetersenLocalChildren.push (x := s227) b227 <|
    PetersenLocalChildren.push (x := s228) b228 <|
    PetersenLocalChildren.push (x := s229) b229 <|
    PetersenLocalChildren.push (x := s231) b231 <|
    PetersenLocalChildren.push (x := s234) b234 <|
    PetersenLocalChildren.nil
theorem b235 : Blocked tgt 7 s235 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s235 7 _ le
  decide +kernel
theorem b236 : Blocked tgt 7 s236 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s236 7 _ le
  decide +kernel
theorem b237 : Blocked tgt 7 s237 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s237 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
