import M251StartData
import M251StartPins0
import M251StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b30 : Blocked tgt 6 s30 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s30 6 _ le
  decide +kernel
theorem b35 : Blocked tgt 6 s35 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2966,2708,2710,2710,2966,9157,3482,2454,3866,3482,2966,2458,3862,2966,9158,918,11078,9158,2966,966,11030,2966,6932,9157,6932,9157,7450,3866,6422,3866,6934,9925,6426,9925,13126,10949,4886,10949,6934,11030,4934,6934,8641,8645,9153,8641,9157,3862,9925,9157,9157,11078,10949,9157,901,965,9093,901,9409,9413,9409,9921,10433,10437,10433,10945,3866,1866,11546,3866,9925,1814,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b36 : Blocked tgt 6 s36 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s36 6 _ le
  decide +kernel
theorem b37 : Blocked tgt 6 s37 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s37 6 _ le
  decide +kernel
theorem b38 : Blocked tgt 6 s38 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s38 6 _ le
  decide +kernel
theorem b39 : Blocked tgt 6 s39 := by
  apply PetersenFastNode.node (nxt := #[s40]) (hints := [6551,2455,2197,2455,8642,8642,7451,3867,6423,3867,9410,3863,9410,3863,10434,11079,10434,11079,6935,11031,4935,6935,2197,2455,2455,2197,3483,3483,2455,9410,3479,2455,8647,407,10695,8647,2455,455,10647,2455,3609,3867,12738,3867,9410,3863,9410,3863,10434,11079,10434,11079,4482,11031,12674,11031,0,3863,3859,3859,10059,1819,11595,10059,3867,1867,11547,3867,10055,1815,11079,10055,3863,1863,11031,3863,2178,11031,11015,11015]) (by decide +kernel)
  change ∀ b ∈ [s40], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.nil
theorem b41 : Blocked tgt 6 s41 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [(false,(1,false),(4,true))] s41 6 _ le
  decide +kernel
theorem b42 : Blocked tgt 6 s42 := by
  apply PetersenFastNode.node (nxt := #[s43]) (hints := [6935,967,1225,6935,902,902,7451,3867,6423,3867,1670,3863,1670,3863,2694,11079,2694,11079,6935,11031,4935,6935,6933,967,967,4998,3867,455,3867,1483,3863,459,3863,967,967,2694,3015,967,2967,2967,4482,3867,4994,3867,1670,3863,1670,3863,2694,11079,2694,11079,6933,11031,4998,11031,1154,3863,3859,3859,10059,1819,11595,10059,3867,1867,11547,3867,10055,1815,11079,10055,3863,1863,11031,3863,0,11031,11015,11015]) (by decide +kernel)
  change ∀ b ∈ [s43], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.nil
theorem b44 : Blocked tgt 6 s44 := by
  intro k le c
  apply rejects_sound r2 i6 6 tgt small2 hot2 [(false,(1,false),(5,true))] s44 6 _ le
  decide +kernel
theorem b45 : Blocked tgt 6 s45 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [(false,(1,false),(4,true))] s45 6 _ le
  decide +kernel
theorem b46 : Blocked tgt 6 s46 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6418,3866,7450,3866,7450,3482,3224,3482,7448,8641,9921,7450,7450,3858,13642,11594,5402,11594,7450,11546,5450,7450,3866,3482,2450,3482,12737,3866,3866,3608,3858,9409,10058,11594,1818,10058,3866,11546,1866,3866,3224,3482,3482,3224,2450,3482,3482,2450,9674,1434,11594,9674,3482,1482,11546,3482,9921,3858,7448,3858,11336,11594,11336,11594,7448,11546,11288,11546,10050,11594,10562,11594,3858,11546,10514,11546,2177,11546,11530,11530]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b47 : Blocked tgt 6 s47 := by
  intro k le c
  apply rejects_sound r2 i6 6 tgt small2 hot2 [(false,(1,false),(5,true))] s47 6 _ le
  decide +kernel
theorem b48 : Blocked tgt 6 s48 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4870,6934,11030,6934,11030,2966,902,2966,4997,11030,11030,6932,11546,3866,1802,3866,11030,3862,1798,3862,11014,2693,6934,2966,2708,2966,6932,901,7450,3866,6422,3866,6934,3862,6426,3862,10885,6934,6934,4870,2708,2966,2966,2708,3482,2454,3866,3482,2966,2458,3862,2966,902,2966,2966,902,3608,3866,3608,3866,3604,3862,3604,3862,4997,6932,6932,11014,1153,3862,3858,3858,1802,3866,3866,1802,1798,3862,3862,1798]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M251
