import M127StartData
import M127StartPins0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b537 : Blocked tgt 6 s537 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7466,2693,4836,7466,2693,901,13156,901,3209,1673,2181,1673,2693,1669,2185,1669,2693,4741,3370,2693,7466,2693,2693,7466,5352,901,5608,901,5930,1673,5930,5352,9733,1669,5352,1669,2756,4741,5320,4741,5546,5546,1417,389,1673,1417,901,393,1669,901,901,9576,4741,901,4900,901,901,13608,4898,1669,1665,1665,1673,4229,5257,1673,5930,1673,1673,5930,1669,4233,4741,1669,7458,1669,1669,13610,9482,4741,4741,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b538 : Blocked tgt 6 s538 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s538 6 _ le
  decide +kernel
theorem b539 : Blocked tgt 6 s539 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s539 6 _ le
  decide +kernel
theorem b543 : Blocked tgt 6 s543 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(1,true),(3,false))] s543 6 _ le
  decide +kernel
theorem b547 : Blocked tgt 6 s547 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s547 6 _ le
  decide +kernel
theorem b548 : Blocked tgt 6 s548 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s548 6 _ le
  decide +kernel
theorem b549 : Blocked tgt 6 s549 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s549 6 _ le
  decide +kernel
theorem b550 : Blocked tgt 6 s550 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s550 6 _ le
  decide +kernel
theorem b552 : Blocked tgt 6 s552 := by
  apply PetersenFastNode.node (nxt := #[s553,s555]) (hints := [12999,1420,9159,9159,1420,12487,1804,1420,396,396,1420,12999,1420,2452,1420,0,3340,1420,1420,4807,9484,1420,9546,1548,9802,9546,9799,9546,9799,10055,10966,9031,10966,11094,10951,9046,10951,9030,2838,2902,11030,2838,2836,1804,1804,2836,2836,1804,1804,2836,1804,788,3340,1804,1804,1610,9484,1804,3348,3348,9799,3340,10951,3340,10516,9484,10516,9484,1,3340,10950,3340,10516,9484,10516,9484,3340,8468,9484,3340]) (by decide +kernel)
  change ∀ b ∈ [s553,s555], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s553) b553 <|
    PetersenLocalChildren.push (x := s555) b555 <|
    PetersenLocalChildren.nil
theorem b556 : Blocked tgt 6 s556 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(true,(1,false),(4,false))] s556 6 _ le
  decide +kernel
theorem b557 : Blocked tgt 6 s557 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3338,1418,386,1418,10949,9576,9060,10949,11465,9929,10437,9929,10949,9925,10441,9925,10949,12997,3338,10949,2693,10885,2757,2693,9576,1418,9576,9704,1418,9801,1802,1418,394,394,1418,9925,10948,1418,1418,12997,1418,5352,9482,1418,9929,1802,9929,9576,9925,9576,9925,9060,9157,9157,804,9482,9512,9482,770,9925,9921,9921,9929,12485,13513,9929,1673,1737,9865,1673,9925,12489,12997,9925,1669,1733,9861,1669,4741,4805,12933,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b558 : Blocked tgt 6 s558 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s558 6 _ le
  decide +kernel
theorem b562 : Blocked tgt 6 s562 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(1,false),(5,true))] s562 6 _ le
  decide +kernel
theorem b563 : Blocked tgt 6 s563 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2693,7466,2693,7466,13610,5546,5288,5546,901,901,1673,5930,1673,5930,1669,13610,1669,7458,4741,13578,4741,9482,7466,5546,4514,5546,2693,7466,7466,2693,7466,5930,4898,5930,7458,7466,7458,1669,3338,7434,3370,3338,5288,5546,5546,9093,5546,1545,5930,5546,4522,4522,5546,6562,1418,1450,5514,1418,1673,5930,1673,5930,1669,7458,1669,7458,4741,9512,4741,9093,4898,5930,5930,4898,1802,1834,5898,1802,3330,3362,7426,3330]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b564 : Blocked tgt 6 s564 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s564 6 _ le
  decide +kernel
theorem b565 : Blocked tgt 6 s565 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4741,9482,4741,13578,9482,1418,6804,1418,901,901,1673,1802,1673,1802,1669,9482,1669,7442,2693,3338,2693,3338,5514,1418,1450,1418,4741,9093,11028,4741,5898,1802,1834,1802,7442,1669,3346,3346,7434,3338,3370,3338,9480,1418,1418,9093,1418,1545,1802,1418,394,394,1418,6546,1418,4498,3338,1418,1673,1802,1673,1802,1669,7442,1669,7442,2693,3338,2693,3338,2834,1802,1802,2834,1802,786,3338,1802,1669,3338,7426,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
