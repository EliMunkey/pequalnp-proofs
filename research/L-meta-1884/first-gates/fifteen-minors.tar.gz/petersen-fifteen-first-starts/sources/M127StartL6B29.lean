import M127StartData
import M127StartPins1
import M127StartPins0
import M127StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b984 : Blocked tgt 6 s984 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s984 6 _ le
  decide +kernel
theorem b985 : Blocked tgt 6 s985 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s985 6 _ le
  decide +kernel
theorem b998 : Blocked tgt 6 s998 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s998 6 _ le
  decide +kernel
theorem b999 : Blocked tgt 6 s999 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s999 6 _ le
  decide +kernel
theorem b1000 : Blocked tgt 6 s1000 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1000 6 _ le
  decide +kernel
theorem b1001 : Blocked tgt 6 s1001 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1001 6 _ le
  decide +kernel
theorem b1002 : Blocked tgt 6 s1002 := by
  apply PetersenFastNode.node (nxt := #[s1003,s1004,s1005]) (hints := [8968,904,0,904,6871,4744,2775,2775,1805,1676,1805,1676,3349,1672,3349,1672,3341,2696,3341,2696,1421,1421,904,11095,1420,392,1676,1420,904,396,1672,904,904,3341,2696,904,1,904,904,9485,5260,1676,4232,1676,4744,1672,4236,1672,4744,2696,11339,2696,2,4744,4744,9485,2837,1672,1668,1668,1676,2184,3212,1676,1805,1676,1676,1805,1672,2188,2696,1672,3349,1672,1672,3349,3341,2696,2696,3341]) (by decide +kernel)
  change ∀ b ∈ [s1003,s1004,s1005], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1003) b1003 <|
    PetersenLocalChildren.push (x := s1004) b1004 <|
    PetersenLocalChildren.push (x := s1005) b1005 <|
    PetersenLocalChildren.nil
theorem b1006 : Blocked tgt 6 s1006 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1006 6 _ le
  decide +kernel
theorem b1007 : Blocked tgt 6 s1007 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [11092,12997,10964,10964,1418,9929,1802,1418,2194,9925,3218,9925,1418,402,3210,1418,9029,9029,1418,9157,1418,6868,9482,1418,13513,9929,12485,9929,12997,9925,12489,9925,12997,9044,11092,12997,12997,9157,11092,9157,4741,12933,4805,4741,2834,9925,9921,9921,9929,786,3338,9929,9673,8645,9673,9929,1673,1737,9865,1673,9925,3338,3330,9925,9157,8649,9157,9925,1669,1733,9861,1669,9157,10949,3338,8466,9482,3338,901,965,9093,901]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1008 : Blocked tgt 6 s1008 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9029,9029,9157,1418,9157,9028,9673,8645,9929,9673,9157,8649,9925,9157,9157,3338,901,965,9093,901,11092,1418,1418,10964,1418,9929,1802,1418,386,394,1410,386,1418,10949,2194,1418,1418,6868,9482,1418,13513,1802,12485,1802,12997,9925,12489,9925,12997,10949,11076,10949,4741,9482,4805,9482,770,778,1794,770,1802,10437,11465,1802,1802,1737,9482,1802,9925,10441,10949,9925,8450,8458,8450,9474,9482,2757,9482,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1009 : Blocked tgt 6 s1009 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1009 6 _ le
  decide +kernel
theorem b1010 : Blocked tgt 6 s1010 := by
  apply PetersenFastNode.node (nxt := #[s1011]) (hints := [9483,1419,6805,1419,902,902,4742,0,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,8966,1419,1419,9094,6805,1419,1419,2709,1419,1674,1803,1419,2451,395,3347,2451,1419,403,3339,1419,4742,11029,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,5258,1803,4230,1803,4742,3347,4234,3347,4742,3339,3081,3339,2835,779,3347,2835,1803,787,3339,1803,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s1011], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1011) b1011 <|
    PetersenLocalChildren.nil
theorem b1012 : Blocked tgt 6 s1012 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10964,9029,11092,10964,1418,9929,1802,1418,2450,394,3346,2450,1418,402,3338,1418,12996,1418,1418,12996,1418,2772,9482,1418,9673,8645,9929,9673,9157,8649,9925,9157,9157,9044,10949,9157,9157,9028,901,965,9093,901,2834,9925,9921,9921,9929,10437,11465,9929,13513,9929,9929,12485,1673,1737,9865,1673,9925,10441,10949,9925,12997,9925,9925,12489,1669,1733,9861,1669,10949,11336,2693,2757,10885,2693,4741,12933,4805,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1013 : Blocked tgt 6 s1013 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2450,1418,2450,1418,12997,9157,11092,9157,13513,9929,12485,9929,12997,9925,12489,9925,10949,10949,4741,12933,4805,4741,9029,9029,1418,9157,1418,9929,1802,1418,386,394,1410,386,1418,2450,2450,1418,1418,2772,9482,1418,9673,8645,9929,9673,9157,8649,9925,9157,9157,11092,11076,9157,901,965,9093,901,770,9925,9921,9921,9929,2834,2834,9929,1673,1737,9865,1673,9925,3346,3346,9925,1669,1733,9861,1669,9482,10514,9482,10514]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1014 : Blocked tgt 6 s1014 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s1014 6 _ le
  decide +kernel
theorem b1015 : Blocked tgt 6 s1015 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,1418,6804,1418,9093,901,965,901,4741,4741,9865,1673,1737,1673,9861,1669,1733,1669,10885,2693,2757,2693,773,773,1418,901,6804,1418,1418,6804,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,901,11028,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,5321,1673,4293,1673,4805,1669,4297,1669,4805,2693,3080,2693,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
