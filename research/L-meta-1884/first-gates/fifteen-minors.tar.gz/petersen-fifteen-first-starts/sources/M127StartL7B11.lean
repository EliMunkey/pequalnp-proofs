import M127StartData
import M127StartPins0
import M127StartL6B0
import M127StartL6B16
import M127StartL6B17
import M127StartL6B8
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b475 : Blocked tgt 7 s475 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s475 7 _ le
  decide +kernel
theorem b476 : Blocked tgt 7 s476 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s476 7 _ le
  decide +kernel
theorem b477 : Blocked tgt 7 s477 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s477 7 _ le
  decide +kernel
theorem b478 : Blocked tgt 7 s478 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s478 7 _ le
  decide +kernel
theorem b479 : Blocked tgt 7 s479 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s479 7 _ le
  decide +kernel
theorem b480 : Blocked tgt 7 s480 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s480 7 _ le
  decide +kernel
theorem b481 : Blocked tgt 7 s481 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s481 7 _ le
  decide +kernel
theorem b482 : Blocked tgt 7 s482 := by
  apply PetersenFastNode.node (nxt := #[s14,s483,s484,s485,s242,s243,s486,s487,s488,s489,s490,s491,s492,s493]) (hints := [15106,15106,15234,9043,0,9171,15234,1,15234,15106,15106,9171,5944,5366,5944,9751,15106,9879,5944,15106,5944,6072,5366,9879,7488,15106,7488,9811,5366,9939,7488,5366,7488,15106,15106,9939,7480,13042,7480,13058,15106,10963,7480,15106,7480,13042,13042,10963,10978,10978,2,11010,15106,13011,15074,15106,3,10978,10978,13011,13624,6850,13624,6914,15106,4,5560,15106,13624,5560,6850,5,1431,1431,9879,467,9171,5944,9879,9171,9879,1431,1431,5944,9171,9171,9939,407,1431,7488,9939,1431,9939,9171,9171,7488,9171,9171,10963,13186,15234,7480,10963,15234,10963,9171,9171,7480,9171,9171,13011,11138,15234,6,13011,15234,13011,9171,9171,7,915,915,8,979,9171,13624,9107,9171,9,915,915,13624,6976,6976,7488,9879,9879,9939,9871,9879,7488,9871,6976,9939,3223,9879,3223,2259,6976,10963,3223,6976,3223,9879,9879,10963,5271,9879,5271,4307,5944,13011,5271,5944,5271,9879,9879,13011,1687,5944,13624,1687,9879,10,9879,9879,13624,5944,5944,11,9939,9939,10963,2199,7488,3223,10963,7488,10963,9939,9939,3223,9939,9939,13011,4247,7488,5271,13011,7488,13011,9939,9939,5271,1683,1683,14656,1747,9939,13624,9875,9939,14656,1683,1683,13624,10963,10963,13011,3384,7480,12,13011,7480,13011,10963,10963,13,2707,2707,13624,2771,10963,14656,10899,10963,13624,2707,2707,14656,4755,4755,9496,4819,13011,13624,12947,13011,9496,4755,4755,13624]) (by decide +kernel)
  change ∀ b ∈ [s14,s483,s484,s485,s242,s243,s486,s487,s488,s489,s490,s491,s492,s493], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s483) b483 <|
    PetersenLocalChildren.push (x := s484) b484 <|
    PetersenLocalChildren.push (x := s485) b485 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s486) b486 <|
    PetersenLocalChildren.push (x := s487) b487 <|
    PetersenLocalChildren.push (x := s488) b488 <|
    PetersenLocalChildren.push (x := s489) b489 <|
    PetersenLocalChildren.push (x := s490) b490 <|
    PetersenLocalChildren.push (x := s491) b491 <|
    PetersenLocalChildren.push (x := s492) b492 <|
    PetersenLocalChildren.push (x := s493) b493 <|
    PetersenLocalChildren.nil
theorem b494 : Blocked tgt 7 s494 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s494 7 _ le
  decide +kernel
theorem b495 : Blocked tgt 7 s495 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s495 7 _ le
  decide +kernel
theorem b496 : Blocked tgt 7 s496 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s496 7 _ le
  decide +kernel
theorem b497 : Blocked tgt 7 s497 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s497 7 _ le
  decide +kernel
theorem b498 : Blocked tgt 7 s498 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s498 7 _ le
  decide +kernel
theorem b499 : Blocked tgt 7 s499 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s499 7 _ le
  decide +kernel
theorem b500 : Blocked tgt 7 s500 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s500 7 _ le
  decide +kernel
theorem b501 : Blocked tgt 7 s501 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s501 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
