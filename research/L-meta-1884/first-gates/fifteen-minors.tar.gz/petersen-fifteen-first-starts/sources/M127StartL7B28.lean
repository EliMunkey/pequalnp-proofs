import M127StartData
import M127StartPins0
import M127StartL6B28
import M127StartL6B27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b954 : Blocked tgt 7 s954 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s954 7 _ le
  decide +kernel
theorem b955 : Blocked tgt 7 s955 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s955 7 _ le
  decide +kernel
theorem b956 : Blocked tgt 7 s956 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s956 7 _ le
  decide +kernel
theorem b957 : Blocked tgt 7 s957 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s957 7 _ le
  decide +kernel
theorem b958 : Blocked tgt 7 s958 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s958 7 _ le
  decide +kernel
theorem b959 : Blocked tgt 7 s959 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s959 7 _ le
  decide +kernel
theorem b960 : Blocked tgt 7 s960 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s960 7 _ le
  decide +kernel
theorem b961 : Blocked tgt 7 s961 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s961 7 _ le
  decide +kernel
theorem b962 : Blocked tgt 7 s962 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s962 7 _ le
  decide +kernel
theorem b963 : Blocked tgt 7 s963 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s963 7 _ le
  decide +kernel
theorem b964 : Blocked tgt 7 s964 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s964 7 _ le
  decide +kernel
theorem b965 : Blocked tgt 7 s965 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s965 7 _ le
  decide +kernel
theorem b966 : Blocked tgt 7 s966 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s966 7 _ le
  decide +kernel
theorem b967 : Blocked tgt 7 s967 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s967 7 _ le
  decide +kernel
theorem b968 : Blocked tgt 7 s968 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s968 7 _ le
  decide +kernel
theorem b969 : Blocked tgt 7 s969 := by
  apply PetersenFastNode.node (nxt := #[s970,s948,s971,s927]) (hints := [13614,0,1,13614,13614,6582,6840,13614,905,905,1677,5934,1677,5934,1673,7478,1673,7478,13614,7470,12598,7470,4745,13582,4745,9486,5550,5550,15160,9097,15160,9097,5934,1677,5934,1677,7478,1673,7478,1673,7470,2697,2,4745,3,4745,6840,6582,6582,9097,5934,1677,5934,6582,6582,1673,7478,6582,7470,6582,7598,2454,2486,6550,2454,1677,5934,1677,5934,1673,7478,1673,7478,9097,7470,15144,7470,4745,11064,4745,9097,6966,4910,7478,6966,5934,4918,7470,5934,1806,1838,5902,1806,1673,7470,7462,7462,3350,3382,7446,3350,3342,3374,7438,3342]) (by decide +kernel)
  change ∀ b ∈ [s970,s948,s971,s927], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s970) b970 <|
    PetersenLocalChildren.push (x := s948) b948 <|
    PetersenLocalChildren.push (x := s971) b971 <|
    PetersenLocalChildren.push (x := s927) b927 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
