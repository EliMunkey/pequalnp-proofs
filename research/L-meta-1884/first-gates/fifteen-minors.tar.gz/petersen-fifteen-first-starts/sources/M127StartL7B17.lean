import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B20
import M127StartL6B8
import M127StartL6B21
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b642 : Blocked tgt 7 s642 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s642 7 _ le
  decide +kernel
theorem b643 : Blocked tgt 7 s643 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s643 7 _ le
  decide +kernel
theorem b644 : Blocked tgt 7 s644 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s644 7 _ le
  decide +kernel
theorem b645 : Blocked tgt 7 s645 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s645 7 _ le
  decide +kernel
theorem b646 : Blocked tgt 7 s646 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s646 7 _ le
  decide +kernel
theorem b647 : Blocked tgt 7 s647 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s647 7 _ le
  decide +kernel
theorem b648 : Blocked tgt 7 s648 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s648 7 _ le
  decide +kernel
theorem b649 : Blocked tgt 7 s649 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s649 7 _ le
  decide +kernel
theorem b650 : Blocked tgt 7 s650 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s650 7 _ le
  decide +kernel
theorem b651 : Blocked tgt 7 s651 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s651 7 _ le
  decide +kernel
theorem b652 : Blocked tgt 7 s652 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s652 7 _ le
  decide +kernel
theorem b653 : Blocked tgt 7 s653 := by
  apply PetersenFastNode.node (nxt := #[s654,s655,s242,s243,s656,s657,s658,s659,s660,s661,s662,s663]) (hints := [6912,6912,15232,913,5558,913,7168,5558,15232,6912,6912,913,5558,5558,5942,9813,6912,9941,5942,6912,5942,5558,5558,9941,7486,6912,7486,5558,5558,9873,7486,5558,7486,7614,6912,9873,5558,5558,7478,4864,6912,2705,7478,6912,7478,5558,5558,2705,1430,1430,0,1462,5558,4753,5526,5558,1,1430,1430,4753,5558,5558,13622,6912,6912,2,13622,6912,13622,5558,5558,3,9685,9685,9941,401,913,5942,9941,913,9941,9685,9685,5942,913,913,9873,469,9685,7486,9873,9685,9873,913,913,7486,913,913,2705,13184,15232,7478,2705,15232,2705,913,913,7478,913,913,4753,11136,15232,4,4753,15232,4753,913,913,5,1429,1429,6,913,913,13622,913,913,7,1429,1429,13622,6974,6974,7486,9873,9941,9873,9869,9941,7486,9869,6974,9873,9941,9941,11477,2193,6974,2705,11477,6974,11477,9941,9941,2705,9941,9941,13525,4241,5942,4753,13525,5942,13525,9941,9941,4753,1685,1685,13622,1749,9941,8,9877,9941,13622,1685,1685,9,2705,9873,2705,2261,7486,11477,2705,7486,2705,9873,9873,11477,4753,9873,4753,4309,7486,13525,4753,7486,4753,9873,9873,13525,1681,7486,14654,1681,9873,13622,9873,9873,14654,7486,7486,13622,2705,2705,4753,3382,7478,10,4753,7478,4753,2705,2705,11,3221,3221,13622,2705,2705,14654,2705,2705,13622,3221,3221,14654,5269,5269,9494,4753,4753,13622,4753,4753,9494,5269,5269,13622]) (by decide +kernel)
  change ∀ b ∈ [s654,s655,s242,s243,s656,s657,s658,s659,s660,s661,s662,s663], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s654) b654 <|
    PetersenLocalChildren.push (x := s655) b655 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s656) b656 <|
    PetersenLocalChildren.push (x := s657) b657 <|
    PetersenLocalChildren.push (x := s658) b658 <|
    PetersenLocalChildren.push (x := s659) b659 <|
    PetersenLocalChildren.push (x := s660) b660 <|
    PetersenLocalChildren.push (x := s661) b661 <|
    PetersenLocalChildren.push (x := s662) b662 <|
    PetersenLocalChildren.push (x := s663) b663 <|
    PetersenLocalChildren.nil
theorem b664 : Blocked tgt 7 s664 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s664 7 _ le
  decide +kernel
theorem b665 : Blocked tgt 7 s665 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s665 7 _ le
  decide +kernel
theorem b666 : Blocked tgt 7 s666 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s666 7 _ le
  decide +kernel
theorem b667 : Blocked tgt 7 s667 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s667 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
