import M15StartData
import M15StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 3 s0 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s0 3 _ le
  decide +kernel
theorem b1 : Blocked tgt 3 s1 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s1 3 _ le
  decide +kernel
theorem b2 : Blocked tgt 3 s2 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s2 3 _ le
  decide +kernel
theorem b3 : Blocked tgt 3 s3 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [100,100,186,234,200,186,50,178,58,50,184,234,200,234,116,56,196,116,98,106,226,98]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact

    PetersenLocalChildren.nil
theorem b4 : Blocked tgt 3 s4 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s4 3 _ le
  decide +kernel
theorem b5 : Blocked tgt 3 s5 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [100,185,100,184,186,201,50,58,178,50,185,202,200,185,49,57,177,49,98,106,226,98]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact

    PetersenLocalChildren.nil
theorem b6 : Blocked tgt 3 s6 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s6 3 _ le
  decide +kernel
theorem b7 : Blocked tgt 3 s7 := by
  intro k le c
  apply rejects_sound r2 i2 0 tgt small2 hot2 [] s7 3 _ le
  decide +kernel
theorem b8 : Blocked tgt 3 s8 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s8 3 _ le
  decide +kernel
theorem b9 : Blocked tgt 3 s9 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s9 3 _ le
  decide +kernel
theorem b10 : Blocked tgt 3 s10 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s10 3 _ le
  decide +kernel
theorem b11 : Blocked tgt 3 s11 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s11 3 _ le
  decide +kernel
theorem b12 : Blocked tgt 3 s12 := by
  intro k le c
  apply rejects_sound r2 i2 0 tgt small2 hot2 [] s12 3 _ le
  decide +kernel
theorem b13 : Blocked tgt 3 s13 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s13 3 _ le
  decide +kernel
theorem b14 : Blocked tgt 3 s14 := by
  intro k le c
  apply rejects_sound r1 i2 0 tgt small1 hot1 [] s14 3 _ le
  decide +kernel
end PetersenSmallStarts.M15
