import M55StartData
import M55StartPins0
import M55StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 4 s0 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s0 4 _ le
  decide +kernel
theorem b1 : Blocked tgt 4 s1 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s1 4 _ le
  decide +kernel
theorem b2 : Blocked tgt 4 s2 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s2 4 _ le
  decide +kernel
theorem b3 : Blocked tgt 4 s3 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s3 4 _ le
  decide +kernel
theorem b4 : Blocked tgt 4 s4 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s4 4 _ le
  decide +kernel
theorem b5 : Blocked tgt 4 s5 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s5 4 _ le
  decide +kernel
theorem b6 : Blocked tgt 4 s6 := by
  apply PetersenFastNode.node (nxt := #[s7]) (hints := [891,829,98,987,98,985,290,731,290,723,546,475,546,459,989,827,989,825,627,635,883,627,363,379,875,363,725,733,981,725,461,477,973,461,290,0,546,290]) (by decide +kernel)
  change ∀ b ∈ [s7], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.nil
theorem b8 : Blocked tgt 4 s8 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s8 4 _ le
  decide +kernel
theorem b9 : Blocked tgt 4 s9 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s9 4 _ le
  decide +kernel
theorem b10 : Blocked tgt 4 s10 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s10 4 _ le
  decide +kernel
theorem b11 : Blocked tgt 4 s11 := by
  apply PetersenFastNode.node (nxt := #[s12]) (hints := [627,627,422,230,725,230,290,418,294,290,422,678,0,422,725,230,725,230,723,821,723,883,355,678,867,678,98,102,226,98,230,213,678,230,546,550,546,674]) (by decide +kernel)
  change ∀ b ∈ [s12], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.nil
theorem b13 : Blocked tgt 4 s13 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s13 4 _ le
  decide +kernel
theorem b14 : Blocked tgt 4 s14 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s14 4 _ le
  decide +kernel
theorem b15 : Blocked tgt 4 s15 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s15 4 _ le
  decide +kernel
theorem b16 : Blocked tgt 4 s16 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s16 4 _ le
  decide +kernel
theorem b17 : Blocked tgt 4 s17 := by
  intro k le c
  apply rejects_sound r7 i2 0 tgt small7 hot7 [] s17 4 _ le
  decide +kernel
end PetersenSmallStarts.M55
