import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b10 : Blocked tgt 4 s10 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s10 4 _ le
  decide +kernel
theorem b33 : Blocked tgt 4 s33 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s33 4 _ le
  decide +kernel
theorem b34 : Blocked tgt 4 s34 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s34 4 _ le
  decide +kernel
theorem b128 : Blocked tgt 4 s128 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,713,841,197,713,389,837,201,389,389,1349,1544,389,712,841,776,841,1428,837,1812,837,388,1349,1412,1349,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b129 : Blocked tgt 4 s129 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,457,457,197,713,453,453,201,837,2373,1349,1544,1349,392,841,392,841,1428,837,1428,837,2372,1349,3396,1349,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b132 : Blocked tgt 4 s132 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [712,1104,713,841,776,713,193,705,201,193,713,1609,1544,713,712,841,776,841,1232,200,1552,1232,712,1609,1544,1609,1424,841,833,833,841,400,1609,841,1089,1097,1089,1601]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b166 : Blocked tgt 4 s166 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s166 4 _ le
  decide +kernel
theorem b209 : Blocked tgt 4 s209 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1428,714,906,776,714,1106,1618,202,1106,714,1610,210,714,712,906,776,906,1364,1682,1812,1682,452,1674,1348,1674,1426,394,1682,1426,906,402,1674,906,772,1674,1666,1666]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b221 : Blocked tgt 4 s221 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s221 4 _ le
  decide +kernel
theorem b270 : Blocked tgt 4 s270 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s270 4 _ le
  decide +kernel
theorem b299 : Blocked tgt 4 s299 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s299 4 _ le
  decide +kernel
theorem b429 : Blocked tgt 4 s429 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,1364,389,1364,713,841,197,713,453,837,201,453,453,1349,404,453,777,777,1364,841,1364,773,1812,1364,712,1349,1348,1348,1424,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b438 : Blocked tgt 4 s438 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1108,193,1426,193,1424,833,1556,833,1426,1089,402,1089,386,1428,1106,1428,1104,1812,833,1812,1234,194,210,1218,194,1428,1554,1812,1428,388,404,1412,388,772,788,1796,772]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b440 : Blocked tgt 4 s440 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s440 4 _ le
  decide +kernel
theorem b530 : Blocked tgt 4 s530 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,194,1349,453,388,453,1089,1345,1093,1089,1349,837,1666,837,388,453,388,453,386,1092,386,1218,1218,837,1666,837,193,197,449,193,453,1538,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b533 : Blocked tgt 4 s533 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1349,453,388,453,906,841,906,841,1349,837,772,837,714,714,713,197,841,713,453,201,837,453,388,453,453,388,386,837,833,833,906,841,841,906,1218,837,837,1666]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
