import M127StartData
import M127StartPins0
import M127StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b95 : Blocked tgt 5 s95 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s95 5 _ le
  decide +kernel
theorem b97 : Blocked tgt 5 s97 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s97 5 _ le
  decide +kernel
theorem b98 : Blocked tgt 5 s98 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s98 5 _ le
  decide +kernel
theorem b108 : Blocked tgt 5 s108 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s108 5 _ le
  decide +kernel
theorem b230 : Blocked tgt 5 s230 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,1418,2708,1418,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,8466,2693,773,773,1418,901,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b232 : Blocked tgt 5 s232 := by
  apply PetersenFastNode.node (nxt := #[s233]) (hints := [2709,2709,902,902,1418,1674,390,1418,4742,1670,394,1670,4742,2694,3081,2694,2837,0,2837,2965,1417,1674,1545,1674,3605,1670,3605,1670,4741,2694,6789,2694,1674,2837,1674,1801,1670,8457,1670,2837,2694,789,2694,773,3089,1670,1666,1666,1674,2182,3210,1674,1670,2186,2694,1670]) (by decide +kernel)
  change ∀ b ∈ [s233], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s233) b233 <|
    PetersenLocalChildren.nil
theorem b292 : Blocked tgt 5 s292 := by
  apply PetersenFastNode.node (nxt := #[s233]) (hints := [6837,6837,1418,1674,390,1418,774,1670,394,774,774,2694,7209,774,774,4742,0,774,5545,1674,5673,1674,6965,1670,7733,1670,4901,2694,6949,2694,2837,4742,6933,4742,7217,1670,1666,1666,1674,2182,3210,1674,1674,4230,5258,1674,1670,2186,2694,1670,1670,4234,4742,1670,2694,3113,4742,2694]) (by decide +kernel)
  change ∀ b ∈ [s233], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s233) b233 <|
    PetersenLocalChildren.nil
theorem b553 : Blocked tgt 5 s553 := by
  apply PetersenFastNode.node (nxt := #[s554]) (hints := [9545,1547,9801,9545,9798,9545,9798,10054,10965,9030,9173,9173,10950,9045,9158,9158,2837,2901,11029,2837,2835,1803,1803,2835,403,1803,1803,915,1419,787,1419,1803,1803,1609,9483,1803,403,1427,395,395,10950,1419,10515,9483,10515,9483,0,1419,387,1419,403,9483,8595,9483,1419,8467,9483,1419]) (by decide +kernel)
  change ∀ b ∈ [s554], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s554) b554 <|
    PetersenLocalChildren.nil
theorem b555 : Blocked tgt 5 s555 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(true,(1,false),(4,false)),(false,(1,false),(0,false))] s555 5 _ le
  decide +kernel
theorem b731 : Blocked tgt 5 s731 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3338,1418,386,1418,10949,9157,9028,9157,11465,9929,10437,9929,10949,9925,10441,9925,2693,10885,2757,2693,9544,9157,9544,9157,1418,9801,1802,1418,394,394,1418,9925,1418,2756,9482,1418,9673,8645,9929,9673,9157,8649,9925,9157,901,965,9093,901,770,9925,9921,9921,1673,1737,9865,1673,1669,1733,9861,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b824 : Blocked tgt 5 s824 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s824 5 _ le
  decide +kernel
theorem b832 : Blocked tgt 5 s832 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s832 5 _ le
  decide +kernel
theorem b833 : Blocked tgt 5 s833 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s833 5 _ le
  decide +kernel
theorem b840 : Blocked tgt 5 s840 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s840 5 _ le
  decide +kernel
theorem b928 : Blocked tgt 5 s928 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,1418,2708,1418,4741,901,2836,901,5257,1673,4229,1673,4741,1669,4233,1669,2693,2693,8466,4741,773,773,1418,901,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,3338,2949,901,2834,1669,1665,1665,1673,786,3338,1673,1669,3338,3330,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b930 : Blocked tgt 5 s930 := by
  apply PetersenFastNode.node (nxt := #[s931]) (hints := [1419,1419,13514,9674,9545,9674,2694,1670,12490,1670,3786,1738,2694,1738,5258,13450,5322,5258,9545,9674,9545,9674,2451,1670,3347,1670,3339,1738,3339,1738,5515,5321,9483,5515,902,8650,1670,902,1738,902,1738,1994,1418,1482,9610,1418,0,1670,1670,1730,787,1670,1670,1811,3339,1738,1674,1674]) (by decide +kernel)
  change ∀ b ∈ [s931], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s931) b931 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
