import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b483 : Blocked tgt 5 s483 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s483 5 _ le
  decide +kernel
theorem b484 : Blocked tgt 5 s484 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s484 5 _ le
  decide +kernel
theorem b485 : Blocked tgt 5 s485 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s485 5 _ le
  decide +kernel
theorem b486 : Blocked tgt 5 s486 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,2373,1364,1364,714,841,906,714,1106,837,1618,837,714,210,1610,714,389,389,714,453,2633,841,2117,841,2373,837,2121,837,2373,404,1428,2373,2373,453,1428,453,1426,837,833,833,841,402,1674,841,713,197,713,841,837,1674,1666,837,453,201,453,837,453,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b487 : Blocked tgt 5 s487 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [389,389,453,714,453,388,713,197,841,713,453,201,837,453,453,1674,1428,714,714,1364,714,841,906,714,194,202,706,194,714,1349,1106,714,2633,906,2117,906,2373,837,2121,837,2373,1349,1412,1349,386,394,898,386,906,1093,1609,906,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b488 : Blocked tgt 5 s488 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,389,1428,1364,714,841,906,714,1234,202,1682,1234,714,210,1674,714,2372,714,714,2372,713,197,841,713,453,201,837,453,453,404,1349,453,453,388,1426,837,833,833,841,1093,1609,841,2633,841,841,2117,837,1097,1349,837,2373,837,837,2121,1349,1544]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b489 : Blocked tgt 5 s489 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,714,1234,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,1349,1349,389,389,714,453,714,841,906,714,194,202,706,194,714,1234,1234,714,713,197,841,713,453,201,837,453,453,1428,1412,453,386,837,833,833,841,1426,1426,841,837,1682,1682,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b493 : Blocked tgt 5 s493 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s493 5 _ le
  decide +kernel
theorem b496 : Blocked tgt 5 s496 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,1428,453,776,841,776,841,1812,837,1812,837,2372,1349,3396,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b497 : Blocked tgt 5 s497 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,453,2373,453,1364,1364,2889,841,2373,841,2373,837,1812,837,2373,1349,1544,1349,1428,453,453,1428,713,841,197,713,453,837,201,453,453,1349,404,453,904,841,3412,841,1812,837,1812,837,2372,1349,3396,1349,1424,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b500 : Blocked tgt 5 s500 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2633,453,388,453,2633,841,2117,841,2113,837,2121,837,2373,1349,1674,1349,388,453,388,453,2762,841,402,841,1682,837,1682,837,1674,1349,1674,1349,713,197,841,713,453,201,837,453,453,388,1349,453,402,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b501 : Blocked tgt 5 s501 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,1349,1674,1349,1234,1234,2373,453,388,453,2633,841,2117,841,1682,837,1682,837,1674,1349,1349,1674,453,1546,453,1349,841,1093,841,1609,837,1097,837,1349,3152,453,3280,453,3282,841,906,841,1682,837,1682,837,713,197,841,713,453,201,837,453,1682,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b504 : Blocked tgt 5 s504 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,388,453,2633,841,2117,841,2373,1349,1674,1349,2373,837,2121,837,388,453,388,453,906,841,906,841,1674,1349,1674,1349,2242,837,2754,837,713,197,841,713,453,1546,1349,453,453,201,837,453,841,1093,1609,841,386,837,833,833,837,1097,837,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b505 : Blocked tgt 5 s505 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1674,1349,2373,1349,714,714,2633,453,388,453,2633,841,906,841,2885,837,2633,837,1674,1349,1349,1674,1349,453,388,453,1609,841,1093,841,1349,837,1097,837,2632,453,2760,453,906,841,906,841,1666,837,2762,837,713,197,841,713,453,201,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b508 : Blocked tgt 5 s508 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,2113,841,2117,841,2373,837,2121,837,2373,453,1428,453,2373,1349,1544,1349,776,841,776,841,3412,837,1554,837,1428,453,1428,453,2372,1349,3396,1349,1426,837,833,833,713,197,713,841,841,1093,1609,841,453,201,453,837,837,1097,1349,837,453,404,1349,453]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b509 : Blocked tgt 5 s509 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,1234,1234,1426,841,1426,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,453,1428,713,197,841,713,453,201,837,453,453,404,1349,453,1426,841,1426,841,3282,837,1812,837,2242,1349,3266,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
