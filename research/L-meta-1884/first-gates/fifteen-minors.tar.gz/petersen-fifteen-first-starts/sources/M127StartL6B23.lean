import M127StartData
import M127StartPins0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b773 : Blocked tgt 6 s773 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s773 6 _ le
  decide +kernel
theorem b774 : Blocked tgt 6 s774 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s774 6 _ le
  decide +kernel
theorem b775 : Blocked tgt 6 s775 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s775 6 _ le
  decide +kernel
theorem b776 : Blocked tgt 6 s776 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s776 6 _ le
  decide +kernel
theorem b777 : Blocked tgt 6 s777 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s777 6 _ le
  decide +kernel
theorem b778 : Blocked tgt 6 s778 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s778 6 _ le
  decide +kernel
theorem b779 : Blocked tgt 6 s779 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s779 6 _ le
  decide +kernel
theorem b780 : Blocked tgt 6 s780 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s780 6 _ le
  decide +kernel
theorem b781 : Blocked tgt 6 s781 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s781 6 _ le
  decide +kernel
theorem b782 : Blocked tgt 6 s782 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s782 6 _ le
  decide +kernel
theorem b797 : Blocked tgt 6 s797 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,9093,1417,901,901,13610,1673,5672,1673,14642,7474,1669,1669,2693,3209,2693,3209,4741,5257,4741,5257,5290,5290,5546,1417,5546,1673,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,1417,5930,1673,1417,393,393,1417,7474,1417,7466,3209,1417,1417,11060,5257,1417,6962,1673,1673,6962,1673,4914,3209,1673,1673,1834,5257,1673,2693,3209,7458,3209,3346,5257,7442,5257,3209,3370,5257,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b813 : Blocked tgt 6 s813 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s813 6 _ le
  decide +kernel
theorem b814 : Blocked tgt 6 s814 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s814 6 _ le
  decide +kernel
theorem b823 : Blocked tgt 6 s823 := by
  apply PetersenFastNode.node (nxt := #[s824]) (hints := [13611,2451,2709,13611,902,902,1674,5931,1674,5931,1670,3347,1670,3347,11563,3371,10515,3371,2694,13579,2694,9483,2709,2451,2451,2709,5931,1674,5931,2451,2451,1670,3347,2451,3371,3499,403,403,2451,2694,1674,5931,1674,5931,1670,3347,1670,3347,13077,3371,9094,3371,2694,11029,2694,9094,2835,4907,3347,2835,3371,2835,3371,3883,1803,1835,5899,1803,5653,3347,3347,3363,1670,3347,3347,1670,0,3371,3339,3339]) (by decide +kernel)
  change ∀ b ∈ [s824], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s824) b824 <|
    PetersenLocalChildren.nil
theorem b825 : Blocked tgt 6 s825 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s825 6 _ le
  decide +kernel
theorem b826 : Blocked tgt 6 s826 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4741,10514,4741,9482,10514,2450,2708,2450,901,901,1673,2834,1673,2834,1669,3346,1669,3346,2693,10514,2693,7434,5514,2450,1418,1418,4741,9093,11060,4741,1802,2834,1802,2834,7442,3346,3378,3346,7434,2693,3338,3338,2708,2450,2450,2708,2450,1673,2834,2450,2450,4490,3346,2450,402,402,2450,5514,1673,2834,1673,2834,1669,3346,1669,3346,2693,7434,2693,7434,2834,778,3346,2834,1802,2834,2834,1802,1669,3346,3346,7426]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
