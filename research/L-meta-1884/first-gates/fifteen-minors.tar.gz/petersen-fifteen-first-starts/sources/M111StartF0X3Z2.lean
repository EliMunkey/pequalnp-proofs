import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_2 : NoAtMost (0x5500550055005500 :: inputs 6) tgt 6 := by
  change NoAtMost [0x5500550055005500,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s29] [194,778,195,778,196,908,835,908,390,2698,455,2698,196,2700,839,2700,714,778,715,778,716,908,843,908,390,2698,455,2698,716,2700,1351,2700,1106,1818,195,1818,1236,1948,835,1948,1366,3738,455,3738,1236,3740,839,3740,1626,1818,715,1818,1756,1948,843,1948,1366,3738,455,3738,1756,3740,3740,3740,2210,2730,2275,2730,196,908,2915,908,2470,2730,2535,2730,196,196,2919,2919,2730,2730,2795,2730,716,908,2923,908,2470,2730,2535,2730,716,196,3431,3431,3186,3770,2275,3770,1236,1948,2915,1948,3446,3770,2535,3770,1236,1236,2919,2919,3706,3770,2795,3770,1756,1948,2923,1948,3446,3770,2535,3770,1756,1236,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s29], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_2
end PetersenSmallStarts.M111
