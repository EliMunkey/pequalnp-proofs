import M127StartData
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b584 : Blocked tgt 6 s584 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s584 6 _ le
  decide +kernel
theorem b585 : Blocked tgt 6 s585 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s585 6 _ le
  decide +kernel
theorem b586 : Blocked tgt 6 s586 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s586 6 _ le
  decide +kernel
theorem b587 : Blocked tgt 6 s587 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s587 6 _ le
  decide +kernel
theorem b588 : Blocked tgt 6 s588 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s588 6 _ le
  decide +kernel
theorem b589 : Blocked tgt 6 s589 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s589 6 _ le
  decide +kernel
theorem b590 : Blocked tgt 6 s590 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s590 6 _ le
  decide +kernel
theorem b591 : Blocked tgt 6 s591 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false)),(false,(0,false),(5,true))] s591 6 _ le
  decide +kernel
theorem b600 : Blocked tgt 6 s600 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9029,9029,9544,9157,15060,1418,1418,10964,1418,9801,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1418,6868,9482,1418,9157,11092,9673,8645,9929,9673,9157,8649,9925,9157,9157,3082,10949,9157,901,965,9093,901,13513,9929,12485,9929,12997,9925,12489,9925,12997,10949,11368,10949,4741,12933,4805,4741,2834,9925,9921,9921,9929,10437,11465,9929,1673,1737,9865,1673,9925,10441,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b601 : Blocked tgt 6 s601 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s601 6 _ le
  decide +kernel
theorem b602 : Blocked tgt 6 s602 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s602 6 _ le
  decide +kernel
theorem b603 : Blocked tgt 6 s603 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s603 6 _ le
  decide +kernel
theorem b604 : Blocked tgt 6 s604 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s604 6 _ le
  decide +kernel
theorem b605 : Blocked tgt 6 s605 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s605 6 _ le
  decide +kernel
theorem b606 : Blocked tgt 6 s606 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s606 6 _ le
  decide +kernel
theorem b620 : Blocked tgt 6 s620 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s620 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
