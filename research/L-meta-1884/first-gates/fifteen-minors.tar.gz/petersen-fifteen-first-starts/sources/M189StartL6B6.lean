import M189StartData
import M189StartPins0
import M189StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b123 : Blocked tgt 6 s123 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2469,1428,1364,1946,1364,1946,2010,1364,707,1812,707,3364,1219,3364,1219,2179,2179,2664,2243,1364,2664,1754,1754,2273,2277,2529,2273,2533,579,2917,2533,2533,1091,3429,2533,453,2533,2533,453,453,2533,2533,453,707,2661,707,2913,1219,3173,1219,3425,2243,2856,2243,2499,451,451,2856,1946,707,788,1219,707,707,2917,2243,707,837,707,707,837,1219,3429,2243,1219,1349,1219,1219,1349,2243,3738]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b124 : Blocked tgt 6 s124 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s124 6 _ le
  decide +kernel
theorem b125 : Blocked tgt 6 s125 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s125 6 _ le
  decide +kernel
theorem b126 : Blocked tgt 6 s126 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s126 6 _ le
  decide +kernel
theorem b127 : Blocked tgt 6 s127 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s127 6 _ le
  decide +kernel
theorem b128 : Blocked tgt 6 s128 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s128 6 _ le
  decide +kernel
theorem b129 : Blocked tgt 6 s129 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s129 6 _ le
  decide +kernel
theorem b130 : Blocked tgt 6 s130 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s130 6 _ le
  decide +kernel
theorem b131 : Blocked tgt 6 s131 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s131 6 _ le
  decide +kernel
theorem b132 : Blocked tgt 6 s132 := by
  apply PetersenFastNode.node (nxt := #[s133]) (hints := [1429,2210,1429,2665,1947,452,1813,708,1813,708,3365,1220,3365,1220,2180,2180,2665,2244,1755,1755,2274,1819,1817,2274,2274,580,2658,2274,2274,1092,3170,2274,1429,2244,2242,2242,1365,2274,2274,1429,708,1435,708,1427,1220,923,1220,907,2244,873,2244,1947,1947,2857,2011,1947,708,789,1220,708,708,610,2244,708,1365,708,708,1813,1220,1122,2244,1220,0,1220,1220,1349,2244,3739]) (by decide +kernel)
  change ∀ b ∈ [s133], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s133) b133 <|
    PetersenLocalChildren.nil
theorem b134 : Blocked tgt 6 s134 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s134 6 _ le
  decide +kernel
theorem b136 : Blocked tgt 6 s136 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s136 6 _ le
  decide +kernel
theorem b137 : Blocked tgt 6 s137 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s137 6 _ le
  decide +kernel
theorem b138 : Blocked tgt 6 s138 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s138 6 _ le
  decide +kernel
theorem b139 : Blocked tgt 6 s139 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s139 6 _ le
  decide +kernel
theorem b140 : Blocked tgt 6 s140 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s140 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
