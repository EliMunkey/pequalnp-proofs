import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b437 : Blocked tgt 6 s437 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s437 6 _ le
  decide +kernel
theorem b438 : Blocked tgt 6 s438 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s438 6 _ le
  decide +kernel
theorem b439 : Blocked tgt 6 s439 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s439 6 _ le
  decide +kernel
theorem b440 : Blocked tgt 6 s440 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s440 6 _ le
  decide +kernel
theorem b441 : Blocked tgt 6 s441 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s441 6 _ le
  decide +kernel
theorem b442 : Blocked tgt 6 s442 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s442 6 _ le
  decide +kernel
theorem b443 : Blocked tgt 6 s443 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s443 6 _ le
  decide +kernel
theorem b444 : Blocked tgt 6 s444 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [12714,4522,6836,4522,901,901,1665,5930,1665,5930,1669,7474,1669,7474,2693,7466,2693,7466,4741,13578,4741,9482,6836,4522,4522,6836,4522,1537,5930,4522,7474,4522,6578,6578,4522,4788,6570,4522,394,426,4490,394,1665,5930,1665,5930,1669,7474,1669,7474,2693,7466,2693,7466,4741,11060,4741,9093,6962,4906,7474,6962,5930,4914,7466,5930,1802,1834,5898,1802,1669,7466,7458,7458,3346,3378,7442,3346,3338,3370,7434,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b445 : Blocked tgt 6 s445 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(true,(0,false),(2,false))] s445 6 _ le
  decide +kernel
theorem b446 : Blocked tgt 6 s446 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s446 6 _ le
  decide +kernel
theorem b447 : Blocked tgt 6 s447 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s447 6 _ le
  decide +kernel
theorem b448 : Blocked tgt 6 s448 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s448 6 _ le
  decide +kernel
theorem b453 : Blocked tgt 6 s453 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s453 6 _ le
  decide +kernel
theorem b454 : Blocked tgt 6 s454 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s454 6 _ le
  decide +kernel
theorem b455 : Blocked tgt 6 s455 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s455 6 _ le
  decide +kernel
theorem b456 : Blocked tgt 6 s456 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s456 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
