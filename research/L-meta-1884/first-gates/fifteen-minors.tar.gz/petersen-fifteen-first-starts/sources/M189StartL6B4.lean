import M189StartData
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b88 : Blocked tgt 6 s88 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s88 6 _ le
  decide +kernel
theorem b89 : Blocked tgt 6 s89 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s89 6 _ le
  decide +kernel
theorem b90 : Blocked tgt 6 s90 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s90 6 _ le
  decide +kernel
theorem b91 : Blocked tgt 6 s91 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s91 6 _ le
  decide +kernel
theorem b92 : Blocked tgt 6 s92 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s92 6 _ le
  decide +kernel
theorem b93 : Blocked tgt 6 s93 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s93 6 _ le
  decide +kernel
theorem b94 : Blocked tgt 6 s94 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s94 6 _ le
  decide +kernel
theorem b95 : Blocked tgt 6 s95 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s95 6 _ le
  decide +kernel
theorem b96 : Blocked tgt 6 s96 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s96 6 _ le
  decide +kernel
theorem b97 : Blocked tgt 6 s97 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s97 6 _ le
  decide +kernel
theorem b98 : Blocked tgt 6 s98 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s98 6 _ le
  decide +kernel
theorem b99 : Blocked tgt 6 s99 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s99 6 _ le
  decide +kernel
theorem b100 : Blocked tgt 6 s100 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s100 6 _ le
  decide +kernel
theorem b101 : Blocked tgt 6 s101 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s101 6 _ le
  decide +kernel
theorem b102 : Blocked tgt 6 s102 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s102 6 _ le
  decide +kernel
theorem b103 : Blocked tgt 6 s103 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s103 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
