import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL5B3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1310 : Blocked tgt 6 s1310 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1310 6 _ le
  decide +kernel
theorem b1311 : Blocked tgt 6 s1311 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1311 6 _ le
  decide +kernel
theorem b1312 : Blocked tgt 6 s1312 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1312 6 _ le
  decide +kernel
theorem b1313 : Blocked tgt 6 s1313 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1313 6 _ le
  decide +kernel
theorem b1314 : Blocked tgt 6 s1314 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1673,5930,6962,1673,5736,5546,6578,5736,5736,5992,6964,5736,7732,15412,5736,7784,2177,5736,1608,5704,1640,1608,5546,5352,1417,13610,1417,13608,1665,13610,13610,6962,3209,7272,3209,13610,5257,9514,5257,9482,13672,5290,13672,5288,7732,5546,5546,6578,15464,3081,15464,5546,1418,1450,5514,1418,6964,13672,13672,6964,13672,7210,15464,13672,9544,9576,13640,9544,5668,15464,7716,15464,3604,5257,7700,5257,11336,11368,15432,11336]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1315 : Blocked tgt 6 s1315 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1315 6 _ le
  decide +kernel
theorem b1316 : Blocked tgt 6 s1316 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1316 6 _ le
  decide +kernel
theorem b1317 : Blocked tgt 6 s1317 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1317 6 _ le
  decide +kernel
theorem b1318 : Blocked tgt 6 s1318 := by
  apply PetersenFastNode.node (nxt := #[s1319,s1297]) (hints := [6580,5548,6580,5548,1675,5932,6964,1675,1675,1419,387,1419,1667,7476,1675,3211,2179,1675,1675,5259,4227,1675,5548,0,13612,5548,5290,5292,5546,5290,6580,5548,5548,6580,5548,3083,7468,5548,1420,1452,5516,1420,1419,9611,1667,13612,13612,6964,3211,4916,3211,13612,5259,9516,5259,9484,387,1419,1419,387,1419,7212,3211,1419,1419,1,5259,1419,1667,3211,2179,3211,1667,5259,4227,5259,3211,3372,5259,3211]) (by decide +kernel)
  change ∀ b ∈ [s1319,s1297], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1319) b1319 <|
    PetersenLocalChildren.push (x := s1297) b1297 <|
    PetersenLocalChildren.nil
theorem b1320 : Blocked tgt 6 s1320 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1320 6 _ le
  decide +kernel
theorem b1321 : Blocked tgt 6 s1321 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1321 6 _ le
  decide +kernel
theorem b1322 : Blocked tgt 6 s1322 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1322 6 _ le
  decide +kernel
theorem b1323 : Blocked tgt 6 s1323 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1323 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
