import M127StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 128) : Fin 128 := (#[0,2,1,3,16,18,17,19,8,10,9,11,24,26,25,27,4,6,5,7,20,22,21,23,12,14,13,15,28,30,29,31,64,66,65,67,80,82,81,83,72,74,73,75,88,90,89,91,68,70,69,71,84,86,85,87,76,78,77,79,92,94,93,95,32,34,33,35,48,50,49,51,40,42,41,43,56,58,57,59,36,38,37,39,52,54,53,55,44,46,45,47,60,62,61,63,96,98,97,99,112,114,113,115,104,106,105,107,120,122,121,123,100,102,101,103,116,118,117,119,108,110,109,111,124,126,125,127] : Array (Fin 128))[x.val]?.getD 0
private theorem cover0 : i7.all (fun q => i7.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x44444444444444444444444444444444 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x44444444444444444444444444444444) (a:=0x22222222222222222222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (a:=0xffffaaaaffffaaaaffffaaaaffffaaaa) (by decide +kernel) gate_0_4_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) (a:=0xaaaa0000aaaa0000aaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_1_2_2 : NoAtMost (0x30303030303030303030303030303030 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x30303030303030303030303030303030) (a:=0x55550000555500005555000055550000) (by decide +kernel) gate_0_4_2
theorem labeled_1_2_3 : NoAtMost (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) (a:=0xaaaa0000aaaa0000aaaa0000aaaa0000) (by decide +kernel) gate_0_4_3
theorem labeled_1_3_0 : NoAtMost (0xffccffccffccffccffccffccffccffcc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffccffccffccffccffccffccffccffcc) (a:=0xffaaffaaffaaffaaffaaffaaffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_1_3_1 : NoAtMost (0xcc00cc00cc00cc00cc00cc00cc00cc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc00cc00cc00cc00cc00cc00cc00cc) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_1_3_2 : NoAtMost (0x33003300330033003300330033003300 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33003300330033003300330033003300) (a:=0x55005500550055005500550055005500) (by decide +kernel) gate_0_3_2
theorem labeled_1_3_3 : NoAtMost (0xcc00cc00cc00cc00cc00cc00cc00cc00 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc00cc00cc00cc00cc00cc00cc00cc00) (a:=0xaa00aa00aa00aa00aa00aa00aa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_1_4_1 : NoAtMost (0xcccc0000cccc0000cccc0000cccc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000cccc0000cccc0000cccc) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_4_2 : NoAtMost (0x33330000333300003333000033330000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33330000333300003333000033330000) (a:=0x50505050505050505050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_1_4_3 : NoAtMost (0xcccc0000cccc0000cccc0000cccc0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000cccc0000cccc0000cccc0000) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_5_1 : NoAtMost (0xcccccccc00000000cccccccc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccccccc00000000cccccccc) (a:=0xaaaaaaaaaaaaaaaa) (by decide +kernel) gate_0_6_1
theorem labeled_1_5_2 : NoAtMost (0x33333333000000003333333300000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33333333000000003333333300000000) (a:=0x55555555555555550000000000000000) (by decide +kernel) gate_0_6_2
theorem labeled_1_5_3 : NoAtMost (0xcccccccc00000000cccccccc00000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccccccc00000000cccccccc00000000) (a:=0xaaaaaaaaaaaaaaaa0000000000000000) (by decide +kernel) gate_0_6_3
theorem labeled_1_6_0 : NoAtMost (0xffffffffffffffffcccccccccccccccc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffffffffffffcccccccccccccccc) (a:=0xffffffffaaaaaaaaffffffffaaaaaaaa) (by decide +kernel) gate_0_5_0
theorem labeled_1_6_1 : NoAtMost (0xcccccccccccccccc :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccccccccccccccc) (a:=0xaaaaaaaa00000000aaaaaaaa) (by decide +kernel) gate_0_5_1
theorem labeled_1_6_2 : NoAtMost (0x33333333333333330000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x33333333333333330000000000000000) (a:=0x55555555000000005555555500000000) (by decide +kernel) gate_0_5_2
theorem labeled_1_6_3 : NoAtMost (0xcccccccccccccccc0000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccccccccccccccc0000000000000000) (a:=0xaaaaaaaa00000000aaaaaaaa00000000) (by decide +kernel) gate_0_5_3
theorem labeled_2_4_2 : NoAtMost (0xf0f00000f0f00000f0f00000f0f0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f00000f0f00000f0f00000f0f0000) (a:=0xf0f00000f0f00000f0f00000f0f0) (by decide +kernel) gate_2_4_1
theorem labeled_3_4_0 : NoAtMost (0xffffff00ffffff00ffffff00ffffff00 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffff00ffffff00ffffff00ffffff00) (a:=0xfff0fff0fff0fff0fff0fff0fff0fff0) (by decide +kernel) gate_2_3_0
theorem labeled_3_4_1 : NoAtMost (0xff000000ff000000ff000000ff00 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff000000ff000000ff00) (a:=0xf000f000f000f000f000f000f000f00) (by decide +kernel) gate_2_3_2
theorem labeled_3_4_2 : NoAtMost (0xff000000ff000000ff000000ff0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff000000ff000000ff0000) (a:=0xf000f000f000f000f000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_3_4_3 : NoAtMost (0xff000000ff000000ff000000ff000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff000000ff000000ff000000) (a:=0xf000f000f000f000f000f000f000f000) (by decide +kernel) gate_2_3_3
theorem labeled_3_6_0 : NoAtMost (0xffffffffffffffffff00ff00ff00ff00 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffffffffffffff00ff00ff00ff00) (a:=0xffffffffff00ff00ffffffffff00ff00) (by decide +kernel) gate_3_5_0
theorem labeled_3_6_1 : NoAtMost (0xff00ff00ff00ff00 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff00ff00ff00) (a:=0xff00ff0000000000ff00ff00) (by decide +kernel) gate_3_5_1
theorem labeled_3_6_2 : NoAtMost (0xff00ff00ff00ff0000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff00ff00ff0000000000000000) (a:=0xff00ff0000000000ff00ff00000000) (by decide +kernel) gate_3_5_2
theorem labeled_3_6_3 : NoAtMost (0xff00ff00ff00ff000000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff00ff00ff00ff000000000000000000) (a:=0xff00ff0000000000ff00ff0000000000) (by decide +kernel) gate_3_5_3
theorem labeled_4_5_1 : NoAtMost (0xffff000000000000ffff0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff000000000000ffff0000) (a:=0xf0f0f0f0f0f0f0f0) (by decide +kernel) gate_2_6_1
theorem labeled_4_5_2 : NoAtMost (0xffff000000000000ffff00000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff000000000000ffff00000000) (a:=0xf0f0f0f0f0f0f0f0000000000000000) (by decide +kernel) gate_2_6_2
theorem labeled_4_5_3 : NoAtMost (0xffff000000000000ffff000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff000000000000ffff000000000000) (a:=0xf0f0f0f0f0f0f0f00000000000000000) (by decide +kernel) gate_2_6_3
theorem labeled_4_6_0 : NoAtMost (0xffffffffffffffffffff0000ffff0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffffffffffffffff0000ffff0000) (a:=0xfffffffff0f0f0f0fffffffff0f0f0f0) (by decide +kernel) gate_2_5_0
theorem labeled_4_6_1 : NoAtMost (0xffff0000ffff0000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff0000ffff0000) (a:=0xf0f0f0f000000000f0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_4_6_2 : NoAtMost (0xffff0000ffff0000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff0000ffff0000000000000000) (a:=0xf0f0f0f000000000f0f0f0f00000000) (by decide +kernel) gate_2_5_2
theorem labeled_4_6_3 : NoAtMost (0xffff0000ffff00000000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff0000ffff00000000000000000000) (a:=0xf0f0f0f000000000f0f0f0f000000000) (by decide +kernel) gate_2_5_3
theorem labeled_5_6_2 : NoAtMost (0xffffffff0000000000000000 :: inputs 7) tgt 8 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffff0000000000000000) (a:=0xffffffff00000000) (by decide +kernel) gate_5_6_1
def forbidden : List (BitVec 128) := [0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0x22222222222222222222222222222222,0x44444444444444444444444444444444,0x88888888888888888888888888888888,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0,0xffaaffaaffaaffaaffaaffaaffaaffaa,0xaa00aa00aa00aa00aa00aa00aa00aa,0x55005500550055005500550055005500,0xaa00aa00aa00aa00aa00aa00aa00aa00,0xffffaaaaffffaaaaffffaaaaffffaaaa,0xaaaa0000aaaa0000aaaa0000aaaa,0x55550000555500005555000055550000,0xaaaa0000aaaa0000aaaa0000aaaa0000,0xffffffffaaaaaaaaffffffffaaaaaaaa,0xaaaaaaaa00000000aaaaaaaa,0x55555555000000005555555500000000,0xaaaaaaaa00000000aaaaaaaa00000000,0xaaaaaaaaaaaaaaaa,0x55555555555555550000000000000000,0xaaaaaaaaaaaaaaaa0000000000000000,0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c,0x30303030303030303030303030303030,0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0,0xffccffccffccffccffccffccffccffcc,0xcc00cc00cc00cc00cc00cc00cc00cc,0x33003300330033003300330033003300,0xcc00cc00cc00cc00cc00cc00cc00cc00,0xcccc0000cccc0000cccc0000cccc,0x33330000333300003333000033330000,0xcccc0000cccc0000cccc0000cccc0000,0xcccccccc00000000cccccccc,0x33333333000000003333333300000000,0xcccccccc00000000cccccccc00000000,0xffffffffffffffffcccccccccccccccc,0xcccccccccccccccc,0x33333333333333330000000000000000,0xcccccccccccccccc0000000000000000,0xfff0fff0fff0fff0fff0fff0fff0fff0,0xf000f000f000f000f000f000f000f0,0xf000f000f000f000f000f000f000f00,0xf000f000f000f000f000f000f000f000,0xf0f00000f0f00000f0f00000f0f0,0xf0f00000f0f00000f0f00000f0f0000,0xf0f00000f0f00000f0f00000f0f00000,0xfffffffff0f0f0f0fffffffff0f0f0f0,0xf0f0f0f000000000f0f0f0f0,0xf0f0f0f000000000f0f0f0f00000000,0xf0f0f0f000000000f0f0f0f000000000,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0000000000000000,0xf0f0f0f0f0f0f0f00000000000000000,0xffffff00ffffff00ffffff00ffffff00,0xff000000ff000000ff000000ff00,0xff000000ff000000ff000000ff0000,0xff000000ff000000ff000000ff000000,0xffffffffff00ff00ffffffffff00ff00,0xff00ff0000000000ff00ff00,0xff00ff0000000000ff00ff00000000,0xff00ff0000000000ff00ff0000000000,0xffffffffffffffffff00ff00ff00ff00,0xff00ff00ff00ff00,0xff00ff00ff00ff0000000000000000,0xff00ff00ff00ff000000000000000000,0xffff000000000000ffff0000,0xffff000000000000ffff00000000,0xffff000000000000ffff000000000000,0xffffffffffffffffffff0000ffff0000,0xffff0000ffff0000,0xffff0000ffff0000000000000000,0xffff0000ffff00000000000000000000,0xffffffffffffffffffffffff00000000,0xffffffff00000000,0xffffffff0000000000000000,0xffffffff000000000000000000000000]
theorem all_forbidden (g : BitVec 128) (h : g∈forbidden) : NoAtMost (g::inputs 7) tgt 8 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 7) tgt 8 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x22222222222222222222222222222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x44444444444444444444444444444444) labeled_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x88888888888888888888888888888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x50505050505050505050505050505050) gate_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffaaffaaffaaffaaffaaffaaffaaffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaa00aa00aa00aa00aa00aa00aa00aa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x55005500550055005500550055005500) gate_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaa00aa00aa00aa00aa00aa00aa00aa00) gate_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffaaaaffffaaaaffffaaaaffffaaaa) gate_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaa0000aaaa0000aaaa0000aaaa) gate_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x55550000555500005555000055550000) gate_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaa0000aaaa0000aaaa0000aaaa0000) gate_0_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffaaaaaaaaffffffffaaaaaaaa) gate_0_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaaaaaa00000000aaaaaaaa) gate_0_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x55555555000000005555555500000000) gate_0_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaaaaaa00000000aaaaaaaa00000000) gate_0_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaaaaaaaaaaaaaa) gate_0_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x55555555555555550000000000000000) gate_0_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xaaaaaaaaaaaaaaaa0000000000000000) gate_0_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x30303030303030303030303030303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0) labeled_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffccffccffccffccffccffccffccffcc) labeled_1_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcc00cc00cc00cc00cc00cc00cc00cc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x33003300330033003300330033003300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcc00cc00cc00cc00cc00cc00cc00cc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccc0000cccc0000cccc0000cccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x33330000333300003333000033330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccc0000cccc0000cccc0000cccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccccccc00000000cccccccc) labeled_1_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x33333333000000003333333300000000) labeled_1_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccccccc00000000cccccccc00000000) labeled_1_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffffffffffcccccccccccccccc) labeled_1_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccccccccccccccc) labeled_1_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0x33333333333333330000000000000000) labeled_1_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xcccccccccccccccc0000000000000000) labeled_1_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xfff0fff0fff0fff0fff0fff0fff0fff0) gate_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf000f000f000f000f000f000f000f0) gate_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf000f000f000f000f000f000f000f00) gate_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf000f000f000f000f000f000f000f000) gate_2_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f00000f0f00000f0f00000f0f0) gate_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f00000f0f00000f0f00000f0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f00000f0f00000f0f00000f0f00000) gate_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xfffffffff0f0f0f0fffffffff0f0f0f0) gate_2_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f000000000f0f0f0f0) gate_2_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f000000000f0f0f0f00000000) gate_2_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f000000000f0f0f0f000000000) gate_2_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f0f0f0f0f0) gate_2_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f0f0f0f0f0000000000000000) gate_2_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xf0f0f0f0f0f0f0f00000000000000000) gate_2_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffff00ffffff00ffffff00ffffff00) labeled_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff000000ff000000ff000000ff00) labeled_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff000000ff000000ff000000ff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff000000ff000000ff000000ff000000) labeled_3_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffff00ff00ffffffffff00ff00) gate_3_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff0000000000ff00ff00) gate_3_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff0000000000ff00ff00000000) gate_3_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff0000000000ff00ff0000000000) gate_3_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffffffffffff00ff00ff00ff00) labeled_3_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff00ff00ff00) labeled_3_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff00ff00ff0000000000000000) labeled_3_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xff00ff00ff00ff000000000000000000) labeled_3_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff000000000000ffff0000) labeled_4_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff000000000000ffff00000000) labeled_4_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff000000000000ffff000000000000) labeled_4_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffffffffffffff0000ffff0000) labeled_4_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff0000ffff0000) labeled_4_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff0000ffff0000000000000000) labeled_4_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffff0000ffff00000000000000000000) labeled_4_6_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffffffffffffffffffff00000000) gate_5_6_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffff00000000) gate_5_6_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffff0000000000000000) labeled_5_6_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 8) (x:=0xffffffff000000000000000000000000) gate_5_6_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M127
