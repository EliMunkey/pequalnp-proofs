import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222222222222222 :: inputs 6) tgt 6 := by
  change NoAtMost [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s11] [194,835,195,835,196,835,835,835,390,839,455,839,196,839,839,839,714,843,715,843,716,843,843,843,390,1351,455,1351,716,1351,1351,1351,1106,835,195,835,1236,835,835,835,1366,839,455,839,1236,839,839,839,1626,843,715,843,1756,843,843,843,1366,1430,455,1430,1756,1756,3740,3740,2210,2915,2275,2915,196,2915,2915,2915,2470,2919,2535,2919,196,2919,2919,2919,2730,2923,2795,2923,716,2923,2923,2923,2470,3431,2535,3431,716,3431,3431,3431,3186,2915,2275,2915,1236,2915,2915,2915,3446,2919,2535,2919,1236,2919,2919,2919,3706,2923,2795,2923,1756,2923,2923,2923,3446,3510,2535,3510,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s11], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M111
