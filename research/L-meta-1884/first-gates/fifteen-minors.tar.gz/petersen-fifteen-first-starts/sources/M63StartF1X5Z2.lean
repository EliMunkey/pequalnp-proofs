import M63StartData
import M63StartL7B1
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_2 : NoAtMost (0x3333333300000000 :: inputs 6) tgt 7 := by
  change NoAtMost [0x3333333300000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s1021,s0,s1022] [195,2147,196,2851,197,2147,836,2851,391,2407,456,2855,197,2407,840,2855,715,2667,716,2859,717,2667,844,2859,391,2407,456,3627,717,2407,1352,3627,1107,3187,196,3635,1237,3187,836,3635,1367,3447,456,3895,1237,3447,840,3895,715,2667,716,2859,717,2667,844,2859,1367,3447,456,456,717,3447,2376,0,2147,2147,196,2851,2277,2147,836,2851,2407,2407,456,2855,2277,2407,840,2855,2667,2667,716,2859,2797,2667,844,2859,2407,2407,456,3627,2797,2407,1352,3627,3187,3187,196,3635,3317,3187,836,3635,3447,3447,456,3895,3317,3447,840,3895,2667,2667,716,2859,2797,2667,844,2859,3447,3447,456,456,2797,3447,1,2] (by decide +kernel)
  change ∀ b ∈ [s1021,s0,s1022], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s1021) b1021 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1022) b1022 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_2
end PetersenSmallStarts.M63
