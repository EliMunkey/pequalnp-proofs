import M251StartData
import M251StartL7B1
import M251StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_3 : NoAtMost (0xcccccccc00000000cccccccc00000000 :: inputs 7) tgt 7 := by
  change NoAtMost [0xcccccccc00000000cccccccc00000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s51,s0,s52] [387,387,388,388,389,389,1156,1156,903,903,904,904,905,905,1672,1672,1163,1163,388,388,1421,1421,2180,2180,903,903,904,904,905,905,2696,2696,2195,2195,388,388,2453,2453,1156,1156,2711,2711,904,904,2969,2969,1672,1672,3227,3227,388,388,3485,3485,3869,3869,2711,2711,904,904,2969,2969,6937,11033,4387,5283,4516,5284,389,389,5284,5284,4903,5671,5032,5800,905,905,5800,5800,5291,5291,4516,6308,1421,1421,6308,6308,4903,6823,5032,6824,905,905,6824,6824,6323,6323,4516,5284,2453,2453,5284,5284,6839,6839,5032,5800,2969,2969,5800,5800,7355,7355,4516,388,3485,3485,3869,3869,6839,6839,5032,904,2969,2969,11033,11033,8643,8643,8644,8644,8645,8645,9412,9412,9159,9159,9160,9160,9161,9161,9928,9928,9419,9419,8644,8644,9677,9677,10436,10436,9159,9159,9160,9160,9161,9161,10952,10952,2195,2195,8644,8644,2453,2453,9412,9412,2711,2711,9160,9160,2969,2969,9928,9928,3227,3227,8644,8644,3485,3485,3869,3869,2711,2711,9160,9160,2969,2969,6937,0,12643,13539,12772,13540,8645,8645,13540,13540,13159,13927,13288,14056,9161,9161,14056,14056,13547,13547,12772,14564,9677,9677,14564,14564,13159,14951,13288,15080,9161,9161,15080,15080,6323,6323,12772,13540,2453,2453,13540,13540,6839,6839,13288,14056,2969,2969,14056,14056,7355,7355,12772,8644,3485,3485,3869,3869,6839,6839,13288,9160,2969,2969,1,2] (by decide +kernel)
  change ∀ b ∈ [s51,s0,s52], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_3
end PetersenSmallStarts.M251
