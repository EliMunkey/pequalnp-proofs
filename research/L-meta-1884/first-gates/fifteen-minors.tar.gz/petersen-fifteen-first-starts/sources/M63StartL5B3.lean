import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b103 : Blocked tgt 5 s103 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s103 5 _ le
  decide +kernel
theorem b104 : Blocked tgt 5 s104 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3754,2794,2274,2794,453,453,2468,1349,1609,841,1093,841,1349,837,1097,837,1349,2373,1706,1349,2664,2666,2792,2664,2794,777,2986,2794,773,2794,2794,837,714,746,2762,714,713,2858,841,713,837,713,837,965,2373,420,2373,713,2466,837,833,833,841,2117,2633,841,837,2121,2373,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b105 : Blocked tgt 5 s105 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s105 5 _ le
  decide +kernel
theorem b106 : Blocked tgt 5 s106 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s106 5 _ le
  decide +kernel
theorem b111 : Blocked tgt 5 s111 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s111 5 _ le
  decide +kernel
theorem b112 : Blocked tgt 5 s112 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s112 5 _ le
  decide +kernel
theorem b113 : Blocked tgt 5 s113 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s113 5 _ le
  decide +kernel
theorem b121 : Blocked tgt 5 s121 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s121 5 _ le
  decide +kernel
theorem b122 : Blocked tgt 5 s122 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s122 5 _ le
  decide +kernel
theorem b123 : Blocked tgt 5 s123 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s123 5 _ le
  decide +kernel
theorem b124 : Blocked tgt 5 s124 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,714,1428,1364,714,841,906,714,1234,202,1682,1234,714,1234,1234,714,714,1234,1234,714,841,778,841,904,837,1554,837,1428,1349,1428,1349,1477,453,453,2373,388,1426,837,833,833,841,1093,1609,841,2633,841,841,2117,837,1097,1349,837,2373,837,837,2121,1349,1674]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b125 : Blocked tgt 5 s125 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s125 5 _ le
  decide +kernel
theorem b126 : Blocked tgt 5 s126 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s126 5 _ le
  decide +kernel
theorem b127 : Blocked tgt 5 s127 := by
  apply PetersenFastNode.node (nxt := #[s128,s129]) (hints := [1366,1366,455,455,715,843,199,715,2375,839,203,839,2375,1351,1546,1351,1430,0,1430,1494,714,843,778,843,1814,839,1814,839,2374,1351,3398,1351,843,906,839,1,839,1430,1351,406,1351,390,1554,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s128,s129], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.nil
theorem b130 : Blocked tgt 5 s130 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [713,2373,453,453,1364,1364,713,2373,2373,713,2373,837,1812,837,2373,1349,1544,1349,1428,1492,712,1428,841,841,1428,837,1552,837,1609,1349,1609,1349,712,3412,3412,712,1812,837,1812,837,2372,1349,3396,1349,1424,837,1552,837,1609,1349,1609,1349,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b131 : Blocked tgt 5 s131 := by
  apply PetersenFastNode.node (nxt := #[s132]) (hints := [1365,1365,714,842,2118,714,2374,714,202,2374,454,454,714,2374,2374,1350,1545,1350,713,842,777,842,3413,201,1555,3413,1429,713,1429,1493,2373,1350,3397,1350,1427,842,842,1427,0,842,842,1425,842,1094,1610,842,838,838,1350,1610,1350,1610,1350,1610,1350,1610]) (by decide +kernel)
  change ∀ b ∈ [s132], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
