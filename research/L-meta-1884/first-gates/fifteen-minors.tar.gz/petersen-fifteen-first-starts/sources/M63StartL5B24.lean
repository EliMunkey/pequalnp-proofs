import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b849 : Blocked tgt 5 s849 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s849 5 _ le
  decide +kernel
theorem b850 : Blocked tgt 5 s850 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s850 5 _ le
  decide +kernel
theorem b851 : Blocked tgt 5 s851 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s851 5 _ le
  decide +kernel
theorem b852 : Blocked tgt 5 s852 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s852 5 _ le
  decide +kernel
theorem b853 : Blocked tgt 5 s853 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s853 5 _ le
  decide +kernel
theorem b854 : Blocked tgt 5 s854 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s854 5 _ le
  decide +kernel
theorem b860 : Blocked tgt 5 s860 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s860 5 _ le
  decide +kernel
theorem b861 : Blocked tgt 5 s861 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s861 5 _ le
  decide +kernel
theorem b865 : Blocked tgt 5 s865 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,true),(3,false)),(true,(0,false),(1,false))] s865 5 _ le
  decide +kernel
theorem b866 : Blocked tgt 5 s866 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s866 5 _ le
  decide +kernel
theorem b867 : Blocked tgt 5 s867 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s867 5 _ le
  decide +kernel
theorem b882 : Blocked tgt 5 s882 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s882 5 _ le
  decide +kernel
theorem b895 : Blocked tgt 5 s895 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s895 5 _ le
  decide +kernel
theorem b896 : Blocked tgt 5 s896 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s896 5 _ le
  decide +kernel
theorem b910 : Blocked tgt 5 s910 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s910 5 _ le
  decide +kernel
theorem b911 : Blocked tgt 5 s911 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s911 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
