import M127StartData
import M127StartPins0
import M127StartL6B4
import M127StartL6B5
import M127StartL6B2
import M127StartL6B0
import M127StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b133 : Blocked tgt 7 s133 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s133 7 _ le
  decide +kernel
theorem b134 : Blocked tgt 7 s134 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s134 7 _ le
  decide +kernel
theorem b135 : Blocked tgt 7 s135 := by
  apply PetersenFastNode.node (nxt := #[s136,s137,s138,s139]) (hints := [15096,9033,15224,15096,5550,9933,5934,5550,6582,4526,7478,6582,5550,4534,7470,5550,5550,13032,1422,1454,5518,1422,5550,6904,13614,5550,9677,8649,9933,9677,9161,8653,9929,9161,9161,13176,10953,9161,9161,13160,9161,11128,13001,9161,905,969,9097,905,6966,9929,9925,9925,9933,10441,11469,9933,13932,9933,9933,13932,9933,12489,13517,9933,1677,1741,9869,1677,9929,10445,10953,9929,13928,9929,9929,13928,9929,12493,13001,9929,1673,1737,9865,1673,10953,15468,10953,3374,13001,10953,2697,2761,10889,2697,0,13001,1,13001,2,13614,3,13614,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s136,s137,s138,s139], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s136) b136 <|
    PetersenLocalChildren.push (x := s137) b137 <|
    PetersenLocalChildren.push (x := s138) b138 <|
    PetersenLocalChildren.push (x := s139) b139 <|
    PetersenLocalChildren.nil
theorem b140 : Blocked tgt 7 s140 := by
  apply PetersenFastNode.node (nxt := #[s141,s142]) (hints := [6580,5548,6580,5548,15222,9159,15222,9159,6964,9931,6964,9931,7476,9927,7476,9927,10951,10951,0,12999,1,12999,14644,13612,14644,13612,9031,9031,5548,9159,5548,9931,5932,5548,4516,4524,5540,4516,5548,6580,6580,5548,1420,1452,5516,1420,5548,6902,13612,5548,9675,8647,9931,9675,9159,8651,9927,9159,9159,15222,15206,9159,9159,11126,12999,9159,903,967,9095,903,4900,9927,9923,9923,9931,6964,6964,9931,9931,12487,13515,9931,1675,1739,9867,1675,9927,7476,7476,9927,9927,12491,12999,9927,1671,1735,9863,1671,12999,11370,12999,11338,13612,14644,13612,14644,4743,4807,12935,4743]) (by decide +kernel)
  change ∀ b ∈ [s141,s142], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s141) b141 <|
    PetersenLocalChildren.push (x := s142) b142 <|
    PetersenLocalChildren.nil
theorem b143 : Blocked tgt 7 s143 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s143 7 _ le
  decide +kernel
theorem b144 : Blocked tgt 7 s144 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s144 7 _ le
  decide +kernel
theorem b145 : Blocked tgt 7 s145 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s145 7 _ le
  decide +kernel
theorem b146 : Blocked tgt 7 s146 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s146 7 _ le
  decide +kernel
theorem b147 : Blocked tgt 7 s147 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s147 7 _ le
  decide +kernel
theorem b148 : Blocked tgt 7 s148 := by
  apply PetersenFastNode.node (nxt := #[s149,s150,s151,s110,s152,s142,s69,s153,s154,s119,s155,s156]) (hints := [5526,0,5558,1430,13009,1430,1462,13009,5558,1430,1,1430,13009,13009,15200,9169,2,9169,11104,3,15200,9169,13009,9169,13525,13525,5942,9941,13009,9941,12497,13009,5942,9941,13525,9941,13009,13009,7486,9937,13525,9937,12501,13525,7486,9937,13009,9937,13009,13009,7478,10961,4,10961,3382,5,7478,10961,13009,10961,4753,4753,13622,12945,13009,9494,4817,13009,13622,4753,4753,9494,9041,15072,15200,9041,1430,9169,1430,1430,15200,9169,15072,9169,1430,1430,1814,9941,15072,9941,1814,15072,1814,1430,1430,9941,2462,2462,3358,406,1430,9937,3358,1430,3358,2462,2462,9937,1430,1430,3350,414,2462,10961,3350,2462,3350,1430,1430,10961,1430,1430,9494,6880,15072,6,9494,15072,9494,1430,1430,7,9685,9685,9941,8657,9169,1814,9941,9169,9941,9685,9685,1814,9169,9169,9937,8661,9685,3358,9937,9685,9937,9169,9169,3358,9169,9169,10961,3350,15200,3350,10961,15200,10961,9169,9169,3350,913,913,8,977,9169,9494,9105,9169,9,913,913,9494,2846,2846,3358,9937,9941,9937,9933,9941,3358,9933,2846,9937,9941,9941,11477,10449,2846,10961,11477,2846,11477,9941,9941,10961,1685,1685,9494,1749,9941,10,9877,9941,9494,1685,1685,11,9937,9937,10961,10453,3358,11477,10961,3358,10961,9937,9937,11477,1681,1681,10526,1745,9937,9494,9873,9937,10526,1681,1681,9494,2705,2705,9494,2769,10961,10526,10897,10961,9494,2705,2705,10526]) (by decide +kernel)
  change ∀ b ∈ [s149,s150,s151,s110,s152,s142,s69,s153,s154,s119,s155,s156], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s149) b149 <|
    PetersenLocalChildren.push (x := s150) b150 <|
    PetersenLocalChildren.push (x := s151) b151 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s152) b152 <|
    PetersenLocalChildren.push (x := s142) b142 <|
    PetersenLocalChildren.push (x := s69) b69 <|
    PetersenLocalChildren.push (x := s153) b153 <|
    PetersenLocalChildren.push (x := s154) b154 <|
    PetersenLocalChildren.push (x := s119) b119 <|
    PetersenLocalChildren.push (x := s155) b155 <|
    PetersenLocalChildren.push (x := s156) b156 <|
    PetersenLocalChildren.nil
theorem b157 : Blocked tgt 7 s157 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s157 7 _ le
  decide +kernel
theorem b158 : Blocked tgt 7 s158 := by
  apply PetersenFastNode.node (nxt := #[s18,s159,s50,s160,s161]) (hints := [5519,1423,1455,1423,13002,9162,0,9162,13002,1,13518,9934,12490,9934,13002,9930,12494,9930,13002,10954,3375,10954,4746,12938,4810,4746,9034,1423,9162,1423,15065,1423,9934,1807,1423,2455,399,3351,2455,1423,407,3343,1423,1423,2,9487,1423,9162,15193,9678,8650,9934,9678,9162,8654,9930,9162,9162,3343,10954,9162,906,970,9098,906,9805,9934,9805,9934,11865,9930,11865,9930,11341,10954,11341,10954,3,9487,4,9487,2839,9930,9926,9926,9934,10442,11470,9934,1678,1742,9870,1678,9930,10446,10954,9930,1674,1738,9866,1674,2698,2762,10890,2698]) (by decide +kernel)
  change ∀ b ∈ [s18,s159,s50,s160,s161], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s159) b159 <|
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s160) b160 <|
    PetersenLocalChildren.push (x := s161) b161 <|
    PetersenLocalChildren.nil
theorem b162 : Blocked tgt 7 s162 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s162 7 _ le
  decide +kernel
theorem b163 : Blocked tgt 7 s163 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s163 7 _ le
  decide +kernel
theorem b164 : Blocked tgt 7 s164 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s164 7 _ le
  decide +kernel
theorem b165 : Blocked tgt 7 s165 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s165 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
