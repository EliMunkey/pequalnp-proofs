import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b265 : Blocked tgt 6 s265 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s265 6 _ le
  decide +kernel
theorem b266 : Blocked tgt 6 s266 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s266 6 _ le
  decide +kernel
theorem b267 : Blocked tgt 6 s267 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s267 6 _ le
  decide +kernel
theorem b268 : Blocked tgt 6 s268 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s268 6 _ le
  decide +kernel
theorem b269 : Blocked tgt 6 s269 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s269 6 _ le
  decide +kernel
theorem b270 : Blocked tgt 6 s270 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s270 6 _ le
  decide +kernel
theorem b271 : Blocked tgt 6 s271 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s271 6 _ le
  decide +kernel
theorem b272 : Blocked tgt 6 s272 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s272 6 _ le
  decide +kernel
theorem b273 : Blocked tgt 6 s273 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s273 6 _ le
  decide +kernel
theorem b274 : Blocked tgt 6 s274 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s274 6 _ le
  decide +kernel
theorem b275 : Blocked tgt 6 s275 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s275 6 _ le
  decide +kernel
theorem b276 : Blocked tgt 6 s276 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s276 6 _ le
  decide +kernel
theorem b277 : Blocked tgt 6 s277 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s277 6 _ le
  decide +kernel
theorem b286 : Blocked tgt 6 s286 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,9093,901,6964,901,13610,1673,5672,1673,14642,1669,12586,1669,13610,2693,12594,2693,9482,4741,9514,4741,773,773,5546,901,5546,1673,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,1417,389,1673,1417,901,393,1669,901,901,7466,2693,901,901,11060,4741,901,6962,1669,1665,1665,1673,2181,3209,1673,1673,4229,5257,1673,1669,2185,2693,1669,1669,4233,4741,1669,2693,3370,4741,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b287 : Blocked tgt 6 s287 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s287 6 _ le
  decide +kernel
theorem b289 : Blocked tgt 6 s289 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s289 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
