import M251StartData
import M251StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_0 : NoAtMost (0xffccffccffccffccffccffccffccffcc :: inputs 7) tgt 7 := by
  change NoAtMost [0xffccffccffccffccffccffccffccffcc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s24] [386,388,387,2179,388,388,1155,2179,902,904,903,2695,904,904,1671,2695,1162,1162,387,2179,1420,1420,2179,2179,902,904,903,2695,904,904,2695,2695,2194,2452,387,3604,2452,2452,1155,3860,2710,2968,903,3608,2968,2968,1671,3864,3226,3226,387,3610,3484,3484,3868,3868,2710,2968,903,6936,2968,2968,6936,6936,4386,4394,4515,6307,388,388,5283,6307,4902,904,5031,6823,904,904,5799,6823,5290,5290,4515,6307,1420,1420,6307,6307,4902,904,5031,6823,904,904,6823,6823,6322,6458,4515,6458,2452,2452,5283,3860,6838,2968,5031,3608,2968,2968,5799,3864,7354,7354,4515,7482,3484,3484,3868,3868,6838,2968,5031,11032,2968,2968,11032,11032,8642,8644,8643,10435,8644,8644,9411,10435,9158,9160,9159,10951,9160,9160,9927,10951,9418,9418,8643,10435,9676,9676,10435,10435,9158,9160,9159,10951,9160,9160,10951,10951,2194,2452,8643,3604,2452,2452,9411,3860,2710,2968,9159,3608,2968,2968,9927,3864,3226,3226,8643,3610,3484,3484,3868,3868,2710,2968,9159,6936,2968,2968,6936,6936,12642,12650,12771,14563,8644,8644,13539,14563,13158,9160,13287,15079,9160,9160,14055,15079,13546,13546,12771,14563,9676,9676,14563,14563,13158,9160,13287,15079,9160,9160,15079,15079,6322,6458,12771,6458,2452,2452,13539,3860,6838,2968,13287,3608,2968,2968,14055,3864,7354,7354,12771,7482,3484,3484,3868,3868,6838,2968,13287,7482,2968,2968,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s24], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_0
end PetersenSmallStarts.M251
