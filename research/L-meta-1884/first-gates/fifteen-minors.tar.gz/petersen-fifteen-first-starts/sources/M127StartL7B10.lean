import M127StartData
import M127StartPins0
import M127StartL6B14
import M127StartL6B15
import M127StartPins1
import M127StartL6B16
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b426 : Blocked tgt 7 s426 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s426 7 _ le
  decide +kernel
theorem b427 : Blocked tgt 7 s427 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s427 7 _ le
  decide +kernel
theorem b428 : Blocked tgt 7 s428 := by
  apply PetersenFastNode.node (nxt := #[s429,s430,s431]) (hints := [5293,5293,5549,9676,15095,5549,5549,15095,5549,15095,5933,5549,6581,4525,7477,6581,5549,4533,7469,5549,1421,1453,5517,1421,5549,6903,13613,5549,9160,9160,9676,5933,10188,9676,8644,8652,9668,8644,9676,7469,11468,9676,9676,0,13516,9676,1420,1484,9612,1420,9932,9932,13931,5933,9928,7477,9928,7477,10952,11468,10952,11468,13000,13516,13000,13516,1,13613,2,13613,6965,9928,7477,9928,11468,10952,11468,10952,13516,13000,13516,13000,5933,5739,13613,5933,10436,10444,10436,11460,12484,12492,12484,13508,1672,1736,9864,1672,11468,3373,13516,11468,3212,3276,11404,3212,5260,5324,13452,5260]) (by decide +kernel)
  change ∀ b ∈ [s429,s430,s431], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s429) b429 <|
    PetersenLocalChildren.push (x := s430) b430 <|
    PetersenLocalChildren.push (x := s431) b431 <|
    PetersenLocalChildren.nil
theorem b432 : Blocked tgt 7 s432 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s432 7 _ le
  decide +kernel
theorem b433 : Blocked tgt 7 s433 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s433 7 _ le
  decide +kernel
theorem b434 : Blocked tgt 7 s434 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s434 7 _ le
  decide +kernel
theorem b435 : Blocked tgt 7 s435 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s435 7 _ le
  decide +kernel
theorem b436 : Blocked tgt 7 s436 := by
  apply PetersenFastNode.node (nxt := #[s437,s438,s439,s440,s441,s442,s443,s444,s445,s446,s447,s448]) (hints := [15104,15104,15232,9041,4534,9169,15232,4534,15232,15104,15104,9169,4534,4534,5942,9805,15104,9933,5942,15104,5942,4534,4534,9933,7486,15104,7486,4534,4534,9937,6590,4534,7486,6590,15104,9937,4534,4534,7478,13056,15104,10961,6582,15104,7478,4534,4534,10961,406,406,0,438,4534,13009,4502,4534,1,406,406,13009,4534,4534,13622,6912,15104,2,12726,15104,13622,4534,4534,3,8653,8653,9933,9169,9169,5942,9933,9169,9933,8653,8653,5942,9169,9169,9937,8653,8653,7486,9937,8653,9937,9169,9169,7486,9169,9169,10961,13184,15232,7478,10961,15232,10961,9169,9169,7478,9169,9169,13009,11136,15232,4,13009,15232,13009,9169,9169,5,913,913,6,977,9169,13622,9105,9169,7,913,913,13622,6974,6974,7486,9933,9933,9937,9933,9933,7486,9937,6974,9937,9933,9933,10445,10961,6974,10961,10445,6974,10445,9933,9933,10961,9933,9933,12493,13009,5942,13009,12493,5942,12493,9933,9933,13009,1677,1677,13622,1741,9933,8,9869,9933,13622,1677,1677,9,9937,9937,10961,10445,7486,10445,10961,7486,10961,9937,9937,10445,9937,9937,13009,12493,7486,12493,13009,7486,13009,9937,9937,12493,1681,1681,14654,1745,9937,13622,9873,9937,14654,1681,1681,13622,10961,10961,13009,3382,7478,10,13009,7478,13009,10961,10961,11,2705,2705,13622,2769,10961,14654,10897,10961,13622,2705,2705,14654,4753,4753,9494,4817,13009,13622,12945,13009,9494,4753,4753,13622]) (by decide +kernel)
  change ∀ b ∈ [s437,s438,s439,s440,s441,s442,s443,s444,s445,s446,s447,s448], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s437) b437 <|
    PetersenLocalChildren.push (x := s438) b438 <|
    PetersenLocalChildren.push (x := s439) b439 <|
    PetersenLocalChildren.push (x := s440) b440 <|
    PetersenLocalChildren.push (x := s441) b441 <|
    PetersenLocalChildren.push (x := s442) b442 <|
    PetersenLocalChildren.push (x := s443) b443 <|
    PetersenLocalChildren.push (x := s444) b444 <|
    PetersenLocalChildren.push (x := s445) b445 <|
    PetersenLocalChildren.push (x := s446) b446 <|
    PetersenLocalChildren.push (x := s447) b447 <|
    PetersenLocalChildren.push (x := s448) b448 <|
    PetersenLocalChildren.nil
theorem b449 : Blocked tgt 7 s449 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s449 7 _ le
  decide +kernel
theorem b450 : Blocked tgt 7 s450 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s450 7 _ le
  decide +kernel
theorem b451 : Blocked tgt 7 s451 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s451 7 _ le
  decide +kernel
theorem b452 : Blocked tgt 7 s452 := by
  apply PetersenFastNode.node (nxt := #[s453,s454,s455,s456,s457,s458,s459,s460,s461,s462,s463,s464,s465,s466,s467,s468,s469,s470]) (hints := [15110,15110,15238,9047,6596,9175,15238,6596,15238,15110,15110,9175,5948,6596,5948,14598,15110,0,5948,15110,5948,6076,6596,1,6596,6596,7492,4540,2,9943,7492,3,7492,6596,6596,9943,7484,4532,7484,4548,6596,10967,7484,6596,7484,4532,4532,10967,2468,2468,4,2500,6596,13015,6564,6596,5,2468,2468,13015,13628,6596,13628,6918,15110,6,13628,15110,13628,6596,6596,7,8659,8659,13946,8663,9175,5948,9171,9175,13946,8659,8659,5948,9175,9175,9943,7236,13690,7492,9943,13690,9943,9175,9175,7492,9175,9175,10967,13190,15238,7484,10967,15238,10967,9175,9175,7484,9175,9175,13015,11142,15238,8,13015,15238,13015,9175,9175,9,919,919,10,983,9175,13628,9111,9175,11,919,919,13628,6980,6980,7492,9943,5948,9943,9939,5948,7492,9939,6980,9943,10451,5948,10451,10455,6980,10967,10451,6980,10451,10963,5948,10967,12499,1820,12499,12503,5948,13015,12499,5948,12499,13011,1820,13015,5948,5948,13628,5754,13946,12,13628,13946,13628,5948,5948,13,9943,9943,10967,7484,7492,7484,10967,7492,10967,9943,9943,7484,9943,9943,13015,3396,7492,14,13015,7492,13015,9943,9943,15,1687,1687,14660,1751,9943,13628,9879,9943,14660,1687,1687,13628,10967,10967,13015,3388,7484,16,13015,7484,13015,10967,10967,17,2711,2711,13628,2775,10967,14660,10903,10967,13628,2711,2711,14660,4759,4759,9500,4823,13015,13628,12951,13015,9500,4759,4759,13628]) (by decide +kernel)
  change ∀ b ∈ [s453,s454,s455,s456,s457,s458,s459,s460,s461,s462,s463,s464,s465,s466,s467,s468,s469,s470], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s453) b453 <|
    PetersenLocalChildren.push (x := s454) b454 <|
    PetersenLocalChildren.push (x := s455) b455 <|
    PetersenLocalChildren.push (x := s456) b456 <|
    PetersenLocalChildren.push (x := s457) b457 <|
    PetersenLocalChildren.push (x := s458) b458 <|
    PetersenLocalChildren.push (x := s459) b459 <|
    PetersenLocalChildren.push (x := s460) b460 <|
    PetersenLocalChildren.push (x := s461) b461 <|
    PetersenLocalChildren.push (x := s462) b462 <|
    PetersenLocalChildren.push (x := s463) b463 <|
    PetersenLocalChildren.push (x := s464) b464 <|
    PetersenLocalChildren.push (x := s465) b465 <|
    PetersenLocalChildren.push (x := s466) b466 <|
    PetersenLocalChildren.push (x := s467) b467 <|
    PetersenLocalChildren.push (x := s468) b468 <|
    PetersenLocalChildren.push (x := s469) b469 <|
    PetersenLocalChildren.push (x := s470) b470 <|
    PetersenLocalChildren.nil
theorem b471 : Blocked tgt 7 s471 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s471 7 _ le
  decide +kernel
theorem b472 : Blocked tgt 7 s472 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s472 7 _ le
  decide +kernel
theorem b473 : Blocked tgt 7 s473 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s473 7 _ le
  decide +kernel
theorem b474 : Blocked tgt 7 s474 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s474 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
