import M3StartData
import M3StartL0B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2 :: inputs 2) tgt 0 := by
  change NoAtMost [0x2,0xa,0xc] tgt 0
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 4); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 4); change false=true at x; contradiction)
    #[s2,s0,s3] [15,15,16,0,17,17,1,2] (by decide +kernel)
  change ∀ b ∈ [s2,s0,s3], Blocked tgt 0 b
  exact
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M3
