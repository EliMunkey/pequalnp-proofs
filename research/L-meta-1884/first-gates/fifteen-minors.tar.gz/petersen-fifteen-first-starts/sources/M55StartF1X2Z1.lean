import M55StartData
import M55StartL4B1
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_1 : NoAtMost (0xc0c0c0c :: inputs 5) tgt 4 := by
  change NoAtMost [0xc0c0c0c,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s18,s0,s20] [99,101,100,228,101,101,292,292,199,101,232,232,101,101,424,424,299,365,100,228,365,365,548,548,431,365,232,232,365,365,680,680,563,629,100,228,629,629,292,292,695,629,232,232,629,629,424,424,827,893,100,228,893,893,989,0,959,893,232,232,893,893,1,2] (by decide +kernel)
  change ∀ b ∈ [s18,s0,s20], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_1
end PetersenSmallStarts.M55
