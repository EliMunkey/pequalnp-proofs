import M189StartData
import M189StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222222222222222 :: inputs 6) tgt 7 := by
  change NoAtMost [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s45] [386,579,451,579,388,579,453,579,390,839,455,839,708,839,709,839,586,1091,451,1091,716,1091,453,1091,390,1351,455,1351,716,1351,1221,1351,1106,579,451,579,1236,579,453,579,1366,839,455,839,1236,839,709,839,1626,1754,451,453,1756,1756,453,453,1366,1430,455,2245,1756,1756,2245,2245,2210,2659,2275,2659,388,2659,453,2659,2470,2919,2535,2919,708,2919,709,2919,2666,3171,2275,3171,716,3171,453,3171,2470,3431,2535,3431,716,3431,1221,3431,1106,2659,2275,2659,1236,2659,453,2659,1366,2919,2535,2919,1236,2919,709,2919,1626,1754,2275,453,1756,1756,453,453,1366,1430,2535,1430,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s45], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M189
