import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b698 : Blocked tgt 5 s698 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s698 5 _ le
  decide +kernel
theorem b699 : Blocked tgt 5 s699 := by
  apply PetersenFastNode.node (nxt := #[s700]) (hints := [715,778,2827,715,3445,203,1683,3445,3445,390,3509,3445,2405,2421,3429,2405,1365,1397,3413,1365,458,458,842,3475,0,842,842,450,842,1094,1610,842,714,2118,714,842,454,838,1350,1610,1350,1610,2374,202,2374,714,454,1610,1350,454,454,714,2374,454,1350,1547,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s700], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s700) b700 <|
    PetersenLocalChildren.nil
theorem b701 : Blocked tgt 5 s701 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s701 5 _ le
  decide +kernel
theorem b702 : Blocked tgt 5 s702 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s702 5 _ le
  decide +kernel
theorem b713 : Blocked tgt 5 s713 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [201,201,457,3506,2664,2666,2664,2792,713,193,713,3626,1609,713,713,3474,2633,713,3314,2282,3314,3762,3762,3632,457,3754,3746,3746,1682,1714,3730,1682,3184,2794,2794,3184,2794,2290,3754,2794,714,746,2762,714,449,3754,1089,3754,449,2633,2113,2633,1674,1706,3722,1674]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b714 : Blocked tgt 5 s714 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s714 5 _ le
  decide +kernel
theorem b721 : Blocked tgt 5 s721 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s721 5 _ le
  decide +kernel
theorem b722 : Blocked tgt 5 s722 := by
  apply PetersenFastNode.node (nxt := #[s723]) (hints := [3507,3315,3185,3315,194,194,834,3763,834,3507,1090,3491,1090,2467,2114,3475,2114,1427,3185,3315,3315,3185,3315,770,3763,3315,2275,2291,3299,2275,1235,1267,3283,1235,450,3763,834,3763,450,2481,1090,450,450,1457,2114,450,834,3763,3747,3747,1683,1715,3731,1683,1090,0,2114,1090]) (by decide +kernel)
  change ∀ b ∈ [s723], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s723) b723 <|
    PetersenLocalChildren.nil
theorem b724 : Blocked tgt 5 s724 := by
  apply PetersenFastNode.node (nxt := #[s723]) (hints := [1427,2795,2665,2795,714,714,838,1683,838,1427,842,1707,842,1707,2634,1427,2634,403,2665,2795,2795,2665,1235,2283,1683,1235,1707,1235,1707,1771,715,747,2763,715,454,1683,838,1683,842,1707,842,1707,2634,401,2634,454,0,1683,1683,1699,838,1683,1683,838,842,1707,1675,1675]) (by decide +kernel)
  change ∀ b ∈ [s723], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s723) b723 <|
    PetersenLocalChildren.nil
theorem b727 : Blocked tgt 5 s727 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s727 5 _ le
  decide +kernel
theorem b731 : Blocked tgt 5 s731 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s731 5 _ le
  decide +kernel
theorem b732 : Blocked tgt 5 s732 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s732 5 _ le
  decide +kernel
theorem b733 : Blocked tgt 5 s733 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1460,714,777,777,1524,841,1524,773,2036,1524,484,500,1508,484,1364,1396,1492,1364,906,841,906,841,1460,837,1682,837,420,1349,436,1349,1428,453,1460,453,1426,837,833,833,841,1093,1609,841,713,197,713,841,837,1097,1349,837,453,201,453,837,453,1546,453,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b738 : Blocked tgt 5 s738 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,777,906,714,1972,773,1972,2036,1460,1524,1460,1234,2404,2420,3428,2404,1364,1396,3412,1364,1716,837,841,837,1426,841,841,1426,841,1349,1609,841,713,2373,713,841,837,1682,837,1609,1349,837,837,713,965,837,1089,1349,1089,1349,453,453,193,2373,1349,1546,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b743 : Blocked tgt 5 s743 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s743 5 _ le
  decide +kernel
theorem b744 : Blocked tgt 5 s744 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3762,3314,2274,3314,453,453,193,837,833,837,833,3506,837,1349,1089,837,837,2373,2113,837,3444,3186,3508,3444,3314,3188,3506,3314,2404,3314,3314,2404,1234,1266,3282,1234,193,3506,3504,3504,1349,3508,1349,1477,2373,1460,2373,1428,1093,1093,3506,1349,1426,2373,3474,2373,1349,1698,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
