import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b710 : Blocked tgt 6 s710 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s710 6 _ le
  decide +kernel
theorem b711 : Blocked tgt 6 s711 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s711 6 _ le
  decide +kernel
theorem b712 : Blocked tgt 6 s712 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s712 6 _ le
  decide +kernel
theorem b713 : Blocked tgt 6 s713 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9482,5514,6836,5514,901,901,1673,1802,1673,1802,1669,3378,1669,3378,2693,3338,2693,3338,4741,9482,4741,10514,6836,5514,5514,6836,1802,1673,1802,5514,3378,4490,3378,6578,3338,4530,3338,5514,1418,1418,5514,2450,1673,1802,1673,1802,1669,3378,1669,3378,2693,3338,2693,3338,4741,11060,4741,9093,3378,1802,3378,3890,1802,4914,3338,1802,2834,1802,1802,2834,1669,3338,3362,3338,1669,3378,3346,3346,2693,3338,3338,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b714 : Blocked tgt 6 s714 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s714 6 _ le
  decide +kernel
theorem b715 : Blocked tgt 6 s715 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false))] s715 6 _ le
  decide +kernel
theorem b716 : Blocked tgt 6 s716 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s716 6 _ le
  decide +kernel
theorem b717 : Blocked tgt 6 s717 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s717 6 _ le
  decide +kernel
theorem b730 : Blocked tgt 6 s730 := by
  apply PetersenFastNode.node (nxt := #[s731]) (hints := [5515,1419,2451,1419,12998,9158,11093,9158,13514,9930,12486,9930,12998,9926,12490,9926,12998,10950,0,10950,4742,12934,4806,4742,9545,9158,9545,9158,1419,9802,1803,1419,395,395,1419,9926,1419,10950,3339,1419,1419,6869,9483,1419,9674,8646,9930,9674,9158,8650,9926,9158,9158,3083,10950,9158,902,966,9094,902,2835,9926,9922,9922,9930,10438,11466,9930,1674,1738,9866,1674,9926,10442,10950,9926,1670,1734,9862,1670,2694,2758,10886,2694]) (by decide +kernel)
  change ∀ b ∈ [s731], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s731) b731 <|
    PetersenLocalChildren.nil
theorem b733 : Blocked tgt 6 s733 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s733 6 _ le
  decide +kernel
theorem b736 : Blocked tgt 6 s736 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,true),(2,false))] s736 6 _ le
  decide +kernel
theorem b739 : Blocked tgt 6 s739 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s739 6 _ le
  decide +kernel
theorem b743 : Blocked tgt 6 s743 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s743 6 _ le
  decide +kernel
theorem b756 : Blocked tgt 6 s756 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s756 6 _ le
  decide +kernel
theorem b757 : Blocked tgt 6 s757 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s757 6 _ le
  decide +kernel
theorem b758 : Blocked tgt 6 s758 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s758 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
