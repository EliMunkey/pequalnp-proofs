import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_1 : NoAtMost (0xaaaa0000aaaa :: inputs 6) tgt 6 := by
  change NoAtMost [0xaaaa0000aaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s32,s0,s57] [195,196,196,196,197,836,836,836,391,456,456,456,197,840,840,840,715,716,716,716,717,844,844,844,391,456,456,456,717,1741,1352,2701,1107,196,196,196,1237,836,836,836,1367,456,456,456,1237,840,840,840,1627,716,716,716,1757,844,844,844,1367,456,456,456,1757,1757,3741,3741,2211,2276,2276,2276,197,2916,2916,2916,2471,2536,2536,2536,197,2920,2920,2920,2731,2796,2796,2796,717,2924,2924,2924,2471,2536,2536,2536,717,1741,3432,0,3187,2276,2276,2276,1237,2916,2916,2916,3447,2536,2536,2536,1237,2920,2920,2920,3707,2796,2796,2796,1757,2924,2924,2924,3447,2536,2536,2536,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s32,s0,s57], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_1
end PetersenSmallStarts.M111
