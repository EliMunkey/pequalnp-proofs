import M111StartData
import M111StartPins0
import M111StartL4B0
import M111StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b85 : Blocked tgt 5 s85 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s85 5 _ le
  decide +kernel
theorem b86 : Blocked tgt 5 s86 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s86 5 _ le
  decide +kernel
theorem b87 : Blocked tgt 5 s87 := by
  apply PetersenFastNode.node (nxt := #[s88,s90]) (hints := [2919,3179,3431,2919,196,2855,196,2854,2535,2283,388,2919,2915,2915,839,871,2887,839,3690,3690,3691,0,2535,3691,2923,3175,2923,3691,1611,1643,3659,1611,2470,2471,2470,2534,2858,2859,2858,2922,196,1,2180,196,2923,2279,2923,2275,455,487,2503,455,843,875,2891,843]) (by decide +kernel)
  change ∀ b ∈ [s88,s90], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s88) b88 <|
    PetersenLocalChildren.push (x := s90) b90 <|
    PetersenLocalChildren.nil
theorem b91 : Blocked tgt 5 s91 := by
  apply PetersenFastNode.node (nxt := #[s90]) (hints := [1397,838,1397,1909,454,202,1427,838,834,834,838,1098,1350,838,3219,838,838,1813,1657,454,1525,1657,1657,842,1913,1657,0,1610,1641,1610,1625,1625,842,198,842,194,1610,2485,1610,454,1429,454,454,1429,842,2873,1610,842,1817,842,842,1817,2179,1610,1610,3203]) (by decide +kernel)
  change ∀ b ∈ [s90], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s90) b90 <|
    PetersenLocalChildren.nil
theorem b92 : Blocked tgt 5 s92 := by
  apply PetersenFastNode.node (nxt := #[s93]) (hints := [195,2854,195,3893,2918,2233,387,2918,2914,2914,2918,3178,3430,2918,838,870,2886,838,3705,195,2485,3705,3705,2858,3897,3705,0,3690,3689,3689,1625,1657,3673,1625,2922,2229,2922,2225,3690,2534,405,437,2453,405,2922,2873,3690,2922,842,874,2890,842,1610,1642,3658,1610]) (by decide +kernel)
  change ∀ b ∈ [s93], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.nil
theorem b94 : Blocked tgt 5 s94 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2917,3177,3429,2917,3444,3192,3444,3892,3892,2281,386,3892,3888,3888,1812,1844,3860,1812,194,3689,3688,3688,3689,2484,2921,2872,2921,3689,1609,1641,3657,1609,3704,2469,2468,3704,3704,2857,3896,3704,1624,1656,3672,1624,3896,2277,3896,2273,453,485,2501,453,1816,1848,3864,1816]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b95 : Blocked tgt 5 s95 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s95 5 _ le
  decide +kernel
theorem b96 : Blocked tgt 5 s96 := by
  apply PetersenFastNode.node (nxt := #[s97]) (hints := [838,0,1625,1235,1625,1235,454,454,842,1427,842,1427,1610,3203,1610,2179,1235,774,1235,1813,838,2250,1427,838,1427,834,838,1098,1350,838,1625,1235,1235,1625,1235,778,1427,1235,195,211,1219,195,842,1427,842,1427,1610,2453,1610,2502,387,403,1411,387]) (by decide +kernel)
  change ∀ b ∈ [s97], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s97) b97 <|
    PetersenLocalChildren.nil
theorem b98 : Blocked tgt 5 s98 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s98 5 _ le
  decide +kernel
theorem b99 : Blocked tgt 5 s99 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s99 5 _ le
  decide +kernel
theorem b103 : Blocked tgt 5 s103 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3738,1754,1364,1754,453,453,841,1946,841,1946,837,3730,837,3218,1349,3722,1349,2698,1364,1754,1754,1364,1754,777,1946,1754,1234,1242,1746,1234,714,730,1738,714,841,1946,841,1946,837,2249,837,2501,1349,2452,1349,2501,1426,1434,1938,1426,906,922,1930,906,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b105 : Blocked tgt 5 s105 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1754,1364,389,389,1754,453,1754,841,1946,1754,1234,1242,1746,1234,714,730,1738,714,3476,453,1428,453,3738,841,1816,841,3218,837,3226,837,2698,1349,2714,1349,713,197,841,713,453,201,837,453,453,2452,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b106 : Blocked tgt 5 s106 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s106 5 _ le
  decide +kernel
theorem b107 : Blocked tgt 5 s107 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s107 5 _ le
  decide +kernel
theorem b108 : Blocked tgt 5 s108 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,389,1428,1364,1754,1364,1946,1754,3738,1754,1754,1624,1234,1242,1746,1234,714,730,1738,714,197,197,453,2761,2761,453,453,713,453,2249,837,453,453,404,1349,453,841,841,1426,837,1938,837,1609,1349,1609,1349,3218,837,3226,837,1609,1349,1609,1349,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b109 : Blocked tgt 5 s109 := by
  apply PetersenFastNode.node (nxt := #[s110]) (hints := [3739,1755,1365,1755,454,714,842,1947,838,3731,838,3219,1350,3723,1350,2699,1365,1755,1755,1365,1755,778,1817,1755,1235,1243,1747,1235,715,731,1739,715,842,454,842,970,454,2250,838,454,454,405,1350,454,0,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s110], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M111
