import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) tgt 6 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s25] [194,195,195,195,196,1091,835,1091,390,195,455,195,196,1091,839,1091,714,715,715,715,716,1611,843,1611,390,715,455,715,716,1611,1351,1611,1106,195,195,195,1236,1428,835,839,1366,195,455,195,1236,3220,839,839,1626,715,715,715,1756,1948,843,1948,1366,715,455,715,1756,3740,3740,3740,2210,2275,2275,2275,196,3171,2915,3171,2470,2275,2535,2275,196,3171,2919,3171,2730,2795,2795,2795,716,3691,2923,3691,2470,2795,2535,2795,716,3691,3431,3691,3186,2275,2275,2275,1236,1428,2915,2919,3446,2275,2535,2275,1236,3446,2919,2919,3706,2795,2795,2795,1756,1948,2923,1948,3446,2795,2535,2795,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s25], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M111
