import M127StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r19 (x : Fin 16) : Fin 128 := (#[0,1,2,3,16,17,18,19,64,65,66,67,80,81,82,83] : Array (Fin 128))[x.val]?.getD 0
theorem small19 : NoAtMost i4 (PetersenPackedPin.project r19 tgt) 3 := by
  have a : PetersenPackedPin.project r19 tgt = table 83 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 83 0 (by decide +kernel) (by decide +kernel)
theorem hot19 : forcedConst r19 tgt = false := by decide +kernel
def r21 (x : Fin 16) : Fin 128 := (#[8,9,10,11,40,41,42,43,72,73,74,75,104,105,106,107] : Array (Fin 128))[x.val]?.getD 0
theorem small21 : NoAtMost i4 (PetersenPackedPin.project r21 tgt) 3 := by
  have a : PetersenPackedPin.project r21 tgt = table 99 8 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 99 8 (by decide +kernel) (by decide +kernel)
theorem hot21 : forcedConst r21 tgt = false := by decide +kernel
def r23 (x : Fin 16) : Fin 128 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27] : Array (Fin 128))[x.val]?.getD 0
theorem small23 : NoAtMost i4 (PetersenPackedPin.project r23 tgt) 3 := by
  have a : PetersenPackedPin.project r23 tgt = table 27 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 27 0 (by decide +kernel) (by decide +kernel)
theorem hot23 : forcedConst r23 tgt = false := by decide +kernel
end PetersenSmallStarts.M127
