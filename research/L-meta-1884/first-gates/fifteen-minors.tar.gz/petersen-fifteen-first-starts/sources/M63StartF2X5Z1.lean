import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_5_1 : NoAtMost (0xf0f0f0f0 :: inputs 6) tgt 7 := by
  change NoAtMost [0xf0f0f0f0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1235] [194,390,195,455,196,774,835,839,390,390,455,455,196,774,839,839,714,390,715,455,716,1350,843,1351,390,390,455,455,716,1350,1351,1351,1106,1366,195,455,1236,1366,835,839,1366,1366,455,455,1236,1366,839,839,714,1366,715,455,716,1366,843,2635,1366,1366,455,455,716,1366,2375,2635,2146,390,195,455,2276,774,835,839,2406,390,455,455,2276,774,839,839,2666,390,715,455,2796,1350,843,1351,2406,390,455,455,2796,1350,1351,1351,3186,1366,195,455,3316,1366,835,839,3446,1366,455,455,3316,1366,839,839,2666,1366,715,455,2796,1366,843,2988,3446,1366,455,455,2796,1366,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1235], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1235) b1235 <|
    PetersenLocalChildren.nil
#print axioms gate_2_5_1
end PetersenSmallStarts.M63
