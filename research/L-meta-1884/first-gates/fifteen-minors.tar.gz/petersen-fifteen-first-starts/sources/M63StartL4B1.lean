import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b534 : Blocked tgt 4 s534 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2633,713,388,713,1349,837,1097,837,1609,841,1093,841,2632,713,2760,713,1218,837,2754,837,906,841,906,841,453,201,837,453,713,197,841,713,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b551 : Blocked tgt 4 s551 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1674,714,194,714,1349,453,388,453,1609,841,1093,841,1349,837,1097,837,388,453,712,453,714,777,906,714,202,202,714,837,713,197,841,713,453,201,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b700 : Blocked tgt 4 s700 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s700 4 _ le
  decide +kernel
theorem b723 : Blocked tgt 4 s723 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1426,1234,1104,1234,193,193,833,1682,833,1426,1089,1410,1089,386,1104,1234,1234,1104,1234,769,1682,1234,194,210,1218,194,449,1682,833,1682,449,400,1089,449,833,1682,1666,1666]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b746 : Blocked tgt 4 s746 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s746 4 _ le
  decide +kernel
theorem b756 : Blocked tgt 4 s756 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s756 4 _ le
  decide +kernel
theorem b761 : Blocked tgt 4 s761 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,1364,712,1364,776,776,1428,1812,1552,1428,388,1412,404,388,712,1364,1364,712,1364,200,1812,1364,2372,1364,1348,1348,1424,1812,1552,1812,904,400,1544,904,772,788,1796,772]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b771 : Blocked tgt 4 s771 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [468,468,389,1364,841,841,1428,837,1552,837,453,453,713,1349,904,1364,1364,208,1364,773,1812,1364,1544,1349,1348,1348,1424,837,1552,837,713,1349,713,1349,837,788,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b788 : Blocked tgt 4 s788 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s788 4 _ le
  decide +kernel
theorem b797 : Blocked tgt 4 s797 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s797 4 _ le
  decide +kernel
theorem b843 : Blocked tgt 4 s843 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1106,1364,1428,776,1426,776,1424,1428,1554,388,404,1412,388,1234,1108,1426,1234,1234,712,1812,1234,194,210,1218,194,1426,1556,1552,1426,386,402,1410,386,772,788,1796,772]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b968 : Blocked tgt 4 s968 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s968 4 _ le
  decide +kernel
theorem b1039 : Blocked tgt 4 s1039 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1039 4 _ le
  decide +kernel
theorem b1055 : Blocked tgt 4 s1055 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1055 4 _ le
  decide +kernel
theorem b1105 : Blocked tgt 4 s1105 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1105 4 _ le
  decide +kernel
theorem b1109 : Blocked tgt 4 s1109 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [837,453,193,453,1426,1426,1234,1364,1234,1364,837,1349,788,837,193,453,453,193,1364,389,1364,1428,453,404,1349,453,1234,1364,1234,1364,898,1349,2946,1349,194,1349,1348,1348]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
