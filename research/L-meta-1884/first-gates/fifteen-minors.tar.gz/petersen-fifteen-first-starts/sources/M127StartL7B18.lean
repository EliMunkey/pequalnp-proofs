import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B21
import M127StartL6B20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b668 : Blocked tgt 7 s668 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s668 7 _ le
  decide +kernel
theorem b669 : Blocked tgt 7 s669 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s669 7 _ le
  decide +kernel
theorem b670 : Blocked tgt 7 s670 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s670 7 _ le
  decide +kernel
theorem b671 : Blocked tgt 7 s671 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s671 7 _ le
  decide +kernel
theorem b672 : Blocked tgt 7 s672 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s672 7 _ le
  decide +kernel
theorem b673 : Blocked tgt 7 s673 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s673 7 _ le
  decide +kernel
theorem b674 : Blocked tgt 7 s674 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s674 7 _ le
  decide +kernel
theorem b675 : Blocked tgt 7 s675 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s675 7 _ le
  decide +kernel
theorem b676 : Blocked tgt 7 s676 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s676 7 _ le
  decide +kernel
theorem b677 : Blocked tgt 7 s677 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s677 7 _ le
  decide +kernel
theorem b678 : Blocked tgt 7 s678 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s678 7 _ le
  decide +kernel
theorem b679 : Blocked tgt 7 s679 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s679 7 _ le
  decide +kernel
theorem b680 : Blocked tgt 7 s680 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s680 7 _ le
  decide +kernel
theorem b681 : Blocked tgt 7 s681 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s681 7 _ le
  decide +kernel
theorem b682 : Blocked tgt 7 s682 := by
  apply PetersenFastNode.node (nxt := #[s683,s659,s633,s684]) (hints := [13614,0,1,13614,13614,5550,5292,5550,905,905,1677,5934,1677,5934,14646,7478,12590,7478,2697,7470,2697,7470,4745,13582,4745,9486,5550,6582,9613,9097,9613,9097,5934,2,5934,3,7478,1673,7470,2697,7470,2697,5261,4745,5261,4745,15160,5550,5550,9097,5550,1549,5934,5550,7478,5550,7606,5550,2697,7470,5550,1422,1454,5518,1422,8581,5934,9093,5934,9097,7478,9613,7478,2697,7470,2697,7470,4745,11064,4745,9097,6966,4910,7478,6966,5934,4918,7470,5934,1806,1838,5902,1806,2697,7470,7462,7462,3350,3382,7446,3350,3342,3374,7438,3342]) (by decide +kernel)
  change ∀ b ∈ [s683,s659,s633,s684], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s683) b683 <|
    PetersenLocalChildren.push (x := s659) b659 <|
    PetersenLocalChildren.push (x := s633) b633 <|
    PetersenLocalChildren.push (x := s684) b684 <|
    PetersenLocalChildren.nil
theorem b685 : Blocked tgt 7 s685 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s685 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
