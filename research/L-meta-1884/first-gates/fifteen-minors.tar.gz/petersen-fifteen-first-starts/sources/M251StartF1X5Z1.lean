import M251StartData
import M251StartL7B1
import M251StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_1 : NoAtMost (0xcccccccc00000000cccccccc :: inputs 7) tgt 7 := by
  change NoAtMost [0xcccccccc00000000cccccccc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s34,s0,s49] [387,389,388,1797,389,389,1156,1797,903,905,904,1801,905,905,1672,1801,1163,1421,388,1805,1421,1421,2180,1805,903,905,904,11017,905,905,2696,11017,2195,2453,388,3861,2453,2453,1156,3861,2711,2969,904,3865,2969,2969,1672,3865,3227,3485,388,3869,3485,3485,3869,3869,2711,2969,904,11033,2969,2969,6937,11033,4387,389,4516,1797,389,389,5284,1797,4903,905,5032,1801,905,905,5800,1801,5291,1421,4516,1805,1421,1421,6308,1805,4903,905,5032,11017,905,905,6824,11017,6323,2453,4516,3861,2453,2453,5284,3861,6839,2969,5032,3865,2969,2969,5800,3865,7355,3485,4516,3869,3485,3485,3869,3869,6839,2969,5032,11033,2969,2969,11033,11033,8643,8645,8644,10053,8645,8645,9412,10053,9159,9161,9160,10057,9161,9161,9928,10057,9419,9677,8644,10061,9677,9677,10436,10061,9159,9161,9160,11081,9161,9161,10952,11081,2195,2453,8644,3861,2453,2453,9412,3861,2711,2969,9160,3865,2969,2969,9928,3865,3227,3485,8644,3869,3485,3485,3869,3869,2711,2969,9160,13256,2969,2969,6937,0,12643,8645,12772,10053,8645,8645,13540,10053,13159,9161,13288,10057,9161,9161,14056,10057,13547,9677,12772,10061,9677,9677,14564,10061,13159,9161,13288,11081,9161,9161,15080,11081,6323,2453,12772,3861,2453,2453,13540,3861,6839,2969,13288,3865,2969,2969,14056,3865,7355,3485,12772,3869,3485,3485,3869,3869,6839,2969,13288,13288,2969,2969,1,2] (by decide +kernel)
  change ∀ b ∈ [s34,s0,s49], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_1
end PetersenSmallStarts.M251
