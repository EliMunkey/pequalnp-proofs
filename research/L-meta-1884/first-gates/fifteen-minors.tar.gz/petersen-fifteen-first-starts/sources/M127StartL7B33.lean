import M127StartData
import M127StartPins0
import M127StartL6B35
import M127StartL6B27
import M127StartL6B30
import M127StartL6B8
import M127StartL6B31
import M127StartL6B32
import M127StartL6B33
import M127StartL6B36
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1163 : Blocked tgt 7 s1163 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1163 7 _ le
  decide +kernel
theorem b1164 : Blocked tgt 7 s1164 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1164 7 _ le
  decide +kernel
theorem b1165 : Blocked tgt 7 s1165 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1165 7 _ le
  decide +kernel
theorem b1166 : Blocked tgt 7 s1166 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1418,1418,12997,9157,11092,9157,13513,9929,12997,9929,12997,9925,13513,9925,12481,12997,12997,12481,12997,10949,3338,10949,4741,12933,4805,4741,11092,9157,11092,9157,1802,9929,1802,9929,6546,9925,5514,9925,6546,5514,5514,6546,3338,10949,3338,10949,5514,6868,9482,5514,9673,9157,9929,9673,9157,9673,9925,9157,8641,9157,9157,8641,9157,9044,10949,9157,901,965,9093,901,778,9929,9925,9929,2834,9929,10949,11465,9929,1673,1737,9865,1673,9925,3346,9925,11465,10949,9925,1669,1733,9861,1669,10433,10949,10433,10949,10514,9482,10514,9482,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1167 : Blocked tgt 7 s1167 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1167 7 _ le
  decide +kernel
theorem b1168 : Blocked tgt 7 s1168 := by
  apply PetersenFastNode.node (nxt := #[s1169]) (hints := [12998,13514,13514,12998,1419,1419,13514,9674,9545,9674,13514,12994,12486,13514,12998,13514,13514,9926,13514,11466,3339,11466,5258,13450,5322,5258,6547,5515,6547,5515,9158,9674,9158,9674,9930,9930,9926,3347,10950,11466,10950,11466,10515,9483,10515,9483,9545,9674,9545,9674,5515,14549,2835,5515,6547,9926,5515,9926,3339,11466,3339,11466,5515,5321,9483,5515,9674,8646,9154,9674,9158,9674,9674,9158,9674,3083,11466,9674,1418,1482,9610,1418,2835,9926,9922,11466,10438,11466,10946,9483,0,9483,2835,9926,11466,10950,11466,1670,1734,9862,1670,3210,3274,11402,3210]) (by decide +kernel)
  change ∀ b ∈ [s1169], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1169) b1169 <|
    PetersenLocalChildren.nil
theorem b1170 : Blocked tgt 7 s1170 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1170 7 _ le
  decide +kernel
theorem b1171 : Blocked tgt 7 s1171 := by
  apply PetersenFastNode.node (nxt := #[s929,s1172,s1174,s1175]) (hints := [1422,1422,13001,9161,11096,9161,13517,13001,13001,13517,13001,9929,12493,9929,13001,10953,0,10953,13517,13001,13001,13517,4745,12937,4809,4745,11096,9161,11096,9161,5518,14552,2838,5518,3350,9929,3350,9929,5518,10953,6550,10953,5518,6550,6550,5518,5518,6872,9486,5518,9677,9161,9161,9677,9161,8653,9929,9161,9161,9048,10953,9161,9677,9161,9161,9677,905,969,9097,905,2838,9929,3350,9929,10441,2838,10953,9933,9933,9486,1,9486,2838,9929,3350,10953,9929,2,9929,9929,3,1673,1737,9865,1673,10953,11469,2697,2761,10889,2697,9486,10518,9486,10518]) (by decide +kernel)
  change ∀ b ∈ [s929,s1172,s1174,s1175], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s929) b929 <|
    PetersenLocalChildren.push (x := s1172) b1172 <|
    PetersenLocalChildren.push (x := s1174) b1174 <|
    PetersenLocalChildren.push (x := s1175) b1175 <|
    PetersenLocalChildren.nil
theorem b1176 : Blocked tgt 7 s1176 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1176 7 _ le
  decide +kernel
theorem b1177 : Blocked tgt 7 s1177 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s1177 7 _ le
  decide +kernel
theorem b1178 : Blocked tgt 7 s1178 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1178 7 _ le
  decide +kernel
theorem b1179 : Blocked tgt 7 s1179 := by
  apply PetersenFastNode.node (nxt := #[s1180,s1181,s1016,s231,s1056,s934,s1032,s1182,s1086,s1183,s1110,s1185,s1186,s1118,s1189,s1169,s1172,s1190,s1191,s1192]) (hints := [1438,4761,5534,1438,0,1,4761,4761,2856,921,2,921,2856,3,2856,921,4761,921,5853,13533,1628,1757,4761,1757,4761,4761,1628,1757,13533,1757,4761,4761,3366,1689,13533,1689,12509,13533,3366,1689,4761,1689,4761,4761,3358,2713,4,2713,3358,5,3358,2713,4761,2713,5277,5277,9502,4761,4761,6,4761,4761,9502,5277,5277,7,2856,6824,2856,921,5534,921,2856,5534,2856,921,6824,921,5534,5534,1628,1757,6824,1757,1628,6824,1628,1757,5534,1757,3366,6566,3366,1689,5534,1689,3366,5534,3366,1689,6566,1689,3358,5534,3358,2713,6566,2713,3358,6566,3358,2713,5534,2713,5534,5534,9502,6824,6824,8,9502,6824,9502,5534,5534,9,1757,9693,1757,921,921,10,1757,921,1757,2013,9693,11,921,921,1689,8669,9693,3366,1689,9693,1689,921,921,3366,921,921,2713,808,2856,3358,2713,2856,2713,921,921,3358,1437,1437,12,921,921,9502,921,921,13,1437,1437,9502,3366,14,3366,1689,1757,1689,1749,1757,3366,1689,15,1689,1757,1757,11485,2713,16,2713,3805,17,11485,1757,1757,2713,1693,1757,9502,1693,18,19,1689,1689,2713,10461,3366,11485,2713,3366,2713,1689,1689,11485,3366,3366,10534,1689,1689,9502,1689,1689,10534,3366,3366,9502,3229,3229,9502,2713,2713,10534,2713,2713,9502,3229,3229,10534]) (by decide +kernel)
  change ∀ b ∈ [s1180,s1181,s1016,s231,s1056,s934,s1032,s1182,s1086,s1183,s1110,s1185,s1186,s1118,s1189,s1169,s1172,s1190,s1191,s1192], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1180) b1180 <|
    PetersenLocalChildren.push (x := s1181) b1181 <|
    PetersenLocalChildren.push (x := s1016) b1016 <|
    PetersenLocalChildren.push (x := s231) b231 <|
    PetersenLocalChildren.push (x := s1056) b1056 <|
    PetersenLocalChildren.push (x := s934) b934 <|
    PetersenLocalChildren.push (x := s1032) b1032 <|
    PetersenLocalChildren.push (x := s1182) b1182 <|
    PetersenLocalChildren.push (x := s1086) b1086 <|
    PetersenLocalChildren.push (x := s1183) b1183 <|
    PetersenLocalChildren.push (x := s1110) b1110 <|
    PetersenLocalChildren.push (x := s1185) b1185 <|
    PetersenLocalChildren.push (x := s1186) b1186 <|
    PetersenLocalChildren.push (x := s1118) b1118 <|
    PetersenLocalChildren.push (x := s1189) b1189 <|
    PetersenLocalChildren.push (x := s1169) b1169 <|
    PetersenLocalChildren.push (x := s1172) b1172 <|
    PetersenLocalChildren.push (x := s1190) b1190 <|
    PetersenLocalChildren.push (x := s1191) b1191 <|
    PetersenLocalChildren.push (x := s1192) b1192 <|
    PetersenLocalChildren.nil
theorem b1193 : Blocked tgt 7 s1193 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1193 7 _ le
  decide +kernel
theorem b1194 : Blocked tgt 7 s1194 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1194 7 _ le
  decide +kernel
theorem b1195 : Blocked tgt 7 s1195 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1195 7 _ le
  decide +kernel
theorem b1196 : Blocked tgt 7 s1196 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1196 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
