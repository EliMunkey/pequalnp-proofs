import M51StartData
import M51StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_1 : NoAtMost (0xc0c :: inputs 4) tgt 2 := by
  change NoAtMost [0xc0c,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s7,s0,s8] [51,53,52,84,53,53,84,84,87,53,52,148,121,53,148,148,155,189,52,84,189,189,84,84,223,189,52,0,257,189,1,2] (by decide +kernel)
  change ∀ b ∈ [s7,s0,s8], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_1
end PetersenSmallStarts.M51
