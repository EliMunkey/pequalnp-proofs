import M127StartData
import M127StartPins0
import M127StartL6B5
import M127StartL6B25
import M127StartL6B26
import M127StartL6B23
import M127StartL6B24
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b872 : Blocked tgt 7 s872 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s872 7 _ le
  decide +kernel
theorem b873 : Blocked tgt 7 s873 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s873 7 _ le
  decide +kernel
theorem b874 : Blocked tgt 7 s874 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s874 7 _ le
  decide +kernel
theorem b875 : Blocked tgt 7 s875 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s875 7 _ le
  decide +kernel
theorem b876 : Blocked tgt 7 s876 := by
  apply PetersenFastNode.node (nxt := #[s149,s150,s877,s878,s879,s880,s881,s882,s883,s826,s842,s884]) (hints := [5526,0,5526,2462,13009,2462,1430,13009,5526,1430,1,2462,13009,13009,15232,9169,2,9169,11136,3,15232,9169,13009,9169,13525,13525,1814,9941,13009,9941,12497,13009,1814,9941,13525,9941,13009,13009,7486,9937,13525,9937,12501,13525,7486,9937,13009,9937,13009,13009,7446,10961,4,10961,3350,5,7446,10961,13009,10961,4753,4753,9494,12945,13009,10526,4817,13009,9494,4753,4753,10526,10976,10976,11104,9169,2462,9169,11104,2462,11104,10976,10976,9169,2462,2462,2846,9941,10976,9941,2846,10976,2846,2462,2462,9941,2462,2462,3358,9937,5526,9937,3358,5526,3358,2462,2462,9937,414,5526,7446,414,2462,10961,2462,2462,7446,10961,5526,10961,2462,2462,10526,2784,10976,6,10526,10976,10526,2462,2462,7,9685,9685,9941,8657,9169,2846,9941,9169,9941,9685,9685,2846,9169,9169,9937,8661,9685,3358,9937,9685,9937,9169,9169,3358,9169,9169,10961,11104,11104,7446,10961,11104,10961,9169,9169,7446,913,913,8,977,9169,10526,9105,9169,9,913,913,10526,2846,2846,3358,9937,9941,9937,9933,9941,3358,9933,2846,9937,9941,9941,11477,10449,2846,10961,11477,2846,11477,9941,9941,10961,1685,1685,10526,1749,9941,10,9877,9941,10526,1685,1685,11,9937,9937,10961,10453,3358,11477,10961,3358,10961,9937,9937,11477,1681,1681,10526,1745,9937,9494,9873,9937,10526,1681,1681,9494,2705,2705,9494,2769,10961,10526,10897,10961,9494,2705,2705,10526]) (by decide +kernel)
  change ∀ b ∈ [s149,s150,s877,s878,s879,s880,s881,s882,s883,s826,s842,s884], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s149) b149 <|
    PetersenLocalChildren.push (x := s150) b150 <|
    PetersenLocalChildren.push (x := s877) b877 <|
    PetersenLocalChildren.push (x := s878) b878 <|
    PetersenLocalChildren.push (x := s879) b879 <|
    PetersenLocalChildren.push (x := s880) b880 <|
    PetersenLocalChildren.push (x := s881) b881 <|
    PetersenLocalChildren.push (x := s882) b882 <|
    PetersenLocalChildren.push (x := s883) b883 <|
    PetersenLocalChildren.push (x := s826) b826 <|
    PetersenLocalChildren.push (x := s842) b842 <|
    PetersenLocalChildren.push (x := s884) b884 <|
    PetersenLocalChildren.nil
theorem b885 : Blocked tgt 7 s885 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s885 7 _ le
  decide +kernel
theorem b886 : Blocked tgt 7 s886 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s886 7 _ le
  decide +kernel
theorem b887 : Blocked tgt 7 s887 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s887 7 _ le
  decide +kernel
theorem b888 : Blocked tgt 7 s888 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s888 7 _ le
  decide +kernel
theorem b889 : Blocked tgt 7 s889 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s889 7 _ le
  decide +kernel
theorem b890 : Blocked tgt 7 s890 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s890 7 _ le
  decide +kernel
theorem b891 : Blocked tgt 7 s891 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s891 7 _ le
  decide +kernel
theorem b893 : Blocked tgt 7 s893 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s893 7 _ le
  decide +kernel
theorem b894 : Blocked tgt 7 s894 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s894 7 _ le
  decide +kernel
theorem b895 : Blocked tgt 7 s895 := by
  apply PetersenFastNode.node (nxt := #[s896,s897,s898,s899,s900]) (hints := [9034,9034,5551,9162,15097,5551,5551,15097,5551,9934,5935,5551,6583,4527,7479,6583,5551,4535,7471,5551,1423,1455,5519,1423,5551,6905,13615,5551,9162,15225,9678,8650,9934,9678,9162,8654,9930,9162,9162,7471,11210,9162,9162,0,13002,9162,906,970,9098,906,13933,9934,13933,9934,15993,9930,15993,9930,10954,10954,15469,7471,1,13002,2,13002,3,13615,4,13615,6967,9930,9926,9926,9934,4919,7471,9934,9934,12490,13518,9934,1678,1742,9870,1678,9930,7471,7463,9930,9930,12494,13002,9930,1674,1738,9866,1674,13002,3375,13002,3343,7471,12599,13615,7471,4746,4810,12938,4746]) (by decide +kernel)
  change ∀ b ∈ [s896,s897,s898,s899,s900], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s896) b896 <|
    PetersenLocalChildren.push (x := s897) b897 <|
    PetersenLocalChildren.push (x := s898) b898 <|
    PetersenLocalChildren.push (x := s899) b899 <|
    PetersenLocalChildren.push (x := s900) b900 <|
    PetersenLocalChildren.nil
theorem b901 : Blocked tgt 7 s901 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s901 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
