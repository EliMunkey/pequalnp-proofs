import M111StartData
import M111StartL6B0
import M111StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_5_1 : NoAtMost (0xff00ff00 :: inputs 6) tgt 6 := by
  change NoAtMost [0xff00ff00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s144] [194,714,195,715,196,716,835,843,390,714,455,715,196,716,839,1611,714,714,715,715,716,716,843,843,390,714,455,715,716,716,1351,1611,1106,1626,195,715,1236,1756,835,843,1366,1626,455,715,1236,1756,839,2887,1626,1626,715,715,1756,1756,843,843,1366,1626,455,715,1756,1756,3740,3220,2210,714,2275,715,196,716,2915,843,2470,714,2535,715,196,716,2919,1611,2730,714,2795,715,716,716,2923,843,2470,714,2535,715,716,716,3431,1611,3186,1626,2275,715,1236,1756,2915,843,3446,1626,2535,715,1236,1756,2919,2919,3706,1626,2795,715,1756,1756,2923,843,3446,1626,2535,715,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s144], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s144) b144 <|
    PetersenLocalChildren.nil
#print axioms gate_3_5_1
end PetersenSmallStarts.M111
