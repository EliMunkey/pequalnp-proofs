import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b881 : Blocked tgt 6 s881 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s881 6 _ le
  decide +kernel
theorem b882 : Blocked tgt 6 s882 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s882 6 _ le
  decide +kernel
theorem b883 : Blocked tgt 6 s883 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s883 6 _ le
  decide +kernel
theorem b884 : Blocked tgt 6 s884 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s884 6 _ le
  decide +kernel
theorem b896 : Blocked tgt 6 s896 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s896 6 _ le
  decide +kernel
theorem b897 : Blocked tgt 6 s897 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s897 6 _ le
  decide +kernel
theorem b898 : Blocked tgt 6 s898 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s898 6 _ le
  decide +kernel
theorem b899 : Blocked tgt 6 s899 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s899 6 _ le
  decide +kernel
theorem b900 : Blocked tgt 6 s900 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s900 6 _ le
  decide +kernel
theorem b904 : Blocked tgt 6 s904 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s904 6 _ le
  decide +kernel
theorem b905 : Blocked tgt 6 s905 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s905 6 _ le
  decide +kernel
theorem b906 : Blocked tgt 6 s906 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s906 6 _ le
  decide +kernel
theorem b907 : Blocked tgt 6 s907 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s907 6 _ le
  decide +kernel
theorem b917 : Blocked tgt 6 s917 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s917 6 _ le
  decide +kernel
theorem b918 : Blocked tgt 6 s918 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s918 6 _ le
  decide +kernel
theorem b919 : Blocked tgt 6 s919 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9029,9029,1418,9157,10964,1418,1418,10964,1418,9929,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1418,2772,9482,1418,9157,11092,9673,8645,9929,9673,9157,8649,9925,9157,9157,3338,11205,9157,901,965,9093,901,13513,9929,12485,9929,12997,9925,12489,9925,10949,10949,11336,12997,4741,12933,4805,4741,2834,9925,9921,9921,9929,786,3338,9929,1673,1737,9865,1673,9925,3338,3330,9925,1669,1733,9861,1669,3338,8466,9482,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
