import M47StartData
import M47StartL4B0
import M47StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_4_0 : NoAtMost (0xffffff00 :: inputs 5) tgt 4 := by
  change NoAtMost [0xffffff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s22] [98,362,99,363,100,364,419,427,198,406,231,231,100,364,423,555,362,362,363,363,364,364,427,427,198,694,231,231,364,364,679,811,562,562,99,363,628,628,419,427,694,694,231,231,628,628,423,918,826,826,363,363,892,892,427,427,694,694,231,231,892,892,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s22], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.nil
#print axioms gate_3_4_0
end PetersenSmallStarts.M47
