import M251StartData
import M251StartPins0
import M251StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b33 : Blocked tgt 7 s33 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s33 7 _ le
  decide +kernel
theorem b34 : Blocked tgt 7 s34 := by
  apply PetersenFastNode.node (nxt := #[s35,s36,s37,s38,s39,s41,s42,s44,s45,s46,s47,s48]) (hints := [6946,6946,2720,2978,0,2978,2720,1,2720,2978,6946,2978,9169,6946,13265,9169,2,3,7462,7462,3620,3878,6946,3878,6434,6946,3620,3878,7462,3878,9937,6946,9937,3874,7462,3874,9937,7462,9937,3874,6946,3874,10961,13138,10961,11090,6946,11090,10961,6946,10961,11090,13138,11090,6946,6946,10784,11042,13138,11042,4946,13138,10784,6946,6946,11042,2720,2720,6944,2978,2978,13265,2978,2978,6944,2720,2720,13265,3494,3494,3878,2466,2978,4,3878,2978,3878,3494,3494,5,2978,2978,3874,2470,3494,9937,3874,3494,3874,2978,2978,9937,9170,9170,11090,930,2978,10961,11090,2978,11090,9170,9170,10961,2978,2978,11042,978,9170,6,11042,9170,11042,2978,2978,7,12749,12749,3620,3878,13265,3878,13261,13265,3620,3878,12749,3878,9937,13265,9937,3874,7460,3874,9937,7460,9937,3874,13265,3874,10961,13265,10961,11090,6944,11090,10961,6944,10961,11090,13265,11090,5009,5009,10784,11042,13265,11042,13201,13265,10784,11042,5009,11042,9421,8,9421,3874,3878,3874,3870,3878,9421,3870,9,3874,10070,10070,11606,1830,3878,11090,11606,3878,11606,10070,10070,11090,3878,3878,11558,1878,10070,11042,11558,10070,11558,3878,3878,11042,10066,10066,11090,1826,3874,11606,11090,3874,11090,10066,10066,11606,3874,3874,11042,1874,10066,11558,11042,10066,11042,3874,3874,11558,2705,2705,10,11042,11090,11042,11026,11090,11,11026,2705,11042]) (by decide +kernel)
  change ∀ b ∈ [s35,s36,s37,s38,s39,s41,s42,s44,s45,s46,s47,s48], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s41) b41 <|
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s46) b46 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.nil
theorem b49 : Blocked tgt 7 s49 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s49 7 _ le
  decide +kernel
theorem b50 : Blocked tgt 7 s50 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s50 7 _ le
  decide +kernel
theorem b51 : Blocked tgt 7 s51 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s51 7 _ le
  decide +kernel
theorem b52 : Blocked tgt 7 s52 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s52 7 _ le
  decide +kernel
theorem b53 : Blocked tgt 7 s53 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s53 7 _ le
  decide +kernel
theorem b54 : Blocked tgt 7 s54 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s54 7 _ le
  decide +kernel
theorem b55 : Blocked tgt 7 s55 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s55 7 _ le
  decide +kernel
end PetersenSmallStarts.M251
