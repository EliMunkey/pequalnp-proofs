import M127StartData
import M127StartPins0
import M127StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b42 : Blocked tgt 6 s42 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s42 6 _ le
  decide +kernel
theorem b43 : Blocked tgt 6 s43 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s43 6 _ le
  decide +kernel
theorem b44 : Blocked tgt 6 s44 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s44 6 _ le
  decide +kernel
theorem b45 : Blocked tgt 6 s45 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s45 6 _ le
  decide +kernel
theorem b46 : Blocked tgt 6 s46 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s46 6 _ le
  decide +kernel
theorem b47 : Blocked tgt 6 s47 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s47 6 _ le
  decide +kernel
theorem b48 : Blocked tgt 6 s48 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s48 6 _ le
  decide +kernel
theorem b49 : Blocked tgt 6 s49 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s49 6 _ le
  decide +kernel
theorem b50 : Blocked tgt 6 s50 := by
  apply PetersenFastNode.node (nxt := #[s21,s51]) (hints := [4743,903,0,903,2774,2774,5900,1804,1836,1804,7444,3348,3380,3348,7436,3340,3372,3340,5516,1420,1452,1420,903,7126,1419,1804,1675,1419,903,3348,1671,903,903,3340,2695,903,775,775,903,1420,5322,1804,5834,1804,6870,3348,7894,3348,4806,3340,6854,3340,1,1420,6806,1420,2836,780,3348,2836,1804,788,3340,1804,1420,1675,1420,1804,1671,3340,3332,3332,2452,396,2452,3348,1420,404,1420,3340]) (by decide +kernel)
  change ∀ b ∈ [s21,s51], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.nil
theorem b52 : Blocked tgt 6 s52 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s52 6 _ le
  decide +kernel
theorem b53 : Blocked tgt 6 s53 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s53 6 _ le
  decide +kernel
theorem b54 : Blocked tgt 6 s54 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s54 6 _ le
  decide +kernel
theorem b55 : Blocked tgt 6 s55 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s55 6 _ le
  decide +kernel
theorem b56 : Blocked tgt 6 s56 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s56 6 _ le
  decide +kernel
theorem b57 : Blocked tgt 6 s57 := by
  apply PetersenFastNode.node (nxt := #[s29,s58,s59]) (hints := [2775,3031,1420,5933,1676,5933,904,3349,1672,904,904,3373,11371,904,904,0,4744,904,776,776,904,5549,5355,5933,5867,5933,2775,3349,3799,3349,4823,3373,2775,3373,1,2775,2775,4744,2,5549,2711,5549,2837,4909,3349,2837,3373,2837,3373,3885,1805,1837,5901,1805,5549,1676,5549,5933,1672,3349,3349,3365,1672,3349,3349,1672,2453,4525,2453,3349,3341,3341,3373,2453,3501,3373,1421,1453,1421,5517]) (by decide +kernel)
  change ∀ b ∈ [s29,s58,s59], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s58) b58 <|
    PetersenLocalChildren.push (x := s59) b59 <|
    PetersenLocalChildren.nil
theorem b60 : Blocked tgt 6 s60 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s60 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
