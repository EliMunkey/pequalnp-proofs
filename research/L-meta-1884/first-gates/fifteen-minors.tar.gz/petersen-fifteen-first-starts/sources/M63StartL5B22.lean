import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b784 : Blocked tgt 5 s784 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s784 5 _ le
  decide +kernel
theorem b785 : Blocked tgt 5 s785 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s785 5 _ le
  decide +kernel
theorem b786 : Blocked tgt 5 s786 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s786 5 _ le
  decide +kernel
theorem b787 : Blocked tgt 5 s787 := by
  apply PetersenFastNode.node (nxt := #[s788]) (hints := [1461,1525,1235,842,1427,842,1235,838,1747,838,195,1350,1219,1350,390,390,1235,454,907,842,907,842,1461,838,1973,838,421,1350,1445,1350,0,454,1429,454,1427,838,834,834,842,1094,1610,842,714,198,714,842,838,1098,1350,838,454,202,454,838,454,1547,454,1350]) (by decide +kernel)
  change ∀ b ∈ [s788], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s788) b788 <|
    PetersenLocalChildren.nil
theorem b796 : Blocked tgt 5 s796 := by
  apply PetersenFastNode.node (nxt := #[s797]) (hints := [715,778,907,715,3445,203,1683,3445,1461,715,1461,1525,2405,2421,3429,2405,1365,1397,3413,1365,1427,842,842,1427,0,842,842,1457,842,1094,1610,842,714,2118,714,842,838,838,1350,1610,1350,1610,2374,202,2374,714,1350,1610,1350,1610,2374,714,454,454,1350,1547,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s797], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s797) b797 <|
    PetersenLocalChildren.nil
theorem b798 : Blocked tgt 5 s798 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s798 5 _ le
  decide +kernel
theorem b802 : Blocked tgt 5 s802 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(true,(0,false),(5,false))] s802 5 _ le
  decide +kernel
theorem b803 : Blocked tgt 5 s803 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s803 5 _ le
  decide +kernel
theorem b804 : Blocked tgt 5 s804 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(true,(0,false),(5,false))] s804 5 _ le
  decide +kernel
theorem b805 : Blocked tgt 5 s805 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [404,2666,404,468,2794,777,2986,2794,194,2794,1666,194,1706,194,1706,1770,714,746,2762,714,713,2858,841,713,837,713,837,965,713,404,404,713,2373,404,2373,713,386,837,833,833,841,386,1706,841,841,2117,2633,841,837,1666,1666,837,837,2121,2373,837,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b806 : Blocked tgt 5 s806 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(true,(0,false),(5,false))] s806 5 _ le
  decide +kernel
theorem b808 : Blocked tgt 5 s808 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2666,1428,1364,2794,777,2986,2794,1234,2794,1682,1234,1706,1234,1706,1770,714,746,2762,714,713,2858,841,713,837,713,837,965,713,1428,453,453,2373,404,2373,713,1426,837,833,833,841,1426,1706,841,841,2117,2633,841,837,1682,1682,837,837,2121,2373,837,2373,1706,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b809 : Blocked tgt 5 s809 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(true,(0,false),(5,false))] s809 5 _ le
  decide +kernel
theorem b810 : Blocked tgt 5 s810 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s810 5 _ le
  decide +kernel
theorem b811 : Blocked tgt 5 s811 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s811 5 _ le
  decide +kernel
theorem b815 : Blocked tgt 5 s815 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(false,(0,true),(5,false))] s815 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
