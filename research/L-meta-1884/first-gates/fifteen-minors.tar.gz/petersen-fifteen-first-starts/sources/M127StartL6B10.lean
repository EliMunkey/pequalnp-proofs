import M127StartData
import M127StartPins0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b290 : Blocked tgt 6 s290 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s290 6 _ le
  decide +kernel
theorem b291 : Blocked tgt 6 s291 := by
  apply PetersenFastNode.node (nxt := #[s232,s292]) (hints := [6838,6838,903,903,1419,1675,391,1419,387,1671,395,1671,1419,2695,7210,2695,1419,4743,0,4743,6966,1,6966,7094,5546,1675,5674,1675,7734,1671,7734,1671,5546,2695,7210,2695,1418,4743,5514,4743,1675,6966,1675,5930,1671,12586,1671,6966,2695,4918,2695,4902,4743,2870,4743,2838,7218,1671,1667,1667,1675,2183,3211,1675,1675,4231,5259,1675,1671,2187,2695,1671,1671,4235,4743,1671,2695,3114,4743,2695]) (by decide +kernel)
  change ∀ b ∈ [s232,s292], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s232) b232 <|
    PetersenLocalChildren.push (x := s292) b292 <|
    PetersenLocalChildren.nil
theorem b300 : Blocked tgt 6 s300 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s300 6 _ le
  decide +kernel
theorem b301 : Blocked tgt 6 s301 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s301 6 _ le
  decide +kernel
theorem b302 : Blocked tgt 6 s302 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s302 6 _ le
  decide +kernel
theorem b303 : Blocked tgt 6 s303 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s303 6 _ le
  decide +kernel
theorem b304 : Blocked tgt 6 s304 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s304 6 _ le
  decide +kernel
theorem b305 : Blocked tgt 6 s305 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s305 6 _ le
  decide +kernel
theorem b306 : Blocked tgt 6 s306 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s306 6 _ le
  decide +kernel
theorem b307 : Blocked tgt 6 s307 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s307 6 _ le
  decide +kernel
theorem b308 : Blocked tgt 6 s308 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s308 6 _ le
  decide +kernel
theorem b309 : Blocked tgt 6 s309 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s309 6 _ le
  decide +kernel
theorem b310 : Blocked tgt 6 s310 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s310 6 _ le
  decide +kernel
theorem b311 : Blocked tgt 6 s311 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s311 6 _ le
  decide +kernel
theorem b312 : Blocked tgt 6 s312 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s312 6 _ le
  decide +kernel
theorem b313 : Blocked tgt 6 s313 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s313 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
