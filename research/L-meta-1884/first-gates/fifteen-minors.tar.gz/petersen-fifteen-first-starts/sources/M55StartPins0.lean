import M55StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 16) : Fin 32 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23] : Array (Fin 32))[x.val]?.getD 0
theorem small0 : NoAtMost i4 (PetersenPackedPin.project r0 tgt) 3 := by
  have a : PetersenPackedPin.project r0 tgt = table 39 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 39 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r3 (x : Fin 4) : Fin 32 := (#[0,2,4,6] : Array (Fin 32))[x.val]?.getD 0
theorem small3 : NoAtMost i2 (PetersenPackedPin.project r3 tgt) 0 := by
  have a : PetersenPackedPin.project r3 tgt = table 6 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 6 0 (by decide +kernel) (by decide +kernel)
theorem hot3 : forcedConst r3 tgt = false := by decide +kernel
def r7 (x : Fin 4) : Fin 32 := (#[1,9,17,25] : Array (Fin 32))[x.val]?.getD 0
theorem small7 : NoAtMost i2 (PetersenPackedPin.project r7 tgt) 0 := by
  have a : PetersenPackedPin.project r7 tgt = table 48 1 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 48 1 (by decide +kernel) (by decide +kernel)
theorem hot7 : forcedConst r7 tgt = false := by decide +kernel
end PetersenSmallStarts.M55
