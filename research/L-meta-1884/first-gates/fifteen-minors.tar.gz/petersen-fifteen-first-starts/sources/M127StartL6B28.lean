import M127StartData
import M127StartPins0
import M127StartL5B1
import M127StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b945 : Blocked tgt 6 s945 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s945 6 _ le
  decide +kernel
theorem b946 : Blocked tgt 6 s946 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s946 6 _ le
  decide +kernel
theorem b947 : Blocked tgt 6 s947 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s947 6 _ le
  decide +kernel
theorem b948 : Blocked tgt 6 s948 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s948 6 _ le
  decide +kernel
theorem b949 : Blocked tgt 6 s949 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s949 6 _ le
  decide +kernel
theorem b950 : Blocked tgt 6 s950 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(true,(0,false),(5,false))] s950 6 _ le
  decide +kernel
theorem b951 : Blocked tgt 6 s951 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s951 6 _ le
  decide +kernel
theorem b952 : Blocked tgt 6 s952 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s952 6 _ le
  decide +kernel
theorem b953 : Blocked tgt 6 s953 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s953 6 _ le
  decide +kernel
theorem b970 : Blocked tgt 6 s970 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,15156,901,6964,901,13610,1673,5672,1673,14642,1669,12586,1669,2693,2693,12594,7466,9482,4741,9514,4741,773,773,5546,901,5546,1673,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,1417,389,1673,1417,901,393,1669,901,901,7466,2949,901,901,11060,4741,901,6962,1669,1665,1665,1673,4914,7466,1673,1673,4229,5257,1673,1669,7466,7458,1669,1669,4233,4741,1669,4741,3370,4741,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b971 : Blocked tgt 6 s971 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s971 6 _ le
  decide +kernel
theorem b973 : Blocked tgt 6 s973 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s973 6 _ le
  decide +kernel
theorem b974 : Blocked tgt 6 s974 := by
  apply PetersenFastNode.node (nxt := #[s930,s975]) (hints := [5548,5548,2695,9675,13674,9675,2695,1671,7476,1671,3787,1739,2695,1739,2695,13515,0,13515,13612,2695,2183,2183,13674,9675,13674,9675,6580,1671,7476,1671,7468,1739,7468,1739,2452,13515,6548,13515,13612,6310,13612,6580,903,8651,1671,903,1739,903,1739,1995,9675,9578,13515,9675,1419,1483,9611,1419,1,1671,1671,1731,1671,12491,4743,1671,4916,1671,1671,5940,1739,4743,5835,1739,7468,1739,1675,1675,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s930,s975], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s930) b930 <|
    PetersenLocalChildren.push (x := s975) b975 <|
    PetersenLocalChildren.nil
theorem b976 : Blocked tgt 6 s976 := by
  apply PetersenFastNode.node (nxt := #[s932,s975]) (hints := [4516,4516,10951,9159,13158,9159,10435,10947,10439,10435,10951,9927,7460,9927,10951,12999,0,10951,2695,10887,2759,2695,13158,9159,13158,9159,4900,14566,4900,6564,6564,9927,7460,9927,2436,12999,6532,12999,6564,6886,12580,6564,8643,8647,9155,8643,9159,7204,9927,9159,9159,9062,12999,9159,903,967,9095,903,4900,9927,9923,9923,12483,12487,12483,12995,4900,1,12580,4900,9927,3364,12999,9927,1671,1735,9863,1671,4743,4807,12935,4743]) (by decide +kernel)
  change ∀ b ∈ [s932,s975], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s932) b932 <|
    PetersenLocalChildren.push (x := s975) b975 <|
    PetersenLocalChildren.nil
theorem b979 : Blocked tgt 6 s979 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s979 6 _ le
  decide +kernel
theorem b980 : Blocked tgt 6 s980 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s980 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
