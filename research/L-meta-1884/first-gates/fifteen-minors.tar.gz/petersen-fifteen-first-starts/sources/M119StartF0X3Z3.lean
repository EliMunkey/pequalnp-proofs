import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_3 : NoAtMost (0xaa00aa00aa00aa00 :: inputs 6) tgt 5 := by
  change NoAtMost [0xaa00aa00aa00aa00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s15,s0,s16] [195,195,196,196,197,197,580,1092,391,391,456,456,197,197,840,1352,587,907,196,196,717,909,1092,1092,847,911,456,456,717,2701,1352,1352,1107,1107,196,196,1237,1237,580,1429,1367,1367,456,456,1237,1237,840,3221,1627,1947,196,196,1757,1949,1949,1949,1887,1951,456,456,1757,3741,3741,3741,2211,2211,2276,2276,197,197,2660,3172,2471,2471,2536,2536,197,197,2920,3432,2667,2731,2276,2276,717,909,3172,3172,2927,2991,2536,2536,717,197,3432,3432,3187,3187,2276,2276,1237,1237,2660,1429,3447,3447,2536,2536,1237,1237,2920,0,3707,3771,2276,2276,1757,1949,1949,1949,3967,4031,2536,2536,1757,1237,1,2] (by decide +kernel)
  change ∀ b ∈ [s15,s0,s16], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_3
end PetersenSmallStarts.M119
