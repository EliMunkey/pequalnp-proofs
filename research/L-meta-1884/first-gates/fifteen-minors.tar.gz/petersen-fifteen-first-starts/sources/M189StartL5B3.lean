import M189StartData
import M189StartL4B0
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b241 : Blocked tgt 5 s241 := by
  apply PetersenFastNode.node (nxt := #[s242]) (hints := [1365,1235,1235,1365,1235,388,1427,1235,1365,1235,1235,1365,3365,1220,1219,1219,1235,2180,3219,1235,580,452,1433,452,2534,2534,3430,1220,3430,1220,3349,2244,3349,2244,0,452,452,2658,452,3174,1220,452,452,809,2244,452,2662,1220,3430,1220,582,2244,2630,2244,1220,1382,2244,1220]) (by decide +kernel)
  change ∀ b ∈ [s242], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.nil
theorem b243 : Blocked tgt 5 s243 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s243 5 _ le
  decide +kernel
theorem b244 : Blocked tgt 5 s244 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s244 5 _ le
  decide +kernel
theorem b245 : Blocked tgt 5 s245 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s245 5 _ le
  decide +kernel
theorem b254 : Blocked tgt 5 s254 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s254 5 _ le
  decide +kernel
theorem b255 : Blocked tgt 5 s255 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s255 5 _ le
  decide +kernel
theorem b256 : Blocked tgt 5 s256 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s256 5 _ le
  decide +kernel
theorem b257 : Blocked tgt 5 s257 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s257 5 _ le
  decide +kernel
theorem b258 : Blocked tgt 5 s258 := by
  apply PetersenFastNode.node (nxt := #[s259]) (hints := [1817,1819,1817,1945,1429,2217,1813,1429,2469,405,3365,2469,1429,485,2438,1429,1365,2469,1365,1429,1427,1435,1939,1427,907,923,1931,907,1947,2857,2180,1947,731,388,731,987,1220,789,708,708,2180,2853,2180,2692,1235,731,723,723,1220,1381,2180,1220,0,731,715,715,731,2779]) (by decide +kernel)
  change ∀ b ∈ [s259], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s259) b259 <|
    PetersenLocalChildren.nil
theorem b260 : Blocked tgt 5 s260 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s260 5 _ le
  decide +kernel
theorem b261 : Blocked tgt 5 s261 := by
  apply PetersenFastNode.node (nxt := #[s262]) (hints := [1365,595,723,1365,723,388,979,723,1365,723,723,853,3365,708,707,707,723,2180,2771,723,1811,452,1433,452,2534,2534,3430,580,3430,708,3349,2244,3349,2244,0,452,452,1809,452,3174,708,452,452,809,2244,452,3430,708,2918,708,1813,2244,3349,2244,708,1382,2244,708]) (by decide +kernel)
  change ∀ b ∈ [s262], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s262) b262 <|
    PetersenLocalChildren.nil
theorem b263 : Blocked tgt 5 s263 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s263 5 _ le
  decide +kernel
theorem b264 : Blocked tgt 5 s264 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s264 5 _ le
  decide +kernel
theorem b265 : Blocked tgt 5 s265 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s265 5 _ le
  decide +kernel
theorem b274 : Blocked tgt 5 s274 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1234,1234,1364,1234,387,1426,1234,1364,1234,1234,1364,3364,1219,1218,1218,1234,707,1746,1234,1810,451,1432,451,869,997,3429,1219,3429,1219,579,579,3348,707,609,451,451,865,451,3173,1219,451,451,808,707,451,869,1219,1893,1219,1812,707,837,707,707,1381,707,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b275 : Blocked tgt 5 s275 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s275 5 _ le
  decide +kernel
end PetersenSmallStarts.M189
