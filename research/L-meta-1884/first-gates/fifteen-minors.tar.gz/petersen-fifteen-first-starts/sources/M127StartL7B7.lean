import M127StartData
import M127StartPins0
import M127StartL6B11
import M127StartPins1
import M127StartL6B12
import M127StartL6B13
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b316 : Blocked tgt 7 s316 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s316 7 _ le
  decide +kernel
theorem b317 : Blocked tgt 7 s317 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s317 7 _ le
  decide +kernel
theorem b318 : Blocked tgt 7 s318 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s318 7 _ le
  decide +kernel
theorem b319 : Blocked tgt 7 s319 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s319 7 _ le
  decide +kernel
theorem b320 : Blocked tgt 7 s320 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s320 7 _ le
  decide +kernel
theorem b321 : Blocked tgt 7 s321 := by
  apply PetersenFastNode.node (nxt := #[s322,s323,s324,s325,s326,s327,s328,s329,s330,s331,s332,s333]) (hints := [15104,15104,15232,9041,4534,8661,15232,4534,15232,15104,15104,8661,4534,4534,5942,9813,15104,9941,5046,15104,5942,4534,4534,9941,7486,15104,7486,4534,4534,9937,6590,4534,7486,6590,15104,9937,4534,4534,7478,13056,15104,10961,6582,15104,7478,4534,4534,10961,406,406,0,438,4534,13009,4502,4534,1,406,406,13009,4534,4534,13622,6912,15104,2,12726,15104,13622,4534,4534,3,8661,8661,9941,5686,15232,5942,9173,15232,9941,8661,8661,5942,9937,15232,9937,8661,8661,7486,9169,8661,9937,9169,15232,7486,10961,8661,10961,13184,15232,7478,10961,15232,10961,8661,8661,7478,13009,8661,13009,11136,15232,4,13009,15232,13009,8661,8661,5,405,405,6,469,8661,13622,8597,8661,7,405,405,13622,6974,6974,7486,9937,9941,9937,9933,9941,7486,9933,6974,9937,9941,9941,11477,10449,6974,10961,11477,6974,11477,9941,9941,10961,9941,9941,13525,12497,5942,13009,13525,5942,13525,9941,9941,13009,1685,1685,13622,1749,9941,8,9877,9941,13622,1685,1685,9,9937,9937,10961,10453,7486,11477,10961,7486,10961,9937,9937,11477,9937,9937,13009,12501,7486,13525,13009,7486,13009,9937,9937,13525,1681,1681,14654,1745,9937,13622,9873,9937,14654,1681,1681,13622,10961,10961,13009,3382,7478,10,13009,7478,13009,10961,10961,11,2705,2705,13622,2769,10961,14654,10897,10961,13622,2705,2705,14654,4753,4753,9494,4817,13009,13622,12945,13009,9494,4753,4753,13622]) (by decide +kernel)
  change ∀ b ∈ [s322,s323,s324,s325,s326,s327,s328,s329,s330,s331,s332,s333], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s322) b322 <|
    PetersenLocalChildren.push (x := s323) b323 <|
    PetersenLocalChildren.push (x := s324) b324 <|
    PetersenLocalChildren.push (x := s325) b325 <|
    PetersenLocalChildren.push (x := s326) b326 <|
    PetersenLocalChildren.push (x := s327) b327 <|
    PetersenLocalChildren.push (x := s328) b328 <|
    PetersenLocalChildren.push (x := s329) b329 <|
    PetersenLocalChildren.push (x := s330) b330 <|
    PetersenLocalChildren.push (x := s331) b331 <|
    PetersenLocalChildren.push (x := s332) b332 <|
    PetersenLocalChildren.push (x := s333) b333 <|
    PetersenLocalChildren.nil
theorem b334 : Blocked tgt 7 s334 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s334 7 _ le
  decide +kernel
theorem b335 : Blocked tgt 7 s335 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s335 7 _ le
  decide +kernel
theorem b336 : Blocked tgt 7 s336 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s336 7 _ le
  decide +kernel
theorem b337 : Blocked tgt 7 s337 := by
  apply PetersenFastNode.node (nxt := #[s338,s339,s340,s341,s342,s343,s344,s345,s346,s347,s348,s349]) (hints := [6590,7486,6590,4534,9937,13556,6590,9937,6590,7486,7486,13556,9169,9937,9169,8661,7486,13684,9169,7486,9169,9937,9937,13684,6974,7486,6974,9937,9937,9941,9933,9937,6974,9933,7486,9941,9937,9937,10961,10453,7486,11477,10961,7486,10961,9937,9937,11477,9937,9937,13009,12501,7486,13525,13009,7486,13009,9937,9937,13525,1681,1681,14654,1745,9937,13622,9873,9937,14654,1681,1681,13622,13556,13556,13684,5302,6590,9169,13684,6590,13684,13556,13556,9169,5942,13556,5942,9813,15104,9941,5942,15104,5942,13556,13556,9941,7478,13556,7478,11349,6590,11477,7478,6590,7478,13556,13556,11477,2462,2462,0,13525,13556,13525,13524,13556,1,13524,2462,13525,13622,5300,13622,5364,13556,2,13622,13556,13622,5300,5300,3,9941,13684,9941,5686,9169,5942,9941,9169,9941,13684,13684,5942,11477,13684,11477,7222,15232,7478,11477,15232,11477,13684,13684,7478,13525,9556,13525,9588,13684,4,13525,13684,13525,9556,9556,5,913,913,6,13622,13684,13622,13620,13684,7,13620,913,13622,9941,9941,11477,10449,6974,10961,11477,6974,11477,9941,9941,10961,9941,9941,13525,1846,5942,13009,13525,5942,13525,9941,9941,13009,1685,1685,13622,1749,9941,8,9877,9941,13622,1685,1685,9,11477,11477,13525,3382,7478,10,13525,7478,13525,11477,11477,11,3221,3221,13622,3285,11477,14654,11413,11477,13622,3221,3221,14654,5269,5269,9494,5333,13525,13622,13461,13525,9494,5269,5269,13622]) (by decide +kernel)
  change ∀ b ∈ [s338,s339,s340,s341,s342,s343,s344,s345,s346,s347,s348,s349], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s338) b338 <|
    PetersenLocalChildren.push (x := s339) b339 <|
    PetersenLocalChildren.push (x := s340) b340 <|
    PetersenLocalChildren.push (x := s341) b341 <|
    PetersenLocalChildren.push (x := s342) b342 <|
    PetersenLocalChildren.push (x := s343) b343 <|
    PetersenLocalChildren.push (x := s344) b344 <|
    PetersenLocalChildren.push (x := s345) b345 <|
    PetersenLocalChildren.push (x := s346) b346 <|
    PetersenLocalChildren.push (x := s347) b347 <|
    PetersenLocalChildren.push (x := s348) b348 <|
    PetersenLocalChildren.push (x := s349) b349 <|
    PetersenLocalChildren.nil
theorem b350 : Blocked tgt 7 s350 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s350 7 _ le
  decide +kernel
theorem b351 : Blocked tgt 7 s351 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s351 7 _ le
  decide +kernel
theorem b352 : Blocked tgt 7 s352 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s352 7 _ le
  decide +kernel
theorem b353 : Blocked tgt 7 s353 := by
  apply PetersenFastNode.node (nxt := #[s354,s355,s356,s357,s358,s359,s360,s361,s362,s363,s364,s365,s366,s367]) (hints := [15106,15106,15234,9043,4544,0,13314,4544,15234,13314,15106,1,5944,4544,5944,9815,15106,9943,5944,15106,5944,4544,4544,9943,4544,4544,7488,9811,13558,9939,5568,13558,7488,4544,4544,9939,7480,13042,7480,4544,4544,10963,5560,4544,7480,5560,13042,10963,416,416,2,448,4544,13011,4512,4544,3,416,416,13011,13624,4544,13624,6914,15106,4,13624,15106,13624,4544,4544,5,9943,13686,9943,5688,15234,5944,9943,15234,9943,13686,13686,5944,9939,15234,9939,7232,13686,7488,9939,13686,9939,15234,15234,7488,10963,13170,10963,13186,15234,7480,9171,15234,10963,9171,13170,7480,13011,11106,13011,11138,15234,6,13011,15234,13011,11106,11106,7,6978,6978,8,7042,15234,13624,15170,15234,9,6978,6978,13624,6976,6976,7488,9939,9943,9939,9935,9943,7488,9935,6976,9939,9943,9943,11479,10451,6976,10963,11479,6976,11479,9943,9943,10963,9943,9943,13527,12499,5944,13011,13527,5944,13527,9943,9943,13011,1687,1687,13624,1751,9943,10,9879,9943,13624,1687,1687,11,9939,9939,10963,10455,7488,11479,10963,7488,10963,9939,9939,11479,9939,9939,13011,12503,7488,13527,13011,7488,13011,9939,9939,13527,1683,1683,14656,1747,9939,13624,9875,9939,14656,1683,1683,13624,10963,10963,13011,3384,7480,12,13011,7480,13011,10963,10963,13,2707,2707,13624,2771,10963,14656,10899,10963,13624,2707,2707,14656,4755,4755,9496,4819,13011,13624,12947,13011,9496,4755,4755,13624]) (by decide +kernel)
  change ∀ b ∈ [s354,s355,s356,s357,s358,s359,s360,s361,s362,s363,s364,s365,s366,s367], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s354) b354 <|
    PetersenLocalChildren.push (x := s355) b355 <|
    PetersenLocalChildren.push (x := s356) b356 <|
    PetersenLocalChildren.push (x := s357) b357 <|
    PetersenLocalChildren.push (x := s358) b358 <|
    PetersenLocalChildren.push (x := s359) b359 <|
    PetersenLocalChildren.push (x := s360) b360 <|
    PetersenLocalChildren.push (x := s361) b361 <|
    PetersenLocalChildren.push (x := s362) b362 <|
    PetersenLocalChildren.push (x := s363) b363 <|
    PetersenLocalChildren.push (x := s364) b364 <|
    PetersenLocalChildren.push (x := s365) b365 <|
    PetersenLocalChildren.push (x := s366) b366 <|
    PetersenLocalChildren.push (x := s367) b367 <|
    PetersenLocalChildren.nil
theorem b368 : Blocked tgt 7 s368 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s368 7 _ le
  decide +kernel
theorem b369 : Blocked tgt 7 s369 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s369 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
