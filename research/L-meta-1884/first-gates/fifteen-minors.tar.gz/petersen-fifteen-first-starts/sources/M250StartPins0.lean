import M250StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 4) : Fin 64 := (#[0,8,32,40] : Array (Fin 64))[x.val]?.getD 0
theorem small0 : NoAtMost i2 (PetersenPackedPin.project r0 tgt) 0 := by
  have a : PetersenPackedPin.project r0 tgt = table 160 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 160 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
end PetersenSmallStarts.M250
