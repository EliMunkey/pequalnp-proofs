import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_2 : NoAtMost (0x55005500 :: inputs 5) tgt 4 := by
  change NoAtMost [0x55005500,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s10] [98,394,99,394,100,460,419,460,198,198,231,231,100,100,423,423,362,394,363,394,364,460,427,460,198,198,231,231,364,100,679,679,562,922,99,922,628,988,419,988,694,694,231,231,628,628,423,423,826,922,363,922,892,988,427,988,694,694,231,231,892,628,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s10], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_2
end PetersenSmallStarts.M47
