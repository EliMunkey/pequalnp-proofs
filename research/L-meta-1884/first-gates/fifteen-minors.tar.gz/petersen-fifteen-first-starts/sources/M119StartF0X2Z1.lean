import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) tgt 5 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s4] [194,195,195,195,196,579,579,579,390,195,455,195,196,579,839,579,586,195,195,195,716,1091,1091,1091,846,195,455,195,716,1091,1351,1091,1106,195,195,195,1236,579,579,579,1366,195,455,195,1236,579,839,579,1626,195,195,195,1756,1948,1948,1948,1886,195,455,195,1756,3740,3740,3740,2210,2275,2275,2275,196,2659,2659,2659,2470,2275,2535,2275,196,2659,2919,2659,2666,2275,2275,2275,716,3171,3171,3171,2926,2275,2535,2275,716,3171,3431,3171,3186,2275,2275,2275,1236,2659,2659,2659,3446,2275,2535,2275,1236,2659,2919,2659,3706,2275,2275,2275,1756,1948,1948,1948,3966,2275,2535,2275,1756,3966,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s4], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M119
