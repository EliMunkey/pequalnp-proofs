import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b195 : Blocked tgt 6 s195 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s195 6 _ le
  decide +kernel
theorem b196 : Blocked tgt 6 s196 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s196 6 _ le
  decide +kernel
theorem b199 : Blocked tgt 6 s199 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s199 6 _ le
  decide +kernel
theorem b200 : Blocked tgt 6 s200 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s200 6 _ le
  decide +kernel
theorem b201 : Blocked tgt 6 s201 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s201 6 _ le
  decide +kernel
theorem b202 : Blocked tgt 6 s202 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s202 6 _ le
  decide +kernel
theorem b218 : Blocked tgt 6 s218 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s218 6 _ le
  decide +kernel
theorem b219 : Blocked tgt 6 s219 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s219 6 _ le
  decide +kernel
theorem b220 : Blocked tgt 6 s220 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s220 6 _ le
  decide +kernel
theorem b221 : Blocked tgt 6 s221 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s221 6 _ le
  decide +kernel
theorem b222 : Blocked tgt 6 s222 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s222 6 _ le
  decide +kernel
theorem b223 : Blocked tgt 6 s223 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s223 6 _ le
  decide +kernel
theorem b224 : Blocked tgt 6 s224 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s224 6 _ le
  decide +kernel
theorem b225 : Blocked tgt 6 s225 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s225 6 _ le
  decide +kernel
theorem b226 : Blocked tgt 6 s226 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s226 6 _ le
  decide +kernel
theorem b227 : Blocked tgt 6 s227 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s227 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
