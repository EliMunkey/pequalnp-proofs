import M111StartData
import M111StartL5B1
import M111StartL5B0
import M111StartL5B2
import M111StartPins0
import M111StartL5B3
import M111StartL5B4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b60 : Blocked tgt 6 s60 := by
  apply PetersenFastNode.node (nxt := #[s61,s62,s17,s63,s64,s66,s67,s68,s69,s40,s70,s72,s73,s74,s75,s76]) (hints := [1770,3754,1770,1412,0,1,469,2,469,1476,3754,3524,469,3754,469,3492,3,3524,857,3754,857,1864,4,3912,857,5,857,3754,3754,3912,853,3234,853,3242,3754,3908,853,3754,853,3234,3234,3908,1365,2714,1365,2730,3754,6,1365,3754,1365,2714,2714,7,3524,1380,3524,405,1770,469,3524,1770,3524,1380,1380,469,3912,1770,3912,793,1380,857,3912,1380,3912,1770,1770,857,3908,1250,3908,1258,1770,853,3908,1770,3908,1250,1250,853,730,730,8,746,1770,1365,1754,1770,9,730,730,1365,3784,3784,3912,3268,3524,1962,3912,3524,3912,3784,3784,1962,3524,3524,3908,3272,3784,10,3908,3784,3908,3524,3524,11,2484,2484,1365,2500,3524,12,3508,3524,1365,2484,2484,13,1442,1442,14,3908,3912,3908,3904,3912,15,3904,1442,3908,2872,2872,1625,2888,3912,1365,3896,3912,1625,2872,2872,1365,2868,2868,1365,2884,3908,1625,3892,3908,1365,2868,2868,1625]) (by decide +kernel)
  change ∀ b ∈ [s61,s62,s17,s63,s64,s66,s67,s68,s69,s40,s70,s72,s73,s74,s75,s76], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s62) b62 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s63) b63 <|
    PetersenLocalChildren.push (x := s64) b64 <|
    PetersenLocalChildren.push (x := s66) b66 <|
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s68) b68 <|
    PetersenLocalChildren.push (x := s69) b69 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.push (x := s70) b70 <|
    PetersenLocalChildren.push (x := s72) b72 <|
    PetersenLocalChildren.push (x := s73) b73 <|
    PetersenLocalChildren.push (x := s74) b74 <|
    PetersenLocalChildren.push (x := s75) b75 <|
    PetersenLocalChildren.push (x := s76) b76 <|
    PetersenLocalChildren.nil
theorem b77 : Blocked tgt 6 s77 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s77 6 _ le
  decide +kernel
theorem b78 : Blocked tgt 6 s78 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s78 6 _ le
  decide +kernel
theorem b79 : Blocked tgt 6 s79 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s79 6 _ le
  decide +kernel
theorem b80 : Blocked tgt 6 s80 := by
  apply PetersenFastNode.node (nxt := #[s81,s82,s83,s84,s85,s86,s87,s43,s91,s72,s92,s94,s95,s96,s98,s99]) (hints := [1250,3908,1250,2869,2933,3720,1250,2933,1250,3908,3908,3720,2549,2933,2549,2297,0,1,1442,2,1442,2933,2933,2937,2929,2933,1442,2929,3,2937,2933,2933,3445,3193,3908,3705,3445,3908,3445,2933,2933,3705,853,853,3234,885,2933,4,2901,2933,3234,853,853,5,3720,3720,3524,2485,1250,2549,3524,1250,3524,3720,3720,2549,3720,3720,3912,2873,3460,2937,3912,3460,3912,3720,3720,2937,210,210,6,3705,3720,3705,3704,3720,7,3704,210,3705,1640,1640,3234,1672,3720,8,3688,3720,3234,1640,1640,9,2937,2289,2937,2293,2549,1442,2937,2549,2937,2289,2289,1442,3705,2549,3705,2500,3524,10,3705,3524,3705,2549,2549,11,469,469,12,501,2549,3234,2517,2549,13,469,469,3234,2937,2937,3705,2888,3912,3445,3705,3912,3705,2937,2937,3445,857,857,3234,889,2937,14,2905,2937,3234,857,857,15,1625,1625,2194,1657,3705,3234,3673,3705,2194,1625,1625,3234]) (by decide +kernel)
  change ∀ b ∈ [s81,s82,s83,s84,s85,s86,s87,s43,s91,s72,s92,s94,s95,s96,s98,s99], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s82) b82 <|
    PetersenLocalChildren.push (x := s83) b83 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s85) b85 <|
    PetersenLocalChildren.push (x := s86) b86 <|
    PetersenLocalChildren.push (x := s87) b87 <|
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s91) b91 <|
    PetersenLocalChildren.push (x := s72) b72 <|
    PetersenLocalChildren.push (x := s92) b92 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.push (x := s95) b95 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.push (x := s98) b98 <|
    PetersenLocalChildren.push (x := s99) b99 <|
    PetersenLocalChildren.nil
theorem b100 : Blocked tgt 6 s100 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s100 6 _ le
  decide +kernel
theorem b101 : Blocked tgt 6 s101 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s101 6 _ le
  decide +kernel
theorem b102 : Blocked tgt 6 s102 := by
  apply PetersenFastNode.node (nxt := #[s103]) (hints := [3445,2470,3509,3445,1755,2858,1947,1755,1235,1243,1747,1235,715,731,1739,715,1755,3445,3739,1755,1365,1755,1755,1365,2794,2278,2922,2794,2534,2282,2918,2534,2534,2485,3430,2534,486,2534,3739,2534,454,1427,2918,2914,2914,2922,3174,3690,2922,842,2922,2922,842,842,2922,2922,842,2918,3178,3430,2918,838,2918,2918,838,838,2918,2918,838,1350,3430,3430,1350,1350,3430,3430,1350,3739,0]) (by decide +kernel)
  change ∀ b ∈ [s103], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s103) b103 <|
    PetersenLocalChildren.nil
theorem b104 : Blocked tgt 6 s104 := by
  apply PetersenFastNode.node (nxt := #[s105,s18,s106,s107,s108,s109,s112,s114,s115,s117,s118,s48,s121,s96,s124,s127,s129,s132]) (hints := [3756,3756,1382,1772,0,1772,1382,1,1382,1772,3756,1772,471,3756,2519,471,2,3,859,3756,859,1964,4,1964,859,5,859,1964,3756,1964,855,3236,855,3748,3756,6,855,3756,855,3236,3236,7,1367,2716,1367,3740,3756,8,1367,3756,1367,2716,2716,9,1382,1382,3494,1772,1772,2519,1772,1772,3494,1382,1382,2519,1772,1772,1964,795,1382,859,1964,1382,1964,1772,1772,859,1252,1252,1830,1260,1772,855,1764,1772,1830,1252,1252,855,732,732,10,748,1772,1367,1756,1772,11,732,732,1367,859,2779,859,1964,2519,1964,859,2519,859,1964,2779,1964,855,2519,855,2267,2779,12,855,2779,855,2519,2519,13,1367,2519,1367,2470,3494,14,1367,3494,1367,2519,2519,15,1444,1444,16,1452,1964,855,1956,1964,17,1444,1444,855,924,924,1627,940,1964,1367,1948,1964,1627,924,924,1367,855,855,1367,1115,1830,1627,1367,1830,1367,855,855,1627]) (by decide +kernel)
  change ∀ b ∈ [s105,s18,s106,s107,s108,s109,s112,s114,s115,s117,s118,s48,s121,s96,s124,s127,s129,s132], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s105) b105 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s106) b106 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s108) b108 <|
    PetersenLocalChildren.push (x := s109) b109 <|
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.push (x := s114) b114 <|
    PetersenLocalChildren.push (x := s115) b115 <|
    PetersenLocalChildren.push (x := s117) b117 <|
    PetersenLocalChildren.push (x := s118) b118 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.push (x := s121) b121 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.push (x := s124) b124 <|
    PetersenLocalChildren.push (x := s127) b127 <|
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.nil
theorem b134 : Blocked tgt 6 s134 := by
  apply PetersenFastNode.node (nxt := #[s135,s136,s137,s138,s107]) (hints := [3449,1759,3449,1759,2538,458,2926,1951,2926,1951,2922,0,2922,1,3434,2,3434,3,3743,3743,3449,1759,1759,3449,1759,2862,1951,1759,1239,1247,1751,1239,719,735,1743,719,1759,1401,3417,1759,2798,1951,2926,1951,2538,2286,2922,2538,2538,2489,3434,2538,4,2538,2506,1431,1439,1943,1431,911,927,1935,911,1951,878,2894,1951,2922,3182,3434,2922,842,874,2890,842,1354,1386,3402,1354]) (by decide +kernel)
  change ∀ b ∈ [s135,s136,s137,s138,s107], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s135) b135 <|
    PetersenLocalChildren.push (x := s136) b136 <|
    PetersenLocalChildren.push (x := s137) b137 <|
    PetersenLocalChildren.push (x := s138) b138 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.nil
theorem b139 : Blocked tgt 6 s139 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s139 6 _ le
  decide +kernel
theorem b140 : Blocked tgt 6 s140 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s140 6 _ le
  decide +kernel
theorem b141 : Blocked tgt 6 s141 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s141 6 _ le
  decide +kernel
theorem b142 : Blocked tgt 6 s142 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s142 6 _ le
  decide +kernel
theorem b143 : Blocked tgt 6 s143 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s143 6 _ le
  decide +kernel
theorem b144 : Blocked tgt 6 s144 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s144 6 _ le
  decide +kernel
end PetersenSmallStarts.M111
