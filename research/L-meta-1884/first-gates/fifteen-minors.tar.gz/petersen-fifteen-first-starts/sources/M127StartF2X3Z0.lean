import M127StartData
import M127StartL8B0
import M127StartL8B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_0 : NoAtMost (0xfff0fff0fff0fff0fff0fff0fff0fff0 :: inputs 7) tgt 8 := by
  change NoAtMost [0xfff0fff0fff0fff0fff0fff0fff0fff0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 8
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1217] [386,774,387,903,388,780,1667,1671,774,774,903,903,388,1420,1671,1671,1418,1418,1419,1419,1420,1420,1675,1675,774,774,903,903,1420,1420,2695,2695,2194,2710,387,903,2452,780,1667,1671,2710,2710,903,903,2452,1420,1671,1671,1418,1418,1419,1419,1420,1420,1675,1675,2710,2710,903,903,1420,1420,4743,4743,4258,4774,387,903,4516,4908,1667,1671,4774,4774,903,903,4516,5548,1671,1671,5290,5290,1419,1419,5548,5548,1675,1675,4774,4774,903,903,5548,5548,2695,2695,6322,6838,387,903,6580,4908,1667,1671,6838,6838,903,903,6580,5548,1671,1671,5290,5290,1419,1419,5548,5548,1675,1675,6838,6838,903,903,5548,5548,13612,13612,8514,9030,8643,9159,388,780,9923,9927,9030,9030,9159,9159,388,1420,9927,9927,9546,9546,9675,9675,1420,1420,9931,9931,9030,9030,9159,9159,1420,1420,10951,10951,10450,10966,8643,9159,2452,780,9923,9927,10966,10966,9159,9159,2452,1420,9927,9927,9546,9546,9675,9675,1420,1420,9931,9931,10966,10966,9159,9159,1420,1420,12999,12999,12514,13030,8643,9159,4516,4908,9923,9927,13030,13030,9159,9159,4516,5548,9927,9927,13546,13546,9675,9675,5548,5548,9931,9931,13030,13030,9159,9159,5548,5548,10951,10951,14578,15094,8643,9159,6580,4908,9923,9927,15094,15094,9159,9159,6580,5548,9927,9927,13546,13546,9675,9675,5548,5548,9931,9931,15094,15094,9159,9159,5548,5548,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1217], Blocked tgt 8 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1217) b1217 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_0
end PetersenSmallStarts.M127
