import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b336 : Blocked tgt 5 s336 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s336 5 _ le
  decide +kernel
theorem b337 : Blocked tgt 5 s337 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s337 5 _ le
  decide +kernel
theorem b342 : Blocked tgt 5 s342 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s342 5 _ le
  decide +kernel
theorem b343 : Blocked tgt 5 s343 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s343 5 _ le
  decide +kernel
theorem b344 : Blocked tgt 5 s344 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s344 5 _ le
  decide +kernel
theorem b345 : Blocked tgt 5 s345 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s345 5 _ le
  decide +kernel
theorem b346 : Blocked tgt 5 s346 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s346 5 _ le
  decide +kernel
theorem b347 : Blocked tgt 5 s347 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s347 5 _ le
  decide +kernel
theorem b348 : Blocked tgt 5 s348 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s348 5 _ le
  decide +kernel
theorem b349 : Blocked tgt 5 s349 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s349 5 _ le
  decide +kernel
theorem b350 : Blocked tgt 5 s350 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s350 5 _ le
  decide +kernel
theorem b351 : Blocked tgt 5 s351 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s351 5 _ le
  decide +kernel
theorem b352 : Blocked tgt 5 s352 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s352 5 _ le
  decide +kernel
theorem b353 : Blocked tgt 5 s353 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s353 5 _ le
  decide +kernel
theorem b354 : Blocked tgt 5 s354 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s354 5 _ le
  decide +kernel
theorem b355 : Blocked tgt 5 s355 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s355 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
