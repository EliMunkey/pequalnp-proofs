import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) tgt 7 := by
  change NoAtMost [0xf000f000f000f0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1071] [194,390,195,455,196,1350,835,1351,390,390,455,455,196,1350,839,1351,714,390,715,455,716,1350,843,1351,390,390,455,455,716,1350,1351,1351,1106,1366,195,455,1236,1366,835,2375,1366,1366,455,455,1236,1366,839,2375,714,1366,715,455,716,1366,843,2375,1366,1366,455,455,716,1366,2375,2375,2146,2406,195,455,2276,2406,835,1351,2406,2406,455,455,2276,2406,839,1351,2666,2406,715,455,2796,2406,843,1351,2406,2406,455,455,2796,2406,1351,1351,3186,3446,195,455,3316,3446,835,835,3446,3446,455,455,3316,3446,839,3764,2666,3446,715,455,2796,3446,843,843,3446,3446,455,455,2796,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1071], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1071) b1071 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_1
end PetersenSmallStarts.M63
