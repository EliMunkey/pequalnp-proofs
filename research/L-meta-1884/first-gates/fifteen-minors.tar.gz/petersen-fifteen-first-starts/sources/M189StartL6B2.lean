import M189StartData
import M189StartPins0
import M189StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b47 : Blocked tgt 6 s47 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s47 6 _ le
  decide +kernel
theorem b48 : Blocked tgt 6 s48 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,1754,2533,1754,1364,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2533,1428,2273,2277,2529,2273,2533,579,2917,2533,2533,1091,3429,2533,453,485,2501,453,1816,451,1816,451,1812,707,1812,707,3364,1219,3364,1219,3348,2243,3348,2243,451,2661,707,451,451,3173,1219,451,451,808,2243,451,707,788,1219,707,707,869,2243,707,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b49 : Blocked tgt 6 s49 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s49 6 _ le
  decide +kernel
theorem b50 : Blocked tgt 6 s50 := by
  apply PetersenFastNode.node (nxt := #[s51,s52]) (hints := [1110,1110,1430,2467,1756,2531,1430,1756,1430,1110,1110,2531,1756,1756,1948,389,1110,453,1948,1110,1948,1756,1756,453,1236,1236,1814,1244,1756,709,1748,1756,1814,1236,1236,709,716,716,3366,732,1756,1221,1740,1756,3366,716,716,1221,1756,1756,3740,2181,0,2245,3740,1,3740,1756,1756,2245,2275,2730,1818,2275,2531,453,2531,2531,1818,453,2730,453,2531,2531,2659,709,2730,709,2659,2730,2659,2531,2531,709,2531,2531,3171,1221,1430,1221,3171,1430,3171,2531,2531,1221,451,451,3350,483,2531,2245,2499,2531,3350,451,451,2245,453,453,709,2659,1948,2659,709,1948,709,453,453,2659,453,453,1221,3171,1948,3171,1221,1948,1221,453,453,3171,453,453,2245,810,2858,3350,2245,2858,2245,453,453,3350,709,709,1221,790,1814,3626,1221,1814,1221,709,709,3626,709,709,2245,611,2659,3740,2245,2659,2245,709,709,3740,1221,1221,2245,1123,3171,3740,2245,3171,2245,1221,1221,3740]) (by decide +kernel)
  change ∀ b ∈ [s51,s52], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.nil
theorem b53 : Blocked tgt 6 s53 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2469,1428,1364,1754,1108,1364,1754,1754,1364,1364,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2728,2533,2529,2529,2273,2533,2533,2728,2533,707,2917,2533,2533,1219,3429,2533,453,485,2501,453,451,451,707,2661,707,2913,1219,3173,1219,3425,2243,3348,2243,3348,707,2917,707,2917,1219,3429,1219,3429,2243,3348,2243,3348,707,788,1219,707,707,869,2243,707,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b54 : Blocked tgt 6 s54 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s54 6 _ le
  decide +kernel
theorem b55 : Blocked tgt 6 s55 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s55 6 _ le
  decide +kernel
theorem b56 : Blocked tgt 6 s56 := by
  apply PetersenFastNode.node (nxt := #[s57,s58]) (hints := [1430,1626,1430,1628,1756,2275,1430,1756,1430,1494,1626,2275,1756,1756,1948,389,0,453,1948,1,1948,1756,1756,453,1236,1236,1814,1244,1756,709,1748,1756,1814,1236,1236,709,716,716,3366,732,1756,1221,1740,1756,3366,716,716,1221,1756,1756,3740,2181,2666,2245,3740,2666,3740,1756,1756,2245,2275,2275,1818,453,1430,453,2531,1430,1818,2275,2275,453,2275,2275,2659,581,2730,709,2659,2730,2659,2275,2275,709,2275,2275,3171,1093,1430,1221,3171,1430,3171,2275,2275,1221,1430,1430,3350,2245,2275,2245,2243,2275,3350,2243,1430,2245,453,453,709,1436,1948,1814,709,1948,709,453,453,1814,453,453,1221,924,1948,3366,1221,1948,1221,453,453,3366,453,453,2245,810,2858,3350,2245,2858,2245,453,453,3350,709,709,1221,790,1814,3626,1221,1814,1221,709,709,3626,709,709,2245,611,2659,3740,2245,2659,2245,709,709,3740,1221,1221,2245,1123,3171,3740,2245,3171,2245,1221,1221,3740]) (by decide +kernel)
  change ∀ b ∈ [s57,s58], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s58) b58 <|
    PetersenLocalChildren.nil
theorem b59 : Blocked tgt 6 s59 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s59 6 _ le
  decide +kernel
theorem b60 : Blocked tgt 6 s60 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s60 6 _ le
  decide +kernel
theorem b61 : Blocked tgt 6 s61 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s61 6 _ le
  decide +kernel
theorem b62 : Blocked tgt 6 s62 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s62 6 _ le
  decide +kernel
theorem b63 : Blocked tgt 6 s63 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s63 6 _ le
  decide +kernel
theorem b64 : Blocked tgt 6 s64 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s64 6 _ le
  decide +kernel
theorem b65 : Blocked tgt 6 s65 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s65 6 _ le
  decide +kernel
theorem b66 : Blocked tgt 6 s66 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s66 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
