import M45StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 16) : Fin 16 := (#[0,2,1,3,8,10,9,11,4,6,5,7,12,14,13,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover0 : i4.all (fun q => i4.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
private def a1 (x : Fin 16) : Fin 16 := (#[0,1,4,5,2,3,6,7,8,9,12,13,10,11,14,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover1 : i4.all (fun q => i4.contains (PetersenPackedPin.project a1 q)) = true := by decide +kernel
private theorem same1 : PetersenPackedPin.project a1 tgt=tgt := by decide +kernel
private def a2 (x : Fin 16) : Fin 16 := (#[0,4,1,5,8,12,9,13,2,6,3,7,10,14,11,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover2 : i4.all (fun q => i4.contains (PetersenPackedPin.project a2 q)) = true := by decide +kernel
private theorem same2 : PetersenPackedPin.project a2 tgt=tgt := by decide +kernel
private def a3 (x : Fin 16) : Fin 16 := (#[0,8,2,10,4,12,6,14,1,9,3,11,5,13,7,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover3 : i4.all (fun q => i4.contains (PetersenPackedPin.project a3 q)) = true := by decide +kernel
private theorem same3 : PetersenPackedPin.project a3 tgt=tgt := by decide +kernel
private def a4 (x : Fin 16) : Fin 16 := (#[0,2,8,10,1,3,9,11,4,6,12,14,5,7,13,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover4 : i4.all (fun q => i4.contains (PetersenPackedPin.project a4 q)) = true := by decide +kernel
private theorem same4 : PetersenPackedPin.project a4 tgt=tgt := by decide +kernel
private def a5 (x : Fin 16) : Fin 16 := (#[0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover5 : i4.all (fun q => i4.contains (PetersenPackedPin.project a5 q)) = true := by decide +kernel
private theorem same5 : PetersenPackedPin.project a5 tgt=tgt := by decide +kernel
private def a6 (x : Fin 16) : Fin 16 := (#[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover6 : i4.all (fun q => i4.contains (PetersenPackedPin.project a6 q)) = true := by decide +kernel
private theorem same6 : PetersenPackedPin.project a6 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x4444 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x4444) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_0 : NoAtMost (0xfafa :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xfafa) (a:=0xeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_2_1 : NoAtMost (0xa0a :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xa0a) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_2 : NoAtMost (0x5050 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x5050) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_3 : NoAtMost (0xa0a0 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xa0a0) (a:=0x8888) (by decide +kernel) gate_0_1_3
theorem labeled_0_3_2 : NoAtMost (0x5500 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0x5500) (a:=0xaa) (by decide +kernel) gate_0_3_1
theorem labeled_1_2_0 : NoAtMost (0xfcfc :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfc) (a:=0xffaa) (by decide +kernel) gate_0_3_0
theorem labeled_1_2_1 : NoAtMost (0xc0c :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c) (a:=0xaa) (by decide +kernel) gate_0_3_1
theorem labeled_1_2_2 : NoAtMost (0x3030 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x3030) (a:=0xaa) (by decide +kernel) gate_0_3_1
theorem labeled_1_3_0 : NoAtMost (0xffcc :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xffcc) (a:=0xeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_3_1 : NoAtMost (0xcc :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xcc) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_1_3_2 : NoAtMost (0x3300 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0x3300) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_1_3_3 : NoAtMost (0xcc00 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xcc00) (a:=0x8888) (by decide +kernel) gate_0_1_3
theorem labeled_2_3_0 : NoAtMost (0xfff0 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xfff0) (a:=0xeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_3_1 : NoAtMost (0xf0 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xf0) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_2_3_2 : NoAtMost (0xf00 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xf00) (a:=0x2222) (by decide +kernel) gate_0_1_1
theorem labeled_2_3_3 : NoAtMost (0xf000 :: inputs 4) tgt 2 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xf000) (a:=0x8888) (by decide +kernel) gate_0_1_3
def forbidden : List (BitVec 16) := [0xeeee,0x2222,0x4444,0x8888,0xfafa,0xa0a,0x5050,0xa0a0,0xffaa,0xaa,0x5500,0xfcfc,0xc0c,0x3030,0xffcc,0xcc,0x3300,0xcc00,0xfff0,0xf0,0xf00,0xf000]
theorem all_forbidden (g : BitVec 16) (h : g∈forbidden) : NoAtMost (g::inputs 4) tgt 2 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 4) tgt 2 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x2222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x4444) labeled_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x8888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xfafa) labeled_0_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xa0a) labeled_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x5050) labeled_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xa0a0) labeled_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xaa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x5500) labeled_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xc0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x3030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xffcc) labeled_1_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xcc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0x3300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xcc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xfff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xf0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xf00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 2) (x:=0xf000) labeled_2_3_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M45
