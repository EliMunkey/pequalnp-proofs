import M51StartData
import M51StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_2 : NoAtMost (0x4444 :: inputs 4) tgt 2 := by
  change NoAtMost [0x4444,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s4] [50,50,51,51,52,82,83,83,86,86,51,51,120,86,147,147,154,154,51,51,188,154,83,83,222,222,51,51,256,222,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s4], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_2
end PetersenSmallStarts.M51
