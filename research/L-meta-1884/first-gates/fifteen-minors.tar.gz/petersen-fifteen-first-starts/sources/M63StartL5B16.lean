import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b562 : Blocked tgt 5 s562 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s562 5 _ le
  decide +kernel
theorem b563 : Blocked tgt 5 s563 := by
  apply PetersenFastNode.node (nxt := #[s128]) (hints := [390,390,0,454,715,715,2634,842,2118,842,1683,838,1683,838,1675,1350,1675,1350,3413,454,454,1429,714,198,842,714,454,202,838,454,454,1547,1350,454,2763,842,907,842,1683,838,1683,838,1675,1350,1675,1350,1683,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s128], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.nil
theorem b564 : Blocked tgt 5 s564 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s564 5 _ le
  decide +kernel
theorem b565 : Blocked tgt 5 s565 := by
  apply PetersenFastNode.node (nxt := #[s129]) (hints := [715,715,2374,714,0,2374,2634,842,2118,842,2374,838,2122,838,2374,1350,1675,1350,3413,714,2761,714,395,842,395,842,1683,838,1683,838,1675,1350,1675,1350,714,198,458,458,838,202,454,454,1350,1547,1350,714,1683,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s129], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.nil
theorem b566 : Blocked tgt 5 s566 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,837,2121,837,714,714,2633,713,1428,713,2633,841,776,841,2633,1609,1674,1609,1682,837,837,1682,453,201,453,837,1426,837,833,833,837,1097,1349,837,2632,713,2760,713,2762,841,776,841,1674,1609,1674,1609,713,197,841,713,713,1546,1609,713,841,1093,1609,841]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b567 : Blocked tgt 5 s567 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,713,404,2373,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,404,713,404,713,2762,841,402,841,1682,837,1682,837,1674,1349,1674,1349,713,197,841,713,837,201,837,193,1349,404,453,453,402,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b568 : Blocked tgt 5 s568 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,1349,1674,1349,1234,1234,2373,453,388,453,2633,841,2117,841,1682,837,1682,837,1674,1349,1349,1674,453,404,453,1349,841,1093,841,1609,837,1097,837,1349,3412,453,3280,453,3282,841,3408,841,1682,837,1682,837,713,197,841,713,453,201,837,453,1682,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b571 : Blocked tgt 5 s571 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3412,714,1364,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1106,453,714,453,714,841,970,714,1234,202,1682,1234,714,210,1674,714,713,197,841,713,453,201,837,453,453,1674,1349,453,1682,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b572 : Blocked tgt 5 s572 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s572 5 _ le
  decide +kernel
theorem b575 : Blocked tgt 5 s575 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3282,714,714,1234,1428,453,714,453,714,841,906,714,202,202,714,837,714,1349,1674,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,713,197,841,713,453,201,837,453,453,1674,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b576 : Blocked tgt 5 s576 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s576 5 _ le
  decide +kernel
theorem b578 : Blocked tgt 5 s578 := by
  apply PetersenFastNode.node (nxt := #[s132]) (hints := [715,715,2634,714,0,714,2634,842,907,842,2114,2626,2122,2114,2634,1610,1675,1610,2633,714,2761,714,907,842,907,842,1683,2251,1683,3283,1675,1610,1675,1610,714,779,842,714,194,202,706,194,714,1547,1610,714,1427,842,834,834,842,403,1610,842,1090,1098,1090,1602]) (by decide +kernel)
  change ∀ b ∈ [s132], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.nil
theorem b579 : Blocked tgt 5 s579 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2113,841,2633,841,714,714,2633,713,1424,713,1682,2633,2633,833,2633,1609,1674,1609,906,841,841,906,841,713,193,713,833,841,833,1426,841,1609,1089,841,2632,713,2760,713,1682,833,1682,833,1674,1609,1674,1609,201,201,713,449,713,1546,1609,713,833,1609,1089,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b581 : Blocked tgt 5 s581 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1234,714,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,389,389,1234,453,1234,841,1426,1234,1234,837,1746,1234,194,210,1218,194,713,197,841,713,453,201,837,453,453,1546,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b582 : Blocked tgt 5 s582 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s582 5 _ le
  decide +kernel
theorem b583 : Blocked tgt 5 s583 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,713,404,2373,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,404,713,404,713,906,841,906,841,1666,837,1666,837,1674,1349,1674,1349,713,778,841,713,837,713,837,965,1349,404,453,453,386,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
