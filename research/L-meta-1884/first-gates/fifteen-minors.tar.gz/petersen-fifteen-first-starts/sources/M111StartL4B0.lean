import M111StartData
import M111StartPins0
import M111StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3 : Blocked tgt 4 s3 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s3 4 _ le
  decide +kernel
theorem b4 : Blocked tgt 4 s4 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s4 4 _ le
  decide +kernel
theorem b5 : Blocked tgt 4 s5 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s5 4 _ le
  decide +kernel
theorem b19 : Blocked tgt 4 s19 := by
  apply PetersenFastNode.node (nxt := #[s20]) (hints := [715,1739,389,389,715,907,777,715,195,707,203,195,453,0,453,1349,907,1093,907,1609,773,1097,773,1349,713,907,777,907,453,201,773,453,387,395,899,387]) (by decide +kernel)
  change ∀ b ∈ [s20], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
theorem b22 : Blocked tgt 4 s22 := by
  apply PetersenFastNode.node (nxt := #[s20]) (hints := [2469,2469,715,907,2857,715,195,707,203,195,715,2699,0,715,2793,907,2857,907,2533,2281,2853,2533,453,2699,2501,2699,387,395,899,387,907,809,2699,907,2179,2187,2179,2691]) (by decide +kernel)
  change ∀ b ∈ [s20], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
theorem b42 : Blocked tgt 4 s42 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,194,3169,2273,2208,2273,3169,2913,386,2913,1089,3137,1121,1089,2208,2273,2208,2273,386,2913,386,2913,1218,1120,2178,1218,2273,386,2529,2273,193,225,2241,193,833,865,2881,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b45 : Blocked tgt 4 s45 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2437,453,388,453,1738,1349,714,714,906,841,906,1738,1218,1226,1730,1218,1349,453,453,388,713,197,841,713,453,201,837,453,1609,841,1093,841,1349,837,1097,837,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b46 : Blocked tgt 4 s46 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1349,453,388,453,714,714,906,841,906,841,1349,837,1097,837,388,453,453,388,713,197,841,713,453,201,837,453,906,841,906,841,1218,837,1730,837,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b47 : Blocked tgt 4 s47 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,1349,453,388,453,1609,841,1093,841,1349,837,1097,837,388,453,388,453,906,841,906,841,1218,837,1730,837,713,197,841,713,453,201,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b49 : Blocked tgt 4 s49 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1348,714,1349,453,388,453,1609,841,1093,841,1349,837,1097,837,389,389,714,453,714,841,906,714,194,202,706,194,713,197,841,713,453,201,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b51 : Blocked tgt 4 s51 := by
  apply PetersenFastNode.node (nxt := #[s52]) (hints := [3429,195,3170,3426,3174,3170,3430,2534,2469,2534,1350,3398,1382,1350,387,3173,387,1219,2469,2534,2469,2534,1349,1381,3397,1349,2274,2278,2274,2530,387,0,2179,387,454,486,2502,454]) (by decide +kernel)
  change ∀ b ∈ [s52], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.nil
theorem b53 : Blocked tgt 4 s53 := by
  apply PetersenFastNode.node (nxt := #[s52]) (hints := [195,195,1350,454,389,454,1350,838,773,838,1090,1346,1094,1090,389,454,389,454,1219,838,773,838,387,1093,387,1219,454,0,838,454,194,198,450,194,834,834]) (by decide +kernel)
  change ∀ b ∈ [s52], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.nil
theorem b65 : Blocked tgt 4 s65 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s65 4 _ le
  decide +kernel
theorem b71 : Blocked tgt 4 s71 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1136,193,3218,193,3216,833,1840,833,3218,1089,2194,1089,2178,3248,1106,3248,1104,3888,769,3888,1234,194,210,1218,194,3248,1426,3504,3248,2208,2224,3232,2208,2848,2864,3872,2848]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b88 : Blocked tgt 4 s88 := by
  apply PetersenFastNode.node (nxt := #[s89]) (hints := [195,2854,195,1603,2534,2282,2534,2918,387,2918,2914,2914,838,870,2886,838,2469,3690,3689,3689,2857,2858,2857,2921,195,0,2179,195,2922,2278,2922,3690,1610,1642,3658,1610,842,874,2890,842]) (by decide +kernel)
  change ∀ b ∈ [s89], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.nil
theorem b90 : Blocked tgt 4 s90 := by
  apply PetersenFastNode.node (nxt := #[s89]) (hints := [838,1098,1350,838,454,202,387,838,387,834,195,774,195,773,1610,0,454,1610,842,1094,842,1610,1609,1609,842,198,842,194,389,390,453,389,777,778,841,777]) (by decide +kernel)
  change ∀ b ∈ [s89], Blocked tgt 3 b
  exact 
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M111
