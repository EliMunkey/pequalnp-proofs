import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_3 : NoAtMost (0xa0a0a0a0a0a0a0a0 :: inputs 6) tgt 5 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s7] [194,455,195,455,196,839,579,839,390,455,455,455,196,839,839,839,586,455,195,455,716,1351,1091,1351,846,455,455,455,716,1351,1351,1351,1106,455,195,455,1236,839,579,839,1366,455,455,455,1236,839,839,839,1626,455,195,455,1756,1756,1948,1948,1886,455,455,455,1756,1756,3740,3740,2210,2535,2275,2535,196,2919,2659,2919,2470,2535,2535,2535,196,2919,2919,2919,2666,2535,2275,2535,716,3431,3171,3431,2926,2535,2535,2535,716,3431,3431,3431,3186,2535,2275,2535,1236,2919,2659,2919,3446,2535,2535,2535,1236,2919,2919,2919,3706,2535,2275,2535,1756,1756,1948,1948,3966,2535,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s7], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_3
end PetersenSmallStarts.M119
