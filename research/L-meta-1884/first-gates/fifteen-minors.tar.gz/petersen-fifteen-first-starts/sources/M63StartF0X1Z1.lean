import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222222222222222 :: inputs 6) tgt 7 := by
  change NoAtMost [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s89] [194,835,195,835,196,835,835,835,390,839,455,839,196,839,839,839,714,843,715,843,716,843,843,843,390,1351,455,1351,716,1351,1351,1351,1106,835,195,835,1236,835,835,835,1366,839,455,839,1236,839,839,839,714,843,715,843,716,843,843,843,1366,2375,455,2375,716,2375,2375,2375,2146,835,195,835,2276,835,835,835,2406,839,455,839,2276,839,839,839,2666,843,715,843,2796,843,843,843,2406,1351,455,1351,2796,1351,1351,1351,3186,835,195,835,3316,835,835,835,3446,839,455,839,3316,839,839,839,2666,843,715,843,2796,843,843,843,3446,3510,455,3510,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s89], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M63
