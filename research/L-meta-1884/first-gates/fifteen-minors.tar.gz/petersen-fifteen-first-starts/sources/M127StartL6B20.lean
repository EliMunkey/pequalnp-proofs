import M127StartData
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b621 : Blocked tgt 6 s621 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s621 6 _ le
  decide +kernel
theorem b622 : Blocked tgt 6 s622 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s622 6 _ le
  decide +kernel
theorem b626 : Blocked tgt 6 s626 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s626 6 _ le
  decide +kernel
theorem b627 : Blocked tgt 6 s627 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s627 6 _ le
  decide +kernel
theorem b628 : Blocked tgt 6 s628 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s628 6 _ le
  decide +kernel
theorem b629 : Blocked tgt 6 s629 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s629 6 _ le
  decide +kernel
theorem b630 : Blocked tgt 6 s630 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s630 6 _ le
  decide +kernel
theorem b631 : Blocked tgt 6 s631 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s631 6 _ le
  decide +kernel
theorem b632 : Blocked tgt 6 s632 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s632 6 _ le
  decide +kernel
theorem b633 : Blocked tgt 6 s633 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6324,5546,385,385,1673,5930,1673,5930,1665,7474,1665,7474,2177,7466,2177,7466,4225,13578,4225,9482,6324,5546,5546,6324,5546,1545,5930,5546,7474,5546,7474,7602,5546,4276,7466,5546,1418,1450,5514,1418,1673,5930,1673,5930,1665,7474,1665,7474,2177,7466,2177,7466,4225,11060,4225,8577,6962,4906,7474,6962,5930,4914,7466,5930,1802,1834,5898,1802,1665,7466,7458,7458,3346,3378,7442,3346,3338,3370,7434,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b634 : Blocked tgt 6 s634 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s634 6 _ le
  decide +kernel
theorem b635 : Blocked tgt 6 s635 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s635 6 _ le
  decide +kernel
theorem b636 : Blocked tgt 6 s636 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s636 6 _ le
  decide +kernel
theorem b637 : Blocked tgt 6 s637 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true)),(true,(0,false),(3,false))] s637 6 _ le
  decide +kernel
theorem b654 : Blocked tgt 6 s654 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s654 6 _ le
  decide +kernel
theorem b655 : Blocked tgt 6 s655 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s655 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
