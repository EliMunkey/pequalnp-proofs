import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_2 : NoAtMost (0x44444444 :: inputs 5) tgt 4 := by
  change NoAtMost [0x44444444,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s3] [98,196,99,196,100,196,419,196,198,230,231,231,100,390,423,423,362,460,363,460,364,460,427,460,198,230,231,231,364,678,679,679,562,724,99,724,628,724,419,724,694,694,231,231,628,694,423,423,826,988,363,988,892,988,427,988,694,694,231,231,892,694,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s3], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_2
end PetersenSmallStarts.M47
