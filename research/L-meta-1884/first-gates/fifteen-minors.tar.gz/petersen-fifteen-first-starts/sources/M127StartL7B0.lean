import M127StartData
import M127StartPins0
import M127StartL6B0
import M127StartL6B1
import M127StartL6B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 7 s2 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s2 7 _ le
  decide +kernel
theorem b3 : Blocked tgt 7 s3 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s3 7 _ le
  decide +kernel
theorem b4 : Blocked tgt 7 s4 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s4 7 _ le
  decide +kernel
theorem b5 : Blocked tgt 7 s5 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s5 7 _ le
  decide +kernel
theorem b6 : Blocked tgt 7 s6 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s6 7 _ le
  decide +kernel
theorem b7 : Blocked tgt 7 s7 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s7 7 _ le
  decide +kernel
theorem b8 : Blocked tgt 7 s8 := by
  apply PetersenFastNode.node (nxt := #[s9,s11,s12]) (hints := [15095,15223,9676,8648,9932,9676,5293,9032,9032,5549,9032,8652,9928,9032,9032,7469,10952,9032,9032,0,13000,9032,776,840,8968,776,9804,9804,15095,9932,1,5549,15095,5549,15095,7477,15991,7477,13031,7469,15079,7469,10967,10999,15063,10967,6839,13613,15031,13613,5549,5933,7477,9928,7477,9924,7469,10440,7469,9932,9932,12488,13516,9932,13613,1740,13613,1676,6581,4525,7477,6581,5549,4533,7469,5549,1421,1453,5517,1421,5549,2,13613,5549,9928,7469,7461,7461,3349,3381,7445,3349,7477,12589,14645,7477,3341,3373,7437,3341,7469,12597,13613,7469,9485,9517,9485,13581]) (by decide +kernel)
  change ∀ b ∈ [s9,s11,s12], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.nil
theorem b13 : Blocked tgt 7 s13 := by
  apply PetersenFastNode.node (nxt := #[s14,s15]) (hints := [9031,5292,9031,9675,5548,13546,5548,9931,6580,4524,7476,6580,5548,4532,7468,5548,1420,1452,5516,1420,5548,0,13612,5548,9675,15222,9675,5804,9031,9675,8643,8651,9667,8643,9675,7468,11467,9675,9675,1,13515,9675,1419,1483,9611,1419,13930,5932,13930,5932,15094,7476,15990,7476,13030,11467,15078,11467,10966,13515,15062,13515,6838,13612,15030,13612,6964,4908,7476,6964,11467,4916,11467,5932,13515,1836,13515,1804,5932,5738,13612,5932,10435,10443,10435,11459,12483,12491,12483,13507,7476,12588,14644,7476,11467,3372,13515,11467,3211,3275,11403,3211,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s14,s15], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.nil
theorem b16 : Blocked tgt 7 s16 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s16 7 _ le
  decide +kernel
theorem b17 : Blocked tgt 7 s17 := by
  apply PetersenFastNode.node (nxt := #[s18,s19,s20,s23,s24]) (hints := [1423,1423,13002,9162,0,9162,13002,1,13518,9934,12490,9934,13002,9930,12494,9930,13002,10954,3343,10954,4746,12938,4810,4746,5263,5519,9162,5519,15065,1807,9934,1807,9934,3351,9930,3351,9930,3343,10954,3343,10954,5519,2,9487,5519,9162,11097,9678,8650,9934,9678,9162,8654,9930,9162,9162,3343,10954,9162,906,970,9098,906,9805,9934,9805,9934,11865,9930,11865,9930,11341,10954,11341,10954,3,9487,4,9487,2839,9930,9926,9926,9934,10442,11470,9934,1678,1742,9870,1678,9930,10446,10954,9930,1674,1738,9866,1674,2698,2762,10890,2698]) (by decide +kernel)
  change ∀ b ∈ [s18,s19,s20,s23,s24], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.nil
theorem b25 : Blocked tgt 7 s25 := by
  apply PetersenFastNode.node (nxt := #[s26,s27,s28,s30,s31,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s52,s53,s54,s55,s12,s56,s57,s60,s61,s62]) (hints := [6925,926,6925,7181,0,1,1442,1442,1698,5955,926,5955,1698,926,1698,5955,1442,5955,926,926,1694,7499,1442,7499,1694,1442,1694,926,926,7499,926,926,2718,7491,2,7491,2718,3,2718,926,926,7491,926,926,4766,4,5,6,4766,7,4766,926,926,8,798,9,10,798,926,5571,926,926,11,5571,12,5571,5377,5377,13953,5955,6925,5955,5889,6925,13953,5955,5377,5955,6925,6925,16013,7499,5377,7499,7949,5377,16013,7499,6925,7499,4861,4861,15489,7491,6925,7491,6909,6925,15489,7491,4861,7491,2797,2797,13,2829,6925,4766,6893,6925,14,2797,2797,4766,15,16,17,5571,6925,5571,6861,6925,11,5571,18,5571,6987,6987,7499,4931,5955,1694,7499,5955,7499,6987,6987,1694,5955,5955,7491,4939,6987,2718,7491,6987,7491,5955,5955,2718,1827,1827,5282,1859,5955,4766,5923,5955,5282,1827,1827,4766,5571,5955,5571,1698,1698,19,5571,1698,5571,5955,5955,20,1694,1694,2718,7491,7499,7491,7483,7499,2718,7483,1694,7491,3371,3371,4766,3403,7499,5282,7467,7499,4766,3371,3371,5282,6603,7499,6603,4547,1694,5571,6603,1694,6603,7499,7499,5571,3363,3363,4766,3395,7491,21,7459,7491,4766,3363,3363,22,5571,7491,5571,4555,2718,6603,5571,2718,5571,7491,7491,6603,1443,23,1443,1475,4766,5571,1443,4766,1443,5539,24,5571]) (by decide +kernel)
  change ∀ b ∈ [s26,s27,s28,s30,s31,s41,s42,s43,s44,s45,s46,s47,s48,s49,s50,s52,s53,s54,s55,s12,s56,s57,s60,s61,s62], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.push (x := s41) b41 <|
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s46) b46 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.push (x := s54) b54 <|
    PetersenLocalChildren.push (x := s55) b55 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.push (x := s56) b56 <|
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s60) b60 <|
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s62) b62 <|
    PetersenLocalChildren.nil
theorem b63 : Blocked tgt 7 s63 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s63 7 _ le
  decide +kernel
theorem b64 : Blocked tgt 7 s64 := by
  apply PetersenFastNode.node (nxt := #[s26,s65,s20,s66,s67,s68,s69,s70,s71]) (hints := [8974,0,910,6909,6909,5939,1682,5939,1682,7483,1678,7483,1678,7475,2702,7475,2702,1,4750,2,4750,5555,5555,910,15229,1426,398,1682,1426,910,402,1678,910,910,7475,2702,910,910,3,4750,910,4,910,910,13619,13937,1682,13937,1682,15997,1678,15997,1678,15473,2702,15473,2702,5,4750,6,4750,7,13619,8,13619,6971,1678,1674,1674,1682,2190,3218,1682,1682,4238,5266,1682,5939,1682,1682,5939,1678,2194,2702,1678,1678,4242,4750,1678,7483,1678,1678,7483,2702,3379,4750,2702,7475,2702,2702,7475,9491,4750,4750,13587]) (by decide +kernel)
  change ∀ b ∈ [s26,s65,s20,s66,s67,s68,s69,s70,s71], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s65) b65 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s66) b66 <|
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s68) b68 <|
    PetersenLocalChildren.push (x := s69) b69 <|
    PetersenLocalChildren.push (x := s70) b70 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b72 : Blocked tgt 7 s72 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s72 7 _ le
  decide +kernel
theorem b73 : Blocked tgt 7 s73 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s73 7 _ le
  decide +kernel
theorem b74 : Blocked tgt 7 s74 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s74 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
