import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1238 : Blocked tgt 7 s1238 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1238 7 _ le
  decide +kernel
theorem b1239 : Blocked tgt 7 s1239 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1239 7 _ le
  decide +kernel
theorem b1240 : Blocked tgt 7 s1240 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1240 7 _ le
  decide +kernel
theorem b1241 : Blocked tgt 7 s1241 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1241 7 _ le
  decide +kernel
theorem b1242 : Blocked tgt 7 s1242 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1242 7 _ le
  decide +kernel
theorem b1243 : Blocked tgt 7 s1243 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s1243 7 _ le
  decide +kernel
theorem b1244 : Blocked tgt 7 s1244 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1244 7 _ le
  decide +kernel
theorem b1245 : Blocked tgt 7 s1245 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1245 7 _ le
  decide +kernel
theorem b1246 : Blocked tgt 7 s1246 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s1246 7 _ le
  decide +kernel
theorem b1247 : Blocked tgt 7 s1247 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1247 7 _ le
  decide +kernel
theorem b1248 : Blocked tgt 7 s1248 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1248 7 _ le
  decide +kernel
theorem b1249 : Blocked tgt 7 s1249 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1249 7 _ le
  decide +kernel
theorem b1250 : Blocked tgt 7 s1250 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1250 7 _ le
  decide +kernel
theorem b1251 : Blocked tgt 7 s1251 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1251 7 _ le
  decide +kernel
theorem b1252 : Blocked tgt 7 s1252 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1252 7 _ le
  decide +kernel
theorem b1253 : Blocked tgt 7 s1253 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1253 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
