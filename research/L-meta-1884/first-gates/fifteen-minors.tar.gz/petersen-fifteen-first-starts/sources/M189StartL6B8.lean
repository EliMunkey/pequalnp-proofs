import M189StartData
import M189StartPins0
import M189StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b161 : Blocked tgt 6 s161 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s161 6 _ le
  decide +kernel
theorem b162 : Blocked tgt 6 s162 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s162 6 _ le
  decide +kernel
theorem b164 : Blocked tgt 6 s164 := by
  apply PetersenFastNode.node (nxt := #[s165]) (hints := [2274,2278,2530,2274,1625,2534,2534,1753,2534,580,2854,2534,1365,2470,1365,1429,2534,405,3430,2534,454,486,2502,454,1755,1947,452,2662,708,452,388,388,452,1365,452,3174,1220,452,452,3349,2244,452,1243,1243,1755,708,0,1755,1755,1235,715,731,1739,715,1755,2244,3739,1755,708,1813,708,3625,1220,708,708,3739,2244,708,3365,1220,3365,1220,3219,2244,3219,2244,1220,2715,2244,1220]) (by decide +kernel)
  change ∀ b ∈ [s165], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s165) b165 <|
    PetersenLocalChildren.nil
theorem b166 : Blocked tgt 6 s166 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s166 6 _ le
  decide +kernel
theorem b167 : Blocked tgt 6 s167 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s167 6 _ le
  decide +kernel
theorem b168 : Blocked tgt 6 s168 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s168 6 _ le
  decide +kernel
theorem b169 : Blocked tgt 6 s169 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s169 6 _ le
  decide +kernel
theorem b170 : Blocked tgt 6 s170 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s170 6 _ le
  decide +kernel
theorem b171 : Blocked tgt 6 s171 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s171 6 _ le
  decide +kernel
theorem b172 : Blocked tgt 6 s172 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s172 6 _ le
  decide +kernel
theorem b173 : Blocked tgt 6 s173 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s173 6 _ le
  decide +kernel
theorem b174 : Blocked tgt 6 s174 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s174 6 _ le
  decide +kernel
theorem b175 : Blocked tgt 6 s175 := by
  apply PetersenFastNode.node (nxt := #[s112]) (hints := [1365,2470,1429,1365,1755,388,1947,1755,1243,1243,1755,708,1755,1235,715,731,1739,715,1755,2244,3739,1755,2274,2278,2530,2274,2534,580,2918,2534,2209,2534,2534,2209,2534,1092,3430,2534,454,486,2502,454,452,2662,708,452,452,1427,452,3174,1220,452,452,809,2244,452,708,0,708,789,1220,708,708,870,2244,708,3105,1220,3105,1220,3219,2244,3219,2244,1220,1382,2244,1220]) (by decide +kernel)
  change ∀ b ∈ [s112], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.nil
theorem b176 : Blocked tgt 6 s176 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s176 6 _ le
  decide +kernel
theorem b177 : Blocked tgt 6 s177 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s177 6 _ le
  decide +kernel
theorem b178 : Blocked tgt 6 s178 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s178 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
