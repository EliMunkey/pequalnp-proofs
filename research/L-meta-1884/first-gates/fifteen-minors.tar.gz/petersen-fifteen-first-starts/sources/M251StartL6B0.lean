import M251StartData
import M251StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 6 s2 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s2 6 _ le
  decide +kernel
theorem b3 : Blocked tgt 6 s3 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s3 6 _ le
  decide +kernel
theorem b4 : Blocked tgt 6 s4 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s4 6 _ le
  decide +kernel
theorem b6 : Blocked tgt 6 s6 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6 6 _ le
  decide +kernel
theorem b7 : Blocked tgt 6 s7 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s7 6 _ le
  decide +kernel
theorem b8 : Blocked tgt 6 s8 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s8 6 _ le
  decide +kernel
theorem b9 : Blocked tgt 6 s9 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s9 6 _ le
  decide +kernel
theorem b10 : Blocked tgt 6 s10 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s10 6 _ le
  decide +kernel
theorem b11 : Blocked tgt 6 s11 := by
  intro k le c
  apply rejects_sound r2 i6 6 tgt small2 hot2 [] s11 6 _ le
  decide +kernel
theorem b12 : Blocked tgt 6 s12 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s12 6 _ le
  decide +kernel
theorem b13 : Blocked tgt 6 s13 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [(false,(0,false),(1,true))] s13 6 _ le
  decide +kernel
theorem b25 : Blocked tgt 6 s25 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [(true,(1,false),(3,false))] s25 6 _ le
  decide +kernel
theorem b26 : Blocked tgt 6 s26 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [(true,(1,false),(2,false))] s26 6 _ le
  decide +kernel
theorem b27 : Blocked tgt 6 s27 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s27 6 _ le
  decide +kernel
theorem b28 : Blocked tgt 6 s28 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s28 6 _ le
  decide +kernel
theorem b29 : Blocked tgt 6 s29 := by
  intro k le c
  apply rejects_sound r1 i6 6 tgt small1 hot1 [] s29 6 _ le
  decide +kernel
end PetersenSmallStarts.M251
