import M111StartData
import M111StartL6B0
import M111StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_4_1 : NoAtMost (0xff000000ff00 :: inputs 6) tgt 6 := by
  change NoAtMost [0xff000000ff00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s141] [194,714,195,715,196,716,835,843,390,714,455,715,196,716,839,2700,714,714,715,715,716,716,843,843,390,714,455,715,716,716,1351,2700,1106,714,195,715,1236,716,835,843,1366,714,455,715,1236,716,839,2700,1626,714,715,715,1756,716,843,843,1366,714,455,715,1756,716,3740,2700,2210,2730,2275,2795,196,716,2915,2923,2470,2730,2535,2795,196,716,2919,3431,2730,2730,2795,2795,716,716,2923,2923,2470,2730,2535,2795,716,716,3431,3431,3186,2730,2275,2795,1236,716,2915,2923,3446,2730,2535,2795,1236,716,2919,3894,3706,2730,2795,2795,1756,716,2923,2923,3446,2730,2535,2795,1756,716,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s141], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s141) b141 <|
    PetersenLocalChildren.nil
#print axioms gate_3_4_1
end PetersenSmallStarts.M111
