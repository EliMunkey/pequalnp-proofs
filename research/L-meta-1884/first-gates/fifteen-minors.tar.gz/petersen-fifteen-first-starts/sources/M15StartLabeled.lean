import M15StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 16) : Fin 16 := (#[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15] : Array (Fin 16))[x.val]?.getD 0
private theorem cover0 : i4.all (fun q => i4.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
theorem labeled_0_3_2 : NoAtMost (0x5500 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x5500) (a:=0xaa) (by decide +kernel) gate_0_3_1
theorem labeled_1_2_2 : NoAtMost (0x3030 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3030) (a:=0xc0c) (by decide +kernel) gate_1_2_1
theorem labeled_1_3_1 : NoAtMost (0xcc :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc) (a:=0x5050) (by decide +kernel) gate_0_2_2
theorem labeled_1_3_2 : NoAtMost (0x3300 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3300) (a:=0xa0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_3_3 : NoAtMost (0xcc00 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc00) (a:=0xa0a0) (by decide +kernel) gate_0_2_3
theorem labeled_2_3_0 : NoAtMost (0xfff0 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfff0) (a:=0xeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_3_1 : NoAtMost (0xf0 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0) (a:=0x4444) (by decide +kernel) gate_0_1_2
theorem labeled_2_3_2 : NoAtMost (0xf00 :: inputs 4) tgt 3 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf00) (a:=0x2222) (by decide +kernel) gate_0_1_1
def forbidden : List (BitVec 16) := [0xeeee,0x2222,0x4444,0xa0a,0x5050,0xa0a0,0xffaa,0xaa,0x5500,0xaa00,0xfcfc,0xc0c,0x3030,0xc0c0,0xcc,0x3300,0xcc00,0xfff0,0xf0,0xf00]
theorem all_forbidden (g : BitVec 16) (h : g∈forbidden) : NoAtMost (g::inputs 4) tgt 3 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 4) tgt 3 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x2222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x4444) gate_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xa0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x5050) gate_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xa0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xaa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x5500) labeled_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xaa00) gate_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xfcfc) gate_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xc0c) gate_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x3030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xc0c0) gate_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xcc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0x3300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xcc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xfff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xf0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 4) tgt 3) (x:=0xf00) labeled_2_3_2 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M15
