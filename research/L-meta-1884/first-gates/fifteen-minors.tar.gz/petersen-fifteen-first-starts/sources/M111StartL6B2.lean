import M111StartData
import M111StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b145 : Blocked tgt 6 s145 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s145 6 _ le
  decide +kernel
theorem b146 : Blocked tgt 6 s146 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s146 6 _ le
  decide +kernel
end PetersenSmallStarts.M111
