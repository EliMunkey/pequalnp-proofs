import M119StartData
import M119StartL5B0
import M119StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_5_3 : NoAtMost (0xf0f0f0f000000000 :: inputs 6) tgt 5 := by
  change NoAtMost [0xf0f0f0f000000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s22] [194,2470,195,2535,196,196,579,2919,390,2470,455,2535,196,196,839,2919,586,2926,195,2535,716,716,1091,3431,846,2926,455,2535,716,716,1351,3431,1106,3446,195,2535,1236,1236,579,2919,1366,3446,455,2535,1236,1236,839,2919,1626,3966,195,2535,1756,1756,1948,1948,1886,3966,455,2535,1756,1756,3740,3740,2210,2470,2275,2535,196,196,2659,2919,2470,2470,2535,2535,196,196,2919,2919,2666,2926,2275,2535,716,716,3171,3431,2926,2926,2535,2535,716,716,3431,3431,3186,3446,2275,2535,1236,1236,2659,2919,3446,3446,2535,2535,1236,1236,2919,2919,3706,3966,2275,2535,1756,1756,1948,1948,3966,3966,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s22], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.nil
#print axioms gate_2_5_3
end PetersenSmallStarts.M119
