import M47StartData
import M47StartL4B1
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_2 : NoAtMost (0x33003300 :: inputs 5) tgt 4 := by
  change NoAtMost [0x33003300,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s19,s0,s20] [99,395,100,428,101,395,420,428,199,811,232,812,101,811,424,812,363,395,364,428,365,395,428,428,199,811,232,812,365,811,680,812,563,827,100,428,629,827,420,428,695,827,232,232,629,827,424,0,827,827,364,428,893,827,428,428,695,827,232,232,893,827,1,2] (by decide +kernel)
  change ∀ b ∈ [s19,s0,s20], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_2
end PetersenSmallStarts.M47
