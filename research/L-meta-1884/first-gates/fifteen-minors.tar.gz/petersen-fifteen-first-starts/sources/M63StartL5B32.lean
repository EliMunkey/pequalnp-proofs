import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1191 : Blocked tgt 5 s1191 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1191 5 _ le
  decide +kernel
theorem b1192 : Blocked tgt 5 s1192 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1192 5 _ le
  decide +kernel
theorem b1193 : Blocked tgt 5 s1193 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(0,false),(5,false))] s1193 5 _ le
  decide +kernel
theorem b1194 : Blocked tgt 5 s1194 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1194 5 _ le
  decide +kernel
theorem b1195 : Blocked tgt 5 s1195 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1195 5 _ le
  decide +kernel
theorem b1196 : Blocked tgt 5 s1196 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1196 5 _ le
  decide +kernel
theorem b1197 : Blocked tgt 5 s1197 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(0,false),(5,false))] s1197 5 _ le
  decide +kernel
theorem b1198 : Blocked tgt 5 s1198 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1198 5 _ le
  decide +kernel
theorem b1199 : Blocked tgt 5 s1199 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1199 5 _ le
  decide +kernel
theorem b1200 : Blocked tgt 5 s1200 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1200 5 _ le
  decide +kernel
theorem b1201 : Blocked tgt 5 s1201 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1201 5 _ le
  decide +kernel
theorem b1202 : Blocked tgt 5 s1202 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1202 5 _ le
  decide +kernel
theorem b1203 : Blocked tgt 5 s1203 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(0,false),(5,false))] s1203 5 _ le
  decide +kernel
theorem b1208 : Blocked tgt 5 s1208 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1208 5 _ le
  decide +kernel
theorem b1209 : Blocked tgt 5 s1209 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(0,true),(5,false))] s1209 5 _ le
  decide +kernel
theorem b1210 : Blocked tgt 5 s1210 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(0,true),(5,false))] s1210 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
