import M111StartData
import M111StartPins0
import M111StartL5B0
import M111StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 6 s0 := by
  intro k le c
  apply rejects_sound r0 i6 6 tgt small0 hot0 [] s0 6 _ le
  decide +kernel
theorem b1 : Blocked tgt 6 s1 := by
  apply PetersenFastNode.node (nxt := #[s2,s6,s7,s8,s9,s10]) (hints := [2475,1760,2539,1760,3450,1760,2927,1952,1760,1240,1248,1752,1240,720,736,1744,720,1760,0,3744,1760,2539,3514,2799,2283,2927,2799,2539,2287,2923,2539,2539,1,3435,2539,459,491,2507,459,3902,2927,3902,2927,3898,2923,3898,2923,2,3435,3,3435,4,3744,5,3744,1432,2923,2919,2919,2927,3179,3695,2927,847,879,2895,847,2923,3183,3435,2923,843,875,2891,843,1355,1387,3403,1355]) (by decide +kernel)
  change ∀ b ∈ [s2,s6,s7,s8,s9,s10], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.nil
theorem b11 : Blocked tgt 6 s11 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s11 6 _ le
  decide +kernel
theorem b12 : Blocked tgt 6 s12 := by
  apply PetersenFastNode.node (nxt := #[s13,s14,s15,s16,s17,s18,s21,s23]) (hints := [1762,1762,2541,3516,2929,1954,2929,1954,2925,0,2925,1,3437,2,3437,3,4,3746,5,3746,3452,2541,3580,1954,2865,1954,3712,3452,2861,3900,3452,6,3437,3436,3436,3746,1404,3746,1372,2801,1954,2929,1954,2541,2289,2925,2541,2541,7,3437,2541,461,3746,2509,3746,1434,1442,1946,1434,914,930,1938,914,1954,881,3746,1954,2925,3185,3437,2925,3226,3234,3226,3738,2706,2722,2706,3730]) (by decide +kernel)
  change ∀ b ∈ [s13,s14,s15,s16,s17,s18,s21,s23], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.nil
theorem b24 : Blocked tgt 6 s24 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s24 6 _ le
  decide +kernel
theorem b25 : Blocked tgt 6 s25 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s25 6 _ le
  decide +kernel
theorem b26 : Blocked tgt 6 s26 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s26 6 _ le
  decide +kernel
theorem b27 : Blocked tgt 6 s27 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s27 6 _ le
  decide +kernel
theorem b28 : Blocked tgt 6 s28 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s28 6 _ le
  decide +kernel
theorem b29 : Blocked tgt 6 s29 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s29 6 _ le
  decide +kernel
theorem b30 : Blocked tgt 6 s30 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s30 6 _ le
  decide +kernel
theorem b31 : Blocked tgt 6 s31 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s31 6 _ le
  decide +kernel
theorem b32 : Blocked tgt 6 s32 := by
  apply PetersenFastNode.node (nxt := #[s33,s34,s35,s36,s37,s38,s39,s40,s41,s43,s44,s48,s50,s54,s55,s56]) (hints := [730,3445,1754,730,0,1,3445,3445,2484,2549,2,2549,2484,3,2484,2549,3445,2549,3705,3705,922,2937,3445,2937,3189,3445,922,2937,3705,2937,3445,3445,2868,2933,3705,2933,3193,3705,2868,2933,3445,2933,1365,1365,2714,3413,3445,4,1397,3445,2714,1365,1365,5,2484,3444,2484,2549,1754,2549,2484,1754,2484,2549,3444,2549,922,1754,922,2937,3444,2937,922,3444,922,2937,1754,2937,1234,1234,2868,2933,1754,2933,1746,1754,2868,2933,1234,2933,1754,1754,2714,1396,3444,6,2714,3444,2714,1754,1754,7,2809,2809,2937,2293,2549,922,2937,2549,2937,2809,2809,922,2549,2549,2933,2297,2809,8,2933,2809,2933,2549,2549,9,469,469,10,501,2549,2714,2517,2549,11,469,469,2714,402,402,12,2933,2937,2933,2929,2937,13,2929,402,2933,857,857,2714,889,2937,14,2905,2937,2714,857,857,15,853,853,2194,885,2933,2714,2901,2933,2194,853,853,2714]) (by decide +kernel)
  change ∀ b ∈ [s33,s34,s35,s36,s37,s38,s39,s40,s41,s43,s44,s48,s50,s54,s55,s56], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s33) b33 <|
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.push (x := s41) b41 <|
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s54) b54 <|
    PetersenLocalChildren.push (x := s55) b55 <|
    PetersenLocalChildren.push (x := s56) b56 <|
    PetersenLocalChildren.nil
theorem b57 : Blocked tgt 6 s57 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s57 6 _ le
  decide +kernel
theorem b58 : Blocked tgt 6 s58 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s58 6 _ le
  decide +kernel
theorem b59 : Blocked tgt 6 s59 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s59 6 _ le
  decide +kernel
end PetersenSmallStarts.M111
