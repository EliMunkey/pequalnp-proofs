import M63StartData
import M63StartL4B0
import M63StartL4B1
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b531 : Blocked tgt 5 s531 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1349,1609,1234,714,1349,453,388,453,1865,841,1349,841,1682,837,1682,837,1674,1234,1738,1674,453,1546,453,1544,841,402,837,1674,837,1666,1104,453,1232,453,1234,841,906,841,1234,837,1682,837,713,197,841,713,453,201,837,453,1682,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b532 : Blocked tgt 5 s532 := by
  apply PetersenFastNode.node (nxt := #[s533,s534]) (hints := [716,716,1351,455,390,455,2635,843,1095,843,1351,1611,1351,839,1099,839,390,455,390,455,908,843,908,843,1676,0,1676,1740,1220,839,2756,839,715,199,843,715,455,1548,1546,455,455,203,839,455,843,1,1676,843,388,839,835,835,839,1668]) (by decide +kernel)
  change ∀ b ∈ [s533,s534], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s533) b533 <|
    PetersenLocalChildren.push (x := s534) b534 <|
    PetersenLocalChildren.nil
theorem b535 : Blocked tgt 5 s535 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1349,2633,1609,1349,714,714,2633,713,388,713,2633,841,906,841,1349,2633,2633,1349,1674,1738,1218,1674,453,713,453,713,1674,841,386,841,837,837,2632,713,2760,713,906,841,906,841,1218,2762,2762,1218,713,197,841,713,453,713,713,453,386,841,841,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b538 : Blocked tgt 5 s538 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s538 5 _ le
  decide +kernel
theorem b540 : Blocked tgt 5 s540 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s540 5 _ le
  decide +kernel
theorem b541 : Blocked tgt 5 s541 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1364,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,1428,453,776,841,776,841,1812,837,1812,837,2372,1349,3396,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b542 : Blocked tgt 5 s542 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,453,2373,453,1364,1364,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,453,1428,713,841,197,713,453,837,201,453,453,1349,404,453,3156,841,3412,841,1812,837,1812,837,2372,1349,3396,1349,1424,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b545 : Blocked tgt 5 s545 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s545 5 _ le
  decide +kernel
theorem b546 : Blocked tgt 5 s546 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,388,453,388,453,906,841,906,841,2242,837,2754,837,1674,1349,1674,1349,713,197,841,713,453,201,837,453,453,1546,1349,453,386,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b547 : Blocked tgt 5 s547 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1674,1349,2373,1349,714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,1674,1349,1349,1674,1349,453,388,453,1609,841,1093,841,1349,837,1097,837,2632,453,2760,453,906,841,906,841,2250,837,2762,837,713,197,841,713,453,201,837,453,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b550 : Blocked tgt 5 s550 := by
  apply PetersenFastNode.node (nxt := #[s551]) (hints := [2763,715,1235,715,2374,454,1429,454,2634,842,2118,842,2374,838,2122,838,2374,1350,0,1350,1429,454,713,454,715,778,907,715,203,203,715,838,715,1350,1675,715,714,198,842,714,454,202,838,454,454,1547,1350,454,1427,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s551], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s551) b551 <|
    PetersenLocalChildren.nil
theorem b552 : Blocked tgt 5 s552 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [712,712,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,1428,453,776,841,776,841,1554,837,1554,837,1544,1349,1544,1349,713,197,841,713,453,201,837,453,453,404,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b553 : Blocked tgt 5 s553 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,453,1428,453,1234,1234,1426,841,1426,841,2373,837,2121,837,2373,1349,1544,1349,1428,453,453,1428,713,197,841,713,453,201,837,453,453,404,1349,453,1426,841,1426,841,3282,837,3794,837,2242,1349,3266,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b556 : Blocked tgt 5 s556 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s556 5 _ le
  decide +kernel
theorem b559 : Blocked tgt 5 s559 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1234,714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1364,453,1428,1364,1234,841,1426,1234,1234,837,1682,1234,210,210,1234,1349,713,197,841,713,453,201,837,453,453,1428,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b561 : Blocked tgt 5 s561 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,2373,714,714,389,389,2760,453,2762,841,776,841,1682,837,1682,837,1674,1349,1674,1349,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,713,197,841,713,453,201,837,453,453,1546,1349,453,1682,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
