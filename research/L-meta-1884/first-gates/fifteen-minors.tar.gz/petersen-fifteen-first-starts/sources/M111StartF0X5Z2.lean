import M111StartData
import M111StartL6B1
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_2 : NoAtMost (0x5555555500000000 :: inputs 6) tgt 6 := by
  change NoAtMost [0x5555555500000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s60,s0,s77] [195,2211,196,2211,197,2851,836,2851,391,2471,456,2471,197,2855,840,2855,715,2731,716,2731,717,2859,844,2859,391,2471,456,2471,717,717,1352,1352,1107,3251,196,3251,1237,3891,836,3891,1367,3511,456,3511,1237,3895,840,3895,1627,3771,716,3771,1757,3899,844,3899,1367,3511,456,3511,1757,1757,3741,0,2211,2211,2276,2211,197,2851,2916,2851,2471,2471,2536,2471,197,2855,2920,2855,2731,2731,2796,2731,717,2859,2924,2859,2471,2471,2536,2471,717,717,3432,3432,3187,3251,2276,3251,1237,3891,2916,3891,3447,3511,2536,3511,1237,3895,2920,3895,3707,3771,2796,3771,1757,3899,2924,3899,3447,3511,2536,3511,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s60,s0,s77], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s60) b60 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_2
end PetersenSmallStarts.M111
