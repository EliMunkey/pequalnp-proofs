import M189StartData
import M189StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_3 : NoAtMost (0xa0a0a0a0a0a0a0a0 :: inputs 6) tgt 7 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s135] [386,455,451,455,388,839,453,839,390,455,455,455,708,839,709,839,586,455,451,455,716,1351,453,1351,390,455,455,455,716,1351,1221,1351,1106,455,451,455,1236,839,453,839,1366,455,455,455,1236,839,709,839,1626,455,451,455,1756,1756,453,2245,1366,455,455,455,1756,1756,2245,2245,2210,2535,2275,2535,388,2919,453,2919,2470,2535,2535,2535,708,2919,709,2919,2666,2535,2275,2535,716,3431,453,3431,2470,2535,2535,2535,716,3431,1221,3431,1106,2535,2275,2535,1236,2919,453,2919,1366,2535,2535,2535,1236,2919,709,2919,1626,2535,2275,2535,1756,1756,453,1948,1366,2535,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s135], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s135) b135 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_3
end PetersenSmallStarts.M189
