import M189StartData
import M189StartPins0
import M189StartL6B0
import M189StartL6B1
import M189StartL6B2
import M189StartL6B3
import M189StartL6B4
import M189StartL6B5
import M189StartL6B6
import M189StartL6B7
import M189StartL6B8
import M189StartL6B9
import M189StartL6B10
import M189StartL6B11
import M189StartL6B12
import M189StartL6B13
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 7 s0 := by
  intro k le c
  apply rejects_sound r0 i6 7 tgt small0 hot0 [] s0 7 _ le
  decide +kernel
theorem b1 : Blocked tgt 7 s1 := by
  apply PetersenFastNode.node (nxt := #[s2,s3,s4,s5,s6,s7,s8,s10,s11,s13,s14,s15,s17,s18,s20,s21,s22,s25,s26,s27,s28,s31,s32,s33,s34,s37,s38,s39,s40,s43,s44]) (hints := [2500,0,1,1785,1785,2,2564,3,2564,1785,1785,4,1395,3,5,1785,1785,1977,418,6,482,1977,7,1977,1785,1785,482,1265,1265,1843,1273,1785,738,1777,1785,1843,1265,1265,738,745,745,3395,761,1785,1250,1769,1785,3395,745,745,1250,1785,1785,3769,2210,8,2274,3769,9,3769,1785,1785,2274,2564,2564,4,1459,2,10,2304,2304,1847,2308,2564,482,2560,2564,1847,2304,2304,482,2564,2564,2948,610,11,738,2948,12,2948,2564,2564,738,2564,2564,3460,1122,13,1250,3460,14,3460,2564,2564,1250,484,484,3379,516,2564,2274,2532,2564,3379,484,484,2274,1847,15,1847,482,16,482,1847,17,1847,482,18,482,1843,19,1843,738,20,738,1843,21,1843,738,22,738,3395,23,3395,1250,24,1250,3395,25,3395,1250,26,1250,3379,27,3379,2274,28,2274,3379,29,3379,2274,30,2274,482,482,738,2692,1977,2948,738,1977,738,482,482,2948,482,482,1250,3204,1977,3460,1250,1977,1250,482,482,3460,482,482,2274,839,2887,3379,2274,2887,2274,482,482,3379,738,738,1250,819,1843,3655,1250,1843,1250,738,738,3655,738,738,2274,900,2948,3769,2274,2948,2274,738,738,3769,1250,1250,2274,1412,3460,3769,2274,3460,2274,1250,1250,3769]) (by decide +kernel)
  change ∀ b ∈ [s2,s3,s4,s5,s6,s7,s8,s10,s11,s13,s14,s15,s17,s18,s20,s21,s22,s25,s26,s27,s28,s31,s32,s33,s34,s37,s38,s39,s40,s43,s44], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.push (x := s33) b33 <|
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.nil
theorem b45 : Blocked tgt 7 s45 := by
  apply PetersenFastNode.node (nxt := #[s6,s46,s47,s48,s4,s49,s50,s53,s54,s55,s56,s59,s60,s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s73,s74,s75,s76,s79,s80,s81,s82,s83,s84,s85,s86]) (hints := [1789,0,1789,1399,1,2,2568,0,1463,2568,3,4,486,5,486,6,7,8,486,9,486,10,11,12,742,13,742,2952,14,2952,742,15,742,2952,16,2952,1254,17,1254,3464,18,3464,1254,19,1254,3464,20,3464,2278,21,2278,22,23,24,2278,25,2278,26,27,28,1463,2,1463,1789,1789,4,1527,29,30,1789,1789,1981,422,31,486,1981,32,1981,1789,1789,486,1269,1269,1847,2952,1789,2952,1781,1789,1847,2952,1269,2952,749,749,3399,3464,1789,3464,1773,1789,3399,3464,749,3464,1789,1789,3773,2214,33,2278,3773,34,3773,1789,1789,2278,1851,2763,1851,486,1463,486,1851,1463,1851,486,2763,486,2952,1463,2952,742,2763,742,2952,2763,2952,742,1463,742,3464,2503,3464,1254,1463,1254,3464,1463,3464,1254,2503,1254,1463,1463,3383,2278,2503,2278,3383,2503,3383,2278,1463,2278,2692,486,2692,2696,1981,2952,2692,1981,2692,2948,486,2952,3204,486,3204,3208,1981,3464,3204,1981,3204,3460,486,3464,486,486,2278,843,2891,3383,2278,2891,2278,486,486,3383,2952,2952,3464,823,1847,3659,3464,1847,3464,2952,2952,3659,872,872,2278,904,2952,3773,2920,2952,2278,872,872,3773,1384,1384,2278,1416,3464,3773,3432,3464,2278,1384,1384,3773]) (by decide +kernel)
  change ∀ b ∈ [s6,s46,s47,s48,s4,s49,s50,s53,s54,s55,s56,s59,s60,s61,s62,s63,s64,s65,s66,s67,s68,s69,s70,s73,s74,s75,s76,s79,s80,s81,s82,s83,s84,s85,s86], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s46) b46 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.push (x := s54) b54 <|
    PetersenLocalChildren.push (x := s55) b55 <|
    PetersenLocalChildren.push (x := s56) b56 <|
    PetersenLocalChildren.push (x := s59) b59 <|
    PetersenLocalChildren.push (x := s60) b60 <|
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s62) b62 <|
    PetersenLocalChildren.push (x := s63) b63 <|
    PetersenLocalChildren.push (x := s64) b64 <|
    PetersenLocalChildren.push (x := s65) b65 <|
    PetersenLocalChildren.push (x := s66) b66 <|
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s68) b68 <|
    PetersenLocalChildren.push (x := s69) b69 <|
    PetersenLocalChildren.push (x := s70) b70 <|
    PetersenLocalChildren.push (x := s73) b73 <|
    PetersenLocalChildren.push (x := s74) b74 <|
    PetersenLocalChildren.push (x := s75) b75 <|
    PetersenLocalChildren.push (x := s76) b76 <|
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s82) b82 <|
    PetersenLocalChildren.push (x := s83) b83 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s85) b85 <|
    PetersenLocalChildren.push (x := s86) b86 <|
    PetersenLocalChildren.nil
theorem b87 : Blocked tgt 7 s87 := by
  apply PetersenFastNode.node (nxt := #[s6,s14,s47,s7,s88,s89,s90,s91,s92,s93,s94,s95,s96,s97,s98,s99,s100,s101,s102,s103,s104,s2,s3]) (hints := [1777,0,1387,1777,1,2,2556,0,1451,2556,3,4,1969,5,1969,474,6,474,1969,7,1969,474,8,474,2940,9,2940,730,10,730,2940,11,2940,730,12,730,3452,13,3452,1242,14,1242,3452,15,3452,1242,16,1242,3761,17,3761,2266,18,2266,3761,19,3761,2266,20,2266,2492,21,22,1451,2,1451,1387,1387,4,1969,1647,1969,474,1387,474,1969,1387,1969,474,1647,474,1387,1387,1835,730,1647,730,1835,1647,1835,730,1387,730,3387,2687,3387,1242,1387,1242,3387,1387,3387,1242,2687,1242,3761,1387,3761,2266,2687,2266,3761,2687,3761,2266,1387,2266,1839,2751,1839,474,1451,474,1839,1451,1839,474,2751,474,2940,1451,2940,730,2751,730,2940,2751,2940,730,1451,730,3452,2491,3452,1242,1451,1242,3452,1451,3452,1242,2491,1242,1451,1451,3371,2266,2491,2266,3371,2491,3371,2266,1451,2266,474,474,730,2684,1969,2940,730,1969,730,474,474,2940,474,474,1242,3196,1969,3452,1242,1969,1242,474,474,3452,474,474,2266,831,2879,3371,2266,2879,2266,474,474,3371,730,730,1242,811,1835,3647,1242,1835,1242,730,730,3647,730,730,2266,892,2940,3761,2266,2940,2266,730,730,3761,1242,1242,2266,1404,3452,3761,2266,3452,2266,1242,1242,3761]) (by decide +kernel)
  change ∀ b ∈ [s6,s14,s47,s7,s88,s89,s90,s91,s92,s93,s94,s95,s96,s97,s98,s99,s100,s101,s102,s103,s104,s2,s3], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s88) b88 <|
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.push (x := s90) b90 <|
    PetersenLocalChildren.push (x := s91) b91 <|
    PetersenLocalChildren.push (x := s92) b92 <|
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.push (x := s95) b95 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.push (x := s97) b97 <|
    PetersenLocalChildren.push (x := s98) b98 <|
    PetersenLocalChildren.push (x := s99) b99 <|
    PetersenLocalChildren.push (x := s100) b100 <|
    PetersenLocalChildren.push (x := s101) b101 <|
    PetersenLocalChildren.push (x := s102) b102 <|
    PetersenLocalChildren.push (x := s103) b103 <|
    PetersenLocalChildren.push (x := s104) b104 <|
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
theorem b105 : Blocked tgt 7 s105 := by
  apply PetersenFastNode.node (nxt := #[s6,s106,s107,s91,s108,s55,s109,s110,s113,s114,s115,s116,s117,s118,s119,s120,s121,s122,s123,s124,s125,s10,s84,s126,s127,s128,s129,s130,s131,s132,s134]) (hints := [1785,0,1395,1785,1,2,2564,3,2564,2304,4,2304,2564,5,2564,2304,6,2304,482,0,1977,482,7,8,2948,9,2948,738,10,738,2948,11,2948,738,12,738,3460,13,3460,1250,14,1250,3460,15,3460,1250,16,1250,3769,17,3769,2274,18,2274,3769,19,3769,2274,20,2274,1395,1395,1459,2304,21,2304,1459,22,1459,2304,1395,2304,1977,2,1977,1395,1395,8,2041,23,24,1395,1395,1843,738,25,738,1843,26,1843,738,1395,738,3395,27,3395,1250,1395,1250,3395,1395,3395,1250,28,1250,3769,1395,3769,2274,29,2274,3769,30,3769,2274,1395,2274,2304,2304,1847,2564,2564,1977,2564,2564,1847,2304,2304,1977,2304,2304,2688,610,2759,738,2688,2759,2688,2304,2304,738,2304,2304,3200,1122,1459,1250,3200,1459,3200,2304,2304,1250,484,484,3379,2274,2304,2274,2272,2304,3379,2272,484,2274,738,1457,738,2948,1977,2948,738,1977,738,2948,1457,2948,1250,937,1250,3460,1977,3460,1250,1977,1250,3460,937,3460,2274,1977,2274,839,2887,3379,2274,2887,2274,1977,1977,3379,738,738,1250,819,1843,3655,1250,1843,1250,738,738,3655,738,738,2274,640,2688,3769,2274,2688,2274,738,738,3769,1250,1250,2274,1152,3200,3769,2274,3200,2274,1250,1250,3769]) (by decide +kernel)
  change ∀ b ∈ [s6,s106,s107,s91,s108,s55,s109,s110,s113,s114,s115,s116,s117,s118,s119,s120,s121,s122,s123,s124,s125,s10,s84,s126,s127,s128,s129,s130,s131,s132,s134], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s106) b106 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s91) b91 <|
    PetersenLocalChildren.push (x := s108) b108 <|
    PetersenLocalChildren.push (x := s55) b55 <|
    PetersenLocalChildren.push (x := s109) b109 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s113) b113 <|
    PetersenLocalChildren.push (x := s114) b114 <|
    PetersenLocalChildren.push (x := s115) b115 <|
    PetersenLocalChildren.push (x := s116) b116 <|
    PetersenLocalChildren.push (x := s117) b117 <|
    PetersenLocalChildren.push (x := s118) b118 <|
    PetersenLocalChildren.push (x := s119) b119 <|
    PetersenLocalChildren.push (x := s120) b120 <|
    PetersenLocalChildren.push (x := s121) b121 <|
    PetersenLocalChildren.push (x := s122) b122 <|
    PetersenLocalChildren.push (x := s123) b123 <|
    PetersenLocalChildren.push (x := s124) b124 <|
    PetersenLocalChildren.push (x := s125) b125 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s126) b126 <|
    PetersenLocalChildren.push (x := s127) b127 <|
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.push (x := s130) b130 <|
    PetersenLocalChildren.push (x := s131) b131 <|
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.push (x := s134) b134 <|
    PetersenLocalChildren.nil
theorem b135 : Blocked tgt 7 s135 := by
  apply PetersenFastNode.node (nxt := #[s6,s136,s107,s89,s137,s49,s138,s139,s140,s141,s142,s143,s144,s145,s146,s147,s148,s149,s150,s155,s156,s157,s158,s159,s160,s161,s162]) (hints := [1781,0,1781,1391,1,2,2300,3,2300,2560,4,2560,2300,5,2300,2560,6,2560,478,0,1973,478,7,8,734,9,734,2944,10,2944,734,11,734,2944,12,2944,1246,13,1246,3456,14,3456,1246,15,1246,3456,16,3456,2270,17,2270,18,19,20,2270,21,2270,22,23,24,1455,1651,1455,2560,1781,2560,1455,1781,1455,2560,1651,2560,414,25,26,1973,2,1973,1781,1781,8,1261,1261,1839,2944,1781,2944,1773,1781,1839,2944,1261,2944,741,741,3391,3456,1781,3456,1765,1781,3391,3456,741,3456,1781,1781,3765,2206,2691,2270,3765,2691,3765,1781,1781,2270,2300,2300,1843,2560,2560,1973,2560,2560,1843,2300,2300,1973,2560,2560,2944,606,2755,734,2944,2755,2944,2560,2560,734,2560,2560,3456,1118,1455,1246,3456,1455,3456,2560,2560,1246,480,480,3375,512,2560,2270,2528,2560,3375,480,480,2270,734,1453,734,2944,1973,2944,734,1973,734,2944,1453,2944,1246,933,1246,3456,1973,3456,1246,1973,1246,3456,933,3456,2270,1973,2270,835,2883,3375,2270,2883,2270,1973,1973,3375,2944,2944,3456,815,1839,3651,3456,1839,3456,2944,2944,3651,864,864,2270,896,2944,3765,2912,2944,2270,864,864,3765,1376,1376,2270,1408,3456,3765,3424,3456,2270,1376,1376,3765]) (by decide +kernel)
  change ∀ b ∈ [s6,s136,s107,s89,s137,s49,s138,s139,s140,s141,s142,s143,s144,s145,s146,s147,s148,s149,s150,s155,s156,s157,s158,s159,s160,s161,s162], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s136) b136 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.push (x := s137) b137 <|
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.push (x := s138) b138 <|
    PetersenLocalChildren.push (x := s139) b139 <|
    PetersenLocalChildren.push (x := s140) b140 <|
    PetersenLocalChildren.push (x := s141) b141 <|
    PetersenLocalChildren.push (x := s142) b142 <|
    PetersenLocalChildren.push (x := s143) b143 <|
    PetersenLocalChildren.push (x := s144) b144 <|
    PetersenLocalChildren.push (x := s145) b145 <|
    PetersenLocalChildren.push (x := s146) b146 <|
    PetersenLocalChildren.push (x := s147) b147 <|
    PetersenLocalChildren.push (x := s148) b148 <|
    PetersenLocalChildren.push (x := s149) b149 <|
    PetersenLocalChildren.push (x := s150) b150 <|
    PetersenLocalChildren.push (x := s155) b155 <|
    PetersenLocalChildren.push (x := s156) b156 <|
    PetersenLocalChildren.push (x := s157) b157 <|
    PetersenLocalChildren.push (x := s158) b158 <|
    PetersenLocalChildren.push (x := s159) b159 <|
    PetersenLocalChildren.push (x := s160) b160 <|
    PetersenLocalChildren.push (x := s161) b161 <|
    PetersenLocalChildren.push (x := s162) b162 <|
    PetersenLocalChildren.nil
theorem b163 : Blocked tgt 7 s163 := by
  apply PetersenFastNode.node (nxt := #[s164,s128,s166,s167,s168,s169,s6,s170,s171,s28,s172,s173,s174,s175,s176,s177,s178,s179,s181,s182,s183,s185,s186,s187,s188,s191,s192]) (hints := [1455,1651,1455,2560,1781,2560,1455,1781,1455,2560,1651,2560,1781,1781,1973,478,0,478,1973,1,1973,1781,1781,478,1269,2,3,1781,1781,4,734,5,734,1781,1781,6,1261,5,7,741,741,3391,757,1781,1246,1765,1781,3391,741,741,1246,1781,1781,3765,2270,2691,2270,3765,2691,3765,1781,1781,2270,2300,2300,1843,2304,2560,478,2556,2560,1843,2300,2300,478,2560,2560,2944,606,2755,734,2944,2755,2944,2560,2560,734,1455,1455,8,2560,2560,9,2560,2560,10,1455,1455,11,2560,2560,3456,1118,1455,1246,3456,1455,3456,2560,2560,1246,480,480,3375,512,2560,2270,2528,2560,3375,480,480,2270,478,478,734,2688,1973,2944,734,1973,734,478,478,2944,1453,1453,12,478,478,13,478,478,14,1453,1453,15,478,478,1246,3200,1973,3456,1246,1973,1246,478,478,3456,478,478,2270,835,2883,3375,2270,2883,2270,478,478,3375,734,734,6,1839,4,16,734,734,1246,3651,17,3651,1246,18,1246,734,734,3651,734,734,2270,896,2944,3765,2270,2944,2270,734,734,3765,3391,19,3391,1246,20,1246,3391,21,3391,1246,22,1246,3245,23,3245,2270,24,2270,3245,25,3245,2270,26,2270,1246,1246,2270,1408,3456,3765,2270,3456,2270,1246,1246,3765]) (by decide +kernel)
  change ∀ b ∈ [s164,s128,s166,s167,s168,s169,s6,s170,s171,s28,s172,s173,s174,s175,s176,s177,s178,s179,s181,s182,s183,s185,s186,s187,s188,s191,s192], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s164) b164 <|
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.push (x := s166) b166 <|
    PetersenLocalChildren.push (x := s167) b167 <|
    PetersenLocalChildren.push (x := s168) b168 <|
    PetersenLocalChildren.push (x := s169) b169 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s171) b171 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s172) b172 <|
    PetersenLocalChildren.push (x := s173) b173 <|
    PetersenLocalChildren.push (x := s174) b174 <|
    PetersenLocalChildren.push (x := s175) b175 <|
    PetersenLocalChildren.push (x := s176) b176 <|
    PetersenLocalChildren.push (x := s177) b177 <|
    PetersenLocalChildren.push (x := s178) b178 <|
    PetersenLocalChildren.push (x := s179) b179 <|
    PetersenLocalChildren.push (x := s181) b181 <|
    PetersenLocalChildren.push (x := s182) b182 <|
    PetersenLocalChildren.push (x := s183) b183 <|
    PetersenLocalChildren.push (x := s185) b185 <|
    PetersenLocalChildren.push (x := s186) b186 <|
    PetersenLocalChildren.push (x := s187) b187 <|
    PetersenLocalChildren.push (x := s188) b188 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.push (x := s192) b192 <|
    PetersenLocalChildren.nil
theorem b193 : Blocked tgt 7 s193 := by
  apply PetersenFastNode.node (nxt := #[s6,s194,s195,s95,s196,s63,s197,s143,s198,s116,s199,s200,s168,s201,s202,s203,s204,s205,s206,s209,s210,s211,s129,s214,s215,s216,s219,s220,s221]) (hints := [1783,0,1783,1263,1,2,1457,3,1457,2562,4,2562,1457,5,1457,2562,6,2562,1975,7,1975,480,8,480,1975,9,1975,480,10,480,736,0,1841,736,11,12,3393,13,3393,1248,14,1248,3393,15,3393,1248,16,1248,3767,17,3767,2272,18,2272,3767,19,3767,2272,20,2272,1457,1653,1457,2562,1783,2562,1457,1783,1457,2562,1653,2562,1783,1783,1975,480,21,480,1975,22,1975,480,1783,480,1841,2,1841,1783,1783,12,1775,23,24,743,743,3393,1248,1783,1248,1767,1783,3393,1248,743,1248,1783,1783,3767,2272,2693,2272,3767,2693,3767,2272,1783,2272,2302,2302,1845,2306,2562,480,2558,2562,1845,2302,2302,480,2562,2562,1841,2245,2757,25,1841,2757,1841,2562,2562,26,2562,2562,3458,1120,1457,1248,3458,1457,3458,2562,2562,1248,482,482,3377,514,2562,2272,2530,2562,3377,482,482,2272,480,480,27,1463,1975,1841,1967,1975,28,480,480,1841,480,480,1248,3202,1975,3458,1248,1975,1248,480,480,3458,480,480,2272,837,2885,3377,2272,2885,2272,480,480,3377,1248,2881,1248,817,1841,3653,1248,1841,1248,2881,2881,3653,2272,1841,2272,3255,2881,3767,2272,2881,2272,3759,1841,3767,1248,1248,2272,1410,3458,3767,2272,3458,2272,1248,1248,3767]) (by decide +kernel)
  change ∀ b ∈ [s6,s194,s195,s95,s196,s63,s197,s143,s198,s116,s199,s200,s168,s201,s202,s203,s204,s205,s206,s209,s210,s211,s129,s214,s215,s216,s219,s220,s221], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s194) b194 <|
    PetersenLocalChildren.push (x := s195) b195 <|
    PetersenLocalChildren.push (x := s95) b95 <|
    PetersenLocalChildren.push (x := s196) b196 <|
    PetersenLocalChildren.push (x := s63) b63 <|
    PetersenLocalChildren.push (x := s197) b197 <|
    PetersenLocalChildren.push (x := s143) b143 <|
    PetersenLocalChildren.push (x := s198) b198 <|
    PetersenLocalChildren.push (x := s116) b116 <|
    PetersenLocalChildren.push (x := s199) b199 <|
    PetersenLocalChildren.push (x := s200) b200 <|
    PetersenLocalChildren.push (x := s168) b168 <|
    PetersenLocalChildren.push (x := s201) b201 <|
    PetersenLocalChildren.push (x := s202) b202 <|
    PetersenLocalChildren.push (x := s203) b203 <|
    PetersenLocalChildren.push (x := s204) b204 <|
    PetersenLocalChildren.push (x := s205) b205 <|
    PetersenLocalChildren.push (x := s206) b206 <|
    PetersenLocalChildren.push (x := s209) b209 <|
    PetersenLocalChildren.push (x := s210) b210 <|
    PetersenLocalChildren.push (x := s211) b211 <|
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.push (x := s214) b214 <|
    PetersenLocalChildren.push (x := s215) b215 <|
    PetersenLocalChildren.push (x := s216) b216 <|
    PetersenLocalChildren.push (x := s219) b219 <|
    PetersenLocalChildren.push (x := s220) b220 <|
    PetersenLocalChildren.push (x := s221) b221 <|
    PetersenLocalChildren.nil
theorem b222 : Blocked tgt 7 s222 := by
  apply PetersenFastNode.node (nxt := #[s6,s178,s195,s93,s223,s226,s227,s61,s228,s231,s232,s141,s233,s246,s247,s114,s248,s249,s250,s170,s251,s252,s253,s266,s267,s268,s269,s270,s271,s272,s273,s276,s277,s278,s279,s282,s283,s166,s167,s284,s285,s286,s288,s289,s291,s292,s293]) (hints := [1801,0,1281,1801,1,2,2580,3,2580,4,5,6,2580,7,2580,8,9,10,498,11,498,12,13,14,498,15,498,16,17,18,754,0,1859,754,19,20,1266,21,1266,22,23,24,1266,25,1266,26,27,28,2290,29,2290,30,31,32,2290,33,2290,34,35,36,1411,1411,1475,2516,1281,2580,1475,1281,1475,1411,1411,2580,1993,1281,1993,434,1411,498,1993,1411,1993,1281,1281,498,1289,37,38,1859,2,1859,1281,1281,20,3411,39,3411,1266,1281,1266,1265,1281,3411,1265,40,1266,3785,1281,3785,2226,41,2290,3785,42,3785,1281,1281,2290,2320,2320,1863,2324,2580,498,2576,2580,1863,2320,2320,498,2580,2580,1859,2263,2775,43,1859,2775,1859,2580,2580,44,2580,2580,3476,1138,1475,1266,3476,1475,3476,2580,2580,1266,500,500,3395,532,2580,2290,2548,2580,3395,500,500,2290,498,498,45,1481,1993,1859,1985,1993,46,498,498,1859,498,498,1266,3220,1993,3476,1266,1993,1266,498,498,3476,498,498,2290,855,2903,3395,2290,2903,2290,498,498,3395,1266,2899,1266,835,1859,3671,1266,1859,1266,2899,2899,3671,2290,1859,2290,3273,2899,3785,2290,2899,2290,3777,1859,3785,1266,1266,2290,1428,3476,3785,2290,3476,2290,1266,1266,3785]) (by decide +kernel)
  change ∀ b ∈ [s6,s178,s195,s93,s223,s226,s227,s61,s228,s231,s232,s141,s233,s246,s247,s114,s248,s249,s250,s170,s251,s252,s253,s266,s267,s268,s269,s270,s271,s272,s273,s276,s277,s278,s279,s282,s283,s166,s167,s284,s285,s286,s288,s289,s291,s292,s293], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s178) b178 <|
    PetersenLocalChildren.push (x := s195) b195 <|
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.push (x := s223) b223 <|
    PetersenLocalChildren.push (x := s226) b226 <|
    PetersenLocalChildren.push (x := s227) b227 <|
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s228) b228 <|
    PetersenLocalChildren.push (x := s231) b231 <|
    PetersenLocalChildren.push (x := s232) b232 <|
    PetersenLocalChildren.push (x := s141) b141 <|
    PetersenLocalChildren.push (x := s233) b233 <|
    PetersenLocalChildren.push (x := s246) b246 <|
    PetersenLocalChildren.push (x := s247) b247 <|
    PetersenLocalChildren.push (x := s114) b114 <|
    PetersenLocalChildren.push (x := s248) b248 <|
    PetersenLocalChildren.push (x := s249) b249 <|
    PetersenLocalChildren.push (x := s250) b250 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s251) b251 <|
    PetersenLocalChildren.push (x := s252) b252 <|
    PetersenLocalChildren.push (x := s253) b253 <|
    PetersenLocalChildren.push (x := s266) b266 <|
    PetersenLocalChildren.push (x := s267) b267 <|
    PetersenLocalChildren.push (x := s268) b268 <|
    PetersenLocalChildren.push (x := s269) b269 <|
    PetersenLocalChildren.push (x := s270) b270 <|
    PetersenLocalChildren.push (x := s271) b271 <|
    PetersenLocalChildren.push (x := s272) b272 <|
    PetersenLocalChildren.push (x := s273) b273 <|
    PetersenLocalChildren.push (x := s276) b276 <|
    PetersenLocalChildren.push (x := s277) b277 <|
    PetersenLocalChildren.push (x := s278) b278 <|
    PetersenLocalChildren.push (x := s279) b279 <|
    PetersenLocalChildren.push (x := s282) b282 <|
    PetersenLocalChildren.push (x := s283) b283 <|
    PetersenLocalChildren.push (x := s166) b166 <|
    PetersenLocalChildren.push (x := s167) b167 <|
    PetersenLocalChildren.push (x := s284) b284 <|
    PetersenLocalChildren.push (x := s285) b285 <|
    PetersenLocalChildren.push (x := s286) b286 <|
    PetersenLocalChildren.push (x := s288) b288 <|
    PetersenLocalChildren.push (x := s289) b289 <|
    PetersenLocalChildren.push (x := s291) b291 <|
    PetersenLocalChildren.push (x := s292) b292 <|
    PetersenLocalChildren.push (x := s293) b293 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M189
