import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b856 : Blocked tgt 6 s856 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s856 6 _ le
  decide +kernel
theorem b857 : Blocked tgt 6 s857 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s857 6 _ le
  decide +kernel
theorem b858 : Blocked tgt 6 s858 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s858 6 _ le
  decide +kernel
theorem b859 : Blocked tgt 6 s859 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s859 6 _ le
  decide +kernel
theorem b860 : Blocked tgt 6 s860 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s860 6 _ le
  decide +kernel
theorem b861 : Blocked tgt 6 s861 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s861 6 _ le
  decide +kernel
theorem b862 : Blocked tgt 6 s862 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s862 6 _ le
  decide +kernel
theorem b863 : Blocked tgt 6 s863 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s863 6 _ le
  decide +kernel
theorem b864 : Blocked tgt 6 s864 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s864 6 _ le
  decide +kernel
theorem b865 : Blocked tgt 6 s865 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s865 6 _ le
  decide +kernel
theorem b866 : Blocked tgt 6 s866 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s866 6 _ le
  decide +kernel
theorem b867 : Blocked tgt 6 s867 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s867 6 _ le
  decide +kernel
theorem b877 : Blocked tgt 6 s877 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10964,9029,11092,10964,15060,1418,1418,10996,1418,9929,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1418,2772,9482,1418,9157,11124,9673,8645,9929,9673,9157,8649,9925,9157,9157,9044,10949,9157,901,965,9093,901,13513,9929,12485,9929,12997,9925,12489,9925,12997,10949,11336,10949,4741,12933,4805,4741,2834,9925,9921,9921,9929,10437,11465,9929,1673,1737,9865,1673,9925,10441,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b878 : Blocked tgt 6 s878 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s878 6 _ le
  decide +kernel
theorem b879 : Blocked tgt 6 s879 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s879 6 _ le
  decide +kernel
theorem b880 : Blocked tgt 6 s880 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s880 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
