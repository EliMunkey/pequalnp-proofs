import M111StartData
import M111StartL6B1
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_2 : NoAtMost (0x3300330033003300 :: inputs 6) tgt 6 := by
  change NoAtMost [0x3300330033003300,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s80,s0,s100] [195,779,196,844,197,779,836,844,391,1611,456,1612,197,1611,840,1612,715,779,716,844,717,779,844,844,391,1611,456,1612,717,1611,1352,1612,1107,1627,196,844,1237,1627,836,844,1367,1627,456,456,1237,1627,840,3221,1627,1627,716,844,1757,1627,844,844,1367,1627,456,456,1757,1627,3741,3741,2211,2859,2276,2924,197,2859,2916,2924,2471,3691,2536,3692,197,3691,2920,3692,2731,2859,2796,2924,717,2859,2924,2924,2471,3691,2536,3692,717,3691,3432,3692,3187,3707,2276,2924,1237,3707,2916,2924,3447,3707,2536,2536,1237,3707,2920,0,3707,3707,2796,2924,1757,3707,2924,2924,3447,3707,2536,2536,1757,3707,1,2] (by decide +kernel)
  change ∀ b ∈ [s80,s0,s100], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s100) b100 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_2
end PetersenSmallStarts.M111
