import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_1 : NoAtMost (0xcccccccc :: inputs 6) tgt 7 := by
  change NoAtMost [0xcccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1020] [194,196,195,388,196,196,835,388,390,196,455,1668,196,196,839,1668,714,716,715,908,716,716,843,908,390,716,455,1676,716,716,1351,1676,1106,1236,195,1428,1236,1236,835,1428,1366,1236,455,1684,1236,1236,839,1684,714,716,715,908,716,716,843,908,1366,716,455,2375,716,716,2375,2375,2146,196,195,388,2276,196,835,388,2406,196,455,1668,2276,196,839,1668,2666,716,715,908,2796,716,843,908,2406,716,455,1676,2796,716,1351,1676,3186,1236,195,1428,3316,1236,835,1428,3446,1236,455,1684,3316,1236,839,1684,2666,716,715,908,2796,716,843,908,3446,716,455,3510,2796,716,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1020], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1020) b1020 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_1
end PetersenSmallStarts.M63
