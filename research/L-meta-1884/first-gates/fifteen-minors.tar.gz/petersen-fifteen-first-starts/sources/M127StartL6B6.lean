import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b168 : Blocked tgt 6 s168 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s168 6 _ le
  decide +kernel
theorem b169 : Blocked tgt 6 s169 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s169 6 _ le
  decide +kernel
theorem b170 : Blocked tgt 6 s170 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s170 6 _ le
  decide +kernel
theorem b171 : Blocked tgt 6 s171 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s171 6 _ le
  decide +kernel
theorem b172 : Blocked tgt 6 s172 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s172 6 _ le
  decide +kernel
theorem b173 : Blocked tgt 6 s173 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s173 6 _ le
  decide +kernel
theorem b174 : Blocked tgt 6 s174 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,2708,5546,9093,901,965,901,9865,1673,1737,1673,9861,1669,1733,1669,11562,3370,10514,3370,12933,4741,4805,4741,773,773,5546,901,5546,1673,5930,5546,2450,4522,3346,2450,3370,2450,3370,3498,1418,1450,5514,1418,1417,389,1673,1417,901,393,1669,901,901,3370,11028,901,901,11028,4741,901,2834,1669,1665,1665,1673,2834,3370,1673,1673,4229,5257,1673,1669,3346,3346,1669,1669,4233,4741,1669,2693,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b175 : Blocked tgt 6 s175 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s175 6 _ le
  decide +kernel
theorem b178 : Blocked tgt 6 s178 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s178 6 _ le
  decide +kernel
theorem b179 : Blocked tgt 6 s179 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s179 6 _ le
  decide +kernel
theorem b182 : Blocked tgt 6 s182 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s182 6 _ le
  decide +kernel
theorem b183 : Blocked tgt 6 s183 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s183 6 _ le
  decide +kernel
theorem b186 : Blocked tgt 6 s186 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s186 6 _ le
  decide +kernel
theorem b187 : Blocked tgt 6 s187 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s187 6 _ le
  decide +kernel
theorem b193 : Blocked tgt 6 s193 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s193 6 _ le
  decide +kernel
theorem b194 : Blocked tgt 6 s194 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s194 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
