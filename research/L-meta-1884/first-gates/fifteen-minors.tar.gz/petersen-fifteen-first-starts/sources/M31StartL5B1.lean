import M31StartData
import M31StartL4B0
import M31StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b21 : Blocked tgt 5 s21 := by
  apply PetersenFastNode.node (nxt := #[s22,s23,s24,s25]) (hints := [201,201,364,233,366,397,462,366,630,110,854,630,366,696,366,118,846,366,365,105,429,365,233,109,425,233,233,728,233,782,681,233,726,425,421,421,0,429,429,1,429,553,813,429,425,920,425,557,681,425,2,681,3,681]) (by decide +kernel)
  change ∀ b ∈ [s22,s23,s24,s25], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s22) b22 <|
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.nil
theorem b26 : Blocked tgt 5 s26 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [362,626,362,626,361,229,361,229,425,722,425,722,421,421,809,677,809,677,197,197,626,229,626,393,722,626,626,362,362,626,98,114,610,98,97,101,225,97,229,361,361,229,229,778,677,229,722,425,425,722,545,549,545,673,677,809,677,809]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b27 : Blocked tgt 5 s27 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s27 5 _ le
  decide +kernel
theorem b28 : Blocked tgt 5 s28 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s28 5 _ le
  decide +kernel
theorem b29 : Blocked tgt 5 s29 := by
  apply PetersenFastNode.node (nxt := #[s30]) (hints := [693,198,725,693,363,426,459,363,627,107,851,627,363,115,843,363,363,0,362,102,426,362,230,106,422,230,230,213,678,230,230,197,723,422,418,418,426,550,810,426,393,426,426,393,422,554,678,422,389,422,422,389,678,777]) (by decide +kernel)
  change ∀ b ∈ [s30], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.nil
theorem b31 : Blocked tgt 5 s31 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [626,362,626,362,724,229,724,229,722,425,722,425,850,421,850,421,677,677,197,197,362,229,362,425,458,362,98,106,354,98,362,626,626,362,361,101,425,361,229,105,421,229,229,724,708,229,194,421,417,417,425,722,722,425,421,850,850,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b32 : Blocked tgt 5 s32 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s32 5 _ le
  decide +kernel
theorem b34 : Blocked tgt 5 s34 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s34 5 _ le
  decide +kernel
theorem b35 : Blocked tgt 5 s35 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s35 5 _ le
  decide +kernel
theorem b36 : Blocked tgt 5 s36 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [197,362,229,362,692,362,425,458,362,626,106,850,626,362,114,842,362,229,724,361,101,425,361,229,105,421,229,229,842,677,229,392,425,392,425,916,421,916,421,776,677,776,677,722,421,417,417,425,549,809,425,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b37 : Blocked tgt 5 s37 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s37 5 _ le
  decide +kernel
theorem b38 : Blocked tgt 5 s38 := by
  apply PetersenFastNode.node (nxt := #[s17]) (hints := [693,198,725,693,363,394,693,363,363,693,693,363,627,107,851,627,363,115,843,363,426,230,426,490,362,230,230,0,230,787,422,230,230,213,678,230,426,459,851,422,418,418,426,550,810,426,851,422,851,422,843,678,843,678,422,554,678,422]) (by decide +kernel)
  change ∀ b ∈ [s17], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
theorem b39 : Blocked tgt 5 s39 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s39 5 _ le
  decide +kernel
theorem b40 : Blocked tgt 5 s40 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s40 5 _ le
  decide +kernel
theorem b41 : Blocked tgt 5 s41 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s41 5 _ le
  decide +kernel
theorem b42 : Blocked tgt 5 s42 := by
  apply PetersenFastNode.node (nxt := #[s43,s44]) (hints := [726,363,726,758,364,395,460,364,628,364,364,628,628,364,364,628,364,116,844,364,363,396,427,363,423,363,423,487,231,231,363,726,679,214,679,363,724,423,419,419,724,427,427,724,427,551,811,427,423,852,423,555,679,423,0,679,1,679]) (by decide +kernel)
  change ∀ b ∈ [s43,s44], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M31
