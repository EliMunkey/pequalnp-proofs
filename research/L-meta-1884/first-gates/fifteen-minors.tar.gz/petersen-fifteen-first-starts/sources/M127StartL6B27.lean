import M127StartData
import M127StartPins0
import M127StartL5B1
import M127StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b920 : Blocked tgt 6 s920 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s920 6 _ le
  decide +kernel
theorem b921 : Blocked tgt 6 s921 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s921 6 _ le
  decide +kernel
theorem b922 : Blocked tgt 6 s922 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s922 6 _ le
  decide +kernel
theorem b923 : Blocked tgt 6 s923 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s923 6 _ le
  decide +kernel
theorem b924 : Blocked tgt 6 s924 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s924 6 _ le
  decide +kernel
theorem b925 : Blocked tgt 6 s925 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s925 6 _ le
  decide +kernel
theorem b926 : Blocked tgt 6 s926 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s926 6 _ le
  decide +kernel
theorem b927 : Blocked tgt 6 s927 := by
  apply PetersenFastNode.node (nxt := #[s928]) (hints := [4742,0,4742,9483,9483,5515,2709,5515,902,902,1674,1803,1674,1803,1670,3347,1670,3347,9483,3339,8467,3339,1419,1419,4742,9094,11029,4742,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,2709,5515,5515,9094,1803,1674,1803,5515,2451,4491,3347,2451,3339,2451,3339,3467,1674,1803,1674,1803,1670,3347,1670,3347,9094,3339,11013,3339,2835,779,3347,2835,1803,787,3339,1803,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s928], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s928) b928 <|
    PetersenLocalChildren.nil
theorem b929 : Blocked tgt 6 s929 := by
  apply PetersenFastNode.node (nxt := #[s930,s932]) (hints := [1420,1420,10951,9159,9030,9159,13515,10951,10439,13515,10951,9927,12491,9927,11467,10951,10951,13515,2695,10887,2759,2695,9030,9159,9030,9159,5516,10438,788,5516,2452,9927,3348,9927,3340,2452,3340,3468,5516,2758,9484,5516,9675,9159,9159,9675,9159,8651,9927,9159,9675,9159,9159,9675,903,967,9095,903,788,9927,1812,9927,9931,9931,9484,0,9484,788,1,9927,9927,3332,1671,1735,9863,1671,3340,8468,9484,3340]) (by decide +kernel)
  change ∀ b ∈ [s930,s932], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s930) b930 <|
    PetersenLocalChildren.push (x := s932) b932 <|
    PetersenLocalChildren.nil
theorem b933 : Blocked tgt 6 s933 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s933 6 _ le
  decide +kernel
theorem b934 : Blocked tgt 6 s934 := by
  apply PetersenFastNode.node (nxt := #[s930]) (hints := [1419,1419,4742,902,2837,902,5834,1738,4742,1738,4742,1670,12490,1670,2694,2694,5258,4742,4742,5258,2709,902,2837,902,5515,1738,1609,1738,2451,1670,3347,1670,3339,2451,3339,3467,5515,2709,9483,5515,1738,902,1738,1994,902,8650,1670,902,902,789,2821,902,1418,902,902,1418,3347,1670,1730,1670,1738,0,3339,1738,1674,1674,1670,3339,3331,1670,3347,1670,1670,3347,3339,8467,9483,3339]) (by decide +kernel)
  change ∀ b ∈ [s930], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s930) b930 <|
    PetersenLocalChildren.nil
theorem b935 : Blocked tgt 6 s935 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s935 6 _ le
  decide +kernel
theorem b936 : Blocked tgt 6 s936 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(false,(0,false),(4,true))] s936 6 _ le
  decide +kernel
theorem b937 : Blocked tgt 6 s937 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10949,13513,11465,10949,1418,1418,13513,9673,9544,9673,13513,9929,1802,9929,10949,13513,13513,10949,5257,13449,5321,5257,3338,3466,2434,3338,9157,9673,9157,9673,3338,9929,770,9929,9925,9925,3338,9482,8450,3338,9544,9673,9544,9673,1802,9929,1802,9929,2434,5514,5514,2434,5514,5320,9482,5514,9673,8645,9929,9673,9157,9673,9673,9157,1417,1481,9609,1417,770,9929,9929,770,1673,1737,9865,1673,3330,9482,8450,9482]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b943 : Blocked tgt 6 s943 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s943 6 _ le
  decide +kernel
theorem b944 : Blocked tgt 6 s944 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s944 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
