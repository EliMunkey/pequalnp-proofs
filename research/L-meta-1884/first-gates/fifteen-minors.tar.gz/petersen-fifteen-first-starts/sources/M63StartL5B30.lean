import M63StartData
import M63StartPins0
import M63StartL4B2
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1135 : Blocked tgt 5 s1135 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1135 5 _ le
  decide +kernel
theorem b1136 : Blocked tgt 5 s1136 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1136 5 _ le
  decide +kernel
theorem b1137 : Blocked tgt 5 s1137 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(1,false),(0,true))] s1137 5 _ le
  decide +kernel
theorem b1138 : Blocked tgt 5 s1138 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1138 5 _ le
  decide +kernel
theorem b1139 : Blocked tgt 5 s1139 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(1,false),(0,true))] s1139 5 _ le
  decide +kernel
theorem b1143 : Blocked tgt 5 s1143 := by
  apply PetersenFastNode.node (nxt := #[s1144,s1145,s1146]) (hints := [196,0,772,196,2155,2157,2155,2283,3191,196,3191,3319,196,2487,1092,196,196,1463,2116,196,2285,2989,3765,3895,3757,1,3757,772,772,2,2116,772,3509,2285,3317,3317,2285,2485,3309,2285,205,237,2253,205,2151,3757,3749,3749,1685,1717,3733,1685,1677,1709,3725,1677]) (by decide +kernel)
  change ∀ b ∈ [s1144,s1145,s1146], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1144) b1144 <|
    PetersenLocalChildren.push (x := s1145) b1145 <|
    PetersenLocalChildren.push (x := s1146) b1146 <|
    PetersenLocalChildren.nil
theorem b1147 : Blocked tgt 5 s1147 := by
  apply PetersenFastNode.node (nxt := #[s1144,s221]) (hints := [2796,2796,779,715,3318,715,3190,0,3702,3190,2150,1611,3174,1611,1110,2635,3158,2635,1,715,2858,715,3508,2476,3764,3508,2860,1611,3756,1611,780,2635,2828,2635,195,203,707,195,715,2486,1611,715,715,1462,2635,715,1091,1099,1091,1603,2115,2123,2115,2627,1611,1708,2635,1611]) (by decide +kernel)
  change ∀ b ∈ [s1144,s221], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1144) b1144 <|
    PetersenLocalChildren.push (x := s221) b221 <|
    PetersenLocalChildren.nil
theorem b1148 : Blocked tgt 5 s1148 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1148 5 _ le
  decide +kernel
theorem b1149 : Blocked tgt 5 s1149 := by
  apply PetersenFastNode.node (nxt := #[s1145,s1150]) (hints := [3190,715,3318,715,2796,2796,3764,0,3764,2934,3756,779,3756,843,1110,2635,3158,2635,1,715,715,3506,195,203,707,195,715,2486,843,715,715,1462,2635,715,3508,2476,2996,2996,3756,843,2988,843,1428,2635,3476,2635,1091,843,835,835,2115,2123,2115,2627,843,1708,2635,843]) (by decide +kernel)
  change ∀ b ∈ [s1145,s1150], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1145) b1145 <|
    PetersenLocalChildren.push (x := s1150) b1150 <|
    PetersenLocalChildren.nil
theorem b1151 : Blocked tgt 5 s1151 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1151 5 _ le
  decide +kernel
theorem b1153 : Blocked tgt 5 s1153 := by
  apply PetersenFastNode.node (nxt := #[s1144,s1154]) (hints := [2284,0,2540,2284,775,455,3510,455,3446,3446,2284,1351,3308,1351,204,2375,2252,2375,195,199,195,451,3508,2476,3764,3508,1091,1095,1091,1347,2115,2119,2115,2371,3510,455,455,3510,455,2486,1351,455,455,1462,2375,455,1,1351,3748,1351,1684,2375,3732,2375,1351,1708,2375,1351]) (by decide +kernel)
  change ∀ b ∈ [s1144,s1154], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1144) b1144 <|
    PetersenLocalChildren.push (x := s1154) b1154 <|
    PetersenLocalChildren.nil
theorem b1155 : Blocked tgt 5 s1155 := by
  apply PetersenFastNode.node (nxt := #[s1145,s1156]) (hints := [3510,455,3510,455,2284,0,2540,2284,3316,3316,2284,775,3308,2284,204,236,2252,204,195,199,451,195,2870,455,455,2998,455,2486,839,455,455,1462,2375,455,3508,2476,2996,2996,1091,839,835,835,2115,2119,2115,2371,1,839,3748,839,1684,2375,3732,2375,839,1708,2375,839]) (by decide +kernel)
  change ∀ b ∈ [s1145,s1156], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1145) b1145 <|
    PetersenLocalChildren.push (x := s1156) b1156 <|
    PetersenLocalChildren.nil
theorem b1157 : Blocked tgt 5 s1157 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1157 5 _ le
  decide +kernel
theorem b1158 : Blocked tgt 5 s1158 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1158 5 _ le
  decide +kernel
theorem b1162 : Blocked tgt 5 s1162 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1162 5 _ le
  decide +kernel
theorem b1163 : Blocked tgt 5 s1163 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1163 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
