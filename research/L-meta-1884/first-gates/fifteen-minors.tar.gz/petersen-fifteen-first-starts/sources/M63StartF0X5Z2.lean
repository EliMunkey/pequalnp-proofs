import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_2 : NoAtMost (0x5555555500000000 :: inputs 6) tgt 7 := by
  change NoAtMost [0x5555555500000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s639] [194,2466,195,2466,196,2468,835,2468,390,2470,455,2470,196,3748,839,3748,714,2858,715,2858,716,2988,843,2988,390,2470,455,2470,716,3756,1351,3756,1106,3506,195,3506,1236,3508,835,3508,1366,3510,455,3510,1236,3764,839,3764,714,2858,715,2858,716,2988,843,2988,1366,3510,455,3510,716,716,2375,2375,2146,2466,195,2466,2276,2468,835,2468,2406,2470,455,2470,2276,3748,839,3748,2666,2858,715,2858,2796,2988,843,2988,2406,2470,455,2470,2796,3756,1351,3756,3186,3506,195,3506,3316,3508,835,3508,3446,3510,455,3510,3316,3764,839,3764,2666,2858,715,2858,2796,2988,843,2988,3446,3510,455,3510,2796,716,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s639], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s639) b639 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_2
end PetersenSmallStarts.M63
