import M47StartData
import M47StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 4 s0 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s0 4 _ le
  decide +kernel
theorem b1 : Blocked tgt 4 s1 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s1 4 _ le
  decide +kernel
theorem b2 : Blocked tgt 4 s2 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s2 4 _ le
  decide +kernel
theorem b3 : Blocked tgt 4 s3 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s3 4 _ le
  decide +kernel
theorem b4 : Blocked tgt 4 s4 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s4 4 _ le
  decide +kernel
theorem b5 : Blocked tgt 4 s5 := by
  intro k le c
  apply rejects_sound r5 i2 0 tgt small5 hot5 [] s5 4 _ le
  decide +kernel
theorem b6 : Blocked tgt 4 s6 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s6 4 _ le
  decide +kernel
theorem b7 : Blocked tgt 4 s7 := by
  intro k le c
  apply rejects_sound r3 i2 0 tgt small3 hot3 [] s7 4 _ le
  decide +kernel
theorem b8 : Blocked tgt 4 s8 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s8 4 _ le
  decide +kernel
theorem b9 : Blocked tgt 4 s9 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s9 4 _ le
  decide +kernel
theorem b10 : Blocked tgt 4 s10 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s10 4 _ le
  decide +kernel
theorem b11 : Blocked tgt 4 s11 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s11 4 _ le
  decide +kernel
theorem b12 : Blocked tgt 4 s12 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s12 4 _ le
  decide +kernel
theorem b13 : Blocked tgt 4 s13 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [362,362,677,229,196,229,809,425,549,425,677,421,553,421,196,229,196,229,458,425,458,425,610,421,866,421,361,101,425,361,229,105,421,229,194,421,417,417]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b14 : Blocked tgt 4 s14 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s14 4 _ le
  decide +kernel
theorem b15 : Blocked tgt 4 s15 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s15 4 _ le
  decide +kernel
end PetersenSmallStarts.M47
