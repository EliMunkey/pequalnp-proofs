import M119StartData
import M119StartL5B0
import M119StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_3 : NoAtMost (0xf000f000f000f000 :: inputs 6) tgt 5 := by
  change NoAtMost [0xf000f000f000f000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s19] [194,846,195,195,196,196,579,579,390,846,455,455,196,196,839,1351,586,846,195,195,716,716,1091,1091,846,846,455,455,716,716,1351,1351,1106,1886,195,195,1236,1236,579,579,1366,1886,455,455,1236,1236,839,579,1626,1886,195,195,1756,1756,1948,3740,1886,1886,455,455,1756,1756,3740,3740,2210,2926,2275,2275,196,196,2659,2659,2470,2926,2535,2535,196,196,2919,3431,2666,2926,2275,2275,716,716,3171,3171,2926,2926,2535,2535,716,716,3431,3431,3186,3966,2275,2275,1236,1236,2659,2659,3446,3966,2535,2535,1236,1236,2919,2659,3706,3966,2275,2275,1756,1756,1948,1428,3966,3966,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s19], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_3
end PetersenSmallStarts.M119
