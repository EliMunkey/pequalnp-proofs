import M31StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 32) : Fin 32 := (#[0,2,1,3,16,18,17,19,8,10,9,11,24,26,25,27,4,6,5,7,20,22,21,23,12,14,13,15,28,30,29,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover0 : i5.all (fun q => i5.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
private def a1 (x : Fin 32) : Fin 32 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover1 : i5.all (fun q => i5.contains (PetersenPackedPin.project a1 q)) = true := by decide +kernel
private theorem same1 : PetersenPackedPin.project a1 tgt=tgt := by decide +kernel
private def a2 (x : Fin 32) : Fin 32 := (#[0,1,16,17,8,9,24,25,4,5,20,21,12,13,28,29,2,3,18,19,10,11,26,27,6,7,22,23,14,15,30,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover2 : i5.all (fun q => i5.contains (PetersenPackedPin.project a2 q)) = true := by decide +kernel
private theorem same2 : PetersenPackedPin.project a2 tgt=tgt := by decide +kernel
private def a3 (x : Fin 32) : Fin 32 := (#[0,8,16,24,1,9,17,25,2,10,18,26,3,11,19,27,4,12,20,28,5,13,21,29,6,14,22,30,7,15,23,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover3 : i5.all (fun q => i5.contains (PetersenPackedPin.project a3 q)) = true := by decide +kernel
private theorem same3 : PetersenPackedPin.project a3 tgt=tgt := by decide +kernel
private def a4 (x : Fin 32) : Fin 32 := (#[0,16,1,17,2,18,3,19,4,20,5,21,6,22,7,23,8,24,9,25,10,26,11,27,12,28,13,29,14,30,15,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover4 : i5.all (fun q => i5.contains (PetersenPackedPin.project a4 q)) = true := by decide +kernel
private theorem same4 : PetersenPackedPin.project a4 tgt=tgt := by decide +kernel
private def a5 (x : Fin 32) : Fin 32 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover5 : i5.all (fun q => i5.contains (PetersenPackedPin.project a5 q)) = true := by decide +kernel
private theorem same5 : PetersenPackedPin.project a5 tgt=tgt := by decide +kernel
private def a6 (x : Fin 32) : Fin 32 := (#[0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15,16,24,20,28,18,26,22,30,17,25,21,29,19,27,23,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover6 : i5.all (fun q => i5.contains (PetersenPackedPin.project a6 q)) = true := by decide +kernel
private theorem same6 : PetersenPackedPin.project a6 tgt=tgt := by decide +kernel
private def a7 (x : Fin 32) : Fin 32 := (#[0,4,8,12,16,20,24,28,1,5,9,13,17,21,25,29,2,6,10,14,18,22,26,30,3,7,11,15,19,23,27,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover7 : i5.all (fun q => i5.contains (PetersenPackedPin.project a7 q)) = true := by decide +kernel
private theorem same7 : PetersenPackedPin.project a7 tgt=tgt := by decide +kernel
private def a8 (x : Fin 32) : Fin 32 := (#[0,16,8,24,4,20,12,28,2,18,10,26,6,22,14,30,1,17,9,25,5,21,13,29,3,19,11,27,7,23,15,31] : Array (Fin 32))[x.val]?.getD 0
private theorem cover8 : i5.all (fun q => i5.contains (PetersenPackedPin.project a8 q)) = true := by decide +kernel
private theorem same8 : PetersenPackedPin.project a8 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x44444444 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x44444444) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_2_2 : NoAtMost (0x50505050 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0x50505050) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_3_1 : NoAtMost (0xaa00aa :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaa00aa) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_3_2 : NoAtMost (0x55005500 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0x55005500) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_3_3 : NoAtMost (0xaa00aa00 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaa00aa00) (a:=0xa0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_0_4_0 : NoAtMost (0xffffaaaa :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffaaaa) (a:=0xeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_0_4_1 : NoAtMost (0xaaaa :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaaaa) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_4_2 : NoAtMost (0x55550000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0x55550000) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfc :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xfcfcfcfc) (a:=0xeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xc0c0c0c) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_2_2 : NoAtMost (0x30303030 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0x30303030) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_3_1 : NoAtMost (0xcc00cc :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xcc00cc) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_3_2 : NoAtMost (0x33003300 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0x33003300) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_3_3 : NoAtMost (0xcc00cc00 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xcc00cc00) (a:=0xa0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_4_1 : NoAtMost (0xcccc :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_4_2 : NoAtMost (0x33330000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0x33330000) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_4_3 : NoAtMost (0xcccc0000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000) (a:=0xa0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_2_3_0 : NoAtMost (0xfff0fff0 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xfff0fff0) (a:=0xeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_2_3_1 : NoAtMost (0xf000f0 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a7 cover7 same7 (g:=0xf000f0) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_3_2 : NoAtMost (0xf000f00 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xf000f00) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_2_4_1 : NoAtMost (0xf0f0 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a7 cover7 same7 (g:=0xf0f0) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_2_4_2 : NoAtMost (0xf0f0000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a8 cover8 same8 (g:=0xf0f0000) (a:=0xa0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_2_4_3 : NoAtMost (0xf0f00000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a7 cover7 same7 (g:=0xf0f00000) (a:=0xa0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_3_4_0 : NoAtMost (0xffffff00 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xffffff00) (a:=0xeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_3_4_1 : NoAtMost (0xff00 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xff00) (a:=0x22222222) (by decide +kernel) gate_0_1_1
theorem labeled_3_4_2 : NoAtMost (0xff0000 :: inputs 5) tgt 6 :=
  PetersenSmallStarts.relabel_aux a8 cover8 same8 (g:=0xff0000) (a:=0x22222222) (by decide +kernel) gate_0_1_1
def forbidden : List (BitVec 32) := [0xeeeeeeee,0x22222222,0x44444444,0xa0a0a0a,0x50505050,0xa0a0a0a0,0xaa00aa,0x55005500,0xaa00aa00,0xffffaaaa,0xaaaa,0x55550000,0xfcfcfcfc,0xc0c0c0c,0x30303030,0xcc00cc,0x33003300,0xcc00cc00,0xcccc,0x33330000,0xcccc0000,0xfff0fff0,0xf000f0,0xf000f00,0xf0f0,0xf0f0000,0xf0f00000,0xffffff00,0xff00,0xff0000]
theorem all_forbidden (g : BitVec 32) (h : g∈forbidden) : NoAtMost (g::inputs 5) tgt 6 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 5) tgt 6 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x22222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x44444444) labeled_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xa0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x50505050) labeled_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xa0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xaa00aa) labeled_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x55005500) labeled_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xaa00aa00) labeled_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xffffaaaa) labeled_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xaaaa) labeled_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x55550000) labeled_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xc0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x30303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xcc00cc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x33003300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xcc00cc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xcccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0x33330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xcccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xfff0fff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xf000f0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xf000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xf0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xf0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xf0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xffffff00) labeled_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xff00) labeled_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 5) tgt 6) (x:=0xff0000) labeled_3_4_2 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M31
