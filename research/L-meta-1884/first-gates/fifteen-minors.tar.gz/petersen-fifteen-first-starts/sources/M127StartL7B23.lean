import M127StartData
import M127StartPins0
import M127StartL6B23
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b785 : Blocked tgt 7 s785 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s785 7 _ le
  decide +kernel
theorem b786 : Blocked tgt 7 s786 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s786 7 _ le
  decide +kernel
theorem b787 : Blocked tgt 7 s787 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s787 7 _ le
  decide +kernel
theorem b788 : Blocked tgt 7 s788 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s788 7 _ le
  decide +kernel
theorem b789 : Blocked tgt 7 s789 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s789 7 _ le
  decide +kernel
theorem b790 : Blocked tgt 7 s790 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s790 7 _ le
  decide +kernel
theorem b791 : Blocked tgt 7 s791 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s791 7 _ le
  decide +kernel
theorem b792 : Blocked tgt 7 s792 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s792 7 _ le
  decide +kernel
theorem b793 : Blocked tgt 7 s793 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s793 7 _ le
  decide +kernel
theorem b794 : Blocked tgt 7 s794 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s794 7 _ le
  decide +kernel
theorem b795 : Blocked tgt 7 s795 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s795 7 _ le
  decide +kernel
theorem b796 : Blocked tgt 7 s796 := by
  apply PetersenFastNode.node (nxt := #[s797,s778]) (hints := [13612,0,1,13612,13612,6580,6838,13612,1419,1419,1675,5932,1675,5932,14644,7476,12588,7476,3211,7468,3211,7468,5259,13580,5259,9484,5548,5548,9095,9611,9095,9611,5932,1675,5932,1675,7476,1671,7468,3211,7468,3211,4743,5259,4743,5259,6838,6580,6580,9611,5932,1675,5932,6580,4524,7476,6580,7468,4532,7468,4516,2452,2484,6548,2452,1675,5932,1675,5932,9095,7476,9611,7476,3211,7468,3211,7468,5259,11062,5259,9611,6964,4908,7476,6964,5932,4916,7468,5932,1804,1836,5900,1804,2695,7468,7460,7460,3348,3380,7444,3348,3340,3372,7436,3340]) (by decide +kernel)
  change ∀ b ∈ [s797,s778], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s797) b797 <|
    PetersenLocalChildren.push (x := s778) b778 <|
    PetersenLocalChildren.nil
theorem b798 : Blocked tgt 7 s798 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s798 7 _ le
  decide +kernel
theorem b799 : Blocked tgt 7 s799 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s799 7 _ le
  decide +kernel
theorem b800 : Blocked tgt 7 s800 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s800 7 _ le
  decide +kernel
theorem b801 : Blocked tgt 7 s801 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s801 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
