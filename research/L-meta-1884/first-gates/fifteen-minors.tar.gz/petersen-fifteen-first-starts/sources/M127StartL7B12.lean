import M127StartData
import M127StartPins1
import M127StartPins0
import M127StartL6B17
import M127StartL6B15
import M127StartL6B16
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b502 : Blocked tgt 7 s502 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s502 7 _ le
  decide +kernel
theorem b503 : Blocked tgt 7 s503 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s503 7 _ le
  decide +kernel
theorem b504 : Blocked tgt 7 s504 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s504 7 _ le
  decide +kernel
theorem b505 : Blocked tgt 7 s505 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s505 7 _ le
  decide +kernel
theorem b506 : Blocked tgt 7 s506 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s506 7 _ le
  decide +kernel
theorem b507 : Blocked tgt 7 s507 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s507 7 _ le
  decide +kernel
theorem b508 : Blocked tgt 7 s508 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s508 7 _ le
  decide +kernel
theorem b509 : Blocked tgt 7 s509 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s509 7 _ le
  decide +kernel
theorem b510 : Blocked tgt 7 s510 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s510 7 _ le
  decide +kernel
theorem b511 : Blocked tgt 7 s511 := by
  apply PetersenFastNode.node (nxt := #[s512,s489,s513,s444,s464]) (hints := [13615,0,1,13615,13615,2,6841,13615,1422,1422,13615,5935,5677,5935,1674,7479,1674,7479,3214,7471,3214,7471,5262,13583,5262,9487,5551,5551,9098,9614,9098,9614,5935,1678,7479,3,7479,4,7471,3214,7471,3214,4746,5262,4746,5262,6841,9614,15161,9614,5935,6841,6063,7479,1546,7479,6841,7471,3214,7471,3214,2713,5262,6809,5262,9614,5935,9098,5935,8582,7479,9606,7479,3214,7471,3214,7471,5262,11065,5262,9614,6967,4911,7479,6967,5935,4919,7471,5935,1807,1839,5903,1807,2182,7471,7463,7463,3351,3383,7447,3351,3343,3375,7439,3343]) (by decide +kernel)
  change ∀ b ∈ [s512,s489,s513,s444,s464], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s512) b512 <|
    PetersenLocalChildren.push (x := s489) b489 <|
    PetersenLocalChildren.push (x := s513) b513 <|
    PetersenLocalChildren.push (x := s444) b444 <|
    PetersenLocalChildren.push (x := s464) b464 <|
    PetersenLocalChildren.nil
theorem b514 : Blocked tgt 7 s514 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s514 7 _ le
  decide +kernel
theorem b515 : Blocked tgt 7 s515 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s515 7 _ le
  decide +kernel
theorem b516 : Blocked tgt 7 s516 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s516 7 _ le
  decide +kernel
theorem b517 : Blocked tgt 7 s517 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s517 7 _ le
  decide +kernel
theorem b521 : Blocked tgt 7 s521 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s521 7 _ le
  decide +kernel
theorem b522 : Blocked tgt 7 s522 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s522 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
