import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b192 : Blocked tgt 5 s192 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s192 5 _ le
  decide +kernel
theorem b195 : Blocked tgt 5 s195 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s195 5 _ le
  decide +kernel
theorem b196 : Blocked tgt 5 s196 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s196 5 _ le
  decide +kernel
theorem b197 : Blocked tgt 5 s197 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s197 5 _ le
  decide +kernel
theorem b198 : Blocked tgt 5 s198 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s198 5 _ le
  decide +kernel
theorem b199 : Blocked tgt 5 s199 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s199 5 _ le
  decide +kernel
theorem b200 : Blocked tgt 5 s200 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s200 5 _ le
  decide +kernel
theorem b201 : Blocked tgt 5 s201 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s201 5 _ le
  decide +kernel
theorem b207 : Blocked tgt 5 s207 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s207 5 _ le
  decide +kernel
theorem b208 : Blocked tgt 5 s208 := by
  apply PetersenFastNode.node (nxt := #[s209]) (hints := [715,2763,1429,1429,715,907,777,715,195,1683,203,1683,715,1675,211,715,1365,0,1493,1365,907,1109,907,2633,1683,2121,1683,1365,1675,1365,1675,1349,713,907,777,907,1813,1683,1813,1683,453,1675,1545,1675,1427,395,1683,1427,907,403,1675,907,773,1675,1667,1667]) (by decide +kernel)
  change ∀ b ∈ [s209], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s209) b209 <|
    PetersenLocalChildren.nil
theorem b214 : Blocked tgt 5 s214 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s214 5 _ le
  decide +kernel
theorem b215 : Blocked tgt 5 s215 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s215 5 _ le
  decide +kernel
theorem b216 : Blocked tgt 5 s216 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s216 5 _ le
  decide +kernel
theorem b217 : Blocked tgt 5 s217 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s217 5 _ le
  decide +kernel
theorem b218 : Blocked tgt 5 s218 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s218 5 _ le
  decide +kernel
theorem b219 : Blocked tgt 5 s219 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s219 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
