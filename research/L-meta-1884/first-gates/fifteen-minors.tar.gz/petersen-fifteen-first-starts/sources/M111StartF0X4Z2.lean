import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_2 : NoAtMost (0x5555000055550000 :: inputs 6) tgt 6 := by
  change NoAtMost [0x5555000055550000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s58] [194,1426,195,1426,196,1428,835,1428,390,1430,455,1430,196,3220,839,3220,714,1818,715,1818,716,1948,843,1948,390,1430,455,1430,716,3740,1351,3740,1106,1426,195,1426,1236,1428,835,1428,1366,1430,455,1430,1236,3220,839,3220,1626,1818,715,1818,1756,1948,843,1948,1366,1430,455,1430,1756,3740,3740,3740,2210,3250,2275,3250,196,1428,2915,1428,2470,3510,2535,3510,196,3894,2919,3894,2730,3770,2795,3770,716,1948,2923,1948,2470,3510,2535,3510,716,716,3431,3431,3186,3250,2275,3250,1236,1428,2915,1428,3446,3510,2535,3510,1236,3894,2919,3894,3706,3770,2795,3770,1756,1948,2923,1948,3446,3510,2535,3510,1756,716,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s58], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s58) b58 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_2
end PetersenSmallStarts.M111
