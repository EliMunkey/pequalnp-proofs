import M189StartData
import M189StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a :: inputs 6) tgt 7 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s105] [386,579,451,579,388,709,453,709,390,579,455,579,708,709,709,709,586,1091,451,1091,716,1221,453,1221,390,1091,455,1091,716,1221,1221,1221,1106,579,451,579,1236,709,453,709,1366,579,455,579,1236,709,709,709,1626,2243,451,2243,1756,2245,453,2245,1366,2243,455,2243,1756,2245,2245,2245,2210,2275,2275,2275,388,709,453,709,2470,2275,2535,2275,708,709,709,709,2666,2275,2275,2275,716,1221,453,1221,2470,2275,2535,2275,716,1221,1221,1221,1106,2275,2275,2275,1236,709,453,709,1366,2275,2535,2275,1236,709,709,709,1626,2275,2275,2275,1756,1948,453,1948,1366,2275,2535,2275,1756,1366,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s105], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s105) b105 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M189
