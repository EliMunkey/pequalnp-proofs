import M111StartData
import M111StartL6B0
import M111StartL6B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_5_3 : NoAtMost (0xff00ff0000000000 :: inputs 6) tgt 6 := by
  change NoAtMost [0xff00ff0000000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s146] [194,2730,195,2795,196,196,835,2923,390,390,455,455,196,196,839,839,714,2730,715,2795,716,716,843,2923,390,390,455,455,716,716,1351,1351,1106,3706,195,2795,1236,1236,835,2923,1366,1366,455,455,1236,1236,839,839,1626,3706,715,2795,1756,1756,843,2923,1366,1366,455,455,1756,1756,3740,3220,2210,2730,2275,2795,196,196,2915,2923,2470,2470,2535,2535,196,196,2919,3431,2730,2730,2795,2795,716,716,2923,2923,2470,2470,2535,2535,716,716,3431,3431,3186,3706,2275,2795,1236,1236,2915,2923,3446,3446,2535,2535,1236,1236,2919,839,3706,3706,2795,2795,1756,1756,2923,2923,3446,3446,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s146], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s146) b146 <|
    PetersenLocalChildren.nil
#print axioms gate_3_5_3
end PetersenSmallStarts.M111
