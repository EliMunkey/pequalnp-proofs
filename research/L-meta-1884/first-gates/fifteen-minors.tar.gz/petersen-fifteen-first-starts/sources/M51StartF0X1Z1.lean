import M51StartData
import M51StartL2B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222 :: inputs 4) tgt 2 := by
  change NoAtMost [0x2222,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 2
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s2,s0,s3] [51,84,52,84,53,84,84,84,87,148,52,148,121,148,148,148,155,84,52,84,189,84,84,84,223,255,52,0,257,257,1,2] (by decide +kernel)
  change ∀ b ∈ [s2,s0,s3], Blocked tgt 2 b
  exact
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M51
