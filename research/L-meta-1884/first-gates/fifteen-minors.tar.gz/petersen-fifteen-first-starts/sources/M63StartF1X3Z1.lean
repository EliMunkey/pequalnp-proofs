import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_1 : NoAtMost (0xcc00cc00cc00cc :: inputs 6) tgt 7 := by
  change NoAtMost [0xcc00cc00cc00cc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s782] [194,196,195,388,196,196,835,388,390,196,455,839,196,196,839,839,714,196,715,388,716,196,843,388,390,196,455,1351,716,196,1351,1351,1106,1236,195,1428,1236,1236,835,1428,1366,1236,455,839,1236,1236,839,839,714,1236,715,1428,716,1236,843,1428,1366,1236,455,2375,716,1236,2375,2375,2146,2276,195,2468,2276,2276,835,2468,2406,2276,455,839,2276,2276,839,839,2666,2276,715,2468,2796,2276,843,2468,2406,2276,455,1351,2796,2276,1351,1351,3186,3316,195,3508,3316,3316,835,3508,3446,3316,455,839,3316,3316,839,839,2666,3316,715,3508,2796,3316,843,3508,3446,3316,455,715,2796,3316,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s782], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s782) b782 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_1
end PetersenSmallStarts.M63
