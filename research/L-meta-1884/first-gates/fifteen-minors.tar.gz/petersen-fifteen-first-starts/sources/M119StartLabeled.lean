import M119StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 64) : Fin 64 := (#[0,2,1,3,8,10,9,11,4,6,5,7,12,14,13,15,32,34,33,35,40,42,41,43,36,38,37,39,44,46,45,47,16,18,17,19,24,26,25,27,20,22,21,23,28,30,29,31,48,50,49,51,56,58,57,59,52,54,53,55,60,62,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover0 : i6.all (fun q => i6.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
private def a1 (x : Fin 64) : Fin 64 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23,8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,48,49,50,51,52,53,54,55,40,41,42,43,44,45,46,47,56,57,58,59,60,61,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover1 : i6.all (fun q => i6.contains (PetersenPackedPin.project a1 q)) = true := by decide +kernel
private theorem same1 : PetersenPackedPin.project a1 tgt=tgt := by decide +kernel
private def a2 (x : Fin 64) : Fin 64 := (#[0,1,2,3,32,33,34,35,8,9,10,11,40,41,42,43,16,17,18,19,48,49,50,51,24,25,26,27,56,57,58,59,4,5,6,7,36,37,38,39,12,13,14,15,44,45,46,47,20,21,22,23,52,53,54,55,28,29,30,31,60,61,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover2 : i6.all (fun q => i6.contains (PetersenPackedPin.project a2 q)) = true := by decide +kernel
private theorem same2 : PetersenPackedPin.project a2 tgt=tgt := by decide +kernel
private def a3 (x : Fin 64) : Fin 64 := (#[0,2,1,3,16,18,17,19,4,6,5,7,20,22,21,23,32,34,33,35,48,50,49,51,36,38,37,39,52,54,53,55,8,10,9,11,24,26,25,27,12,14,13,15,28,30,29,31,40,42,41,43,56,58,57,59,44,46,45,47,60,62,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover3 : i6.all (fun q => i6.contains (PetersenPackedPin.project a3 q)) = true := by decide +kernel
private theorem same3 : PetersenPackedPin.project a3 tgt=tgt := by decide +kernel
private def a4 (x : Fin 64) : Fin 64 := (#[0,2,1,3,8,10,9,11,32,34,33,35,40,42,41,43,4,6,5,7,12,14,13,15,36,38,37,39,44,46,45,47,16,18,17,19,24,26,25,27,48,50,49,51,56,58,57,59,20,22,21,23,28,30,29,31,52,54,53,55,60,62,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover4 : i6.all (fun q => i6.contains (PetersenPackedPin.project a4 q)) = true := by decide +kernel
private theorem same4 : PetersenPackedPin.project a4 tgt=tgt := by decide +kernel
private def a5 (x : Fin 64) : Fin 64 := (#[0,1,2,3,32,33,34,35,16,17,18,19,48,49,50,51,8,9,10,11,40,41,42,43,24,25,26,27,56,57,58,59,4,5,6,7,36,37,38,39,20,21,22,23,52,53,54,55,12,13,14,15,44,45,46,47,28,29,30,31,60,61,62,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover5 : i6.all (fun q => i6.contains (PetersenPackedPin.project a5 q)) = true := by decide +kernel
private theorem same5 : PetersenPackedPin.project a5 tgt=tgt := by decide +kernel
private def a6 (x : Fin 64) : Fin 64 := (#[0,2,1,3,16,18,17,19,32,34,33,35,48,50,49,51,4,6,5,7,20,22,21,23,36,38,37,39,52,54,53,55,8,10,9,11,24,26,25,27,40,42,41,43,56,58,57,59,12,14,13,15,28,30,29,31,44,46,45,47,60,62,61,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover6 : i6.all (fun q => i6.contains (PetersenPackedPin.project a6 q)) = true := by decide +kernel
private theorem same6 : PetersenPackedPin.project a6 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x4444444444444444 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x4444444444444444) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_0_4_0 : NoAtMost (0xffffaaaaffffaaaa :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xffffaaaaffffaaaa) (a:=0xffaaffaaffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_0_4_1 : NoAtMost (0xaaaa0000aaaa :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xaaaa0000aaaa) (a:=0xaa00aa00aa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_0_4_2 : NoAtMost (0x5555000055550000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0x5555000055550000) (a:=0x5500550055005500) (by decide +kernel) gate_0_3_2
theorem labeled_0_4_3 : NoAtMost (0xaaaa0000aaaa0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xaaaa0000aaaa0000) (a:=0xaa00aa00aa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_0_5_1 : NoAtMost (0xaaaaaaaa :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaaaaaaaa) (a:=0xa0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_0_5_2 : NoAtMost (0x5555555500000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0x5555555500000000) (a:=0x5050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_0_5_3 : NoAtMost (0xaaaaaaaa00000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xaaaaaaaa00000000) (a:=0xa0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfcfcfcfcfc :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfcfcfcfcfcfcfc) (a:=0xffaaffaaffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c0c0c0c0c :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c) (a:=0xaa00aa00aa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_1_2_2 : NoAtMost (0x3030303030303030 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3030303030303030) (a:=0x5500550055005500) (by decide +kernel) gate_0_3_2
theorem labeled_1_2_3 : NoAtMost (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c0) (a:=0xaa00aa00aa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_1_3_1 : NoAtMost (0xcc00cc00cc00cc :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc00cc00cc00cc) (a:=0xa0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_3_2 : NoAtMost (0x3300330033003300 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3300330033003300) (a:=0x5050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_1_3_3 : NoAtMost (0xcc00cc00cc00cc00 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcc00cc00cc00cc00) (a:=0xa0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_4_1 : NoAtMost (0xcccc0000cccc :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xcccc0000cccc) (a:=0xa0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_4_2 : NoAtMost (0x3333000033330000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0x3333000033330000) (a:=0x5050505050505050) (by decide +kernel) gate_0_2_2
theorem labeled_1_4_3 : NoAtMost (0xcccc0000cccc0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xcccc0000cccc0000) (a:=0xa0a0a0a0a0a0a0a0) (by decide +kernel) gate_0_2_3
theorem labeled_1_5_0 : NoAtMost (0xffffffffcccccccc :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xffffffffcccccccc) (a:=0xffaaffaaffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_1_5_1 : NoAtMost (0xcccccccc :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xcccccccc) (a:=0xaa00aa00aa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_1_5_2 : NoAtMost (0x3333333300000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0x3333333300000000) (a:=0x5500550055005500) (by decide +kernel) gate_0_3_2
theorem labeled_1_5_3 : NoAtMost (0xcccccccc00000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xcccccccc00000000) (a:=0xaa00aa00aa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_2_3_2 : NoAtMost (0xf000f000f000f00 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f00) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_2_4_0 : NoAtMost (0xfffff0f0fffff0f0 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xfffff0f0fffff0f0) (a:=0xfff0fff0fff0fff0) (by decide +kernel) gate_2_3_0
theorem labeled_2_4_1 : NoAtMost (0xf0f00000f0f0 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xf0f00000f0f0) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_2_4_2 : NoAtMost (0xf0f00000f0f0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xf0f00000f0f0000) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_2_4_3 : NoAtMost (0xf0f00000f0f00000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a1 cover1 same1 (g:=0xf0f00000f0f00000) (a:=0xf000f000f000f000) (by decide +kernel) gate_2_3_3
theorem labeled_2_5_2 : NoAtMost (0xf0f0f0f00000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xf0f0f0f00000000) (a:=0xf0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_3_4_1 : NoAtMost (0xff000000ff00 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff00) (a:=0xf0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_3_4_2 : NoAtMost (0xff000000ff0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a3 cover3 same3 (g:=0xff000000ff0000) (a:=0xf0f0f0f0) (by decide +kernel) gate_2_5_1
theorem labeled_3_4_3 : NoAtMost (0xff000000ff000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff000000) (a:=0xf0f0f0f000000000) (by decide +kernel) gate_2_5_3
theorem labeled_3_5_0 : NoAtMost (0xffffffffff00ff00 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xffffffffff00ff00) (a:=0xfff0fff0fff0fff0) (by decide +kernel) gate_2_3_0
theorem labeled_3_5_1 : NoAtMost (0xff00ff00 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a4 cover4 same4 (g:=0xff00ff00) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_3_5_2 : NoAtMost (0xff00ff00000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xff00ff00000000) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_3_5_3 : NoAtMost (0xff00ff0000000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a2 cover2 same2 (g:=0xff00ff0000000000) (a:=0xf000f000f000f000) (by decide +kernel) gate_2_3_3
theorem labeled_4_5_0 : NoAtMost (0xffffffffffff0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xffffffffffff0000) (a:=0xfff0fff0fff0fff0) (by decide +kernel) gate_2_3_0
theorem labeled_4_5_1 : NoAtMost (0xffff0000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a6 cover6 same6 (g:=0xffff0000) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_4_5_2 : NoAtMost (0xffff00000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xffff00000000) (a:=0xf000f000f000f0) (by decide +kernel) gate_2_3_1
theorem labeled_4_5_3 : NoAtMost (0xffff000000000000 :: inputs 6) tgt 5 :=
  PetersenSmallStarts.relabel_aux a5 cover5 same5 (g:=0xffff000000000000) (a:=0xf000f000f000f000) (by decide +kernel) gate_2_3_3
def forbidden : List (BitVec 64) := [0xeeeeeeeeeeeeeeee,0x2222222222222222,0x4444444444444444,0x8888888888888888,0xa0a0a0a0a0a0a0a,0x5050505050505050,0xa0a0a0a0a0a0a0a0,0xffaaffaaffaaffaa,0xaa00aa00aa00aa,0x5500550055005500,0xaa00aa00aa00aa00,0xffffaaaaffffaaaa,0xaaaa0000aaaa,0x5555000055550000,0xaaaa0000aaaa0000,0xaaaaaaaa,0x5555555500000000,0xaaaaaaaa00000000,0xfcfcfcfcfcfcfcfc,0xc0c0c0c0c0c0c0c,0x3030303030303030,0xc0c0c0c0c0c0c0c0,0xcc00cc00cc00cc,0x3300330033003300,0xcc00cc00cc00cc00,0xcccc0000cccc,0x3333000033330000,0xcccc0000cccc0000,0xffffffffcccccccc,0xcccccccc,0x3333333300000000,0xcccccccc00000000,0xfff0fff0fff0fff0,0xf000f000f000f0,0xf000f000f000f00,0xf000f000f000f000,0xfffff0f0fffff0f0,0xf0f00000f0f0,0xf0f00000f0f0000,0xf0f00000f0f00000,0xf0f0f0f0,0xf0f0f0f00000000,0xf0f0f0f000000000,0xff000000ff00,0xff000000ff0000,0xff000000ff000000,0xffffffffff00ff00,0xff00ff00,0xff00ff00000000,0xff00ff0000000000,0xffffffffffff0000,0xffff0000,0xffff00000000,0xffff000000000000]
theorem all_forbidden (g : BitVec 64) (h : g∈forbidden) : NoAtMost (g::inputs 6) tgt 5 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 6) tgt 5 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xeeeeeeeeeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x2222222222222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x4444444444444444) labeled_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x8888888888888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xa0a0a0a0a0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x5050505050505050) gate_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xa0a0a0a0a0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffaaffaaffaaffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaa00aa00aa00aa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x5500550055005500) gate_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaa00aa00aa00aa00) gate_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffffaaaaffffaaaa) labeled_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaaaa0000aaaa) labeled_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x5555000055550000) labeled_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaaaa0000aaaa0000) labeled_0_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaaaaaaaa) labeled_0_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x5555555500000000) labeled_0_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xaaaaaaaa00000000) labeled_0_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xfcfcfcfcfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xc0c0c0c0c0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x3030303030303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xc0c0c0c0c0c0c0c0) labeled_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcc00cc00cc00cc) labeled_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x3300330033003300) labeled_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcc00cc00cc00cc00) labeled_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcccc0000cccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x3333000033330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcccc0000cccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffffffffcccccccc) labeled_1_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcccccccc) labeled_1_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0x3333333300000000) labeled_1_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xcccccccc00000000) labeled_1_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xfff0fff0fff0fff0) gate_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf000f000f000f0) gate_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf000f000f000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf000f000f000f000) gate_2_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xfffff0f0fffff0f0) labeled_2_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f00000f0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f00000f0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f00000f0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f0f0f0) gate_2_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f0f0f00000000) labeled_2_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xf0f0f0f000000000) gate_2_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff000000ff00) labeled_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff000000ff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff000000ff000000) labeled_3_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffffffffff00ff00) labeled_3_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff00ff00) labeled_3_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff00ff00000000) labeled_3_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xff00ff0000000000) labeled_3_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffffffffffff0000) labeled_4_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffff0000) labeled_4_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffff00000000) labeled_4_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 5) (x:=0xffff000000000000) labeled_4_5_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M119
