import SmallStartCore
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M51
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def tgt : BitVec 16 := 0xaaa8
def i4 : List (BitVec 16) := [0xaaaa,0xcccc,0xf0f0,0xff00]
theorem target_eq : tgt = graphTarget 4 [(0,1),(0,2),(0,3)] := by decide +kernel
def i2 : List (BitVec 4) := [0xa,0xc]
def s0 : List (BitVec 16) := [0xaaaa,0xcccc,0xf0f0,0xff00]
def s1 : List (BitVec 16) := [0xaaaa,0xcccc,0xeeee,0xf0f0,0xff00]
def s2 : List (BitVec 16) := [0x2222,0xaaaa,0xf0f0,0xff00]
def s3 : List (BitVec 16) := [0x2222,0xaaaa,0xcccc,0xf0f0,0xff00]
def s4 : List (BitVec 16) := [0x4444,0xaaaa,0xcccc,0xf0f0,0xff00]
def s5 : List (BitVec 16) := [0x8888,0xaaaa,0xf0f0,0xff00]
def s6 : List (BitVec 16) := [0x8888,0xaaaa,0xcccc,0xf0f0,0xff00]
def s7 : List (BitVec 16) := [0xc0c,0xaaaa,0xf0f0,0xff00]
def s8 : List (BitVec 16) := [0xc0c,0xaaaa,0xcccc,0xf0f0,0xff00]
def s9 : List (BitVec 16) := [0xaaaa,0xc0c0,0xcccc,0xf0f0,0xff00]
end PetersenSmallStarts.M51
