import M127StartData
import M127StartL5B3
import M127StartL5B1
import M127StartL5B2
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1186 : Blocked tgt 6 s1186 := by
  apply PetersenFastNode.node (nxt := #[s1187,s232,s1188,s1111]) (hints := [1422,1422,4745,0,9486,4745,4745,1421,1,4745,5261,1677,4233,1677,4745,1673,4237,1673,4745,2697,3342,2697,5518,2,9486,5518,6808,1421,5516,1421,5518,1677,1548,1677,3350,1673,3350,1673,3342,2697,3342,2697,905,905,1677,3,1677,1806,1673,8462,1673,10518,2697,8470,2697,9486,1421,393,1677,1421,1673,397,1673,389,2697,3086,2697,1421,3350,1673,1669,1669,1677,2185,3213,1677,1673,2189,2697,1673]) (by decide +kernel)
  change ∀ b ∈ [s1187,s232,s1188,s1111], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1187) b1187 <|
    PetersenLocalChildren.push (x := s232) b232 <|
    PetersenLocalChildren.push (x := s1188) b1188 <|
    PetersenLocalChildren.push (x := s1111) b1111 <|
    PetersenLocalChildren.nil
theorem b1189 : Blocked tgt 6 s1189 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1189 6 _ le
  decide +kernel
theorem b1190 : Blocked tgt 6 s1190 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(0,false),(4,true))] s1190 6 _ le
  decide +kernel
theorem b1191 : Blocked tgt 6 s1191 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1191 6 _ le
  decide +kernel
theorem b1192 : Blocked tgt 6 s1192 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1192 6 _ le
  decide +kernel
theorem b1281 : Blocked tgt 6 s1281 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1281 6 _ le
  decide +kernel
theorem b1282 : Blocked tgt 6 s1282 := by
  apply PetersenFastNode.node (nxt := #[s1283]) (hints := [5737,5353,1546,5353,1674,1418,386,1418,1666,7475,1674,3210,2178,1674,1674,5258,4226,1674,5931,1674,1674,13611,5353,1418,5609,5353,6325,5353,5353,6325,7467,3210,7467,5353,2197,5258,5321,5258,5547,5547,386,1418,1418,386,1418,7211,3210,1418,1418,9577,5258,1418,0,1418,1418,13609,1666,3210,2178,3210,1666,5258,4226,5258,6963,13611,1666,13611,3210,3371,5258,3210,7467,3210,3210,7467,9483,5258,5258,13579]) (by decide +kernel)
  change ∀ b ∈ [s1283], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1283) b1283 <|
    PetersenLocalChildren.nil
theorem b1290 : Blocked tgt 6 s1290 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1290 6 _ le
  decide +kernel
theorem b1291 : Blocked tgt 6 s1291 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1673,13610,1673,5930,13610,5546,5288,5546,1417,1417,1665,13610,13610,6962,3209,7466,3209,7466,5257,13578,5257,9482,6578,5546,6578,5546,1673,1929,897,1673,7474,7474,1673,7466,2177,7466,1673,5257,4225,1673,5288,5546,5546,5288,6578,5546,5546,6578,5546,4530,7466,5546,1418,1450,5514,1418,897,9609,9609,897,3209,7466,3209,7466,5257,9512,5257,9609,1665,7466,2177,7466,1665,5257,4225,5257,3338,3370,7434,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1292 : Blocked tgt 6 s1292 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1292 6 _ le
  decide +kernel
theorem b1296 : Blocked tgt 6 s1296 := by
  apply PetersenFastNode.node (nxt := #[s1297]) (hints := [2451,1419,2451,1419,1738,1897,2869,1738,1670,3347,1738,3786,2694,1738,1738,5834,4742,1738,1674,1674,1738,9483,9577,1419,9577,9705,2451,1419,1419,2451,1419,11338,3339,1419,2709,1419,1419,13513,1419,5353,9483,1419,1670,9577,9577,2869,11466,3339,11466,9577,9674,9674,0,9483,9513,9483,1670,11466,2694,11466,1670,13514,4742,13514,2835,9483,1666,9483,11466,3339,13514,11466,3210,3274,11402,3210,5258,5322,13450,5258]) (by decide +kernel)
  change ∀ b ∈ [s1297], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1297) b1297 <|
    PetersenLocalChildren.nil
theorem b1305 : Blocked tgt 6 s1305 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1305 6 _ le
  decide +kernel
theorem b1306 : Blocked tgt 6 s1306 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1306 6 _ le
  decide +kernel
theorem b1307 : Blocked tgt 6 s1307 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1307 6 _ le
  decide +kernel
theorem b1308 : Blocked tgt 6 s1308 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1308 6 _ le
  decide +kernel
theorem b1309 : Blocked tgt 6 s1309 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1309 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
