import M127StartData
import M127StartPins0
import M127StartL6B23
import M127StartL6B24
import M127StartL6B25
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b821 : Blocked tgt 7 s821 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s821 7 _ le
  decide +kernel
theorem b822 : Blocked tgt 7 s822 := by
  apply PetersenFastNode.node (nxt := #[s823,s825,s826]) (hints := [13613,6581,6839,13613,904,904,1676,5933,1676,5933,1672,7477,1672,7477,2696,14645,2696,13613,13613,14645,14645,13613,4744,13581,4744,9485,6839,6581,6581,6839,5933,1676,5933,6581,6581,1672,7477,6581,4533,6581,2696,5549,5549,2453,2485,6549,2453,1676,5933,1676,5933,1672,7477,1672,7477,2696,15159,2696,9096,13095,9096,9096,13095,4744,11063,4744,9096,6965,4909,7477,6965,5933,6965,6965,5933,5933,6965,6965,5933,1805,1837,5901,1805,1672,7477,7477,1672,5671,7477,7477,5671,3349,3381,7445,3349,7469,7469,2696,0,4744,2696,1,4744,2,4744]) (by decide +kernel)
  change ∀ b ∈ [s823,s825,s826], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s823) b823 <|
    PetersenLocalChildren.push (x := s825) b825 <|
    PetersenLocalChildren.push (x := s826) b826 <|
    PetersenLocalChildren.nil
theorem b827 : Blocked tgt 7 s827 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s827 7 _ le
  decide +kernel
theorem b828 : Blocked tgt 7 s828 := by
  apply PetersenFastNode.node (nxt := #[s829,s830,s831,s834,s835]) (hints := [15097,9034,15225,15097,6583,9806,6967,6583,6583,9802,7479,6583,4535,4535,6583,13033,5551,5551,2455,2487,6551,2455,13615,6905,13615,6583,9678,8650,9934,9678,9162,8654,9930,9162,9162,13177,10954,9162,13677,9162,9162,13677,9162,11129,13002,9162,906,970,9098,906,6967,9930,9926,9926,9934,10442,11470,9934,9934,5935,9934,12490,13518,9934,1678,1742,9870,1678,9930,10446,10954,9930,0,9930,9930,1,9930,12494,13002,9930,1674,1738,9866,1674,10954,7471,10954,2,13002,10954,2698,2762,10890,2698,3,13002,4,13002,13615,14647,13615,14647,4746,4810,12938,4746]) (by decide +kernel)
  change ∀ b ∈ [s829,s830,s831,s834,s835], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s829) b829 <|
    PetersenLocalChildren.push (x := s830) b830 <|
    PetersenLocalChildren.push (x := s831) b831 <|
    PetersenLocalChildren.push (x := s834) b834 <|
    PetersenLocalChildren.push (x := s835) b835 <|
    PetersenLocalChildren.nil
theorem b836 : Blocked tgt 7 s836 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s836 7 _ le
  decide +kernel
theorem b837 : Blocked tgt 7 s837 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s837 7 _ le
  decide +kernel
theorem b838 : Blocked tgt 7 s838 := by
  apply PetersenFastNode.node (nxt := #[s839,s841,s842]) (hints := [6839,904,6967,6839,6581,1740,5739,6581,6581,1672,7477,6581,4533,6581,2696,5549,5549,2453,2485,6549,2453,13613,6839,13613,6581,1740,904,1740,1996,904,8652,1672,904,904,6967,2696,904,4903,904,904,4903,904,2871,4744,904,1420,904,904,1420,7477,1672,1732,1672,1740,2696,3788,1740,5739,1740,1740,5739,1740,4744,5836,1740,1676,1676,1672,10444,2696,1672,5671,1672,1672,5671,1672,12492,4744,1672,7477,1672,1672,7477,2696,7469,2696,0,4744,2696,3212,2696,2696,3212,1,4744,2,4744,13613,14645,13613,14645,5260,4744,4744,5260]) (by decide +kernel)
  change ∀ b ∈ [s839,s841,s842], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s839) b839 <|
    PetersenLocalChildren.push (x := s841) b841 <|
    PetersenLocalChildren.push (x := s842) b842 <|
    PetersenLocalChildren.nil
theorem b843 : Blocked tgt 7 s843 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s843 7 _ le
  decide +kernel
theorem b844 : Blocked tgt 7 s844 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s844 7 _ le
  decide +kernel
theorem b845 : Blocked tgt 7 s845 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s845 7 _ le
  decide +kernel
theorem b846 : Blocked tgt 7 s846 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s846 7 _ le
  decide +kernel
theorem b847 : Blocked tgt 7 s847 := by
  apply PetersenFastNode.node (nxt := #[s848,s849,s850,s851,s852,s853,s854,s855,s856,s857,s814,s858,s859,s823,s831,s860,s839,s861,s862,s863,s864,s865,s866,s867]) (hints := [10988,10988,11116,9181,2474,9181,11116,2474,11116,10988,10988,9181,5954,2474,5954,9953,10988,9953,5954,10988,5954,2474,2474,9953,2474,2474,3370,9949,0,9949,3370,1,3370,2474,2474,9949,3394,2474,3394,3522,2,3,426,4,5,426,2474,10973,2474,2474,6,10973,7,10973,13634,2474,13634,2796,10988,8,13634,10988,13634,2474,2474,9,9697,9697,9953,8669,9181,5954,9953,9181,9953,9697,9697,5954,9181,9181,9949,8673,9697,3370,9949,9697,9949,9181,9181,3370,13164,13180,11392,9181,9181,3394,9181,9181,11392,11132,13180,3394,9181,9181,10973,11116,11116,10,10973,11116,10973,9181,9181,11,925,925,12,989,9181,13634,9117,9181,13,925,925,13634,2858,2858,3370,9949,9953,9949,9945,9953,3370,9945,2858,9949,3394,5954,3394,9953,9953,14,9953,9953,3394,3906,5954,15,9953,9953,11489,10461,5954,10973,11489,5954,11489,9953,9953,10973,1697,1697,13634,1761,9953,16,9889,9953,13634,1697,1697,17,13932,13948,18,9949,9949,3394,9949,9949,19,3386,13948,3394,9949,9949,10973,10465,3370,11489,10973,3370,10973,9949,9949,11489,1693,1693,10538,1757,9949,13634,9885,9949,10538,1693,1693,13634,20,21,22,10973,3394,10973,3362,3394,6,10973,23,10973,3394,3394,13634,10538,11392,10538,11586,11392,13634,3394,3394,10538,2717,2717,9506,2781,10973,13634,10909,10973,9506,2717,2717,13634]) (by decide +kernel)
  change ∀ b ∈ [s848,s849,s850,s851,s852,s853,s854,s855,s856,s857,s814,s858,s859,s823,s831,s860,s839,s861,s862,s863,s864,s865,s866,s867], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s848) b848 <|
    PetersenLocalChildren.push (x := s849) b849 <|
    PetersenLocalChildren.push (x := s850) b850 <|
    PetersenLocalChildren.push (x := s851) b851 <|
    PetersenLocalChildren.push (x := s852) b852 <|
    PetersenLocalChildren.push (x := s853) b853 <|
    PetersenLocalChildren.push (x := s854) b854 <|
    PetersenLocalChildren.push (x := s855) b855 <|
    PetersenLocalChildren.push (x := s856) b856 <|
    PetersenLocalChildren.push (x := s857) b857 <|
    PetersenLocalChildren.push (x := s814) b814 <|
    PetersenLocalChildren.push (x := s858) b858 <|
    PetersenLocalChildren.push (x := s859) b859 <|
    PetersenLocalChildren.push (x := s823) b823 <|
    PetersenLocalChildren.push (x := s831) b831 <|
    PetersenLocalChildren.push (x := s860) b860 <|
    PetersenLocalChildren.push (x := s839) b839 <|
    PetersenLocalChildren.push (x := s861) b861 <|
    PetersenLocalChildren.push (x := s862) b862 <|
    PetersenLocalChildren.push (x := s863) b863 <|
    PetersenLocalChildren.push (x := s864) b864 <|
    PetersenLocalChildren.push (x := s865) b865 <|
    PetersenLocalChildren.push (x := s866) b866 <|
    PetersenLocalChildren.push (x := s867) b867 <|
    PetersenLocalChildren.nil
theorem b868 : Blocked tgt 7 s868 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s868 7 _ le
  decide +kernel
theorem b869 : Blocked tgt 7 s869 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s869 7 _ le
  decide +kernel
theorem b870 : Blocked tgt 7 s870 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s870 7 _ le
  decide +kernel
theorem b871 : Blocked tgt 7 s871 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(4,false))] s871 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
