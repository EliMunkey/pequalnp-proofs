import M251StartData
import M251StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_0 : NoAtMost (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc :: inputs 7) tgt 7 := by
  change NoAtMost [0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s20] [386,388,387,391,388,388,1155,1671,902,902,903,903,904,904,1671,1671,1162,1420,387,391,1420,1420,2179,2695,902,902,903,903,904,904,2695,2695,2194,2452,387,391,2452,2452,1155,1671,2710,2710,903,903,2968,2968,1671,1671,3226,3484,387,391,3484,3484,3868,3868,2710,2710,903,903,2968,2968,6936,6936,4386,4390,4515,4519,388,388,5283,5799,4902,4902,5031,5031,904,904,5799,5799,5290,1420,4515,4519,1420,1420,6307,6823,4902,4902,5031,5031,904,904,6823,6823,6322,6454,4515,4519,2452,2452,5283,5799,6838,6838,5031,5031,2968,2968,5799,5799,7354,3484,4515,4519,3484,3484,3868,3868,6838,6838,5031,5031,2968,2968,11032,11032,8642,8644,8643,8647,8644,8644,9411,9927,9158,9158,9159,9159,9160,9160,9927,9927,9418,9676,8643,8647,9676,9676,10435,10951,9158,9158,9159,9159,9160,9160,10951,10951,2194,2452,8643,8647,2452,2452,9411,9927,2710,2710,9159,9159,2968,2968,9927,9927,3226,3484,8643,8647,3484,3484,3868,3868,2710,2710,9159,9159,2968,2968,6936,6936,12642,12646,12771,12775,8644,8644,13539,14055,13158,13158,13287,13287,9160,9160,14055,14055,13546,9676,12771,12775,9676,9676,14563,15079,13158,13158,13287,13287,9160,9160,15079,15079,6322,6454,12771,12775,2452,2452,13539,14055,6838,6838,13287,13287,2968,2968,14055,14055,7354,3484,12771,12775,3484,3484,3868,3868,6838,6838,13287,13287,2968,2968,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s20], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_0
end PetersenSmallStarts.M251
