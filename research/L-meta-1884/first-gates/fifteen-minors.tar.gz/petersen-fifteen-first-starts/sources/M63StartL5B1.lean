import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b35 : Blocked tgt 5 s35 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1460,1234,1524,1460,841,1426,841,1426,837,837,1609,1349,1609,1349,713,453,713,453,1234,777,1426,1234,1234,714,1972,1234,194,1349,1218,1349,389,389,1234,453,1426,841,841,1426,1089,1093,1089,1345,193,197,193,449,1349,1609,1349,1609,453,713,453,713,453,1546,453,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b36 : Blocked tgt 5 s36 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s36 5 _ le
  decide +kernel
theorem b37 : Blocked tgt 5 s37 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s37 5 _ le
  decide +kernel
theorem b38 : Blocked tgt 5 s38 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s38 5 _ le
  decide +kernel
theorem b39 : Blocked tgt 5 s39 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s39 5 _ le
  decide +kernel
theorem b40 : Blocked tgt 5 s40 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [389,389,453,714,1428,453,453,388,713,197,841,713,453,201,837,453,453,1674,420,484,714,841,906,714,194,202,706,194,714,1349,1106,714,2826,906,936,906,420,837,932,420,420,1349,1412,420,386,394,898,386,906,1093,1609,906,2852,1097,1349,2852]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b43 : Blocked tgt 5 s43 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s43 5 _ le
  decide +kernel
theorem b44 : Blocked tgt 5 s44 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s44 5 _ le
  decide +kernel
theorem b45 : Blocked tgt 5 s45 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s45 5 _ le
  decide +kernel
theorem b50 : Blocked tgt 5 s50 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3508,3444,389,3444,713,841,197,713,453,837,201,453,453,1349,2484,453,453,2373,1460,453,777,777,3444,841,3444,773,3892,3444,2404,2420,3428,2404,1364,1396,3412,1364,3504,837,833,833,841,1093,1609,841,841,2117,2633,841,837,1097,1349,837,837,2121,2373,837,1349,1576,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b51 : Blocked tgt 5 s51 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s51 5 _ le
  decide +kernel
theorem b52 : Blocked tgt 5 s52 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s52 5 _ le
  decide +kernel
theorem b57 : Blocked tgt 5 s57 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s57 5 _ le
  decide +kernel
theorem b58 : Blocked tgt 5 s58 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2986,2794,777,2794,841,713,197,713,833,833,837,3506,841,1609,1093,841,841,2633,2117,841,2664,2666,2792,2664,3314,2282,3762,3314,2794,2290,3754,2794,714,746,2762,714,193,201,705,193,713,3626,1609,713,713,1456,2633,713,1089,1097,1089,1601,2113,2121,2113,2625,1609,1706,2633,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b59 : Blocked tgt 5 s59 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s59 5 _ le
  decide +kernel
theorem b60 : Blocked tgt 5 s60 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3754,2794,2290,2794,1349,453,2468,453,1609,841,1093,841,1349,837,1097,837,1349,2373,1706,1349,389,389,2792,453,2794,777,2986,2794,2274,2282,2786,2274,714,746,2762,714,713,197,841,713,453,201,837,453,453,1444,2373,453,2466,837,833,833,841,2117,2633,841,837,2121,2373,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
