import M111StartData
import M111StartPins0
import M111StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b35 : Blocked tgt 5 s35 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2469,2469,714,2533,3428,714,714,3428,714,2921,906,714,194,202,706,194,714,1380,2698,714,2533,2468,2793,2277,2921,2793,2533,2281,2917,2533,453,485,2501,453,3689,2921,3173,2921,3429,2917,3177,2917,1349,3397,1381,1349,386,2917,2913,2913,841,873,2889,841,837,869,2885,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b36 : Blocked tgt 5 s36 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s36 5 _ le
  decide +kernel
theorem b37 : Blocked tgt 5 s37 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s37 5 _ le
  decide +kernel
theorem b38 : Blocked tgt 5 s38 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s38 5 _ le
  decide +kernel
theorem b39 : Blocked tgt 5 s39 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s39 5 _ le
  decide +kernel
theorem b40 : Blocked tgt 5 s40 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s40 5 _ le
  decide +kernel
theorem b41 : Blocked tgt 5 s41 := by
  apply PetersenFastNode.node (nxt := #[s42]) (hints := [195,195,3430,2282,2217,3430,3690,2922,3174,2922,3430,2918,3178,2918,1350,3398,1382,1350,3429,2282,2217,2282,387,2922,387,2922,2853,2918,1219,2918,1219,1381,2179,1219,2282,387,2538,2282,2534,2534,202,234,2250,202,0,2918,2914,2914,842,874,2890,842,838,870,2886,838]) (by decide +kernel)
  change ∀ b ∈ [s42], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.nil
theorem b43 : Blocked tgt 5 s43 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3429,2917,3177,2917,3688,194,3689,2533,2468,3689,3689,2921,2856,2921,1609,3657,1641,1609,1218,2917,2917,2852,2533,2281,386,2917,2913,2913,837,869,2885,837,3688,2533,2468,2533,2856,2921,2856,2921,1608,1640,3656,1608,2921,2277,2921,2273,453,485,2501,453,841,873,2889,841]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b44 : Blocked tgt 5 s44 := by
  apply PetersenFastNode.node (nxt := #[s45,s46,s47]) (hints := [717,717,1352,0,2701,1352,1352,456,391,456,1612,844,1096,844,1352,840,1100,840,1741,1,2701,1741,391,456,391,456,909,844,909,844,1221,840,1733,840,456,2504,844,2,844,2701,840,2189,840,2181,716,200,844,716,456,204,840,456,389,840,836,836]) (by decide +kernel)
  change ∀ b ∈ [s45,s46,s47], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s46) b46 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.nil
theorem b48 : Blocked tgt 5 s48 := by
  apply PetersenFastNode.node (nxt := #[s49]) (hints := [1350,0,1350,2699,2699,1739,1349,1739,454,454,842,907,842,907,838,2691,838,2179,715,715,1350,2502,2437,1350,907,842,907,842,1350,838,1098,838,1349,1739,1739,2502,907,842,907,1739,1219,1227,1731,1219,842,907,842,907,838,2250,838,2502,387,395,899,387]) (by decide +kernel)
  change ∀ b ∈ [s49], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.nil
theorem b50 : Blocked tgt 5 s50 := by
  apply PetersenFastNode.node (nxt := #[s51,s53]) (hints := [196,196,3431,2535,2470,2535,3431,2919,2854,2919,3171,3427,3175,3171,1351,3399,1383,1351,2470,2535,2470,2535,1220,2919,2854,2919,388,3174,388,1220,1220,1382,2180,1220,2535,0,2919,2535,2275,2279,2531,2275,455,487,2503,455,2915,2915,839,871,2887,839,388,1,2180,388]) (by decide +kernel)
  change ∀ b ∈ [s51,s53], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.nil
theorem b54 : Blocked tgt 5 s54 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3169,2917,3429,2917,3428,194,3429,2533,2468,2533,3169,3429,3429,2913,1349,3397,1381,1349,1218,2917,2917,2852,2917,2533,2273,2533,2913,386,837,2885,869,837,2468,2533,2468,2533,898,2913,3428,2913,1348,1380,3396,1348,2273,2533,2533,2273,453,485,2501,453,833,865,2881,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b55 : Blocked tgt 5 s55 := by
  apply PetersenFastNode.node (nxt := #[s53]) (hints := [715,715,1350,454,389,454,1898,874,1350,874,1350,838,3178,838,1610,1350,1350,1610,389,454,389,454,1739,874,809,874,1219,838,1731,838,1739,1349,2699,1739,874,454,874,1002,454,2282,838,454,714,454,454,714,0,838,866,838,842,842,2179,838,838,2691]) (by decide +kernel)
  change ∀ b ∈ [s53], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.nil
theorem b56 : Blocked tgt 5 s56 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1349,3657,1641,1349,3688,714,3689,2793,2728,2793,3689,841,1093,3689,3169,3681,3177,3169,1738,1640,1738,2698,453,745,453,2761,841,873,837,2186,837,2178,2728,2793,2728,2793,3688,841,906,841,3168,837,3680,837,2793,197,841,2793,2273,2281,2785,2273,386,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b61 : Blocked tgt 5 s61 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s61 5 _ le
  decide +kernel
theorem b62 : Blocked tgt 5 s62 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s62 5 _ le
  decide +kernel
end PetersenSmallStarts.M111
