import M55StartData
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_3 : NoAtMost (0xaa00aa00 :: inputs 5) tgt 4 := by
  change NoAtMost [0xaa00aa00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s15,s0,s16] [99,99,100,100,101,101,292,548,199,199,232,232,101,101,424,680,299,459,100,100,365,461,548,548,431,463,232,232,365,101,680,680,563,563,100,100,629,629,292,725,695,695,232,232,629,629,424,0,827,987,100,100,893,989,989,989,959,991,232,232,893,629,1,2] (by decide +kernel)
  change ∀ b ∈ [s15,s0,s16], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_3
end PetersenSmallStarts.M55
