import M119StartData
import M119StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b19 : Blocked tgt 5 s19 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s19 5 _ le
  decide +kernel
theorem b20 : Blocked tgt 5 s20 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s20 5 _ le
  decide +kernel
theorem b21 : Blocked tgt 5 s21 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s21 5 _ le
  decide +kernel
theorem b22 : Blocked tgt 5 s22 := by
  intro k le c
  apply rejects_sound r0 i4 3 tgt small0 hot0 [] s22 5 _ le
  decide +kernel
end PetersenSmallStarts.M119
