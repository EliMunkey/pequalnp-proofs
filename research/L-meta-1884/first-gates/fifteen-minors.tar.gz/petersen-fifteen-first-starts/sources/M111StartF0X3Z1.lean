import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_1 : NoAtMost (0xaa00aa00aa00aa :: inputs 6) tgt 6 := by
  change NoAtMost [0xaa00aa00aa00aa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s28] [194,195,195,195,196,1091,835,1091,390,455,455,455,196,1351,839,1351,714,195,715,195,716,1091,843,1091,390,455,455,455,716,1351,1351,1351,1106,195,195,195,1236,1428,835,843,1366,455,455,455,1236,1748,839,3220,1626,195,715,195,1756,1756,843,843,1366,455,455,455,1756,1756,3740,3740,2210,2275,2275,2275,196,3171,2915,3171,2470,2535,2535,2535,196,3431,2919,3431,2730,2275,2795,2275,716,3171,2923,3171,2470,2535,2535,2535,716,3431,3431,3431,3186,2275,2275,2275,1236,1428,2915,2923,3446,2535,2535,2535,1236,1748,2919,3894,3706,2275,2795,2275,1756,1756,2923,2923,3446,2535,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s28], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_1
end PetersenSmallStarts.M111
