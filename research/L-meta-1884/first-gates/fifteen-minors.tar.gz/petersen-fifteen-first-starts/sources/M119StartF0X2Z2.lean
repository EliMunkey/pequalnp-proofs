import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_2 : NoAtMost (0x5050505050505050 :: inputs 6) tgt 5 := by
  change NoAtMost [0x5050505050505050,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s5,s0,s6] [195,391,196,391,197,197,580,580,391,391,456,391,197,197,840,840,587,911,196,911,717,717,1092,1092,847,911,456,911,717,717,1352,1352,1107,1431,196,1431,1237,1237,580,580,1367,1431,456,1431,1237,1237,840,840,1627,1951,196,1951,1757,1757,1949,3741,1887,1951,456,1951,1757,1757,3741,3741,2211,2471,2276,2471,197,197,2660,2660,2471,2471,2536,2471,197,197,2920,2920,2667,2991,2276,2991,717,717,3172,3172,2927,2991,2536,2991,717,717,3432,3432,3187,3511,2276,3511,1237,1237,2660,2660,3447,3511,2536,3511,1237,1237,2920,2920,3707,4031,2276,4031,1757,1757,1949,0,3967,4031,2536,4031,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s5,s0,s6], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_2
end PetersenSmallStarts.M119
