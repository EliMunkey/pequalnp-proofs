import M55StartData
import M55StartL4B0
import M55StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_2 : NoAtMost (0xf000f00 :: inputs 5) tgt 4 := by
  change NoAtMost [0xf000f00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s28] [98,298,99,99,100,364,291,419,198,298,231,231,100,364,423,423,298,298,99,99,364,364,547,547,430,298,231,231,364,364,679,679,562,826,99,99,628,892,291,419,694,826,231,231,628,892,423,423,826,826,99,99,892,892,988,724,958,826,231,231,892,892,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s28], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_2
end PetersenSmallStarts.M55
