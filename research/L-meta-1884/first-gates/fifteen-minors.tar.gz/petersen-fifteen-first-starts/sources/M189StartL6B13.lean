import M189StartData
import M189StartPins0
import M189StartL5B2
import M189StartL5B3
import M189StartL5B4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b288 : Blocked tgt 6 s288 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s288 6 _ le
  decide +kernel
theorem b289 : Blocked tgt 6 s289 := by
  apply PetersenFastNode.node (nxt := #[s229,s241,s261,s274,s290]) (hints := [1239,1751,584,584,712,0,456,1,456,712,712,2922,712,2,1224,712,712,3,2248,712,1369,1239,1239,1369,1239,392,1431,1239,1369,1239,1239,1369,3369,1224,1223,1223,1239,2184,3223,1239,1815,456,1437,456,2538,2538,3434,1224,3434,1224,3353,2248,3353,2248,4,456,456,1813,456,3178,1224,456,456,813,2248,456,3434,1224,3434,1224,1817,2248,3353,2248,1224,1386,2248,1224]) (by decide +kernel)
  change ∀ b ∈ [s229,s241,s261,s274,s290], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s229) b229 <|
    PetersenLocalChildren.push (x := s241) b241 <|
    PetersenLocalChildren.push (x := s261) b261 <|
    PetersenLocalChildren.push (x := s274) b274 <|
    PetersenLocalChildren.push (x := s290) b290 <|
    PetersenLocalChildren.nil
theorem b291 : Blocked tgt 6 s291 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s291 6 _ le
  decide +kernel
theorem b292 : Blocked tgt 6 s292 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s292 6 _ le
  decide +kernel
theorem b293 : Blocked tgt 6 s293 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s293 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
