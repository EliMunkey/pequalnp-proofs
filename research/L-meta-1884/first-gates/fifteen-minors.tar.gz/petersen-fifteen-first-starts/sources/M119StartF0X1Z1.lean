import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_1 : NoAtMost (0x2222222222222222 :: inputs 6) tgt 5 := by
  change NoAtMost [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s2] [194,579,195,579,196,579,579,579,390,839,455,839,196,839,839,839,586,1091,195,1091,716,1091,1091,1091,846,1351,455,1351,716,1351,1351,1351,1106,579,195,579,1236,579,579,579,1366,839,455,839,1236,839,839,839,1626,1754,195,1946,1756,1756,1948,1948,1886,1950,455,1950,1756,1756,3740,3740,2210,2659,2275,2659,196,2659,2659,2659,2470,2919,2535,2919,196,2919,2919,2919,2666,3171,2275,3171,716,3171,3171,3171,2926,3431,2535,3431,716,3431,3431,3431,3186,2659,2275,2659,1236,2659,2659,2659,3446,2919,2535,2919,1236,2919,2919,2919,3706,3770,2275,3770,1756,1756,1948,1948,3966,4030,2535,4030,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s2], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_1
end PetersenSmallStarts.M119
