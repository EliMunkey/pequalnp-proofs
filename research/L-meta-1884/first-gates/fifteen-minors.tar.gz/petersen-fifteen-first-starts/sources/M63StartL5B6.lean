import M63StartData
import M63StartL4B0
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b220 : Blocked tgt 5 s220 := by
  apply PetersenFastNode.node (nxt := #[s221]) (hints := [2665,714,2793,2665,3445,2665,3635,3445,3445,198,3317,3317,2405,2421,3429,2405,1365,1397,3413,1365,202,202,714,3507,0,714,714,194,714,1094,1610,714,714,2118,2634,714,198,710,1350,1610,1350,1610,2374,2634,2374,2634,198,1610,1222,198,198,2634,2246,198,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s221], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s221) b221 <|
    PetersenLocalChildren.nil
theorem b222 : Blocked tgt 5 s222 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s222 5 _ le
  decide +kernel
theorem b223 : Blocked tgt 5 s223 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s223 5 _ le
  decide +kernel
theorem b224 : Blocked tgt 5 s224 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s224 5 _ le
  decide +kernel
theorem b225 : Blocked tgt 5 s225 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s225 5 _ le
  decide +kernel
theorem b226 : Blocked tgt 5 s226 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(3,false))] s226 5 _ le
  decide +kernel
theorem b231 : Blocked tgt 5 s231 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(3,false))] s231 5 _ le
  decide +kernel
theorem b232 : Blocked tgt 5 s232 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s232 5 _ le
  decide +kernel
theorem b233 : Blocked tgt 5 s233 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s233 5 _ le
  decide +kernel
theorem b234 : Blocked tgt 5 s234 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(3,false))] s234 5 _ le
  decide +kernel
theorem b235 : Blocked tgt 5 s235 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s235 5 _ le
  decide +kernel
theorem b236 : Blocked tgt 5 s236 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(3,false))] s236 5 _ le
  decide +kernel
theorem b241 : Blocked tgt 5 s241 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s241 5 _ le
  decide +kernel
theorem b242 : Blocked tgt 5 s242 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s242 5 _ le
  decide +kernel
theorem b243 : Blocked tgt 5 s243 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s243 5 _ le
  decide +kernel
theorem b244 : Blocked tgt 5 s244 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s244 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
