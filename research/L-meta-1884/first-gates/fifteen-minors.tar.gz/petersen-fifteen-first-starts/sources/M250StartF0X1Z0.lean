import M250StartData
import M250StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeee :: inputs 6) tgt 4 := by
  change NoAtMost [0xeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1] [386,387,451,451,388,388,453,453,390,391,455,455,1220,1220,1221,1221,906,907,971,971,908,908,973,973,910,911,975,975,1740,1740,1741,1741,1106,1108,451,451,1236,1236,453,453,1366,391,455,455,1236,1236,2757,2757,1626,1628,971,971,1756,1756,973,973,1886,911,975,975,1756,1756,2765,2765,2466,2467,2531,2531,2468,2468,2533,2533,2470,2471,2535,2535,2724,2724,2789,2789,906,907,971,971,908,908,973,973,910,911,975,975,1740,1740,1741,1741,3186,3188,2531,2531,3316,3316,2533,2533,3446,2471,2535,2535,3316,3316,2789,2789,1626,1628,971,971,1756,1756,973,973,1886,911,975,975,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_0
end PetersenSmallStarts.M250
