import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1111 : Blocked tgt 4 s1111 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1364,1234,1364,837,453,193,453,833,1426,837,1349,1089,837,1364,389,1428,1364,1234,1364,1364,1234,194,1349,1348,1348,193,453,453,193,453,404,1349,453,833,1349,1089,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1144 : Blocked tgt 4 s1144 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2152,2154,2280,2152,3506,2282,3314,3314,2282,2482,3306,2282,202,234,2250,202,3188,193,3188,3316,193,2484,1089,193,193,1460,2113,193,2148,2164,3172,2148,1108,1140,3156,1108,1089,1706,2113,1089]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1145 : Blocked tgt 4 s1145 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2152,2154,2152,2280,2868,193,2868,2996,193,2484,769,193,193,1460,2113,193,3506,2282,2994,2994,2282,2482,2986,2282,202,234,2250,202,2148,3754,3746,3746,1682,1714,3730,1682,1674,1706,3722,1674]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1146 : Blocked tgt 4 s1146 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1146 4 _ le
  decide +kernel
theorem b1150 : Blocked tgt 4 s1150 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1150 4 _ le
  decide +kernel
theorem b1154 : Blocked tgt 4 s1154 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1154 4 _ le
  decide +kernel
theorem b1156 : Blocked tgt 4 s1156 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1156 4 _ le
  decide +kernel
end PetersenSmallStarts.M63
