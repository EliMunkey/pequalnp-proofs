import M127StartData
import M127StartL4B0
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1173 : Blocked tgt 5 s1173 := by
  apply PetersenFastNode.node (nxt := #[s931]) (hints := [2451,2451,4742,902,2837,902,4742,1670,3347,1670,4742,2694,0,2694,4226,4738,4230,4226,2837,902,2837,902,3347,1670,3347,1670,4483,2694,6531,2694,2835,6293,2835,6547,902,3091,1670,902,902,789,2694,902,386,390,898,386,1670,3347,2694,1670,2835,1670,1666,1666,2178,2182,2690,2178]) (by decide +kernel)
  change ∀ b ∈ [s931], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s931) b931 <|
    PetersenLocalChildren.nil
theorem b1184 : Blocked tgt 5 s1184 := by
  intro k le c
  apply rejects_sound r15 i4 3 tgt small15 hot15 [] s1184 5 _ le
  decide +kernel
theorem b1187 : Blocked tgt 5 s1187 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [773,773,5512,901,5514,4741,1418,1418,5514,1673,1544,5514,3346,4490,3346,6546,3338,4498,3338,5514,4741,901,901,2836,1417,389,1673,1417,901,393,1669,901,901,3082,2693,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,3338,2693,3346,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1188 : Blocked tgt 5 s1188 := by
  apply PetersenFastNode.node (nxt := #[s233]) (hints := [774,774,0,902,1419,1419,5258,1674,4230,1674,3347,1670,3347,1670,3339,2694,3339,2694,6805,902,902,2837,1418,390,1674,1418,902,394,1670,902,902,3083,2694,902,5515,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,3347,1670,1666,1666,1674,2182,3210,1674,1670,2186,2694,1670]) (by decide +kernel)
  change ∀ b ∈ [s233], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s233) b233 <|
    PetersenLocalChildren.nil
theorem b1283 : Blocked tgt 5 s1283 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,5288,1545,5288,1673,1417,385,1417,1665,7216,1673,3209,2177,1673,1673,5257,4225,1673,5288,1417,5544,5288,6320,5288,5288,6320,5288,3081,7208,5288,2192,5257,5256,5256,385,1417,1417,385,1417,4912,3209,1417,1417,9512,5257,1417,1665,3209,2177,3209,1665,5257,4225,5257,3209,3112,5257,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1297 : Blocked tgt 5 s1297 := by
  apply PetersenFastNode.node (nxt := #[s1298]) (hints := [5643,1419,1546,1419,1674,1803,2835,1674,1666,3347,1674,3210,2178,1674,1674,1418,386,1418,1419,0,9483,1419,2451,1419,1419,2451,1419,3082,3339,1419,2193,1418,1417,1417,1666,9483,9483,2835,3210,787,3210,9483,1418,9610,1666,3210,2178,3210,386,1418,386,1418,1418,3083,1418,3210]) (by decide +kernel)
  change ∀ b ∈ [s1298], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1298) b1298 <|
    PetersenLocalChildren.nil
theorem b1319 : Blocked tgt 5 s1319 := by
  apply PetersenFastNode.node (nxt := #[s1298]) (hints := [1674,1418,386,1418,5931,5547,6579,5547,7475,7475,1674,7467,2178,7467,1674,5258,4226,1674,5289,5291,5289,5545,386,1418,1418,386,1418,7211,3210,1418,1418,0,5258,1418,6579,5547,5547,6579,5547,3082,7467,5547,1419,1451,5515,1419,1666,7467,2178,7467,1666,5258,4226,5258,3339,3371,7435,3339]) (by decide +kernel)
  change ∀ b ∈ [s1298], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s1298) b1298 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
