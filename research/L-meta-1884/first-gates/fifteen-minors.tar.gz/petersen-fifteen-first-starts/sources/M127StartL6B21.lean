import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b656 : Blocked tgt 6 s656 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s656 6 _ le
  decide +kernel
theorem b657 : Blocked tgt 6 s657 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s657 6 _ le
  decide +kernel
theorem b658 : Blocked tgt 6 s658 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s658 6 _ le
  decide +kernel
theorem b659 : Blocked tgt 6 s659 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s659 6 _ le
  decide +kernel
theorem b660 : Blocked tgt 6 s660 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s660 6 _ le
  decide +kernel
theorem b661 : Blocked tgt 6 s661 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s661 6 _ le
  decide +kernel
theorem b662 : Blocked tgt 6 s662 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s662 6 _ le
  decide +kernel
theorem b663 : Blocked tgt 6 s663 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s663 6 _ le
  decide +kernel
theorem b683 : Blocked tgt 6 s683 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,9609,901,1417,901,1673,5930,1673,5930,1669,1669,12586,7474,3209,2693,3209,2693,5257,4741,5257,4741,773,773,5546,901,5546,1545,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,1418,1450,5514,1418,385,389,897,385,901,7474,1925,901,901,7466,2693,901,901,11060,4741,901,6962,4906,7474,6962,2177,2181,2177,2689,4225,4229,4225,4737,2693,7466,2693,7458,4741,3378,4741,3346,2693,3370,4741,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b684 : Blocked tgt 6 s684 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(false,(1,false),(5,true))] s684 6 _ le
  decide +kernel
theorem b692 : Blocked tgt 6 s692 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(3,false)),(true,(0,false),(2,false))] s692 6 _ le
  decide +kernel
theorem b693 : Blocked tgt 6 s693 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s693 6 _ le
  decide +kernel
theorem b694 : Blocked tgt 6 s694 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s694 6 _ le
  decide +kernel
theorem b695 : Blocked tgt 6 s695 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s695 6 _ le
  decide +kernel
theorem b696 : Blocked tgt 6 s696 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s696 6 _ le
  decide +kernel
theorem b709 : Blocked tgt 6 s709 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s709 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
