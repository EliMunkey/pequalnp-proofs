import M127StartData
import M127StartL7B29
import M127StartL7B4
import M127StartL7B30
import M127StartL7B27
import M127StartL7B31
import M127StartL7B9
import M127StartL7B0
import M127StartL7B5
import M127StartL7B12
import M127StartL7B23
import M127StartL7B13
import M127StartL7B18
import M127StartL7B20
import M127StartL7B24
import M127StartL7B28
import M127StartL7B32
import M127StartL7B33
import M127StartL7B34
import M127StartPins0
import M127StartL7B14
import M127StartL7B10
import M127StartL7B35
import M127StartL7B36
import M127StartL7B37
import M127StartL7B19
import M127StartL7B38
import M127StartL7B39
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b991 : Blocked tgt 8 s991 := by
  apply PetersenFastNode.node (nxt := #[s992,s993,s994,s995,s996,s997,s1018,s217,s1025,s1026,s1030,s1031,s1035,s1036,s1037,s1038,s1041,s1042,s1043,s1044,s1058,s916,s1059,s1060,s1061,s1062,s1074,s1075,s1076,s1077,s414,s17,s263,s1078,s1083,s1084,s505,s1090,s790,s530,s676,s729,s1091,s809,s963,s1092,s1093,s1094,s1104,s1105,s1106,s1107,s1108,s1109,s1114,s1120,s1121,s1124,s1129,s1134,s1137,s1138,s1142,s1147,s1148,s1149,s1150,s1151,s1163,s1164,s1165,s1166,s1167,s1168,s1170,s1171,s1176,s1177,s1178,s1179,s1193,s1194,s1195,s1196,s1197,s1198,s1199,s1200,s1201,s1202,s1203,s1204,s1205,s1206,s1207,s1208]) (hints := [1514,13093,5610,0,1514,1,2,3,13093,13093,11188,4,9253,5,9253,6,11188,7,11188,8,9253,13093,9253,9,13609,13609,1898,10,10025,13093,10025,11,12581,13093,1898,12,10025,13609,10025,13,13093,13093,3442,14,10021,13609,10021,15,12585,13609,3442,16,10021,13093,10021,17,13093,13093,3434,18,11045,19,11045,20,3434,21,3434,22,11045,13093,11045,23,4837,4837,9578,24,13029,13093,25,26,4901,13093,9578,27,4837,4837,28,29,11188,15156,11188,30,9253,5610,9253,31,11188,5610,11188,32,9253,15156,9253,33,1898,5610,1898,34,10025,15156,10025,35,1898,15156,1898,36,10025,5610,10025,37,3442,6642,3442,38,10021,5610,10021,39,3442,5610,3442,40,10021,6642,10021,41,3434,5610,3434,42,11045,6642,11045,43,3434,6642,3434,44,11045,5610,11045,45,5610,5610,9578,46,6964,15156,47,48,9578,15156,9578,49,5610,5610,50,51,9769,9769,10025,52,8741,9253,1898,53,10025,9253,10025,54,9769,9769,1898,55,9253,9253,10021,56,8745,9769,3442,57,10021,9769,10021,58,9253,9253,3442,59,9253,9253,11045,60,9140,11188,3434,61,11045,11188,11045,62,9253,9253,3434,63,997,997,64,65,1061,9253,9578,66,9189,9253,67,68,997,997,9578,69,2930,2930,3442,70,10021,10025,10021,71,10017,10025,3442,72,10017,2930,10021,73,10025,10025,11561,74,10533,2930,11045,75,11561,2930,11561,76,10025,10025,11045,77,1769,1769,9578,78,1833,10025,79,80,9961,10025,9578,81,1769,1769,82,83,10021,10021,11045,84,10537,3442,11561,85,11045,3442,11045,86,10021,10021,11561,87,1765,1765,10610,88,1829,10021,9578,89,9957,10021,10610,90,1765,1765,9578,91,2789,2789,9578,92,2853,11045,10610,93,10981,11045,9578,94,2789,2789,10610,95]) (by decide +kernel)
  change ∀ b ∈ [s992,s993,s994,s995,s996,s997,s1018,s217,s1025,s1026,s1030,s1031,s1035,s1036,s1037,s1038,s1041,s1042,s1043,s1044,s1058,s916,s1059,s1060,s1061,s1062,s1074,s1075,s1076,s1077,s414,s17,s263,s1078,s1083,s1084,s505,s1090,s790,s530,s676,s729,s1091,s809,s963,s1092,s1093,s1094,s1104,s1105,s1106,s1107,s1108,s1109,s1114,s1120,s1121,s1124,s1129,s1134,s1137,s1138,s1142,s1147,s1148,s1149,s1150,s1151,s1163,s1164,s1165,s1166,s1167,s1168,s1170,s1171,s1176,s1177,s1178,s1179,s1193,s1194,s1195,s1196,s1197,s1198,s1199,s1200,s1201,s1202,s1203,s1204,s1205,s1206,s1207,s1208], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s992) b992 <|
    PetersenLocalChildren.push (x := s993) b993 <|
    PetersenLocalChildren.push (x := s994) b994 <|
    PetersenLocalChildren.push (x := s995) b995 <|
    PetersenLocalChildren.push (x := s996) b996 <|
    PetersenLocalChildren.push (x := s997) b997 <|
    PetersenLocalChildren.push (x := s1018) b1018 <|
    PetersenLocalChildren.push (x := s217) b217 <|
    PetersenLocalChildren.push (x := s1025) b1025 <|
    PetersenLocalChildren.push (x := s1026) b1026 <|
    PetersenLocalChildren.push (x := s1030) b1030 <|
    PetersenLocalChildren.push (x := s1031) b1031 <|
    PetersenLocalChildren.push (x := s1035) b1035 <|
    PetersenLocalChildren.push (x := s1036) b1036 <|
    PetersenLocalChildren.push (x := s1037) b1037 <|
    PetersenLocalChildren.push (x := s1038) b1038 <|
    PetersenLocalChildren.push (x := s1041) b1041 <|
    PetersenLocalChildren.push (x := s1042) b1042 <|
    PetersenLocalChildren.push (x := s1043) b1043 <|
    PetersenLocalChildren.push (x := s1044) b1044 <|
    PetersenLocalChildren.push (x := s1058) b1058 <|
    PetersenLocalChildren.push (x := s916) b916 <|
    PetersenLocalChildren.push (x := s1059) b1059 <|
    PetersenLocalChildren.push (x := s1060) b1060 <|
    PetersenLocalChildren.push (x := s1061) b1061 <|
    PetersenLocalChildren.push (x := s1062) b1062 <|
    PetersenLocalChildren.push (x := s1074) b1074 <|
    PetersenLocalChildren.push (x := s1075) b1075 <|
    PetersenLocalChildren.push (x := s1076) b1076 <|
    PetersenLocalChildren.push (x := s1077) b1077 <|
    PetersenLocalChildren.push (x := s414) b414 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.push (x := s263) b263 <|
    PetersenLocalChildren.push (x := s1078) b1078 <|
    PetersenLocalChildren.push (x := s1083) b1083 <|
    PetersenLocalChildren.push (x := s1084) b1084 <|
    PetersenLocalChildren.push (x := s505) b505 <|
    PetersenLocalChildren.push (x := s1090) b1090 <|
    PetersenLocalChildren.push (x := s790) b790 <|
    PetersenLocalChildren.push (x := s530) b530 <|
    PetersenLocalChildren.push (x := s676) b676 <|
    PetersenLocalChildren.push (x := s729) b729 <|
    PetersenLocalChildren.push (x := s1091) b1091 <|
    PetersenLocalChildren.push (x := s809) b809 <|
    PetersenLocalChildren.push (x := s963) b963 <|
    PetersenLocalChildren.push (x := s1092) b1092 <|
    PetersenLocalChildren.push (x := s1093) b1093 <|
    PetersenLocalChildren.push (x := s1094) b1094 <|
    PetersenLocalChildren.push (x := s1104) b1104 <|
    PetersenLocalChildren.push (x := s1105) b1105 <|
    PetersenLocalChildren.push (x := s1106) b1106 <|
    PetersenLocalChildren.push (x := s1107) b1107 <|
    PetersenLocalChildren.push (x := s1108) b1108 <|
    PetersenLocalChildren.push (x := s1109) b1109 <|
    PetersenLocalChildren.push (x := s1114) b1114 <|
    PetersenLocalChildren.push (x := s1120) b1120 <|
    PetersenLocalChildren.push (x := s1121) b1121 <|
    PetersenLocalChildren.push (x := s1124) b1124 <|
    PetersenLocalChildren.push (x := s1129) b1129 <|
    PetersenLocalChildren.push (x := s1134) b1134 <|
    PetersenLocalChildren.push (x := s1137) b1137 <|
    PetersenLocalChildren.push (x := s1138) b1138 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s1147) b1147 <|
    PetersenLocalChildren.push (x := s1148) b1148 <|
    PetersenLocalChildren.push (x := s1149) b1149 <|
    PetersenLocalChildren.push (x := s1150) b1150 <|
    PetersenLocalChildren.push (x := s1151) b1151 <|
    PetersenLocalChildren.push (x := s1163) b1163 <|
    PetersenLocalChildren.push (x := s1164) b1164 <|
    PetersenLocalChildren.push (x := s1165) b1165 <|
    PetersenLocalChildren.push (x := s1166) b1166 <|
    PetersenLocalChildren.push (x := s1167) b1167 <|
    PetersenLocalChildren.push (x := s1168) b1168 <|
    PetersenLocalChildren.push (x := s1170) b1170 <|
    PetersenLocalChildren.push (x := s1171) b1171 <|
    PetersenLocalChildren.push (x := s1176) b1176 <|
    PetersenLocalChildren.push (x := s1177) b1177 <|
    PetersenLocalChildren.push (x := s1178) b1178 <|
    PetersenLocalChildren.push (x := s1179) b1179 <|
    PetersenLocalChildren.push (x := s1193) b1193 <|
    PetersenLocalChildren.push (x := s1194) b1194 <|
    PetersenLocalChildren.push (x := s1195) b1195 <|
    PetersenLocalChildren.push (x := s1196) b1196 <|
    PetersenLocalChildren.push (x := s1197) b1197 <|
    PetersenLocalChildren.push (x := s1198) b1198 <|
    PetersenLocalChildren.push (x := s1199) b1199 <|
    PetersenLocalChildren.push (x := s1200) b1200 <|
    PetersenLocalChildren.push (x := s1201) b1201 <|
    PetersenLocalChildren.push (x := s1202) b1202 <|
    PetersenLocalChildren.push (x := s1203) b1203 <|
    PetersenLocalChildren.push (x := s1204) b1204 <|
    PetersenLocalChildren.push (x := s1205) b1205 <|
    PetersenLocalChildren.push (x := s1206) b1206 <|
    PetersenLocalChildren.push (x := s1207) b1207 <|
    PetersenLocalChildren.push (x := s1208) b1208 <|
    PetersenLocalChildren.nil
theorem b1209 : Blocked tgt 8 s1209 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1209 8 _ le
  decide +kernel
theorem b1210 : Blocked tgt 8 s1210 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1210 8 _ le
  decide +kernel
theorem b1211 : Blocked tgt 8 s1211 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1211 8 _ le
  decide +kernel
theorem b1212 : Blocked tgt 8 s1212 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1212 8 _ le
  decide +kernel
theorem b1213 : Blocked tgt 8 s1213 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1213 8 _ le
  decide +kernel
theorem b1214 : Blocked tgt 8 s1214 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1214 8 _ le
  decide +kernel
theorem b1215 : Blocked tgt 8 s1215 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1215 8 _ le
  decide +kernel
theorem b1216 : Blocked tgt 8 s1216 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1216 8 _ le
  decide +kernel
theorem b1217 : Blocked tgt 8 s1217 := by
  apply PetersenFastNode.node (nxt := #[s1218,s569,s451,s1219,s1220,s1166,s1221,s1222,s1223,s1224,s1225,s1226,s1227,s1228,s1229,s1230,s1231,s1232,s1233,s1234,s1235,s1236,s6,s1237,s1238,s1239,s1240,s1241,s1242,s1243,s1244,s1245,s1246,s1247,s1248,s1249,s1250,s1251,s1252,s1253,s1254,s1255,s1256]) (hints := [15135,15135,15263,9072,5589,9200,15263,5589,15263,15135,15135,9200,5589,5589,5973,9844,15135,9972,5973,15135,5973,5589,5589,9972,6621,6621,16031,5589,5589,9968,5589,5589,16031,6621,6621,9968,6621,6621,0,5589,5589,1,5589,5589,2,6621,6621,3,5589,5589,7509,4573,6621,10992,7509,6621,7509,5589,5589,10992,1461,1461,4,1493,5589,13040,5557,5589,5,1461,1461,13040,5589,5589,13653,6943,15135,6,13653,15135,13653,5589,5589,7,9716,9716,9972,9200,9200,5973,9972,9200,9972,9716,9716,5973,9200,9200,9968,9716,9716,8,9968,9716,9968,9200,9200,9,8684,8684,10,9200,9200,11,9200,9200,12,8684,8684,13,9200,9200,10992,13215,15263,7509,10992,15263,10992,9200,9200,7509,9200,9200,13040,11167,15263,14,13040,15263,13040,9200,9200,15,944,944,16,1008,9200,13653,9136,9200,17,944,944,13653,4949,18,19,9972,9972,20,9968,21,9968,9972,9972,22,7005,21,23,9972,9972,11508,10992,24,10992,11508,25,11508,9972,9972,10992,9972,9972,13556,13040,5973,13040,13556,5973,13556,9972,9972,13040,1716,1716,13653,1780,9972,26,9908,9972,13653,1716,1716,27,9968,9968,22,7517,20,28,9968,9968,10992,11508,16031,11508,10992,16031,10992,9968,9968,11508,9968,9968,13040,13556,16031,13556,13040,16031,13040,9968,9968,13556,1712,1712,14685,1776,9968,13653,9904,9968,14685,1712,1712,13653,10476,29,10476,10992,30,10992,10476,31,10476,10992,32,10992,12524,33,12524,13040,34,13040,12524,35,12524,13040,36,13040,14685,37,14685,13653,38,13653,14685,39,14685,13653,40,13653,10992,10992,13040,3413,7509,41,13040,7509,13040,10992,10992,42,2736,2736,13653,2800,10992,14685,10928,10992,13653,2736,2736,14685,4784,4784,9525,4848,13040,13653,12976,13040,9525,4784,4784,13653]) (by decide +kernel)
  change ∀ b ∈ [s1218,s569,s451,s1219,s1220,s1166,s1221,s1222,s1223,s1224,s1225,s1226,s1227,s1228,s1229,s1230,s1231,s1232,s1233,s1234,s1235,s1236,s6,s1237,s1238,s1239,s1240,s1241,s1242,s1243,s1244,s1245,s1246,s1247,s1248,s1249,s1250,s1251,s1252,s1253,s1254,s1255,s1256], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s1218) b1218 <|
    PetersenLocalChildren.push (x := s569) b569 <|
    PetersenLocalChildren.push (x := s451) b451 <|
    PetersenLocalChildren.push (x := s1219) b1219 <|
    PetersenLocalChildren.push (x := s1220) b1220 <|
    PetersenLocalChildren.push (x := s1166) b1166 <|
    PetersenLocalChildren.push (x := s1221) b1221 <|
    PetersenLocalChildren.push (x := s1222) b1222 <|
    PetersenLocalChildren.push (x := s1223) b1223 <|
    PetersenLocalChildren.push (x := s1224) b1224 <|
    PetersenLocalChildren.push (x := s1225) b1225 <|
    PetersenLocalChildren.push (x := s1226) b1226 <|
    PetersenLocalChildren.push (x := s1227) b1227 <|
    PetersenLocalChildren.push (x := s1228) b1228 <|
    PetersenLocalChildren.push (x := s1229) b1229 <|
    PetersenLocalChildren.push (x := s1230) b1230 <|
    PetersenLocalChildren.push (x := s1231) b1231 <|
    PetersenLocalChildren.push (x := s1232) b1232 <|
    PetersenLocalChildren.push (x := s1233) b1233 <|
    PetersenLocalChildren.push (x := s1234) b1234 <|
    PetersenLocalChildren.push (x := s1235) b1235 <|
    PetersenLocalChildren.push (x := s1236) b1236 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s1237) b1237 <|
    PetersenLocalChildren.push (x := s1238) b1238 <|
    PetersenLocalChildren.push (x := s1239) b1239 <|
    PetersenLocalChildren.push (x := s1240) b1240 <|
    PetersenLocalChildren.push (x := s1241) b1241 <|
    PetersenLocalChildren.push (x := s1242) b1242 <|
    PetersenLocalChildren.push (x := s1243) b1243 <|
    PetersenLocalChildren.push (x := s1244) b1244 <|
    PetersenLocalChildren.push (x := s1245) b1245 <|
    PetersenLocalChildren.push (x := s1246) b1246 <|
    PetersenLocalChildren.push (x := s1247) b1247 <|
    PetersenLocalChildren.push (x := s1248) b1248 <|
    PetersenLocalChildren.push (x := s1249) b1249 <|
    PetersenLocalChildren.push (x := s1250) b1250 <|
    PetersenLocalChildren.push (x := s1251) b1251 <|
    PetersenLocalChildren.push (x := s1252) b1252 <|
    PetersenLocalChildren.push (x := s1253) b1253 <|
    PetersenLocalChildren.push (x := s1254) b1254 <|
    PetersenLocalChildren.push (x := s1255) b1255 <|
    PetersenLocalChildren.push (x := s1256) b1256 <|
    PetersenLocalChildren.nil
theorem b1257 : Blocked tgt 8 s1257 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1257 8 _ le
  decide +kernel
theorem b1258 : Blocked tgt 8 s1258 := by
  apply PetersenFastNode.node (nxt := #[s435,s1259,s700,s1260,s1261,s1262,s1263,s1264,s6,s1265,s1236,s1266,s1267,s1268,s1269,s1270,s1271,s1272,s1273,s1274,s1275,s1276,s1277,s1278,s1279,s1280,s1284,s1285,s1168,s1286,s1287,s1288,s1289,s1293,s1294,s1295,s1299,s1300,s1301,s1302,s1303,s1304,s1324,s1325,s1326,s1327,s1328,s1329]) (hints := [6626,0,6626,5594,1,5594,6626,2,6626,5594,3,5594,9205,4,9205,9721,5,9721,9205,6,9205,9721,7,9721,9977,8,7010,9977,9,10,9973,8,9973,7522,11,12,10997,13,10997,11513,14,11513,10997,15,10997,11513,16,11513,13045,17,13045,13561,18,13561,13045,19,13045,13561,20,13561,14690,21,14690,13658,22,13658,14690,23,14690,13658,24,13658,13592,13592,13720,5338,5594,9721,13720,5594,13720,13592,13592,9721,5594,5594,7010,14628,15140,25,7010,15140,7010,5594,5594,26,6626,6626,16036,5594,5594,9973,5594,5594,16036,6626,6626,9973,5594,5594,7514,11385,6626,11513,7514,6626,7514,5594,5594,11513,1466,1466,27,1498,5594,13561,5562,5594,28,1466,1466,13561,5594,5594,13658,5400,13592,29,13658,13592,13658,5594,5594,30,9721,9721,31,8693,9205,7010,9201,9205,32,9721,9721,7010,9205,9205,9973,9721,9721,33,9721,9721,9973,9205,9205,34,9721,9721,11513,7258,15268,7514,11513,15268,11513,9721,9721,7514,9721,9721,13561,9624,13720,35,13561,13720,13561,9721,9721,36,1465,1465,37,1529,9721,13658,9657,9721,38,1465,1465,13658,7010,7010,12,9973,10,9973,9969,39,40,11513,4946,11513,10485,7010,10997,11513,7010,11513,10993,4946,10997,13561,2882,13561,12533,7010,13045,13561,7010,13561,13041,2882,13045,13658,7010,13658,41,42,43,13658,44,13658,7010,7010,45,9973,9973,10997,11513,16036,11513,10997,16036,10997,11513,9973,11513,9973,9973,13045,13561,16036,13561,13045,16036,13045,13561,9973,13561,1717,1717,14690,13658,9973,13658,9909,9973,14690,13658,1717,13658,11513,11513,13561,3418,7514,46,13561,7514,13561,11513,11513,47,3257,3257,13658,3321,11513,14690,11449,11513,13658,3257,3257,14690,5305,5305,9530,5369,13561,13658,13497,13561,9530,5305,5305,13658]) (by decide +kernel)
  change ∀ b ∈ [s435,s1259,s700,s1260,s1261,s1262,s1263,s1264,s6,s1265,s1236,s1266,s1267,s1268,s1269,s1270,s1271,s1272,s1273,s1274,s1275,s1276,s1277,s1278,s1279,s1280,s1284,s1285,s1168,s1286,s1287,s1288,s1289,s1293,s1294,s1295,s1299,s1300,s1301,s1302,s1303,s1304,s1324,s1325,s1326,s1327,s1328,s1329], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s435) b435 <|
    PetersenLocalChildren.push (x := s1259) b1259 <|
    PetersenLocalChildren.push (x := s700) b700 <|
    PetersenLocalChildren.push (x := s1260) b1260 <|
    PetersenLocalChildren.push (x := s1261) b1261 <|
    PetersenLocalChildren.push (x := s1262) b1262 <|
    PetersenLocalChildren.push (x := s1263) b1263 <|
    PetersenLocalChildren.push (x := s1264) b1264 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s1265) b1265 <|
    PetersenLocalChildren.push (x := s1236) b1236 <|
    PetersenLocalChildren.push (x := s1266) b1266 <|
    PetersenLocalChildren.push (x := s1267) b1267 <|
    PetersenLocalChildren.push (x := s1268) b1268 <|
    PetersenLocalChildren.push (x := s1269) b1269 <|
    PetersenLocalChildren.push (x := s1270) b1270 <|
    PetersenLocalChildren.push (x := s1271) b1271 <|
    PetersenLocalChildren.push (x := s1272) b1272 <|
    PetersenLocalChildren.push (x := s1273) b1273 <|
    PetersenLocalChildren.push (x := s1274) b1274 <|
    PetersenLocalChildren.push (x := s1275) b1275 <|
    PetersenLocalChildren.push (x := s1276) b1276 <|
    PetersenLocalChildren.push (x := s1277) b1277 <|
    PetersenLocalChildren.push (x := s1278) b1278 <|
    PetersenLocalChildren.push (x := s1279) b1279 <|
    PetersenLocalChildren.push (x := s1280) b1280 <|
    PetersenLocalChildren.push (x := s1284) b1284 <|
    PetersenLocalChildren.push (x := s1285) b1285 <|
    PetersenLocalChildren.push (x := s1168) b1168 <|
    PetersenLocalChildren.push (x := s1286) b1286 <|
    PetersenLocalChildren.push (x := s1287) b1287 <|
    PetersenLocalChildren.push (x := s1288) b1288 <|
    PetersenLocalChildren.push (x := s1289) b1289 <|
    PetersenLocalChildren.push (x := s1293) b1293 <|
    PetersenLocalChildren.push (x := s1294) b1294 <|
    PetersenLocalChildren.push (x := s1295) b1295 <|
    PetersenLocalChildren.push (x := s1299) b1299 <|
    PetersenLocalChildren.push (x := s1300) b1300 <|
    PetersenLocalChildren.push (x := s1301) b1301 <|
    PetersenLocalChildren.push (x := s1302) b1302 <|
    PetersenLocalChildren.push (x := s1303) b1303 <|
    PetersenLocalChildren.push (x := s1304) b1304 <|
    PetersenLocalChildren.push (x := s1324) b1324 <|
    PetersenLocalChildren.push (x := s1325) b1325 <|
    PetersenLocalChildren.push (x := s1326) b1326 <|
    PetersenLocalChildren.push (x := s1327) b1327 <|
    PetersenLocalChildren.push (x := s1328) b1328 <|
    PetersenLocalChildren.push (x := s1329) b1329 <|
    PetersenLocalChildren.nil
theorem b1330 : Blocked tgt 8 s1330 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1330 8 _ le
  decide +kernel
theorem b1331 : Blocked tgt 8 s1331 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1331 8 _ le
  decide +kernel
theorem b1332 : Blocked tgt 8 s1332 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1332 8 _ le
  decide +kernel
theorem b1333 : Blocked tgt 8 s1333 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1333 8 _ le
  decide +kernel
end PetersenSmallStarts.M127
