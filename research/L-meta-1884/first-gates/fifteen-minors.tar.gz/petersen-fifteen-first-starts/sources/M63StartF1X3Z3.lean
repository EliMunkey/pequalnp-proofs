import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_3 : NoAtMost (0xcc00cc00cc00cc00 :: inputs 6) tgt 7 := by
  change NoAtMost [0xcc00cc00cc00cc00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s893] [194,716,195,195,196,716,835,835,390,716,455,455,196,716,839,839,714,716,715,843,716,716,843,843,390,716,455,455,716,716,1351,1351,1106,716,195,195,1236,716,835,835,1366,716,455,455,1236,716,839,839,714,716,715,843,716,716,843,843,1366,716,455,455,716,716,2375,2375,2146,2796,195,195,2276,2796,835,835,2406,2796,455,455,2276,2796,839,839,2666,2796,715,843,2796,2796,843,843,2406,2796,455,455,2796,2796,1351,1351,3186,2796,195,195,3316,2796,835,835,3446,2796,455,455,3316,2796,839,839,2666,2796,715,843,2796,2796,843,843,3446,2796,455,455,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s893], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s893) b893 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_3
end PetersenSmallStarts.M63
