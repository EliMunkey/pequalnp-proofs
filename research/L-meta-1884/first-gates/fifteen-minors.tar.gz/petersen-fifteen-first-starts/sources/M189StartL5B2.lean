import M189StartData
import M189StartPins0
import M189StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b207 : Blocked tgt 5 s207 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s207 5 _ le
  decide +kernel
theorem b208 : Blocked tgt 5 s208 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,1219,714,3364,3429,2533,1091,2533,1219,451,3173,451,707,707,772,1219,1219,2243,1381,1219,2468,2469,2468,2532,2664,451,2856,451,2852,2853,2852,2916,2179,2179,2664,2243,2273,2277,2529,2273,2533,2216,2917,2533,453,485,2501,453,451,2661,2657,451,451,2856,2243,451,2243,2917,2243,2755]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b212 : Blocked tgt 5 s212 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [387,387,1364,451,1364,2469,1428,1364,1364,1234,3364,3365,3364,3428,1364,2243,3348,1364,2273,2277,2273,2529,451,1426,451,3173,1219,451,451,3348,2243,451,1616,2533,2533,1744,2533,1091,3429,2533,453,485,2501,453,706,3429,1730,3429,1746,2243,3218,2243,1349,1381,3397,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b213 : Blocked tgt 5 s213 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s213 5 _ le
  decide +kernel
theorem b217 : Blocked tgt 5 s217 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s217 5 _ le
  decide +kernel
theorem b218 : Blocked tgt 5 s218 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1234,2657,2273,579,2273,707,451,1426,451,707,1219,3104,707,707,2243,609,707,1616,2273,1744,2273,1426,451,1426,451,706,1219,1730,1219,1746,2243,3218,2243,2273,451,2529,2273,2273,1091,3169,2273,3088,2243,2241,2241,451,402,1219,451,451,800,2243,451,1219,1121,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b224 : Blocked tgt 5 s224 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1816,1818,1816,1944,1428,2216,1812,1428,2468,404,3364,2468,1428,484,2437,1428,1364,2468,1364,1428,1426,1434,1938,1426,906,922,1930,906,1946,2856,2179,1946,1626,387,1626,1882,579,788,1219,579,579,2852,2179,579,1234,1242,1234,1618,1219,1380,2179,1219,586,602,586,1610,1626,3674]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b225 : Blocked tgt 5 s225 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s225 5 _ le
  decide +kernel
theorem b229 : Blocked tgt 5 s229 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s229 5 _ le
  decide +kernel
theorem b230 : Blocked tgt 5 s230 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s230 5 _ le
  decide +kernel
theorem b234 : Blocked tgt 5 s234 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s234 5 _ le
  decide +kernel
theorem b235 : Blocked tgt 5 s235 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s235 5 _ le
  decide +kernel
theorem b236 : Blocked tgt 5 s236 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s236 5 _ le
  decide +kernel
theorem b237 : Blocked tgt 5 s237 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s237 5 _ le
  decide +kernel
theorem b238 : Blocked tgt 5 s238 := by
  apply PetersenFastNode.node (nxt := #[s239]) (hints := [1817,1819,1817,1945,1429,2217,1813,1429,2469,405,3365,2469,1429,485,2438,1429,1365,2469,1365,1429,1427,1435,1939,1427,907,923,1931,907,1947,617,2180,1947,1947,388,1755,1755,1220,789,1220,2661,2180,613,2180,2692,1235,1243,1235,1621,1220,1381,2180,1220,0,1220,1219,1219,3739,3739]) (by decide +kernel)
  change ∀ b ∈ [s239], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s239) b239 <|
    PetersenLocalChildren.nil
theorem b240 : Blocked tgt 5 s240 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s240 5 _ le
  decide +kernel
end PetersenSmallStarts.M189
