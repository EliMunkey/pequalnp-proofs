import M55StartData
import M55StartL4B1
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_4_1 : NoAtMost (0xff00 :: inputs 5) tgt 4 := by
  change NoAtMost [0xff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s30,s0,s31] [99,299,100,459,101,365,292,461,199,431,232,463,101,365,424,680,299,299,100,459,365,365,548,461,431,431,232,463,365,365,680,680,563,299,100,459,629,365,292,461,695,431,232,463,629,365,424,0,827,299,100,459,893,365,989,461,959,431,232,463,893,365,1,2] (by decide +kernel)
  change ∀ b ∈ [s30,s0,s31], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.nil
#print axioms gate_3_4_1
end PetersenSmallStarts.M55
