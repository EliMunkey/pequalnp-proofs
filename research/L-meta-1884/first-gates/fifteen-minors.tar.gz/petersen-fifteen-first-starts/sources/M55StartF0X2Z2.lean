import M55StartData
import M55StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_2 : NoAtMost (0x50505050 :: inputs 5) tgt 4 := by
  change NoAtMost [0x50505050,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s6,s0,s8] [99,199,100,199,101,101,292,292,199,199,232,199,101,101,424,424,299,463,100,463,365,365,548,548,431,463,232,463,365,365,680,680,563,727,100,727,629,629,292,292,695,727,232,727,629,629,424,424,827,991,100,991,893,893,989,0,959,991,232,991,893,893,1,2] (by decide +kernel)
  change ∀ b ∈ [s6,s0,s8], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_2
end PetersenSmallStarts.M55
