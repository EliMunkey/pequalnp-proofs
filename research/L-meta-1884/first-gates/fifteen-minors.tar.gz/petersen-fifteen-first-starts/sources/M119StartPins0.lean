import M119StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 16) : Fin 64 := (#[0,1,2,3,16,17,18,19,32,33,34,35,48,49,50,51] : Array (Fin 64))[x.val]?.getD 0
theorem small0 : NoAtMost i4 (PetersenPackedPin.project r0 tgt) 3 := by
  have a : PetersenPackedPin.project r0 tgt = table 99 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 99 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r9 (x : Fin 4) : Fin 64 := (#[2,6,34,38] : Array (Fin 64))[x.val]?.getD 0
theorem small9 : NoAtMost i2 (PetersenPackedPin.project r9 tgt) 0 := by
  have a : PetersenPackedPin.project r9 tgt = table 68 2 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 68 2 (by decide +kernel) (by decide +kernel)
theorem hot9 : forcedConst r9 tgt = false := by decide +kernel
end PetersenSmallStarts.M119
