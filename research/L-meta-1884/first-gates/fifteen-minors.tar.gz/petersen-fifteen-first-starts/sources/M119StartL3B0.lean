import M119StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b11 : Blocked tgt 3 s11 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,194,837,453,388,453,577,833,581,577,388,453,388,453,386,580,386,706,193,197,449,193]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M119
