import M111StartData
import M111StartL6B0
import M111StartL6B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_5_2 : NoAtMost (0xff00ff00000000 :: inputs 6) tgt 6 := by
  change NoAtMost [0xff00ff00000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s145] [194,2210,195,2275,196,3170,835,3171,390,2470,455,2535,196,3430,839,3431,714,2210,715,2275,716,3170,843,3171,390,2470,455,2535,716,3430,1351,3431,1106,3186,195,2275,1236,3186,835,835,1366,3446,455,2535,1236,3446,839,839,1626,3186,715,2275,1756,3186,843,843,1366,3446,455,2535,1756,3446,3740,3740,2210,2210,2275,2275,196,3170,2915,3171,2470,2470,2535,2535,196,3430,2919,3431,2730,2210,2795,2275,716,3170,2923,3171,2470,2470,2535,2535,716,3430,3431,3431,3186,3186,2275,2275,1236,3186,2915,2923,3446,3446,2535,2535,1236,3446,2919,839,3706,3186,2795,2275,1756,3186,2923,2923,3446,3446,2535,2535,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s145], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s145) b145 <|
    PetersenLocalChildren.nil
#print axioms gate_3_5_2
end PetersenSmallStarts.M111
