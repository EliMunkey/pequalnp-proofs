import M31StartData
import M31StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b72 : Blocked tgt 4 s72 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s72 4 _ le
  decide +kernel
theorem b80 : Blocked tgt 4 s80 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s80 4 _ le
  decide +kernel
theorem b81 : Blocked tgt 4 s81 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s81 4 _ le
  decide +kernel
theorem b82 : Blocked tgt 4 s82 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s82 4 _ le
  decide +kernel
theorem b83 : Blocked tgt 4 s83 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s83 4 _ le
  decide +kernel
theorem b84 : Blocked tgt 4 s84 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s84 4 _ le
  decide +kernel
theorem b85 : Blocked tgt 4 s85 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s85 4 _ le
  decide +kernel
theorem b90 : Blocked tgt 4 s90 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s90 4 _ le
  decide +kernel
theorem b96 : Blocked tgt 4 s96 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [196,361,196,360,362,393,98,106,354,98,362,777,842,362,361,394,392,361,97,105,353,97,361,778,809,361,194,202,450,194,809,676,809,458,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M31
