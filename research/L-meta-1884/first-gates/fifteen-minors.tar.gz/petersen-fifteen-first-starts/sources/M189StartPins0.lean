import M189StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 64) : Fin 64 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63] : Array (Fin 64))[x.val]?.getD 0
theorem small0 : NoAtMost i6 (PetersenPackedPin.project r0 tgt) 7 := by
  have a : PetersenPackedPin.project r0 tgt = table 189 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 189 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 16) : Fin 64 := (#[0,2,4,6,16,18,20,22,32,34,36,38,48,50,52,54] : Array (Fin 64))[x.val]?.getD 0
theorem small1 : NoAtMost i4 (PetersenPackedPin.project r1 tgt) 3 := by
  have a : PetersenPackedPin.project r1 tgt = table 172 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 172 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r2 (x : Fin 16) : Fin 64 := (#[0,2,4,6,8,10,12,14,32,34,36,38,40,42,44,46] : Array (Fin 64))[x.val]?.getD 0
theorem small2 : NoAtMost i4 (PetersenPackedPin.project r2 tgt) 3 := by
  have a : PetersenPackedPin.project r2 tgt = table 156 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 156 0 (by decide +kernel) (by decide +kernel)
theorem hot2 : forcedConst r2 tgt = false := by decide +kernel
def r4 (x : Fin 16) : Fin 64 := (#[0,1,8,9,16,17,24,25,32,33,40,41,48,49,56,57] : Array (Fin 64))[x.val]?.getD 0
theorem small4 : NoAtMost i4 (PetersenPackedPin.project r4 tgt) 3 := by
  have a : PetersenPackedPin.project r4 tgt = table 177 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 177 0 (by decide +kernel) (by decide +kernel)
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
def r5 (x : Fin 16) : Fin 64 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29] : Array (Fin 64))[x.val]?.getD 0
theorem small5 : NoAtMost i4 (PetersenPackedPin.project r5 tgt) 3 := by
  have a : PetersenPackedPin.project r5 tgt = table 57 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 57 0 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
def r7 (x : Fin 16) : Fin 64 := (#[0,1,2,3,16,17,18,19,32,33,34,35,48,49,50,51] : Array (Fin 64))[x.val]?.getD 0
theorem small7 : NoAtMost i4 (PetersenPackedPin.project r7 tgt) 3 := by
  have a : PetersenPackedPin.project r7 tgt = table 165 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 165 0 (by decide +kernel) (by decide +kernel)
theorem hot7 : forcedConst r7 tgt = false := by decide +kernel
end PetersenSmallStarts.M189
