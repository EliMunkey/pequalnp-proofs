import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL6B19
import M127StartL6B20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b610 : Blocked tgt 7 s610 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s610 7 _ le
  decide +kernel
theorem b611 : Blocked tgt 7 s611 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s611 7 _ le
  decide +kernel
theorem b612 : Blocked tgt 7 s612 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s612 7 _ le
  decide +kernel
theorem b613 : Blocked tgt 7 s613 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s613 7 _ le
  decide +kernel
theorem b614 : Blocked tgt 7 s614 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s614 7 _ le
  decide +kernel
theorem b615 : Blocked tgt 7 s615 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s615 7 _ le
  decide +kernel
theorem b617 : Blocked tgt 7 s617 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s617 7 _ le
  decide +kernel
theorem b618 : Blocked tgt 7 s618 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s618 7 _ le
  decide +kernel
theorem b619 : Blocked tgt 7 s619 := by
  apply PetersenFastNode.node (nxt := #[s620,s621,s622]) (hints := [9032,9032,5549,9160,13547,5549,5549,15095,5549,9804,5933,5549,6581,4525,7477,6581,5549,4533,7469,5549,1421,1453,5517,1421,5549,5355,13613,5549,9160,9676,8644,8648,9156,8644,9160,7477,10184,9160,9160,7469,10952,9160,9160,0,13000,9160,904,968,9096,904,9932,5933,9932,5933,9928,9928,15991,7477,11468,10952,11468,10952,13516,13000,13516,13000,1,13613,2,13613,6965,9932,9932,6965,10436,10440,10436,10948,12484,12488,12484,12996,1676,1740,9868,1676,10952,11468,10952,11468,13000,13516,13000,13516,7477,12589,14645,7477,10952,3373,13000,10952,2696,2760,10888,2696,4744,4808,12936,4744]) (by decide +kernel)
  change ∀ b ∈ [s620,s621,s622], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s620) b620 <|
    PetersenLocalChildren.push (x := s621) b621 <|
    PetersenLocalChildren.push (x := s622) b622 <|
    PetersenLocalChildren.nil
theorem b623 : Blocked tgt 7 s623 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s623 7 _ le
  decide +kernel
theorem b624 : Blocked tgt 7 s624 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s624 7 _ le
  decide +kernel
theorem b625 : Blocked tgt 7 s625 := by
  apply PetersenFastNode.node (nxt := #[s626,s627,s628,s629,s630,s631,s632,s633,s634,s635,s636,s637]) (hints := [14592,14592,15232,8653,5558,8653,14848,5558,15232,14592,14592,8653,5558,5558,5942,9813,14592,9941,5942,14592,5942,5558,5558,9941,7486,14592,7486,5558,5558,9933,7486,5558,7486,7614,14592,9933,5558,5558,7478,12544,14592,10445,7478,14592,7478,5558,5558,10445,1430,1430,0,1462,5558,12493,5526,5558,1,1430,1430,12493,5558,5558,13622,6400,14592,2,13622,14592,13622,5558,5558,3,9685,9685,9941,8653,8653,5942,9941,8653,9941,9685,9685,5942,8653,8653,9933,9685,9685,7486,9933,9685,9933,8653,8653,7486,8653,8653,10445,13184,15232,7478,10445,15232,10445,8653,8653,7478,8653,8653,12493,11136,15232,4,12493,15232,12493,8653,8653,5,397,397,6,461,8653,13622,8589,8653,7,397,397,13622,6974,6974,7486,9933,9941,9933,9941,9941,7486,9933,6974,9933,9941,9941,11477,10445,6974,10445,11477,6974,11477,9941,9941,10445,9941,9941,13525,12493,5942,12493,13525,5942,13525,9941,9941,12493,1685,1685,13622,1749,9941,8,9877,9941,13622,1685,1685,9,9933,9933,10445,11477,7486,11477,10445,7486,10445,9933,9933,11477,9933,9933,12493,13525,7486,13525,12493,7486,12493,9933,9933,13525,1677,1677,14654,1741,9933,13622,9869,9933,14654,1677,1677,13622,10445,10445,12493,3382,7478,10,12493,7478,12493,10445,10445,11,2189,2189,13622,2253,10445,14654,10381,10445,13622,2189,2189,14654,4237,4237,9494,4301,12493,13622,12429,12493,9494,4237,4237,13622]) (by decide +kernel)
  change ∀ b ∈ [s626,s627,s628,s629,s630,s631,s632,s633,s634,s635,s636,s637], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s626) b626 <|
    PetersenLocalChildren.push (x := s627) b627 <|
    PetersenLocalChildren.push (x := s628) b628 <|
    PetersenLocalChildren.push (x := s629) b629 <|
    PetersenLocalChildren.push (x := s630) b630 <|
    PetersenLocalChildren.push (x := s631) b631 <|
    PetersenLocalChildren.push (x := s632) b632 <|
    PetersenLocalChildren.push (x := s633) b633 <|
    PetersenLocalChildren.push (x := s634) b634 <|
    PetersenLocalChildren.push (x := s635) b635 <|
    PetersenLocalChildren.push (x := s636) b636 <|
    PetersenLocalChildren.push (x := s637) b637 <|
    PetersenLocalChildren.nil
theorem b638 : Blocked tgt 7 s638 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s638 7 _ le
  decide +kernel
theorem b639 : Blocked tgt 7 s639 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s639 7 _ le
  decide +kernel
theorem b640 : Blocked tgt 7 s640 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s640 7 _ le
  decide +kernel
theorem b641 : Blocked tgt 7 s641 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s641 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
