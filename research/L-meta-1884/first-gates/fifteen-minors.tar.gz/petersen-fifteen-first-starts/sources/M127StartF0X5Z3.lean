import M127StartData
import M127StartL8B1
import M127StartL8B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_3 : NoAtMost (0xaaaaaaaa00000000aaaaaaaa00000000 :: inputs 7) tgt 8 := by
  change NoAtMost [0xaaaaaaaa00000000aaaaaaaa00000000,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 8
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s1211,s0,s1212] [387,387,388,388,389,389,1668,1668,775,775,904,904,389,389,1672,1672,1419,1419,1420,1420,1421,1421,1676,1676,775,775,904,904,1421,1421,2696,2696,2195,2195,388,388,2453,2453,1668,1668,2711,2711,904,904,2453,2453,1672,1672,1419,1419,1420,1420,1421,1421,1676,1676,2711,2711,904,904,1421,1421,4744,9485,4259,4899,388,388,4517,4901,1668,1668,4775,4903,904,904,4517,7461,1672,1672,5291,5675,1420,1420,5549,5933,1676,1676,4775,4903,904,904,5549,7469,2696,2696,6323,6963,388,388,6581,6965,1668,1668,6839,6967,904,904,6581,7477,1672,1672,5291,5675,1420,1420,5549,5933,1676,1676,6839,6967,904,904,5549,13613,13613,13613,8515,8515,8644,8644,389,389,9924,9924,9031,9031,9160,9160,389,389,9928,9928,9547,9547,9676,9676,1421,1421,9932,9932,9031,9031,9160,9160,1421,1421,10952,10952,10451,10451,8644,8644,2453,2453,9924,9924,10967,10967,9160,9160,2453,2453,9928,9928,9547,9547,9676,9676,1421,1421,9932,9932,10967,10967,9160,9160,1421,1421,13000,0,12515,12643,8644,8644,4517,4901,9924,9924,13031,13159,9160,9160,4517,7461,9928,9928,13547,13675,9676,9676,5549,5933,9932,9932,13031,13159,9160,9160,5549,7469,10952,10952,14579,14707,8644,8644,6581,6965,9924,9924,15095,15223,9160,9160,6581,7477,9928,9928,13547,13675,9676,9676,5549,5933,9932,9932,15095,15223,9160,9160,5549,1421,1,2] (by decide +kernel)
  change ∀ b ∈ [s1211,s0,s1212], Blocked tgt 8 b
  exact 
    PetersenLocalChildren.push (x := s1211) b1211 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1212) b1212 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_3
end PetersenSmallStarts.M127
