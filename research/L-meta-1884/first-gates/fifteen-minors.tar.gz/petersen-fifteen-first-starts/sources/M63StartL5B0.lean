import M63StartData
import M63StartL4B0
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b9 : Blocked tgt 5 s9 := by
  apply PetersenFastNode.node (nxt := #[s10]) (hints := [778,778,1461,842,0,1461,1461,715,1461,774,1973,1461,421,437,1445,421,1365,1397,1429,1365,715,907,1683,838,834,834,842,1094,1610,842,714,198,714,842,1235,838,1683,838,715,1350,1675,1350,1107,390,715,390,838,1098,1350,838,390,202,390,838,390,1675,390,1350]) (by decide +kernel)
  change ∀ b ∈ [s10], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.nil
theorem b11 : Blocked tgt 5 s11 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s11 5 _ le
  decide +kernel
theorem b13 : Blocked tgt 5 s13 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s13 5 _ le
  decide +kernel
theorem b16 : Blocked tgt 5 s16 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s16 5 _ le
  decide +kernel
theorem b17 : Blocked tgt 5 s17 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s17 5 _ le
  decide +kernel
theorem b20 : Blocked tgt 5 s20 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s20 5 _ le
  decide +kernel
theorem b21 : Blocked tgt 5 s21 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s21 5 _ le
  decide +kernel
theorem b23 : Blocked tgt 5 s23 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s23 5 _ le
  decide +kernel
theorem b25 : Blocked tgt 5 s25 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s25 5 _ le
  decide +kernel
theorem b26 : Blocked tgt 5 s26 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s26 5 _ le
  decide +kernel
theorem b27 : Blocked tgt 5 s27 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s27 5 _ le
  decide +kernel
theorem b28 : Blocked tgt 5 s28 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s28 5 _ le
  decide +kernel
theorem b29 : Blocked tgt 5 s29 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s29 5 _ le
  decide +kernel
theorem b30 : Blocked tgt 5 s30 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s30 5 _ le
  decide +kernel
theorem b31 : Blocked tgt 5 s31 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s31 5 _ le
  decide +kernel
theorem b32 : Blocked tgt 5 s32 := by
  apply PetersenFastNode.node (nxt := #[s33,s34]) (hints := [716,779,908,716,775,775,1684,839,1462,1526,716,1351,1676,1351,391,391,714,455,1428,839,835,835,0,843,843,1458,843,1095,1611,843,715,199,715,843,839,1974,839,1099,1351,839,455,203,455,839,422,1351,1446,1351,1,455,1430,455,455,1548,455,1351]) (by decide +kernel)
  change ∀ b ∈ [s33,s34], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s33) b33 <|
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
