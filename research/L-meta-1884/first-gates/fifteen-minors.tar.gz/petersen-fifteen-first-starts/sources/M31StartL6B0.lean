import M31StartData
import M31StartPins0
import M31StartL5B0
import M31StartL5B1
import M31StartL5B2
import M31StartL5B3
import M31StartL5B4
import M31StartL5B5
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 6 s0 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s0 6 _ le
  decide +kernel
theorem b1 : Blocked tgt 6 s1 := by
  apply PetersenFastNode.node (nxt := #[s2,s3,s4,s5,s6,s7,s8,s10,s11,s12,s14,s15,s16,s18,s19,s20,s21,s26,s27,s28,s29,s31,s32]) (hints := [220,0,1,385,385,2,252,3,252,385,385,4,715,3,5,385,385,481,448,6,448,481,7,481,385,385,448,649,649,873,129,385,444,873,385,873,649,649,444,385,385,865,137,649,700,865,649,865,385,385,700,252,252,4,747,2,8,384,384,448,124,252,481,448,252,448,384,384,481,252,252,444,128,384,873,444,384,444,252,252,873,252,252,700,865,9,865,700,10,700,252,252,865,415,11,415,448,12,448,415,13,415,448,14,448,939,15,939,444,16,444,939,17,939,444,18,444,799,19,799,700,20,700,799,21,799,700,22,700,745,745,873,444,448,444,440,448,873,440,745,444,448,448,832,572,745,700,832,745,832,448,448,700,444,444,700,576,873,832,700,873,700,444,444,832]) (by decide +kernel)
  change ∀ b ∈ [s2,s3,s4,s5,s6,s7,s8,s10,s11,s12,s14,s15,s16,s18,s19,s20,s21,s26,s27,s28,s29,s31,s32], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s2) b2 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s5) b5 <|
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.push (x := s8) b8 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.push (x := s15) b15 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.nil
theorem b33 : Blocked tgt 6 s33 := by
  apply PetersenFastNode.node (nxt := #[s6,s34,s35,s36,s4,s37,s38,s39,s40,s41,s42,s45,s46,s47,s48,s49,s50,s51,s52,s53,s56,s57,s60,s61,s64]) (hints := [387,0,387,717,1,2,254,0,749,254,3,4,483,5,483,450,6,450,483,7,483,450,8,450,875,9,875,446,10,446,875,11,875,446,12,446,867,13,867,702,14,702,867,15,867,702,16,702,749,2,749,387,387,4,781,17,18,387,387,483,450,19,450,483,20,483,450,387,450,651,651,875,446,387,446,875,387,875,446,651,446,387,387,867,702,651,702,867,651,867,702,387,702,450,21,450,419,749,483,450,749,450,481,22,483,446,749,446,811,23,875,446,24,446,749,749,875,702,221,702,237,749,867,702,749,702,221,221,867,747,747,875,446,450,446,442,450,875,442,747,446,450,450,834,574,747,702,834,747,834,450,450,702,446,446,702,578,875,834,702,875,702,446,446,834]) (by decide +kernel)
  change ∀ b ∈ [s6,s34,s35,s36,s4,s37,s38,s39,s40,s41,s42,s45,s46,s47,s48,s49,s50,s51,s52,s53,s56,s57,s60,s61,s64], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.push (x := s41) b41 <|
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s46) b46 <|
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s48) b48 <|
    PetersenLocalChildren.push (x := s49) b49 <|
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.push (x := s56) b56 <|
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s60) b60 <|
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s64) b64 <|
    PetersenLocalChildren.nil
theorem b65 : Blocked tgt 6 s65 := by
  apply PetersenFastNode.node (nxt := #[s6,s66,s67,s68,s69,s39,s70,s71,s73,s74,s75,s76,s77,s78,s79,s86,s87,s88,s89,s91,s92,s10,s56,s93,s94,s95,s97,s98,s99]) (hints := [391,0,721,391,1,2,258,3,258,390,4,390,258,5,258,390,6,390,454,0,487,454,7,8,450,9,450,10,11,12,450,13,450,14,15,16,706,17,706,838,18,838,706,19,706,838,20,838,721,721,753,390,21,390,753,22,753,390,721,390,487,2,487,721,721,8,519,23,24,879,721,879,418,25,450,879,26,879,721,721,450,871,27,871,838,721,838,871,721,871,838,28,838,390,390,421,258,258,487,258,258,421,390,390,487,126,126,450,134,390,879,382,390,450,126,126,879,390,390,838,241,753,871,838,753,838,390,390,871,751,751,879,450,487,450,879,487,879,450,751,450,838,487,838,706,751,706,838,751,838,706,487,706,574,450,574,582,879,838,574,879,574,830,450,838]) (by decide +kernel)
  change ∀ b ∈ [s6,s66,s67,s68,s69,s39,s70,s71,s73,s74,s75,s76,s77,s78,s79,s86,s87,s88,s89,s91,s92,s10,s56,s93,s94,s95,s97,s98,s99], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s66) b66 <|
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s68) b68 <|
    PetersenLocalChildren.push (x := s69) b69 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s70) b70 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.push (x := s73) b73 <|
    PetersenLocalChildren.push (x := s74) b74 <|
    PetersenLocalChildren.push (x := s75) b75 <|
    PetersenLocalChildren.push (x := s76) b76 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.push (x := s78) b78 <|
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.push (x := s86) b86 <|
    PetersenLocalChildren.push (x := s87) b87 <|
    PetersenLocalChildren.push (x := s88) b88 <|
    PetersenLocalChildren.push (x := s89) b89 <|
    PetersenLocalChildren.push (x := s91) b91 <|
    PetersenLocalChildren.push (x := s92) b92 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s56) b56 <|
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.push (x := s95) b95 <|
    PetersenLocalChildren.push (x := s97) b97 <|
    PetersenLocalChildren.push (x := s98) b98 <|
    PetersenLocalChildren.push (x := s99) b99 <|
    PetersenLocalChildren.nil
theorem b100 : Blocked tgt 6 s100 := by
  apply PetersenFastNode.node (nxt := #[s6,s101,s67,s102,s103,s37,s104,s105,s106,s107,s108,s109,s110,s111,s112,s113,s114,s115,s116]) (hints := [381,0,381,711,1,2,380,3,380,248,4,248,380,5,380,248,6,248,444,0,477,444,7,8,869,9,869,440,10,440,869,11,869,440,12,440,828,13,828,696,14,696,828,15,828,696,16,696,743,579,743,248,381,248,743,381,743,248,579,248,412,17,18,477,2,477,381,381,8,645,645,869,440,381,440,869,381,869,440,645,440,381,381,861,696,645,696,861,645,861,696,381,696,380,380,411,248,248,477,248,248,411,380,380,477,248,248,440,124,380,869,440,380,440,248,248,869,248,248,696,231,743,861,696,743,696,248,248,861,741,741,869,440,477,440,869,477,869,440,741,440,828,477,828,696,741,696,828,741,828,696,477,696,440,440,696,572,869,828,696,869,696,440,440,828]) (by decide +kernel)
  change ∀ b ∈ [s6,s101,s67,s102,s103,s37,s104,s105,s106,s107,s108,s109,s110,s111,s112,s113,s114,s115,s116], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s6) b6 <|
    PetersenLocalChildren.push (x := s101) b101 <|
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s102) b102 <|
    PetersenLocalChildren.push (x := s103) b103 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s104) b104 <|
    PetersenLocalChildren.push (x := s105) b105 <|
    PetersenLocalChildren.push (x := s106) b106 <|
    PetersenLocalChildren.push (x := s107) b107 <|
    PetersenLocalChildren.push (x := s108) b108 <|
    PetersenLocalChildren.push (x := s109) b109 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s111) b111 <|
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.push (x := s113) b113 <|
    PetersenLocalChildren.push (x := s114) b114 <|
    PetersenLocalChildren.push (x := s115) b115 <|
    PetersenLocalChildren.push (x := s116) b116 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M31
