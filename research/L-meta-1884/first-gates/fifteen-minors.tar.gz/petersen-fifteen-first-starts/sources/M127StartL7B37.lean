import M127StartData
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1254 : Blocked tgt 7 s1254 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1254 7 _ le
  decide +kernel
theorem b1255 : Blocked tgt 7 s1255 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1255 7 _ le
  decide +kernel
theorem b1256 : Blocked tgt 7 s1256 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1256 7 _ le
  decide +kernel
theorem b1259 : Blocked tgt 7 s1259 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1259 7 _ le
  decide +kernel
theorem b1260 : Blocked tgt 7 s1260 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1260 7 _ le
  decide +kernel
theorem b1261 : Blocked tgt 7 s1261 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1261 7 _ le
  decide +kernel
theorem b1262 : Blocked tgt 7 s1262 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1262 7 _ le
  decide +kernel
theorem b1263 : Blocked tgt 7 s1263 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1263 7 _ le
  decide +kernel
theorem b1264 : Blocked tgt 7 s1264 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1264 7 _ le
  decide +kernel
theorem b1265 : Blocked tgt 7 s1265 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1265 7 _ le
  decide +kernel
theorem b1266 : Blocked tgt 7 s1266 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1266 7 _ le
  decide +kernel
theorem b1267 : Blocked tgt 7 s1267 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1267 7 _ le
  decide +kernel
theorem b1268 : Blocked tgt 7 s1268 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s1268 7 _ le
  decide +kernel
theorem b1269 : Blocked tgt 7 s1269 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1269 7 _ le
  decide +kernel
theorem b1270 : Blocked tgt 7 s1270 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1270 7 _ le
  decide +kernel
theorem b1271 : Blocked tgt 7 s1271 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s1271 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
