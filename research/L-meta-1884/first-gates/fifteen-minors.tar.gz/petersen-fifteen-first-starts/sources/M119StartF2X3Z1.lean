import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) tgt 5 := by
  change NoAtMost [0xf000f000f000f0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s18] [194,390,195,455,196,1350,579,1351,390,390,455,455,196,1350,839,1351,586,390,195,455,716,1350,1091,1351,846,390,455,455,716,1350,1351,1351,1106,1366,195,455,1236,1366,579,579,1366,1366,455,455,1236,1366,839,579,1626,1366,195,455,1756,1366,1948,1948,1886,1366,455,455,1756,1366,3740,3740,2210,2470,2275,2535,196,3430,2659,3431,2470,2470,2535,2535,196,3430,2919,3431,2666,2470,2275,2535,716,3430,3171,3431,2926,2470,2535,2535,716,3430,3431,3431,3186,3446,2275,2535,1236,3446,2659,2659,3446,3446,2535,2535,1236,3446,2919,2659,3706,3446,2275,2535,1756,3446,1948,1948,3966,3446,2535,2535,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s18], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_1
end PetersenSmallStarts.M119
