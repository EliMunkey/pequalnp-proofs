import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_2 : NoAtMost (0x4444444444444444 :: inputs 6) tgt 7 := by
  change NoAtMost [0x4444444444444444,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s157] [194,388,195,388,196,388,835,388,390,1668,455,1668,196,1668,839,1668,714,908,715,908,716,908,843,908,390,1676,455,1676,716,1676,1351,1676,1106,1428,195,1428,1236,1428,835,1428,1366,1684,455,1684,1236,1684,839,1684,714,908,715,908,716,908,843,908,1366,1366,455,455,716,1366,2375,2375,2146,2468,195,2468,2276,2468,835,2468,2406,3748,455,3748,2276,3748,839,3748,2666,2988,715,2988,2796,2988,843,2988,2406,3756,455,3756,2796,3756,1351,3756,3186,3508,195,3508,3316,3508,835,3508,3446,3764,455,3764,3316,3764,839,3764,2666,2988,715,2988,2796,2988,843,2988,3446,3446,455,455,2796,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s157], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s157) b157 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_2
end PetersenSmallStarts.M63
