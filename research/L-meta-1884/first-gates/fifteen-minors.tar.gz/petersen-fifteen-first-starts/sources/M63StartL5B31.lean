import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1164 : Blocked tgt 5 s1164 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(2,false),(0,false))] s1164 5 _ le
  decide +kernel
theorem b1165 : Blocked tgt 5 s1165 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1165 5 _ le
  decide +kernel
theorem b1166 : Blocked tgt 5 s1166 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1166 5 _ le
  decide +kernel
theorem b1167 : Blocked tgt 5 s1167 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1167 5 _ le
  decide +kernel
theorem b1168 : Blocked tgt 5 s1168 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1168 5 _ le
  decide +kernel
theorem b1169 : Blocked tgt 5 s1169 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1169 5 _ le
  decide +kernel
theorem b1170 : Blocked tgt 5 s1170 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(2,false),(0,false))] s1170 5 _ le
  decide +kernel
theorem b1171 : Blocked tgt 5 s1171 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1171 5 _ le
  decide +kernel
theorem b1172 : Blocked tgt 5 s1172 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1172 5 _ le
  decide +kernel
theorem b1173 : Blocked tgt 5 s1173 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1173 5 _ le
  decide +kernel
theorem b1174 : Blocked tgt 5 s1174 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(true,(2,false),(0,false))] s1174 5 _ le
  decide +kernel
theorem b1178 : Blocked tgt 5 s1178 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1178 5 _ le
  decide +kernel
theorem b1179 : Blocked tgt 5 s1179 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(2,false),(0,true))] s1179 5 _ le
  decide +kernel
theorem b1180 : Blocked tgt 5 s1180 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(2,false),(0,true))] s1180 5 _ le
  decide +kernel
theorem b1181 : Blocked tgt 5 s1181 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s1181 5 _ le
  decide +kernel
theorem b1182 : Blocked tgt 5 s1182 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(2,false),(0,true))] s1182 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
