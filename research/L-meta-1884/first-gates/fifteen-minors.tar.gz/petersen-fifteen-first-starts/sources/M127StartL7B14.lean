import M127StartData
import M127StartPins0
import M127StartL6B18
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b559 : Blocked tgt 7 s559 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s559 7 _ le
  decide +kernel
theorem b560 : Blocked tgt 7 s560 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s560 7 _ le
  decide +kernel
theorem b561 : Blocked tgt 7 s561 := by
  apply PetersenFastNode.node (nxt := #[s562,s563,s564,s565]) (hints := [13614,5550,5292,5550,905,905,1677,5934,1677,5934,1673,13614,1673,14646,14646,13614,13614,14646,2697,7470,2697,7470,4745,13582,4745,9486,15160,5550,5550,9097,5550,1549,5934,5550,4526,5550,1673,5550,6582,5550,2697,7470,5550,1422,1454,5518,1422,1677,5934,1677,5934,1673,8589,1673,9097,15160,9097,9097,15160,2697,7470,2697,7470,4745,11064,4745,9097,6966,5934,5934,6966,6966,5934,5934,6966,5934,4918,7470,5934,1806,1838,5902,1806,7478,7478,1673,7470,2697,7470,1673,4237,4745,1673,0,7470,1,7470,2,4745,3,4745,3342,3374,7438,3342]) (by decide +kernel)
  change ∀ b ∈ [s562,s563,s564,s565], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s562) b562 <|
    PetersenLocalChildren.push (x := s563) b563 <|
    PetersenLocalChildren.push (x := s564) b564 <|
    PetersenLocalChildren.push (x := s565) b565 <|
    PetersenLocalChildren.nil
theorem b566 : Blocked tgt 7 s566 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(true,(0,false),(2,false))] s566 7 _ le
  decide +kernel
theorem b567 : Blocked tgt 7 s567 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [(true,(0,false),(2,false))] s567 7 _ le
  decide +kernel
theorem b568 : Blocked tgt 7 s568 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s568 7 _ le
  decide +kernel
theorem b569 : Blocked tgt 7 s569 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s569 7 _ le
  decide +kernel
theorem b570 : Blocked tgt 7 s570 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s570 7 _ le
  decide +kernel
theorem b571 : Blocked tgt 7 s571 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s571 7 _ le
  decide +kernel
theorem b572 : Blocked tgt 7 s572 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s572 7 _ le
  decide +kernel
theorem b573 : Blocked tgt 7 s573 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s573 7 _ le
  decide +kernel
theorem b574 : Blocked tgt 7 s574 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s574 7 _ le
  decide +kernel
theorem b575 : Blocked tgt 7 s575 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s575 7 _ le
  decide +kernel
theorem b576 : Blocked tgt 7 s576 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s576 7 _ le
  decide +kernel
theorem b577 : Blocked tgt 7 s577 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s577 7 _ le
  decide +kernel
theorem b578 : Blocked tgt 7 s578 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(3,false))] s578 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
