import M127StartData
import M127StartPins0
import M127StartPins1
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b829 : Blocked tgt 6 s829 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s829 6 _ le
  decide +kernel
theorem b830 : Blocked tgt 6 s830 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s830 6 _ le
  decide +kernel
theorem b831 : Blocked tgt 6 s831 := by
  apply PetersenFastNode.node (nxt := #[s832,s833]) (hints := [10966,9031,11094,10966,2452,9803,2836,2452,2452,9799,3348,2452,3372,3500,404,404,2452,10950,13612,2774,13612,2452,9675,8647,9931,9675,9159,8651,9927,9159,11370,9159,9159,11626,9159,9046,10951,9159,903,967,9095,903,2836,9927,9923,9923,9931,3884,9931,10439,11467,9931,1675,1739,9867,1675,0,9927,9927,3364,9927,10443,10951,9927,1671,1735,9863,1671,1,10951,3340,10951,3372,10516,11564,3372,2695,2759,10887,2695]) (by decide +kernel)
  change ∀ b ∈ [s832,s833], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s832) b832 <|
    PetersenLocalChildren.push (x := s833) b833 <|
    PetersenLocalChildren.nil
theorem b834 : Blocked tgt 6 s834 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s834 6 _ le
  decide +kernel
theorem b835 : Blocked tgt 6 s835 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s835 6 _ le
  decide +kernel
theorem b839 : Blocked tgt 6 s839 := by
  apply PetersenFastNode.node (nxt := #[s840]) (hints := [2709,902,2837,2709,2451,1738,5737,2451,2451,1670,3347,2451,3371,3499,403,403,2451,2694,13611,2709,13611,2451,1738,902,1738,1994,902,8650,1670,902,4885,902,902,2853,902,2837,2694,902,1418,902,902,1418,3347,1670,1730,1670,3371,1738,1738,3689,1738,2694,3786,1738,1674,1674,5653,1670,1670,3363,1670,10442,2694,1670,3347,1670,1670,3347,0,2694,3339,2694,3371,10515,11563,3371,3210,2694,2694,3210]) (by decide +kernel)
  change ∀ b ∈ [s840], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s840) b840 <|
    PetersenLocalChildren.nil
theorem b841 : Blocked tgt 6 s841 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s841 6 _ le
  decide +kernel
theorem b842 : Blocked tgt 6 s842 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5514,2450,1418,1418,4741,901,2868,901,5833,1737,4741,1737,4741,1669,12489,1669,4741,2693,3338,2693,5257,4741,4741,5257,2708,901,2836,2708,2450,1737,2708,2450,2450,1669,3346,2450,402,402,2450,2693,2450,2708,10514,2450,1737,901,1737,1993,901,8649,1669,901,901,2836,2693,901,1417,901,901,1417,3346,1669,1729,1669,1737,2693,3785,1737,1673,1673,1669,10441,2693,1669,3346,1669,1669,3346,3209,2693,2693,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b848 : Blocked tgt 6 s848 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s848 6 _ le
  decide +kernel
theorem b849 : Blocked tgt 6 s849 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s849 6 _ le
  decide +kernel
theorem b850 : Blocked tgt 6 s850 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s850 6 _ le
  decide +kernel
theorem b851 : Blocked tgt 6 s851 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s851 6 _ le
  decide +kernel
theorem b852 : Blocked tgt 6 s852 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s852 6 _ le
  decide +kernel
theorem b853 : Blocked tgt 6 s853 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s853 6 _ le
  decide +kernel
theorem b854 : Blocked tgt 6 s854 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s854 6 _ le
  decide +kernel
theorem b855 : Blocked tgt 6 s855 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s855 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
