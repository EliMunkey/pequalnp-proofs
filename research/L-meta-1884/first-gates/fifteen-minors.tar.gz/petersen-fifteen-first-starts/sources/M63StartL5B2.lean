import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b61 : Blocked tgt 5 s61 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s61 5 _ le
  decide +kernel
theorem b62 : Blocked tgt 5 s62 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s62 5 _ le
  decide +kernel
theorem b67 : Blocked tgt 5 s67 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s67 5 _ le
  decide +kernel
theorem b68 : Blocked tgt 5 s68 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s68 5 _ le
  decide +kernel
theorem b70 : Blocked tgt 5 s70 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s70 5 _ le
  decide +kernel
theorem b71 : Blocked tgt 5 s71 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s71 5 _ le
  decide +kernel
theorem b78 : Blocked tgt 5 s78 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s78 5 _ le
  decide +kernel
theorem b79 : Blocked tgt 5 s79 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s79 5 _ le
  decide +kernel
theorem b80 : Blocked tgt 5 s80 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s80 5 _ le
  decide +kernel
theorem b81 : Blocked tgt 5 s81 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,389,1428,1364,714,841,906,714,1234,202,1682,1234,714,210,1674,714,2762,714,714,746,713,197,841,713,453,201,837,453,453,404,1349,453,2373,453,453,388,1426,837,833,833,841,1093,1609,841,2633,841,841,2117,837,1097,1349,837,2373,837,837,2121,1349,1706]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b84 : Blocked tgt 5 s84 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s84 5 _ le
  decide +kernel
theorem b87 : Blocked tgt 5 s87 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s87 5 _ le
  decide +kernel
theorem b93 : Blocked tgt 5 s93 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s93 5 _ le
  decide +kernel
theorem b94 : Blocked tgt 5 s94 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s94 5 _ le
  decide +kernel
theorem b97 : Blocked tgt 5 s97 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s97 5 _ le
  decide +kernel
theorem b98 : Blocked tgt 5 s98 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s98 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
