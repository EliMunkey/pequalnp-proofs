import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_1 : NoAtMost (0xaaaa :: inputs 5) tgt 4 := by
  change NoAtMost [0xaaaa,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s13,s0,s14] [99,100,100,100,101,420,420,420,199,232,232,232,101,424,424,424,363,364,364,364,365,428,428,428,199,232,232,232,365,877,680,0,563,100,100,100,629,420,420,420,695,232,232,232,629,424,424,424,827,364,364,364,893,428,428,428,695,232,232,232,893,893,1,2] (by decide +kernel)
  change ∀ b ∈ [s13,s0,s14], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s14) b14 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_1
end PetersenSmallStarts.M47
