import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_1 : NoAtMost (0xaaaaaaaa :: inputs 6) tgt 6 := by
  change NoAtMost [0xaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s59] [194,195,195,195,196,835,835,835,390,455,455,455,196,839,839,839,714,715,715,715,716,843,843,843,390,455,455,455,716,1351,1351,1351,1106,195,195,195,1236,835,835,835,1366,455,455,455,1236,839,839,839,1626,715,715,715,1756,843,843,843,1366,455,455,455,1756,3740,3740,3740,2210,195,2275,195,196,835,2915,835,2470,455,2535,455,196,839,2919,839,2730,715,2795,715,716,843,2923,843,2470,455,2535,455,716,1351,3431,1351,3186,195,2275,195,1236,835,2915,835,3446,455,2535,455,1236,839,2919,839,3706,715,2795,715,1756,843,2923,843,3446,455,2535,455,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s59], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s59) b59 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_1
end PetersenSmallStarts.M111
