import M63StartData
import M63StartPins0
import M63StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b816 : Blocked tgt 5 s816 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s816 5 _ le
  decide +kernel
theorem b817 : Blocked tgt 5 s817 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s817 5 _ le
  decide +kernel
theorem b818 : Blocked tgt 5 s818 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s818 5 _ le
  decide +kernel
theorem b819 : Blocked tgt 5 s819 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s819 5 _ le
  decide +kernel
theorem b820 : Blocked tgt 5 s820 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s820 5 _ le
  decide +kernel
theorem b821 : Blocked tgt 5 s821 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(false,(0,true),(5,false))] s821 5 _ le
  decide +kernel
theorem b822 : Blocked tgt 5 s822 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s822 5 _ le
  decide +kernel
theorem b823 : Blocked tgt 5 s823 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s823 5 _ le
  decide +kernel
theorem b824 : Blocked tgt 5 s824 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s824 5 _ le
  decide +kernel
theorem b825 : Blocked tgt 5 s825 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(3,true)),(false,(0,true),(5,false))] s825 5 _ le
  decide +kernel
theorem b830 : Blocked tgt 5 s830 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s830 5 _ le
  decide +kernel
theorem b831 : Blocked tgt 5 s831 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s831 5 _ le
  decide +kernel
theorem b842 : Blocked tgt 5 s842 := by
  apply PetersenFastNode.node (nxt := #[s843]) (hints := [1365,1107,1365,1429,842,1427,842,1425,838,1555,405,405,1429,421,454,454,1235,778,1427,1235,1235,774,1813,1235,195,211,1219,195,0,1235,1235,2373,1427,838,834,1427,387,403,1411,387,714,1427,1427,842,838,917,1813,838,838,714,966,838,1350,1350]) (by decide +kernel)
  change ∀ b ∈ [s843], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s843) b843 <|
    PetersenLocalChildren.nil
theorem b846 : Blocked tgt 5 s846 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s846 5 _ le
  decide +kernel
theorem b847 : Blocked tgt 5 s847 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s847 5 _ le
  decide +kernel
theorem b848 : Blocked tgt 5 s848 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s848 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
