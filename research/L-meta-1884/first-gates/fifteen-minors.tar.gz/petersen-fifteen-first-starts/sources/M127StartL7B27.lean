import M127StartData
import M127StartPins0
import M127StartL6B26
import M127StartPins1
import M127StartL6B7
import M127StartL6B25
import M127StartL6B27
import M127StartL6B24
import M127StartL6B8
import M127StartL6B28
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b902 : Blocked tgt 7 s902 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s902 7 _ le
  decide +kernel
theorem b903 : Blocked tgt 7 s903 := by
  apply PetersenFastNode.node (nxt := #[s904,s905,s906,s907]) (hints := [15096,9033,15224,15096,6582,9805,15096,6582,6582,15096,5550,5550,6582,9801,7478,6582,7470,6582,7470,7598,2454,2486,6550,2454,13614,6904,13614,6582,9677,8649,9933,9677,13676,9161,9161,13676,9161,8653,9929,9161,9161,13176,10953,9161,9161,11128,13001,9161,905,969,9097,905,9933,5934,7478,9929,9925,9925,9933,10953,11981,9933,9933,12489,13517,9933,1677,1741,9869,1677,7478,9929,7478,9929,11469,10953,7470,10953,0,13001,1,13001,13614,2,13614,3,9929,7470,10953,9929,9929,12493,13001,9929,1673,1737,9865,1673,10953,3374,13001,10953,2697,2761,10889,2697,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s904,s905,s906,s907], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s904) b904 <|
    PetersenLocalChildren.push (x := s905) b905 <|
    PetersenLocalChildren.push (x := s906) b906 <|
    PetersenLocalChildren.push (x := s907) b907 <|
    PetersenLocalChildren.nil
theorem b908 : Blocked tgt 7 s908 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s908 7 _ le
  decide +kernel
theorem b909 : Blocked tgt 7 s909 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s909 7 _ le
  decide +kernel
theorem b910 : Blocked tgt 7 s910 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s910 7 _ le
  decide +kernel
theorem b911 : Blocked tgt 7 s911 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s911 7 _ le
  decide +kernel
theorem b912 : Blocked tgt 7 s912 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s912 7 _ le
  decide +kernel
theorem b913 : Blocked tgt 7 s913 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s913 7 _ le
  decide +kernel
theorem b914 : Blocked tgt 7 s914 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s914 7 _ le
  decide +kernel
theorem b915 : Blocked tgt 7 s915 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s915 7 _ le
  decide +kernel
theorem b916 : Blocked tgt 7 s916 := by
  apply PetersenFastNode.node (nxt := #[s917,s918,s919,s222,s879,s920,s921,s922,s854,s923,s924,s925,s926,s927,s929,s933,s934,s935,s936,s937]) (hints := [1438,13017,5534,1438,0,1,13017,13017,11112,9177,2,9177,11112,3,11112,9177,13017,9177,13533,13533,1822,9949,13017,9949,12505,13017,1822,9949,13533,9949,13017,13017,3366,9945,13533,9945,12509,13533,3366,9945,13017,9945,10969,13017,3358,10969,4,5,4761,4761,9502,12953,13017,6,4825,13017,9502,4761,4761,7,10984,10984,11112,9177,5534,9177,11112,5534,11112,9177,10984,9177,1822,5534,1822,9949,10984,9949,1822,10984,1822,9949,5534,9949,2470,2470,3366,9945,5534,9945,3366,5534,3366,9945,2470,9945,3358,5534,3358,2470,2470,8,3358,2470,3358,3486,5534,9,5534,5534,9502,2792,10984,10,9502,10984,9502,5534,5534,11,9693,9693,9949,8665,9177,1822,9949,9177,9949,9693,9693,1822,9177,9177,9945,8669,9693,3366,9945,9693,9945,9177,9177,3366,9177,9177,11356,9064,11112,3358,11096,11112,11356,9177,9177,3358,921,921,12,985,9177,9502,9113,9177,13,921,921,9502,2854,2854,3366,9945,9949,9945,9941,9949,3366,9941,2854,9945,9949,9949,3358,806,2854,14,3358,2854,3358,9949,9949,15,1693,1693,9502,1757,9949,16,9885,9949,9502,1693,1693,17,9945,9945,18,3358,3366,3358,3350,3366,19,9945,9945,3358,1689,1689,10534,1753,9945,9502,9881,9945,10534,1689,1689,9502,3358,3358,9502,8486,11356,10534,9502,11356,9502,3358,3358,10534]) (by decide +kernel)
  change ∀ b ∈ [s917,s918,s919,s222,s879,s920,s921,s922,s854,s923,s924,s925,s926,s927,s929,s933,s934,s935,s936,s937], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s917) b917 <|
    PetersenLocalChildren.push (x := s918) b918 <|
    PetersenLocalChildren.push (x := s919) b919 <|
    PetersenLocalChildren.push (x := s222) b222 <|
    PetersenLocalChildren.push (x := s879) b879 <|
    PetersenLocalChildren.push (x := s920) b920 <|
    PetersenLocalChildren.push (x := s921) b921 <|
    PetersenLocalChildren.push (x := s922) b922 <|
    PetersenLocalChildren.push (x := s854) b854 <|
    PetersenLocalChildren.push (x := s923) b923 <|
    PetersenLocalChildren.push (x := s924) b924 <|
    PetersenLocalChildren.push (x := s925) b925 <|
    PetersenLocalChildren.push (x := s926) b926 <|
    PetersenLocalChildren.push (x := s927) b927 <|
    PetersenLocalChildren.push (x := s929) b929 <|
    PetersenLocalChildren.push (x := s933) b933 <|
    PetersenLocalChildren.push (x := s934) b934 <|
    PetersenLocalChildren.push (x := s935) b935 <|
    PetersenLocalChildren.push (x := s936) b936 <|
    PetersenLocalChildren.push (x := s937) b937 <|
    PetersenLocalChildren.nil
theorem b938 : Blocked tgt 7 s938 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s938 7 _ le
  decide +kernel
theorem b939 : Blocked tgt 7 s939 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s939 7 _ le
  decide +kernel
theorem b940 : Blocked tgt 7 s940 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s940 7 _ le
  decide +kernel
theorem b941 : Blocked tgt 7 s941 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s941 7 _ le
  decide +kernel
theorem b942 : Blocked tgt 7 s942 := by
  apply PetersenFastNode.node (nxt := #[s943,s944,s242,s243,s945,s946,s947,s948,s906,s949,s950,s951,s952,s953]) (hints := [15106,15106,15234,915,6592,915,15234,6592,15234,15106,15106,915,5944,6592,5944,1687,15106,1687,5944,15106,5944,6592,6592,1687,6592,6592,7488,1683,5366,1683,7488,5366,7488,6592,6592,1683,7480,4850,7480,6592,6592,10899,7480,6592,7480,7608,4850,10899,2464,2464,0,2496,6592,4755,6560,6592,1,2464,2464,4755,13624,6592,13624,6914,15106,2,5560,15106,13624,5560,6592,3,1431,1431,1687,403,915,5944,1687,915,1687,1431,1431,5944,915,915,1683,407,1431,7488,1683,1431,1683,915,915,7488,915,915,10899,13186,15234,7480,10899,15234,10899,915,915,7480,915,915,4755,11138,15234,4,4755,15234,4755,915,915,5,6978,6978,6,915,915,13624,915,915,7,6978,6978,13624,6976,6976,7488,1683,1687,1683,1679,1687,7488,1679,6976,1683,1687,1687,11415,10387,6976,10899,11415,6976,11415,1687,1687,10899,1687,1687,5271,4243,5944,4755,5271,5944,5271,1687,1687,4755,5944,5944,13624,1687,1687,8,1687,1687,13624,5944,5944,9,1683,1683,10899,10391,7488,11415,10899,7488,10899,1683,1683,11415,1683,1683,4755,4247,7488,5271,4755,7488,4755,1683,1683,5271,7488,7488,14656,1683,1683,13624,1683,1683,14656,7488,7488,13624,4755,10899,4755,3384,7480,10,4755,7480,4755,10899,10899,11,2707,7480,13624,2707,10899,14656,10899,10899,13624,7480,7480,14656,9496,12,9496,4755,4755,13624,4755,4755,9496,13592,13,13624]) (by decide +kernel)
  change ∀ b ∈ [s943,s944,s242,s243,s945,s946,s947,s948,s906,s949,s950,s951,s952,s953], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s943) b943 <|
    PetersenLocalChildren.push (x := s944) b944 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s945) b945 <|
    PetersenLocalChildren.push (x := s946) b946 <|
    PetersenLocalChildren.push (x := s947) b947 <|
    PetersenLocalChildren.push (x := s948) b948 <|
    PetersenLocalChildren.push (x := s906) b906 <|
    PetersenLocalChildren.push (x := s949) b949 <|
    PetersenLocalChildren.push (x := s950) b950 <|
    PetersenLocalChildren.push (x := s951) b951 <|
    PetersenLocalChildren.push (x := s952) b952 <|
    PetersenLocalChildren.push (x := s953) b953 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
