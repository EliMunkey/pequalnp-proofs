import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_3 : NoAtMost (0xaa00aa00aa00aa00 :: inputs 6) tgt 6 := by
  change NoAtMost [0xaa00aa00aa00aa00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s30] [194,715,195,715,196,843,835,843,390,715,455,715,196,1611,839,1611,714,715,715,715,716,843,843,843,390,715,455,715,716,1611,1351,1611,1106,715,195,715,1236,843,835,843,1366,715,455,715,1236,1236,839,3220,1626,715,715,715,1756,843,843,843,1366,715,455,715,1756,3740,3740,3740,2210,2795,2275,2795,196,2923,2915,2923,2470,2795,2535,2795,196,3691,2919,3691,2730,2795,2795,2795,716,2923,2923,2923,2470,2795,2535,2795,716,3691,3431,3691,3186,2795,2275,2795,1236,2923,2915,2923,3446,2795,2535,2795,1236,1236,2919,3894,3706,2795,2795,2795,1756,2923,2923,2923,3446,2795,2535,2795,1756,1236,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s30], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_3
end PetersenSmallStarts.M111
