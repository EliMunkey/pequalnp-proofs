import M127StartData
import M127StartL8B0
import M127StartL8B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_3_5_0 : NoAtMost (0xffffffffff00ff00ffffffffff00ff00 :: inputs 7) tgt 8 := by
  change NoAtMost [0xffffffffff00ff00ffffffffff00ff00,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 8
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1341] [386,1418,387,1419,388,1420,1667,1675,774,1574,903,903,388,1420,1671,2695,1418,1418,1419,1419,1420,1420,1675,1675,774,4774,903,903,1420,1420,2695,2695,2194,3122,387,1419,2452,3380,1667,1675,2710,3638,903,903,2452,3380,1671,4235,1418,1418,1419,1419,1420,1420,1675,1675,2710,6838,903,903,1420,1420,4743,5259,4258,4258,387,1419,4516,4516,1667,1675,4774,4774,903,903,4516,4516,1671,2695,5290,5290,1419,1419,5548,5548,1675,1675,4774,4774,903,903,5548,5548,2695,2695,6322,6322,387,1419,6580,6580,1667,1675,6838,6838,903,903,6580,6580,1671,7476,5290,5290,1419,1419,5548,5548,1675,1675,6838,6838,903,903,5548,5548,13612,13612,8514,9546,8643,9675,388,1420,9923,9931,9030,9830,9159,9159,388,1420,9927,10951,9546,9546,9675,9675,1420,1420,9931,9931,9030,13030,9159,9159,1420,1420,10951,10951,10450,11378,8643,9675,2452,3380,9923,9931,10966,11894,9159,9159,2452,3380,9927,12491,9546,9546,9675,9675,1420,1420,9931,9931,10966,15094,9159,9159,1420,1420,12999,13515,12514,12514,8643,9675,4516,4516,9923,9931,13030,13030,9159,9159,4516,4516,9927,10951,13546,13546,9675,9675,5548,5548,9931,9931,13030,13030,9159,9159,5548,5548,10951,10951,14578,14578,8643,9675,6580,6580,9923,9931,15094,15094,9159,9159,6580,6580,9927,7476,13546,13546,9675,9675,5548,5548,9931,9931,15094,15094,9159,9159,5548,5548,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1341], Blocked tgt 8 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1341) b1341 <|
    PetersenLocalChildren.nil
#print axioms gate_3_5_0
end PetersenSmallStarts.M127
