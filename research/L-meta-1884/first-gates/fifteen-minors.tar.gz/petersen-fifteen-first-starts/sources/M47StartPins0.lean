import M47StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 16) : Fin 32 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23] : Array (Fin 32))[x.val]?.getD 0
theorem small0 : NoAtMost i4 (PetersenPackedPin.project r0 tgt) 3 := by
  have a : PetersenPackedPin.project r0 tgt = table 39 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 39 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 16) : Fin 32 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15] : Array (Fin 32))[x.val]?.getD 0
theorem small1 : NoAtMost i4 (PetersenPackedPin.project r1 tgt) 3 := by
  have a : PetersenPackedPin.project r1 tgt = table 15 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 15 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r3 (x : Fin 4) : Fin 32 := (#[0,4,8,12] : Array (Fin 32))[x.val]?.getD 0
theorem small3 : NoAtMost i2 (PetersenPackedPin.project r3 tgt) 0 := by
  have a : PetersenPackedPin.project r3 tgt = table 12 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 12 0 (by decide +kernel) (by decide +kernel)
theorem hot3 : forcedConst r3 tgt = false := by decide +kernel
def r5 (x : Fin 4) : Fin 32 := (#[4,6,12,14] : Array (Fin 32))[x.val]?.getD 0
theorem small5 : NoAtMost i2 (PetersenPackedPin.project r5 tgt) 0 := by
  have a : PetersenPackedPin.project r5 tgt = table 10 4 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 10 4 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
end PetersenSmallStarts.M47
