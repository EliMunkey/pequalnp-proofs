import M127StartData
import M127StartPins0
import M127StartL6B21
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b686 : Blocked tgt 7 s686 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s686 7 _ le
  decide +kernel
theorem b687 : Blocked tgt 7 s687 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s687 7 _ le
  decide +kernel
theorem b688 : Blocked tgt 7 s688 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,true))] s688 7 _ le
  decide +kernel
theorem b690 : Blocked tgt 7 s690 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s690 7 _ le
  decide +kernel
theorem b691 : Blocked tgt 7 s691 := by
  apply PetersenFastNode.node (nxt := #[s692,s693,s694,s695,s696]) (hints := [13677,5551,13677,13805,15097,5551,5551,15097,5551,9934,5935,5551,6583,4527,7479,6583,5551,4535,7471,5551,1423,1455,5519,1423,5551,6905,13615,5551,9162,9162,9934,5679,9934,13677,9930,7223,9930,7479,10954,7215,10954,13677,13002,9581,13002,9549,0,13615,13613,13613,9934,5935,9934,5935,9930,7479,9930,7479,10954,7471,10954,7471,13002,1,13002,2,3,13615,4,13615,6967,9930,9926,9926,9934,10442,11470,9934,9934,12490,13518,9934,1678,1742,9870,1678,9930,10446,10954,9930,9930,12494,13002,9930,1674,1738,9866,1674,10954,3375,13002,10954,2698,2762,10890,2698,4746,4810,12938,4746]) (by decide +kernel)
  change ∀ b ∈ [s692,s693,s694,s695,s696], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s692) b692 <|
    PetersenLocalChildren.push (x := s693) b693 <|
    PetersenLocalChildren.push (x := s694) b694 <|
    PetersenLocalChildren.push (x := s695) b695 <|
    PetersenLocalChildren.push (x := s696) b696 <|
    PetersenLocalChildren.nil
theorem b697 : Blocked tgt 7 s697 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s697 7 _ le
  decide +kernel
theorem b698 : Blocked tgt 7 s698 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s698 7 _ le
  decide +kernel
theorem b699 : Blocked tgt 7 s699 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s699 7 _ le
  decide +kernel
theorem b700 : Blocked tgt 7 s700 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s700 7 _ le
  decide +kernel
theorem b701 : Blocked tgt 7 s701 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s701 7 _ le
  decide +kernel
theorem b702 : Blocked tgt 7 s702 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s702 7 _ le
  decide +kernel
theorem b703 : Blocked tgt 7 s703 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s703 7 _ le
  decide +kernel
theorem b704 : Blocked tgt 7 s704 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s704 7 _ le
  decide +kernel
theorem b705 : Blocked tgt 7 s705 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s705 7 _ le
  decide +kernel
theorem b706 : Blocked tgt 7 s706 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s706 7 _ le
  decide +kernel
theorem b707 : Blocked tgt 7 s707 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s707 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
