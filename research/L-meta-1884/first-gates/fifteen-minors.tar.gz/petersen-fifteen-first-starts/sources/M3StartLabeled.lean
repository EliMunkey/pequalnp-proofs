import M3StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M3
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 4) : Fin 4 := (#[0,2,1,3] : Array (Fin 4))[x.val]?.getD 0
private theorem cover0 : i2.all (fun q => i2.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
theorem labeled_0_1_2 : NoAtMost (0x4 :: inputs 2) tgt 0 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x4) (a:=0x2) (by decide +kernel) gate_0_1_1
def forbidden : List (BitVec 4) := [0xe,0x2,0x4]
theorem all_forbidden (g : BitVec 4) (h : g∈forbidden) : NoAtMost (g::inputs 2) tgt 0 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 2) tgt 0 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 2) tgt 0) (x:=0xe) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 2) tgt 0) (x:=0x2) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 2) tgt 0) (x:=0x4) labeled_0_1_2 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M3
