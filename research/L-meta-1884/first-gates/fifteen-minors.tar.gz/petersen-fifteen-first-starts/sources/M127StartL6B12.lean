import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b342 : Blocked tgt 6 s342 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s342 6 _ le
  decide +kernel
theorem b343 : Blocked tgt 6 s343 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s343 6 _ le
  decide +kernel
theorem b344 : Blocked tgt 6 s344 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s344 6 _ le
  decide +kernel
theorem b345 : Blocked tgt 6 s345 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s345 6 _ le
  decide +kernel
theorem b346 : Blocked tgt 6 s346 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s346 6 _ le
  decide +kernel
theorem b347 : Blocked tgt 6 s347 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s347 6 _ le
  decide +kernel
theorem b348 : Blocked tgt 6 s348 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s348 6 _ le
  decide +kernel
theorem b349 : Blocked tgt 6 s349 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s349 6 _ le
  decide +kernel
theorem b354 : Blocked tgt 6 s354 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s354 6 _ le
  decide +kernel
theorem b355 : Blocked tgt 6 s355 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s355 6 _ le
  decide +kernel
theorem b356 : Blocked tgt 6 s356 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s356 6 _ le
  decide +kernel
theorem b357 : Blocked tgt 6 s357 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s357 6 _ le
  decide +kernel
theorem b358 : Blocked tgt 6 s358 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s358 6 _ le
  decide +kernel
theorem b359 : Blocked tgt 6 s359 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s359 6 _ le
  decide +kernel
theorem b360 : Blocked tgt 6 s360 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s360 6 _ le
  decide +kernel
theorem b361 : Blocked tgt 6 s361 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s361 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
