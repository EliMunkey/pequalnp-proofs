import M127StartData
import M127StartPins0
import M127StartL6B36
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1272 : Blocked tgt 7 s1272 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1272 7 _ le
  decide +kernel
theorem b1273 : Blocked tgt 7 s1273 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1273 7 _ le
  decide +kernel
theorem b1274 : Blocked tgt 7 s1274 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1274 7 _ le
  decide +kernel
theorem b1275 : Blocked tgt 7 s1275 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1275 7 _ le
  decide +kernel
theorem b1276 : Blocked tgt 7 s1276 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1276 7 _ le
  decide +kernel
theorem b1277 : Blocked tgt 7 s1277 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1277 7 _ le
  decide +kernel
theorem b1278 : Blocked tgt 7 s1278 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1278 7 _ le
  decide +kernel
theorem b1279 : Blocked tgt 7 s1279 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1279 7 _ le
  decide +kernel
theorem b1280 : Blocked tgt 7 s1280 := by
  apply PetersenFastNode.node (nxt := #[s1281,s1282]) (hints := [14582,9931,9803,9803,9931,9675,8643,9675,5932,9931,9931,0,9923,7476,9931,11467,10435,9931,9931,13515,12483,9931,1675,9867,1739,1675,13674,9675,13674,9675,5548,5548,14582,9795,15990,14582,7468,11467,7468,11467,10454,13515,14550,13515,13612,6390,13612,6326,13674,9675,9675,13674,8643,9675,9675,8643,9675,7212,11467,9675,9675,9578,13515,9675,1419,1483,9611,1419,6964,9923,7988,9923,7468,11467,7468,11467,2836,13515,6932,13515,13612,1,13612,6964,9923,11467,10435,11467,9923,13515,12483,13515,1667,13612,9859,13612,11467,3372,13515,11467,3211,3275,11403,3211,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s1281,s1282], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1281) b1281 <|
    PetersenLocalChildren.push (x := s1282) b1282 <|
    PetersenLocalChildren.nil
theorem b1284 : Blocked tgt 7 s1284 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1284 7 _ le
  decide +kernel
theorem b1285 : Blocked tgt 7 s1285 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1285 7 _ le
  decide +kernel
theorem b1286 : Blocked tgt 7 s1286 := by
  apply PetersenFastNode.node (nxt := #[s1282]) (hints := [6901,5353,6901,5353,902,1418,902,1418,1674,1674,1670,7475,2694,3210,2694,3210,4742,5258,4742,5258,14643,13611,14643,13611,5353,1418,5609,5353,5353,6389,6963,5353,6901,5353,5353,6901,7467,3210,7467,5353,2773,5258,5321,5258,5547,5547,1418,390,898,1418,902,1418,1418,902,1418,7211,3210,1418,1418,9577,5258,1418,6965,1418,1418,13609,6963,1670,1666,3210,2182,3210,2690,5258,4230,5258,4738,13611,0,13611,6963,1670,3210,2694,3210,1670,5258,4742,5258,14643,13611,1670,13611,3210,3371,5258,3210,7467,3210,3210,7467,9483,5258,5258,13579]) (by decide +kernel)
  change ∀ b ∈ [s1282], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1282) b1282 <|
    PetersenLocalChildren.nil
theorem b1287 : Blocked tgt 7 s1287 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,true),(3,false))] s1287 7 _ le
  decide +kernel
theorem b1288 : Blocked tgt 7 s1288 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1288 7 _ le
  decide +kernel
theorem b1289 : Blocked tgt 7 s1289 := by
  apply PetersenFastNode.node (nxt := #[s1290,s1291,s1292]) (hints := [9932,0,9932,5933,13547,5549,13547,5549,9676,9676,9924,7989,9924,6965,11468,7469,11468,7469,13516,6933,13516,2837,6965,13613,1,13613,6581,5549,6581,5549,9932,10188,9156,9932,7477,7477,9932,7469,10436,7469,9932,13516,12484,9932,14645,13613,14645,13613,13547,5549,5549,13547,6581,5549,5549,6581,5549,4533,7469,5549,1421,1453,5517,1421,5549,5355,13613,5549,9156,2,9924,9156,11468,7469,11468,7469,13516,11123,13516,9156,900,13613,9092,13613,9924,7469,10436,7469,9924,13516,12484,13516,14645,13613,14645,13613,3341,3373,7437,3341,7469,12597,13613,7469,9485,9517,9485,13581]) (by decide +kernel)
  change ∀ b ∈ [s1290,s1291,s1292], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s1290) b1290 <|
    PetersenLocalChildren.push (x := s1291) b1291 <|
    PetersenLocalChildren.push (x := s1292) b1292 <|
    PetersenLocalChildren.nil
theorem b1293 : Blocked tgt 7 s1293 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1293 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
