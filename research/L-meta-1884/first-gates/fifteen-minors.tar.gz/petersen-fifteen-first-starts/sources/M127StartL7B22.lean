import M127StartData
import M127StartPins0
import M127StartL6B23
import M127StartL6B8
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b759 : Blocked tgt 7 s759 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s759 7 _ le
  decide +kernel
theorem b760 : Blocked tgt 7 s760 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s760 7 _ le
  decide +kernel
theorem b761 : Blocked tgt 7 s761 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s761 7 _ le
  decide +kernel
theorem b762 : Blocked tgt 7 s762 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s762 7 _ le
  decide +kernel
theorem b763 : Blocked tgt 7 s763 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s763 7 _ le
  decide +kernel
theorem b764 : Blocked tgt 7 s764 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s764 7 _ le
  decide +kernel
theorem b765 : Blocked tgt 7 s765 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s765 7 _ le
  decide +kernel
theorem b766 : Blocked tgt 7 s766 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s766 7 _ le
  decide +kernel
theorem b767 : Blocked tgt 7 s767 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s767 7 _ le
  decide +kernel
theorem b768 : Blocked tgt 7 s768 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s768 7 _ le
  decide +kernel
theorem b769 : Blocked tgt 7 s769 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s769 7 _ le
  decide +kernel
theorem b770 : Blocked tgt 7 s770 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s770 7 _ le
  decide +kernel
theorem b771 : Blocked tgt 7 s771 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s771 7 _ le
  decide +kernel
theorem b772 : Blocked tgt 7 s772 := by
  apply PetersenFastNode.node (nxt := #[s773,s774,s242,s243,s775,s776,s777,s778,s779,s780,s781,s782]) (hints := [15104,15104,15232,9041,6590,9169,15232,6590,15232,15104,15104,9169,5942,6590,5942,1685,15104,1685,5942,15104,5942,6590,6590,1685,6590,6590,7486,4534,5364,1745,7486,5364,7486,6590,6590,1745,7478,4526,7478,4542,6590,10961,7478,6590,7478,4526,4526,10961,2462,2462,0,2494,6590,13009,6558,6590,1,2462,2462,13009,13622,6590,13622,6912,15104,2,5558,15104,13622,5558,6590,3,1429,1429,1685,8657,9169,5942,1685,9169,1685,1429,1429,5942,1745,9169,1745,1429,1429,7486,1745,1429,1745,2001,9169,7486,9169,9169,10961,13184,15232,7478,10961,15232,10961,9169,9169,7478,9169,9169,13009,11136,15232,4,13009,15232,13009,9169,9169,5,913,913,6,977,9169,13622,9105,9169,7,913,913,13622,6974,6974,7486,1685,1685,1745,1685,1685,7486,1741,6974,1745,1685,1685,3221,10449,6974,10961,3221,6974,3221,1685,1685,10961,1685,1685,5269,12497,5942,13009,5269,5942,5269,1685,1685,13009,5942,5942,13622,1685,1685,8,1685,1685,13622,5942,5942,9,1745,1745,10961,3221,7486,3221,3793,7486,10961,1745,1745,3221,1745,1745,13009,5269,7486,5269,5841,7486,13009,1745,1745,5269,7486,7486,14654,1745,1745,13622,1681,1745,14654,1681,7486,13622,10961,10961,13009,3382,7478,10,13009,7478,13009,10961,10961,11,2705,2705,13622,2769,10961,14654,10897,10961,13622,2705,2705,14654,4753,4753,9494,4817,13009,13622,12945,13009,9494,4753,4753,13622]) (by decide +kernel)
  change ∀ b ∈ [s773,s774,s242,s243,s775,s776,s777,s778,s779,s780,s781,s782], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s773) b773 <|
    PetersenLocalChildren.push (x := s774) b774 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s775) b775 <|
    PetersenLocalChildren.push (x := s776) b776 <|
    PetersenLocalChildren.push (x := s777) b777 <|
    PetersenLocalChildren.push (x := s778) b778 <|
    PetersenLocalChildren.push (x := s779) b779 <|
    PetersenLocalChildren.push (x := s780) b780 <|
    PetersenLocalChildren.push (x := s781) b781 <|
    PetersenLocalChildren.push (x := s782) b782 <|
    PetersenLocalChildren.nil
theorem b783 : Blocked tgt 7 s783 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(3,false))] s783 7 _ le
  decide +kernel
theorem b784 : Blocked tgt 7 s784 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s784 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
