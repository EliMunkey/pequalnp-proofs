import M189StartData
import M189StartPins0
import M189StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b104 : Blocked tgt 6 s104 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s104 6 _ le
  decide +kernel
theorem b106 : Blocked tgt 6 s106 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s106 6 _ le
  decide +kernel
theorem b107 : Blocked tgt 6 s107 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s107 6 _ le
  decide +kernel
theorem b108 : Blocked tgt 6 s108 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1626,1626,1754,2273,1364,1754,1754,1364,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2533,2533,2273,451,2529,2273,2273,579,2657,2273,2273,1091,3169,2273,3348,2243,2241,2241,1816,451,1816,451,2917,707,2917,707,3429,1219,3429,1219,3348,2243,3348,2243,451,2917,707,451,451,3429,1219,451,451,808,2243,451,707,788,1219,707,707,609,2243,707,1219,1121,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b109 : Blocked tgt 6 s109 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s109 6 _ le
  decide +kernel
theorem b110 : Blocked tgt 6 s110 := by
  apply PetersenFastNode.node (nxt := #[s111,s112]) (hints := [1366,2471,1430,1366,389,1366,453,1756,1756,1366,709,1814,709,3366,1221,3366,1221,3740,2245,3740,2245,2275,2279,2531,2275,2730,2535,2535,2730,2535,581,2919,2535,2535,1093,3431,2535,455,487,2503,455,453,1948,453,2663,709,453,453,3175,1221,453,453,3350,2245,453,0,709,1,709,3626,1221,3626,1221,3740,2245,3740,2245,709,790,1221,709,709,871,2245,709,1221,1383,2245,1221]) (by decide +kernel)
  change ∀ b ∈ [s111,s112], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s111) b111 <|
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.nil
theorem b113 : Blocked tgt 6 s113 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s113 6 _ le
  decide +kernel
theorem b114 : Blocked tgt 6 s114 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s114 6 _ le
  decide +kernel
theorem b115 : Blocked tgt 6 s115 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s115 6 _ le
  decide +kernel
theorem b116 : Blocked tgt 6 s116 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s116 6 _ le
  decide +kernel
theorem b117 : Blocked tgt 6 s117 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s117 6 _ le
  decide +kernel
theorem b118 : Blocked tgt 6 s118 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s118 6 _ le
  decide +kernel
theorem b119 : Blocked tgt 6 s119 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s119 6 _ le
  decide +kernel
theorem b120 : Blocked tgt 6 s120 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s120 6 _ le
  decide +kernel
theorem b121 : Blocked tgt 6 s121 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s121 6 _ le
  decide +kernel
theorem b122 : Blocked tgt 6 s122 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s122 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
