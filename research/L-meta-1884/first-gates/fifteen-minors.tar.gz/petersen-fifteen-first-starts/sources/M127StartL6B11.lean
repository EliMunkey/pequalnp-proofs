import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b322 : Blocked tgt 6 s322 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s322 6 _ le
  decide +kernel
theorem b323 : Blocked tgt 6 s323 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s323 6 _ le
  decide +kernel
theorem b324 : Blocked tgt 6 s324 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s324 6 _ le
  decide +kernel
theorem b325 : Blocked tgt 6 s325 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s325 6 _ le
  decide +kernel
theorem b326 : Blocked tgt 6 s326 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s326 6 _ le
  decide +kernel
theorem b327 : Blocked tgt 6 s327 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s327 6 _ le
  decide +kernel
theorem b328 : Blocked tgt 6 s328 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s328 6 _ le
  decide +kernel
theorem b329 : Blocked tgt 6 s329 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s329 6 _ le
  decide +kernel
theorem b330 : Blocked tgt 6 s330 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s330 6 _ le
  decide +kernel
theorem b331 : Blocked tgt 6 s331 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s331 6 _ le
  decide +kernel
theorem b332 : Blocked tgt 6 s332 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s332 6 _ le
  decide +kernel
theorem b333 : Blocked tgt 6 s333 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s333 6 _ le
  decide +kernel
theorem b338 : Blocked tgt 6 s338 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s338 6 _ le
  decide +kernel
theorem b339 : Blocked tgt 6 s339 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s339 6 _ le
  decide +kernel
theorem b340 : Blocked tgt 6 s340 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s340 6 _ le
  decide +kernel
theorem b341 : Blocked tgt 6 s341 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s341 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
