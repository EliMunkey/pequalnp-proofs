import M127StartData
import M127StartL8B0
import M127StartL8B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_6_1 : NoAtMost (0xf0f0f0f0f0f0f0f0 :: inputs 7) tgt 8 := by
  change NoAtMost [0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 8
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1337] [386,774,387,903,388,1542,1667,1671,774,774,903,903,388,1542,1671,1671,1418,774,1419,903,1420,2694,1675,2695,774,774,903,903,1420,2694,2695,2695,2194,2710,387,903,2452,2710,1667,1671,2710,2710,903,903,2452,2710,1671,1671,1418,2710,1419,903,1420,2710,1675,4743,2710,2710,903,903,1420,2710,4743,4743,4258,4774,387,903,4516,4774,1667,1671,4774,4774,903,903,4516,4774,1671,1671,5290,4774,1419,903,5548,4774,1675,2695,4774,4774,903,903,5548,4774,2695,2695,6322,6838,387,903,6580,6838,1667,1671,6838,6838,903,903,6580,6838,1671,1671,5290,6838,1419,903,5548,6838,1675,9867,6838,6838,903,903,5548,6838,13612,13612,8514,774,8643,903,388,1542,9923,1671,9030,774,9159,903,388,1542,9927,1671,9546,774,9675,903,1420,2694,9931,2695,9030,774,9159,903,1420,2694,10951,2695,10450,2710,8643,903,2452,2710,9923,1671,10966,2710,9159,903,2452,2710,9927,1671,9546,2710,9675,903,1420,2710,9931,4743,10966,2710,9159,903,1420,2710,12999,4743,12514,4774,8643,903,4516,4774,9923,1671,13030,4774,9159,903,4516,4774,9927,1671,13546,4774,9675,903,5548,4774,9931,2695,13030,4774,9159,903,5548,4774,10951,2695,14578,6838,8643,903,6580,6838,9923,1671,15094,6838,9159,903,6580,6838,9927,1671,13546,6838,9675,903,5548,6838,9931,9931,15094,6838,9159,903,5548,6838,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1337], Blocked tgt 8 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1337) b1337 <|
    PetersenLocalChildren.nil
#print axioms gate_2_6_1
end PetersenSmallStarts.M127
