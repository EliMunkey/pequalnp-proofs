import M119StartData
import M119StartL5B1
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_5_1 : NoAtMost (0xf0f0f0f0 :: inputs 6) tgt 5 := by
  change NoAtMost [0xf0f0f0f0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s20,s0,s21] [195,391,196,456,197,839,580,840,391,391,456,456,197,839,840,840,587,847,196,456,717,847,1092,1352,847,847,456,456,717,847,1352,1352,1107,1367,196,456,1237,1367,580,840,1367,1367,456,456,1237,1367,840,840,1627,1887,196,456,1757,1887,1949,3741,1887,1887,456,456,1757,1887,3741,3741,2211,391,2276,456,197,839,2660,840,2471,391,2536,456,197,839,2920,840,2667,847,2276,456,717,847,3172,1352,2927,847,2536,456,717,847,3432,1352,3187,1367,2276,456,1237,1367,2660,840,3447,1367,2536,456,1237,1367,2920,840,3707,1887,2276,456,1757,1887,1949,0,3967,1887,2536,456,1757,1887,1,2] (by decide +kernel)
  change ∀ b ∈ [s20,s0,s21], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.nil
#print axioms gate_2_5_1
end PetersenSmallStarts.M119
