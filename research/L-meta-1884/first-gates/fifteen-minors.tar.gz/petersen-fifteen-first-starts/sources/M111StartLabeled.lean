import M111StartBank
import SmallStartRelabel
open PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxRecDepth 200000
set_option maxHeartbeats 0
set_option exponentiation.threshold 8192
private def a0 (x : Fin 64) : Fin 64 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63] : Array (Fin 64))[x.val]?.getD 0
private theorem cover0 : i6.all (fun q => i6.contains (PetersenPackedPin.project a0 q)) = true := by decide +kernel
private theorem same0 : PetersenPackedPin.project a0 tgt=tgt := by decide +kernel
theorem labeled_0_2_2 : NoAtMost (0x5050505050505050 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x5050505050505050) (a:=0xa0a0a0a0a0a0a0a) (by decide +kernel) gate_0_2_1
theorem labeled_1_2_0 : NoAtMost (0xfcfcfcfcfcfcfcfc :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfcfcfcfcfcfcfcfc) (a:=0xeeeeeeeeeeeeeeee) (by decide +kernel) gate_0_1_0
theorem labeled_1_2_1 : NoAtMost (0xc0c0c0c0c0c0c0c :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c) (a:=0x4444444444444444) (by decide +kernel) gate_0_1_2
theorem labeled_1_2_2 : NoAtMost (0x3030303030303030 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3030303030303030) (a:=0x2222222222222222) (by decide +kernel) gate_0_1_1
theorem labeled_1_2_3 : NoAtMost (0xc0c0c0c0c0c0c0c0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xc0c0c0c0c0c0c0c0) (a:=0x8888888888888888) (by decide +kernel) gate_0_1_3
theorem labeled_1_4_1 : NoAtMost (0xcccc0000cccc :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000cccc) (a:=0xcc00cc00cc00cc) (by decide +kernel) gate_1_3_1
theorem labeled_1_4_2 : NoAtMost (0x3333000033330000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0x3333000033330000) (a:=0x3300330033003300) (by decide +kernel) gate_1_3_2
theorem labeled_1_4_3 : NoAtMost (0xcccc0000cccc0000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xcccc0000cccc0000) (a:=0xcc00cc00cc00cc00) (by decide +kernel) gate_1_3_3
theorem labeled_2_3_0 : NoAtMost (0xfff0fff0fff0fff0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfff0fff0fff0fff0) (a:=0xffffaaaaffffaaaa) (by decide +kernel) gate_0_4_0
theorem labeled_2_3_1 : NoAtMost (0xf000f000f000f0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f0) (a:=0xaaaa0000aaaa) (by decide +kernel) gate_0_4_1
theorem labeled_2_3_2 : NoAtMost (0xf000f000f000f00 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf000f000f000f00) (a:=0x5555000055550000) (by decide +kernel) gate_0_4_2
theorem labeled_2_4_0 : NoAtMost (0xfffff0f0fffff0f0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xfffff0f0fffff0f0) (a:=0xffaaffaaffaaffaa) (by decide +kernel) gate_0_3_0
theorem labeled_2_4_1 : NoAtMost (0xf0f00000f0f0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f00000f0f0) (a:=0xaa00aa00aa00aa) (by decide +kernel) gate_0_3_1
theorem labeled_2_4_2 : NoAtMost (0xf0f00000f0f0000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f00000f0f0000) (a:=0x5500550055005500) (by decide +kernel) gate_0_3_2
theorem labeled_2_4_3 : NoAtMost (0xf0f00000f0f00000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f00000f0f00000) (a:=0xaa00aa00aa00aa00) (by decide +kernel) gate_0_3_3
theorem labeled_2_5_1 : NoAtMost (0xf0f0f0f0 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0f0f0) (a:=0xaaaaaaaa) (by decide +kernel) gate_0_5_1
theorem labeled_2_5_2 : NoAtMost (0xf0f0f0f00000000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0f0f00000000) (a:=0x5555555500000000) (by decide +kernel) gate_0_5_2
theorem labeled_2_5_3 : NoAtMost (0xf0f0f0f000000000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xf0f0f0f000000000) (a:=0xaaaaaaaa00000000) (by decide +kernel) gate_0_5_3
theorem labeled_3_4_2 : NoAtMost (0xff000000ff0000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xff000000ff0000) (a:=0xff000000ff00) (by decide +kernel) gate_3_4_1
theorem labeled_4_5_0 : NoAtMost (0xffffffffffff0000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffffffffffff0000) (a:=0xffffffffff00ff00) (by decide +kernel) gate_3_5_0
theorem labeled_4_5_1 : NoAtMost (0xffff0000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff0000) (a:=0xff00ff00) (by decide +kernel) gate_3_5_1
theorem labeled_4_5_2 : NoAtMost (0xffff00000000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff00000000) (a:=0xff00ff00000000) (by decide +kernel) gate_3_5_2
theorem labeled_4_5_3 : NoAtMost (0xffff000000000000 :: inputs 6) tgt 6 :=
  PetersenSmallStarts.relabel_aux a0 cover0 same0 (g:=0xffff000000000000) (a:=0xff00ff0000000000) (by decide +kernel) gate_3_5_3
def forbidden : List (BitVec 64) := [0xeeeeeeeeeeeeeeee,0x2222222222222222,0x4444444444444444,0x8888888888888888,0xa0a0a0a0a0a0a0a,0x5050505050505050,0xa0a0a0a0a0a0a0a0,0xffaaffaaffaaffaa,0xaa00aa00aa00aa,0x5500550055005500,0xaa00aa00aa00aa00,0xffffaaaaffffaaaa,0xaaaa0000aaaa,0x5555000055550000,0xaaaaaaaa,0x5555555500000000,0xaaaaaaaa00000000,0xfcfcfcfcfcfcfcfc,0xc0c0c0c0c0c0c0c,0x3030303030303030,0xc0c0c0c0c0c0c0c0,0xcc00cc00cc00cc,0x3300330033003300,0xcc00cc00cc00cc00,0xcccc0000cccc,0x3333000033330000,0xcccc0000cccc0000,0xffffffffcccccccc,0xcccccccc,0x3333333300000000,0xfff0fff0fff0fff0,0xf000f000f000f0,0xf000f000f000f00,0xfffff0f0fffff0f0,0xf0f00000f0f0,0xf0f00000f0f0000,0xf0f00000f0f00000,0xf0f0f0f0,0xf0f0f0f00000000,0xf0f0f0f000000000,0xffffff00ffffff00,0xff000000ff00,0xff000000ff0000,0xff000000ff000000,0xffffffffff00ff00,0xff00ff00,0xff00ff00000000,0xff00ff0000000000,0xffffffffffff0000,0xffff0000,0xffff00000000,0xffff000000000000]
theorem all_forbidden (g : BitVec 64) (h : g∈forbidden) : NoAtMost (g::inputs 6) tgt 6 := by
  have bank : ∀ x ∈ forbidden, NoAtMost (x::inputs 6) tgt 6 :=
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xeeeeeeeeeeeeeeee) gate_0_1_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x2222222222222222) gate_0_1_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x4444444444444444) gate_0_1_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x8888888888888888) gate_0_1_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xa0a0a0a0a0a0a0a) gate_0_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x5050505050505050) labeled_0_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xa0a0a0a0a0a0a0a0) gate_0_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffaaffaaffaaffaa) gate_0_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xaa00aa00aa00aa) gate_0_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x5500550055005500) gate_0_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xaa00aa00aa00aa00) gate_0_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffffaaaaffffaaaa) gate_0_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xaaaa0000aaaa) gate_0_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x5555000055550000) gate_0_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xaaaaaaaa) gate_0_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x5555555500000000) gate_0_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xaaaaaaaa00000000) gate_0_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xfcfcfcfcfcfcfcfc) labeled_1_2_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xc0c0c0c0c0c0c0c) labeled_1_2_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x3030303030303030) labeled_1_2_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xc0c0c0c0c0c0c0c0) labeled_1_2_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xcc00cc00cc00cc) gate_1_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x3300330033003300) gate_1_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xcc00cc00cc00cc00) gate_1_3_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xcccc0000cccc) labeled_1_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x3333000033330000) labeled_1_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xcccc0000cccc0000) labeled_1_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffffffffcccccccc) gate_1_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xcccccccc) gate_1_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0x3333333300000000) gate_1_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xfff0fff0fff0fff0) labeled_2_3_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf000f000f000f0) labeled_2_3_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf000f000f000f00) labeled_2_3_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xfffff0f0fffff0f0) labeled_2_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f00000f0f0) labeled_2_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f00000f0f0000) labeled_2_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f00000f0f00000) labeled_2_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f0f0f0) labeled_2_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f0f0f00000000) labeled_2_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xf0f0f0f000000000) labeled_2_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffffff00ffffff00) gate_3_4_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff000000ff00) gate_3_4_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff000000ff0000) labeled_3_4_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff000000ff000000) gate_3_4_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffffffffff00ff00) gate_3_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff00ff00) gate_3_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff00ff00000000) gate_3_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xff00ff0000000000) gate_3_5_3 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffffffffffff0000) labeled_4_5_0 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffff0000) labeled_4_5_1 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffff00000000) labeled_4_5_2 <|
    PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 6) tgt 6) (x:=0xffff000000000000) labeled_4_5_3 <|
    PetersenLocalChildren.nil
  exact bank g h
#print axioms all_forbidden
end PetersenSmallStarts.M111
