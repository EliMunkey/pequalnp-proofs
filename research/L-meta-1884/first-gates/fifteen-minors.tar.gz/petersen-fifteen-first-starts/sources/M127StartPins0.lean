import M127StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small0 : NoAtMost i5 (PetersenPackedPin.project r0 tgt) 6 := by
  have a : PetersenPackedPin.project r0 tgt = table 31 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 31 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r4 (x : Fin 64) : Fin 128 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27,32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59,64,65,66,67,72,73,74,75,80,81,82,83,88,89,90,91,96,97,98,99,104,105,106,107,112,113,114,115,120,121,122,123] : Array (Fin 128))[x.val]?.getD 0
theorem small4 : NoAtMost i6 (PetersenPackedPin.project r4 tgt) 6 := by
  have a : PetersenPackedPin.project r4 tgt = table 123 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 123 0 (by decide +kernel) (by decide +kernel)
theorem hot4 : forcedConst r4 tgt = false := by decide +kernel
def r5 (x : Fin 64) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111] : Array (Fin 128))[x.val]?.getD 0
theorem small5 : NoAtMost i6 (PetersenPackedPin.project r5 tgt) 6 := by
  have a : PetersenPackedPin.project r5 tgt = table 111 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 111 0 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
def r6 (x : Fin 16) : Fin 128 := (#[0,2,4,6,8,10,12,14,64,66,68,70,72,74,76,78] : Array (Fin 128))[x.val]?.getD 0
theorem small6 : NoAtMost i4 (PetersenPackedPin.project r6 tgt) 3 := by
  have a : PetersenPackedPin.project r6 tgt = table 78 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 78 0 (by decide +kernel) (by decide +kernel)
theorem hot6 : forcedConst r6 tgt = false := by decide +kernel
def r7 (x : Fin 16) : Fin 128 := (#[32,34,36,38,40,42,44,46,96,98,100,102,104,106,108,110] : Array (Fin 128))[x.val]?.getD 0
theorem small7 : NoAtMost i4 (PetersenPackedPin.project r7 tgt) 3 := by
  have a : PetersenPackedPin.project r7 tgt = table 78 32 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 78 32 (by decide +kernel) (by decide +kernel)
theorem hot7 : forcedConst r7 tgt = false := by decide +kernel
def r8 (x : Fin 16) : Fin 128 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30] : Array (Fin 128))[x.val]?.getD 0
theorem small8 : NoAtMost i4 (PetersenPackedPin.project r8 tgt) 3 := by
  have a : PetersenPackedPin.project r8 tgt = table 30 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 30 0 (by decide +kernel) (by decide +kernel)
theorem hot8 : forcedConst r8 tgt = false := by decide +kernel
def r10 (x : Fin 16) : Fin 128 := (#[32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62] : Array (Fin 128))[x.val]?.getD 0
theorem small10 : NoAtMost i4 (PetersenPackedPin.project r10 tgt) 3 := by
  have a : PetersenPackedPin.project r10 tgt = table 30 32 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 30 32 (by decide +kernel) (by decide +kernel)
theorem hot10 : forcedConst r10 tgt = false := by decide +kernel
def r12 (x : Fin 16) : Fin 128 := (#[0,1,8,9,16,17,24,25,32,33,40,41,48,49,56,57] : Array (Fin 128))[x.val]?.getD 0
theorem small12 : NoAtMost i4 (PetersenPackedPin.project r12 tgt) 3 := by
  have a : PetersenPackedPin.project r12 tgt = table 57 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 57 0 (by decide +kernel) (by decide +kernel)
theorem hot12 : forcedConst r12 tgt = false := by decide +kernel
def r13 (x : Fin 16) : Fin 128 := (#[64,65,72,73,80,81,88,89,96,97,104,105,112,113,120,121] : Array (Fin 128))[x.val]?.getD 0
theorem small13 : NoAtMost i4 (PetersenPackedPin.project r13 tgt) 3 := by
  have a : PetersenPackedPin.project r13 tgt = table 57 64 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 57 64 (by decide +kernel) (by decide +kernel)
theorem hot13 : forcedConst r13 tgt = false := by decide +kernel
def r14 (x : Fin 16) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29] : Array (Fin 128))[x.val]?.getD 0
theorem small14 : NoAtMost i4 (PetersenPackedPin.project r14 tgt) 3 := by
  have a : PetersenPackedPin.project r14 tgt = table 29 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 29 0 (by decide +kernel) (by decide +kernel)
theorem hot14 : forcedConst r14 tgt = false := by decide +kernel
def r15 (x : Fin 16) : Fin 128 := (#[64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93] : Array (Fin 128))[x.val]?.getD 0
theorem small15 : NoAtMost i4 (PetersenPackedPin.project r15 tgt) 3 := by
  have a : PetersenPackedPin.project r15 tgt = table 29 64 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 29 64 (by decide +kernel) (by decide +kernel)
theorem hot15 : forcedConst r15 tgt = false := by decide +kernel
def r18 (x : Fin 16) : Fin 128 := (#[0,1,2,3,32,33,34,35,64,65,66,67,96,97,98,99] : Array (Fin 128))[x.val]?.getD 0
theorem small18 : NoAtMost i4 (PetersenPackedPin.project r18 tgt) 3 := by
  have a : PetersenPackedPin.project r18 tgt = table 99 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 99 0 (by decide +kernel) (by decide +kernel)
theorem hot18 : forcedConst r18 tgt = false := by decide +kernel
end PetersenSmallStarts.M127
