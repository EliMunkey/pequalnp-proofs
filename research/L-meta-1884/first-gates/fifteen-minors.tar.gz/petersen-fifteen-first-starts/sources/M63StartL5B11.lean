import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b360 : Blocked tgt 5 s360 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s360 5 _ le
  decide +kernel
theorem b384 : Blocked tgt 5 s384 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s384 5 _ le
  decide +kernel
theorem b389 : Blocked tgt 5 s389 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(true,(0,false),(5,false))] s389 5 _ le
  decide +kernel
theorem b390 : Blocked tgt 5 s390 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,388,453,388,453,2762,841,3018,841,1682,837,1682,837,1674,1349,1674,1349,713,197,841,713,453,201,837,453,453,388,1349,453,402,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b391 : Blocked tgt 5 s391 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s391 5 _ le
  decide +kernel
theorem b392 : Blocked tgt 5 s392 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(true,(0,false),(5,false))] s392 5 _ le
  decide +kernel
theorem b393 : Blocked tgt 5 s393 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [388,453,388,1348,2794,841,3050,2794,1234,2282,1682,1234,1706,1234,1706,1770,714,746,2762,714,713,197,841,713,453,201,837,453,453,388,388,453,453,388,2373,453,402,837,833,833,841,402,938,841,841,2117,2633,841,837,1682,1682,837,837,2121,2373,837,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b394 : Blocked tgt 5 s394 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(true,(0,false),(5,false))] s394 5 _ le
  decide +kernel
theorem b396 : Blocked tgt 5 s396 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,453,1428,1364,2794,841,3050,2794,1234,2282,1682,1234,1706,1234,1706,1770,714,746,2762,714,713,197,841,713,453,201,837,453,453,1428,1428,453,453,404,2373,453,1426,837,833,833,841,1426,1706,841,841,2117,2633,841,837,1682,1682,837,837,2121,2373,837,2373,1706,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b397 : Blocked tgt 5 s397 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(true,(0,false),(5,false))] s397 5 _ le
  decide +kernel
theorem b398 : Blocked tgt 5 s398 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s398 5 _ le
  decide +kernel
theorem b399 : Blocked tgt 5 s399 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s399 5 _ le
  decide +kernel
theorem b403 : Blocked tgt 5 s403 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(false,(0,true),(5,false))] s403 5 _ le
  decide +kernel
theorem b404 : Blocked tgt 5 s404 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1234,1234,2373,1349,1674,1349,2373,453,388,453,2633,841,2117,841,2373,837,2121,837,1674,1349,1674,1349,3152,453,3280,453,3282,841,3538,841,1682,837,1682,837,453,1546,453,1349,841,1093,841,1609,837,1097,837,1349,713,197,841,713,453,201,837,453,1682,837,833,833]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b405 : Blocked tgt 5 s405 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s405 5 _ le
  decide +kernel
theorem b406 : Blocked tgt 5 s406 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s406 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
