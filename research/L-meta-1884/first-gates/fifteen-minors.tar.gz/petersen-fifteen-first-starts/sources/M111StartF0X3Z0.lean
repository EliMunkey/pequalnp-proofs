import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_0 : NoAtMost (0xffaaffaaffaaffaa :: inputs 6) tgt 6 := by
  change NoAtMost [0xffaaffaaffaaffaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s27] [194,195,195,195,196,204,835,835,390,455,455,455,196,204,839,839,714,714,715,715,716,716,843,843,390,455,455,455,716,716,1351,1351,1106,1114,195,195,1236,1244,835,835,1366,455,455,455,1236,1244,839,839,1626,1626,715,715,1756,1756,843,843,1366,455,455,455,1756,1756,3740,3740,2210,2275,2275,2275,196,204,2915,2915,2470,2535,2535,2535,196,204,2919,2919,2730,2730,2795,2795,716,716,2923,2923,2470,2535,2535,2535,716,716,3431,3431,3186,3194,2275,2275,1236,1244,2915,2915,3446,2535,2535,2535,1236,1244,2919,2919,3706,3706,2795,2795,1756,1756,2923,2923,3446,2535,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s27], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_0
end PetersenSmallStarts.M111
