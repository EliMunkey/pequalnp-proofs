import M15StartData
import M15StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_1 : NoAtMost (0xaa :: inputs 4) tgt 3 := by
  change NoAtMost [0xaa,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 3
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s0,s10] [50,51,51,51,52,100,211,219,102,119,119,119,52,180,215,198,186,51,187,51,188,188,219,219,102,119,119,119,188,188,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s10], Blocked tgt 3 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_1
end PetersenSmallStarts.M15
