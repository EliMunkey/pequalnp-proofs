import M127StartData
import M127StartPins0
import M127StartL5B0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b85 : Blocked tgt 6 s85 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s85 6 _ le
  decide +kernel
theorem b86 : Blocked tgt 6 s86 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s86 6 _ le
  decide +kernel
theorem b87 : Blocked tgt 6 s87 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s87 6 _ le
  decide +kernel
theorem b88 : Blocked tgt 6 s88 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s88 6 _ le
  decide +kernel
theorem b89 : Blocked tgt 6 s89 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s89 6 _ le
  decide +kernel
theorem b90 : Blocked tgt 6 s90 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s90 6 _ le
  decide +kernel
theorem b91 : Blocked tgt 6 s91 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s91 6 _ le
  decide +kernel
theorem b92 : Blocked tgt 6 s92 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s92 6 _ le
  decide +kernel
theorem b93 : Blocked tgt 6 s93 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s93 6 _ le
  decide +kernel
theorem b94 : Blocked tgt 6 s94 := by
  apply PetersenFastNode.node (nxt := #[s34,s95]) (hints := [9484,1420,0,1420,2870,2870,9867,1675,1739,1675,9863,1671,1735,1671,10887,2695,2759,2695,9095,903,967,903,1420,11190,1420,1675,1804,1420,2452,1671,3348,1671,1420,2695,3340,2695,775,775,1420,903,5674,1675,5674,1675,7734,1671,7734,1671,8998,2695,11046,2695,1,903,11030,903,2836,1671,1667,1667,1675,2183,3211,1675,1419,391,1419,1675,1671,2187,2695,1671,903,395,903,1671,903,3340,903,2695]) (by decide +kernel)
  change ∀ b ∈ [s34,s95], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s34) b34 <|
    PetersenLocalChildren.push (x := s95) b95 <|
    PetersenLocalChildren.nil
theorem b96 : Blocked tgt 6 s96 := by
  apply PetersenFastNode.node (nxt := #[s10,s97,s98]) (hints := [2871,2999,1421,1740,5739,1421,2453,1672,3349,1672,1421,2696,3341,2696,776,776,1421,904,1421,0,9485,1421,5739,1740,1899,1740,2871,1672,3895,1672,807,2696,2855,2696,1,904,2839,904,2,2871,2871,9485,3349,1672,1732,1672,1740,2696,3788,1740,1740,904,1996,1740,1676,1676,1672,10444,2696,1672,904,8652,904,1672,3349,1672,1672,3349,904,3341,904,2696,3212,2696,2696,3212,1420,904,904,1420]) (by decide +kernel)
  change ∀ b ∈ [s10,s97,s98], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s10) b10 <|
    PetersenLocalChildren.push (x := s97) b97 <|
    PetersenLocalChildren.push (x := s98) b98 <|
    PetersenLocalChildren.nil
theorem b99 : Blocked tgt 6 s99 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s99 6 _ le
  decide +kernel
theorem b100 : Blocked tgt 6 s100 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s100 6 _ le
  decide +kernel
theorem b101 : Blocked tgt 6 s101 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s101 6 _ le
  decide +kernel
theorem b102 : Blocked tgt 6 s102 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s102 6 _ le
  decide +kernel
theorem b105 : Blocked tgt 6 s105 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s105 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
