import M45StartData
import M45StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M45
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b0 : Blocked tgt 2 s0 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s0 2 _ le
  decide +kernel
theorem b1 : Blocked tgt 2 s1 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s1 2 _ le
  decide +kernel
theorem b2 : Blocked tgt 2 s2 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s2 2 _ le
  decide +kernel
theorem b3 : Blocked tgt 2 s3 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s3 2 _ le
  decide +kernel
theorem b4 : Blocked tgt 2 s4 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s4 2 _ le
  decide +kernel
theorem b5 : Blocked tgt 2 s5 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s5 2 _ le
  decide +kernel
theorem b6 : Blocked tgt 2 s6 := by
  intro k le c
  apply rejects_sound r0 i2 0 tgt small0 hot0 [] s6 2 _ le
  decide +kernel
end PetersenSmallStarts.M45
