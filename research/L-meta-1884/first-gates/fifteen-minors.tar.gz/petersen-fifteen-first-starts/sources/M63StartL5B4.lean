import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b133 : Blocked tgt 5 s133 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [453,453,1234,1364,1426,841,1426,713,965,837,713,837,2373,1349,1544,1349,1428,1234,1492,1428,841,1426,841,1424,837,1554,1349,404,1349,388,1234,841,1426,841,1234,837,1812,837,194,1349,1218,1349,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b140 : Blocked tgt 5 s140 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [713,777,3316,713,3444,2664,3444,773,3892,3444,2404,2420,3428,2404,1364,1396,3412,1364,841,2856,3316,837,833,833,841,1093,1609,841,841,2117,2633,841,3312,837,3632,837,2792,1349,3624,1349,712,2373,2760,2373,837,1097,1349,837,837,2121,2373,837,1349,1576,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b141 : Blocked tgt 5 s141 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s141 5 _ le
  decide +kernel
theorem b146 : Blocked tgt 5 s146 := by
  apply PetersenFastNode.node (nxt := #[s128]) (hints := [3445,3445,714,842,198,714,390,838,202,390,390,1350,3625,390,390,2374,0,390,2793,842,2857,842,3509,838,3893,838,2469,1350,3493,1350,1429,2374,3477,2374,3633,838,834,834,842,1094,1610,842,842,2118,2634,842,838,1098,1350,838,838,2122,2374,838,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s128], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.nil
theorem b147 : Blocked tgt 5 s147 := by
  apply PetersenFastNode.node (nxt := #[s129]) (hints := [3445,3445,458,458,198,714,454,454,202,838,714,1350,3625,1350,714,2374,0,2374,2473,842,2473,842,3509,838,3509,838,2793,1350,3625,1350,713,2374,2761,2374,3633,838,834,834,842,1094,1610,842,842,2118,2634,842,838,1098,1350,838,838,2122,2374,838,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s129], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s129) b129 <|
    PetersenLocalChildren.nil
theorem b150 : Blocked tgt 5 s150 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s150 5 _ le
  decide +kernel
theorem b151 : Blocked tgt 5 s151 := by
  apply PetersenFastNode.node (nxt := #[s132]) (hints := [2665,2665,714,842,2857,714,194,706,202,194,714,1610,3625,714,714,2634,0,714,2793,842,2857,842,3313,2281,3633,3313,2793,1610,3625,1610,713,2634,2761,2634,3505,842,834,834,842,2481,1610,842,842,809,2634,842,1090,1098,1090,1602,2114,2122,2114,2626,1610,1577,2634,1610]) (by decide +kernel)
  change ∀ b ∈ [s132], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s132) b132 <|
    PetersenLocalChildren.nil
theorem b165 : Blocked tgt 5 s165 := by
  apply PetersenFastNode.node (nxt := #[s166]) (hints := [715,778,907,715,1525,715,1683,1525,1461,715,1461,1525,485,501,1509,485,1365,1397,1493,1365,1427,842,842,1427,0,842,842,1457,842,1094,1610,842,714,198,714,842,838,838,1350,1610,1350,1610,454,714,454,714,1350,1610,1350,1610,454,714,454,714,454,1547,454,1350]) (by decide +kernel)
  change ∀ b ∈ [s166], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s166) b166 <|
    PetersenLocalChildren.nil
theorem b167 : Blocked tgt 5 s167 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s167 5 _ le
  decide +kernel
theorem b168 : Blocked tgt 5 s168 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2986,2794,777,2794,841,713,193,713,833,841,833,3506,841,1609,1089,841,841,2633,2113,841,2664,2666,2792,2664,3762,2794,3762,3826,2794,1545,3754,2794,714,746,2762,714,3634,713,713,3762,713,3626,1609,713,713,1456,2633,713,833,1609,3746,1609,1682,2633,3730,2633,1609,1706,2633,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b173 : Blocked tgt 5 s173 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s173 5 _ le
  decide +kernel
theorem b174 : Blocked tgt 5 s174 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s174 5 _ le
  decide +kernel
theorem b179 : Blocked tgt 5 s179 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s179 5 _ le
  decide +kernel
theorem b180 : Blocked tgt 5 s180 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s180 5 _ le
  decide +kernel
theorem b181 : Blocked tgt 5 s181 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s181 5 _ le
  decide +kernel
theorem b190 : Blocked tgt 5 s190 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,714,1364,714,2373,453,1428,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1544,1349,389,389,714,453,714,841,906,714,1234,202,1682,1234,714,210,1674,714,713,197,841,713,453,201,837,453,453,1674,1349,453,1426,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
