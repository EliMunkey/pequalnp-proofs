import M55StartData
import M55StartL4B0
import M55StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_3_3 : NoAtMost (0xf000f000 :: inputs 5) tgt 4 := by
  change NoAtMost [0xf000f000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s29] [98,430,99,99,100,100,291,291,198,430,231,231,100,100,423,679,298,430,99,99,364,364,547,547,430,430,231,231,364,364,679,679,562,958,99,99,628,628,291,291,694,958,231,231,628,628,423,291,826,958,99,99,892,892,988,724,958,958,231,231,892,892,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s29], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.nil
#print axioms gate_2_3_3
end PetersenSmallStarts.M55
