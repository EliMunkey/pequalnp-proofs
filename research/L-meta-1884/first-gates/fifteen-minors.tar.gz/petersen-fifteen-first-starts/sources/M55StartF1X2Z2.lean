import M55StartData
import M55StartL4B0
import M55StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M55
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_2_2 : NoAtMost (0x30303030 :: inputs 5) tgt 4 := by
  change NoAtMost [0x30303030,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s21] [98,422,99,423,100,422,291,423,198,422,231,423,100,422,423,423,298,430,99,679,364,430,547,679,430,430,231,679,364,430,679,679,562,694,99,423,628,694,291,423,694,694,231,423,628,694,423,423,826,958,99,99,892,958,988,988,958,958,231,99,892,958,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s21], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.nil
#print axioms gate_1_2_2
end PetersenSmallStarts.M55
