import M47StartData
import M47StartL4B0
import M47StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_3_1 : NoAtMost (0xcc00cc :: inputs 5) tgt 4 := by
  change NoAtMost [0xcc00cc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s18] [98,100,99,196,100,100,419,196,198,100,231,423,100,100,423,423,362,100,363,196,364,100,427,196,198,100,231,679,364,100,679,679,562,628,99,724,628,628,419,724,694,628,231,423,628,628,423,423,826,628,363,724,892,628,427,724,694,628,231,363,892,628,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s18], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s18) b18 <|
    PetersenLocalChildren.nil
#print axioms gate_1_3_1
end PetersenSmallStarts.M47
