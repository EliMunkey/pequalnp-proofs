import M127StartData
import M127StartPins0
import M127StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b228 : Blocked tgt 6 s228 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s228 6 _ le
  decide +kernel
theorem b229 : Blocked tgt 6 s229 := by
  apply PetersenFastNode.node (nxt := #[s230]) (hints := [4742,0,9483,1419,6805,1419,2837,2837,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,1419,2709,4742,9094,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,6805,1419,1419,6805,1419,1674,1803,1419,2451,395,3347,2451,1419,403,3339,1419,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,2835,779,3347,2835,1803,787,3339,1803,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s230], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s230) b230 <|
    PetersenLocalChildren.nil
theorem b231 : Blocked tgt 6 s231 := by
  apply PetersenFastNode.node (nxt := #[s232]) (hints := [1419,2709,902,902,5834,1738,4742,1738,4742,1670,12490,1670,4742,2694,3339,2694,5258,4742,4742,5258,2837,1419,2837,2965,1419,1738,1609,1738,2451,1670,3347,1670,1419,2694,3339,2694,1419,6805,9483,1419,1738,2837,1738,1865,1670,3091,1670,2837,2694,789,2694,773,0,2837,2837,9481,3347,1670,1730,1670,1738,2694,3786,1738,1674,1674,1670,10442,2694,1670,3347,1670,1670,3347,3210,2694,2694,3210]) (by decide +kernel)
  change ∀ b ∈ [s232], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s232) b232 <|
    PetersenLocalChildren.nil
theorem b234 : Blocked tgt 6 s234 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s234 6 _ le
  decide +kernel
theorem b240 : Blocked tgt 6 s240 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s240 6 _ le
  decide +kernel
theorem b241 : Blocked tgt 6 s241 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s241 6 _ le
  decide +kernel
theorem b242 : Blocked tgt 6 s242 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s242 6 _ le
  decide +kernel
theorem b243 : Blocked tgt 6 s243 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s243 6 _ le
  decide +kernel
theorem b244 : Blocked tgt 6 s244 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s244 6 _ le
  decide +kernel
theorem b245 : Blocked tgt 6 s245 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s245 6 _ le
  decide +kernel
theorem b246 : Blocked tgt 6 s246 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s246 6 _ le
  decide +kernel
theorem b247 : Blocked tgt 6 s247 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s247 6 _ le
  decide +kernel
theorem b248 : Blocked tgt 6 s248 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s248 6 _ le
  decide +kernel
theorem b249 : Blocked tgt 6 s249 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s249 6 _ le
  decide +kernel
theorem b250 : Blocked tgt 6 s250 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s250 6 _ le
  decide +kernel
theorem b260 : Blocked tgt 6 s260 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s260 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
