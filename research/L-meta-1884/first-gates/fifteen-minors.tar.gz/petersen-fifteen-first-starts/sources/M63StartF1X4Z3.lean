import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_4_3 : NoAtMost (0xcccc0000cccc0000 :: inputs 6) tgt 7 := by
  change NoAtMost [0xcccc0000cccc0000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s989] [194,1236,195,195,196,1236,835,835,390,1236,455,455,196,1236,839,839,714,1236,715,715,716,1236,843,843,390,1236,455,455,716,1236,1351,1351,1106,1236,195,195,1236,1236,835,835,1366,1236,455,455,1236,1236,839,839,714,1236,715,715,716,1236,843,843,1366,1236,455,455,716,1236,2375,2375,2146,3316,195,195,2276,3316,835,835,2406,3316,455,455,2276,3316,839,839,2666,3316,715,715,2796,3316,843,843,2406,3316,455,455,2796,3316,1351,1351,3186,3316,195,195,3316,3316,835,835,3446,3316,455,455,3316,3316,839,839,2666,3316,715,715,2796,3316,843,843,3446,3316,455,455,2796,3316,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s989], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s989) b989 <|
    PetersenLocalChildren.nil
#print axioms gate_1_4_3
end PetersenSmallStarts.M63
