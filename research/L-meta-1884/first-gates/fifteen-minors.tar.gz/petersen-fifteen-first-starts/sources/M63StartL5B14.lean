import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b512 : Blocked tgt 5 s512 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s512 5 _ le
  decide +kernel
theorem b513 : Blocked tgt 5 s513 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s513 5 _ le
  decide +kernel
theorem b514 : Blocked tgt 5 s514 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s514 5 _ le
  decide +kernel
theorem b515 : Blocked tgt 5 s515 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s515 5 _ le
  decide +kernel
theorem b516 : Blocked tgt 5 s516 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,2762,468,468,906,841,906,2762,210,2250,722,210,1674,210,714,714,2372,2762,2762,1349,841,906,841,906,837,1554,837,1428,2373,404,2373,1674,453,453,1426,837,833,833,2633,841,841,2117,841,1093,1609,841,2373,837,837,2121,837,1097,1349,837,2373,1349,1674,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b517 : Blocked tgt 5 s517 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2762,1349,2762,1364,453,1428,841,1093,841,1609,837,1097,837,1349,1349,1544,1364,453,388,1364,1104,1108,1360,1104,1364,2250,1812,1364,1674,1364,1364,714,713,197,841,713,1812,201,1812,453,2373,453,453,388,1552,1556,1552,1808,2633,841,841,2117,2373,1812,1812,2121]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b518 : Blocked tgt 5 s518 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,1364,714,1364,453,453,2633,841,2117,841,2373,837,2121,837,2373,1349,1674,1349,1364,714,388,1364,1104,841,1360,841,1364,837,1812,1364,1545,1349,1364,1349,841,778,841,904,837,1682,837,388,1349,1674,1349,388,1552,837,833,833,841,1093,1609,841,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b519 : Blocked tgt 5 s519 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s519 5 _ le
  decide +kernel
theorem b520 : Blocked tgt 5 s520 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s520 5 _ le
  decide +kernel
theorem b523 : Blocked tgt 5 s523 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s523 5 _ le
  decide +kernel
theorem b524 : Blocked tgt 5 s524 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s524 5 _ le
  decide +kernel
theorem b525 : Blocked tgt 5 s525 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [389,389,714,453,1364,714,714,1364,714,841,906,714,1234,202,1682,1234,714,210,1674,714,453,1428,713,197,841,713,453,201,837,453,453,1674,1477,453,2633,841,2117,841,2373,837,2121,837,1349,1349,1544,2373,1426,837,833,833,841,402,1674,841,837,1674,1666,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b526 : Blocked tgt 5 s526 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,453,1428,1364,906,841,906,2762,1234,2250,1682,1234,2762,210,1234,2762,2762,1234,714,714,713,197,841,713,453,201,837,453,453,1428,1349,453,2373,453,453,388,1426,837,833,833,841,1093,1609,841,2633,841,841,2117,837,1097,1349,837,2373,837,837,2121,1349,1674]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b527 : Blocked tgt 5 s527 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s527 5 _ le
  decide +kernel
theorem b528 : Blocked tgt 5 s528 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s528 5 _ le
  decide +kernel
theorem b529 : Blocked tgt 5 s529 := by
  apply PetersenFastNode.node (nxt := #[s530]) (hints := [715,715,1350,454,389,454,2634,1350,1094,2634,1350,838,2122,838,1610,1350,1350,2634,389,454,389,454,2763,1093,403,2763,1235,838,1683,838,1675,1235,1675,1739,714,454,454,714,454,202,838,454,714,454,454,714,403,838,915,838,842,842,0,838,838,1667]) (by decide +kernel)
  change ∀ b ∈ [s530], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s530) b530 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
