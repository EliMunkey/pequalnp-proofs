import M189StartData
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b239 : Blocked tgt 4 s239 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s239 4 _ le
  decide +kernel
theorem b242 : Blocked tgt 4 s242 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s242 4 _ le
  decide +kernel
theorem b259 : Blocked tgt 4 s259 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s259 4 _ le
  decide +kernel
theorem b262 : Blocked tgt 4 s262 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s262 4 _ le
  decide +kernel
end PetersenSmallStarts.M189
