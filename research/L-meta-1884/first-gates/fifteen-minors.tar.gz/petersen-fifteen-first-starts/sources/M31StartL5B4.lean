import M31StartData
import M31StartPins0
import M31StartL4B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b92 : Blocked tgt 5 s92 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s92 5 _ le
  decide +kernel
theorem b93 : Blocked tgt 5 s93 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s93 5 _ le
  decide +kernel
theorem b94 : Blocked tgt 5 s94 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s94 5 _ le
  decide +kernel
theorem b95 : Blocked tgt 5 s95 := by
  apply PetersenFastNode.node (nxt := #[s82,s96]) (hints := [231,363,231,362,364,395,108,108,364,0,364,628,364,779,844,364,363,396,394,363,99,107,355,99,694,363,363,726,363,214,811,363,236,236,460,724,724,460,460,724,811,212,811,460,852,852,547,555,547,803,1,811,678,811]) (by decide +kernel)
  change ∀ b ∈ [s82,s96], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s82) b82 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.nil
theorem b97 : Blocked tgt 5 s97 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s97 5 _ le
  decide +kernel
theorem b98 : Blocked tgt 5 s98 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s98 5 _ le
  decide +kernel
theorem b99 : Blocked tgt 5 s99 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [362,626,724,361,724,360,722,393,850,106,850,98,362,809,874,362,361,724,361,692,458,722,458,722,692,850,388,850,809,842,361,722,720,361,97,105,353,97,361,724,809,361,722,788,850,722,809,722,809,458,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b101 : Blocked tgt 5 s101 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s101 5 _ le
  decide +kernel
theorem b102 : Blocked tgt 5 s102 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s102 5 _ le
  decide +kernel
theorem b103 : Blocked tgt 5 s103 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [197,197,362,229,560,362,362,692,362,393,458,362,626,106,850,626,362,114,842,362,229,361,101,101,229,458,229,850,421,229,229,842,677,229,392,458,425,425,916,421,916,421,809,677,809,677,722,421,850,421,809,677,809,677,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b104 : Blocked tgt 5 s104 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s104 5 _ le
  decide +kernel
theorem b105 : Blocked tgt 5 s105 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s105 5 _ le
  decide +kernel
theorem b106 : Blocked tgt 5 s106 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s106 5 _ le
  decide +kernel
theorem b107 : Blocked tgt 5 s107 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s107 5 _ le
  decide +kernel
theorem b108 : Blocked tgt 5 s108 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [724,229,724,229,362,393,458,362,626,362,362,626,626,362,362,626,362,114,842,362,361,229,425,361,229,361,421,229,97,229,229,97,229,212,677,229,722,421,425,421,722,425,425,722,425,677,809,425,421,850,421,809,677,421,545,677,545,677]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b109 : Blocked tgt 5 s109 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s109 5 _ le
  decide +kernel
end PetersenSmallStarts.M31
