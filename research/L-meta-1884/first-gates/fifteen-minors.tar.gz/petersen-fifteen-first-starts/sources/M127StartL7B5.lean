import M127StartData
import M127StartPins0
import M127StartL6B8
import M127StartL6B6
import M127StartL6B7
import M127StartL6B0
import M127StartL6B9
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b238 : Blocked tgt 7 s238 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s238 7 _ le
  decide +kernel
theorem b239 : Blocked tgt 7 s239 := by
  apply PetersenFastNode.node (nxt := #[s240,s241,s242,s243,s244,s245,s170,s169,s201,s246,s247,s248,s249,s250]) (hints := [6914,6914,15234,8979,5560,9107,15234,5560,15234,6914,6914,9107,5560,5560,5944,1687,6914,1687,5944,6914,5944,5560,5560,1687,6592,6592,7488,4536,5560,1683,7488,5560,7488,6592,6592,1683,5560,5560,7480,4544,6592,2707,7480,6592,7480,5560,5560,2707,1432,1432,0,1464,5560,4755,5528,5560,1,1432,1432,4755,5560,5560,13624,6914,6914,2,13624,6914,13624,5560,5560,3,1687,9623,1687,8595,9107,5944,1687,9107,1687,9623,9623,5944,1683,9107,1683,8599,9623,7488,1683,9623,1683,9107,9107,7488,2707,9107,2707,13186,15234,7480,2707,15234,2707,9107,9107,7480,4755,9107,4755,11138,15234,4,4755,15234,4755,9107,9107,5,915,6978,6,915,9107,13624,9107,9107,7,6978,6978,13624,6976,6976,7488,1683,1687,1683,1679,1687,7488,1679,6976,1683,1687,1687,3223,2195,6976,2707,3223,6976,3223,1687,1687,2707,1687,1687,5271,4243,5944,4755,5271,5944,5271,1687,1687,4755,5944,5944,13624,1687,1687,8,1687,1687,13624,5944,5944,9,1683,1683,2707,2199,7488,3223,2707,7488,2707,1683,1683,3223,1683,1683,4755,4247,7488,5271,4755,7488,4755,1683,1683,5271,7488,7488,14656,1683,1683,13624,1683,1683,14656,7488,7488,13624,2707,2707,4755,3384,7480,10,4755,7480,4755,2707,2707,11,7480,7480,13624,2707,2707,14656,2707,2707,13624,7480,7480,14656,9496,12,9496,4755,4755,13624,4755,4755,9496,13592,13,13624]) (by decide +kernel)
  change ∀ b ∈ [s240,s241,s242,s243,s244,s245,s170,s169,s201,s246,s247,s248,s249,s250], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s240) b240 <|
    PetersenLocalChildren.push (x := s241) b241 <|
    PetersenLocalChildren.push (x := s242) b242 <|
    PetersenLocalChildren.push (x := s243) b243 <|
    PetersenLocalChildren.push (x := s244) b244 <|
    PetersenLocalChildren.push (x := s245) b245 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s169) b169 <|
    PetersenLocalChildren.push (x := s201) b201 <|
    PetersenLocalChildren.push (x := s246) b246 <|
    PetersenLocalChildren.push (x := s247) b247 <|
    PetersenLocalChildren.push (x := s248) b248 <|
    PetersenLocalChildren.push (x := s249) b249 <|
    PetersenLocalChildren.push (x := s250) b250 <|
    PetersenLocalChildren.nil
theorem b251 : Blocked tgt 7 s251 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s251 7 _ le
  decide +kernel
theorem b252 : Blocked tgt 7 s252 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s252 7 _ le
  decide +kernel
theorem b253 : Blocked tgt 7 s253 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s253 7 _ le
  decide +kernel
theorem b254 : Blocked tgt 7 s254 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s254 7 _ le
  decide +kernel
theorem b255 : Blocked tgt 7 s255 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s255 7 _ le
  decide +kernel
theorem b256 : Blocked tgt 7 s256 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s256 7 _ le
  decide +kernel
theorem b257 : Blocked tgt 7 s257 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s257 7 _ le
  decide +kernel
theorem b258 : Blocked tgt 7 s258 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s258 7 _ le
  decide +kernel
theorem b259 : Blocked tgt 7 s259 := by
  apply PetersenFastNode.node (nxt := #[s260]) (hints := [15093,9030,9802,9802,15093,9930,5547,13545,7475,9798,7475,15093,7467,13045,7467,13029,10965,10997,15061,10965,13611,6901,13611,6837,9930,14837,9930,13673,13673,15221,15221,13673,9926,7219,9926,15221,10950,13173,10950,13157,12998,11125,12998,11093,6965,7029,15157,6965,9930,5931,7475,9926,9922,9922,9930,10438,11466,9930,9930,12486,13514,9930,1674,1738,9866,1674,6579,9926,7475,9926,5547,10950,7467,10950,1419,12998,5515,12998,5547,0,13611,5547,9926,10442,10950,9926,9926,12490,12998,9926,1670,1734,9862,1670,10950,3371,12998,10950,2694,2758,10886,2694,4742,4806,12934,4742]) (by decide +kernel)
  change ∀ b ∈ [s260], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s260) b260 <|
    PetersenLocalChildren.nil
theorem b261 : Blocked tgt 7 s261 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s261 7 _ le
  decide +kernel
theorem b262 : Blocked tgt 7 s262 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s262 7 _ le
  decide +kernel
theorem b263 : Blocked tgt 7 s263 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s263 7 _ le
  decide +kernel
theorem b264 : Blocked tgt 7 s264 := by
  apply PetersenFastNode.node (nxt := #[s193,s26,s265,s266,s267,s268,s269,s270,s271,s272,s260,s273,s274,s275,s276,s277]) (hints := [6916,6916,7172,917,0,1,5946,5368,5946,1689,6916,1689,5946,6916,5946,5368,5368,1689,7490,6916,7490,1685,5368,1685,7490,5368,7490,6916,6916,1685,7482,4852,7482,4868,6916,2709,7482,6916,7482,4852,4852,2709,2788,2788,2,2820,6916,4757,6884,6916,3,2788,2788,4757,5562,6916,5562,6852,4,5,1689,5624,1689,5690,7172,5946,1689,7172,1689,5624,5624,5946,1685,7172,1685,7234,5624,7490,1685,5624,1685,7172,7172,7490,2709,5108,2709,5124,7172,7482,2709,7172,2709,5108,5108,7482,4757,3044,4757,3076,7172,6,4757,7172,4757,3044,3044,7,6980,6980,8,7044,7172,5562,7108,7172,9,6980,6980,5562,6978,6978,7490,1685,1689,1685,1681,1689,7490,1681,6978,1685,1689,1689,3225,2197,6978,2709,3225,6978,3225,1689,1689,2709,1689,1689,5273,4245,5946,4757,5273,5946,5273,1689,1689,4757,5562,5946,5562,1689,1689,10,1689,1689,5562,5946,5946,11,1685,1685,2709,2201,7490,3225,2709,7490,2709,1685,1685,3225,1685,1685,4757,4249,7490,5273,4757,7490,4757,1685,1685,5273,6594,7490,6594,1685,1685,5562,1685,1685,6594,7490,7490,5562,2709,2709,4757,3386,7482,12,4757,7482,4757,2709,2709,13,5562,7482,5562,2709,2709,6594,2709,2709,5562,7482,7482,6594,1434,14,1434,4757,4757,5562,4757,4757,1434,5530,15,5562]) (by decide +kernel)
  change ∀ b ∈ [s193,s26,s265,s266,s267,s268,s269,s270,s271,s272,s260,s273,s274,s275,s276,s277], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s193) b193 <|
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s265) b265 <|
    PetersenLocalChildren.push (x := s266) b266 <|
    PetersenLocalChildren.push (x := s267) b267 <|
    PetersenLocalChildren.push (x := s268) b268 <|
    PetersenLocalChildren.push (x := s269) b269 <|
    PetersenLocalChildren.push (x := s270) b270 <|
    PetersenLocalChildren.push (x := s271) b271 <|
    PetersenLocalChildren.push (x := s272) b272 <|
    PetersenLocalChildren.push (x := s260) b260 <|
    PetersenLocalChildren.push (x := s273) b273 <|
    PetersenLocalChildren.push (x := s274) b274 <|
    PetersenLocalChildren.push (x := s275) b275 <|
    PetersenLocalChildren.push (x := s276) b276 <|
    PetersenLocalChildren.push (x := s277) b277 <|
    PetersenLocalChildren.nil
theorem b278 : Blocked tgt 7 s278 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,true))] s278 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
