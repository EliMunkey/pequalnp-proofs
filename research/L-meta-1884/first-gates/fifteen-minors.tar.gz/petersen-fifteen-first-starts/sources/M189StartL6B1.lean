import M189StartData
import M189StartL5B0
import M189StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b22 : Blocked tgt 6 s22 := by
  apply PetersenFastNode.node (nxt := #[s23,s24]) (hints := [1366,2471,1430,1366,1756,389,1948,1756,1756,1626,1236,1244,1748,1236,716,732,1740,716,1756,2181,3740,1756,2275,2279,2531,2275,2535,2730,2535,581,2919,2535,2535,1093,3431,2535,455,487,2503,455,453,1818,453,2663,709,453,453,3175,1221,453,453,3350,2245,453,0,709,1,709,3626,1221,3626,1221,3610,2245,3610,2245,709,790,1221,709,709,871,2245,709,1221,1383,2245,1221]) (by decide +kernel)
  change ∀ b ∈ [s23,s24], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.nil
theorem b25 : Blocked tgt 6 s25 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,1754,1364,1754,2533,2273,2533,2273,451,451,2917,707,2917,707,3429,1219,3429,1219,3348,2243,3348,2243,1626,1626,1754,2273,1754,1364,1816,1754,1234,1242,1746,1234,714,730,1738,714,1754,2179,3738,1754,2273,2533,2533,2273,2273,579,2657,2273,2273,1091,3169,2273,453,2243,2241,2241,707,2917,707,2917,1219,3429,1219,3429,2243,808,2243,1816,707,788,1219,707,707,609,2243,707,1219,1121,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b26 : Blocked tgt 6 s26 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s26 6 _ le
  decide +kernel
theorem b27 : Blocked tgt 6 s27 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s27 6 _ le
  decide +kernel
theorem b28 : Blocked tgt 6 s28 := by
  apply PetersenFastNode.node (nxt := #[s29,s30]) (hints := [2471,2471,1754,2535,1756,389,1948,1756,1236,1244,1748,1236,1756,1366,716,732,1740,716,1756,2181,3740,1756,2275,2279,2531,2275,2535,581,2919,2535,2535,1430,2535,1093,3431,2535,455,487,2503,455,453,2663,709,453,0,453,453,1,453,3175,1221,453,453,810,2245,453,709,1814,709,3626,1221,709,709,871,2245,709,3366,1221,3366,1221,3350,2245,3350,2245,1221,1383,2245,1221]) (by decide +kernel)
  change ∀ b ∈ [s29,s30], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.nil
theorem b31 : Blocked tgt 6 s31 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1754,1234,1754,1234,2728,2533,1428,2533,1946,451,1946,451,707,707,3364,1219,3364,1219,3738,2243,3738,2243,2469,2469,1234,2533,1234,387,1426,1234,1234,1754,1754,1234,714,1219,1218,1218,1234,2179,3218,1234,2273,2277,2529,2273,2533,2728,1812,2533,2533,1091,3429,2533,453,485,2501,453,451,1946,1946,451,451,3173,1219,451,451,808,2243,451,1219,788,1219,2852,2243,3738,2243,3738,1219,1381,2243,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b32 : Blocked tgt 6 s32 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s32 6 _ le
  decide +kernel
theorem b33 : Blocked tgt 6 s33 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s33 6 _ le
  decide +kernel
theorem b34 : Blocked tgt 6 s34 := by
  apply PetersenFastNode.node (nxt := #[s35,s36]) (hints := [1366,2471,1430,1366,1756,389,1948,1756,1236,1244,1748,1236,716,732,1740,716,1756,2666,1756,2181,3740,1756,2275,2279,2531,2275,2535,581,2919,2535,2535,1093,3431,2535,2535,2470,455,487,2503,455,453,2663,709,453,453,3175,1221,453,2858,453,453,2858,453,810,2245,453,709,1814,1221,709,2854,709,709,2854,709,871,2245,709,1221,3366,1221,1383,2245,1221,0,2245,1,2245]) (by decide +kernel)
  change ∀ b ∈ [s35,s36], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.nil
theorem b37 : Blocked tgt 6 s37 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1754,714,1754,714,1428,2533,1428,2533,1946,451,1946,451,1812,707,1812,707,1219,1219,3738,2243,3738,2243,2469,2469,714,2533,714,387,906,714,1234,707,706,706,714,1754,1754,714,714,2179,2698,714,2273,2277,2529,2273,2533,579,2917,2533,2533,1428,3364,2533,453,485,2501,453,451,2661,707,451,451,1946,1946,451,451,808,2243,451,707,788,3364,707,707,869,2243,707,2243,3738,2243,3738]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b38 : Blocked tgt 6 s38 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s38 6 _ le
  decide +kernel
theorem b39 : Blocked tgt 6 s39 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s39 6 _ le
  decide +kernel
theorem b40 : Blocked tgt 6 s40 := by
  apply PetersenFastNode.node (nxt := #[s41,s42]) (hints := [2470,2471,2470,2534,1756,389,1948,1756,1236,1244,1748,1236,716,732,1740,716,1756,2181,3740,1756,1756,1366,2275,2279,2531,2275,2535,581,2919,2535,2535,1093,3431,2535,455,487,2503,455,2535,1430,453,2663,709,453,453,3175,1221,453,453,2858,2245,453,1818,453,453,1818,709,790,1221,709,709,871,2245,709,1814,709,709,1814,1221,1383,2245,1221,0,1221,1221,1,2245,3350]) (by decide +kernel)
  change ∀ b ∈ [s41,s42], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s41) b41 <|
    PetersenLocalChildren.push (x := s42) b42 <|
    PetersenLocalChildren.nil
theorem b43 : Blocked tgt 6 s43 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2664,1754,1364,1754,2533,453,2533,453,1816,451,1816,451,2917,707,2917,707,3429,1219,3429,1219,2243,2243,389,389,1754,453,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2664,3348,1754,2273,451,449,449,453,579,837,453,453,1091,1349,453,453,2533,2533,453,451,581,707,451,451,1093,1219,451,451,808,3608,451,707,788,1219,707,707,2917,2917,707,1219,3429,3429,1219]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b44 : Blocked tgt 6 s44 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s44 6 _ le
  decide +kernel
theorem b46 : Blocked tgt 6 s46 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s46 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
