import M111StartData
import M111StartL4B0
import M111StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b63 : Blocked tgt 5 s63 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3738,1754,1364,1754,453,453,841,1946,841,1946,837,3730,837,3218,1349,3722,1349,2698,1364,1754,1754,1364,1754,777,1946,1754,1234,1242,1746,1234,714,730,1738,714,841,1946,841,1946,837,3224,837,3476,1349,2452,1349,2436,1426,1434,1938,1426,906,922,1930,906,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b64 : Blocked tgt 5 s64 := by
  apply PetersenFastNode.node (nxt := #[s65]) (hints := [1365,390,1429,1365,1755,1365,1849,1755,1755,1365,3739,1755,1235,1243,1747,1235,715,731,1739,715,714,454,454,714,714,454,454,714,454,202,838,454,454,405,1350,454,842,842,0,838,1841,838,1610,1350,1610,1350,3219,838,3731,838,1610,1350,1610,1350,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s65], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s65) b65 <|
    PetersenLocalChildren.nil
theorem b66 : Blocked tgt 5 s66 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s66 5 _ le
  decide +kernel
theorem b67 : Blocked tgt 5 s67 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s67 5 _ le
  decide +kernel
theorem b68 : Blocked tgt 5 s68 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s68 5 _ le
  decide +kernel
theorem b69 : Blocked tgt 5 s69 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s69 5 _ le
  decide +kernel
theorem b70 : Blocked tgt 5 s70 := by
  apply PetersenFastNode.node (nxt := #[s71]) (hints := [1235,1397,202,3219,202,3225,842,1849,842,3219,838,3219,838,3861,1350,2195,1350,2179,3257,1235,3257,1365,3897,778,3897,1235,3893,1235,3893,1365,195,211,1219,195,3257,1427,3513,3257,3509,3509,2217,2233,3241,2217,0,3893,3889,3889,2857,2873,3881,2857,2853,2869,3877,2853]) (by decide +kernel)
  change ∀ b ∈ [s71], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b72 : Blocked tgt 5 s72 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s72 5 _ le
  decide +kernel
theorem b73 : Blocked tgt 5 s73 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s73 5 _ le
  decide +kernel
theorem b74 : Blocked tgt 5 s74 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s74 5 _ le
  decide +kernel
theorem b75 : Blocked tgt 5 s75 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s75 5 _ le
  decide +kernel
theorem b76 : Blocked tgt 5 s76 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [837,3860,3218,837,3892,1364,1234,3892,3892,3508,3248,3508,3888,1426,2852,3876,2868,2852,1364,1396,453,1460,453,3476,833,1840,833,3218,1349,2194,1349,2178,3508,389,3508,1364,3888,1364,1364,1234,194,1349,1348,1348,3248,3508,3508,3248,2468,2484,3492,2468,2848,1349,3872,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b81 : Blocked tgt 5 s81 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s81 5 _ le
  decide +kernel
theorem b82 : Blocked tgt 5 s82 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s82 5 _ le
  decide +kernel
theorem b83 : Blocked tgt 5 s83 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s83 5 _ le
  decide +kernel
theorem b84 : Blocked tgt 5 s84 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s84 5 _ le
  decide +kernel
end PetersenSmallStarts.M111
