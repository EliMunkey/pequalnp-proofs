import M47StartData
import M47StartL4B1
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_4_3 : NoAtMost (0xaaaa0000 :: inputs 5) tgt 4 := by
  change NoAtMost [0xaaaa0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s16,s0,s17] [99,99,100,100,101,101,420,420,199,199,232,232,101,101,424,424,363,363,364,364,365,365,428,428,199,199,232,232,365,365,680,0,563,723,100,100,629,725,420,420,695,727,232,232,629,101,424,424,827,923,364,364,893,989,428,428,695,727,232,232,893,365,1,2] (by decide +kernel)
  change ∀ b ∈ [s16,s0,s17], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
#print axioms gate_0_4_3
end PetersenSmallStarts.M47
