import M189StartData
import M189StartPins0
import M189StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b141 : Blocked tgt 6 s141 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s141 6 _ le
  decide +kernel
theorem b142 : Blocked tgt 6 s142 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s142 6 _ le
  decide +kernel
theorem b143 : Blocked tgt 6 s143 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s143 6 _ le
  decide +kernel
theorem b144 : Blocked tgt 6 s144 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s144 6 _ le
  decide +kernel
theorem b145 : Blocked tgt 6 s145 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s145 6 _ le
  decide +kernel
theorem b146 : Blocked tgt 6 s146 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s146 6 _ le
  decide +kernel
theorem b147 : Blocked tgt 6 s147 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s147 6 _ le
  decide +kernel
theorem b148 : Blocked tgt 6 s148 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s148 6 _ le
  decide +kernel
theorem b149 : Blocked tgt 6 s149 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s149 6 _ le
  decide +kernel
theorem b150 : Blocked tgt 6 s150 := by
  apply PetersenFastNode.node (nxt := #[s151,s152,s153,s154]) (hints := [1432,1628,1432,457,1758,457,1432,1758,1432,457,1628,457,1758,1758,1950,391,0,1,1950,2,1950,1758,1758,3,1238,1238,1816,1246,1758,711,1750,1758,1816,1238,1238,711,718,718,3368,734,1758,1223,1742,1758,3368,718,718,1223,1758,1758,3742,2183,2668,2247,3742,2668,3742,1758,1758,2247,2249,2277,1820,457,457,1950,457,457,1820,485,2277,1950,457,457,841,583,2732,711,841,2732,841,457,457,711,457,457,1353,1095,1432,1223,1353,1432,1353,457,457,1223,1432,1432,3352,457,457,2247,457,457,3352,2245,1432,2247,711,1430,711,841,1950,841,711,1950,711,841,1430,841,1223,910,1223,1353,1950,1353,1223,1950,1223,1353,910,1353,2247,1950,2247,812,2860,3352,455,2860,2247,455,1950,3352,711,711,1223,792,1816,3628,1223,1816,1223,711,711,3628,711,711,2247,841,841,3742,2247,841,2247,711,711,3742,1223,1223,2247,1353,1353,3742,2247,1353,2247,1223,1223,3742]) (by decide +kernel)
  change ∀ b ∈ [s151,s152,s153,s154], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s151) b151 <|
    PetersenLocalChildren.push (x := s152) b152 <|
    PetersenLocalChildren.push (x := s153) b153 <|
    PetersenLocalChildren.push (x := s154) b154 <|
    PetersenLocalChildren.nil
theorem b155 : Blocked tgt 6 s155 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1428,2469,1428,2532,1754,387,1946,1754,1234,1242,1746,1234,714,730,1738,714,1754,2664,2664,1754,1754,2664,1364,1754,2273,2277,2529,2273,2533,579,2917,2533,2533,1091,3429,2533,453,485,2501,453,1428,2533,2533,1428,707,2661,707,2913,1219,3173,1219,3425,1946,2856,2856,1946,1946,2856,451,451,707,788,1219,707,707,869,2885,707,707,2917,2917,707,1219,1381,3397,1219,1219,3429,3429,1219,2243,2243]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b156 : Blocked tgt 6 s156 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s156 6 _ le
  decide +kernel
theorem b157 : Blocked tgt 6 s157 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s157 6 _ le
  decide +kernel
theorem b158 : Blocked tgt 6 s158 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1754,3738,1754,2179,2243,2664,1754,2243,1754,3738,3738,2664,453,3348,453,2243,2243,2273,453,2243,453,2241,3348,2273,451,2243,451,808,3348,2856,451,3348,451,2243,2243,2856,707,2243,707,609,3738,2657,707,3738,707,2243,2243,2657,1219,2243,1219,1121,3738,3169,1219,3738,1219,2243,2243,3169,2468,2664,2468,2209,1754,2273,2468,1754,2468,2664,2664,2273,2664,2664,2856,387,1364,451,2856,1364,2856,2664,2664,451,2852,1234,2852,2657,2664,2657,2852,2664,2852,2656,1234,2657,3364,2664,3364,3105,1754,3169,3364,1754,3364,2664,2664,3169,2273,2273,2856,2212,2468,451,2856,2468,2856,2273,2273,451,2273,2273,2657,2216,2728,707,2657,2728,2657,2273,2273,707,2273,2273,3169,1091,1428,1219,3169,1428,3169,2273,2273,1219,2657,451,2657,2852,2856,2852,2657,2856,2657,2848,451,2852,3169,2856,3169,3108,1946,3364,3169,1946,3169,2856,2856,3364,2657,2657,3169,3112,1812,3624,3169,1812,3169,2657,2657,3624]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b159 : Blocked tgt 6 s159 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s159 6 _ le
  decide +kernel
theorem b160 : Blocked tgt 6 s160 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s160 6 _ le
  decide +kernel
end PetersenSmallStarts.M189
