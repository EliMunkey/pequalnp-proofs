import M189StartData
import M189StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_0 : NoAtMost (0xffaaffaaffaaffaa :: inputs 6) tgt 7 := by
  change NoAtMost [0xffaaffaaffaaffaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s163] [386,451,451,451,388,453,453,453,390,455,455,455,708,709,709,709,586,586,451,451,716,716,453,453,390,455,455,455,716,716,1221,1221,1106,1114,451,451,1236,1244,453,453,1366,455,455,455,1236,1244,709,709,1626,1626,451,451,1756,1756,453,453,1366,455,455,455,1756,1756,2245,2245,2210,2275,2275,2275,388,453,453,453,2470,2535,2535,2535,708,709,709,709,2666,2666,2275,2275,716,716,453,453,2470,2535,2535,2535,716,716,1221,1221,1106,1114,2275,2275,1236,1244,453,453,1366,2535,2535,2535,1236,1244,709,709,1626,1626,2275,2275,1756,1756,453,453,1366,2535,2535,2535,1756,1756,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s163], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s163) b163 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_0
end PetersenSmallStarts.M189
