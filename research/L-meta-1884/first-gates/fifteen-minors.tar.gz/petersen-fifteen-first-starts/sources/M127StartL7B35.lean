import M127StartData
import M127StartPins0
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1222 : Blocked tgt 7 s1222 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1222 7 _ le
  decide +kernel
theorem b1223 : Blocked tgt 7 s1223 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1223 7 _ le
  decide +kernel
theorem b1224 : Blocked tgt 7 s1224 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1224 7 _ le
  decide +kernel
theorem b1225 : Blocked tgt 7 s1225 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1225 7 _ le
  decide +kernel
theorem b1226 : Blocked tgt 7 s1226 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s1226 7 _ le
  decide +kernel
theorem b1227 : Blocked tgt 7 s1227 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s1227 7 _ le
  decide +kernel
theorem b1228 : Blocked tgt 7 s1228 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1228 7 _ le
  decide +kernel
theorem b1229 : Blocked tgt 7 s1229 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [11124,1418,11124,11252,1418,9801,1802,1418,2450,1418,1418,2450,2450,1418,1418,2450,1418,402,3338,1418,10964,1418,1418,10964,1418,6900,9482,1418,9929,1802,9929,9576,9925,9576,9925,11124,10608,11124,11124,10608,10949,9076,10949,9060,9157,9157,2868,2932,11060,2868,778,9929,9925,9929,2834,9929,10949,11465,9929,9929,12997,13513,9929,1673,1737,9865,1673,9925,3346,9925,11465,10949,9925,9925,13513,12997,9925,1669,1733,9861,1669,10433,10949,10433,10949,12481,12997,12481,12997,10514,9482,10514,9482,10949,3338,12997,10949,2693,2757,10885,2693,4741,4805,12933,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1230 : Blocked tgt 7 s1230 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1230 7 _ le
  decide +kernel
theorem b1231 : Blocked tgt 7 s1231 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(2,false),(3,false))] s1231 7 _ le
  decide +kernel
theorem b1232 : Blocked tgt 7 s1232 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,6836,5546,901,901,1673,5930,1673,5930,1669,13610,1669,14642,14642,13610,13610,14642,2693,7466,2693,7466,4741,13578,4741,9482,6836,5546,5546,6836,5546,1545,5930,5546,6578,5546,5546,6578,6578,5546,5546,6578,5546,4530,7466,5546,1418,1450,5514,1418,1673,5930,1673,5930,1669,9609,1669,9093,8577,9093,9093,8577,2693,7466,2693,7466,4741,11060,4741,9093,4906,5930,1669,5930,6962,5930,2693,7466,5930,1802,1834,5898,1802,7474,7474,1669,7466,2693,7466,1669,5257,4741,1669,2177,7466,2177,7466,4225,4741,4225,4741,3338,3370,7434,3338]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1233 : Blocked tgt 7 s1233 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1233 7 _ le
  decide +kernel
theorem b1234 : Blocked tgt 7 s1234 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1234 7 _ le
  decide +kernel
theorem b1235 : Blocked tgt 7 s1235 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1235 7 _ le
  decide +kernel
theorem b1236 : Blocked tgt 7 s1236 := by
  intro k le c
  apply rejects_sound r18 i4 3 tgt small18 hot18 [] s1236 7 _ le
  decide +kernel
theorem b1237 : Blocked tgt 7 s1237 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s1237 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
