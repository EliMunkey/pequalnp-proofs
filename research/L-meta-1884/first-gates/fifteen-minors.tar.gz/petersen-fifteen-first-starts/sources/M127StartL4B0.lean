import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b233 : Blocked tgt 4 s233 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2708,2708,1417,1673,389,1417,773,1669,393,773,773,2693,3080,773,1416,1673,1544,1673,2836,1669,3604,1669,772,2693,2820,2693,3088,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b554 : Blocked tgt 4 s554 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [(true,(1,false),(4,false)),(false,(1,false),(0,false))] s554 4 _ le
  decide +kernel
theorem b931 : Blocked tgt 4 s931 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [386,386,2693,901,772,901,2693,1669,3330,1669,2177,2689,2181,2177,772,901,772,901,2434,1669,3330,1669,770,2180,770,2434,901,3074,1669,901,385,389,897,385,770,1669,1665,1665]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1298 : Blocked tgt 4 s1298 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1802,1418,1545,1418,1665,3346,1673,3209,2177,1673,1673,1417,385,1417,2450,1418,1418,2450,1418,3081,3338,1418,2192,1417,1416,1416,1665,3209,2177,3209,385,1417,385,1417,1417,3082,1417,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
