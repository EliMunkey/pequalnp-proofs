import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b362 : Blocked tgt 6 s362 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s362 6 _ le
  decide +kernel
theorem b363 : Blocked tgt 6 s363 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s363 6 _ le
  decide +kernel
theorem b364 : Blocked tgt 6 s364 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s364 6 _ le
  decide +kernel
theorem b365 : Blocked tgt 6 s365 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s365 6 _ le
  decide +kernel
theorem b366 : Blocked tgt 6 s366 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s366 6 _ le
  decide +kernel
theorem b367 : Blocked tgt 6 s367 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s367 6 _ le
  decide +kernel
theorem b376 : Blocked tgt 6 s376 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s376 6 _ le
  decide +kernel
theorem b377 : Blocked tgt 6 s377 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s377 6 _ le
  decide +kernel
theorem b378 : Blocked tgt 6 s378 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s378 6 _ le
  decide +kernel
theorem b379 : Blocked tgt 6 s379 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s379 6 _ le
  decide +kernel
theorem b380 : Blocked tgt 6 s380 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s380 6 _ le
  decide +kernel
theorem b381 : Blocked tgt 6 s381 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s381 6 _ le
  decide +kernel
theorem b382 : Blocked tgt 6 s382 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s382 6 _ le
  decide +kernel
theorem b383 : Blocked tgt 6 s383 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s383 6 _ le
  decide +kernel
theorem b384 : Blocked tgt 6 s384 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s384 6 _ le
  decide +kernel
theorem b385 : Blocked tgt 6 s385 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s385 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
