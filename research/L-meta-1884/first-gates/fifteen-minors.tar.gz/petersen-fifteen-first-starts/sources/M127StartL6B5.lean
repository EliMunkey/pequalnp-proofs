import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b137 : Blocked tgt 6 s137 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s137 6 _ le
  decide +kernel
theorem b138 : Blocked tgt 6 s138 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s138 6 _ le
  decide +kernel
theorem b139 : Blocked tgt 6 s139 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s139 6 _ le
  decide +kernel
theorem b141 : Blocked tgt 6 s141 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s141 6 _ le
  decide +kernel
theorem b142 : Blocked tgt 6 s142 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s142 6 _ le
  decide +kernel
theorem b149 : Blocked tgt 6 s149 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s149 6 _ le
  decide +kernel
theorem b150 : Blocked tgt 6 s150 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s150 6 _ le
  decide +kernel
theorem b151 : Blocked tgt 6 s151 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s151 6 _ le
  decide +kernel
theorem b152 : Blocked tgt 6 s152 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s152 6 _ le
  decide +kernel
theorem b153 : Blocked tgt 6 s153 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s153 6 _ le
  decide +kernel
theorem b154 : Blocked tgt 6 s154 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s154 6 _ le
  decide +kernel
theorem b155 : Blocked tgt 6 s155 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5514,1418,1450,1418,4741,901,2836,901,5833,1737,4741,1737,4741,1669,12489,1669,4741,2693,3370,2693,5257,4741,4741,5257,773,773,1418,901,1418,1737,1608,1418,2450,394,3346,2450,1418,402,3338,1418,1418,6804,9482,1418,1737,901,1737,1993,901,8649,1669,901,901,3338,2693,901,1417,901,901,1417,3346,1669,1729,1669,1737,2693,3785,1737,1673,1673,1669,10441,2693,1669,3346,1669,1669,3346,3209,2693,2693,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b156 : Blocked tgt 6 s156 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s156 6 _ le
  decide +kernel
theorem b159 : Blocked tgt 6 s159 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s159 6 _ le
  decide +kernel
theorem b160 : Blocked tgt 6 s160 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s160 6 _ le
  decide +kernel
theorem b161 : Blocked tgt 6 s161 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4805,4741,12933,4741,9482,1418,6804,1418,9093,901,965,901,9865,1673,1737,1673,9861,1669,1733,1669,10885,2693,2757,2693,5514,1418,1450,1418,4741,901,11028,901,5257,1673,4229,1673,4741,1669,4233,1669,4741,2693,3370,2693,773,773,1418,901,1418,1673,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1417,389,1673,1417,901,393,1669,901,901,3338,2693,901,2834,1669,1665,1665,1673,2181,3209,1673,1669,2185,2693,1669]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M127
