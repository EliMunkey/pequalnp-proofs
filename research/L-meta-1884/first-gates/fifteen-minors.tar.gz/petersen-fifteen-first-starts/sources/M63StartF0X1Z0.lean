import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_0 : NoAtMost (0xeeeeeeeeeeeeeeee :: inputs 6) tgt 7 := by
  change NoAtMost [0xeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s1] [194,195,195,195,196,196,835,835,390,391,455,455,196,196,839,839,714,715,715,715,716,716,843,843,390,391,455,455,716,716,1351,1351,1106,1108,195,195,1236,1236,835,835,1366,391,455,455,1236,1236,839,839,714,715,715,715,716,716,843,843,1366,391,455,455,716,716,2375,2375,2146,2148,195,195,2276,2276,835,835,2406,391,455,455,2276,2276,839,839,2666,2668,715,715,2796,2796,843,843,2406,391,455,455,2796,2796,1351,1351,3186,3188,195,195,3316,3316,835,835,3446,391,455,455,3316,3316,839,839,2666,2668,715,715,2796,2796,843,843,3446,391,455,455,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_0
end PetersenSmallStarts.M63
