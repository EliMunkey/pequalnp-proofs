import M47StartData
import M47StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M47
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_3 : NoAtMost (0xa0a0a0a0 :: inputs 5) tgt 4 := by
  change NoAtMost [0xa0a0a0a0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 32); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 32); change false=true at x; contradiction)
    #[s0,s7] [98,231,99,231,100,423,419,423,198,231,231,231,100,423,423,423,362,231,363,231,364,679,427,679,198,231,231,231,364,679,679,679,562,231,99,231,628,423,419,423,694,231,231,231,628,423,423,423,826,231,363,231,892,892,427,988,694,231,231,231,892,892,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s7], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s7) b7 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_3
end PetersenSmallStarts.M47
