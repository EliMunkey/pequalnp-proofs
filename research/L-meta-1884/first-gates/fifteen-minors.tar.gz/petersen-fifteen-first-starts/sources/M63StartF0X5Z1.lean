import M63StartData
import M63StartL7B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_5_1 : NoAtMost (0xaaaaaaaa :: inputs 6) tgt 7 := by
  change NoAtMost [0xaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s475,s0,s638] [195,196,196,196,197,836,836,836,391,456,456,456,197,840,840,840,715,716,716,716,717,844,844,844,391,456,456,456,717,1352,1352,1352,1107,196,196,196,1237,836,836,836,1367,456,456,456,1237,840,840,840,715,716,716,716,717,844,844,844,1367,456,456,456,717,2765,2376,0,2147,196,196,196,2277,836,836,836,2407,456,456,456,2277,840,840,840,2667,716,716,716,2797,844,844,844,2407,456,456,456,2797,1352,1352,1352,3187,196,196,196,3317,836,836,836,3447,456,456,456,3317,840,840,840,2667,716,716,716,2797,844,844,844,3447,456,456,456,2797,2797,1,2] (by decide +kernel)
  change ∀ b ∈ [s475,s0,s638], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s475) b475 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s638) b638 <|
    PetersenLocalChildren.nil
#print axioms gate_0_5_1
end PetersenSmallStarts.M63
