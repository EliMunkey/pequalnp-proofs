import M15StartData
import M15StartL3B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M15
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_2 : NoAtMost (0x4444 :: inputs 4) tgt 3 := by
  change NoAtMost [0x4444,0xaaaa,0xcccc,0xf0f0,0xff00] tgt 3
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 16); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 16); change false=true at x; contradiction)
    #[s3,s0,s4] [51,101,52,101,53,101,212,101,103,119,120,120,53,199,216,216,187,237,188,237,189,237,220,237,103,119,120,120,189,0,1,2] (by decide +kernel)
  change ∀ b ∈ [s3,s0,s4], Blocked tgt 3 b
  exact
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s4) b4 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_2
end PetersenSmallStarts.M15
