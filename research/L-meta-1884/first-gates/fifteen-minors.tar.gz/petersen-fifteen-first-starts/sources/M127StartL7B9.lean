import M127StartData
import M127StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b409 : Blocked tgt 7 s409 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s409 7 _ le
  decide +kernel
theorem b410 : Blocked tgt 7 s410 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s410 7 _ le
  decide +kernel
theorem b411 : Blocked tgt 7 s411 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s411 7 _ le
  decide +kernel
theorem b412 : Blocked tgt 7 s412 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s412 7 _ le
  decide +kernel
theorem b413 : Blocked tgt 7 s413 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s413 7 _ le
  decide +kernel
theorem b414 : Blocked tgt 7 s414 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s414 7 _ le
  decide +kernel
theorem b415 : Blocked tgt 7 s415 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s415 7 _ le
  decide +kernel
theorem b416 : Blocked tgt 7 s416 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s416 7 _ le
  decide +kernel
theorem b417 : Blocked tgt 7 s417 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s417 7 _ le
  decide +kernel
theorem b418 : Blocked tgt 7 s418 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s418 7 _ le
  decide +kernel
theorem b419 : Blocked tgt 7 s419 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s419 7 _ le
  decide +kernel
theorem b420 : Blocked tgt 7 s420 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s420 7 _ le
  decide +kernel
theorem b421 : Blocked tgt 7 s421 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s421 7 _ le
  decide +kernel
theorem b422 : Blocked tgt 7 s422 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s422 7 _ le
  decide +kernel
theorem b423 : Blocked tgt 7 s423 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s423 7 _ le
  decide +kernel
theorem b424 : Blocked tgt 7 s424 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false))] s424 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
