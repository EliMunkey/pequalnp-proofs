import M111StartData
import M111StartL6B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_2 : NoAtMost (0x4444444444444444 :: inputs 6) tgt 6 := by
  change NoAtMost [0x4444444444444444,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s12] [194,388,195,388,196,388,835,388,390,2180,455,2180,196,2180,839,2180,714,908,715,908,716,908,843,908,390,2700,455,2700,716,2700,1351,2700,1106,1428,195,1428,1236,1428,835,1428,1366,3220,455,3220,1236,3220,839,3220,1626,1948,715,1948,1756,1948,843,1948,1366,3740,455,3740,1756,3740,3740,3740,2210,388,2275,388,196,388,2915,388,2470,2534,2535,2535,196,2854,2919,2919,2730,908,2795,908,716,908,2923,908,2470,2534,2535,2535,716,3430,3431,3431,3186,1428,2275,1428,1236,1428,2915,1428,3446,3446,2535,2535,1236,3446,2919,2919,3706,1948,2795,1948,1756,1948,2923,1948,3446,3446,2535,2535,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s12], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_2
end PetersenSmallStarts.M111
