import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b407 : Blocked tgt 5 s407 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s407 5 _ le
  decide +kernel
theorem b408 : Blocked tgt 5 s408 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s408 5 _ le
  decide +kernel
theorem b409 : Blocked tgt 5 s409 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s409 5 _ le
  decide +kernel
theorem b410 : Blocked tgt 5 s410 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(false,(0,true),(5,false))] s410 5 _ le
  decide +kernel
theorem b411 : Blocked tgt 5 s411 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s411 5 _ le
  decide +kernel
theorem b412 : Blocked tgt 5 s412 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false)),(false,(0,true),(5,false))] s412 5 _ le
  decide +kernel
theorem b417 : Blocked tgt 5 s417 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s417 5 _ le
  decide +kernel
theorem b418 : Blocked tgt 5 s418 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s418 5 _ le
  decide +kernel
theorem b419 : Blocked tgt 5 s419 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s419 5 _ le
  decide +kernel
theorem b428 : Blocked tgt 5 s428 := by
  apply PetersenFastNode.node (nxt := #[s429]) (hints := [2763,1365,715,715,2374,454,0,454,2634,842,2118,842,2374,838,2122,838,2374,1350,1675,1350,1365,390,1429,1365,778,778,1365,842,1365,774,1813,1365,1675,1350,1349,1349,714,198,842,714,454,202,838,454,454,405,1350,454,1683,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s429], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s429) b429 <|
    PetersenLocalChildren.nil
theorem b437 : Blocked tgt 5 s437 := by
  apply PetersenFastNode.node (nxt := #[s438]) (hints := [3315,3189,194,3507,194,3505,834,3637,834,3507,1090,2483,1090,2467,2114,1459,2114,1427,3509,3187,3509,3185,3893,834,3893,3315,2275,2291,3299,2275,1235,1267,3283,1235,3509,3635,3893,3509,2469,2485,3493,2469,1429,1461,3477,1429,2853,2869,3877,2853,1813,1845,3861,1813,1090,0,2114,1090]) (by decide +kernel)
  change ∀ b ∈ [s438], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s438) b438 <|
    PetersenLocalChildren.nil
theorem b439 : Blocked tgt 5 s439 := by
  apply PetersenFastNode.node (nxt := #[s440,s438]) (hints := [2796,1110,715,1428,715,1426,839,1558,839,1428,843,1964,2635,404,2635,0,1430,2668,1430,2666,1814,2284,1814,1236,1708,1236,1708,1772,716,748,2764,716,1430,203,1814,1430,715,1430,1430,715,390,406,1414,390,1,1814,1814,835,774,790,1798,774,843,1095,1611,843]) (by decide +kernel)
  change ∀ b ∈ [s440,s438], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s440) b440 <|
    PetersenLocalChildren.push (x := s438) b438 <|
    PetersenLocalChildren.nil
theorem b445 : Blocked tgt 5 s445 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s445 5 _ le
  decide +kernel
theorem b446 : Blocked tgt 5 s446 := by
  intro k le c
  apply rejects_sound r12 i4 3 tgt small12 hot12 [] s446 5 _ le
  decide +kernel
theorem b459 : Blocked tgt 5 s459 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s459 5 _ le
  decide +kernel
theorem b482 : Blocked tgt 5 s482 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s482 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
