import M127StartData
import M127StartPins0
import M127StartL6B6
import M127StartL6B2
import M127StartL6B4
import M127StartL6B0
import M127StartL6B1
import M127StartL6B3
import M127StartL6B5
import M127StartL6B7
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b166 : Blocked tgt 7 s166 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s166 7 _ le
  decide +kernel
theorem b167 : Blocked tgt 7 s167 := by
  apply PetersenFastNode.node (nxt := #[s168,s71,s169,s170,s171,s128,s172,s24,s112,s173,s174,s175]) (hints := [13622,13622,15040,5558,0,5558,6848,1,15040,5558,13622,5558,9105,2,9169,913,13622,913,977,13622,9169,913,3,913,9877,13622,9941,1685,4,1685,1749,5,9941,1685,13622,1685,9873,14654,9937,1681,13622,1681,1745,13622,9937,1681,14654,1681,10897,13622,10961,2705,14654,2705,2769,14654,10961,2705,13622,2705,12945,9494,13009,4753,13622,4753,4817,13622,13009,4753,9494,4753,785,15040,15168,785,5558,913,5558,5558,15168,913,15040,913,5558,5558,5942,1685,15040,1685,5942,15040,5942,5558,5558,1685,6590,6590,7486,4534,5558,1681,7486,5558,7486,6590,6590,1681,5558,5558,7478,4542,6590,2705,7478,6590,7478,5558,5558,2705,1430,1430,6,1462,5558,4753,5526,5558,7,1430,1430,4753,1429,1429,1685,401,913,5942,1685,913,1685,1429,1429,5942,913,913,1681,405,1429,7486,1681,1429,1681,913,913,7486,913,913,2705,7478,15168,7478,2705,15168,2705,913,913,7478,913,913,4753,11072,15168,8,4753,15168,4753,913,913,9,6974,6974,7486,1681,1685,1681,1677,1685,7486,1677,6974,1681,1685,1685,3221,2193,6974,2705,3221,6974,3221,1685,1685,2705,1685,1685,5269,4241,5942,4753,5269,5942,5269,1685,1685,4753,1681,1681,2705,2197,7486,3221,2705,7486,2705,1681,1681,3221,1681,1681,4753,4245,7486,5269,4753,7486,4753,1681,1681,5269,2705,2705,4753,3382,7478,10,4753,7478,4753,2705,2705,11]) (by decide +kernel)
  change ∀ b ∈ [s168,s71,s169,s170,s171,s128,s172,s24,s112,s173,s174,s175], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s168) b168 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.push (x := s169) b169 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s171) b171 <|
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.push (x := s172) b172 <|
    PetersenLocalChildren.push (x := s24) b24 <|
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.push (x := s173) b173 <|
    PetersenLocalChildren.push (x := s174) b174 <|
    PetersenLocalChildren.push (x := s175) b175 <|
    PetersenLocalChildren.nil
theorem b176 : Blocked tgt 7 s176 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s176 7 _ le
  decide +kernel
theorem b177 : Blocked tgt 7 s177 := by
  apply PetersenFastNode.node (nxt := #[s47,s178,s94,s179,s161]) (hints := [13615,5551,0,5551,9098,906,970,906,13615,1,9870,1678,1742,1678,9866,1674,1738,1674,10890,2698,2762,2698,12938,4746,4810,4746,778,5551,906,5551,15033,5551,1678,5935,5551,6583,4527,7479,6583,5551,4535,7471,5551,1423,1455,5519,1423,906,15161,1422,394,1678,1422,906,398,1674,906,906,7471,2698,906,906,2,4746,906,5677,1678,5677,1678,7737,1674,7737,1674,7213,2698,7213,2698,3,4746,4,4746,6967,1674,1670,1670,1678,2186,3214,1678,1678,4234,5262,1678,1674,2190,2698,1674,1674,4238,4746,1674,2698,3375,4746,2698]) (by decide +kernel)
  change ∀ b ∈ [s47,s178,s94,s179,s161], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s47) b47 <|
    PetersenLocalChildren.push (x := s178) b178 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.push (x := s179) b179 <|
    PetersenLocalChildren.push (x := s161) b161 <|
    PetersenLocalChildren.nil
theorem b180 : Blocked tgt 7 s180 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s180 7 _ le
  decide +kernel
theorem b181 : Blocked tgt 7 s181 := by
  apply PetersenFastNode.node (nxt := #[s12,s96,s182,s155,s183,s128]) (hints := [779,5552,907,5552,6842,5552,1743,5742,5552,6584,4528,7480,6584,5552,4536,7472,5552,1424,1456,5520,1424,5552,0,13616,5552,907,6970,1743,907,1743,1999,907,8655,1675,907,907,7472,2699,907,907,1,4747,907,1423,907,907,1423,5742,1743,5742,1743,7738,1675,7738,1675,15470,2699,15470,2699,2,4747,3,4747,4,13616,5,13616,7480,1675,1735,1675,1743,2699,3791,1743,1743,4747,5839,1743,1679,1679,1675,10447,2699,1675,1675,12495,4747,1675,7480,1675,1675,7480,2699,3376,4747,2699,3215,2699,2699,3215,5263,4747,4747,5263]) (by decide +kernel)
  change ∀ b ∈ [s12,s96,s182,s155,s183,s128], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s12) b12 <|
    PetersenLocalChildren.push (x := s96) b96 <|
    PetersenLocalChildren.push (x := s182) b182 <|
    PetersenLocalChildren.push (x := s155) b155 <|
    PetersenLocalChildren.push (x := s183) b183 <|
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.nil
theorem b184 : Blocked tgt 7 s184 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s184 7 _ le
  decide +kernel
theorem b185 : Blocked tgt 7 s185 := by
  apply PetersenFastNode.node (nxt := #[s57,s77,s186,s142,s187,s174]) (hints := [9035,5552,9163,5552,10970,5552,9935,5936,5552,2456,4528,3352,2456,3376,2456,3376,3504,1424,1456,5520,1424,5552,0,13616,5552,9163,11098,9679,8651,9935,9679,9163,8655,9931,9163,9163,3376,11374,9163,9163,1,13003,9163,907,971,9099,907,13934,9935,13934,9935,11866,9931,11866,9931,11374,3376,11374,3376,2,13003,3,13003,4,13616,5,13616,2840,9931,9927,9927,9935,2840,3376,9935,9935,12491,13519,9935,1679,1743,9871,1679,9931,3352,3352,9931,9931,12495,13003,9931,1675,1739,9867,1675,10955,10955,3376,10520,11568,3376,4747,4811,12939,4747]) (by decide +kernel)
  change ∀ b ∈ [s57,s77,s186,s142,s187,s174], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s77) b77 <|
    PetersenLocalChildren.push (x := s186) b186 <|
    PetersenLocalChildren.push (x := s142) b142 <|
    PetersenLocalChildren.push (x := s187) b187 <|
    PetersenLocalChildren.push (x := s174) b174 <|
    PetersenLocalChildren.nil
theorem b188 : Blocked tgt 7 s188 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s188 7 _ le
  decide +kernel
theorem b190 : Blocked tgt 7 s190 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s190 7 _ le
  decide +kernel
theorem b191 : Blocked tgt 7 s191 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s191 7 _ le
  decide +kernel
theorem b192 : Blocked tgt 7 s192 := by
  apply PetersenFastNode.node (nxt := #[s193,s194,s159,s195,s178,s196]) (hints := [9035,5552,9163,5552,15098,5552,9935,5936,5552,6584,4528,7480,6584,5552,4536,7472,5552,1424,1456,5520,1424,5552,0,13616,5552,9163,15226,9679,8651,9935,9679,9163,8655,9931,9163,9163,7472,10955,9163,9163,1,13003,9163,907,971,9099,907,13934,9935,13934,9935,15994,9931,15994,9931,15470,10955,15470,10955,2,13003,3,13003,4,13616,5,13616,6968,9931,9927,9927,9935,10443,11471,9935,9935,12491,13519,9935,1679,1743,9871,1679,9931,10447,10955,9931,9931,12495,13003,9931,1675,1739,9867,1675,10955,3376,13003,10955,2699,2763,10891,2699,4747,4811,12939,4747]) (by decide +kernel)
  change ∀ b ∈ [s193,s194,s159,s195,s178,s196], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s193) b193 <|
    PetersenLocalChildren.push (x := s194) b194 <|
    PetersenLocalChildren.push (x := s159) b159 <|
    PetersenLocalChildren.push (x := s195) b195 <|
    PetersenLocalChildren.push (x := s178) b178 <|
    PetersenLocalChildren.push (x := s196) b196 <|
    PetersenLocalChildren.nil
theorem b197 : Blocked tgt 7 s197 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s197 7 _ le
  decide +kernel
theorem b198 : Blocked tgt 7 s198 := by
  apply PetersenFastNode.node (nxt := #[s199,s200,s201,s202]) (hints := [15096,9033,15224,15096,5550,9805,15096,5550,5550,15096,15096,5550,6582,4526,7478,6582,5550,4534,7470,5550,1422,1454,5518,1422,5550,6904,13614,5550,9933,9161,9933,10189,9677,9161,9161,13676,9161,7222,9929,9161,9161,13176,10953,9161,9161,11128,13001,9161,905,969,9097,905,9933,5934,7478,9929,9925,9925,9933,10441,11469,9933,9933,12489,13517,9933,1677,1741,9869,1677,7478,9929,7478,9929,7470,10953,7470,10953,0,13001,1,13001,13614,2,13614,3,9929,10445,10953,9929,9929,12493,13001,9929,1673,1737,9865,1673,10953,3374,13001,10953,2697,2761,10889,2697,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s199,s200,s201,s202], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s199) b199 <|
    PetersenLocalChildren.push (x := s200) b200 <|
    PetersenLocalChildren.push (x := s201) b201 <|
    PetersenLocalChildren.push (x := s202) b202 <|
    PetersenLocalChildren.nil
theorem b203 : Blocked tgt 7 s203 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s203 7 _ le
  decide +kernel
theorem b204 : Blocked tgt 7 s204 := by
  intro k le c
  apply rejects_sound r4 i6 6 tgt small4 hot4 [] s204 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
