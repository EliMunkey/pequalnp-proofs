import M189StartData
import M189StartPins0
import M189StartL5B2
import M189StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M189
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b200 : Blocked tgt 6 s200 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s200 6 _ le
  decide +kernel
theorem b201 : Blocked tgt 6 s201 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s201 6 _ le
  decide +kernel
theorem b202 : Blocked tgt 6 s202 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s202 6 _ le
  decide +kernel
theorem b203 : Blocked tgt 6 s203 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s203 6 _ le
  decide +kernel
theorem b204 : Blocked tgt 6 s204 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s204 6 _ le
  decide +kernel
theorem b205 : Blocked tgt 6 s205 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s205 6 _ le
  decide +kernel
theorem b206 : Blocked tgt 6 s206 := by
  apply PetersenFastNode.node (nxt := #[s207,s208]) (hints := [1430,2471,1430,2534,1756,453,1948,1756,1814,1756,1748,1748,716,732,1740,716,1756,2181,2666,1756,1756,2666,1236,1756,2275,2279,2531,2275,2535,2218,2919,2535,2535,1093,3431,2535,455,487,2503,455,1430,2535,2535,1430,453,2663,2659,453,453,3175,1221,453,453,2858,2245,453,1948,453,453,1948,1221,790,1221,2919,2245,2919,2245,2757,709,709,2919,1814,1221,1383,2245,1221,0,1221,1221,1,2245,3740]) (by decide +kernel)
  change ∀ b ∈ [s207,s208], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s207) b207 <|
    PetersenLocalChildren.push (x := s208) b208 <|
    PetersenLocalChildren.nil
theorem b209 : Blocked tgt 6 s209 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s209 6 _ le
  decide +kernel
theorem b210 : Blocked tgt 6 s210 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s210 6 _ le
  decide +kernel
theorem b211 : Blocked tgt 6 s211 := by
  apply PetersenFastNode.node (nxt := #[s212,s213]) (hints := [1366,2471,1430,1366,389,389,1366,453,1756,1236,709,709,3366,1221,3366,1221,3740,2245,3740,2245,2275,2279,2531,2275,1626,2535,2535,1754,2535,2218,1814,2535,2535,1093,3431,2535,455,487,2503,455,453,1948,453,1622,0,453,453,3175,1221,453,453,3350,2245,453,1,1756,1748,1748,716,1221,1740,1221,1756,2245,3740,2245,1221,790,1221,2854,2245,3228,2245,3732,1221,1383,2245,1221]) (by decide +kernel)
  change ∀ b ∈ [s212,s213], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s212) b212 <|
    PetersenLocalChildren.push (x := s213) b213 <|
    PetersenLocalChildren.nil
theorem b214 : Blocked tgt 6 s214 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s214 6 _ le
  decide +kernel
theorem b215 : Blocked tgt 6 s215 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s215 6 _ le
  decide +kernel
theorem b216 : Blocked tgt 6 s216 := by
  apply PetersenFastNode.node (nxt := #[s217,s218]) (hints := [1236,1236,2218,709,581,581,709,453,1428,453,2919,709,709,0,709,1221,3366,709,709,2245,3220,709,1620,1620,1748,1626,1428,453,1428,453,1814,1748,1748,1878,708,1221,1732,1221,1748,2245,3220,2245,1812,453,1434,453,2535,2535,3431,1221,3431,1221,3350,2245,3350,2245,1,453,453,1810,453,3175,1221,453,453,810,2245,453,3431,1221,3431,1221,1814,2245,3350,2245,1221,1383,2245,1221]) (by decide +kernel)
  change ∀ b ∈ [s217,s218], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s217) b217 <|
    PetersenLocalChildren.push (x := s218) b218 <|
    PetersenLocalChildren.nil
theorem b219 : Blocked tgt 6 s219 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s219 6 _ le
  decide +kernel
theorem b220 : Blocked tgt 6 s220 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s220 6 _ le
  decide +kernel
theorem b221 : Blocked tgt 6 s221 := by
  apply PetersenFastNode.node (nxt := #[s112,s212]) (hints := [709,0,2919,709,1366,1366,1430,2535,1430,2535,709,965,1940,709,3366,3431,3366,3431,3350,2245,3350,709,1748,1878,1748,1814,2275,2535,2275,2535,453,453,1221,3431,1221,3431,2245,3350,2245,1814,1430,2535,1430,2535,1748,1,1940,1748,3366,3431,3366,3431,3350,2245,3350,2245,2275,2535,2535,2275,2535,1093,3431,2535,455,487,2503,455,1221,3431,1221,3431,2245,3350,2245,3350,1351,1383,3399,1351]) (by decide +kernel)
  change ∀ b ∈ [s112,s212], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s112) b112 <|
    PetersenLocalChildren.push (x := s212) b212 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M189
