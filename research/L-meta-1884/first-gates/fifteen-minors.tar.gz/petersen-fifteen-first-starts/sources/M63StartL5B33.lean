import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1211 : Blocked tgt 5 s1211 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1211 5 _ le
  decide +kernel
theorem b1212 : Blocked tgt 5 s1212 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(2,false),(3,false)),(false,(0,true),(5,false))] s1212 5 _ le
  decide +kernel
theorem b1217 : Blocked tgt 5 s1217 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1217 5 _ le
  decide +kernel
theorem b1218 : Blocked tgt 5 s1218 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1218 5 _ le
  decide +kernel
theorem b1219 : Blocked tgt 5 s1219 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s1219 5 _ le
  decide +kernel
theorem b1220 : Blocked tgt 5 s1220 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1220 5 _ le
  decide +kernel
theorem b1221 : Blocked tgt 5 s1221 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s1221 5 _ le
  decide +kernel
theorem b1222 : Blocked tgt 5 s1222 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s1222 5 _ le
  decide +kernel
theorem b1223 : Blocked tgt 5 s1223 := by
  intro k le c
  apply rejects_sound r7 i4 3 tgt small7 hot7 [] s1223 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
