import M111StartData
import M111StartL6B0
import M111StartL6B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_5_2 : NoAtMost (0x3333333300000000 :: inputs 6) tgt 6 := by
  change NoAtMost [0x3333333300000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 6
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s139] [194,2850,195,2915,196,2850,835,2915,390,2854,455,2919,196,2854,839,2919,714,2858,715,2923,716,2858,843,2923,390,3430,455,3431,716,3430,1351,3431,1106,3186,195,2915,1236,3186,835,2915,1366,3446,455,2919,1236,3446,839,2919,1626,3706,715,2923,1756,3706,843,2923,1366,3446,455,455,1756,3446,3740,3740,2210,2850,2275,2915,196,2850,2915,2915,2470,2854,2535,2919,196,2854,2919,2919,2730,2858,2795,2923,716,2858,2923,2923,2470,3430,2535,3431,716,3430,3431,3431,3186,3186,2275,2915,1236,3186,2915,2915,3446,3446,2535,2919,1236,3446,2919,2919,3706,3706,2795,2923,1756,3706,2923,2923,3446,3446,2535,455,1756,3446,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s139], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s139) b139 <|
    PetersenLocalChildren.nil
#print axioms gate_1_5_2
end PetersenSmallStarts.M111
