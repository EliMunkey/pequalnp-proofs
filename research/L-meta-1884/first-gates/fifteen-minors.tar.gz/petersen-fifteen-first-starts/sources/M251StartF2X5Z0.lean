import M251StartData
import M251StartL7B0
import M251StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M251
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_2_5_0 : NoAtMost (0xfffffffff0f0f0f0fffffffff0f0f0f0 :: inputs 7) tgt 7 := by
  change NoAtMost [0xfffffffff0f0f0f0fffffffff0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s53] [386,902,387,903,388,904,1155,1671,902,902,903,903,904,904,1671,1671,1162,1578,387,903,1420,1420,2179,2695,902,902,903,903,904,904,2695,2695,2194,2710,387,903,2452,2968,1155,1671,2710,2710,903,903,2968,2968,1671,1671,3226,3642,387,903,3484,3484,3868,11548,2710,2710,903,903,2968,2968,6936,6936,4386,4386,4515,4515,388,904,5283,5283,4902,4902,5031,5031,904,904,5799,5799,5290,5290,4515,4515,1420,1420,6307,6307,4902,4902,5031,5031,904,904,6823,6823,6322,6322,4515,4515,2452,2968,5283,5283,6838,6838,5031,5031,2968,2968,5799,5799,7354,7354,4515,4515,3484,3484,3868,11548,6838,6838,5031,5031,2968,2968,11032,11032,8642,9158,8643,9159,8644,9160,9411,9927,9158,9158,9159,9159,9160,9160,9927,9927,9418,9834,8643,9159,9676,9676,10435,10951,9158,9158,9159,9159,9160,9160,10951,10951,2194,2710,8643,9159,2452,2968,9411,9927,2710,2710,9159,9159,2968,2968,9927,9927,3226,3642,8643,9159,3484,3484,3868,6424,2710,2710,9159,9159,2968,2968,6936,6936,12642,12642,12771,12771,8644,9160,13539,13539,13158,13158,13287,13287,9160,9160,14055,14055,13546,13546,12771,12771,9676,9676,14563,14563,13158,13158,13287,13287,9160,9160,15079,15079,6322,6322,12771,12771,2452,2968,13539,13539,6838,6838,13287,13287,2968,2968,14055,14055,7354,7354,12771,12771,3484,3484,3868,7738,6838,6838,13287,13287,2968,2968,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s53], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s53) b53 <|
    PetersenLocalChildren.nil
#print axioms gate_2_5_0
end PetersenSmallStarts.M251
