import M250StartData
import M250StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M250
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_1_3 : NoAtMost (0x8888888888888888 :: inputs 6) tgt 4 := by
  change NoAtMost [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 4
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (6:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s3] [386,453,451,453,388,453,453,453,390,1221,455,1221,1220,1221,1221,1221,906,973,971,973,908,973,973,973,910,1741,975,1741,1740,1741,1741,1741,1106,453,451,453,1236,453,453,453,1366,2757,455,2757,1236,2757,2757,2757,1626,973,971,973,1756,973,973,973,1886,2765,975,2765,1756,2765,2765,2765,2466,2533,2531,2533,2468,2533,2533,2533,2470,2789,2535,2789,2724,2789,2789,2789,906,973,971,973,908,973,973,973,910,1741,975,1741,1740,1741,1741,1741,3186,2533,2531,2533,3316,2533,2533,2533,3446,2789,2535,2789,3316,2789,2789,2789,1626,973,971,973,1756,973,973,973,1886,1886,975,1950,1756,1886,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s3], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s3) b3 <|
    PetersenLocalChildren.nil
#print axioms gate_0_1_3
end PetersenSmallStarts.M250
