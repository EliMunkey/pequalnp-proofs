import M119StartData
import M119StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M119
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_3_1 : NoAtMost (0xaa00aa00aa00aa :: inputs 6) tgt 5 := by
  change NoAtMost [0xaa00aa00aa00aa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 5
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s9,s0,s13] [195,196,196,196,197,1092,580,1092,391,456,456,456,197,1352,840,1352,587,196,196,196,717,1092,1092,1092,847,456,456,456,717,1352,1352,1352,1107,196,196,196,1237,1429,580,1429,1367,456,456,456,1237,1749,840,3221,1627,196,196,196,1757,1757,1949,1949,1887,456,456,456,1757,1757,3741,3741,2211,2276,2276,2276,197,3172,2660,3172,2471,2536,2536,2536,197,3432,2920,3432,2667,2276,2276,2276,717,3172,3172,3172,2927,2536,2536,2536,717,3432,3432,3432,3187,2276,2276,2276,1237,1429,2660,1429,3447,2536,2536,2536,1237,1749,2920,0,3707,2276,2276,2276,1757,1757,1949,1949,3967,2536,2536,2536,1757,1757,1,2] (by decide +kernel)
  change ∀ b ∈ [s9,s0,s13], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.nil
#print axioms gate_0_3_1
end PetersenSmallStarts.M119
