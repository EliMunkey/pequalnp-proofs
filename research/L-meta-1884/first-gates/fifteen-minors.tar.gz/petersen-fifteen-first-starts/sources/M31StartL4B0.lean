import M31StartData
import M31StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M31
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b9 : Blocked tgt 4 s9 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s9 4 _ le
  decide +kernel
theorem b13 : Blocked tgt 4 s13 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s13 4 _ le
  decide +kernel
theorem b17 : Blocked tgt 4 s17 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [724,692,197,692,361,425,101,361,229,421,105,229,229,677,212,229,393,393,692,425,692,389,916,692,360,677,676,676,720,421,417,417,425,549,809,425,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b22 : Blocked tgt 4 s22 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s22 4 _ le
  decide +kernel
theorem b23 : Blocked tgt 4 s23 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [458,362,393,362,425,361,101,361,417,417,421,722,425,809,549,425,562,361,360,360,626,106,850,626,362,114,842,362,97,105,353,97,361,778,809,361,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b24 : Blocked tgt 4 s24 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s24 4 _ le
  decide +kernel
theorem b25 : Blocked tgt 4 s25 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [842,362,114,362,677,229,196,229,809,425,549,425,677,421,553,421,197,197,360,229,362,393,458,362,98,106,354,98,361,101,425,361,229,105,421,229,194,421,417,417]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b30 : Blocked tgt 4 s30 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,724,196,692,362,458,392,362,626,850,106,626,362,842,114,362,360,458,720,458,724,786,916,724,212,212,724,842,722,202,850,722,458,210,842,458,388,842,834,834]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b43 : Blocked tgt 4 s43 := by
  intro k le c
  apply rejects_sound r5 i4 3 tgt small5 hot5 [] s43 4 _ le
  decide +kernel
theorem b44 : Blocked tgt 4 s44 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [842,362,98,362,229,229,196,677,809,425,549,425,677,421,553,421,196,361,360,360,362,393,458,362,389,362,362,421,361,394,425,361,421,361,421,485,194,421,417,417]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b54 : Blocked tgt 4 s54 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [361,393,628,361,692,560,692,389,916,692,361,677,676,676,425,392,628,421,417,417,425,549,809,425,624,421,784,421,360,677,776,677,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b55 : Blocked tgt 4 s55 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s55 4 _ le
  decide +kernel
theorem b58 : Blocked tgt 4 s58 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,692,361,425,101,361,197,421,105,197,197,677,776,197,360,425,392,425,724,421,916,421,196,677,708,677,784,421,417,417,425,549,809,425,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b59 : Blocked tgt 4 s59 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [692,692,233,233,101,361,229,229,105,421,361,677,776,677,200,425,200,425,724,421,724,421,360,677,776,677,784,421,417,417,425,549,809,425,421,553,677,421]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
theorem b62 : Blocked tgt 4 s62 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s62 4 _ le
  decide +kernel
theorem b63 : Blocked tgt 4 s63 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [360,560,361,425,392,361,97,353,105,97,361,809,776,361,360,425,392,425,624,104,784,624,360,809,776,809,720,425,417,417,425,208,809,425,545,553,545,801]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 3 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M31
