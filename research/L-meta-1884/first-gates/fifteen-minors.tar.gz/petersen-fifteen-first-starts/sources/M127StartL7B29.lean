import M127StartData
import M127StartL6B28
import M127StartL6B27
import M127StartPins0
import M127StartL6B26
import M127StartL6B29
import M127StartL6B7
import M127StartL6B4
import M127StartL6B30
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b972 : Blocked tgt 7 s972 := by
  apply PetersenFastNode.node (nxt := #[s973,s929,s974,s976]) (hints := [5550,5550,10953,9161,13160,9161,4918,10953,10441,10441,10953,9929,7478,9929,11469,10953,10953,0,10953,13001,1,10953,2697,10889,2761,2697,13160,9161,13160,9161,4918,14568,4918,6582,6582,9929,7478,9929,7470,6582,7470,7598,2454,13001,6550,13001,13614,6888,13614,6582,9677,9161,9161,9677,9161,8653,9929,9161,9677,9161,9161,9677,9161,9064,13001,9161,905,969,9097,905,4918,9929,5942,9929,9933,9933,13517,13001,13517,13001,13614,2,13614,4918,3,9929,9929,7462,9929,12493,13001,9929,1673,1737,9865,1673,13517,13001,13517,13001,7470,12598,13614,7470,4745,4809,12937,4745]) (by decide +kernel)
  change ∀ b ∈ [s973,s929,s974,s976], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s973) b973 <|
    PetersenLocalChildren.push (x := s929) b929 <|
    PetersenLocalChildren.push (x := s974) b974 <|
    PetersenLocalChildren.push (x := s976) b976 <|
    PetersenLocalChildren.nil
theorem b977 : Blocked tgt 7 s977 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s977 7 _ le
  decide +kernel
theorem b978 : Blocked tgt 7 s978 := by
  apply PetersenFastNode.node (nxt := #[s979,s934,s906,s980,s974]) (hints := [5551,5551,6969,906,6969,906,5741,1742,5741,1742,7479,1674,7479,1674,2698,2698,0,4746,1,4746,13615,2,13615,3,6841,906,6969,906,6583,1742,5741,1742,6583,1674,7479,1674,7471,6583,7599,2455,4746,6551,4746,13615,6841,13615,6583,1742,906,1742,1998,906,8654,1674,906,906,4921,6953,906,906,2873,4746,906,1422,906,906,1422,7479,1674,1734,1674,1742,4,7471,1742,1742,4746,5838,1742,1678,1678,1674,7471,7463,1674,1674,12494,4746,1674,7479,1674,1674,7479,4746,3375,4746,3343,7471,12599,13615,7471,5262,4746,4746,5262]) (by decide +kernel)
  change ∀ b ∈ [s979,s934,s906,s980,s974], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s979) b979 <|
    PetersenLocalChildren.push (x := s934) b934 <|
    PetersenLocalChildren.push (x := s906) b906 <|
    PetersenLocalChildren.push (x := s980) b980 <|
    PetersenLocalChildren.push (x := s974) b974 <|
    PetersenLocalChildren.nil
theorem b981 : Blocked tgt 7 s981 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s981 7 _ le
  decide +kernel
theorem b982 : Blocked tgt 7 s982 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s982 7 _ le
  decide +kernel
theorem b983 : Blocked tgt 7 s983 := by
  apply PetersenFastNode.node (nxt := #[s984,s937,s985]) (hints := [10952,0,11468,10952,5549,5549,13675,9676,13675,9676,5933,9932,5933,9932,10952,11976,7461,10952,10952,13516,1,13516,13613,10888,13613,2696,7469,7597,6565,7469,9160,9676,9160,9676,7469,9932,4901,9932,9928,9928,13000,13516,13000,13516,7469,13613,12581,7469,13675,9676,13675,9676,5933,9932,5933,9932,6565,2,7461,6565,2437,13516,6533,13516,13613,6887,13613,6565,9676,8648,9932,9676,9160,9676,9676,9160,9676,9579,13516,9676,1420,1484,9612,1420,4901,9932,9932,4901,9932,12488,13516,9932,1676,1740,9868,1676,13000,13516,13000,13516,7461,13613,12581,13613,5260,5324,13452,5260]) (by decide +kernel)
  change ∀ b ∈ [s984,s937,s985], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s984) b984 <|
    PetersenLocalChildren.push (x := s937) b937 <|
    PetersenLocalChildren.push (x := s985) b985 <|
    PetersenLocalChildren.nil
theorem b986 : Blocked tgt 7 s986 := by
  intro k le c
  apply rejects_sound r5 i6 6 tgt small5 hot5 [] s986 7 _ le
  decide +kernel
theorem b987 : Blocked tgt 7 s987 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(4,true))] s987 7 _ le
  decide +kernel
theorem b992 : Blocked tgt 7 s992 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s992 7 _ le
  decide +kernel
theorem b993 : Blocked tgt 7 s993 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s993 7 _ le
  decide +kernel
theorem b994 : Blocked tgt 7 s994 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s994 7 _ le
  decide +kernel
theorem b995 : Blocked tgt 7 s995 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s995 7 _ le
  decide +kernel
theorem b996 : Blocked tgt 7 s996 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s996 7 _ le
  decide +kernel
theorem b997 : Blocked tgt 7 s997 := by
  apply PetersenFastNode.node (nxt := #[s998,s999,s1000,s1001,s1002,s1006,s220,s110,s1007,s1008,s1009,s1010,s1012,s1013,s1014,s1015,s1016,s1017]) (hints := [9047,15078,0,9047,1436,9175,1436,1436,1,9175,15078,9175,15078,15078,2,1436,1436,13015,1436,1436,3,10982,15078,13015,1436,1436,1820,9947,15078,9947,1820,15078,1820,1436,1436,9947,2468,2468,3364,412,1436,9943,3364,1436,3364,2468,2468,9943,1436,1436,3356,420,2468,10967,3356,2468,3356,1436,1436,10967,1436,1436,9500,6886,15078,4,9500,15078,9500,1436,1436,5,9175,9175,13015,11110,6,7,9691,9691,9947,8663,9175,1820,9947,9175,9947,9691,9691,1820,9175,9175,9943,8667,9691,3364,9943,9691,9943,9175,9175,3364,9175,9175,10967,3356,8,3356,10967,9,10967,9175,9175,3356,919,919,10,983,9175,9500,9111,9175,11,919,919,9500,13531,13531,9818,9947,13015,9947,12503,13015,9818,9947,13531,9947,13015,13015,11878,9943,13531,9943,12507,13531,11878,9943,13015,9943,13015,13015,11354,10967,12,10967,11354,13,11354,10967,13015,10967,4759,4759,14,12951,13015,9500,4823,13015,15,4759,4759,9500,2852,2852,3364,9943,9947,9943,9939,9947,3364,9939,2852,9943,9947,9947,11483,10455,2852,10967,11483,2852,11483,9947,9947,10967,1691,1691,9500,1755,9947,16,9883,9947,9500,1691,1691,17,9943,9943,10967,10459,3364,11483,10967,3364,10967,9943,9943,11483,1687,1687,10532,1751,9943,9500,9879,9943,10532,1687,1687,9500,2711,2711,9500,2775,10967,10532,10903,10967,9500,2711,2711,10532]) (by decide +kernel)
  change ∀ b ∈ [s998,s999,s1000,s1001,s1002,s1006,s220,s110,s1007,s1008,s1009,s1010,s1012,s1013,s1014,s1015,s1016,s1017], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s998) b998 <|
    PetersenLocalChildren.push (x := s999) b999 <|
    PetersenLocalChildren.push (x := s1000) b1000 <|
    PetersenLocalChildren.push (x := s1001) b1001 <|
    PetersenLocalChildren.push (x := s1002) b1002 <|
    PetersenLocalChildren.push (x := s1006) b1006 <|
    PetersenLocalChildren.push (x := s220) b220 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s1007) b1007 <|
    PetersenLocalChildren.push (x := s1008) b1008 <|
    PetersenLocalChildren.push (x := s1009) b1009 <|
    PetersenLocalChildren.push (x := s1010) b1010 <|
    PetersenLocalChildren.push (x := s1012) b1012 <|
    PetersenLocalChildren.push (x := s1013) b1013 <|
    PetersenLocalChildren.push (x := s1014) b1014 <|
    PetersenLocalChildren.push (x := s1015) b1015 <|
    PetersenLocalChildren.push (x := s1016) b1016 <|
    PetersenLocalChildren.push (x := s1017) b1017 <|
    PetersenLocalChildren.nil
theorem b1018 : Blocked tgt 7 s1018 := by
  apply PetersenFastNode.node (nxt := #[s220,s1019,s1021,s1022,s1023]) (hints := [1423,1423,13258,0,9162,13002,13002,1807,9934,1807,9934,3351,9930,3351,9930,3343,10954,3343,10954,9487,1,9487,2,15065,9162,5519,9162,15065,5519,5519,15065,1807,9934,1807,9934,3351,9930,3351,9930,3343,10954,3343,10954,5519,6873,9487,5519,9162,11097,9678,8650,9934,9678,9162,8654,9930,9162,9162,3343,10954,9162,906,970,9098,906,9805,9934,9805,9934,11865,9930,11865,9930,11341,10954,11341,10954,3,9487,4,9487,2839,9930,9926,9926,9934,10442,11470,9934,1678,1742,9870,1678,9930,10446,10954,9930,1674,1738,9866,1674,2698,2762,10890,2698]) (by decide +kernel)
  change ∀ b ∈ [s220,s1019,s1021,s1022,s1023], Blocked tgt 6 b
  exact 
    PetersenLocalChildren.push (x := s220) b220 <|
    PetersenLocalChildren.push (x := s1019) b1019 <|
    PetersenLocalChildren.push (x := s1021) b1021 <|
    PetersenLocalChildren.push (x := s1022) b1022 <|
    PetersenLocalChildren.push (x := s1023) b1023 <|
    PetersenLocalChildren.nil
theorem b1025 : Blocked tgt 7 s1025 := by
  intro k le c
  apply rejects_sound r6 i4 3 tgt small6 hot6 [] s1025 7 _ le
  decide +kernel
end PetersenSmallStarts.M127
