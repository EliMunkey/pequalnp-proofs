import M111StartData
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b20 : Blocked tgt 3 s20 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [388,388,714,906,776,714,194,706,202,194,712,906,776,906,452,200,772,452,386,394,898,386]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
theorem b52 : Blocked tgt 3 s52 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [194,194,1349,453,388,453,1089,1345,1093,1089,388,453,388,453,386,1092,386,1218,193,197,449,193]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
theorem b89 : Blocked tgt 3 s89 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [453,201,453,837,386,837,386,833,194,773,194,1602,841,197,841,1609,388,1609,1608,1608,776,777,840,776]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
theorem b111 : Blocked tgt 3 s111 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1426,1234,1104,1234,193,193,1089,1410,1089,386,1104,1234,1234,1104,194,210,1218,194,449,400,1089,449]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 2 b
  exact 
    
    PetersenLocalChildren.nil
end PetersenSmallStarts.M111
