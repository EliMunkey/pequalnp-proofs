import M127StartData
import M127StartPins0
import M127StartL5B2
import M127StartPins1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M127
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1069 : Blocked tgt 6 s1069 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1069 6 _ le
  decide +kernel
theorem b1070 : Blocked tgt 6 s1070 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1070 6 _ le
  decide +kernel
theorem b1071 : Blocked tgt 6 s1071 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1071 6 _ le
  decide +kernel
theorem b1072 : Blocked tgt 6 s1072 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1072 6 _ le
  decide +kernel
theorem b1073 : Blocked tgt 6 s1073 := by
  intro k le c
  apply rejects_sound r8 i4 3 tgt small8 hot8 [] s1073 6 _ le
  decide +kernel
theorem b1079 : Blocked tgt 6 s1079 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5514,1418,10964,1418,12997,9157,11092,9157,13513,9929,12485,9929,12997,9925,12489,9925,12997,10949,11336,10949,4741,12933,4805,4741,9029,9029,1418,9157,1418,9929,1802,1418,2450,394,3346,2450,1418,402,3338,1418,1418,6868,9482,1418,9673,8645,9929,9673,9157,8649,9925,9157,9157,3338,10949,9157,901,965,9093,901,2834,9925,9921,9921,9929,10437,11465,9929,1673,1737,9865,1673,9925,10441,10949,9925,1669,1733,9861,1669,2693,2757,10885,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b1080 : Blocked tgt 6 s1080 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1080 6 _ le
  decide +kernel
theorem b1081 : Blocked tgt 6 s1081 := by
  apply PetersenFastNode.node (nxt := #[s1082]) (hints := [4742,0,5515,5515,902,2837,1674,1803,1674,1803,1670,3347,1670,3347,2694,3339,2694,3339,2709,2709,4742,902,11029,902,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,6805,902,7061,902,1803,1674,1803,1674,3347,1670,3347,1670,3339,2694,3339,2694,1418,1803,1674,1803,902,3347,1670,3347,902,3339,2694,3339,2835,779,3347,2835,1803,787,3339,1803,1670,3339,3331,3331]) (by decide +kernel)
  change ∀ b ∈ [s1082], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1082) b1082 <|
    PetersenLocalChildren.nil
theorem b1085 : Blocked tgt 6 s1085 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1085 6 _ le
  decide +kernel
theorem b1086 : Blocked tgt 6 s1086 := by
  apply PetersenFastNode.node (nxt := #[s1087,s1088]) (hints := [2710,2710,4743,903,2838,903,5259,1675,4231,1675,4743,1671,4235,1671,4743,2695,3340,2695,4743,0,2838,903,2838,903,1610,1675,1610,1675,3348,1671,3348,1671,3340,2695,3340,2695,5516,5516,1419,391,1675,1419,903,395,1671,903,903,790,2695,903,1,903,903,9482,3348,1671,1667,1667,1675,2183,3211,1675,1675,1804,1671,2187,2695,1671,3348,1671,1671,3348,3340,2695,2695,3340]) (by decide +kernel)
  change ∀ b ∈ [s1087,s1088], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s1087) b1087 <|
    PetersenLocalChildren.push (x := s1088) b1088 <|
    PetersenLocalChildren.nil
theorem b1089 : Blocked tgt 6 s1089 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1089 6 _ le
  decide +kernel
theorem b1095 : Blocked tgt 6 s1095 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1095 6 _ le
  decide +kernel
theorem b1096 : Blocked tgt 6 s1096 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1096 6 _ le
  decide +kernel
theorem b1097 : Blocked tgt 6 s1097 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1097 6 _ le
  decide +kernel
theorem b1098 : Blocked tgt 6 s1098 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1098 6 _ le
  decide +kernel
theorem b1099 : Blocked tgt 6 s1099 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s1099 6 _ le
  decide +kernel
end PetersenSmallStarts.M127
