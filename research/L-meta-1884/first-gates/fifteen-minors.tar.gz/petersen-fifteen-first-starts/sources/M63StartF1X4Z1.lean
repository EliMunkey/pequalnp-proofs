import M63StartData
import M63StartL7B0
import M63StartL7B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_1_4_1 : NoAtMost (0xcccc0000cccc :: inputs 6) tgt 7 := by
  change NoAtMost [0xcccc0000cccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] tgt 7
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 64); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 64); change false=true at x; contradiction)
    #[s0,s927] [194,196,195,388,196,196,835,388,390,196,455,839,196,196,839,839,714,716,715,908,716,716,843,908,390,716,455,1351,716,716,1351,1351,1106,196,195,388,1236,196,835,388,1366,196,455,839,1236,196,839,839,714,716,715,908,716,716,843,908,1366,716,455,2375,716,716,2375,2375,2146,2276,195,2468,2276,2276,835,2468,2406,2276,455,839,2276,2276,839,839,2666,2796,715,2988,2796,2796,843,2988,2406,2796,455,1351,2796,2796,1351,1351,3186,2276,195,2468,3316,2276,835,2468,3446,2276,455,839,3316,2276,839,839,2666,2796,715,2988,2796,2796,843,2988,3446,2796,455,3510,2796,2796,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s927], Blocked tgt 7 b
  exact 
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s927) b927 <|
    PetersenLocalChildren.nil
#print axioms gate_1_4_1
end PetersenSmallStarts.M63
