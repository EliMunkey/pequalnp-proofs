import M111StartData
import M111StartL4B1
import M111StartL4B0
import M111StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M111
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b112 : Blocked tgt 5 s112 := by
  apply PetersenFastNode.node (nxt := #[s113]) (hints := [3731,1235,1365,1235,2502,202,842,1427,842,1427,838,3219,1350,3715,1350,2691,1365,1235,1235,1365,1235,778,1427,1235,1365,1235,1235,1365,195,211,1219,195,842,1427,842,1427,838,2250,838,2502,1350,2453,1350,2502,0,1427,1427,834,387,403,1411,387,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s113], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s113) b113 <|
    PetersenLocalChildren.nil
theorem b114 : Blocked tgt 5 s114 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3218,1234,1364,1234,453,453,841,1426,841,1426,837,3730,1349,3202,1349,2178,1364,1234,1234,1364,1234,777,1426,1234,1234,773,1812,1234,194,210,1218,194,841,1426,841,1426,837,2249,837,2501,1349,2452,1349,2501,1426,837,833,1426,386,402,1410,386,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b115 : Blocked tgt 5 s115 := by
  apply PetersenFastNode.node (nxt := #[s116]) (hints := [3723,715,1365,715,2502,405,842,907,842,907,838,3715,838,3203,1350,2699,1365,715,715,1365,715,778,907,715,195,203,707,195,0,715,715,1349,842,907,842,907,838,2250,838,2502,1350,2453,1350,2502,387,395,899,387,842,907,907,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s116], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s116) b116 <|
    PetersenLocalChildren.nil
theorem b117 : Blocked tgt 5 s117 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2698,714,1364,714,453,453,841,906,841,906,837,2690,837,2178,1349,3722,1364,714,714,1364,714,777,906,714,194,202,706,194,714,1349,1348,714,841,906,841,906,837,2249,837,2501,1349,2452,1349,2501,386,394,898,386,906,1093,1609,906,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact 
    
    PetersenLocalChildren.nil
theorem b118 : Blocked tgt 5 s118 := by
  apply PetersenFastNode.node (nxt := #[s119,s19,s120]) (hints := [1352,0,1352,2701,2701,717,1,717,456,456,844,909,844,909,840,2693,840,2181,717,1741,1352,2,2504,1352,909,1096,909,1612,840,1100,840,1352,2439,717,717,2503,717,780,909,717,197,205,709,197,844,909,844,909,840,2252,840,2504,389,397,901,389]) (by decide +kernel)
  change ∀ b ∈ [s119,s19,s120], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s119) b119 <|
    PetersenLocalChildren.push (x := s19) b19 <|
    PetersenLocalChildren.push (x := s120) b120 <|
    PetersenLocalChildren.nil
theorem b121 : Blocked tgt 5 s121 := by
  apply PetersenFastNode.node (nxt := #[s122,s123]) (hints := [3220,1236,1366,1236,203,203,843,1428,843,1428,839,0,1351,3204,1351,2180,1366,1236,1236,1366,1236,779,1428,1236,1366,1236,1236,1366,196,212,1220,196,843,1428,843,1428,839,2503,1351,2202,1351,2251,1,1428,1428,835,388,404,1412,388,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s122,s123], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s122) b122 <|
    PetersenLocalChildren.push (x := s123) b123 <|
    PetersenLocalChildren.nil
theorem b124 : Blocked tgt 5 s124 := by
  apply PetersenFastNode.node (nxt := #[s125,s126]) (hints := [2700,716,1366,716,406,406,843,908,843,908,839,2692,839,2180,1351,0,1366,716,716,1366,716,779,908,716,196,204,708,196,1,716,716,1350,843,908,843,908,839,2202,839,2454,1351,2503,388,396,900,388,843,908,908,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s125,s126], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s125) b125 <|
    PetersenLocalChildren.push (x := s126) b126 <|
    PetersenLocalChildren.nil
theorem b127 : Blocked tgt 5 s127 := by
  apply PetersenFastNode.node (nxt := #[s128]) (hints := [1350,0,1365,715,1365,715,454,454,1817,907,1817,907,1813,2691,1813,2179,715,1350,715,1349,1350,2453,907,1094,907,1610,838,1098,838,1350,1365,715,715,1365,715,1109,907,715,195,203,707,195,1817,907,1817,907,1813,2250,1813,2502,387,395,899,387]) (by decide +kernel)
  change ∀ b ∈ [s128], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s128) b128 <|
    PetersenLocalChildren.nil
theorem b129 : Blocked tgt 5 s129 := by
  apply PetersenFastNode.node (nxt := #[s130,s110,s131]) (hints := [3221,1237,1367,1237,456,456,840,0,840,3221,3221,1429,1,1429,1352,3205,1352,2181,1367,1237,1237,1367,1237,776,1815,1237,1237,1111,1429,1237,197,213,1221,197,840,2,840,2504,2244,1429,2500,1429,1352,2455,1352,2504,1429,1941,840,791,1352,840,389,405,1413,389]) (by decide +kernel)
  change ∀ b ∈ [s130,s110,s131], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s130) b130 <|
    PetersenLocalChildren.push (x := s110) b110 <|
    PetersenLocalChildren.push (x := s131) b131 <|
    PetersenLocalChildren.nil
theorem b132 : Blocked tgt 5 s132 := by
  apply PetersenFastNode.node (nxt := #[s133]) (hints := [838,0,838,3219,1365,1235,1365,1235,454,454,834,1939,834,1939,1350,3203,1350,2179,1235,1365,1235,1365,838,2502,2242,838,1427,1427,838,1350,1090,838,1365,1235,1235,1365,1235,1365,1939,1235,195,211,1219,195,834,1939,2502,1939,1350,2453,1350,2502,899,915,1923,899]) (by decide +kernel)
  change ∀ b ∈ [s133], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s133) b133 <|
    PetersenLocalChildren.nil
theorem b135 : Blocked tgt 5 s135 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s135 5 _ le
  decide +kernel
theorem b136 : Blocked tgt 5 s136 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s136 5 _ le
  decide +kernel
theorem b137 : Blocked tgt 5 s137 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s137 5 _ le
  decide +kernel
theorem b138 : Blocked tgt 5 s138 := by
  intro k le c
  apply rejects_sound r1 i4 3 tgt small1 hot1 [] s138 5 _ le
  decide +kernel
end PetersenSmallStarts.M111
