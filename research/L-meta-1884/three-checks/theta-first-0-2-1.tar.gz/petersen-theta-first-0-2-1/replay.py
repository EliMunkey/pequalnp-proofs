"""Check a packed Lean source DAG with the pinned project's libraries and no prebuilt local oleans."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True, help='The pinned Lean/Lake project directory')
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--target', default='M191OrbitF0X2Z1')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sources = root/'sources'
    build = root/'build'
    build.mkdir(exist_ok=True)
    entries = [row.split('\t') for row in (root/'sources.tsv').read_text().splitlines()[1:]]
    modules = {name: (digest, sources/path) for name, digest, path in entries}
    if args.target not in modules:
        raise ValueError(f'unknown target {args.target}')
    needed = {}
    def visit(name):
        if name in needed:
            return
        digest, source = modules[name]
        data = source.read_bytes()
        if sha256(data).hexdigest() != digest:
            raise ValueError(f'hash mismatch for {name}')
        dependencies = {d for d in re.findall(r'^import\s+(\S+)', data.decode(), re.M) if d in modules}
        needed[name] = dependencies
        for d in dependencies:
            visit(d)
    visit(args.target)
    env = dict(os.environ)
    env['LEAN_PATH'] = str(build)
    def check(name):
        _, source = modules[name]
        obj = build/(name.replace('.', '/')+'.olean')
        log = obj.with_suffix('.log')
        obj.parent.mkdir(exist_ok=True, parents=True)
        with log.open('w') as out:
            result = subprocess.run(['lake','env','lean','-j','2','--root='+str(sources),'-o',str(obj),str(source)],
                cwd=args.project,env=env,stdout=out,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'{name} failed:\n{log.read_text()[-4000:]}')
        if 'sorryAx' in log.read_text():
            raise RuntimeError(f'{name} reported an unfinished proof')
        print(name,flush=True)
    done=set()
    pending=set(needed)
    running={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while pending or running:
            ready=sorted(n for n in pending if needed[n]<=done)
            while ready and len(running)<args.jobs:
                n=ready.pop(0);pending.remove(n);running[pool.submit(check,n)]=n
            if not running:
                raise RuntimeError('cyclic or unavailable module dependency')
            finished,_=wait(running,return_when=FIRST_COMPLETED)
            for future in finished:
                name=running.pop(future);future.result();done.add(name)
    print(f'Checked {len(done)} local source modules for {args.target}.')
    print((build/(args.target.replace('.','/')+'.log')).read_text(),end='')
if __name__=='__main__':
    main()
