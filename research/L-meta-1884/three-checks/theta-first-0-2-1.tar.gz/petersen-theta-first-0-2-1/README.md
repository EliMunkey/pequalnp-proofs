# Petersen signed circuit first-gate certificates

The entry module is `M191OrbitF0X2Z1`. Check the proof from source with `python3 replay.py --project /path/to/pequalnp-proofs/lean --jobs 4`. Use the project at `074709bd01fc526b9f6279e5b0a028946ceb39fb` with its pinned dependencies and Lean toolchain `leanprover/lean4:v4.36.0`. The verifier checks each module hash. Logs and compiled modules are written under `build/`.
