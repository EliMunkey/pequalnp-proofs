import M191StartPreferredSignals
import M191ResidualC7A0G1
import M191ResidualC7A0G20
import M191ResidualC7A0G21
import M191ResidualC7A0G22
import M191ResidualC7A0G27
import M191ResidualC7A0G30
import M191ResidualC7A0G32
import M191ResidualC7A0G4
import M191ResidualC7A0G9
import M191StagedF0X2Z1G10
import M191StagedF0X2Z1G12
import M191StagedF0X2Z1G13
import M191StagedF0X2Z1G14
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G16
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G18
import M191StagedF0X2Z1G19
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G22
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G5
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G9
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows4
import M191StartPreferredRows5
import M191StartPreferredRows6
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4182 : Blocked tgt 8 s4182 := by
  apply PetersenFastNode.node (nxt := #[s3453,s4183,s4184,s3384,s4185,s4186,s4187,s3635,s4188,s4189,s3819,s4190,s4191,s3826,s3848,s4192,s4193,s4023,s4110,s4194,s4195,s3991,s4012,s4196,s4170,s4197,s4198,s4199,s4200,s4201,s941,s4202,s4203,s4176,s4204,s4205,s4206]) (hints := [6873,6873,7001,810,4559,938,7001,4559,7001,6873,6873,938,4559,4559,5967,9830,6873,9958,5967,6873,5967,4559,4559,9958,7511,6873,7511,4559,4559,1706,6615,4559,7511,6615,6873,1706,4559,4559,11631,6873,6873,10470,10735,6873,11631,4559,4559,10470,8687,8687,13679,463,4559,4778,12783,4559,13679,8687,8687,4778,4559,4559,14679,8687,8687,0,8687,8687,14679,4559,4559,1,4559,4559,2,8687,8687,3,8687,8687,4,4559,4559,5,8678,8678,9958,938,938,5967,9958,938,9958,8678,8678,5967,938,938,1706,8678,8678,7511,1706,8678,1706,938,938,7511,938,938,10470,7001,7001,11631,10470,7001,10470,938,938,11631,938,938,4778,2905,7001,13679,4778,7001,4778,938,938,13679,938,938,14937,8678,8678,14679,8678,8678,14937,938,938,14679,938,938,6,8678,8678,7,8678,8678,8,938,938,9,8934,6999,7511,8934,9958,1706,9958,9958,7511,1706,6999,1706,9958,9958,10470,6999,6999,10,10470,6999,10470,9958,9958,11,9958,9958,12518,4778,5967,4778,12518,5967,12518,9958,9958,4778,1702,1702,14679,9958,9958,14937,9958,9958,14679,1702,1702,14937,1702,1702,12,9958,9958,13,9958,9958,14,1702,1702,15,1706,1706,16,10470,7511,10470,7511,7511,17,1706,1706,10470,1706,1706,4778,12518,7511,12518,4778,7511,4778,1706,1706,12518,1706,1706,14679,3447,11639,18,14679,11639,14679,1706,1706,19,1706,1706,20,7511,7511,21,7511,7511,22,1706,1706,23,4778,10470,4778,12663,24,14711,4778,25,4778,10470,10470,14711,2278,26,27,10470,10470,28,14679,29,14679,2730,10470,30,2730,29,31,4778,4778,10809,12518,12518,14679,12518,12518,10809,4778,4778,14679,4778,4778,32,12518,12518,33,12518,12518,34,4778,4778,35,8874,14679,30,8874,28,36]) (by decide +kernel)
  change ∀ b ∈ [s3453,s4183,s4184,s3384,s4185,s4186,s4187,s3635,s4188,s4189,s3819,s4190,s4191,s3826,s3848,s4192,s4193,s4023,s4110,s4194,s4195,s3991,s4012,s4196,s4170,s4197,s4198,s4199,s4200,s4201,s941,s4202,s4203,s4176,s4204,s4205,s4206], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3453) b3453 <|
    PetersenLocalChildren.push (x := s4183) b4183 <|
    PetersenLocalChildren.push (x := s4184) b4184 <|
    PetersenLocalChildren.push (x := s3384) b3384 <|
    PetersenLocalChildren.push (x := s4185) b4185 <|
    PetersenLocalChildren.push (x := s4186) b4186 <|
    PetersenLocalChildren.push (x := s4187) b4187 <|
    PetersenLocalChildren.push (x := s3635) b3635 <|
    PetersenLocalChildren.push (x := s4188) b4188 <|
    PetersenLocalChildren.push (x := s4189) b4189 <|
    PetersenLocalChildren.push (x := s3819) b3819 <|
    PetersenLocalChildren.push (x := s4190) b4190 <|
    PetersenLocalChildren.push (x := s4191) b4191 <|
    PetersenLocalChildren.push (x := s3826) b3826 <|
    PetersenLocalChildren.push (x := s3848) b3848 <|
    PetersenLocalChildren.push (x := s4192) b4192 <|
    PetersenLocalChildren.push (x := s4193) b4193 <|
    PetersenLocalChildren.push (x := s4023) b4023 <|
    PetersenLocalChildren.push (x := s4110) b4110 <|
    PetersenLocalChildren.push (x := s4194) b4194 <|
    PetersenLocalChildren.push (x := s4195) b4195 <|
    PetersenLocalChildren.push (x := s3991) b3991 <|
    PetersenLocalChildren.push (x := s4012) b4012 <|
    PetersenLocalChildren.push (x := s4196) b4196 <|
    PetersenLocalChildren.push (x := s4170) b4170 <|
    PetersenLocalChildren.push (x := s4197) b4197 <|
    PetersenLocalChildren.push (x := s4198) b4198 <|
    PetersenLocalChildren.push (x := s4199) b4199 <|
    PetersenLocalChildren.push (x := s4200) b4200 <|
    PetersenLocalChildren.push (x := s4201) b4201 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4202) b4202 <|
    PetersenLocalChildren.push (x := s4203) b4203 <|
    PetersenLocalChildren.push (x := s4176) b4176 <|
    PetersenLocalChildren.push (x := s4204) b4204 <|
    PetersenLocalChildren.push (x := s4205) b4205 <|
    PetersenLocalChildren.push (x := s4206) b4206 <|
    PetersenLocalChildren.nil
theorem b4215 : Blocked tgt 8 s4215 := by
  apply PetersenFastNode.node (nxt := #[s3233,s4216,s4217,s3244,s4218,s3246,s4219,s426,s4220,s4221]) (hints := [783,5556,911,5556,6846,5556,9939,5940,5556,4532,4532,5556,0,1,5556,5556,6588,5556,2703,7476,5556,9684,1460,13652,9684,5556,1492,13620,5556,911,6974,9683,911,9939,9683,911,8659,9675,911,911,9683,9683,911,911,7476,2703,911,911,13652,4751,911,911,1491,8847,911,5682,9939,5682,9939,2,3,4,5,6,7,8,9,7218,2703,7218,2703,13394,4751,13394,4751,14910,8847,14910,8847,6972,9939,9931,9931,8907,9939,9939,6972,9939,2703,11475,9939,9939,4751,13523,9939,1683,1747,9875,1683,1679,1679,2703,10451,2703,11467,4751,12499,4751,13515,8847,13620,8847,13620,2703,11475,2703,11475,4751,13523,4751,13523,8847,13620,8847,13620,2703,3380,4751,2703,2703,3283,8847,2703,4751,5331,8847,4751]) (by decide +kernel)
  change ∀ b ∈ [s3233,s4216,s4217,s3244,s4218,s3246,s4219,s426,s4220,s4221], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3233) b3233 <|
    PetersenLocalChildren.push (x := s4216) b4216 <|
    PetersenLocalChildren.push (x := s4217) b4217 <|
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s4218) b4218 <|
    PetersenLocalChildren.push (x := s3246) b3246 <|
    PetersenLocalChildren.push (x := s4219) b4219 <|
    PetersenLocalChildren.push (x := s426) b426 <|
    PetersenLocalChildren.push (x := s4220) b4220 <|
    PetersenLocalChildren.push (x := s4221) b4221 <|
    PetersenLocalChildren.nil
theorem b4243 : Blocked tgt 8 s4243 := by
  apply PetersenFastNode.node (nxt := #[s4244,s3344,s3406,s4245,s4246,s4247,s4248,s4249]) (hints := [6844,909,6972,6844,5554,9937,5938,5554,4530,4530,5554,6844,6844,5554,5554,6586,5554,4796,7474,5554,1458,5554,4749,5554,9682,5554,8845,13618,5554,9681,909,9937,9681,909,8657,9673,909,909,9681,9681,909,909,4924,2701,909,909,6972,4749,909,2844,909,909,2844,909,1489,8845,909,6970,9937,9929,9929,8905,9937,9937,6970,9937,2701,11473,9937,9937,4749,13521,9937,10066,9937,9937,10066,1681,1745,9873,1681,1677,1677,2701,10449,2701,11465,4749,12497,4749,13513,0,1,2,3,8845,13618,8845,13618,2701,11473,2701,11473,4749,13521,4749,13521,4,5,6,7,8845,13618,8845,13618,2701,7474,4749,2701,11602,2701,2701,11602,2701,3281,8845,2701,4749,13650,4749,5329,8845,4749,10780,8845,10780,8845]) (by decide +kernel)
  change ∀ b ∈ [s4244,s3344,s3406,s4245,s4246,s4247,s4248,s4249], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4244) b4244 <|
    PetersenLocalChildren.push (x := s3344) b3344 <|
    PetersenLocalChildren.push (x := s3406) b3406 <|
    PetersenLocalChildren.push (x := s4245) b4245 <|
    PetersenLocalChildren.push (x := s4246) b4246 <|
    PetersenLocalChildren.push (x := s4247) b4247 <|
    PetersenLocalChildren.push (x := s4248) b4248 <|
    PetersenLocalChildren.push (x := s4249) b4249 <|
    PetersenLocalChildren.nil
theorem b4272 : Blocked tgt 8 s4272 := by
  apply PetersenFastNode.node (nxt := #[s4273,s4274,s474,s4275,s4276,s4277,s4278,s4279,s4280,s595,s4281,s4282]) (hints := [6848,785,6976,6848,5558,6848,5942,5558,5300,5558,5558,5300,4534,4534,5558,6848,6848,5558,5558,6590,5558,4800,7478,5558,9686,1462,13654,9686,5558,1494,13622,5558,5686,913,5942,913,9685,913,0,1,913,913,2,3,913,913,4928,2705,913,913,2880,4753,913,913,13622,8849,913,9941,9941,6974,5942,5942,6974,6974,5942,5942,6974,11477,2705,11477,2705,13525,4753,13525,4753,5942,8849,13622,8849,4,5,6,7,8,9,10,11,11477,2705,11477,2705,13525,4753,13525,4753,13364,8849,13364,8849,1681,1681,2705,10453,2705,11469,4753,12501,4753,13517,8849,13622,8849,13622,2705,11477,2705,11477,4753,13525,4753,13525,8849,13622,8849,13622,2705,3382,4753,2705,2705,3285,8849,2705,4753,5333,8849,4753]) (by decide +kernel)
  change ∀ b ∈ [s4273,s4274,s474,s4275,s4276,s4277,s4278,s4279,s4280,s595,s4281,s4282], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4273) b4273 <|
    PetersenLocalChildren.push (x := s4274) b4274 <|
    PetersenLocalChildren.push (x := s474) b474 <|
    PetersenLocalChildren.push (x := s4275) b4275 <|
    PetersenLocalChildren.push (x := s4276) b4276 <|
    PetersenLocalChildren.push (x := s4277) b4277 <|
    PetersenLocalChildren.push (x := s4278) b4278 <|
    PetersenLocalChildren.push (x := s4279) b4279 <|
    PetersenLocalChildren.push (x := s4280) b4280 <|
    PetersenLocalChildren.push (x := s595) b595 <|
    PetersenLocalChildren.push (x := s4281) b4281 <|
    PetersenLocalChildren.push (x := s4282) b4282 <|
    PetersenLocalChildren.nil
theorem b4446 : Blocked tgt 8 s4446 := by
  apply PetersenFastNode.node (nxt := #[s4447,s4448,s4449,s4425,s4450,s4451,s4452,s4453,s4454,s2270,s4455,s4456,s4457,s4458]) (hints := [6850,787,6978,6850,5560,6850,5944,5560,4536,4536,5560,6850,6850,5560,5560,6592,5560,4802,7480,5560,9688,5560,5560,9688,9688,5560,5560,9688,5560,1496,13624,5560,9687,915,915,9687,915,8663,9679,915,915,9687,9687,915,915,4930,2707,915,915,2882,4755,915,9687,915,915,9687,915,1495,8851,915,6976,5944,5944,6976,6976,5944,5944,6976,11479,2707,11479,2707,1848,5944,4755,9943,9943,5944,8851,13624,8851,1683,1683,2707,10455,2707,11471,4755,0,4755,1,2,3,4,5,8851,13624,8851,13624,2707,11479,2707,11479,4755,6,4755,7,8,9,10,11,8851,13624,8851,13624,2707,7480,4755,2707,11479,2707,2707,11479,2707,3287,8851,2707,4755,13527,4755,13624,8851,4755,12,8851,13,8851]) (by decide +kernel)
  change ∀ b ∈ [s4447,s4448,s4449,s4425,s4450,s4451,s4452,s4453,s4454,s2270,s4455,s4456,s4457,s4458], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4447) b4447 <|
    PetersenLocalChildren.push (x := s4448) b4448 <|
    PetersenLocalChildren.push (x := s4449) b4449 <|
    PetersenLocalChildren.push (x := s4425) b4425 <|
    PetersenLocalChildren.push (x := s4450) b4450 <|
    PetersenLocalChildren.push (x := s4451) b4451 <|
    PetersenLocalChildren.push (x := s4452) b4452 <|
    PetersenLocalChildren.push (x := s4453) b4453 <|
    PetersenLocalChildren.push (x := s4454) b4454 <|
    PetersenLocalChildren.push (x := s2270) b2270 <|
    PetersenLocalChildren.push (x := s4455) b4455 <|
    PetersenLocalChildren.push (x := s4456) b4456 <|
    PetersenLocalChildren.push (x := s4457) b4457 <|
    PetersenLocalChildren.push (x := s4458) b4458 <|
    PetersenLocalChildren.nil
theorem b4462 : Blocked tgt 8 s4462 := by
  apply PetersenFastNode.node (nxt := #[s4463,s4464,s4465,s4429,s4466,s4467,s4468,s4469,s4470,s2274,s4471,s4472]) (hints := [6848,785,6976,6848,5558,9813,10070,5558,4534,4534,5558,6848,6848,5558,5558,6590,5558,4800,7478,5558,9686,1462,13654,9686,5558,9686,9686,5558,5558,9686,9686,5558,9685,913,9941,9685,913,8661,9677,913,913,9685,9685,913,913,4928,2705,913,913,2880,4753,913,913,9685,8849,913,1429,913,913,1429,11102,9941,9933,9933,8909,9941,9941,11102,9941,2705,11477,9941,9941,4753,13525,9941,1749,9941,8849,9941,1685,1681,1681,2705,10453,2705,11469,4753,12501,4753,13517,8849,0,8849,1,2,3,4,5,2705,11477,2705,11477,4753,13525,4753,13525,8849,6,8849,7,8,9,10,11,2705,3382,4753,2705,2705,11477,8849,2705,3221,2705,2705,3221,4753,13525,8849,4753,5269,4753,4753,5269,8849,13622]) (by decide +kernel)
  change ∀ b ∈ [s4463,s4464,s4465,s4429,s4466,s4467,s4468,s4469,s4470,s2274,s4471,s4472], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4463) b4463 <|
    PetersenLocalChildren.push (x := s4464) b4464 <|
    PetersenLocalChildren.push (x := s4465) b4465 <|
    PetersenLocalChildren.push (x := s4429) b4429 <|
    PetersenLocalChildren.push (x := s4466) b4466 <|
    PetersenLocalChildren.push (x := s4467) b4467 <|
    PetersenLocalChildren.push (x := s4468) b4468 <|
    PetersenLocalChildren.push (x := s4469) b4469 <|
    PetersenLocalChildren.push (x := s4470) b4470 <|
    PetersenLocalChildren.push (x := s2274) b2274 <|
    PetersenLocalChildren.push (x := s4471) b4471 <|
    PetersenLocalChildren.push (x := s4472) b4472 <|
    PetersenLocalChildren.nil
theorem b4490 : Blocked tgt 8 s4490 := by
  apply PetersenFastNode.node (nxt := #[s4491,s4492,s4493,s3344,s4494,s4031,s4495,s4319,s4496,s4497,s4447,s4498,s4036,s4425,s3759,s4499,s4500,s4501,s4502,s4503,s4504,s4505,s4506,s4071,s4507,s4042,s4508,s4509,s4510,s4511,s4512,s4513,s4514,s4515,s941,s4516,s4517,s4518,s4519,s4520,s4521]) (hints := [6877,6877,7005,814,4563,942,7005,4563,7005,6877,6877,942,4563,4563,5971,9842,6877,9970,5971,6877,5971,4563,4563,9970,7515,6877,7515,4563,4563,0,6619,4563,7515,6619,6877,1,4563,4563,7507,4829,6877,2734,6611,6877,7507,4563,4563,2734,9715,9715,13683,1491,4563,12530,12787,4563,13683,9715,9715,12530,8691,2749,2,4563,4563,3,4563,4563,4,2749,2749,5,4563,4563,13651,1523,9715,8878,12755,9715,13651,4563,4563,8878,9714,9714,9970,942,942,5971,9970,942,9970,9714,9714,5971,942,942,7773,9714,9714,7515,9714,9714,7773,942,942,7515,942,942,2734,4957,7005,7507,2734,7005,2734,942,942,7507,942,942,12530,7005,7005,13683,12530,7005,12530,942,942,13683,942,942,6,8690,9714,7,9706,9714,8,942,942,9,942,942,8878,1522,9714,13651,8878,9714,8878,942,942,13651,8938,7003,7515,9970,9970,7773,9970,9970,7515,7003,7003,7773,9970,9970,11506,2734,7003,2734,11506,7003,11506,9970,9970,2734,9970,9970,12530,1875,5971,10,12530,5971,12530,9970,9970,11,11131,11131,12,9970,9970,13,9962,9970,14,9962,11131,15,1714,1714,13651,1778,9970,8878,9906,9970,13651,1714,1714,8878,2734,5709,2734,11506,7515,11506,2734,7515,2734,11506,5709,11506,3419,16,17,12530,7515,12530,7515,7515,18,12530,19,12530,20,21,22,7515,7515,23,1710,7515,24,1710,19,25,8878,7515,8878,12627,26,13651,8878,27,8878,7515,7515,13651,2734,2734,12530,3411,7507,28,12530,7507,12530,2734,2734,29,2734,2734,30,10482,11506,31,11498,11506,32,2734,2734,33,2734,2734,8878,3314,11506,14683,8878,11506,8878,2734,2734,14683,4782,12530,34,4782,35,36,8878,4274,8878,4338,12530,13651,8878,12530,8878,4274,4274,13651,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651]) (by decide +kernel)
  change ∀ b ∈ [s4491,s4492,s4493,s3344,s4494,s4031,s4495,s4319,s4496,s4497,s4447,s4498,s4036,s4425,s3759,s4499,s4500,s4501,s4502,s4503,s4504,s4505,s4506,s4071,s4507,s4042,s4508,s4509,s4510,s4511,s4512,s4513,s4514,s4515,s941,s4516,s4517,s4518,s4519,s4520,s4521], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4491) b4491 <|
    PetersenLocalChildren.push (x := s4492) b4492 <|
    PetersenLocalChildren.push (x := s4493) b4493 <|
    PetersenLocalChildren.push (x := s3344) b3344 <|
    PetersenLocalChildren.push (x := s4494) b4494 <|
    PetersenLocalChildren.push (x := s4031) b4031 <|
    PetersenLocalChildren.push (x := s4495) b4495 <|
    PetersenLocalChildren.push (x := s4319) b4319 <|
    PetersenLocalChildren.push (x := s4496) b4496 <|
    PetersenLocalChildren.push (x := s4497) b4497 <|
    PetersenLocalChildren.push (x := s4447) b4447 <|
    PetersenLocalChildren.push (x := s4498) b4498 <|
    PetersenLocalChildren.push (x := s4036) b4036 <|
    PetersenLocalChildren.push (x := s4425) b4425 <|
    PetersenLocalChildren.push (x := s3759) b3759 <|
    PetersenLocalChildren.push (x := s4499) b4499 <|
    PetersenLocalChildren.push (x := s4500) b4500 <|
    PetersenLocalChildren.push (x := s4501) b4501 <|
    PetersenLocalChildren.push (x := s4502) b4502 <|
    PetersenLocalChildren.push (x := s4503) b4503 <|
    PetersenLocalChildren.push (x := s4504) b4504 <|
    PetersenLocalChildren.push (x := s4505) b4505 <|
    PetersenLocalChildren.push (x := s4506) b4506 <|
    PetersenLocalChildren.push (x := s4071) b4071 <|
    PetersenLocalChildren.push (x := s4507) b4507 <|
    PetersenLocalChildren.push (x := s4042) b4042 <|
    PetersenLocalChildren.push (x := s4508) b4508 <|
    PetersenLocalChildren.push (x := s4509) b4509 <|
    PetersenLocalChildren.push (x := s4510) b4510 <|
    PetersenLocalChildren.push (x := s4511) b4511 <|
    PetersenLocalChildren.push (x := s4512) b4512 <|
    PetersenLocalChildren.push (x := s4513) b4513 <|
    PetersenLocalChildren.push (x := s4514) b4514 <|
    PetersenLocalChildren.push (x := s4515) b4515 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4516) b4516 <|
    PetersenLocalChildren.push (x := s4517) b4517 <|
    PetersenLocalChildren.push (x := s4518) b4518 <|
    PetersenLocalChildren.push (x := s4519) b4519 <|
    PetersenLocalChildren.push (x := s4520) b4520 <|
    PetersenLocalChildren.push (x := s4521) b4521 <|
    PetersenLocalChildren.nil
theorem b4581 : Blocked tgt 8 s4581 := by
  apply PetersenFastNode.node (nxt := #[s3331,s4028,s4582,s4247,s4583,s4584,s4585,s607,s4586,s4587,s4452,s4588,s4589,s2270,s4590,s4591,s4592,s4593,s572,s4594,s4595,s4543,s4596,s4597,s4598,s4599,s4600,s4601,s4602,s4603,s4604,s4605,s4606,s4607,s4608]) (hints := [6871,6871,6999,808,5581,936,6999,5581,6999,6871,6871,936,5581,5581,5965,9836,6871,9964,5965,6871,5965,5581,5581,9964,6613,6613,7509,4557,5581,0,7509,5581,7509,6613,6613,1,5581,5581,7501,4565,6613,2728,7501,6613,7501,5581,5581,2728,9709,9709,13677,1485,5581,13548,13677,5581,13677,9709,9709,13548,2743,2743,2,5581,5581,3,5581,5581,4,10741,2743,5,5581,5581,13645,1517,9709,8872,13645,9709,13645,5581,5581,8872,9708,9708,9964,936,936,5965,9964,936,9964,9708,9708,5965,936,936,7767,8684,9708,7509,9700,9708,7767,936,936,7509,936,936,2728,4951,6999,7501,2728,6999,2728,936,936,7501,936,936,13548,6999,6999,13677,13548,6999,13548,936,936,13677,936,936,6,9708,9708,7,9708,9708,8,936,936,9,936,936,8872,1516,9708,13645,8872,9708,8872,936,936,13645,6997,6997,7509,9964,9964,7767,9956,9964,7509,9956,6997,7767,9964,9964,11500,2728,6997,2728,11500,6997,11500,9964,9964,2728,9964,9964,13548,1869,5965,10,13548,5965,13548,9964,9964,11,8932,11125,12,9964,9964,13,9964,9964,14,11125,11125,15,1708,1708,13645,1772,9964,8872,9900,9964,13645,1708,1708,8872,2728,5703,2728,10476,7509,11500,2728,7509,2728,11492,5703,11500,12516,16,12516,12524,7509,13548,12516,7509,12516,13540,17,13548,1704,7509,18,1704,19,20,8872,7509,8872,12621,21,13645,8872,22,8872,7509,7509,13645,2728,2728,13548,3405,7501,23,13548,7501,13548,2728,2728,24,2728,2728,25,11500,11500,26,11500,11500,27,2728,2728,28,2728,2728,8872,3308,11500,14677,8872,11500,8872,2728,2728,14677,4776,13548,18,4776,29,30,8872,5292,8872,5356,13548,13645,8872,13548,8872,5292,5292,13645,8872,31,8872,13645,32,13645,8872,33,8872,13645,34,13645]) (by decide +kernel)
  change ∀ b ∈ [s3331,s4028,s4582,s4247,s4583,s4584,s4585,s607,s4586,s4587,s4452,s4588,s4589,s2270,s4590,s4591,s4592,s4593,s572,s4594,s4595,s4543,s4596,s4597,s4598,s4599,s4600,s4601,s4602,s4603,s4604,s4605,s4606,s4607,s4608], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3331) b3331 <|
    PetersenLocalChildren.push (x := s4028) b4028 <|
    PetersenLocalChildren.push (x := s4582) b4582 <|
    PetersenLocalChildren.push (x := s4247) b4247 <|
    PetersenLocalChildren.push (x := s4583) b4583 <|
    PetersenLocalChildren.push (x := s4584) b4584 <|
    PetersenLocalChildren.push (x := s4585) b4585 <|
    PetersenLocalChildren.push (x := s607) b607 <|
    PetersenLocalChildren.push (x := s4586) b4586 <|
    PetersenLocalChildren.push (x := s4587) b4587 <|
    PetersenLocalChildren.push (x := s4452) b4452 <|
    PetersenLocalChildren.push (x := s4588) b4588 <|
    PetersenLocalChildren.push (x := s4589) b4589 <|
    PetersenLocalChildren.push (x := s2270) b2270 <|
    PetersenLocalChildren.push (x := s4590) b4590 <|
    PetersenLocalChildren.push (x := s4591) b4591 <|
    PetersenLocalChildren.push (x := s4592) b4592 <|
    PetersenLocalChildren.push (x := s4593) b4593 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s4594) b4594 <|
    PetersenLocalChildren.push (x := s4595) b4595 <|
    PetersenLocalChildren.push (x := s4543) b4543 <|
    PetersenLocalChildren.push (x := s4596) b4596 <|
    PetersenLocalChildren.push (x := s4597) b4597 <|
    PetersenLocalChildren.push (x := s4598) b4598 <|
    PetersenLocalChildren.push (x := s4599) b4599 <|
    PetersenLocalChildren.push (x := s4600) b4600 <|
    PetersenLocalChildren.push (x := s4601) b4601 <|
    PetersenLocalChildren.push (x := s4602) b4602 <|
    PetersenLocalChildren.push (x := s4603) b4603 <|
    PetersenLocalChildren.push (x := s4604) b4604 <|
    PetersenLocalChildren.push (x := s4605) b4605 <|
    PetersenLocalChildren.push (x := s4606) b4606 <|
    PetersenLocalChildren.push (x := s4607) b4607 <|
    PetersenLocalChildren.push (x := s4608) b4608 <|
    PetersenLocalChildren.nil
theorem b4651 : Blocked tgt 8 s4651 := by
  apply PetersenFastNode.node (nxt := #[s3333,s4090,s4261,s4652,s4653,s4264,s4654,s4655,s4656,s611,s4657,s4658,s4418,s4659,s4468,s4660,s4661,s2274,s4662,s4663,s4664,s4665,s4508,s4666,s4667,s4668,s4669,s4670,s572,s4671,s4672,s4673,s4674,s4675,s4676,s4677,s4678,s4679,s4680,s4681,s4606,s4682,s4683,s4684,s4685]) (hints := [6881,6881,7009,818,5591,946,7009,5591,7009,6881,6881,946,5591,5591,5975,9846,6881,9974,5975,6881,5975,5591,5591,9974,10751,10751,11647,4567,5591,0,11647,5591,11647,10751,10751,1,5591,5591,7511,8703,10751,2738,7511,10751,7511,5591,5591,2738,9719,9719,13687,1495,5591,4786,13687,5591,13687,9719,9719,4786,5591,5591,13655,1527,9719,2,13655,9719,13655,5591,5591,3,6881,6881,4,5591,5591,5,5591,5591,6,6623,6881,7,9718,9718,9974,946,946,5975,9974,946,9974,9718,9718,5975,946,946,11389,8694,9718,11647,9710,9718,11389,946,946,11647,946,946,2738,4961,7009,7511,2738,7009,2738,946,946,7511,946,946,4786,2913,7009,13687,4786,7009,4786,946,946,13687,946,946,13397,1526,9718,13655,9654,9718,13397,946,946,13655,946,946,8,9718,9718,9,9718,9718,10,946,946,11,8942,8942,11647,8950,9974,12,9966,9974,11647,8942,8942,13,9974,9974,11510,2738,7007,2738,11510,7007,11510,9974,9974,2738,9974,9974,13558,4786,5975,4786,13558,5975,13558,9974,9974,4786,1718,1718,13655,1782,9974,14,9910,9974,13655,1718,1718,15,7007,7007,16,9974,9974,17,9974,9974,18,7007,7007,19,2738,20,2738,10486,11647,11510,2738,11647,2738,11502,21,11510,4786,11647,4786,12534,22,13558,4786,23,4786,13550,11647,13558,3455,24,25,3455,11647,13655,11647,11647,26,13655,27,13655,1714,11647,28,1714,29,30,2738,2738,4786,3415,7511,14719,4786,7511,4786,2738,2738,14719,2738,2738,13655,3318,11510,31,11446,11510,13655,2738,2738,32,2738,2738,33,11510,11510,34,11510,11510,35,2738,2738,36,4786,4786,37,5366,13558,13655,13494,13558,38,4786,4786,13655,4786,4786,39,13558,13558,40,13558,13558,41,4786,4786,42,8882,13655,28,8882,43,44]) (by decide +kernel)
  change ∀ b ∈ [s3333,s4090,s4261,s4652,s4653,s4264,s4654,s4655,s4656,s611,s4657,s4658,s4418,s4659,s4468,s4660,s4661,s2274,s4662,s4663,s4664,s4665,s4508,s4666,s4667,s4668,s4669,s4670,s572,s4671,s4672,s4673,s4674,s4675,s4676,s4677,s4678,s4679,s4680,s4681,s4606,s4682,s4683,s4684,s4685], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3333) b3333 <|
    PetersenLocalChildren.push (x := s4090) b4090 <|
    PetersenLocalChildren.push (x := s4261) b4261 <|
    PetersenLocalChildren.push (x := s4652) b4652 <|
    PetersenLocalChildren.push (x := s4653) b4653 <|
    PetersenLocalChildren.push (x := s4264) b4264 <|
    PetersenLocalChildren.push (x := s4654) b4654 <|
    PetersenLocalChildren.push (x := s4655) b4655 <|
    PetersenLocalChildren.push (x := s4656) b4656 <|
    PetersenLocalChildren.push (x := s611) b611 <|
    PetersenLocalChildren.push (x := s4657) b4657 <|
    PetersenLocalChildren.push (x := s4658) b4658 <|
    PetersenLocalChildren.push (x := s4418) b4418 <|
    PetersenLocalChildren.push (x := s4659) b4659 <|
    PetersenLocalChildren.push (x := s4468) b4468 <|
    PetersenLocalChildren.push (x := s4660) b4660 <|
    PetersenLocalChildren.push (x := s4661) b4661 <|
    PetersenLocalChildren.push (x := s2274) b2274 <|
    PetersenLocalChildren.push (x := s4662) b4662 <|
    PetersenLocalChildren.push (x := s4663) b4663 <|
    PetersenLocalChildren.push (x := s4664) b4664 <|
    PetersenLocalChildren.push (x := s4665) b4665 <|
    PetersenLocalChildren.push (x := s4508) b4508 <|
    PetersenLocalChildren.push (x := s4666) b4666 <|
    PetersenLocalChildren.push (x := s4667) b4667 <|
    PetersenLocalChildren.push (x := s4668) b4668 <|
    PetersenLocalChildren.push (x := s4669) b4669 <|
    PetersenLocalChildren.push (x := s4670) b4670 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s4671) b4671 <|
    PetersenLocalChildren.push (x := s4672) b4672 <|
    PetersenLocalChildren.push (x := s4673) b4673 <|
    PetersenLocalChildren.push (x := s4674) b4674 <|
    PetersenLocalChildren.push (x := s4675) b4675 <|
    PetersenLocalChildren.push (x := s4676) b4676 <|
    PetersenLocalChildren.push (x := s4677) b4677 <|
    PetersenLocalChildren.push (x := s4678) b4678 <|
    PetersenLocalChildren.push (x := s4679) b4679 <|
    PetersenLocalChildren.push (x := s4680) b4680 <|
    PetersenLocalChildren.push (x := s4681) b4681 <|
    PetersenLocalChildren.push (x := s4606) b4606 <|
    PetersenLocalChildren.push (x := s4682) b4682 <|
    PetersenLocalChildren.push (x := s4683) b4683 <|
    PetersenLocalChildren.push (x := s4684) b4684 <|
    PetersenLocalChildren.push (x := s4685) b4685 <|
    PetersenLocalChildren.nil
theorem b4687 : Blocked tgt 8 s4687 := by
  apply PetersenFastNode.node (nxt := #[s4688,s4689,s4265,s4690,s4691,s4692,s4358,s4693,s4694,s4695,s4471,s4696,s4697,s4698,s4699,s4700,s4701,s4702,s4703,s4704,s4705,s4706,s4707,s4708,s4709,s4638,s4710,s572,s4711,s4684,s3334,s4139,s4419,s4712,s4713,s4714,s4509,s4715,s4716,s4717,s4718]) (hints := [9715,0,9715,5587,1,5587,9715,2,9715,5587,3,5587,942,4,942,1458,5,1458,942,6,942,1458,7,1458,9970,8,9970,1714,9,1714,9970,10,9970,1714,11,1714,11643,12,11643,13,14,15,1710,16,11643,1710,17,18,2734,19,2734,3250,20,3250,2734,21,2734,3250,22,3250,4782,23,4782,5298,24,5298,4782,25,4782,5298,26,5298,8878,27,8878,13651,28,29,5329,5329,7005,5331,5587,1458,5585,5587,7005,5329,5329,1458,5587,5587,5971,1586,6877,1714,5971,6877,5971,5587,5587,1714,4563,10747,11643,4563,5587,30,5587,5587,11643,10747,10747,31,5587,5587,7507,3122,10747,3250,7507,10747,7507,5587,5587,3250,1459,1459,13683,1491,5587,5298,5555,5587,13683,1459,1459,5298,5587,5587,14683,9715,9715,8878,9715,9715,14683,5587,5587,8878,1458,1458,1714,5715,942,5971,1714,942,1714,1458,1458,5971,426,426,11385,434,1458,11643,1450,1458,11385,426,426,11643,1458,1458,3250,7251,7005,7507,3250,7005,3250,1458,1458,7507,1458,1458,5298,2909,7005,13683,5298,7005,5298,1458,1458,13683,1458,1458,8878,9714,9714,14683,8878,9714,8878,1458,1458,14683,8938,8938,11643,1714,1714,32,1706,1714,11643,1706,8938,33,1714,1714,3250,2734,7003,2734,3250,7003,3250,1714,1714,2734,1714,1714,5298,1875,5971,4782,5298,5971,5298,1714,1714,4782,1714,1714,14683,9970,9970,8878,9970,9970,14683,1714,1714,8878,2218,34,2218,2226,11643,3250,2218,11643,2218,3242,35,3250,4266,11643,4266,4274,36,5298,4266,37,4266,5290,11643,5298,8878,18,8878,11643,11643,38,8878,11643,8878,9902,39,40,3250,3250,5298,3411,7507,14715,5298,7507,5298,3250,3250,14715,3250,3250,8878,11506,11506,14683,8878,11506,8878,3250,3250,14683,5298,5298,8878,13554,13554,14683,8878,13554,8878,5298,5298,14683]) (by decide +kernel)
  change ∀ b ∈ [s4688,s4689,s4265,s4690,s4691,s4692,s4358,s4693,s4694,s4695,s4471,s4696,s4697,s4698,s4699,s4700,s4701,s4702,s4703,s4704,s4705,s4706,s4707,s4708,s4709,s4638,s4710,s572,s4711,s4684,s3334,s4139,s4419,s4712,s4713,s4714,s4509,s4715,s4716,s4717,s4718], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4688) b4688 <|
    PetersenLocalChildren.push (x := s4689) b4689 <|
    PetersenLocalChildren.push (x := s4265) b4265 <|
    PetersenLocalChildren.push (x := s4690) b4690 <|
    PetersenLocalChildren.push (x := s4691) b4691 <|
    PetersenLocalChildren.push (x := s4692) b4692 <|
    PetersenLocalChildren.push (x := s4358) b4358 <|
    PetersenLocalChildren.push (x := s4693) b4693 <|
    PetersenLocalChildren.push (x := s4694) b4694 <|
    PetersenLocalChildren.push (x := s4695) b4695 <|
    PetersenLocalChildren.push (x := s4471) b4471 <|
    PetersenLocalChildren.push (x := s4696) b4696 <|
    PetersenLocalChildren.push (x := s4697) b4697 <|
    PetersenLocalChildren.push (x := s4698) b4698 <|
    PetersenLocalChildren.push (x := s4699) b4699 <|
    PetersenLocalChildren.push (x := s4700) b4700 <|
    PetersenLocalChildren.push (x := s4701) b4701 <|
    PetersenLocalChildren.push (x := s4702) b4702 <|
    PetersenLocalChildren.push (x := s4703) b4703 <|
    PetersenLocalChildren.push (x := s4704) b4704 <|
    PetersenLocalChildren.push (x := s4705) b4705 <|
    PetersenLocalChildren.push (x := s4706) b4706 <|
    PetersenLocalChildren.push (x := s4707) b4707 <|
    PetersenLocalChildren.push (x := s4708) b4708 <|
    PetersenLocalChildren.push (x := s4709) b4709 <|
    PetersenLocalChildren.push (x := s4638) b4638 <|
    PetersenLocalChildren.push (x := s4710) b4710 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s4711) b4711 <|
    PetersenLocalChildren.push (x := s4684) b4684 <|
    PetersenLocalChildren.push (x := s3334) b3334 <|
    PetersenLocalChildren.push (x := s4139) b4139 <|
    PetersenLocalChildren.push (x := s4419) b4419 <|
    PetersenLocalChildren.push (x := s4712) b4712 <|
    PetersenLocalChildren.push (x := s4713) b4713 <|
    PetersenLocalChildren.push (x := s4714) b4714 <|
    PetersenLocalChildren.push (x := s4509) b4509 <|
    PetersenLocalChildren.push (x := s4715) b4715 <|
    PetersenLocalChildren.push (x := s4716) b4716 <|
    PetersenLocalChildren.push (x := s4717) b4717 <|
    PetersenLocalChildren.push (x := s4718) b4718 <|
    PetersenLocalChildren.nil
theorem b4793 : Blocked tgt 8 s4793 := by
  apply PetersenFastNode.node (nxt := #[s4794,s4795,s4796,s4797,s3896,s4798,s3894,s3395,s4799,s4800,s4801,s4802,s4803,s965,s4804,s4805,s4806,s4807,s3900,s2941,s3882,s3404,s4808,s4809,s4810,s4071,s4811,s4042,s4812,s4813,s4814,s4779,s4815,s4816,s941,s4817,s3860,s4818,s4819,s4820,s4821]) (hints := [6877,6877,7005,814,4563,942,7005,4563,7005,6877,6877,942,4563,4563,5971,6877,6877,0,5971,6877,5971,4563,4563,1,7515,6877,7515,4563,4563,1710,6619,4563,7515,6619,6877,1710,4563,4563,7507,4829,6877,2734,6611,6877,7507,4563,4563,2734,467,2749,2,467,4563,12522,4563,4563,3,2749,2749,12522,2749,2749,4,4563,4563,5,4563,4563,6,8691,2749,7,4563,4563,13651,8750,8,8878,12755,9,13651,4563,4563,8878,8682,8682,5713,942,942,5971,942,942,5713,8682,8682,5971,942,942,1710,8682,8682,7515,1710,8682,1710,942,942,7515,942,942,2734,4957,7005,7507,2734,7005,2734,942,942,7507,942,942,12522,7005,7005,10,12522,7005,12522,942,942,11,942,942,12,8682,8682,13,8682,8682,14,942,942,15,942,942,8878,490,8682,13651,8878,8682,8878,942,942,13651,7003,7003,7515,1710,5971,1710,7515,5971,7515,1710,7003,1710,10474,5971,10474,2734,7003,2734,10474,7003,10474,2734,5971,2734,12522,10099,12522,5971,5971,16,12522,5971,12522,14058,10099,17,9962,10099,18,9962,5971,19,5971,5971,20,10099,10099,21,5971,5971,13651,8878,10099,8878,13651,10099,13651,8878,5971,8878,1710,1710,2734,10474,7515,10474,2734,7515,2734,1710,1710,10474,1710,1710,22,12522,7515,12522,7515,7515,23,1710,1710,12522,1710,1710,24,7515,7515,25,7515,7515,26,1710,1710,27,1710,1710,8878,3451,11643,13651,8878,11643,8878,1710,1710,13651,2734,2734,12522,7507,7507,28,12522,7507,12522,2734,2734,29,2734,2734,30,10474,10474,31,10474,10474,32,2734,2734,33,2734,2734,8878,2282,10474,14683,8878,10474,8878,2734,2734,14683,4782,12522,34,4782,35,36,8878,4266,8878,4330,12522,13651,8878,12522,8878,4266,4266,13651,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651]) (by decide +kernel)
  change ∀ b ∈ [s4794,s4795,s4796,s4797,s3896,s4798,s3894,s3395,s4799,s4800,s4801,s4802,s4803,s965,s4804,s4805,s4806,s4807,s3900,s2941,s3882,s3404,s4808,s4809,s4810,s4071,s4811,s4042,s4812,s4813,s4814,s4779,s4815,s4816,s941,s4817,s3860,s4818,s4819,s4820,s4821], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4794) b4794 <|
    PetersenLocalChildren.push (x := s4795) b4795 <|
    PetersenLocalChildren.push (x := s4796) b4796 <|
    PetersenLocalChildren.push (x := s4797) b4797 <|
    PetersenLocalChildren.push (x := s3896) b3896 <|
    PetersenLocalChildren.push (x := s4798) b4798 <|
    PetersenLocalChildren.push (x := s3894) b3894 <|
    PetersenLocalChildren.push (x := s3395) b3395 <|
    PetersenLocalChildren.push (x := s4799) b4799 <|
    PetersenLocalChildren.push (x := s4800) b4800 <|
    PetersenLocalChildren.push (x := s4801) b4801 <|
    PetersenLocalChildren.push (x := s4802) b4802 <|
    PetersenLocalChildren.push (x := s4803) b4803 <|
    PetersenLocalChildren.push (x := s965) b965 <|
    PetersenLocalChildren.push (x := s4804) b4804 <|
    PetersenLocalChildren.push (x := s4805) b4805 <|
    PetersenLocalChildren.push (x := s4806) b4806 <|
    PetersenLocalChildren.push (x := s4807) b4807 <|
    PetersenLocalChildren.push (x := s3900) b3900 <|
    PetersenLocalChildren.push (x := s2941) b2941 <|
    PetersenLocalChildren.push (x := s3882) b3882 <|
    PetersenLocalChildren.push (x := s3404) b3404 <|
    PetersenLocalChildren.push (x := s4808) b4808 <|
    PetersenLocalChildren.push (x := s4809) b4809 <|
    PetersenLocalChildren.push (x := s4810) b4810 <|
    PetersenLocalChildren.push (x := s4071) b4071 <|
    PetersenLocalChildren.push (x := s4811) b4811 <|
    PetersenLocalChildren.push (x := s4042) b4042 <|
    PetersenLocalChildren.push (x := s4812) b4812 <|
    PetersenLocalChildren.push (x := s4813) b4813 <|
    PetersenLocalChildren.push (x := s4814) b4814 <|
    PetersenLocalChildren.push (x := s4779) b4779 <|
    PetersenLocalChildren.push (x := s4815) b4815 <|
    PetersenLocalChildren.push (x := s4816) b4816 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4817) b4817 <|
    PetersenLocalChildren.push (x := s3860) b3860 <|
    PetersenLocalChildren.push (x := s4818) b4818 <|
    PetersenLocalChildren.push (x := s4819) b4819 <|
    PetersenLocalChildren.push (x := s4820) b4820 <|
    PetersenLocalChildren.push (x := s4821) b4821 <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i0 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4830,s4831,s4832,s4833]) (hints := [6840,6840,6968,0,777,462,905,1,6968,462,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4830,s4831,s4832,s4833], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4830) (b4830) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4831) (b4831) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4832) (b4832) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4833) (b4833) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i1 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4834,s4835,s4836,s4837]) (hints := [5934,462,5934,0,9733,6840,9861,1,5934,6840,5934,2,6062,462,9861,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4834,s4835,s4836,s4837], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4834) (b4834) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4835) (b4835) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4836) (b4836) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4837) (b4837) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i2 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4838,s4839,s4840,s4841]) (hints := [7478,6840,7478,0,462,462,1673,1,7478,462,7478,2,2518,6840,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4838,s4839,s4840,s4841], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4838) (b4838) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4839) (b4839) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4840) (b4840) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4841) (b4841) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i3 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4842,s4843,s4844,s4845]) (hints := [7470,462,7470,0,4792,6840,2697,1,7470,6840,7470,2,462,462,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4842,s4843,s4844,s4845], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4842) (b4842) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4843) (b4843) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4844) (b4844) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4845) (b4845) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i4 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4846,s4847,s4848,s4849]) (hints := [462,462,13646,0,2744,6840,4745,1,4558,6840,13646,2,462,462,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4846,s4847,s4848,s4849], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4846) (b4846) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4847) (b4847) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4848) (b4848) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4849) (b4849) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i5 : PetersenLocalChildren.PairOK tgt 7 s4829 (word3,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4850,s4851,s4852,s4853]) (hints := [13614,6840,13614,0,462,462,8841,1,4526,462,13614,2,4526,6840,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4850,s4851,s4852,s4853], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4850) (b4850) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4851) (b4851) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4852) (b4852) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4853) (b4853) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i6 : PetersenLocalChildren.PairOK tgt 7 s4829 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4854,s4855,s4856,s4857]) (hints := [389,389,9861,0,905,905,5934,1,9861,905,9861,2,389,389,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4854,s4855,s4856,s4857], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4854) (b4854) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4855) (b4855) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4856) (b4856) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4857) (b4857) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i7 : PetersenLocalChildren.PairOK tgt 7 s4829 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4858,s4859,s4860,s4861]) (hints := [905,905,1673,0,389,389,7478,1,1673,389,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4858,s4859,s4860,s4861], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4858) (b4858) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4859) (b4859) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4860) (b4860) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4861) (b4861) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i8 : PetersenLocalChildren.PairOK tgt 7 s4829 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4862,s4863,s4864,s4865]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4862,s4863,s4864,s4865], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4862) (b4862) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4863) (b4863) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4864) (b4864) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4865) (b4865) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i9 : PetersenLocalChildren.PairOK tgt 7 s4829 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4866,s4867,s4868,s4869]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4866,s4867,s4868,s4869], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4866) (b4866) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4867) (b4867) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4868) (b4868) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4869) (b4869) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i10 : PetersenLocalChildren.PairOK tgt 7 s4829 (word1,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4870,s4871,s4872,s4873]) (hints := [905,905,8841,0,389,389,13614,1,8841,389,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4870,s4871,s4872,s4873], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4870) (b4870) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4871) (b4871) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4872) (b4872) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4873) (b4873) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i11 : PetersenLocalChildren.PairOK tgt 7 s4829 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4874,s4875,s4876,s4877]) (hints := [8837,6966,7478,0,8837,9861,1673,1,9861,9861,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4874,s4875,s4876,s4877], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4874) (b4874) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4875) (b4875) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4876) (b4876) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4877) (b4877) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i12 : PetersenLocalChildren.PairOK tgt 7 s4829 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4878,s4879,s4880,s4881]) (hints := [2181,9861,2181,0,2697,6966,2697,1,2181,6966,2181,2,9861,9861,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4878,s4879,s4880,s4881], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4878) (b4878) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4879) (b4879) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4880) (b4880) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4881) (b4881) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i13 : PetersenLocalChildren.PairOK tgt 7 s4829 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4882,s4883,s4884,s4885]) (hints := [4229,9861,4229,0,4745,5934,4745,1,4229,5934,4229,2,9861,9861,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4882,s4883,s4884,s4885], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4882) (b4882) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4883) (b4883) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4884) (b4884) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4885) (b4885) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i14 : PetersenLocalChildren.PairOK tgt 7 s4829 (word0,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4886,s4887,s4888,s4889]) (hints := [1669,5934,13614,0,1669,9861,8841,1,9861,9861,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4886,s4887,s4888,s4889], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4886) (b4886) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4887) (b4887) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4888) (b4888) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4889) (b4889) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i15 : PetersenLocalChildren.PairOK tgt 7 s4829 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4890,s4891,s4892,s4893]) (hints := [1673,1673,2697,0,2181,7478,2181,1,2697,7478,2697,2,1673,1673,2181,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4890,s4891,s4892,s4893], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4890) (b4890) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4891) (b4891) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4892) (b4892) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4893) (b4893) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i16 : PetersenLocalChildren.PairOK tgt 7 s4829 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4894,s4895,s4896,s4897]) (hints := [1673,1673,4745,0,4229,7478,4229,1,4745,7478,4745,2,1673,1673,4229,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4894,s4895,s4896,s4897], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4894) (b4894) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4895) (b4895) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4896) (b4896) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4897) (b4897) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i17 : PetersenLocalChildren.PairOK tgt 7 s4829 (word14,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4898,s4899,s4900,s4901]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4898,s4899,s4900,s4901], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4898) (b4898) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4899) (b4899) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4900) (b4900) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4901) (b4901) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i18 : PetersenLocalChildren.PairOK tgt 7 s4829 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4902,s4903,s4904,s4905]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4902,s4903,s4904,s4905], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4902) (b4902) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4903) (b4903) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4904) (b4904) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4905) (b4905) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i19 : PetersenLocalChildren.PairOK tgt 7 s4829 (word5,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4906,s4907,s4908,s4909]) (hints := [2697,2697,8841,0,2181,2181,14646,1,8841,2181,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4906,s4907,s4908,s4909], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4906) (b4906) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4907) (b4907) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4908) (b4908) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4909) (b4909) <|
    PetersenLocalChildren.nil
private theorem thetaPair4829i20 : PetersenLocalChildren.PairOK tgt 7 s4829 (word2,word15) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4910,s4911,s4912,s4913]) (hints := [4745,4745,8841,0,4229,4229,13614,1,8841,4229,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4910,s4911,s4912,s4913], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4910) (b4910) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4911) (b4911) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4912) (b4912) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4913) (b4913) <|
    PetersenLocalChildren.nil
theorem b4829 : Blocked tgt 8 s4829 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word14),(word3,word5),(word3,word2),(word3,word15),(word1,word0),(word1,word14),(word1,word5),(word1,word2),(word1,word15),(word0,word14),(word0,word5),(word0,word2),(word0,word15),(word14,word5),(word14,word2),(word14,word15),(word5,word2),(word5,word15),(word2,word15)], PetersenLocalChildren.PairOK tgt 7 s4829 p
  exact
    PetersenLocalChildren.push thetaPair4829i0 <|
    PetersenLocalChildren.push thetaPair4829i1 <|
    PetersenLocalChildren.push thetaPair4829i2 <|
    PetersenLocalChildren.push thetaPair4829i3 <|
    PetersenLocalChildren.push thetaPair4829i4 <|
    PetersenLocalChildren.push thetaPair4829i5 <|
    PetersenLocalChildren.push thetaPair4829i6 <|
    PetersenLocalChildren.push thetaPair4829i7 <|
    PetersenLocalChildren.push thetaPair4829i8 <|
    PetersenLocalChildren.push thetaPair4829i9 <|
    PetersenLocalChildren.push thetaPair4829i10 <|
    PetersenLocalChildren.push thetaPair4829i11 <|
    PetersenLocalChildren.push thetaPair4829i12 <|
    PetersenLocalChildren.push thetaPair4829i13 <|
    PetersenLocalChildren.push thetaPair4829i14 <|
    PetersenLocalChildren.push thetaPair4829i15 <|
    PetersenLocalChildren.push thetaPair4829i16 <|
    PetersenLocalChildren.push thetaPair4829i17 <|
    PetersenLocalChildren.push thetaPair4829i18 <|
    PetersenLocalChildren.push thetaPair4829i19 <|
    PetersenLocalChildren.push thetaPair4829i20 <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i0 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4953,s4954,s4955,s4956]) (hints := [6840,6840,6968,0,777,4526,905,1,6968,4526,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4953,s4954,s4955,s4956], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4953) (b4953) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4954) (b4954) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4955) (b4955) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4956) (b4956) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i1 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4957,s4958,s4959,s4960]) (hints := [10062,4526,10062,0,1541,6840,1669,1,10062,6840,10062,2,10190,4526,1669,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4957,s4958,s4959,s4960], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4957) (b4957) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4958) (b4958) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4959) (b4959) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4960) (b4960) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i2 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4961,s4962,s4963,s4964,s4965,s4966]) (hints := [4528,4528,13616,0,464,1,8843,2,13616,3,13616,4,4528,4528,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s4961,s4962,s4963,s4964,s4965,s4966], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4961) (b4961) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4962) (b4962) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4963) (b4963) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4964) (b4964) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4965) (b4965) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4966) (b4966) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i3 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4967,s4968,s4969,s4970]) (hints := [11606,6840,11606,0,4526,4526,1673,1,11606,4526,11606,2,6582,6840,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4967,s4968,s4969,s4970], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4967) (b4967) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4968) (b4968) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4969) (b4969) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4970) (b4970) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i4 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4971,s4972,s4973,s4974]) (hints := [11598,4526,11598,0,4792,6840,2697,1,11598,6840,11598,2,4526,4526,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4971,s4972,s4973,s4974], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4971) (b4971) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4972) (b4972) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4973) (b4973) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4974) (b4974) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i5 : PetersenLocalChildren.PairOK tgt 7 s4952 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4975,s4976,s4977,s4978]) (hints := [13646,398,13646,0,430,4526,4745,1,13646,4526,13646,2,398,398,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4975,s4976,s4977,s4978], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4975) (b4975) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4976) (b4976) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4977) (b4977) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4978) (b4978) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i6 : PetersenLocalChildren.PairOK tgt 7 s4952 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4979,s4980,s4981,s4982]) (hints := [389,389,1669,0,905,905,10062,1,1669,905,1669,2,389,389,10062,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4979,s4980,s4981,s4982], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4979) (b4979) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4980) (b4980) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4981) (b4981) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4982) (b4982) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i7 : PetersenLocalChildren.PairOK tgt 7 s4952 (word1,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4983,s4984,s4985,s4986,s4987,s4988]) (hints := [907,907,8843,0,13360,1,13616,2,8843,3,8843,4,907,907,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s4983,s4984,s4985,s4986,s4987,s4988], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4983) (b4983) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4984) (b4984) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4985) (b4985) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4986) (b4986) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4987) (b4987) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4988) (b4988) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i8 : PetersenLocalChildren.PairOK tgt 7 s4952 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4989,s4990,s4991,s4992]) (hints := [905,905,1673,0,389,389,11606,1,1673,389,1673,2,905,905,11606,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4989,s4990,s4991,s4992], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4989) (b4989) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4990) (b4990) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4991) (b4991) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4992) (b4992) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i9 : PetersenLocalChildren.PairOK tgt 7 s4952 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4993,s4994,s4995,s4996]) (hints := [905,905,2697,0,4920,6968,11598,1,2697,6968,2697,2,905,905,11598,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4993,s4994,s4995,s4996], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4993) (b4993) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4994) (b4994) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4995) (b4995) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4996) (b4996) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i10 : PetersenLocalChildren.PairOK tgt 7 s4952 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4997,s4998,s4999,s5000]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4997,s4998,s4999,s5000], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4997) (b4997) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4998) (b4998) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4999) (b4999) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5000) (b5000) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i11 : PetersenLocalChildren.PairOK tgt 7 s4952 (word0,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5001,s5002,s5003,s5004]) (hints := [1669,1669,13614,0,8841,10062,8841,1,9861,10062,13614,2,1669,1669,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5001,s5002,s5003,s5004], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5001) (b5001) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5002) (b5002) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5003) (b5003) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5004) (b5004) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i12 : PetersenLocalChildren.PairOK tgt 7 s4952 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5005,s5006,s5007,s5008]) (hints := [11094,11094,11606,0,1669,1669,1673,1,1669,1669,11606,2,1673,11094,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5005,s5006,s5007,s5008], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5005) (b5005) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5006) (b5006) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5007) (b5007) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5008) (b5008) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i13 : PetersenLocalChildren.PairOK tgt 7 s4952 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5009,s5010,s5011,s5012]) (hints := [1669,1669,2181,0,2697,11094,2697,1,2181,11094,2181,2,1669,1669,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5009,s5010,s5011,s5012], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5009) (b5009) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5010) (b5010) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5011) (b5011) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5012) (b5012) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i14 : PetersenLocalChildren.PairOK tgt 7 s4952 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5013,s5014,s5015,s5016]) (hints := [1669,1669,4229,0,4745,5934,4745,1,4229,5934,4229,2,1669,1669,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5013,s5014,s5015,s5016], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5013) (b5013) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5014) (b5014) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5015) (b5015) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5016) (b5016) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i15 : PetersenLocalChildren.PairOK tgt 7 s4952 (word26,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5017,s5018,s5019,s5020]) (hints := [1673,8841,1673,0,3414,13614,11606,1,1673,13614,1673,2,8841,8841,11606,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5017,s5018,s5019,s5020], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5017) (b5017) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5018) (b5018) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5019) (b5019) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5020) (b5020) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i16 : PetersenLocalChildren.PairOK tgt 7 s4952 (word26,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5021,s5022,s5023,s5024]) (hints := [2697,8841,2697,0,3406,14646,11598,1,2697,14646,2697,2,8841,8841,11598,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5021,s5022,s5023,s5024], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5021) (b5021) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5022) (b5022) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5023) (b5023) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5024) (b5024) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i17 : PetersenLocalChildren.PairOK tgt 7 s4952 (word26,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5025,s5026,s5027,s5028]) (hints := [4745,8841,4745,0,13614,13614,13646,1,4745,13614,4745,2,8841,8841,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5025,s5026,s5027,s5028], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5025) (b5025) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5026) (b5026) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5027) (b5027) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5028) (b5028) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i18 : PetersenLocalChildren.PairOK tgt 7 s4952 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5029,s5030,s5031,s5032]) (hints := [1673,1673,2697,0,2181,11606,2181,1,2697,11606,2697,2,1673,1673,2181,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5029,s5030,s5031,s5032], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5029) (b5029) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5030) (b5030) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5031) (b5031) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5032) (b5032) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i19 : PetersenLocalChildren.PairOK tgt 7 s4952 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5033,s5034,s5035,s5036]) (hints := [1673,1673,4745,0,4229,7478,4229,1,4745,7478,4745,2,1673,1673,4229,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5033,s5034,s5035,s5036], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5033) (b5033) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5034) (b5034) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5035) (b5035) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5036) (b5036) <|
    PetersenLocalChildren.nil
private theorem thetaPair4952i20 : PetersenLocalChildren.PairOK tgt 7 s4952 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5037,s5038,s5039,s5040]) (hints := [2697,2697,4745,0,12630,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5037,s5038,s5039,s5040], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5037) (b5037) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5038) (b5038) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5039) (b5039) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5040) (b5040) <|
    PetersenLocalChildren.nil
theorem b4952 : Blocked tgt 8 s4952 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word26),(word3,word14),(word3,word5),(word3,word2),(word1,word0),(word1,word26),(word1,word14),(word1,word5),(word1,word2),(word0,word26),(word0,word14),(word0,word5),(word0,word2),(word26,word14),(word26,word5),(word26,word2),(word14,word5),(word14,word2),(word5,word2)], PetersenLocalChildren.PairOK tgt 7 s4952 p
  exact
    PetersenLocalChildren.push thetaPair4952i0 <|
    PetersenLocalChildren.push thetaPair4952i1 <|
    PetersenLocalChildren.push thetaPair4952i2 <|
    PetersenLocalChildren.push thetaPair4952i3 <|
    PetersenLocalChildren.push thetaPair4952i4 <|
    PetersenLocalChildren.push thetaPair4952i5 <|
    PetersenLocalChildren.push thetaPair4952i6 <|
    PetersenLocalChildren.push thetaPair4952i7 <|
    PetersenLocalChildren.push thetaPair4952i8 <|
    PetersenLocalChildren.push thetaPair4952i9 <|
    PetersenLocalChildren.push thetaPair4952i10 <|
    PetersenLocalChildren.push thetaPair4952i11 <|
    PetersenLocalChildren.push thetaPair4952i12 <|
    PetersenLocalChildren.push thetaPair4952i13 <|
    PetersenLocalChildren.push thetaPair4952i14 <|
    PetersenLocalChildren.push thetaPair4952i15 <|
    PetersenLocalChildren.push thetaPair4952i16 <|
    PetersenLocalChildren.push thetaPair4952i17 <|
    PetersenLocalChildren.push thetaPair4952i18 <|
    PetersenLocalChildren.push thetaPair4952i19 <|
    PetersenLocalChildren.push thetaPair4952i20 <|
    PetersenLocalChildren.nil
theorem b5071 : Blocked tgt 8 s5071 := by
  apply PetersenFastNode.node (nxt := #[s5072,s5073,s5074,s2907,s2694,s5075,s5076,s4754,s5077,s5078,s5079,s5080,s5062,s5081,s5082,s5083,s5084,s5085,s5086,s5087,s5088,s5089,s5090]) (hints := [4545,4545,6859,0,1,2,6987,4287,6987,4289,4545,8664,6987,4545,6987,4287,4287,8664,4545,4545,6081,9944,3,4,7755,4545,7755,6601,5,6,4545,4545,7489,10456,7,10456,6593,8,7489,4545,4545,10456,8673,8673,13665,449,4545,12504,12769,4545,13665,8673,8673,12504,14923,4545,14923,481,8673,9,14923,8673,14923,4545,4545,10,8664,6859,8664,6987,11,6987,8664,12,8664,6859,6859,6987,5953,6859,6081,5953,13,14,7497,6859,7497,7755,15,7755,7497,16,7497,6859,6859,7755,10456,4795,10456,6843,6859,17,10456,6859,10456,4795,4795,18,12504,2731,12504,6827,6859,19,12504,6859,12504,2731,2731,20,13633,6859,13633,14923,21,14923,13633,22,13633,6859,6859,14923,8664,8664,5823,6987,6987,6081,6987,6987,5823,8664,8664,6081,6987,6987,7755,8664,8664,7497,8664,8664,7755,6987,6987,7497,8664,8664,10456,4939,6987,7489,10456,6987,10456,8664,8664,7489,8664,8664,12504,2891,6987,13665,12504,6987,12504,8664,8664,13665,408,408,14923,472,8664,13633,8600,8664,14923,408,408,13633,7113,7113,7497,7755,6081,7755,7497,6081,7497,7755,7113,7755,10456,6081,10456,5065,7113,2716,10456,7113,10456,6081,6081,2716,12504,10209,12504,1985,6081,4764,12504,6081,12504,10209,10209,4764,6081,6081,13633,14923,10209,14923,13633,10209,13633,14923,6081,14923,5691,5691,2716,10456,7755,10456,7739,7755,2716,10456,5691,10456,3627,3627,14697,12504,7755,12504,7723,7755,14697,12504,3627,12504,7755,7755,14923,3433,11625,13633,14923,11625,14923,7755,7755,13633,10456,10456,12504,3393,7489,14697,12504,7489,12504,10456,10456,14697,2200,2200,12859,2264,10456,14923,10392,10456,12859,2200,2200,14923,4248,4248,10795,4312,12504,14923,12440,12504,10795,4248,4248,14923]) (by decide +kernel)
  change ∀ b ∈ [s5072,s5073,s5074,s2907,s2694,s5075,s5076,s4754,s5077,s5078,s5079,s5080,s5062,s5081,s5082,s5083,s5084,s5085,s5086,s5087,s5088,s5089,s5090], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5072) b5072 <|
    PetersenLocalChildren.push (x := s5073) b5073 <|
    PetersenLocalChildren.push (x := s5074) b5074 <|
    PetersenLocalChildren.push (x := s2907) b2907 <|
    PetersenLocalChildren.push (x := s2694) b2694 <|
    PetersenLocalChildren.push (x := s5075) b5075 <|
    PetersenLocalChildren.push (x := s5076) b5076 <|
    PetersenLocalChildren.push (x := s4754) b4754 <|
    PetersenLocalChildren.push (x := s5077) b5077 <|
    PetersenLocalChildren.push (x := s5078) b5078 <|
    PetersenLocalChildren.push (x := s5079) b5079 <|
    PetersenLocalChildren.push (x := s5080) b5080 <|
    PetersenLocalChildren.push (x := s5062) b5062 <|
    PetersenLocalChildren.push (x := s5081) b5081 <|
    PetersenLocalChildren.push (x := s5082) b5082 <|
    PetersenLocalChildren.push (x := s5083) b5083 <|
    PetersenLocalChildren.push (x := s5084) b5084 <|
    PetersenLocalChildren.push (x := s5085) b5085 <|
    PetersenLocalChildren.push (x := s5086) b5086 <|
    PetersenLocalChildren.push (x := s5087) b5087 <|
    PetersenLocalChildren.push (x := s5088) b5088 <|
    PetersenLocalChildren.push (x := s5089) b5089 <|
    PetersenLocalChildren.push (x := s5090) b5090 <|
    PetersenLocalChildren.nil
theorem b5094 : Blocked tgt 8 s5094 := by
  apply PetersenFastNode.node (nxt := #[s2909,s2718,s5095,s5096,s5097,s5098,s5099,s5100,s4756,s5101,s5102,s5103,s1140,s5104,s5063,s5105,s5106,s5107,s5108,s5084,s5109,s5110,s5111,s5112,s5113,s5114,s5115,s5116,s5117,s5118,s5119,s5120]) (hints := [933,4296,933,4298,4554,8673,933,4554,933,4296,4296,8673,4554,4554,5962,9825,0,1,4554,4554,1573,2,3,4,4554,4554,6868,5,6,7,4554,4554,7498,10465,8,10465,6602,9,7498,4554,4554,10465,8682,8682,13674,458,4554,12513,12778,4554,13674,8682,8682,12513,4554,4554,13642,490,8682,10,12746,8682,13642,4554,4554,11,8673,8673,5704,5706,933,5962,5704,933,5704,8673,8673,5962,933,933,1573,8673,8673,12,8673,8673,1573,933,933,13,6868,6996,6868,8673,8673,14,8673,8673,6868,6996,6996,15,8673,8673,10465,4948,6996,7498,10465,6996,10465,8673,8673,7498,8673,8673,12513,2900,6996,13674,12513,6996,12513,8673,8673,13674,417,417,8869,481,8673,13642,8609,8673,8869,417,417,13642,5066,6994,16,5066,5962,1573,5962,5962,17,6994,6994,1573,6994,6994,18,5962,5962,6868,5962,5962,19,6994,6994,6868,10465,5962,10465,4946,6994,2725,10465,6994,10465,5962,5962,2725,12513,10090,12513,1866,5962,4773,12513,5962,12513,10090,10090,4773,5962,5962,13642,1898,10090,8869,13642,10090,13642,5962,5962,8869,7506,1573,6868,7506,20,21,1573,1573,2725,10465,22,10465,2725,23,2725,10465,1573,10465,14706,1573,14706,12513,24,12513,14706,25,14706,12513,1573,12513,14674,1573,14674,13642,26,13642,14674,27,14674,13642,1573,13642,4804,4804,28,10465,6868,10465,6852,6868,29,10465,4804,10465,14706,2740,14706,12513,6868,12513,14706,6868,14706,12513,2740,12513,14674,6868,14674,13642,30,13642,14674,31,14674,13642,6868,13642,10465,10465,12513,3402,7498,14706,12513,7498,12513,10465,10465,14706,2209,2209,13642,2273,10465,14674,10401,10465,13642,2209,2209,14674,4257,4257,8869,4321,12513,13642,12449,12513,8869,4257,4257,13642]) (by decide +kernel)
  change ∀ b ∈ [s2909,s2718,s5095,s5096,s5097,s5098,s5099,s5100,s4756,s5101,s5102,s5103,s1140,s5104,s5063,s5105,s5106,s5107,s5108,s5084,s5109,s5110,s5111,s5112,s5113,s5114,s5115,s5116,s5117,s5118,s5119,s5120], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2909) b2909 <|
    PetersenLocalChildren.push (x := s2718) b2718 <|
    PetersenLocalChildren.push (x := s5095) b5095 <|
    PetersenLocalChildren.push (x := s5096) b5096 <|
    PetersenLocalChildren.push (x := s5097) b5097 <|
    PetersenLocalChildren.push (x := s5098) b5098 <|
    PetersenLocalChildren.push (x := s5099) b5099 <|
    PetersenLocalChildren.push (x := s5100) b5100 <|
    PetersenLocalChildren.push (x := s4756) b4756 <|
    PetersenLocalChildren.push (x := s5101) b5101 <|
    PetersenLocalChildren.push (x := s5102) b5102 <|
    PetersenLocalChildren.push (x := s5103) b5103 <|
    PetersenLocalChildren.push (x := s1140) b1140 <|
    PetersenLocalChildren.push (x := s5104) b5104 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s5105) b5105 <|
    PetersenLocalChildren.push (x := s5106) b5106 <|
    PetersenLocalChildren.push (x := s5107) b5107 <|
    PetersenLocalChildren.push (x := s5108) b5108 <|
    PetersenLocalChildren.push (x := s5084) b5084 <|
    PetersenLocalChildren.push (x := s5109) b5109 <|
    PetersenLocalChildren.push (x := s5110) b5110 <|
    PetersenLocalChildren.push (x := s5111) b5111 <|
    PetersenLocalChildren.push (x := s5112) b5112 <|
    PetersenLocalChildren.push (x := s5113) b5113 <|
    PetersenLocalChildren.push (x := s5114) b5114 <|
    PetersenLocalChildren.push (x := s5115) b5115 <|
    PetersenLocalChildren.push (x := s5116) b5116 <|
    PetersenLocalChildren.push (x := s5117) b5117 <|
    PetersenLocalChildren.push (x := s5118) b5118 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s5120) b5120 <|
    PetersenLocalChildren.nil
theorem b5276 : Blocked tgt 8 s5276 := by
  apply PetersenFastNode.node (nxt := #[s5277,s4071,s4811,s5278,s5279,s5280,s5281,s4633,s5282,s5283]) (hints := [6846,783,6974,6846,5556,6846,5940,5556,4532,4532,5556,6846,6846,5556,5556,6588,5556,4798,7476,5556,1460,1460,5556,2718,2718,5556,5556,9684,5556,8719,13620,5556,9683,911,911,9683,911,8659,9675,911,911,9683,9683,911,911,4926,2703,911,911,6974,13523,911,911,9683,9683,911,911,1491,8847,911,6972,5940,5940,6972,6972,5940,5940,6972,11475,2703,11475,2703,13523,5940,13523,14035,9939,9939,5940,10068,5940,8847,13620,8847,1679,1679,2703,10451,2703,11467,12491,12499,12491,13515,0,1,2,3,8847,13620,8847,13620,2703,11475,2703,11475,4,13523,5,13523,6,7,8,9,8847,13620,8847,13620,2703,7476,13523,2703,2703,11475,11475,2703,2703,3283,8847,2703,4751,4751,8847,5331,8847,5267,8847,13620,8847,13620]) (by decide +kernel)
  change ∀ b ∈ [s5277,s4071,s4811,s5278,s5279,s5280,s5281,s4633,s5282,s5283], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5277) b5277 <|
    PetersenLocalChildren.push (x := s4071) b4071 <|
    PetersenLocalChildren.push (x := s4811) b4811 <|
    PetersenLocalChildren.push (x := s5278) b5278 <|
    PetersenLocalChildren.push (x := s5279) b5279 <|
    PetersenLocalChildren.push (x := s5280) b5280 <|
    PetersenLocalChildren.push (x := s5281) b5281 <|
    PetersenLocalChildren.push (x := s4633) b4633 <|
    PetersenLocalChildren.push (x := s5282) b5282 <|
    PetersenLocalChildren.push (x := s5283) b5283 <|
    PetersenLocalChildren.nil
theorem b5398 : Blocked tgt 8 s5398 := by
  apply PetersenFastNode.node (nxt := #[s5050,s5063,s5399,s1142,s5400]) (hints := [778,5295,778,9678,5551,5293,5551,9934,4527,5551,0,5551,6583,5551,11470,7471,5551,9679,1455,13647,9679,5551,1487,13615,5551,9678,6969,9678,5807,778,9678,8646,8654,9670,8646,778,9678,9678,778,9678,7471,11470,9678,9678,13647,13518,9678,1422,1486,9614,1422,5677,5935,5677,5935,6841,1,2,6841,6841,3,4,6841,4777,11470,6825,11470,2713,13518,6809,13518,6841,13615,14905,13615,6967,5935,5935,6967,6967,5935,5935,6967,11470,4919,11470,5935,13518,1839,13518,10063,5935,1871,13615,5935,7479,7479,10438,10446,10438,11462,12486,12494,12486,13510,14647,13615,14647,13615,2698,11470,2698,11470,14679,13518,14679,13518,14647,13615,14647,13615,11470,3375,13518,11470,3214,3278,11406,3214,5262,5326,13454,5262]) (by decide +kernel)
  change ∀ b ∈ [s5050,s5063,s5399,s1142,s5400], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5050) b5050 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s5399) b5399 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s5400) b5400 <|
    PetersenLocalChildren.nil
theorem b5472 : Blocked tgt 8 s5472 := by
  apply PetersenFastNode.node (nxt := #[s4138,s5239,s5328,s5374,s572,s5473,s5115,s5419,s5421,s5474]) (hints := [5556,5556,911,9683,911,9683,9939,9939,11612,0,11612,1,2703,11475,2703,11475,4751,13523,4751,13523,13620,2,13620,3,4,5,6846,9683,6974,9683,5940,6846,6068,11612,6,11612,6846,7476,11475,7476,11475,13652,13523,13652,13523,13620,7,13620,6846,6846,8,9,6846,9683,911,911,9683,8651,8659,9675,8651,9683,4926,11475,9683,9683,2878,13523,9683,1427,1491,9619,1427,911,9683,9683,911,6972,5940,11612,6972,11475,2703,11475,2703,13523,4751,13523,4751,5940,1876,13620,5940,6972,5940,5940,6972,10443,10451,10443,11467,12491,12499,12491,13515,3420,3420,11612,13620,1679,1679,11475,3380,13523,11475,3219,3283,11411,3219,2703,11475,11475,2703,5267,5331,13459,5267,4751,13523,13523,4751,8847,8847]) (by decide +kernel)
  change ∀ b ∈ [s4138,s5239,s5328,s5374,s572,s5473,s5115,s5419,s5421,s5474], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s5239) b5239 <|
    PetersenLocalChildren.push (x := s5328) b5328 <|
    PetersenLocalChildren.push (x := s5374) b5374 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s5473) b5473 <|
    PetersenLocalChildren.push (x := s5115) b5115 <|
    PetersenLocalChildren.push (x := s5419) b5419 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s5474) b5474 <|
    PetersenLocalChildren.nil
theorem b5484 : Blocked tgt 8 s5484 := by
  apply PetersenFastNode.node (nxt := #[s5485,s5486,s5487,s5488,s5489,s5490,s572,s5491,s625,s5492,s5493,s5494,s5495,s5496,s5497,s5498,s5499,s5500,s5501,s5502,s391,s626,s631,s599,s4344,s5503,s5504,s5505,s5506,s5507,s5508,s5509,s5510,s5511,s5512,s5513,s5514]) (hints := [6359,6873,0,5583,5583,8678,5583,5583,1,8678,6873,8678,6873,6873,2,5583,5583,3,5583,5583,4,6873,6873,5,5583,5583,5967,9838,6873,9966,5967,6873,5967,5583,5583,9966,6615,6615,7511,4559,5583,1706,7511,5583,7511,6615,6615,1706,5583,5583,7503,4567,6615,10470,7503,6615,7503,5583,5583,10470,9711,9711,13679,1487,5583,12518,13679,5583,13679,9711,9711,12518,5583,5583,13647,1519,9711,8874,13647,9711,13647,5583,5583,8874,938,8678,6,938,7,8,8678,8678,9966,5967,9,5967,9190,10,9966,8678,8678,5967,8678,8678,1706,7511,11,7511,9702,12,1706,8678,8678,7511,8678,8678,10470,7503,13,7503,10470,14,10470,8678,8678,7503,8678,8678,12518,13679,15,13679,12518,16,12518,8678,8678,13679,422,422,8874,486,8678,13647,8614,8678,8874,422,422,13647,9966,17,9966,8934,18,5967,9966,19,9966,5967,20,5967,1706,21,1706,7511,22,7511,1706,23,1706,7511,24,7511,2730,25,2730,10470,26,10470,2730,27,2730,10470,28,10470,4778,29,4778,12518,30,12518,4778,31,4778,12518,32,12518,8874,33,8874,13647,34,13647,8874,35,8874,13647,36,13647,8942,6999,7511,8942,9966,1706,9966,9966,7511,1706,6999,1706,10470,9966,10470,2730,6999,2730,10470,6999,10470,9966,9966,2730,12518,9966,12518,4778,5967,4778,12518,5967,12518,9966,9966,4778,1710,1710,13647,1774,9966,8874,9902,9966,13647,1710,1710,8874,10470,1706,10470,11502,7511,11502,10470,7511,10470,1706,1706,11502,12518,1706,12518,13550,7511,13550,12518,7511,12518,1706,1706,13550,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,10470,10470,12518,3407,7503,14711,12518,7503,12518,10470,10470,14711,2214,2214,8874,2278,10470,14679,10406,10470,8874,2214,2214,14679,4262,4262,8874,4326,12518,13647,12454,12518,8874,4262,4262,13647]) (by decide +kernel)
  change ∀ b ∈ [s5485,s5486,s5487,s5488,s5489,s5490,s572,s5491,s625,s5492,s5493,s5494,s5495,s5496,s5497,s5498,s5499,s5500,s5501,s5502,s391,s626,s631,s599,s4344,s5503,s5504,s5505,s5506,s5507,s5508,s5509,s5510,s5511,s5512,s5513,s5514], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5485) b5485 <|
    PetersenLocalChildren.push (x := s5486) b5486 <|
    PetersenLocalChildren.push (x := s5487) b5487 <|
    PetersenLocalChildren.push (x := s5488) b5488 <|
    PetersenLocalChildren.push (x := s5489) b5489 <|
    PetersenLocalChildren.push (x := s5490) b5490 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s5491) b5491 <|
    PetersenLocalChildren.push (x := s625) b625 <|
    PetersenLocalChildren.push (x := s5492) b5492 <|
    PetersenLocalChildren.push (x := s5493) b5493 <|
    PetersenLocalChildren.push (x := s5494) b5494 <|
    PetersenLocalChildren.push (x := s5495) b5495 <|
    PetersenLocalChildren.push (x := s5496) b5496 <|
    PetersenLocalChildren.push (x := s5497) b5497 <|
    PetersenLocalChildren.push (x := s5498) b5498 <|
    PetersenLocalChildren.push (x := s5499) b5499 <|
    PetersenLocalChildren.push (x := s5500) b5500 <|
    PetersenLocalChildren.push (x := s5501) b5501 <|
    PetersenLocalChildren.push (x := s5502) b5502 <|
    PetersenLocalChildren.push (x := s391) b391 <|
    PetersenLocalChildren.push (x := s626) b626 <|
    PetersenLocalChildren.push (x := s631) b631 <|
    PetersenLocalChildren.push (x := s599) b599 <|
    PetersenLocalChildren.push (x := s4344) b4344 <|
    PetersenLocalChildren.push (x := s5503) b5503 <|
    PetersenLocalChildren.push (x := s5504) b5504 <|
    PetersenLocalChildren.push (x := s5505) b5505 <|
    PetersenLocalChildren.push (x := s5506) b5506 <|
    PetersenLocalChildren.push (x := s5507) b5507 <|
    PetersenLocalChildren.push (x := s5508) b5508 <|
    PetersenLocalChildren.push (x := s5509) b5509 <|
    PetersenLocalChildren.push (x := s5510) b5510 <|
    PetersenLocalChildren.push (x := s5511) b5511 <|
    PetersenLocalChildren.push (x := s5512) b5512 <|
    PetersenLocalChildren.push (x := s5513) b5513 <|
    PetersenLocalChildren.push (x := s5514) b5514 <|
    PetersenLocalChildren.nil

theorem b5586 : Blocked tgt 8 s5586 := by
  apply PetersenFastNode.node (nxt := #[s5587,s5588,s5589,s1384,s5590,s1386,s5591,s5592,s5593,s5508,s5594,s5595,s5596,s5597,s1397,s5546,s1399,s5598,s5599,s5600,s4627,s4633,s4622,s4595,s5601,s5602,s5603,s5604,s5605,s5606,s572,s5607,s4626,s5608,s5609,s5610,s5611]) (hints := [6873,6873,7001,810,5583,938,7001,5583,7001,6873,6873,938,5583,5583,5967,9838,6873,9966,5967,6873,5967,5583,5583,9966,6615,6615,7511,4559,5583,1706,7511,5583,7511,6615,6615,1706,5583,5583,7503,4567,6615,2730,7503,6615,7503,5583,5583,2730,9711,9711,0,5583,5583,12518,5583,5583,1,9711,9711,12518,9711,9711,2,5583,5583,3,5583,5583,4,9711,9711,5,5583,5583,13647,1519,9711,8874,13647,9711,13647,5583,5583,8874,9710,9710,9966,938,938,5967,9966,938,9966,9710,9710,5967,938,938,1706,9710,9710,7511,1706,9710,1706,938,938,7511,938,938,2730,4953,7001,7503,2730,7001,2730,938,938,7503,938,938,12518,7001,7001,6,12518,7001,12518,938,938,7,938,938,8,8678,8678,9,8678,8678,10,938,938,11,938,938,8874,1518,9710,13647,8874,9710,8874,938,938,13647,8942,6999,7511,8942,9966,1706,9966,9966,7511,1706,6999,1706,9966,9966,11502,2730,6999,2730,11502,6999,11502,9966,9966,2730,9966,9966,12518,5967,5967,12,12518,5967,12518,9966,9966,13,9966,9966,14,8934,5967,15,5967,5967,16,9966,9966,17,1710,1710,13647,1774,9966,8874,9902,9966,13647,1710,1710,8874,1706,1706,2730,11502,7511,11502,2730,7511,2730,1706,1706,11502,1706,1706,12518,7511,7511,18,12518,7511,12518,1706,1706,19,1706,1706,20,7511,7511,21,7511,7511,22,1706,1706,23,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,2730,2730,12518,7503,7503,24,12518,7503,12518,2730,2730,25,2730,2730,26,10470,10470,27,10470,10470,28,2730,2730,29,2730,2730,8874,3310,11502,14679,8874,11502,8874,2730,2730,14679,4778,12518,30,4778,31,32,8874,4262,8874,4326,12518,13647,8874,12518,8874,4262,4262,13647,8874,33,8874,13647,34,13647,8874,35,8874,13647,36,13647]) (by decide +kernel)
  change ∀ b ∈ [s5587,s5588,s5589,s1384,s5590,s1386,s5591,s5592,s5593,s5508,s5594,s5595,s5596,s5597,s1397,s5546,s1399,s5598,s5599,s5600,s4627,s4633,s4622,s4595,s5601,s5602,s5603,s5604,s5605,s5606,s572,s5607,s4626,s5608,s5609,s5610,s5611], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5587) b5587 <|
    PetersenLocalChildren.push (x := s5588) b5588 <|
    PetersenLocalChildren.push (x := s5589) b5589 <|
    PetersenLocalChildren.push (x := s1384) b1384 <|
    PetersenLocalChildren.push (x := s5590) b5590 <|
    PetersenLocalChildren.push (x := s1386) b1386 <|
    PetersenLocalChildren.push (x := s5591) b5591 <|
    PetersenLocalChildren.push (x := s5592) b5592 <|
    PetersenLocalChildren.push (x := s5593) b5593 <|
    PetersenLocalChildren.push (x := s5508) b5508 <|
    PetersenLocalChildren.push (x := s5594) b5594 <|
    PetersenLocalChildren.push (x := s5595) b5595 <|
    PetersenLocalChildren.push (x := s5596) b5596 <|
    PetersenLocalChildren.push (x := s5597) b5597 <|
    PetersenLocalChildren.push (x := s1397) b1397 <|
    PetersenLocalChildren.push (x := s5546) b5546 <|
    PetersenLocalChildren.push (x := s1399) b1399 <|
    PetersenLocalChildren.push (x := s5598) b5598 <|
    PetersenLocalChildren.push (x := s5599) b5599 <|
    PetersenLocalChildren.push (x := s5600) b5600 <|
    PetersenLocalChildren.push (x := s4627) b4627 <|
    PetersenLocalChildren.push (x := s4633) b4633 <|
    PetersenLocalChildren.push (x := s4622) b4622 <|
    PetersenLocalChildren.push (x := s4595) b4595 <|
    PetersenLocalChildren.push (x := s5601) b5601 <|
    PetersenLocalChildren.push (x := s5602) b5602 <|
    PetersenLocalChildren.push (x := s5603) b5603 <|
    PetersenLocalChildren.push (x := s5604) b5604 <|
    PetersenLocalChildren.push (x := s5605) b5605 <|
    PetersenLocalChildren.push (x := s5606) b5606 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s5607) b5607 <|
    PetersenLocalChildren.push (x := s4626) b4626 <|
    PetersenLocalChildren.push (x := s5608) b5608 <|
    PetersenLocalChildren.push (x := s5609) b5609 <|
    PetersenLocalChildren.push (x := s5610) b5610 <|
    PetersenLocalChildren.push (x := s5611) b5611 <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i0 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5620,s5621,s5622,s5623]) (hints := [6840,6840,6968,0,777,5550,905,1,6968,5550,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5620,s5621,s5622,s5623], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5620) (b5620) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5621) (b5621) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5622) (b5622) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5623) (b5623) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i1 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5624,s5625,s5626,s5627]) (hints := [5550,5550,5934,0,9805,6840,9933,1,5934,6840,5934,2,5550,5550,9933,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5624,s5625,s5626,s5627], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5624) (b5624) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5625) (b5625) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5626) (b5626) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5627) (b5627) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i2 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5628,s5629,s5630,s5631]) (hints := [7478,2518,7478,0,5550,5550,1673,1,7478,5550,7478,2,7606,2518,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5628,s5629,s5630,s5631], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5628) (b5628) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5629) (b5629) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5630) (b5630) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5631) (b5631) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i3 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5632,s5633,s5634,s5635]) (hints := [5550,5550,7470,0,470,2518,2697,1,7470,2518,7470,2,5550,5550,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5632,s5633,s5634,s5635], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5632) (b5632) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5633) (b5633) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5634) (b5634) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5635) (b5635) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i4 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5636,s5637,s5638,s5639]) (hints := [9678,9678,13646,0,1454,5550,4745,1,13646,5550,13646,2,9678,9678,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5636,s5637,s5638,s5639], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5636) (b5636) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5637) (b5637) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5638) (b5638) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5639) (b5639) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i5 : PetersenLocalChildren.PairOK tgt 7 s5619 (word3,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5640,s5641,s5642,s5643]) (hints := [5550,5550,13614,0,1486,9678,8841,1,13614,9678,13614,2,5550,5550,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5640,s5641,s5642,s5643], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5640) (b5640) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5641) (b5641) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5642) (b5642) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5643) (b5643) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i6 : PetersenLocalChildren.PairOK tgt 7 s5619 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5644,s5645,s5646,s5647]) (hints := [9677,9677,9933,0,905,905,5934,1,9933,905,9933,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5644,s5645,s5646,s5647], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5644) (b5644) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5645) (b5645) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5646) (b5646) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5647) (b5647) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i7 : PetersenLocalChildren.PairOK tgt 7 s5619 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5648,s5649,s5650,s5651]) (hints := [905,905,1673,0,461,9677,7478,1,1673,9677,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5648,s5649,s5650,s5651], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5648) (b5648) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5649) (b5649) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5650) (b5650) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5651) (b5651) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i8 : PetersenLocalChildren.PairOK tgt 7 s5619 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5652,s5653,s5654,s5655]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5652,s5653,s5654,s5655], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5652) (b5652) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5653) (b5653) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5654) (b5654) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5655) (b5655) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i9 : PetersenLocalChildren.PairOK tgt 7 s5619 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5656,s5657,s5658,s5659]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5656,s5657,s5658,s5659], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5656) (b5656) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5657) (b5657) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5658) (b5658) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5659) (b5659) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i10 : PetersenLocalChildren.PairOK tgt 7 s5619 (word1,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5660,s5661,s5662,s5663]) (hints := [905,905,8841,0,1485,9677,13614,1,8841,9677,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5660,s5661,s5662,s5663], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5660) (b5660) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5661) (b5661) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5662) (b5662) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5663) (b5663) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i11 : PetersenLocalChildren.PairOK tgt 7 s5619 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5664,s5665,s5666,s5667]) (hints := [8837,8837,7478,0,8909,9933,1673,1,9861,9933,7478,2,8837,8837,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5664,s5665,s5666,s5667], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5664) (b5664) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5665) (b5665) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5666) (b5666) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5667) (b5667) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i12 : PetersenLocalChildren.PairOK tgt 7 s5619 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5668,s5669,s5670,s5671]) (hints := [9933,9933,11469,0,2697,6966,2697,1,11469,6966,11469,2,9933,9933,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5668,s5669,s5670,s5671], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5668) (b5668) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5669) (b5669) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5670) (b5670) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5671) (b5671) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i13 : PetersenLocalChildren.PairOK tgt 7 s5619 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5672,s5673,s5674,s5675]) (hints := [9933,9933,13517,0,4745,5934,4745,1,13517,5934,13517,2,9933,9933,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5672,s5673,s5674,s5675], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5672) (b5672) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5673) (b5673) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5674) (b5674) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5675) (b5675) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i14 : PetersenLocalChildren.PairOK tgt 7 s5619 (word0,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5676,s5677,s5678,s5679]) (hints := [1677,1677,13614,0,1741,9933,8841,1,9869,9933,13614,2,1677,1677,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5676,s5677,s5678,s5679], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5676) (b5676) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5677) (b5677) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5678) (b5678) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5679) (b5679) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i15 : PetersenLocalChildren.PairOK tgt 7 s5619 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5680,s5681,s5682,s5683]) (hints := [1673,1673,2697,0,2253,7478,11469,1,2697,7478,2697,2,1673,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5680,s5681,s5682,s5683], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5680) (b5680) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5681) (b5681) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5682) (b5682) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5683) (b5683) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i16 : PetersenLocalChildren.PairOK tgt 7 s5619 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5684,s5685,s5686,s5687]) (hints := [1673,1673,4745,0,4301,7478,13517,1,4745,7478,4745,2,1673,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5684,s5685,s5686,s5687], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5684) (b5684) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5685) (b5685) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5686) (b5686) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5687) (b5687) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i17 : PetersenLocalChildren.PairOK tgt 7 s5619 (word6,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5688,s5689,s5690,s5691]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5688,s5689,s5690,s5691], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5688) (b5688) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5689) (b5689) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5690) (b5690) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5691) (b5691) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i18 : PetersenLocalChildren.PairOK tgt 7 s5619 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5692,s5693,s5694,s5695]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5692,s5693,s5694,s5695], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5692) (b5692) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5693) (b5693) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5694) (b5694) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5695) (b5695) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i19 : PetersenLocalChildren.PairOK tgt 7 s5619 (word5,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5696,s5697,s5698,s5699]) (hints := [2697,2697,8841,0,3277,11469,14646,1,8841,11469,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5696,s5697,s5698,s5699], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5696) (b5696) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5697) (b5697) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5698) (b5698) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5699) (b5699) <|
    PetersenLocalChildren.nil
private theorem thetaPair5619i20 : PetersenLocalChildren.PairOK tgt 7 s5619 (word2,word206) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5700,s5701,s5702,s5703]) (hints := [4745,4745,8841,0,5325,13517,13614,1,8841,13517,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5700,s5701,s5702,s5703], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5700) (b5700) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5701) (b5701) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5702) (b5702) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5703) (b5703) <|
    PetersenLocalChildren.nil
theorem b5619 : Blocked tgt 8 s5619 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word206),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word206),(word0,word6),(word0,word5),(word0,word2),(word0,word206),(word6,word5),(word6,word2),(word6,word206),(word5,word2),(word5,word206),(word2,word206)], PetersenLocalChildren.PairOK tgt 7 s5619 p
  exact
    PetersenLocalChildren.push thetaPair5619i0 <|
    PetersenLocalChildren.push thetaPair5619i1 <|
    PetersenLocalChildren.push thetaPair5619i2 <|
    PetersenLocalChildren.push thetaPair5619i3 <|
    PetersenLocalChildren.push thetaPair5619i4 <|
    PetersenLocalChildren.push thetaPair5619i5 <|
    PetersenLocalChildren.push thetaPair5619i6 <|
    PetersenLocalChildren.push thetaPair5619i7 <|
    PetersenLocalChildren.push thetaPair5619i8 <|
    PetersenLocalChildren.push thetaPair5619i9 <|
    PetersenLocalChildren.push thetaPair5619i10 <|
    PetersenLocalChildren.push thetaPair5619i11 <|
    PetersenLocalChildren.push thetaPair5619i12 <|
    PetersenLocalChildren.push thetaPair5619i13 <|
    PetersenLocalChildren.push thetaPair5619i14 <|
    PetersenLocalChildren.push thetaPair5619i15 <|
    PetersenLocalChildren.push thetaPair5619i16 <|
    PetersenLocalChildren.push thetaPair5619i17 <|
    PetersenLocalChildren.push thetaPair5619i18 <|
    PetersenLocalChildren.push thetaPair5619i19 <|
    PetersenLocalChildren.push thetaPair5619i20 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
