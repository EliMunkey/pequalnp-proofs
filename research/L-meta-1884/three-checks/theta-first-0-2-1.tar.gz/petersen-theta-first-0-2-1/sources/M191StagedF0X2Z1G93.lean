import Petersen191Symmetry
import M191StartPreferredSignals
import M191ResidualC8A0G1
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G57
import M191StagedF0X2Z1G58
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G65
import M191StagedF0X2Z1G66
import M191StagedF0X2Z1G67
import M191StagedF0X2Z1G68
import M191StagedF0X2Z1G69
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G85
import M191StagedF0X2Z1G86
import M191StagedF0X2Z1G89
import M191StagedF0X2Z1G90
import M191StagedF0X2Z1G91
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows16
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows39
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows6
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows7
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair13991i0 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13992,s85,s281]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13992,s85,s281], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13992) (b13992) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s85) (b85) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s281) (b281) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i1 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13993,s493,s524,s1155,s1620,s13994,s13995,s13996]) (hints := [6972,0,6972,1,2,3,6972,4,6972,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13993,s493,s524,s1155,s1620,s13994,s13995,s13996], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13993) (b13993) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s493) (b493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s524) (b524) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1155) (b1155) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1620) (b1620) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13994) (b13994) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13995) (b13995) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13996) (b13996) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i2 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13992,s2070,s2835]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13992,s2070,s2835], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13992) (b13992) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2070) (b2070) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2835) (b2835) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i3 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13997,s3605,s4375,s5190,s5777,s5917,s13998,s6492]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13997,s3605,s4375,s5190,s5777,s5917,s13998,s6492], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13997) (b13997) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3605) (b3605) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4375) (b4375) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5190) (b5190) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5777) (b5777) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5917) (b5917) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13998) (b13998) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6492) (b6492) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i4 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13999,s6640,s6672,s7118,s7509,s14000,s14001,s14002]) (hints := [7474,0,7474,1,2,3,7474,4,7474,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13999,s6640,s6672,s7118,s7509,s14000,s14001,s14002], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13999) (b13999) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6640) (b6640) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6672) (b6672) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7118) (b7118) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7509) (b7509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14000) (b14000) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14001) (b14001) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14002) (b14002) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i5 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14003,s14004,s14005,s656,s14006,s1172,s1372,s14007,s14008,s14009,s14034,s14035]) (hints := [0,1,2,3,4,5,6,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s14003,s14004,s14005,s656,s14006,s1172,s1372,s14007,s14008,s14009,s14034,s14035], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14003) (b14003) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14004) (b14004) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14005) (b14005) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s656) (b656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14006) (b14006) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1172) (b1172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1372) (b1372) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14007) (b14007) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14008) (b14008) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14009) (b14009) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14034) (b14034) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14035) (b14035) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i6 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14036,s7661,s8411,s14037]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14036,s7661,s8411,s14037], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14036) (b14036) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7661) (b7661) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8411) (b8411) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14037) (b14037) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i7 : PetersenLocalChildren.PairOK tgt 8 s13991 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14038,s8813,s9509,s10037,s10490,s10671,s14039,s10931]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14038,s8813,s9509,s10037,s10490,s10671,s14039,s10931], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14038) (b14038) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8813) (b8813) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9509) (b9509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10037) (b10037) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10490) (b10490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10671) (b10671) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14039) (b14039) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10931) (b10931) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i8 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11024,s11049,s11281,s11446,s14040]) (hints := [6841,6841,6969,0,1,2,6969,3,6969,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s11024,s11049,s11281,s11446,s14040], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11024) (b11024) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11049) (b11049) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11281) (b11281) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11446) (b11446) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14040) (b14040) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i9 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s281,s2835,s11750,s12026]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s281,s2835,s11750,s12026], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s281) (b281) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2835) (b2835) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11750) (b11750) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12026) (b12026) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i10 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12420,s12895]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12420,s12895], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12420) (b12420) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12895) (b12895) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i11 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12977,s14041]) (hints := [7468,4774,7468,6838,6838,0,7468,6838,7468,4774,4774,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s12977,s14041], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12977) (b12977) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14041) (b14041) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i12 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14042,s11296,s14043,s14044]) (hints := [4776,4776,0,6840,6840,1,6840,6840,2,4776,4776,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14042,s11296,s14043,s14044], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14042) (b14042) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11296) (b11296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14043) (b14043) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14044) (b14044) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i13 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i14 : PetersenLocalChildren.PairOK tgt 8 s13991 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13105,s13598]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13105,s13598], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13105) (b13105) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13598) (b13598) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i15 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14045,s13823]) (hints := [5674,0,5674,5932,6966,5932,5674,6966,5674,5932,1,5932]) (by decide +kernel) ?_
  change ∀ x ∈ [s14045,s13823], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14045) (b14045) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13823) (b13823) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i16 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13932,s14046]) (hints := [1671,6966,1671,7220,0,7476,1671,1,1671,6966,6966,7476]) (by decide +kernel) ?_
  change ∀ x ∈ [s13932,s14046], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13932) (b13932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14046) (b14046) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i17 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14047,s14048,s14049,s14050]) (hints := [4920,0,1,6968,6968,2,7470,3,7470]) (by decide +kernel) ?_
  change ∀ x ∈ [s14047,s14048,s14049,s14050], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14047) (b14047) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14048) (b14048) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14049) (b14049) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14050) (b14050) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i18 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14050,s927,s14051]) (hints := [9676,6967,1,9676,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14050,s927,s14051], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14050) (b14050) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14051) (b14051) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i19 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,2836,13513,2868,6964,13642,13513,6964,13513,2836,2836,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i20 : PetersenLocalChildren.PairOK tgt 8 s13991 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14052,s14058]) (hints := [8839,6966,8839,13612,0,13612,8839,1,8839,6966,6966,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s14052,s14058], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14052) (b14052) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14058) (b14058) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i21 : PetersenLocalChildren.PairOK tgt 8 s13991 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i22 : PetersenLocalChildren.PairOK tgt 8 s13991 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14059,s14060]) (hints := [5932,5932,7468,4916,6964,0,7468,6964,7468,5932,5932,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14059,s14060], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14059) (b14059) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14060) (b14060) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i23 : PetersenLocalChildren.PairOK tgt 8 s13991 (word0,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14061,s13733,s13799,s14062]) (hints := [5676,5676,0,5934,5934,1,5934,5934,2,5676,5676,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14061,s13733,s13799,s14062], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14061) (b14061) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13733) (b13733) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13799) (b13799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14062) (b14062) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i24 : PetersenLocalChildren.PairOK tgt 8 s13991 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i25 : PetersenLocalChildren.PairOK tgt 8 s13991 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i26 : PetersenLocalChildren.PairOK tgt 8 s13991 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14063,s14064]) (hints := [1671,1671,0,7468,7476,7468,7460,7476,1,1671,1671,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s14063,s14064], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14063) (b14063) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14064) (b14064) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i27 : PetersenLocalChildren.PairOK tgt 8 s13991 (word6,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14065,s13955,s14066,s14067]) (hints := [1673,1673,0,7478,7478,1,7478,7478,2,1673,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14065,s13955,s14066,s14067], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14065) (b14065) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13955) (b13955) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14066) (b14066) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14067) (b14067) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i28 : PetersenLocalChildren.PairOK tgt 8 s13991 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i29 : PetersenLocalChildren.PairOK tgt 8 s13991 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i30 : PetersenLocalChildren.PairOK tgt 8 s13991 (word5,word23) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14049,s927,s14068]) (hints := [11468,7469,1,11468,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14049,s927,s14068], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14049) (b14049) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14068) (b14068) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i31 : PetersenLocalChildren.PairOK tgt 8 s13991 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,11594,13513,3370,7466,14674,13513,7466,13513,11594,11594,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i32 : PetersenLocalChildren.PairOK tgt 8 s13991 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8837,7466,8837,3402,11594,14642,8837,11594,8837,7466,7466,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13991i33 : PetersenLocalChildren.PairOK tgt 8 s13991 (word23,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14069,s14070,s14071,s14072]) (hints := [13517,0,13517,13646,1,13646,13517,2,13517,13646,3,13646]) (by decide +kernel) ?_
  change ∀ x ∈ [s14069,s14070,s14071,s14072], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14069) (b14069) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14070) (b14070) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14071) (b14071) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14072) (b14072) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i34 : PetersenLocalChildren.PairOK tgt 8 s13991 (word23,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14073,s14074,s14075,s14076]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s14073,s14074,s14075,s14076], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14073) (b14073) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14074) (b14074) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14075) (b14075) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14076) (b14076) <|
    PetersenLocalChildren.nil
private theorem thetaPair13991i35 : PetersenLocalChildren.PairOK tgt 8 s13991 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b13991 : Blocked tgt 9 s13991 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word23),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word23),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word23),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word23),(word0,word2),(word0,word4),(word6,word5),(word6,word23),(word6,word2),(word6,word4),(word5,word23),(word5,word2),(word5,word4),(word23,word2),(word23,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s13991 p
  exact
    PetersenLocalChildren.push thetaPair13991i0 <|
    PetersenLocalChildren.push thetaPair13991i1 <|
    PetersenLocalChildren.push thetaPair13991i2 <|
    PetersenLocalChildren.push thetaPair13991i3 <|
    PetersenLocalChildren.push thetaPair13991i4 <|
    PetersenLocalChildren.push thetaPair13991i5 <|
    PetersenLocalChildren.push thetaPair13991i6 <|
    PetersenLocalChildren.push thetaPair13991i7 <|
    PetersenLocalChildren.push thetaPair13991i8 <|
    PetersenLocalChildren.push thetaPair13991i9 <|
    PetersenLocalChildren.push thetaPair13991i10 <|
    PetersenLocalChildren.push thetaPair13991i11 <|
    PetersenLocalChildren.push thetaPair13991i12 <|
    PetersenLocalChildren.push thetaPair13991i13 <|
    PetersenLocalChildren.push thetaPair13991i14 <|
    PetersenLocalChildren.push thetaPair13991i15 <|
    PetersenLocalChildren.push thetaPair13991i16 <|
    PetersenLocalChildren.push thetaPair13991i17 <|
    PetersenLocalChildren.push thetaPair13991i18 <|
    PetersenLocalChildren.push thetaPair13991i19 <|
    PetersenLocalChildren.push thetaPair13991i20 <|
    PetersenLocalChildren.push thetaPair13991i21 <|
    PetersenLocalChildren.push thetaPair13991i22 <|
    PetersenLocalChildren.push thetaPair13991i23 <|
    PetersenLocalChildren.push thetaPair13991i24 <|
    PetersenLocalChildren.push thetaPair13991i25 <|
    PetersenLocalChildren.push thetaPair13991i26 <|
    PetersenLocalChildren.push thetaPair13991i27 <|
    PetersenLocalChildren.push thetaPair13991i28 <|
    PetersenLocalChildren.push thetaPair13991i29 <|
    PetersenLocalChildren.push thetaPair13991i30 <|
    PetersenLocalChildren.push thetaPair13991i31 <|
    PetersenLocalChildren.push thetaPair13991i32 <|
    PetersenLocalChildren.push thetaPair13991i33 <|
    PetersenLocalChildren.push thetaPair13991i34 <|
    PetersenLocalChildren.push thetaPair13991i35 <|
    PetersenLocalChildren.nil
theorem b14695 : Blocked tgt 9 s14695 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s14492) (by decide +kernel)
  exact b14492
theorem b14900 : Blocked tgt 9 s14900 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s14286) (by decide +kernel)
  exact b14286
private theorem thetaPair15184i0 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15185,s121,s317]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15185,s121,s317], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15185) (b15185) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s121) (b121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s317) (b317) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i1 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15186,s899,s1686,s15187]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s15186,s899,s1686,s15187], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15186) (b15186) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s899) (b899) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1686) (b1686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15187) (b15187) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i2 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15185,s2549,s2874]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15185,s2549,s2874], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15185) (b15185) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2549) (b2549) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2874) (b2874) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i3 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15188,s4529,s4566,s5454,s5816,s15189,s15190,s15191]) (hints := [11610,0,11610,1,2,3,11610,4,11610,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15188,s4529,s4566,s5454,s5816,s15189,s15190,s15191], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15188) (b15188) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4529) (b4529) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4566) (b4566) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5454) (b5454) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5816) (b5816) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15189) (b15189) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15190) (b15190) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15191) (b15191) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i4 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15192,s6811,s7551,s15193]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s15192,s6811,s7551,s15193], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15192) (b15192) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6811) (b6811) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7551) (b7551) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15193) (b15193) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i5 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15194,s7845,s8447,s15195]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s15194,s7845,s8447,s15195], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15194) (b15194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7845) (b7845) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8447) (b8447) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15195) (b15195) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i6 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15196,s9691,s9728,s10169,s10526,s15197,s15198,s15199]) (hints := [13618,0,13618,1,2,3,13618,4,13618,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15196,s9691,s9728,s10169,s10526,s15197,s15198,s15199], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15196) (b15196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9691) (b9691) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9728) (b9728) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10169) (b10169) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10526) (b10526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15197) (b15197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15198) (b15198) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15199) (b15199) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i7 : PetersenLocalChildren.PairOK tgt 8 s15184 (word7,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15200,s15201,s15202,s4651,s15203,s5472,s5740,s15204,s15205,s15206,s15271,s15272]) (hints := [0,1,2,3,4,5,6,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s15200,s15201,s15202,s4651,s15203,s5472,s5740,s15204,s15205,s15206,s15271,s15272], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15200) (b15200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15201) (b15201) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15202) (b15202) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4651) (b4651) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15203) (b15203) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5472) (b5472) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5740) (b5740) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15204) (b15204) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15205) (b15205) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15206) (b15206) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15271) (b15271) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15272) (b15272) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i8 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11214,s11505]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11214,s11505], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11214) (b11214) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11505) (b11505) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i9 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s317,s2874,s11786,s12046]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s317,s2874,s11786,s12046], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s317) (b317) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2874) (b2874) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11786) (b11786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12046) (b12046) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i10 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12557,s12603,s12764,s12932,s15278]) (hints := [11607,6841,11607,0,1,2,11607,3,11607,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s12557,s12603,s12764,s12932,s15278], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12557) (b12557) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12603) (b12603) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12764) (b12764) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12932) (b12932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15278) (b15278) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i11 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i12 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i13 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13263,s13310,s13470,s13634,s15279]) (hints := [13615,6841,13615,0,1,2,13615,3,13615,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s13263,s13310,s13470,s13634,s15279], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13263) (b13263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13310) (b13310) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13470) (b13470) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13634) (b13634) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15279) (b15279) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i14 : PetersenLocalChildren.PairOK tgt 8 s15184 (word3,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15280,s12642,s15281,s12790,s12868,s15282,s15283,s15284]) (hints := [6844,6844,0,1,2,3,4,5,6,6844,6844,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15280,s12642,s15281,s12790,s12868,s15282,s15283,s15284], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15280) (b15280) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12642) (b12642) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15281) (b15281) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12790) (b12790) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12868) (b12868) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15282) (b15282) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15283) (b15283) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15284) (b15284) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i15 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i16 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,11344,8649,9673,11602,9665,9673,11344,8641,8641,11602]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i17 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i18 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i19 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,13352,1481,9673,13610,9609,9673,13352,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i20 : PetersenLocalChildren.PairOK tgt 8 s15184 (word1,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15292,s13963,s15293,s15294]) (hints := [389,389,0,9677,9677,1,9677,9677,2,389,389,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15292,s13963,s15293,s15294], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15292) (b15292) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13963) (b13963) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15293) (b15293) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15294) (b15294) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i21 : PetersenLocalChildren.PairOK tgt 8 s15184 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14350,s15301]) (hints := [6964,6964,11604,5932,5932,0,11604,5932,11604,6964,6964,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14350,s15301], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14350) (b14350) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15301) (b15301) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i22 : PetersenLocalChildren.PairOK tgt 8 s15184 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i23 : PetersenLocalChildren.PairOK tgt 8 s15184 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i24 : PetersenLocalChildren.PairOK tgt 8 s15184 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14961,s15302]) (hints := [5932,5932,13612,1868,10060,0,13612,10060,13612,5932,5932,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14961,s15302], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14961) (b14961) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15302) (b15302) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i25 : PetersenLocalChildren.PairOK tgt 8 s15184 (word0,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15303,s14367,s14471,s15304]) (hints := [6966,6966,0,5934,5934,1,5934,5934,2,6966,6966,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15303,s14367,s14471,s15304], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15303) (b15303) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14367) (b14367) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14471) (b14471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15304) (b15304) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i26 : PetersenLocalChildren.PairOK tgt 8 s15184 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15309,s15310]) (hints := [10435,0,10435,10443,11604,11467,10435,11604,10435,11459,1,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s15309,s15310], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15309) (b15309) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15310) (b15310) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i27 : PetersenLocalChildren.PairOK tgt 8 s15184 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15168,s15311]) (hints := [12483,11604,12483,12491,0,13515,12483,1,12483,13507,11604,13515]) (by decide +kernel) ?_
  change ∀ x ∈ [s15168,s15311], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15168) (b15168) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15311) (b15311) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i28 : PetersenLocalChildren.PairOK tgt 8 s15184 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15312,s15313,s15314,s15315]) (hints := [3414,0,1,11606,11606,2,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s15312,s15313,s15314,s15315], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15312) (b15312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15313) (b15313) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15314) (b15314) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15315) (b15315) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i29 : PetersenLocalChildren.PairOK tgt 8 s15184 (word6,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15315,s927,s15316]) (hints := [1672,11605,1,1672,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15315,s927,s15316], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15315) (b15315) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15316) (b15316) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i30 : PetersenLocalChildren.PairOK tgt 8 s15184 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15184i31 : PetersenLocalChildren.PairOK tgt 8 s15184 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15317,s15318]) (hints := [3211,3211,13612,3275,11467,0,11403,11467,13612,3211,3211,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s15317,s15318], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15317) (b15317) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15318) (b15318) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i32 : PetersenLocalChildren.PairOK tgt 8 s15184 (word5,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15319,s15320,s15321,s15322]) (hints := [2181,2181,0,11469,11469,1,11469,11469,2,2181,2181,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15319,s15320,s15321,s15322], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15319) (b15319) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15320) (b15320) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15321) (b15321) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15322) (b15322) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i33 : PetersenLocalChildren.PairOK tgt 8 s15184 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15323,s15324]) (hints := [5259,5259,0,5323,13515,13612,13451,13515,1,5259,5259,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s15323,s15324], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15323) (b15323) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15324) (b15324) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i34 : PetersenLocalChildren.PairOK tgt 8 s15184 (word2,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15325,s15178,s15326,s15327]) (hints := [4229,4229,0,13517,13517,1,13517,13517,2,4229,4229,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15325,s15178,s15326,s15327], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15325) (b15325) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15178) (b15178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15326) (b15326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15327) (b15327) <|
    PetersenLocalChildren.nil
private theorem thetaPair15184i35 : PetersenLocalChildren.PairOK tgt 8 s15184 (word4,word21) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15314,s927,s15328]) (hints := [8840,13613,1,8840,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15314,s927,s15328], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15314) (b15314) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15328) (b15328) <|
    PetersenLocalChildren.nil
theorem b15184 : Blocked tgt 9 s15184 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word7,word21),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word3,word21),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word1,word21),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word0,word21),(word6,word5),(word6,word2),(word6,word4),(word6,word21),(word5,word2),(word5,word4),(word5,word21),(word2,word4),(word2,word21),(word4,word21)], PetersenLocalChildren.PairOK tgt 8 s15184 p
  exact
    PetersenLocalChildren.push thetaPair15184i0 <|
    PetersenLocalChildren.push thetaPair15184i1 <|
    PetersenLocalChildren.push thetaPair15184i2 <|
    PetersenLocalChildren.push thetaPair15184i3 <|
    PetersenLocalChildren.push thetaPair15184i4 <|
    PetersenLocalChildren.push thetaPair15184i5 <|
    PetersenLocalChildren.push thetaPair15184i6 <|
    PetersenLocalChildren.push thetaPair15184i7 <|
    PetersenLocalChildren.push thetaPair15184i8 <|
    PetersenLocalChildren.push thetaPair15184i9 <|
    PetersenLocalChildren.push thetaPair15184i10 <|
    PetersenLocalChildren.push thetaPair15184i11 <|
    PetersenLocalChildren.push thetaPair15184i12 <|
    PetersenLocalChildren.push thetaPair15184i13 <|
    PetersenLocalChildren.push thetaPair15184i14 <|
    PetersenLocalChildren.push thetaPair15184i15 <|
    PetersenLocalChildren.push thetaPair15184i16 <|
    PetersenLocalChildren.push thetaPair15184i17 <|
    PetersenLocalChildren.push thetaPair15184i18 <|
    PetersenLocalChildren.push thetaPair15184i19 <|
    PetersenLocalChildren.push thetaPair15184i20 <|
    PetersenLocalChildren.push thetaPair15184i21 <|
    PetersenLocalChildren.push thetaPair15184i22 <|
    PetersenLocalChildren.push thetaPair15184i23 <|
    PetersenLocalChildren.push thetaPair15184i24 <|
    PetersenLocalChildren.push thetaPair15184i25 <|
    PetersenLocalChildren.push thetaPair15184i26 <|
    PetersenLocalChildren.push thetaPair15184i27 <|
    PetersenLocalChildren.push thetaPair15184i28 <|
    PetersenLocalChildren.push thetaPair15184i29 <|
    PetersenLocalChildren.push thetaPair15184i30 <|
    PetersenLocalChildren.push thetaPair15184i31 <|
    PetersenLocalChildren.push thetaPair15184i32 <|
    PetersenLocalChildren.push thetaPair15184i33 <|
    PetersenLocalChildren.push thetaPair15184i34 <|
    PetersenLocalChildren.push thetaPair15184i35 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
