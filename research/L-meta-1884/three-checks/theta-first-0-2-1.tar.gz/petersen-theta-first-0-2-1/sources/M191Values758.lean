import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv758_4260 : PetersenPackedPin.project r758 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv758_4814 : PetersenPackedPin.project r758 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv758_5473 : PetersenPackedPin.project r758 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv758_6170 : PetersenPackedPin.project r758 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv758_6790 : PetersenPackedPin.project r758 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv758_7474 : PetersenPackedPin.project r758 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv758_8012 : PetersenPackedPin.project r758 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv758_1734 : PetersenPackedPin.project r758 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv758_4260 pv758_6790 rfl rfl
theorem pv758_1887 : PetersenPackedPin.project r758 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv758_6170 pv758_6790 rfl rfl
theorem pv758_2192 : PetersenPackedPin.project r758 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv758_4260 pv758_6170 rfl rfl
theorem pv758_2906 : PetersenPackedPin.project r758 (0xf0f00000f0f00000f0f00000f0f0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv758_5473 pv758_6790 rfl rfl
theorem pv758_5978 : PetersenPackedPin.project r758 (0xff000000ff000000ff000000ff000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv758_6170 pv758_6790 rfl rfl
theorem pv758_6504 : PetersenPackedPin.project r758 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv758_4260 pv758_6170 rfl rfl
theorem pv758_6546 : PetersenPackedPin.project r758 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv758_4814 pv758_6170 rfl rfl
theorem pv758_7095 : PetersenPackedPin.project r758 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv758_4260 pv758_6790 rfl rfl
theorem pv758_7235 : PetersenPackedPin.project r758 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv758_5473 pv758_6790 rfl rfl
theorem pv758_7688 : PetersenPackedPin.project r758 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv758_4260 pv758_7474 rfl rfl
theorem pv758_7712 : PetersenPackedPin.project r758 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0xffffcccc := PetersenWireProjection.derive 3 pv758_4814 pv758_7474 rfl rfl
theorem pv758_7855 : PetersenPackedPin.project r758 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv758_6170 pv758_7474 rfl rfl
theorem pv758_7944 : PetersenPackedPin.project r758 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv758_6790 pv758_7474 rfl rfl
theorem pv758_6049 : PetersenPackedPin.project r758 (0xff00f000ff00f000ff00f000ff00f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv758_6170 pv758_7235 rfl rfl
theorem pv758_7528 : PetersenPackedPin.project r758 (0xffffffff0000aaaaffffffff0000aaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv758_1734 pv758_7474 rfl rfl
theorem pv758_7558 : PetersenPackedPin.project r758 (0xffffffff00aa00aaffffffff00aa00aa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv758_2192 pv758_7474 rfl rfl
theorem pv758_7903 : PetersenPackedPin.project r758 (0xffffffffffaaffaaffffffffffaaffaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv758_4260 pv758_7855 rfl rfl
theorem pv758_7971 : PetersenPackedPin.project r758 (0xffffffffffffaaaaffffffffffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv758_4260 pv758_7944 rfl rfl
theorem pv758_3434 : PetersenPackedPin.project r758 (0x33333333000022223333333300002222 : BitVec 128) = 0x33332222 := PetersenWireProjection.derive 2 pv758_4814 pv758_7528 rfl rfl
end PetersenSmallStarts.M191.Residual
