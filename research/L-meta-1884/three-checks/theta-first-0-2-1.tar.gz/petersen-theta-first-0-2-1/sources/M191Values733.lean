import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv733_4260 : PetersenPackedPin.project r733 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv733_4814 : PetersenPackedPin.project r733 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv733_5473 : PetersenPackedPin.project r733 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv733_6170 : PetersenPackedPin.project r733 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv733_6790 : PetersenPackedPin.project r733 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv733_7474 : PetersenPackedPin.project r733 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv733_8012 : PetersenPackedPin.project r733 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv733_2708 : PetersenPackedPin.project r733 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 1 pv733_4260 pv733_5473 rfl rfl
theorem pv733_3632 : PetersenPackedPin.project r733 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv733_4260 pv733_5473 rfl rfl
theorem pv733_5224 : PetersenPackedPin.project r733 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv733_4260 pv733_4814 rfl rfl
theorem pv733_5029 : PetersenPackedPin.project r733 (0xcececececececececececececececece : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv733_2708 pv733_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
