import M191StartPreferredSignals
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G57
import M191StagedF0X2Z1G58
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G84
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows57
import M191StartPreferredRows6
import M191StartPreferredRows60
import M191StartPreferredRows7
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair3224i0 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3225,s3226,s3261,s3262]) (hints := [6840,6840,6968,0,777,4526,905,1,6968,4526,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3225,s3226,s3261,s3262], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3225) (b3225) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3226) (b3226) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3261) (b3261) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3262) (b3262) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i1 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3263,s2900,s3264,s3265]) (hints := [4526,4526,5934,0,9797,6840,9925,1,5934,6840,5934,2,4526,4526,9925,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3263,s2900,s3264,s3265], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3263) (b3263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2900) (b2900) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3264) (b3264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3265) (b3265) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i2 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3310,s3311,s3351,s3352]) (hints := [7478,6840,7478,0,4526,4526,1673,1,6582,4526,7478,2,6582,6840,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3310,s3311,s3351,s3352], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3310) (b3310) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3311) (b3311) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3351) (b3351) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3352) (b3352) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i3 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3353,s3354,s3387,s3388]) (hints := [4526,4526,7470,0,4792,6840,2697,1,6574,6840,7470,2,4526,4526,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3353,s3354,s3387,s3388], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3353) (b3353) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3354) (b3354) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3387) (b3387) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3388) (b3388) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i4 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3389,s3390,s3418,s3419]) (hints := [8654,8654,13646,0,430,4526,4745,1,12750,4526,13646,2,8654,8654,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3389,s3390,s3418,s3419], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3389) (b3389) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3390) (b3390) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3418) (b3418) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3419) (b3419) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i5 : PetersenLocalChildren.PairOK tgt 8 s3224 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3420,s3421,s3468,s3469]) (hints := [4526,4526,13614,0,462,8654,8841,1,12718,8654,13614,2,4526,4526,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3420,s3421,s3468,s3469], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3420) (b3420) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3421) (b3421) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3468) (b3468) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3469) (b3469) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i6 : PetersenLocalChildren.PairOK tgt 8 s3224 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3470,s3471,s3500,s3501]) (hints := [8645,8645,9925,0,905,905,5934,1,9925,905,9925,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3470,s3471,s3500,s3501], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3470) (b3470) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3471) (b3471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3500) (b3500) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3501) (b3501) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i7 : PetersenLocalChildren.PairOK tgt 8 s3224 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3532,s3533,s3569,s3570]) (hints := [905,905,1673,0,8645,8645,7478,1,1673,8645,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3532,s3533,s3569,s3570], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3532) (b3532) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3533) (b3533) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3569) (b3569) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3570) (b3570) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i8 : PetersenLocalChildren.PairOK tgt 8 s3224 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3604,s3605,s3638,s3639]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3604,s3605,s3638,s3639], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3604) (b3604) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3605) (b3605) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3638) (b3638) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3639) (b3639) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i9 : PetersenLocalChildren.PairOK tgt 8 s3224 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3640,s3641,s3672,s3673]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3640,s3641,s3672,s3673], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3640) (b3640) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3641) (b3641) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3672) (b3672) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3673) (b3673) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i10 : PetersenLocalChildren.PairOK tgt 8 s3224 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3674,s3675,s3708,s3709]) (hints := [905,905,8841,0,453,8645,13614,1,8841,8645,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3674,s3675,s3708,s3709], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3674) (b3674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3675) (b3675) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3708) (b3708) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3709) (b3709) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i11 : PetersenLocalChildren.PairOK tgt 8 s3224 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3710,s3711,s3745,s3772]) (hints := [8901,6966,7478,0,8901,9925,1673,1,9925,9925,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3710,s3711,s3745,s3772], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3710) (b3710) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3711) (b3711) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3745) (b3745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3772) (b3772) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i12 : PetersenLocalChildren.PairOK tgt 8 s3224 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3792,s3793,s3829,s3854]) (hints := [9925,9925,10437,0,2697,6966,2697,1,10437,6966,10437,2,9925,9925,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3792,s3793,s3829,s3854], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3792) (b3792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3793) (b3793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3829) (b3829) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3854) (b3854) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i13 : PetersenLocalChildren.PairOK tgt 8 s3224 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3855,s3856,s3893,s3917]) (hints := [9925,9925,12485,0,4745,5934,4745,1,12485,5934,12485,2,9925,9925,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3855,s3856,s3893,s3917], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3855) (b3855) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3856) (b3856) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3893) (b3893) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3917) (b3917) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i14 : PetersenLocalChildren.PairOK tgt 8 s3224 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3918,s3919,s3943,s3967]) (hints := [1669,1669,13614,0,1733,9925,8841,1,9861,9925,13614,2,1669,1669,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3918,s3919,s3943,s3967], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3918) (b3918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3919) (b3919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3943) (b3943) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3967) (b3967) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i15 : PetersenLocalChildren.PairOK tgt 8 s3224 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3968,s3969,s3994,s4025]) (hints := [1673,1673,2697,0,10437,7478,10437,1,2697,7478,2697,2,1673,1673,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3968,s3969,s3994,s4025], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3968) (b3968) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3969) (b3969) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3994) (b3994) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4025) (b4025) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i16 : PetersenLocalChildren.PairOK tgt 8 s3224 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4026,s4027,s4055,s4087]) (hints := [1673,1673,4745,0,12485,7478,12485,1,4745,7478,4745,2,1673,1673,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4026,s4027,s4055,s4087], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4026) (b4026) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4027) (b4027) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4055) (b4055) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4087) (b4087) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i17 : PetersenLocalChildren.PairOK tgt 8 s3224 (word14,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4088,s4089,s4121,s4144]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4088,s4089,s4121,s4144], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4088) (b4088) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4089) (b4089) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4121) (b4121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4144) (b4144) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i18 : PetersenLocalChildren.PairOK tgt 8 s3224 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4145,s4146,s4179,s4180]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4145,s4146,s4179,s4180], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4145) (b4145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4146) (b4146) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4179) (b4179) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4180) (b4180) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i19 : PetersenLocalChildren.PairOK tgt 8 s3224 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4181,s4182,s4207,s4208]) (hints := [2697,2697,8841,0,2245,10437,14646,1,8841,10437,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4181,s4182,s4207,s4208], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4181) (b4181) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4182) (b4182) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4207) (b4207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4208) (b4208) <|
    PetersenLocalChildren.nil
private theorem thetaPair3224i20 : PetersenLocalChildren.PairOK tgt 8 s3224 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4209,s4210,s4211,s4212]) (hints := [4745,4745,8841,0,4293,12485,13614,1,8841,12485,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4209,s4210,s4211,s4212], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4209) (b4209) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4210) (b4210) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4211) (b4211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4212) (b4212) <|
    PetersenLocalChildren.nil
theorem b3224 : Blocked tgt 9 s3224 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word14),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word14),(word1,word5),(word1,word2),(word1,word4),(word0,word14),(word0,word5),(word0,word2),(word0,word4),(word14,word5),(word14,word2),(word14,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s3224 p
  exact
    PetersenLocalChildren.push thetaPair3224i0 <|
    PetersenLocalChildren.push thetaPair3224i1 <|
    PetersenLocalChildren.push thetaPair3224i2 <|
    PetersenLocalChildren.push thetaPair3224i3 <|
    PetersenLocalChildren.push thetaPair3224i4 <|
    PetersenLocalChildren.push thetaPair3224i5 <|
    PetersenLocalChildren.push thetaPair3224i6 <|
    PetersenLocalChildren.push thetaPair3224i7 <|
    PetersenLocalChildren.push thetaPair3224i8 <|
    PetersenLocalChildren.push thetaPair3224i9 <|
    PetersenLocalChildren.push thetaPair3224i10 <|
    PetersenLocalChildren.push thetaPair3224i11 <|
    PetersenLocalChildren.push thetaPair3224i12 <|
    PetersenLocalChildren.push thetaPair3224i13 <|
    PetersenLocalChildren.push thetaPair3224i14 <|
    PetersenLocalChildren.push thetaPair3224i15 <|
    PetersenLocalChildren.push thetaPair3224i16 <|
    PetersenLocalChildren.push thetaPair3224i17 <|
    PetersenLocalChildren.push thetaPair3224i18 <|
    PetersenLocalChildren.push thetaPair3224i19 <|
    PetersenLocalChildren.push thetaPair3224i20 <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i0 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4475,s4735,s3263,s147,s4736]) (hints := [4527,0,6841,1,4527,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s4475,s4735,s3263,s147,s4736], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4475) (b4475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4735) (b4735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3263) (b3263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s147) (b147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4736) (b4736) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i1 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4737,s4738,s932,s978,s4739,s4740,s4741,s4742]) (hints := [909,0,909,1,8649,2,8649,3,909,4,909,5,8649,6,8649,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4737,s4738,s932,s978,s4739,s4740,s4741,s4742], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4737) (b4737) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4738) (b4738) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s932) (b932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s978) (b978) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4739) (b4739) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4740) (b4740) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4741) (b4741) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4742) (b4742) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i2 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4475,s4735,s2900,s2593,s2955]) (hints := [9926,0,5935,1,9926,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s4475,s4735,s2900,s2593,s2955], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4475) (b4475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4735) (b4735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2900) (b2900) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2593) (b2593) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2955) (b2955) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i3 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4475,s4735,s4743,s4744,s4745,s4746]) (hints := [1675,0,1675,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s4475,s4735,s4743,s4744,s4745,s4746], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4475) (b4475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4735) (b4735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4743) (b4743) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4744) (b4744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4745) (b4745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4746) (b4746) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i4 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4747,s4748,s4749,s4786,s4787,s4788,s4789,s4790]) (hints := [2701,0,2701,1,10441,2,10441,3,2701,4,2701,5,10441,6,10441,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4747,s4748,s4749,s4786,s4787,s4788,s4789,s4790], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4747) (b4747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4748) (b4748) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4749) (b4749) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4786) (b4786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4787) (b4787) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4788) (b4788) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4789) (b4789) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4790) (b4790) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i5 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4791,s4792,s4793,s4822,s4823,s4824,s4825,s4826]) (hints := [4749,0,4749,1,12489,2,12489,3,4749,4,4749,5,12489,6,12489,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4791,s4792,s4793,s4822,s4823,s4824,s4825,s4826], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4791) (b4791) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4792) (b4792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4793) (b4793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4822) (b4822) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4823) (b4823) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4824) (b4824) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4825) (b4825) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4826) (b4826) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i6 : PetersenLocalChildren.PairOK tgt 8 s4734 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4827,s4828,s4829,s4914,s4948,s4949,s4950,s4951,s4952,s5041,s5042,s5043]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s4827,s4828,s4829,s4914,s4948,s4949,s4950,s4951,s4952,s5041,s5042,s5043], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4827) (b4827) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4828) (b4828) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4829) (b4829) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4914) (b4914) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4948) (b4948) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4949) (b4949) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4950) (b4950) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4951) (b4951) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4952) (b4952) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5041) (b5041) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5042) (b5042) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5043) (b5043) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i7 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5044,s5045,s5067,s5068,s5069,s5070]) (hints := [6842,6842,6970,0,8647,1,8647,2,6970,3,6970,4,8647,6842,8647,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5044,s5045,s5067,s5068,s5069,s5070], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5044) (b5044) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5045) (b5045) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5067) (b5067) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5068) (b5068) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5069) (b5069) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5070) (b5070) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i8 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s147,s4736,s2593,s2955,s5071,s5091,s5092]) (hints := [5937,0,5937,1,6843,6843,2,3,6065,4,5,6]) (by decide +kernel) ?_
  change ∀ x ∈ [s147,s4736,s2593,s2955,s5071,s5091,s5092], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s147) (b147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4736) (b4736) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2593) (b2593) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2955) (b2955) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5071) (b5071) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5091) (b5091) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5092) (b5092) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i9 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5093,s5094,s5121,s5122,s5123,s5124]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5093,s5094,s5121,s5122,s5123,s5124], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5093) (b5093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5094) (b5094) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5121) (b5121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5122) (b5122) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5123) (b5123) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5124) (b5124) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i10 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5125,s5126,s5127,s5128]) (hints := [7470,4776,7470,0,10437,6840,10437,1,7470,6840,7470,2,10437,4776,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5125,s5126,s5127,s5128], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5125) (b5125) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5126) (b5126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5127) (b5127) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5128) (b5128) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i11 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5129,s5130,s5131,s5132]) (hints := [13646,2712,13646,0,12485,6840,12485,1,13646,6840,13646,2,12485,2712,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5129,s5130,s5131,s5132], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5129) (b5129) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5130) (b5130) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5131) (b5131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5132) (b5132) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i12 : PetersenLocalChildren.PairOK tgt 8 s4734 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5133,s5134,s5167,s5168,s5169,s5170]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5133,s5134,s5167,s5168,s5169,s5170], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5133) (b5133) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5134) (b5134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5167) (b5167) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5168) (b5168) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5169) (b5169) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5170) (b5170) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i13 : PetersenLocalChildren.PairOK tgt 8 s4734 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5171,s5172,s5173,s5174]) (hints := [8645,8645,5676,0,905,905,5934,1,905,905,5676,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5171,s5172,s5173,s5174], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5171) (b5171) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5172) (b5172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5173) (b5173) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5174) (b5174) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i14 : PetersenLocalChildren.PairOK tgt 8 s4734 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5175,s5176,s5187,s5188]) (hints := [905,905,1673,0,8645,8645,7478,1,8645,8645,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5175,s5176,s5187,s5188], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5175) (b5175) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5176) (b5176) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5187) (b5187) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5188) (b5188) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i15 : PetersenLocalChildren.PairOK tgt 8 s4734 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5189,s5190,s5191,s5192]) (hints := [8645,8645,10437,0,4920,6968,7470,1,10437,6968,10437,2,8645,8645,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5189,s5190,s5191,s5192], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5189) (b5189) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5190) (b5190) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5191) (b5191) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5192) (b5192) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i16 : PetersenLocalChildren.PairOK tgt 8 s4734 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5193,s5194,s5195,s5196]) (hints := [8645,8645,12485,0,2872,6968,13646,1,12485,6968,12485,2,8645,8645,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5193,s5194,s5195,s5196], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5193) (b5193) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5194) (b5194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5195) (b5195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5196) (b5196) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i17 : PetersenLocalChildren.PairOK tgt 8 s4734 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5197,s5198,s5211,s5212]) (hints := [389,389,8841,0,453,8645,13614,1,8581,8645,8841,2,389,389,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5197,s5198,s5211,s5212], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5197) (b5197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5198) (b5198) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5211) (b5211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5212) (b5212) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i18 : PetersenLocalChildren.PairOK tgt 8 s4734 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5213,s5214,s5215,s5216]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5213,s5214,s5215,s5216], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5213) (b5213) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5214) (b5214) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5215) (b5215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5216) (b5216) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i19 : PetersenLocalChildren.PairOK tgt 8 s4734 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5217,s5218,s5219,s5220]) (hints := [10437,5934,10437,0,2697,6966,2697,1,10437,6966,10437,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5217,s5218,s5219,s5220], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5217) (b5217) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5218) (b5218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5219) (b5219) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5220) (b5220) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i20 : PetersenLocalChildren.PairOK tgt 8 s4734 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5221,s5222,s5223,s5224]) (hints := [12485,10062,12485,0,4745,5934,4745,1,12485,5934,12485,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5221,s5222,s5223,s5224], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5221) (b5221) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5222) (b5222) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5223) (b5223) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5224) (b5224) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i21 : PetersenLocalChildren.PairOK tgt 8 s4734 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5225,s5226,s5227,s5228]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5225,s5226,s5227,s5228], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5225) (b5225) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5226) (b5226) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5227) (b5227) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5228) (b5228) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i22 : PetersenLocalChildren.PairOK tgt 8 s4734 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5229,s5230,s5231,s5232]) (hints := [1673,1673,2697,0,10437,7478,10437,1,2697,7478,2697,2,10437,1673,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5229,s5230,s5231,s5232], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5229) (b5229) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5230) (b5230) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5231) (b5231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5232) (b5232) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i23 : PetersenLocalChildren.PairOK tgt 8 s4734 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5233,s5234,s5235,s5236]) (hints := [1673,1673,4745,0,12485,7478,12485,1,4745,7478,4745,2,12485,1673,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5233,s5234,s5235,s5236], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5233) (b5233) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5234) (b5234) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5235) (b5235) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5236) (b5236) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i24 : PetersenLocalChildren.PairOK tgt 8 s4734 (word14,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5237,s5238,s5246,s5247]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5237,s5238,s5246,s5247], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5237) (b5237) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5238) (b5238) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5246) (b5246) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5247) (b5247) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i25 : PetersenLocalChildren.PairOK tgt 8 s4734 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5248,s5249,s5250,s5251]) (hints := [10437,10437,12485,0,3374,7470,14678,1,12485,7470,12485,2,10437,10437,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5248,s5249,s5250,s5251], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5248) (b5248) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5249) (b5249) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5250) (b5250) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5251) (b5251) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i26 : PetersenLocalChildren.PairOK tgt 8 s4734 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5252,s5253,s5254,s5255]) (hints := [2181,2181,8841,0,2245,10437,14646,1,10373,10437,8841,2,2181,2181,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5252,s5253,s5254,s5255], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5252) (b5252) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5253) (b5253) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5254) (b5254) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5255) (b5255) <|
    PetersenLocalChildren.nil
private theorem thetaPair4734i27 : PetersenLocalChildren.PairOK tgt 8 s4734 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5256,s5257,s5258,s5259]) (hints := [4229,4229,8841,0,4293,12485,13614,1,12421,12485,8841,2,4229,4229,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5256,s5257,s5258,s5259], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5256) (b5256) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5257) (b5257) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5258) (b5258) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5259) (b5259) <|
    PetersenLocalChildren.nil
theorem b4734 : Blocked tgt 9 s4734 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word14),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word14),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word14),(word1,word5),(word1,word2),(word1,word4),(word0,word14),(word0,word5),(word0,word2),(word0,word4),(word14,word5),(word14,word2),(word14,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s4734 p
  exact
    PetersenLocalChildren.push thetaPair4734i0 <|
    PetersenLocalChildren.push thetaPair4734i1 <|
    PetersenLocalChildren.push thetaPair4734i2 <|
    PetersenLocalChildren.push thetaPair4734i3 <|
    PetersenLocalChildren.push thetaPair4734i4 <|
    PetersenLocalChildren.push thetaPair4734i5 <|
    PetersenLocalChildren.push thetaPair4734i6 <|
    PetersenLocalChildren.push thetaPair4734i7 <|
    PetersenLocalChildren.push thetaPair4734i8 <|
    PetersenLocalChildren.push thetaPair4734i9 <|
    PetersenLocalChildren.push thetaPair4734i10 <|
    PetersenLocalChildren.push thetaPair4734i11 <|
    PetersenLocalChildren.push thetaPair4734i12 <|
    PetersenLocalChildren.push thetaPair4734i13 <|
    PetersenLocalChildren.push thetaPair4734i14 <|
    PetersenLocalChildren.push thetaPair4734i15 <|
    PetersenLocalChildren.push thetaPair4734i16 <|
    PetersenLocalChildren.push thetaPair4734i17 <|
    PetersenLocalChildren.push thetaPair4734i18 <|
    PetersenLocalChildren.push thetaPair4734i19 <|
    PetersenLocalChildren.push thetaPair4734i20 <|
    PetersenLocalChildren.push thetaPair4734i21 <|
    PetersenLocalChildren.push thetaPair4734i22 <|
    PetersenLocalChildren.push thetaPair4734i23 <|
    PetersenLocalChildren.push thetaPair4734i24 <|
    PetersenLocalChildren.push thetaPair4734i25 <|
    PetersenLocalChildren.push thetaPair4734i26 <|
    PetersenLocalChildren.push thetaPair4734i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i0 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5833,s5834,s5835,s5836]) (hints := [6840,6840,6968,0,777,6582,905,1,6968,6582,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5833,s5834,s5835,s5836], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5833) (b5833) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5834) (b5834) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5835) (b5835) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5836) (b5836) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i1 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5837,s2957,s4745,s5838]) (hints := [5934,6582,5934,0,6328,6840,8901,1,5934,6840,5934,2,6062,6582,8901,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5837,s2957,s4745,s5838], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5837) (b5837) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2957) (b2957) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4745) (b4745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5838) (b5838) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i2 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5839,s5840,s5841,s5842,s5843,s5844]) (hints := [6584,6584,7480,0,4528,1,1675,2,7480,3,7480,4,6584,6584,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5839,s5840,s5841,s5842,s5843,s5844], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5839) (b5839) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5840) (b5840) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5841) (b5841) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5842) (b5842) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5843) (b5843) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5844) (b5844) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i3 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5845,s5846,s5847,s5848]) (hints := [7470,4518,7470,0,4534,6582,2697,1,7470,6582,7470,2,4518,4518,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5845,s5846,s5847,s5848], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5845) (b5845) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5846) (b5846) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5847) (b5847) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5848) (b5848) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i4 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5849,s5850,s5851,s5852]) (hints := [13646,10710,13646,0,2486,6582,4745,1,13646,6582,13646,2,10710,10710,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5849,s5850,s5851,s5852], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5849) (b5849) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5850) (b5850) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5851) (b5851) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5852) (b5852) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i5 : PetersenLocalChildren.PairOK tgt 8 s5832 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5853,s5854,s5904,s5905]) (hints := [13614,6582,13614,0,2518,10710,8841,1,13614,10710,13614,2,6582,6582,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5853,s5854,s5904,s5905], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5853) (b5853) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5854) (b5854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5904) (b5904) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5905) (b5905) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i6 : PetersenLocalChildren.PairOK tgt 8 s5832 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5906,s5907,s5908,s5909]) (hints := [8645,8645,8901,0,393,905,5934,1,8901,905,8901,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5906,s5907,s5908,s5909], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5906) (b5906) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5907) (b5907) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5908) (b5908) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5909) (b5909) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i7 : PetersenLocalChildren.PairOK tgt 8 s5832 (word1,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5910,s5911,s5912,s5913,s5914,s5915]) (hints := [907,907,1675,0,7224,1,7480,2,1675,3,1675,4,907,907,7480,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5910,s5911,s5912,s5913,s5914,s5915], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5910) (b5910) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5911) (b5911) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5912) (b5912) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5913) (b5913) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5914) (b5914) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5915) (b5915) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i8 : PetersenLocalChildren.PairOK tgt 8 s5832 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5916,s5917,s5918,s5919]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5916,s5917,s5918,s5919], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5916) (b5916) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5917) (b5917) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5918) (b5918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5919) (b5919) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i9 : PetersenLocalChildren.PairOK tgt 8 s5832 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5920,s5921,s5964,s5965]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5920,s5921,s5964,s5965], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5920) (b5920) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5921) (b5921) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5964) (b5964) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5965) (b5965) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i10 : PetersenLocalChildren.PairOK tgt 8 s5832 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5966,s5967,s6008,s6009]) (hints := [905,905,8841,0,453,8645,13614,1,8841,8645,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5966,s5967,s6008,s6009], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5966) (b5966) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5967) (b5967) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6008) (b6008) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6009) (b6009) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i11 : PetersenLocalChildren.PairOK tgt 8 s5832 (word0,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6010,s6011,s6012,s6013]) (hints := [8901,8901,7478,0,1673,5934,1673,1,9925,5934,7478,2,8901,8901,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6010,s6011,s6012,s6013], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6010) (b6010) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6011) (b6011) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6012) (b6012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6013) (b6013) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i12 : PetersenLocalChildren.PairOK tgt 8 s5832 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6014,s6015,s6016,s6017]) (hints := [8901,8901,10437,0,2185,6966,2697,1,10437,6966,10437,2,8901,8901,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6014,s6015,s6016,s6017], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6014) (b6014) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6015) (b6015) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6016) (b6016) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6017) (b6017) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i13 : PetersenLocalChildren.PairOK tgt 8 s5832 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6018,s6019,s6068,s6069]) (hints := [8901,8901,12485,0,4233,5934,4745,1,12485,5934,12485,2,8901,8901,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6018,s6019,s6068,s6069], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6018) (b6018) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6019) (b6019) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6068) (b6068) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6069) (b6069) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i14 : PetersenLocalChildren.PairOK tgt 8 s5832 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6070,s6071,s6072,s6073]) (hints := [5934,5934,13614,0,8841,8901,8841,1,8837,8901,13614,2,8837,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6070,s6071,s6072,s6073], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6070) (b6070) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6071) (b6071) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6072) (b6072) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6073) (b6073) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i15 : PetersenLocalChildren.PairOK tgt 8 s5832 (word25,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6074,s6075,s6076,s6077]) (hints := [1673,1673,2697,0,7470,7478,7470,1,2697,7478,2697,2,1673,1673,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6074,s6075,s6076,s6077], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6074) (b6074) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6075) (b6075) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6076) (b6076) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6077) (b6077) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i16 : PetersenLocalChildren.PairOK tgt 8 s5832 (word25,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6078,s6079,s6080,s6081]) (hints := [1673,1673,4745,0,3382,7478,13646,1,4745,7478,4745,2,1673,1673,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6078,s6079,s6080,s6081], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6078) (b6078) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6079) (b6079) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6080) (b6080) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6081) (b6081) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i17 : PetersenLocalChildren.PairOK tgt 8 s5832 (word25,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6082,s6083,s6084,s6085]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6082,s6083,s6084,s6085], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6082) (b6082) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6083) (b6083) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6084) (b6084) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6085) (b6085) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i18 : PetersenLocalChildren.PairOK tgt 8 s5832 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6086,s6087,s6088,s6089]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6086,s6087,s6088,s6089], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6086) (b6086) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6087) (b6087) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6088) (b6088) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6089) (b6089) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i19 : PetersenLocalChildren.PairOK tgt 8 s5832 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6090,s6091,s6092,s6093]) (hints := [2697,2697,8841,0,2245,10437,14646,1,8841,10437,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6090,s6091,s6092,s6093], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6090) (b6090) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6091) (b6091) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6092) (b6092) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6093) (b6093) <|
    PetersenLocalChildren.nil
private theorem thetaPair5832i20 : PetersenLocalChildren.PairOK tgt 8 s5832 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6094,s6095,s6096,s6097]) (hints := [4745,4745,8841,0,4293,12485,13614,1,8841,12485,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6094,s6095,s6096,s6097], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6094) (b6094) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6095) (b6095) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6096) (b6096) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6097) (b6097) <|
    PetersenLocalChildren.nil
theorem b5832 : Blocked tgt 9 s5832 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word25),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word25),(word1,word5),(word1,word2),(word1,word4),(word0,word25),(word0,word5),(word0,word2),(word0,word4),(word25,word5),(word25,word2),(word25,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s5832 p
  exact
    PetersenLocalChildren.push thetaPair5832i0 <|
    PetersenLocalChildren.push thetaPair5832i1 <|
    PetersenLocalChildren.push thetaPair5832i2 <|
    PetersenLocalChildren.push thetaPair5832i3 <|
    PetersenLocalChildren.push thetaPair5832i4 <|
    PetersenLocalChildren.push thetaPair5832i5 <|
    PetersenLocalChildren.push thetaPair5832i6 <|
    PetersenLocalChildren.push thetaPair5832i7 <|
    PetersenLocalChildren.push thetaPair5832i8 <|
    PetersenLocalChildren.push thetaPair5832i9 <|
    PetersenLocalChildren.push thetaPair5832i10 <|
    PetersenLocalChildren.push thetaPair5832i11 <|
    PetersenLocalChildren.push thetaPair5832i12 <|
    PetersenLocalChildren.push thetaPair5832i13 <|
    PetersenLocalChildren.push thetaPair5832i14 <|
    PetersenLocalChildren.push thetaPair5832i15 <|
    PetersenLocalChildren.push thetaPair5832i16 <|
    PetersenLocalChildren.push thetaPair5832i17 <|
    PetersenLocalChildren.push thetaPair5832i18 <|
    PetersenLocalChildren.push thetaPair5832i19 <|
    PetersenLocalChildren.push thetaPair5832i20 <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i0 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6555,s6556,s6557,s6558]) (hints := [6840,6840,6968,0,777,6582,905,1,6968,6582,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6555,s6556,s6557,s6558], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6555) (b6555) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6556) (b6556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6557) (b6557) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6558) (b6558) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i1 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6559,s2599,s3013,s6560,s6561,s6582]) (hints := [5936,6584,5936,0,6330,6842,1,2,5936,6842,5936,3,6064,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6559,s2599,s3013,s6560,s6561,s6582], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6559) (b6559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2599) (b2599) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3013) (b3013) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6560) (b6560) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6561) (b6561) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6582) (b6582) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i2 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6583,s6584,s6585,s6586,s6587,s6588]) (hints := [6584,6584,7480,0,1547,1,1675,2,7480,3,7480,4,6584,6584,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6583,s6584,s6585,s6586,s6587,s6588], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6583) (b6583) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6584) (b6584) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6585) (b6585) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6586) (b6586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6587) (b6587) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6588) (b6588) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i3 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6589,s6590,s6591,s6592,s6593,s6594]) (hints := [4536,4778,0,1,4536,6584,11471,2,6584,6584,3,4,4778,4778,11471,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6589,s6590,s6591,s6592,s6593,s6594], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6589) (b6589) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6590) (b6590) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6591) (b6591) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6592) (b6592) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6593) (b6593) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6594) (b6594) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i4 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6591,s6594,s6595,s6596,s6597,s33,s6598,s6599]) (hints := [4780,4780,2,3,6586,6586,4,0,5554,6586,5,6,5554,4780,7,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s6591,s6594,s6595,s6596,s6597,s33,s6598,s6599], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6591) (b6591) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6594) (b6594) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6595) (b6595) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6596) (b6596) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6597) (b6597) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s33) (b33) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6598) (b6598) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6599) (b6599) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i5 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6600,s6601,s6609,s6610]) (hints := [13646,10710,13646,0,2486,6582,4745,1,13646,6582,13646,2,10710,10710,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6600,s6601,s6609,s6610], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6600) (b6600) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6601) (b6601) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6609) (b6609) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6610) (b6610) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i6 : PetersenLocalChildren.PairOK tgt 8 s6554 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6611,s6612,s6624,s6625]) (hints := [13614,6582,13614,0,2518,10710,8841,1,13614,10710,13614,2,6582,6582,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6611,s6612,s6624,s6625], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6611) (b6611) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6612) (b6612) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6624) (b6624) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6625) (b6625) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i7 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6626,s6627,s6633,s6634]) (hints := [9677,9677,5676,0,905,905,5934,1,905,905,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6626,s6627,s6633,s6634], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6626) (b6626) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6627) (b6627) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6633) (b6633) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6634) (b6634) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i8 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6635,s6636,s6637,s6638]) (hints := [905,905,1673,0,8653,9677,7478,1,1673,9677,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6635,s6636,s6637,s6638], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6635) (b6635) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6636) (b6636) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6637) (b6637) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6638) (b6638) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i9 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6639,s6640,s6672,s6673,s6674,s6675]) (hints := [907,907,11471,0,6970,6970,1,2,11471,6970,11471,3,907,907,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6639,s6640,s6672,s6673,s6674,s6675], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6639) (b6639) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6640) (b6640) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6672) (b6672) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6673) (b6673) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6674) (b6674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6675) (b6675) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i10 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6676,s6677,s656,s6678,s6679,s6680,s6681,s6715]) (hints := [909,909,0,1,9681,9681,2,3,9681,9681,4,5,909,909,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6676,s6677,s656,s6678,s6679,s6680,s6681,s6715], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6676) (b6676) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6677) (b6677) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s656) (b656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6678) (b6678) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6679) (b6679) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6680) (b6680) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6681) (b6681) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6715) (b6715) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i11 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6716,s6717,s6721,s6722]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6716,s6717,s6721,s6722], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6716) (b6716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6717) (b6717) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6721) (b6721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6722) (b6722) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i12 : PetersenLocalChildren.PairOK tgt 8 s6554 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6723,s6724,s6728,s6729]) (hints := [905,905,8841,0,1485,9677,13614,1,8841,9677,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6723,s6724,s6728,s6729], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6723) (b6723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6724) (b6724) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6728) (b6728) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6729) (b6729) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i13 : PetersenLocalChildren.PairOK tgt 8 s6554 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6730,s6731,s6732,s6733]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6730,s6731,s6732,s6733], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6730) (b6730) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6731) (b6731) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6732) (b6732) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6733) (b6733) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i14 : PetersenLocalChildren.PairOK tgt 8 s6554 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6734,s6735,s6766,s6767,s6768,s6769]) (hints := [11471,5936,11471,0,6968,6968,1,2,11471,6968,11471,3,11983,5936,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6734,s6735,s6766,s6767,s6768,s6769], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6734) (b6734) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6735) (b6735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6766) (b6766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6767) (b6767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6768) (b6768) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6769) (b6769) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i15 : PetersenLocalChildren.PairOK tgt 8 s6554 (word0,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6734,s6767,s6770,s2320,s6771,s6772,s6773,s6774]) (hints := [9937,5938,2,0,9937,6970,3,4,6970,6970,5,1,5938,5938,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6734,s6767,s6770,s2320,s6771,s6772,s6773,s6774], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6734) (b6734) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6767) (b6767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6770) (b6770) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2320) (b2320) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6771) (b6771) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6772) (b6772) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6773) (b6773) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6774) (b6774) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i16 : PetersenLocalChildren.PairOK tgt 8 s6554 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6775,s6776,s6786,s6787]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6775,s6776,s6786,s6787], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6775) (b6775) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6776) (b6776) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6786) (b6786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6787) (b6787) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i17 : PetersenLocalChildren.PairOK tgt 8 s6554 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6788,s6789,s6793,s6794]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6788,s6789,s6793,s6794], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6788) (b6788) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6789) (b6789) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6793) (b6793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6794) (b6794) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i18 : PetersenLocalChildren.PairOK tgt 8 s6554 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6795,s6796,s6797,s6798]) (hints := [1673,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,1673,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6795,s6796,s6797,s6798], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6795) (b6795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6796) (b6796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6797) (b6797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6798) (b6798) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i19 : PetersenLocalChildren.PairOK tgt 8 s6554 (word6,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6799,s6800,s4573,s6801,s6802,s6803,s6804,s6805]) (hints := [1677,1677,0,1,7482,7482,2,3,7482,7482,4,5,1677,1677,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6799,s6800,s4573,s6801,s6802,s6803,s6804,s6805], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6799) (b6799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6800) (b6800) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4573) (b4573) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6801) (b6801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6802) (b6802) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6803) (b6803) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6804) (b6804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6805) (b6805) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i20 : PetersenLocalChildren.PairOK tgt 8 s6554 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6806,s6807,s6808,s6809]) (hints := [1673,1673,4745,0,12493,7478,13517,1,4745,7478,4745,2,1673,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6806,s6807,s6808,s6809], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6806) (b6806) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6807) (b6807) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6808) (b6808) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6809) (b6809) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i21 : PetersenLocalChildren.PairOK tgt 8 s6554 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6810,s6811,s6812,s6813]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6810,s6811,s6812,s6813], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6810) (b6810) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6811) (b6811) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6812) (b6812) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6813) (b6813) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i22 : PetersenLocalChildren.PairOK tgt 8 s6554 (word5,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s6814,s6815,s6816,s6817]) (hints := [2698,11470,0,1,2698,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s6814,s6815,s6816,s6817], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6814) (b6814) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6815) (b6815) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6816) (b6816) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6817) (b6817) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i23 : PetersenLocalChildren.PairOK tgt 8 s6554 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6818,s6819,s6852,s6853,s6854,s6855]) (hints := [4747,11471,4747,0,14680,1,14680,2,4747,3,4747,4,11471,11471,14680,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6818,s6819,s6852,s6853,s6854,s6855], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6818) (b6818) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6819) (b6819) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6852) (b6852) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6853) (b6853) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6854) (b6854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6855) (b6855) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i24 : PetersenLocalChildren.PairOK tgt 8 s6554 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6856,s6857,s6858,s6859]) (hints := [8841,3213,8841,0,3277,11469,14646,1,8841,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6856,s6857,s6858,s6859], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6856) (b6856) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6857) (b6857) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6858) (b6858) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6859) (b6859) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i25 : PetersenLocalChildren.PairOK tgt 8 s6554 (word66,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6860,s6861,s6862,s6888,s6889,s6917,s6918,s6919]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6860,s6861,s6862,s6888,s6889,s6917,s6918,s6919], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6860) (b6860) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6861) (b6861) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6862) (b6862) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6888) (b6888) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6889) (b6889) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6917) (b6917) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6918) (b6918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6919) (b6919) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i26 : PetersenLocalChildren.PairOK tgt 8 s6554 (word66,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6920,s6921,s6922,s6949,s6950,s6976,s6977,s6978]) (hints := [8845,0,8845,1,14650,2,14650,3,8845,4,8845,5,14650,6,14650,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6920,s6921,s6922,s6949,s6950,s6976,s6977,s6978], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6920) (b6920) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6921) (b6921) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6922) (b6922) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6949) (b6949) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6950) (b6950) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6976) (b6976) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6977) (b6977) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6978) (b6978) <|
    PetersenLocalChildren.nil
private theorem thetaPair6554i27 : PetersenLocalChildren.PairOK tgt 8 s6554 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6979,s6980,s6981,s6982]) (hints := [4745,4745,8841,0,5325,13517,13614,1,8841,13517,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6979,s6980,s6981,s6982], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6979) (b6979) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6980) (b6980) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6981) (b6981) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6982) (b6982) <|
    PetersenLocalChildren.nil
theorem b6554 : Blocked tgt 9 s6554 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word66),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word66),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word66),(word0,word2),(word0,word4),(word6,word5),(word6,word66),(word6,word2),(word6,word4),(word5,word66),(word5,word2),(word5,word4),(word66,word2),(word66,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s6554 p
  exact
    PetersenLocalChildren.push thetaPair6554i0 <|
    PetersenLocalChildren.push thetaPair6554i1 <|
    PetersenLocalChildren.push thetaPair6554i2 <|
    PetersenLocalChildren.push thetaPair6554i3 <|
    PetersenLocalChildren.push thetaPair6554i4 <|
    PetersenLocalChildren.push thetaPair6554i5 <|
    PetersenLocalChildren.push thetaPair6554i6 <|
    PetersenLocalChildren.push thetaPair6554i7 <|
    PetersenLocalChildren.push thetaPair6554i8 <|
    PetersenLocalChildren.push thetaPair6554i9 <|
    PetersenLocalChildren.push thetaPair6554i10 <|
    PetersenLocalChildren.push thetaPair6554i11 <|
    PetersenLocalChildren.push thetaPair6554i12 <|
    PetersenLocalChildren.push thetaPair6554i13 <|
    PetersenLocalChildren.push thetaPair6554i14 <|
    PetersenLocalChildren.push thetaPair6554i15 <|
    PetersenLocalChildren.push thetaPair6554i16 <|
    PetersenLocalChildren.push thetaPair6554i17 <|
    PetersenLocalChildren.push thetaPair6554i18 <|
    PetersenLocalChildren.push thetaPair6554i19 <|
    PetersenLocalChildren.push thetaPair6554i20 <|
    PetersenLocalChildren.push thetaPair6554i21 <|
    PetersenLocalChildren.push thetaPair6554i22 <|
    PetersenLocalChildren.push thetaPair6554i23 <|
    PetersenLocalChildren.push thetaPair6554i24 <|
    PetersenLocalChildren.push thetaPair6554i25 <|
    PetersenLocalChildren.push thetaPair6554i26 <|
    PetersenLocalChildren.push thetaPair6554i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i0 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6814,s6559,s153]) (hints := [6581,0,6839,6581,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s6814,s6559,s153], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6814) (b6814) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6559) (b6559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s153) (b153) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i1 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6984,s1025,s6985,s6986]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s6984,s1025,s6985,s6986], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6984) (b6984) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1025) (b1025) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6985) (b6985) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6986) (b6986) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i2 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6814,s2599,s3013,s2622]) (hints := [5934,0,5934,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6814,s2599,s3013,s2622], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6814) (b6814) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2599) (b2599) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3013) (b3013) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2622) (b2622) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i3 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6987,s4749,s5272,s4786,s6988,s6111,s6989,s6112]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6987,s4749,s5272,s4786,s6988,s6111,s6989,s6112], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6987) (b6987) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4749) (b4749) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5272) (b5272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4786) (b4786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6988) (b6988) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6111) (b6111) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6989) (b6989) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6112) (b6112) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i4 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6990,s6991,s6992,s6815,s6817,s6993,s6994]) (hints := [0,1,2,3,4,5,11472,6,11472]) (by decide +kernel) ?_
  change ∀ x ∈ [s6990,s6991,s6992,s6815,s6817,s6993,s6994], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6990) (b6990) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6991) (b6991) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6992) (b6992) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6815) (b6815) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6817) (b6817) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6993) (b6993) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6994) (b6994) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i5 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6814,s6994,s5,s927,s6995,s6996]) (hints := [2,0,3,4,1,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6814,s6994,s5,s927,s6995,s6996], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6814) (b6814) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6994) (b6994) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6995) (b6995) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6996) (b6996) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i6 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6997,s6998,s7007,s7008]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s6997,s6998,s7007,s7008], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6997) (b6997) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6998) (b6998) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7007) (b7007) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7008) (b7008) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i7 : PetersenLocalChildren.PairOK tgt 8 s6983 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7009,s7010,s7048,s7056,s7057,s7058,s7100,s7101]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s7009,s7010,s7048,s7056,s7057,s7058,s7100,s7101], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7009) (b7009) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7010) (b7010) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7048) (b7048) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7056) (b7056) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7057) (b7057) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7058) (b7058) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7100) (b7100) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7101) (b7101) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i8 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7102,s7103]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s7102,s7103], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7102) (b7102) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7103) (b7103) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i9 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s153,s2622,s7104,s7105]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s153,s2622,s7104,s7105], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s153) (b153) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2622) (b2622) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7104) (b7104) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7105) (b7105) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i10 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7106,s7107]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s7106,s7107], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7106) (b7106) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7107) (b7107) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i11 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7108,s7109]) (hints := [4774,4774,0,11467,6838,11467,6838,6838,1,11467,4774,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s7108,s7109], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7108) (b7108) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7109) (b7109) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i12 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7110,s7111,s7112,s7113]) (hints := [4776,4776,0,6840,6840,1,6840,6840,2,4776,4776,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7110,s7111,s7112,s7113], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7110) (b7110) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7111) (b7111) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7112) (b7112) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7113) (b7113) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i13 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i14 : PetersenLocalChildren.PairOK tgt 8 s6983 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7114,s7117]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s7114,s7117], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7114) (b7114) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7117) (b7117) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i15 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i16 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i17 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7118,s7119]) (hints := [9675,9675,11467,6966,6966,0,11467,6966,11467,9675,9675,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s7118,s7119], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7118) (b7118) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7119) (b7119) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i18 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7120,s1172,s7121,s7122]) (hints := [905,905,0,9677,9677,1,9677,9677,2,905,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7120,s1172,s7121,s7122], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7120) (b7120) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1172) (b1172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7121) (b7121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7122) (b7122) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i19 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i20 : PetersenLocalChildren.PairOK tgt 8 s6983 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i21 : PetersenLocalChildren.PairOK tgt 8 s6983 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i22 : PetersenLocalChildren.PairOK tgt 8 s6983 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7123,s7124]) (hints := [11467,5932,11467,6964,6964,0,11467,6964,11467,5932,5932,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s7123,s7124], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7123) (b7123) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7124) (b7124) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i23 : PetersenLocalChildren.PairOK tgt 8 s6983 (word0,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7125,s3211,s7126,s7127]) (hints := [5934,5934,0,6966,6966,1,6966,6966,2,5934,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7125,s3211,s7126,s7127], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7125) (b7125) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3211) (b3211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7126) (b7126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7127) (b7127) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i24 : PetersenLocalChildren.PairOK tgt 8 s6983 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i25 : PetersenLocalChildren.PairOK tgt 8 s6983 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i26 : PetersenLocalChildren.PairOK tgt 8 s6983 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i27 : PetersenLocalChildren.PairOK tgt 8 s6983 (word6,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7128,s5464,s7129,s7130]) (hints := [1673,1673,0,7478,7478,1,7478,7478,2,1673,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7128,s5464,s7129,s7130], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7128) (b7128) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5464) (b5464) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7129) (b7129) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7130) (b7130) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i28 : PetersenLocalChildren.PairOK tgt 8 s6983 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i29 : PetersenLocalChildren.PairOK tgt 8 s6983 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i30 : PetersenLocalChildren.PairOK tgt 8 s6983 (word5,word66) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6993,s927,s7131]) (hints := [11468,11468,1,2696,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s6993,s927,s7131], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6993) (b6993) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7131) (b7131) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i31 : PetersenLocalChildren.PairOK tgt 8 s6983 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7132,s7133]) (hints := [11467,11467,13515,14676,0,14676,13515,1,13515,11467,11467,14676]) (by decide +kernel) ?_
  change ∀ x ∈ [s7132,s7133], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7132) (b7132) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7133) (b7133) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i32 : PetersenLocalChildren.PairOK tgt 8 s6983 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair6983i33 : PetersenLocalChildren.PairOK tgt 8 s6983 (word66,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7134,s7135,s7136,s7137]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s7134,s7135,s7136,s7137], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7134) (b7134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7135) (b7135) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7136) (b7136) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7137) (b7137) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i34 : PetersenLocalChildren.PairOK tgt 8 s6983 (word66,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7138,s7139,s7140,s7141]) (hints := [8841,0,8841,14646,1,14646,8841,2,8841,14646,3,14646]) (by decide +kernel) ?_
  change ∀ x ∈ [s7138,s7139,s7140,s7141], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7138) (b7138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7139) (b7139) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7140) (b7140) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7141) (b7141) <|
    PetersenLocalChildren.nil
private theorem thetaPair6983i35 : PetersenLocalChildren.PairOK tgt 8 s6983 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b6983 : Blocked tgt 9 s6983 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word66),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word66),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word66),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word66),(word0,word2),(word0,word4),(word6,word5),(word6,word66),(word6,word2),(word6,word4),(word5,word66),(word5,word2),(word5,word4),(word66,word2),(word66,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s6983 p
  exact
    PetersenLocalChildren.push thetaPair6983i0 <|
    PetersenLocalChildren.push thetaPair6983i1 <|
    PetersenLocalChildren.push thetaPair6983i2 <|
    PetersenLocalChildren.push thetaPair6983i3 <|
    PetersenLocalChildren.push thetaPair6983i4 <|
    PetersenLocalChildren.push thetaPair6983i5 <|
    PetersenLocalChildren.push thetaPair6983i6 <|
    PetersenLocalChildren.push thetaPair6983i7 <|
    PetersenLocalChildren.push thetaPair6983i8 <|
    PetersenLocalChildren.push thetaPair6983i9 <|
    PetersenLocalChildren.push thetaPair6983i10 <|
    PetersenLocalChildren.push thetaPair6983i11 <|
    PetersenLocalChildren.push thetaPair6983i12 <|
    PetersenLocalChildren.push thetaPair6983i13 <|
    PetersenLocalChildren.push thetaPair6983i14 <|
    PetersenLocalChildren.push thetaPair6983i15 <|
    PetersenLocalChildren.push thetaPair6983i16 <|
    PetersenLocalChildren.push thetaPair6983i17 <|
    PetersenLocalChildren.push thetaPair6983i18 <|
    PetersenLocalChildren.push thetaPair6983i19 <|
    PetersenLocalChildren.push thetaPair6983i20 <|
    PetersenLocalChildren.push thetaPair6983i21 <|
    PetersenLocalChildren.push thetaPair6983i22 <|
    PetersenLocalChildren.push thetaPair6983i23 <|
    PetersenLocalChildren.push thetaPair6983i24 <|
    PetersenLocalChildren.push thetaPair6983i25 <|
    PetersenLocalChildren.push thetaPair6983i26 <|
    PetersenLocalChildren.push thetaPair6983i27 <|
    PetersenLocalChildren.push thetaPair6983i28 <|
    PetersenLocalChildren.push thetaPair6983i29 <|
    PetersenLocalChildren.push thetaPair6983i30 <|
    PetersenLocalChildren.push thetaPair6983i31 <|
    PetersenLocalChildren.push thetaPair6983i32 <|
    PetersenLocalChildren.push thetaPair6983i33 <|
    PetersenLocalChildren.push thetaPair6983i34 <|
    PetersenLocalChildren.push thetaPair6983i35 <|
    PetersenLocalChildren.nil
theorem b8040 : Blocked tgt 9 s8040 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a000000000a0a0a0a,0xa0a00000a0a00000a0a00000a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s7142) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b7142
theorem b10196 : Blocked tgt 9 s10196 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a,0xa000a000a000a000a000a000a000a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5477) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5477
private theorem thetaPair11525i0 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word22) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11526,s11527,s11612,s11613,s11647]) (hints := [5551,5551,6841,0,1,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s11526,s11527,s11612,s11613,s11647], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11526) (b11526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11527) (b11527) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11612) (b11612) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11613) (b11613) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11647) (b11647) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i1 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11648,s1136,s11649,s11650]) (hints := [6968,5292,6968,0,5294,5550,9677,1,6968,5550,6968,2,5292,5292,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11648,s1136,s11649,s11650], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11648) (b11648) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1136) (b1136) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11649) (b11649) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11650) (b11650) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i2 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11526,s1719,s2688,s3152]) (hints := [5550,5550,6062,0,9933,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11526,s1719,s2688,s3152], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11526) (b11526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1719) (b1719) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2688) (b2688) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3152) (b3152) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i3 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11651,s5071,s5402,s11652,s6429,s11653]) (hints := [7738,6584,7738,0,4528,5552,1,2,7738,5552,7738,3,6584,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11651,s5071,s5402,s11652,s6429,s11653], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11651) (b11651) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5071) (b5071) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5402) (b5402) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11652) (b11652) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6429) (b6429) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11653) (b11653) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i4 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11654,s7104,s11655,s11656]) (hints := [5550,5550,7470,0,4534,6582,11469,1,7470,6582,7470,2,5550,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11654,s7104,s11655,s11656], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11654) (b11654) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7104) (b7104) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11655) (b11655) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11656) (b11656) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i5 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11657,s8004,s11658,s11659]) (hints := [9678,9678,13646,0,1454,5550,13517,1,13646,5550,13646,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11657,s8004,s11658,s11659], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11657) (b11657) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8004) (b8004) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11658) (b11658) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11659) (b11659) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i6 : PetersenLocalChildren.PairOK tgt 8 s11525 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11660,s9922,s10128,s11661,s10857,s11662]) (hints := [14906,5552,14906,0,1488,9680,1,2,14906,9680,14906,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11660,s9922,s10128,s11661,s10857,s11662], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11660) (b11660) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9922) (b9922) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10128) (b10128) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11661) (b11661) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10857) (b10857) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11662) (b11662) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i7 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11663,s11664,s11683,s11093,s11684,s11685]) (hints := [9679,6842,9679,0,6970,1,6970,2,9679,3,9679,4,6842,6842,6970,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11663,s11664,s11683,s11093,s11684,s11685], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11663) (b11663) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11664) (b11664) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11683) (b11683) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11093) (b11093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11684) (b11684) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11685) (b11685) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i8 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11526,s8,s201,s202]) (hints := [5934,6840,6062,0,5934,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11526,s8,s201,s202], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11526) (b11526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8) (b8) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s201) (b201) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s202) (b202) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i9 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11686,s11687,s11704,s11705,s11706,s11707]) (hints := [7480,6842,7480,0,7738,1,7738,2,7480,3,7480,4,6842,6842,7738,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11686,s11687,s11704,s11705,s11706,s11707], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11686) (b11686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11687) (b11687) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11704) (b11704) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11705) (b11705) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11706) (b11706) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11707) (b11707) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i10 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11708,s11709,s11710,s11711,s11712,s11713]) (hints := [11471,4778,11471,0,6826,6842,1,2,11471,6842,11471,3,4778,4778,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11708,s11709,s11710,s11711,s11712,s11713], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11708) (b11708) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11709) (b11709) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11710) (b11710) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11711) (b11711) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11712) (b11712) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11713) (b11713) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i11 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11714,s11715,s11716,s11717,s11718,s11719]) (hints := [13519,2714,13519,0,6810,6842,1,2,13519,6842,13519,3,2714,2714,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11714,s11715,s11716,s11717,s11718,s11719], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11714) (b11714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11715) (b11715) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11716) (b11716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11717) (b11717) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11718) (b11718) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11719) (b11719) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i12 : PetersenLocalChildren.PairOK tgt 8 s11525 (word22,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11720,s11721,s11737,s11738,s11739,s11740]) (hints := [13616,6842,13616,0,14906,1,14906,2,13616,3,13616,4,6842,6842,14906,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11720,s11721,s11737,s11738,s11739,s11740], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11720) (b11720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11721) (b11721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11737) (b11737) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11738) (b11738) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11739) (b11739) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11740) (b11740) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i13 : PetersenLocalChildren.PairOK tgt 8 s11525 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11741,s11742,s11743,s11744]) (hints := [9677,9677,5804,0,6968,6968,6062,1,6968,6968,5804,2,9677,9677,6062,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11741,s11742,s11743,s11744], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11741) (b11741) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11742) (b11742) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11743) (b11743) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11744) (b11744) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i14 : PetersenLocalChildren.PairOK tgt 8 s11525 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11745,s11746,s11747,s11748]) (hints := [8645,8645,7736,0,8653,9677,7478,1,9669,9677,7736,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11745,s11746,s11747,s11748], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11745) (b11745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11746) (b11746) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11747) (b11747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11748) (b11748) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i15 : PetersenLocalChildren.PairOK tgt 8 s11525 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11749,s11750,s11751,s11752]) (hints := [9677,9677,11469,0,4920,6968,7470,1,11469,6968,11469,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11749,s11750,s11751,s11752], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11749) (b11749) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11750) (b11750) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11751) (b11751) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11752) (b11752) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i16 : PetersenLocalChildren.PairOK tgt 8 s11525 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11753,s11754,s11755,s11756]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11753,s11754,s11755,s11756], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11753) (b11753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11754) (b11754) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11755) (b11755) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11756) (b11756) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i17 : PetersenLocalChildren.PairOK tgt 8 s11525 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11757,s11758,s11759,s11760]) (hints := [1421,1421,14904,0,1485,9677,13614,1,9613,9677,14904,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11757,s11758,s11759,s11760], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11757) (b11757) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11758) (b11758) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11759) (b11759) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11760) (b11760) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i18 : PetersenLocalChildren.PairOK tgt 8 s11525 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11761,s11762,s11763,s11764]) (hints := [7094,7094,7478,0,7736,6062,7736,1,7478,6062,7478,2,7736,7094,7736,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11761,s11762,s11763,s11764], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11761) (b11761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11762) (b11762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11763) (b11763) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11764) (b11764) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i19 : PetersenLocalChildren.PairOK tgt 8 s11525 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11765,s11766,s11767,s11768]) (hints := [11469,6062,11469,0,5046,7094,2697,1,11469,7094,11469,2,6062,6062,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11765,s11766,s11767,s11768], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11765) (b11765) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11766) (b11766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11767) (b11767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11768) (b11768) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i20 : PetersenLocalChildren.PairOK tgt 8 s11525 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11769,s11770,s11771,s11772]) (hints := [13517,10190,13517,0,1966,6062,4745,1,13517,6062,13517,2,10190,10190,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11769,s11770,s11771,s11772], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11769) (b11769) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11770) (b11770) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11771) (b11771) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11772) (b11772) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i21 : PetersenLocalChildren.PairOK tgt 8 s11525 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11773,s11774,s11775,s11776]) (hints := [6062,6062,13614,0,14904,10190,14904,1,13614,10190,13614,2,14904,6062,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11773,s11774,s11775,s11776], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11773) (b11773) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11774) (b11774) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11775) (b11775) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11776) (b11776) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i22 : PetersenLocalChildren.PairOK tgt 8 s11525 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11777,s11778,s11779,s11780]) (hints := [10437,5672,10437,0,10445,7736,11469,1,10437,7736,10437,2,11461,5672,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11777,s11778,s11779,s11780], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11777) (b11777) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11778) (b11778) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11779) (b11779) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11780) (b11780) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i23 : PetersenLocalChildren.PairOK tgt 8 s11525 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11781,s11782,s11783,s11784]) (hints := [12485,3608,12485,0,12493,7736,13517,1,12485,7736,12485,2,13509,3608,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11781,s11782,s11783,s11784], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11781) (b11781) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11782) (b11782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11783) (b11783) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11784) (b11784) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i24 : PetersenLocalChildren.PairOK tgt 8 s11525 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11785,s11786,s11787,s11788]) (hints := [7736,7736,14904,0,3414,11606,13614,1,14904,11606,14904,2,7736,7736,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11785,s11786,s11787,s11788], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11785) (b11785) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11786) (b11786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11787) (b11787) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11788) (b11788) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i25 : PetersenLocalChildren.PairOK tgt 8 s11525 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11789,s11790,s11793,s11794]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11789,s11790,s11793,s11794], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11789) (b11789) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11790) (b11790) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11793) (b11793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11794) (b11794) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i26 : PetersenLocalChildren.PairOK tgt 8 s11525 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11795,s11796,s11797,s11798]) (hints := [3213,3213,12840,0,3277,11469,14904,1,11405,11469,12840,2,3213,3213,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11795,s11796,s11797,s11798], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11795) (b11795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11796) (b11796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11797) (b11797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11798) (b11798) <|
    PetersenLocalChildren.nil
private theorem thetaPair11525i27 : PetersenLocalChildren.PairOK tgt 8 s11525 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11799,s11800,s11801,s11802]) (hints := [5261,5261,10776,0,5325,13517,14904,1,13453,13517,10776,2,5261,5261,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11799,s11800,s11801,s11802], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11799) (b11799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11800) (b11800) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11801) (b11801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11802) (b11802) <|
    PetersenLocalChildren.nil
theorem b11525 : Blocked tgt 9 s11525 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word22),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word22,word1),(word22,word0),(word22,word6),(word22,word5),(word22,word2),(word22,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s11525 p
  exact
    PetersenLocalChildren.push thetaPair11525i0 <|
    PetersenLocalChildren.push thetaPair11525i1 <|
    PetersenLocalChildren.push thetaPair11525i2 <|
    PetersenLocalChildren.push thetaPair11525i3 <|
    PetersenLocalChildren.push thetaPair11525i4 <|
    PetersenLocalChildren.push thetaPair11525i5 <|
    PetersenLocalChildren.push thetaPair11525i6 <|
    PetersenLocalChildren.push thetaPair11525i7 <|
    PetersenLocalChildren.push thetaPair11525i8 <|
    PetersenLocalChildren.push thetaPair11525i9 <|
    PetersenLocalChildren.push thetaPair11525i10 <|
    PetersenLocalChildren.push thetaPair11525i11 <|
    PetersenLocalChildren.push thetaPair11525i12 <|
    PetersenLocalChildren.push thetaPair11525i13 <|
    PetersenLocalChildren.push thetaPair11525i14 <|
    PetersenLocalChildren.push thetaPair11525i15 <|
    PetersenLocalChildren.push thetaPair11525i16 <|
    PetersenLocalChildren.push thetaPair11525i17 <|
    PetersenLocalChildren.push thetaPair11525i18 <|
    PetersenLocalChildren.push thetaPair11525i19 <|
    PetersenLocalChildren.push thetaPair11525i20 <|
    PetersenLocalChildren.push thetaPair11525i21 <|
    PetersenLocalChildren.push thetaPair11525i22 <|
    PetersenLocalChildren.push thetaPair11525i23 <|
    PetersenLocalChildren.push thetaPair11525i24 <|
    PetersenLocalChildren.push thetaPair11525i25 <|
    PetersenLocalChildren.push thetaPair11525i26 <|
    PetersenLocalChildren.push thetaPair11525i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i0 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word22) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s12064,s927,s12065,s12128,s12129]) (hints := [0,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s12064,s927,s12065,s12128,s12129], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12064) (b12064) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12065) (b12065) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12128) (b12128) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12129) (b12129) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i1 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12064,s11526,s20,s202]) (hints := [5550,0,1,5550,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12064,s11526,s20,s202], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12064) (b12064) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11526) (b11526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s20) (b20) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s202) (b202) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i2 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12130,s417,s1560,s12131]) (hints := [6968,0,6968,9677,1,9677,6968,2,6968,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12130,s417,s1560,s12131], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12130) (b12130) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s417) (b417) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1560) (b1560) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12131) (b12131) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i3 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12064,s11804,s1720,s2714]) (hints := [9933,0,1,9933,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12064,s11804,s1720,s2714], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12064) (b12064) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11804) (b11804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1720) (b1720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2714) (b2714) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i4 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12132,s3265,s4226,s5092,s5751,s5838,s12133,s6431]) (hints := [7740,0,7740,1,2,3,7740,4,7740,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12132,s3265,s4226,s5092,s5751,s5838,s12133,s6431], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12132) (b12132) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3265) (b3265) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4226) (b4226) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5092) (b5092) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5751) (b5751) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5838) (b5838) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12133) (b12133) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6431) (b6431) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i5 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12134,s6582,s7481,s12135]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12134,s6582,s7481,s12135], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12134) (b12134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6582) (b6582) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7481) (b7481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12135) (b12135) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i6 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12136,s7598,s8377,s12137]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12136,s7598,s8377,s12137], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12136) (b12136) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7598) (b7598) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8377) (b8377) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12137) (b12137) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i7 : PetersenLocalChildren.PairOK tgt 8 s12063 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12138,s8508,s9438,s9942,s10461,s10548,s12139,s10859]) (hints := [14908,0,14908,1,2,3,14908,4,14908,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12138,s8508,s9438,s9942,s10461,s10548,s12139,s10859], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12138) (b12138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8508) (b8508) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9438) (b9438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9942) (b9942) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10461) (b10461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10548) (b10548) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12139) (b12139) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10859) (b10859) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i8 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s11526,s1718,s3152]) (hints := [6840,0,1,6840,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s11526,s1718,s3152], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11526) (b11526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1718) (b1718) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3152) (b3152) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i9 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12140,s12141,s11286,s12142]) (hints := [9677,0,9677,6968,1,6968,9677,2,9677,6968,3,6968]) (by decide +kernel) ?_
  change ∀ x ∈ [s12140,s12141,s11286,s12142], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12140) (b12140) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12141) (b12141) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11286) (b11286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12142) (b12142) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i10 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s11804,s9,s11927]) (hints := [5934,0,1,5934,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s11804,s9,s11927], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11804) (b11804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9) (b9) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11927) (b11927) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i11 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12143,s12144,s12145,s12146]) (hints := [1673,0,1673,7736,1,7736,1673,2,1673,7736,3,7736]) (by decide +kernel) ?_
  change ∀ x ∈ [s12143,s12144,s12145,s12146], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12143) (b12143) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12144) (b12144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12145) (b12145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12146) (b12146) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i12 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12147,s12148,s12193,s12194,s12195,s12196,s12197,s12198]) (hints := [11473,0,11473,1,2,3,11473,4,11473,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12147,s12148,s12193,s12194,s12195,s12196,s12197,s12198], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12147) (b12147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12148) (b12148) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12193) (b12193) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12194) (b12194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12195) (b12195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12196) (b12196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12197) (b12197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12198) (b12198) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i13 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12199,s12200,s12245,s12246,s12247,s12248,s12249,s12250]) (hints := [13521,0,13521,1,2,3,13521,4,13521,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12199,s12200,s12245,s12246,s12247,s12248,s12249,s12250], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12199) (b12199) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12200) (b12200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12245) (b12245) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12246) (b12246) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12247) (b12247) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12248) (b12248) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12249) (b12249) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12250) (b12250) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i14 : PetersenLocalChildren.PairOK tgt 8 s12063 (word22,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12251,s12252,s12253,s12254]) (hints := [8841,0,8841,14904,1,14904,8841,2,8841,14904,3,14904]) (by decide +kernel) ?_
  change ∀ x ∈ [s12251,s12252,s12253,s12254], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12251) (b12251) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12252) (b12252) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12253) (b12253) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12254) (b12254) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i15 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12255,s11252,s12256,s12257]) (hints := [6968,0,6968,9677,1,9677,6968,2,6968,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12255,s11252,s12256,s12257], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12255) (b12255) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11252) (b11252) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12256) (b12256) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12257) (b12257) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i16 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s202,s2714,s3152,s11927,s201,s2688]) (hints := [4,0,3,5,2,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s202,s2714,s3152,s11927,s201,s2688], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s202) (b202) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2714) (b2714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3152) (b3152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11927) (b11927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s201) (b201) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2688) (b2688) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i17 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12258,s12259,s12260,s12261]) (hints := [7736,0,7736,1673,1,1673,7736,2,7736,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s12258,s12259,s12260,s12261], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12258) (b12258) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12259) (b12259) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12260) (b12260) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12261) (b12261) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i18 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12262,s12263,s12264,s12265]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12262,s12263,s12264,s12265], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12262) (b12262) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12263) (b12263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12264) (b12264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12265) (b12265) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i19 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12266,s12267,s12268,s12269]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12266,s12267,s12268,s12269], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12266) (b12266) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12267) (b12267) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12268) (b12268) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12269) (b12269) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i20 : PetersenLocalChildren.PairOK tgt 8 s12063 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12270,s12271,s12272,s12273]) (hints := [14904,0,14904,8841,1,8841,14904,2,14904,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s12270,s12271,s12272,s12273], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12270) (b12270) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12271) (b12271) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12272) (b12272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12273) (b12273) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i21 : PetersenLocalChildren.PairOK tgt 8 s12063 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12274,s12275,s12276,s12277]) (hints := [9677,9677,0,6968,6968,1,6968,6968,2,9677,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12274,s12275,s12276,s12277], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12274) (b12274) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12275) (b12275) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12276) (b12276) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12277) (b12277) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i22 : PetersenLocalChildren.PairOK tgt 8 s12063 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,7732,8649,9673,7474,9665,9673,7732,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i23 : PetersenLocalChildren.PairOK tgt 8 s12063 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i24 : PetersenLocalChildren.PairOK tgt 8 s12063 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i25 : PetersenLocalChildren.PairOK tgt 8 s12063 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,14900,1481,9673,13610,9609,9673,14900,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i26 : PetersenLocalChildren.PairOK tgt 8 s12063 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12278,s12279,s12280,s12281]) (hints := [7478,0,7478,7736,1,7736,7478,2,7478,7736,3,7736]) (by decide +kernel) ?_
  change ∀ x ∈ [s12278,s12279,s12280,s12281], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12278) (b12278) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12279) (b12279) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12280) (b12280) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12281) (b12281) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i27 : PetersenLocalChildren.PairOK tgt 8 s12063 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12282,s12283,s12284,s12285]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s12282,s12283,s12284,s12285], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12282) (b12282) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12283) (b12283) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12284) (b12284) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12285) (b12285) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i28 : PetersenLocalChildren.PairOK tgt 8 s12063 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12286,s12287,s12288,s12289]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s12286,s12287,s12288,s12289], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12286) (b12286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12287) (b12287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12288) (b12288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12289) (b12289) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i29 : PetersenLocalChildren.PairOK tgt 8 s12063 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12290,s12291,s12292,s12293]) (hints := [13614,0,13614,14904,1,14904,13614,2,13614,14904,3,14904]) (by decide +kernel) ?_
  change ∀ x ∈ [s12290,s12291,s12292,s12293], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12290) (b12290) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12291) (b12291) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12292) (b12292) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12293) (b12293) <|
    PetersenLocalChildren.nil
private theorem thetaPair12063i30 : PetersenLocalChildren.PairOK tgt 8 s12063 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,5668,10433,10441,7732,11465,10433,7732,10433,11457,5668,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i31 : PetersenLocalChildren.PairOK tgt 8 s12063 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,3604,12481,12489,7732,13513,12481,7732,12481,13505,3604,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i32 : PetersenLocalChildren.PairOK tgt 8 s12063 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7732,7732,14900,3410,11602,13610,14900,11602,14900,7732,7732,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i33 : PetersenLocalChildren.PairOK tgt 8 s12063 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i34 : PetersenLocalChildren.PairOK tgt 8 s12063 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,12836,3273,11465,14900,11401,11465,12836,3209,3209,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12063i35 : PetersenLocalChildren.PairOK tgt 8 s12063 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,10772,5321,13513,14900,13449,13513,10772,5257,5257,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b12063 : Blocked tgt 9 s12063 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word22),(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word22,word3),(word22,word1),(word22,word0),(word22,word6),(word22,word5),(word22,word2),(word22,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s12063 p
  exact
    PetersenLocalChildren.push thetaPair12063i0 <|
    PetersenLocalChildren.push thetaPair12063i1 <|
    PetersenLocalChildren.push thetaPair12063i2 <|
    PetersenLocalChildren.push thetaPair12063i3 <|
    PetersenLocalChildren.push thetaPair12063i4 <|
    PetersenLocalChildren.push thetaPair12063i5 <|
    PetersenLocalChildren.push thetaPair12063i6 <|
    PetersenLocalChildren.push thetaPair12063i7 <|
    PetersenLocalChildren.push thetaPair12063i8 <|
    PetersenLocalChildren.push thetaPair12063i9 <|
    PetersenLocalChildren.push thetaPair12063i10 <|
    PetersenLocalChildren.push thetaPair12063i11 <|
    PetersenLocalChildren.push thetaPair12063i12 <|
    PetersenLocalChildren.push thetaPair12063i13 <|
    PetersenLocalChildren.push thetaPair12063i14 <|
    PetersenLocalChildren.push thetaPair12063i15 <|
    PetersenLocalChildren.push thetaPair12063i16 <|
    PetersenLocalChildren.push thetaPair12063i17 <|
    PetersenLocalChildren.push thetaPair12063i18 <|
    PetersenLocalChildren.push thetaPair12063i19 <|
    PetersenLocalChildren.push thetaPair12063i20 <|
    PetersenLocalChildren.push thetaPair12063i21 <|
    PetersenLocalChildren.push thetaPair12063i22 <|
    PetersenLocalChildren.push thetaPair12063i23 <|
    PetersenLocalChildren.push thetaPair12063i24 <|
    PetersenLocalChildren.push thetaPair12063i25 <|
    PetersenLocalChildren.push thetaPair12063i26 <|
    PetersenLocalChildren.push thetaPair12063i27 <|
    PetersenLocalChildren.push thetaPair12063i28 <|
    PetersenLocalChildren.push thetaPair12063i29 <|
    PetersenLocalChildren.push thetaPair12063i30 <|
    PetersenLocalChildren.push thetaPair12063i31 <|
    PetersenLocalChildren.push thetaPair12063i32 <|
    PetersenLocalChildren.push thetaPair12063i33 <|
    PetersenLocalChildren.push thetaPair12063i34 <|
    PetersenLocalChildren.push thetaPair12063i35 <|
    PetersenLocalChildren.nil
theorem b13501 : Blocked tgt 9 s13501 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaa,0xaa00aa00aa00aa00aa00aa00aa00aa),(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12798) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12798
end PetersenSmallStarts.M191.Staged
