import M63StartData
import M63StartPins0
import M63StartL5B13
import M63StartL5B14
import M63StartL5B3
import M63StartL5B15
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b498 : Blocked tgt 6 s498 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s498 6 _ le
  decide +kernel
theorem b499 : Blocked tgt 6 s499 := by
  apply PetersenFastNode.node (nxt := #[s500,s501]) (hints := [716,716,2635,455,1430,455,2375,2375,2635,843,2119,2115,839,2123,839,2635,1351,1676,1351,1430,455,1430,455,2764,3414,3414,2764,2764,843,3414,843,1684,839,1684,839,1676,1351,1676,1351,455,1430,1430,455,715,199,843,715,455,203,839,455,455,406,1351,455,843,908,839,1814,839,1814,1351,0,1351,1,1684,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s500,s501], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s500) b500 <|
    PetersenLocalChildren.push (x := s501) b501 <|
    PetersenLocalChildren.nil
theorem b502 : Blocked tgt 6 s502 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s502 6 _ le
  decide +kernel
theorem b503 : Blocked tgt 6 s503 := by
  apply PetersenFastNode.node (nxt := #[s504,s505]) (hints := [716,716,2635,455,1430,455,2635,843,908,843,2887,2635,839,2375,2375,2635,1351,1676,1351,1430,455,1430,455,908,843,908,843,3284,839,2764,839,3284,2764,2764,3284,1676,1351,1676,1351,715,199,843,715,455,203,839,455,1430,455,455,1430,455,406,1351,455,1428,839,835,835,1428,843,843,1428,843,1095,1611,843,839,1684,839,1099,1351,839,0,1351,1,1351]) (by decide +kernel)
  change ∀ b ∈ [s504,s505], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s504) b504 <|
    PetersenLocalChildren.push (x := s505) b505 <|
    PetersenLocalChildren.nil
theorem b506 : Blocked tgt 6 s506 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s506 6 _ le
  decide +kernel
theorem b507 : Blocked tgt 6 s507 := by
  apply PetersenFastNode.node (nxt := #[s508,s509]) (hints := [2764,1236,2375,455,1430,455,2115,843,2119,843,2375,2635,2375,839,2123,2375,1351,1676,1351,1430,455,1430,455,908,843,908,843,3284,2764,2764,3284,3284,839,2764,839,1676,1351,1676,1351,715,199,843,715,455,0,1,455,455,203,839,455,455,406,1351,455,843,908,908,843,1428,839,835,835,843,1095,1611,843,839,1684,1351,1676,1351,1676,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s508,s509], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s508) b508 <|
    PetersenLocalChildren.push (x := s509) b509 <|
    PetersenLocalChildren.nil
theorem b510 : Blocked tgt 6 s510 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s510 6 _ le
  decide +kernel
theorem b511 : Blocked tgt 6 s511 := by
  apply PetersenFastNode.node (nxt := #[s512,s513,s514,s515,s516,s517,s488,s518,s519,s520]) (hints := [1374,1374,1438,463,2772,463,1438,2772,1438,1374,1374,463,916,2772,916,851,1374,851,916,1374,916,2772,2772,851,1244,1244,1692,2260,2772,847,1692,2772,1692,1244,1244,847,2772,2772,0,220,1244,1359,1244,1244,1,2772,2772,1359,2772,2772,2,1244,1244,2383,724,1244,3,724,2772,2383,723,723,851,207,463,916,851,463,851,723,723,916,463,463,847,211,723,1692,847,723,847,463,463,1692,463,463,1359,1438,1438,4,1359,1438,1359,463,463,5,2383,398,2383,463,463,6,463,463,2383,398,398,7,1436,1436,1692,847,851,847,843,851,1692,843,1436,847,851,851,1619,1103,1436,1359,1619,1436,1619,851,851,1359,2643,916,2643,851,851,2383,851,851,2643,2127,916,2383,847,847,1359,1107,1692,1619,1359,1692,1359,847,847,1619,2383,782,2383,847,847,2643,847,847,2383,2131,782,2643,1359,1359,2383,1684,8,9]) (by decide +kernel)
  change ∀ b ∈ [s512,s513,s514,s515,s516,s517,s488,s518,s519,s520], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s512) b512 <|
    PetersenLocalChildren.push (x := s513) b513 <|
    PetersenLocalChildren.push (x := s514) b514 <|
    PetersenLocalChildren.push (x := s515) b515 <|
    PetersenLocalChildren.push (x := s516) b516 <|
    PetersenLocalChildren.push (x := s517) b517 <|
    PetersenLocalChildren.push (x := s488) b488 <|
    PetersenLocalChildren.push (x := s518) b518 <|
    PetersenLocalChildren.push (x := s519) b519 <|
    PetersenLocalChildren.push (x := s520) b520 <|
    PetersenLocalChildren.nil
theorem b521 : Blocked tgt 6 s521 := by
  apply PetersenFastNode.node (nxt := #[s519]) (hints := [2763,1235,1429,454,1429,454,907,842,907,842,1683,838,1683,838,3398,0,1350,2374,2374,1429,454,1429,454,907,842,907,842,1683,838,1683,838,2763,1350,3283,1350,2763,3283,3283,2763,714,198,842,714,454,202,838,454,454,1429,1350,454,389,454,454,389,1427,838,834,834,842,1094,1610,842,907,842,842,907,838,1098,1350,838,773,838,838,773,1350,1675]) (by decide +kernel)
  change ∀ b ∈ [s519], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s519) b519 <|
    PetersenLocalChildren.nil
theorem b522 : Blocked tgt 6 s522 := by
  apply PetersenFastNode.node (nxt := #[s523,s524,s525,s125,s526,s519,s527,s528,s529,s531,s532,s535]) (hints := [726,2385,2774,726,0,1,2385,2385,1440,465,2,465,1440,3,1440,465,2385,465,2645,2645,918,853,2385,853,2129,2385,918,853,2645,853,2385,2385,1694,849,2645,849,2133,2645,1694,849,2385,849,1361,2385,1686,1361,4,5,1376,1376,1440,465,2774,465,1440,2774,1440,465,1376,465,918,2774,918,853,1376,853,918,1376,918,853,2774,853,1246,1246,1694,849,2774,849,1694,2774,1694,849,1246,849,1686,2774,1686,1246,1246,6,1686,1246,1686,1750,2774,7,725,725,853,209,465,918,853,465,853,725,725,918,465,465,849,213,725,1694,849,725,849,465,465,1694,465,465,1556,416,1440,1686,1424,1440,1556,465,465,1686,1438,1438,1694,849,853,849,845,853,1694,845,1438,849,853,853,1686,414,1438,8,1686,1438,1686,853,853,9,849,849,10,1686,1694,1686,1678,1694,11,849,849,1686]) (by decide +kernel)
  change ∀ b ∈ [s523,s524,s525,s125,s526,s519,s527,s528,s529,s531,s532,s535], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s523) b523 <|
    PetersenLocalChildren.push (x := s524) b524 <|
    PetersenLocalChildren.push (x := s525) b525 <|
    PetersenLocalChildren.push (x := s125) b125 <|
    PetersenLocalChildren.push (x := s526) b526 <|
    PetersenLocalChildren.push (x := s519) b519 <|
    PetersenLocalChildren.push (x := s527) b527 <|
    PetersenLocalChildren.push (x := s528) b528 <|
    PetersenLocalChildren.push (x := s529) b529 <|
    PetersenLocalChildren.push (x := s531) b531 <|
    PetersenLocalChildren.push (x := s532) b532 <|
    PetersenLocalChildren.push (x := s535) b535 <|
    PetersenLocalChildren.nil
theorem b536 : Blocked tgt 6 s536 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s536 6 _ le
  decide +kernel
theorem b537 : Blocked tgt 6 s537 := by
  apply PetersenFastNode.node (nxt := #[s526,s538]) (hints := [716,716,2375,455,1430,455,2635,843,2119,843,2375,839,2123,839,2375,0,2375,1351,1,1430,455,1430,455,908,843,908,843,1684,839,1684,839,2764,3284,3284,2764,2764,1351,3284,1351,715,199,843,715,455,203,839,455,455,1430,1430,455,455,1430,1351,455,1428,839,835,835,843,1428,1428,843,843,1095,1611,843,839,1684,1684,839,839,1099,1351,839,1351,1676]) (by decide +kernel)
  change ∀ b ∈ [s526,s538], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s526) b526 <|
    PetersenLocalChildren.push (x := s538) b538 <|
    PetersenLocalChildren.nil
theorem b539 : Blocked tgt 6 s539 := by
  apply PetersenFastNode.node (nxt := #[s540,s541,s542]) (hints := [1367,1367,2376,456,1431,456,2636,844,2120,844,2376,0,2376,840,2124,840,2376,1352,1677,1352,1431,456,1431,456,3159,3415,844,2765,2765,1685,840,1685,840,1677,1352,1677,1352,716,200,844,716,1,456,456,2,456,204,840,456,456,407,1352,456,844,909,1685,840,836,836,844,1096,1612,844,1685,840,1685,840,1677,1352,1677,1352,840,1100,1352,840]) (by decide +kernel)
  change ∀ b ∈ [s540,s541,s542], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s540) b540 <|
    PetersenLocalChildren.push (x := s541) b541 <|
    PetersenLocalChildren.push (x := s542) b542 <|
    PetersenLocalChildren.nil
theorem b543 : Blocked tgt 6 s543 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s543 6 _ le
  decide +kernel
theorem b544 : Blocked tgt 6 s544 := by
  apply PetersenFastNode.node (nxt := #[s545,s546,s547]) (hints := [717,717,2376,456,1431,456,2636,844,2120,844,2376,840,2124,840,2376,0,2376,1352,1677,1352,1431,456,1431,456,909,844,909,844,2253,2765,840,2765,3285,1677,1352,1677,1352,716,200,844,716,456,204,840,456,1431,456,456,1431,456,407,1352,456,1429,840,836,836,1429,844,844,1429,844,1096,1612,844,840,1685,840,1100,1352,840,1,1352,2,1352]) (by decide +kernel)
  change ∀ b ∈ [s545,s546,s547], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s545) b545 <|
    PetersenLocalChildren.push (x := s546) b546 <|
    PetersenLocalChildren.push (x := s547) b547 <|
    PetersenLocalChildren.nil
theorem b548 : Blocked tgt 6 s548 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s548 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
