import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv22_4260 : PetersenPackedPin.project r22 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv22_4814 : PetersenPackedPin.project r22 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv22_5473 : PetersenPackedPin.project r22 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv22_6170 : PetersenPackedPin.project r22 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv22_6790 : PetersenPackedPin.project r22 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv22_7474 : PetersenPackedPin.project r22 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv22_8012 : PetersenPackedPin.project r22 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv22_1343 : PetersenPackedPin.project r22 (0xffffffff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_7474 pv22_8012 rfl rfl
theorem pv22_1734 : PetersenPackedPin.project r22 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xa0a := PetersenWireProjection.derive 1 pv22_4260 pv22_6790 rfl rfl
theorem pv22_1829 : PetersenPackedPin.project r22 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv22_5473 pv22_6790 rfl rfl
theorem pv22_1977 : PetersenPackedPin.project r22 (0xffff0000ffff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_6790 pv22_8012 rfl rfl
theorem pv22_2192 : PetersenPackedPin.project r22 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x2222 := PetersenWireProjection.derive 1 pv22_4260 pv22_6170 rfl rfl
theorem pv22_2461 : PetersenPackedPin.project r22 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_6170 pv22_8012 rfl rfl
theorem pv22_2708 : PetersenPackedPin.project r22 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv22_4260 pv22_5473 rfl rfl
theorem pv22_3485 : PetersenPackedPin.project r22 (0x33333333333333330000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_4814 pv22_8012 rfl rfl
theorem pv22_3632 : PetersenPackedPin.project r22 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_4260 pv22_5473 rfl rfl
theorem pv22_3759 : PetersenPackedPin.project r22 (0x55555555555555550000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_4260 pv22_8012 rfl rfl
theorem pv22_3980 : PetersenPackedPin.project r22 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv22_4260 pv22_5473 rfl rfl
theorem pv22_5850 : PetersenPackedPin.project r22 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv22_4260 pv22_5473 rfl rfl
theorem pv22_7095 : PetersenPackedPin.project r22 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xfafa := PetersenWireProjection.derive 3 pv22_4260 pv22_6790 rfl rfl
theorem pv22_7397 : PetersenPackedPin.project r22 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv22_7474 pv22_8012 rfl rfl
theorem pv22_8208 : PetersenPackedPin.project r22 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv22_4814 pv22_8012 rfl rfl
theorem pv22_8245 : PetersenPackedPin.project r22 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv22_5473 pv22_8012 rfl rfl
theorem pv22_1817 : PetersenPackedPin.project r22 (0xf0500000f0500000f0500000f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv22_1829 pv22_2192 rfl rfl
theorem pv22_3822 : PetersenPackedPin.project r22 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv22_3980 pv22_5850 rfl rfl
theorem pv22_5281 : PetersenPackedPin.project r22 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_2192 pv22_5473 rfl rfl
theorem pv22_5328 : PetersenPackedPin.project r22 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_1734 pv22_5473 rfl rfl
theorem pv22_5335 : PetersenPackedPin.project r22 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv22_5473 pv22_7095 rfl rfl
theorem pv22_5745 : PetersenPackedPin.project r22 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_2708 pv22_8012 rfl rfl
theorem pv22_6421 : PetersenPackedPin.project r22 (0xff55ff55ff55ff55f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_2192 pv22_8245 rfl rfl
theorem pv22_6980 : PetersenPackedPin.project r22 (0xffff5555ffff5555f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv22_1734 pv22_8245 rfl rfl
theorem pv22_7213 : PetersenPackedPin.project r22 (0xfffff050fffff050fffff050fffff050 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv22_1817 pv22_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
