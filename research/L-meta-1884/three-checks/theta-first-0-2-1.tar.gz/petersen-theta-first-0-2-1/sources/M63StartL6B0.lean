import M63StartData
import M63StartPins0
import M63StartL5B0
import M63StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2 : Blocked tgt 6 s2 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s2 6 _ le
  decide +kernel
theorem b3 : Blocked tgt 6 s3 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s3 6 _ le
  decide +kernel
theorem b4 : Blocked tgt 6 s4 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s4 6 _ le
  decide +kernel
theorem b5 : Blocked tgt 6 s5 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s5 6 _ le
  decide +kernel
theorem b6 : Blocked tgt 6 s6 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s6 6 _ le
  decide +kernel
theorem b7 : Blocked tgt 6 s7 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s7 6 _ le
  decide +kernel
theorem b8 : Blocked tgt 6 s8 := by
  apply PetersenFastNode.node (nxt := #[s9,s11]) (hints := [3446,3510,715,199,843,715,2668,391,391,2796,391,203,839,391,391,3756,1351,391,391,0,2375,391,779,779,3446,843,1,2796,3446,2796,3446,3764,3894,3764,2406,3756,3430,3756,1366,1398,3414,1366,2796,2988,3764,839,3764,835,3756,1095,3756,843,843,2119,2635,843,3316,2284,3764,3316,2796,2292,3756,2796,716,748,2764,716,839,3756,3748,3748,1684,1716,3732,1684,1676,1708,3724,1676]) (by decide +kernel)
  change ∀ b ∈ [s9,s11], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s11) b11 <|
    PetersenLocalChildren.nil
theorem b12 : Blocked tgt 6 s12 := by
  apply PetersenFastNode.node (nxt := #[s13]) (hints := [390,2667,390,714,2795,2665,2795,842,3315,2283,3763,3315,2795,2291,3755,2795,715,747,2763,715,714,3509,714,2923,390,714,194,202,706,194,714,3755,1610,714,714,0,2634,714,2857,2987,2857,2987,3445,3763,3893,3763,2405,1610,3429,1610,1365,2634,3413,2634,3507,2475,3763,3507,1610,2483,1610,2987,2634,939,2634,907,1090,1098,1090,1602,2114,2122,2114,2626,1610,1707,2634,1610]) (by decide +kernel)
  change ∀ b ∈ [s13], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.nil
theorem b14 : Blocked tgt 6 s14 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s14 6 _ le
  decide +kernel
theorem b15 : Blocked tgt 6 s15 := by
  apply PetersenFastNode.node (nxt := #[s16,s17]) (hints := [716,716,2375,455,0,455,2375,1,2635,843,2119,843,2375,839,2123,839,2375,1351,1676,1351,2636,2764,455,2764,3414,908,843,908,843,1684,839,1684,839,1676,1351,1676,1351,455,1430,715,199,843,715,455,203,839,455,455,1676,1351,455,778,843,778,843,1814,839,1814,839,1546,1351,1546,1351,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s16,s17], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s17) b17 <|
    PetersenLocalChildren.nil
theorem b18 : Blocked tgt 6 s18 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s18 6 _ le
  decide +kernel
theorem b19 : Blocked tgt 6 s19 := by
  apply PetersenFastNode.node (nxt := #[s20,s21]) (hints := [3446,3446,2796,843,2988,2796,3188,839,3700,839,2796,2292,3692,2796,391,391,2796,455,716,2375,2764,2375,2858,843,2858,843,3510,839,3894,839,2486,2486,3510,3756,0,455,3510,455,1430,2375,3478,2375,3508,839,835,835,843,2484,3756,843,715,199,715,843,843,2119,2635,843,839,3756,3748,839,455,203,455,839,839,2123,2375,839,455,1351,2375,1708,2375,1676,455,1,2375,455]) (by decide +kernel)
  change ∀ b ∈ [s20,s21], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s20) b20 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.nil
theorem b22 : Blocked tgt 6 s22 := by
  apply PetersenFastNode.node (nxt := #[s23]) (hints := [390,390,454,2795,454,2469,714,198,842,714,454,202,838,454,454,3755,454,0,2374,454,2795,3445,2795,842,2987,2795,2275,2283,2787,2275,2795,1350,3187,2795,715,747,2763,715,2857,2987,2857,2987,3509,838,3893,838,3625,1350,3493,1350,1429,2374,3477,2374,2467,2475,2979,2467,2987,1094,1610,2987,907,939,2955,907,838,1098,1350,838,838,2122,2374,838,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s23], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s23) b23 <|
    PetersenLocalChildren.nil
theorem b24 : Blocked tgt 6 s24 := by
  apply PetersenFastNode.node (nxt := #[s25,s26,s9,s13,s27,s28,s16,s29,s30,s31,s32,s35,s36,s37,s38,s39,s21,s40]) (hints := [1478,732,1478,1542,0,1,732,732,924,859,2,859,924,3,924,732,732,859,1252,1252,1700,855,732,855,1700,732,1700,855,1252,855,732,732,1692,1367,1252,1367,1692,1252,1692,1367,732,1367,407,4,5,407,732,471,732,732,6,471,7,471,2844,8,2874,859,1478,859,954,1478,2874,859,9,859,1478,1478,3910,855,10,855,1990,11,3910,855,1478,855,438,438,3642,1367,1478,1367,1462,1478,3642,1367,438,1367,12,13,14,471,1478,471,1446,1478,6,471,15,471,1444,1444,1700,855,859,855,851,859,1700,851,1444,855,859,859,1627,1111,1444,1367,1627,1444,1627,859,859,1367,731,859,731,215,924,471,731,924,731,859,859,471,855,855,1367,1115,1700,1627,1367,1700,1367,855,855,1627,471,855,471,219,1700,731,471,1700,471,855,855,731,471,1367,471,1692,1692,16,471,1692,471,1367,1367,17]) (by decide +kernel)
  change ∀ b ∈ [s25,s26,s9,s13,s27,s28,s16,s29,s30,s31,s32,s35,s36,s37,s38,s39,s21,s40], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.push (x := s26) b26 <|
    PetersenLocalChildren.push (x := s9) b9 <|
    PetersenLocalChildren.push (x := s13) b13 <|
    PetersenLocalChildren.push (x := s27) b27 <|
    PetersenLocalChildren.push (x := s28) b28 <|
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s29) b29 <|
    PetersenLocalChildren.push (x := s30) b30 <|
    PetersenLocalChildren.push (x := s31) b31 <|
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.push (x := s36) b36 <|
    PetersenLocalChildren.push (x := s37) b37 <|
    PetersenLocalChildren.push (x := s38) b38 <|
    PetersenLocalChildren.push (x := s39) b39 <|
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s40) b40 <|
    PetersenLocalChildren.nil
theorem b41 : Blocked tgt 6 s41 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s41 6 _ le
  decide +kernel
theorem b42 : Blocked tgt 6 s42 := by
  apply PetersenFastNode.node (nxt := #[s25,s43,s44,s45]) (hints := [2638,718,0,718,3448,718,845,910,718,1238,206,1686,1238,718,214,1678,718,1,718,718,2377,1464,1464,845,910,845,910,841,1686,841,1686,1353,1678,1353,1678,457,457,2860,845,2860,845,3896,841,3896,841,3628,1353,3628,1353,2,2377,3,2377,1430,841,837,837,845,1097,1613,845,845,2121,2637,845,841,1101,1353,841,841,2125,2377,841,1353,1678,2377,1353]) (by decide +kernel)
  change ∀ b ∈ [s25,s43,s44,s45], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s25) b25 <|
    PetersenLocalChildren.push (x := s43) b43 <|
    PetersenLocalChildren.push (x := s44) b44 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
