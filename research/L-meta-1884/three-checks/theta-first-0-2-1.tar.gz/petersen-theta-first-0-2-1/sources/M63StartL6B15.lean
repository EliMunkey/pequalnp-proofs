import M63StartData
import M63StartPins0
import M63StartL5B12
import M63StartL5B13
import M63StartL5B3
import M63StartL5B1
import M63StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b469 : Blocked tgt 6 s469 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s469 6 _ le
  decide +kernel
theorem b470 : Blocked tgt 6 s470 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s470 6 _ le
  decide +kernel
theorem b471 : Blocked tgt 6 s471 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,false))] s471 6 _ le
  decide +kernel
theorem b472 : Blocked tgt 6 s472 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s472 6 _ le
  decide +kernel
theorem b473 : Blocked tgt 6 s473 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,false))] s473 6 _ le
  decide +kernel
theorem b476 : Blocked tgt 6 s476 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s476 6 _ le
  decide +kernel
theorem b477 : Blocked tgt 6 s477 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s477 6 _ le
  decide +kernel
theorem b478 : Blocked tgt 6 s478 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s478 6 _ le
  decide +kernel
theorem b479 : Blocked tgt 6 s479 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s479 6 _ le
  decide +kernel
theorem b480 : Blocked tgt 6 s480 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s480 6 _ le
  decide +kernel
theorem b481 : Blocked tgt 6 s481 := by
  apply PetersenFastNode.node (nxt := #[s482,s483,s484,s485,s123,s45,s486,s487,s488,s489]) (hints := [399,3422,0,399,724,463,724,724,1,463,3422,463,3422,3422,2,724,724,2383,724,724,3,1374,3422,2383,724,724,916,851,3422,851,916,3422,916,724,724,851,1244,1244,1692,212,724,847,1692,724,1692,1244,1244,847,724,724,1684,220,1244,1359,1684,1244,1684,724,724,1359,463,463,2383,1438,4,5,723,723,851,207,463,916,851,463,851,723,723,916,463,463,847,211,723,1692,847,723,847,463,463,1692,463,463,1359,1684,6,1684,1359,7,1359,463,463,1684,2643,2643,786,851,2383,851,2127,2383,786,851,2643,851,2383,2383,1822,847,2643,847,2131,2643,1822,847,2383,847,2383,2383,1554,1359,8,1359,1554,9,1554,1359,2383,1359,1436,1436,1692,847,851,847,843,851,1692,843,1436,847,851,851,1619,1103,1436,1359,1619,1436,1619,851,851,1359,847,847,1359,1107,1692,1619,1359,1692,1359,847,847,1619]) (by decide +kernel)
  change ∀ b ∈ [s482,s483,s484,s485,s123,s45,s486,s487,s488,s489], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s482) b482 <|
    PetersenLocalChildren.push (x := s483) b483 <|
    PetersenLocalChildren.push (x := s484) b484 <|
    PetersenLocalChildren.push (x := s485) b485 <|
    PetersenLocalChildren.push (x := s123) b123 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s486) b486 <|
    PetersenLocalChildren.push (x := s487) b487 <|
    PetersenLocalChildren.push (x := s488) b488 <|
    PetersenLocalChildren.push (x := s489) b489 <|
    PetersenLocalChildren.nil
theorem b490 : Blocked tgt 6 s490 := by
  apply PetersenFastNode.node (nxt := #[s123]) (hints := [715,715,2502,0,454,2374,2374,907,842,907,842,1683,838,1683,838,1675,1350,1675,1350,3413,454,2763,454,3413,2763,2763,3413,907,842,907,842,1683,838,1683,838,1675,1350,1675,1350,454,1429,714,198,842,714,454,202,838,454,454,1675,1350,454,777,842,777,842,1813,838,1813,838,1545,1350,1545,1350,1427,838,834,834,842,1094,1610,842,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s123], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s123) b123 <|
    PetersenLocalChildren.nil
theorem b491 : Blocked tgt 6 s491 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s491 6 _ le
  decide +kernel
theorem b492 : Blocked tgt 6 s492 := by
  apply PetersenFastNode.node (nxt := #[s80,s493]) (hints := [2764,1366,2375,0,2375,455,1,2635,843,2119,843,2375,839,2123,839,2375,1351,1676,1351,3414,2764,2764,3414,3414,455,2764,455,908,843,908,843,1684,839,1684,839,1676,1351,1676,1351,455,1430,843,908,843,908,839,1684,839,1684,1351,1676,1351,1676,715,199,843,715,455,203,839,455,455,1676,1351,455,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s80,s493], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s493) b493 <|
    PetersenLocalChildren.nil
theorem b494 : Blocked tgt 6 s494 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s494 6 _ le
  decide +kernel
theorem b495 : Blocked tgt 6 s495 := by
  apply PetersenFastNode.node (nxt := #[s496,s497]) (hints := [2764,1366,2375,455,1430,455,2891,2375,843,2375,2635,2375,839,1684,839,2375,1351,1676,1351,1430,455,1430,455,2764,843,3414,843,2764,3414,3414,2764,1684,839,1684,839,1676,1351,1676,1351,715,199,843,715,0,455,455,1,455,203,839,455,455,406,1351,455,843,908,1684,839,835,835,843,1095,1611,843,1684,839,1684,839,1676,1351,1676,1351,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s496,s497], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s496) b496 <|
    PetersenLocalChildren.push (x := s497) b497 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
