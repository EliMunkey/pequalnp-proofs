import M63StartData
import M63StartL5B15
import M63StartPins0
import M63StartL5B14
import M63StartL5B16
import M63StartL5B3
import M63StartL5B4
import M63StartL5B17
import M63StartL5B13
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b549 : Blocked tgt 6 s549 := by
  apply PetersenFastNode.node (nxt := #[s550,s552,s553]) (hints := [2376,0,1237,1237,2376,456,1431,456,909,844,909,844,2376,840,2124,840,1677,1352,1677,1352,2765,2765,456,1,456,2,844,909,844,909,840,1685,1352,1677,1352,1677,1431,456,1431,456,909,844,909,844,3285,840,3797,1677,1352,1677,1352,716,200,844,716,456,204,840,456,456,1549,1352,456,1429,840,836,836,844,1096,1612,844,840,1100,1352,840]) (by decide +kernel)
  change ∀ b ∈ [s550,s552,s553], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s550) b550 <|
    PetersenLocalChildren.push (x := s552) b552 <|
    PetersenLocalChildren.push (x := s553) b553 <|
    PetersenLocalChildren.nil
theorem b554 : Blocked tgt 6 s554 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s554 6 _ le
  decide +kernel
theorem b555 : Blocked tgt 6 s555 := by
  apply PetersenFastNode.node (nxt := #[s527,s556]) (hints := [1236,1236,2375,455,1430,455,2635,843,2119,843,2375,839,2123,839,2375,1351,0,1351,2375,1,1430,455,1430,455,908,843,908,843,1684,839,1684,839,2260,3284,1351,2764,2764,715,199,843,715,455,203,839,455,455,1430,1351,455,390,455,455,390,1428,839,835,835,843,1095,1611,843,908,843,843,908,839,1099,1351,839,774,839,839,774,1351,1676]) (by decide +kernel)
  change ∀ b ∈ [s527,s556], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s527) b527 <|
    PetersenLocalChildren.push (x := s556) b556 <|
    PetersenLocalChildren.nil
theorem b557 : Blocked tgt 6 s557 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s557 6 _ le
  decide +kernel
theorem b558 : Blocked tgt 6 s558 := by
  apply PetersenFastNode.node (nxt := #[s559,s528]) (hints := [2375,0,716,716,1430,455,1430,455,1428,843,1428,843,1684,839,1684,839,2375,1351,1,1351,2764,3284,455,1430,455,1430,843,1428,843,1428,839,1684,839,1684,1351,1676,1430,455,1430,455,1428,843,1428,843,1684,839,1684,839,2764,1351,3788,715,199,843,715,455,203,839,455,455,1430,1351,455,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s559,s528], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s559) b559 <|
    PetersenLocalChildren.push (x := s528) b528 <|
    PetersenLocalChildren.nil
theorem b560 : Blocked tgt 6 s560 := by
  apply PetersenFastNode.node (nxt := #[s561,s562,s127,s563,s564,s565,s566,s567,s568]) (hints := [723,723,2382,0,1,2382,2382,722,2,2382,2642,850,2126,850,2382,846,2130,846,2382,1358,1683,1358,2771,3,4,2771,3421,722,2769,722,2771,850,785,850,1691,846,1691,846,1683,1358,1683,1358,462,462,850,915,846,5,846,6,1358,7,1358,8,206,850,722,846,210,846,202,1358,1555,1358,722,1691,846,842,842,850,1102,1618,850,846,1106,1358,846]) (by decide +kernel)
  change ∀ b ∈ [s561,s562,s127,s563,s564,s565,s566,s567,s568], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s561) b561 <|
    PetersenLocalChildren.push (x := s562) b562 <|
    PetersenLocalChildren.push (x := s127) b127 <|
    PetersenLocalChildren.push (x := s563) b563 <|
    PetersenLocalChildren.push (x := s564) b564 <|
    PetersenLocalChildren.push (x := s565) b565 <|
    PetersenLocalChildren.push (x := s566) b566 <|
    PetersenLocalChildren.push (x := s567) b567 <|
    PetersenLocalChildren.push (x := s568) b568 <|
    PetersenLocalChildren.nil
theorem b569 : Blocked tgt 6 s569 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,2373,2373,2633,2633,2373,2373,2633,2373,837,2121,837,2373,1349,1674,1349,1428,453,1428,453,906,3412,906,2762,2632,2762,2762,2632,1682,837,1682,837,1674,1349,1674,1349,197,453,906,453,713,453,1682,837,453,453,404,1349,453,841,841,1426,837,1682,837,1609,1349,1609,1349,1552,837,1552,837,1609,1349,1609,1349,837,1097,1349,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b570 : Blocked tgt 6 s570 := by
  apply PetersenFastNode.node (nxt := #[s571,s572]) (hints := [2375,0,1,2375,716,716,2375,455,1430,455,2635,843,2119,843,1684,839,1684,839,1676,1351,1676,1351,3414,2764,3414,2764,455,715,843,908,839,1684,839,1684,1351,1676,1351,1676,1430,455,2764,455,2764,843,778,843,1684,839,1684,839,1676,1351,1676,1351,843,455,971,455,1684,839,455,455,1676,1351,455,1684,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s571,s572], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s571) b571 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.nil
theorem b573 : Blocked tgt 6 s573 := by
  apply PetersenFastNode.node (nxt := #[s130]) (hints := [2634,2374,2374,2634,1365,1365,2374,714,0,2374,2634,2374,2374,2634,2374,838,1813,838,2374,1350,1675,1350,2763,3413,2763,3413,454,454,842,842,1683,838,1683,838,1610,1350,1610,1350,3413,714,2761,714,907,3413,3413,2763,1813,838,1813,838,2373,1350,3397,1350,714,907,970,838,202,838,194,1350,1547,1350,714,1427,838,1683,838,1610,1350,1610,1350,838,1098,1350,838]) (by decide +kernel)
  change ∀ b ∈ [s130], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s130) b130 <|
    PetersenLocalChildren.nil
theorem b574 : Blocked tgt 6 s574 := by
  apply PetersenFastNode.node (nxt := #[s575,s576]) (hints := [716,716,2375,0,1,2375,2375,455,1430,455,2635,843,2119,843,2375,839,2123,839,2375,1351,1676,1351,3284,2764,2764,3284,1430,455,2764,455,908,843,908,843,3284,839,2764,839,1676,1351,1676,1351,455,715,843,908,843,908,839,1684,1351,1676,1351,1676,843,199,843,195,203,839,455,455,1676,1351,455,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s575,s576], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s575) b575 <|
    PetersenLocalChildren.push (x := s576) b576 <|
    PetersenLocalChildren.nil
theorem b577 : Blocked tgt 6 s577 := by
  apply PetersenFastNode.node (nxt := #[s131,s578,s579]) (hints := [717,717,2376,716,0,2376,2636,844,2120,844,2376,2636,2636,2376,2376,2636,2636,2376,2376,1352,1677,1352,3415,716,2763,716,909,844,909,844,1685,2253,1685,3285,3415,2765,2765,3415,1677,1352,1677,1352,716,781,844,716,204,716,1685,456,456,1352,1549,1352,716,1429,844,844,1429,1,844,844,2,844,1096,1612,844,840,840,1352,1612,1352,1612,1352,1612,1352,1612]) (by decide +kernel)
  change ∀ b ∈ [s131,s578,s579], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s131) b131 <|
    PetersenLocalChildren.push (x := s578) b578 <|
    PetersenLocalChildren.push (x := s579) b579 <|
    PetersenLocalChildren.nil
theorem b580 : Blocked tgt 6 s580 := by
  apply PetersenFastNode.node (nxt := #[s581,s582,s133,s583,s584]) (hints := [2378,0,1,2378,1239,1239,2378,718,2,2378,1431,846,1431,846,2378,842,2126,842,2378,1354,1679,1354,2767,3287,2767,3287,458,458,846,1431,846,1431,842,1687,1354,3,1354,4,3417,718,3287,718,1431,846,1431,846,3287,842,2767,842,2247,1354,3271,1354,718,1431,846,718,842,718,970,1354,1551,1354,718,1431,842,838,838,846,1098,1614,846,842,1102,1354,842]) (by decide +kernel)
  change ∀ b ∈ [s581,s582,s133,s583,s584], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s581) b581 <|
    PetersenLocalChildren.push (x := s582) b582 <|
    PetersenLocalChildren.push (x := s133) b133 <|
    PetersenLocalChildren.push (x := s583) b583 <|
    PetersenLocalChildren.push (x := s584) b584 <|
    PetersenLocalChildren.nil
theorem b585 : Blocked tgt 6 s585 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,2633,2633,2373,2632,714,2633,453,1428,2633,2633,841,776,841,2373,2633,2633,2373,2633,1609,1544,1609,2762,2632,2762,2632,453,713,906,841,906,841,837,837,1349,1609,1349,1609,2632,453,1428,453,776,841,776,841,1682,2632,2632,3282,1544,1609,1544,1609,841,197,841,193,453,1682,965,1609,404,1609,453,1426,841,841,1426,841,1093,1609,841,1349,1609,1349,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b586 : Blocked tgt 6 s586 := by
  apply PetersenFastNode.node (nxt := #[s587,s588]) (hints := [1236,1236,2375,0,1,2375,2375,455,390,455,2635,843,2119,843,2375,839,2123,839,2375,1351,1546,1351,2764,3284,3284,2764,3414,455,3284,455,1428,843,1428,843,1684,839,1684,839,2764,1351,3284,1351,455,1430,843,1428,843,1428,839,1684,839,1684,1351,1676,715,199,843,715,455,203,839,455,406,1351,455,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s587,s588], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s587) b587 <|
    PetersenLocalChildren.push (x := s588) b588 <|
    PetersenLocalChildren.nil
theorem b589 : Blocked tgt 6 s589 := by
  apply PetersenFastNode.node (nxt := #[s486,s516,s488,s125]) (hints := [718,718,2377,0,1432,2377,2637,845,2121,845,2377,841,2125,841,2377,1,1678,2377,2377,2,3,2377,1432,2766,1432,3416,910,845,910,845,1686,841,1686,841,1678,2262,1678,2766,2376,2766,2766,2376,845,910,845,910,841,1558,841,1432,408,1432,1678,457,457,1430,841,837,837,845,406,1678,845,845,910,910,845,841,1678,1670,841,841,1686,1686,841,1353,1353]) (by decide +kernel)
  change ∀ b ∈ [s486,s516,s488,s125], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s486) b486 <|
    PetersenLocalChildren.push (x := s516) b516 <|
    PetersenLocalChildren.push (x := s488) b488 <|
    PetersenLocalChildren.push (x := s125) b125 <|
    PetersenLocalChildren.nil
theorem b590 : Blocked tgt 6 s590 := by
  apply PetersenFastNode.node (nxt := #[s591,s592,s487,s593,s594]) (hints := [2378,0,1,2378,719,719,2378,2,1433,2378,911,846,911,846,2378,842,2126,842,2378,1354,1549,1354,3287,2767,3287,2767,458,458,846,911,846,911,842,3,842,4,1354,1679,1433,2767,2767,3417,911,846,911,846,2247,842,2759,842,2767,1354,3287,1354,846,911,846,911,842,1559,842,1433,1354,1433,1482,391,842,838,838,846,1098,1614,846,842,1102,1354,842]) (by decide +kernel)
  change ∀ b ∈ [s591,s592,s487,s593,s594], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s591) b591 <|
    PetersenLocalChildren.push (x := s592) b592 <|
    PetersenLocalChildren.push (x := s487) b487 <|
    PetersenLocalChildren.push (x := s593) b593 <|
    PetersenLocalChildren.push (x := s594) b594 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
