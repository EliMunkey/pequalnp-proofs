import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv39_4260 : PetersenPackedPin.project r39 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv39_4814 : PetersenPackedPin.project r39 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv39_5473 : PetersenPackedPin.project r39 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv39_6170 : PetersenPackedPin.project r39 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv39_6790 : PetersenPackedPin.project r39 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv39_7474 : PetersenPackedPin.project r39 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv39_8012 : PetersenPackedPin.project r39 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv39_2708 : PetersenPackedPin.project r39 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a := PetersenWireProjection.derive 1 pv39_4260 pv39_5473 rfl rfl
theorem pv39_6504 : PetersenPackedPin.project r39 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv39_4260 pv39_6170 rfl rfl
theorem pv39_8295 : PetersenPackedPin.project r39 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv39_6170 pv39_8012 rfl rfl
theorem pv39_5761 : PetersenPackedPin.project r39 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv39_2708 pv39_8295 rfl rfl
theorem pv39_5961 : PetersenPackedPin.project r39 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv39_4814 pv39_5761 rfl rfl
end PetersenSmallStarts.M191.Residual
