import M191StartPreferredSignals
import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values13
import M191Values14
import M191Values2
import M191Values5
import M191Values737
import M191Values739
import M191Values753
import M191Values8
import M191Values9
import M191ResidualC7A0G46
import M191ResidualC7A0G47
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows32
import ResidualFast
import ThetaClosing
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b6919 : Blocked tgt 8 s6919 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6919 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5000000000000f5f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6920 : Blocked tgt 8 s6920 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6920 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0a0affff0a0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6921 : Blocked tgt 8 s6921 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6921 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0affff0a0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6949 : Blocked tgt 8 s6949 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6949 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8339 rfl))))))))) (by decide +kernel)
theorem b6976 : Blocked tgt 8 s6976 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6976 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_587 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6977 : Blocked tgt 8 s6977 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6977 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1850 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6978 : Blocked tgt 8 s6978 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6978 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6979 : Blocked tgt 8 s6979 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6979 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7397 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6980 : Blocked tgt 8 s6980 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6980 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 (PetersenWireProjection.cons pv739_8377 rfl))))))))) (by decide +kernel)
theorem b6981 : Blocked tgt 8 s6981 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6981 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_630 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6982 : Blocked tgt 8 s6982 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6982 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_1343 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6984 : Blocked tgt 8 s6984 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6984 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6985 : Blocked tgt 8 s6985 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6985 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6986 : Blocked tgt 8 s6986 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6986 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xc4c4c4c4c4c4c4c4c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6987 : Blocked tgt 8 s6987 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6987 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6988 : Blocked tgt 8 s6988 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6988 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6989 : Blocked tgt 8 s6989 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6989 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6990 : Blocked tgt 8 s6990 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6990 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2672 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6991 : Blocked tgt 8 s6991 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6991 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6992 : Blocked tgt 8 s6992 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6992 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2672 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b6993 : Blocked tgt 8 s6993 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6993 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6994 : Blocked tgt 8 s6994 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6994 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6995 : Blocked tgt 8 s6995 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6995 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6996 : Blocked tgt 8 s6996 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6996 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6997 : Blocked tgt 8 s6997 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6997 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7007 : Blocked tgt 8 s7007 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7007 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7008 : Blocked tgt 8 s7008 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s7008 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5729 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b7009 : Blocked tgt 8 s7009 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7009 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7056 : Blocked tgt 8 s7056 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7056 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl))))))))) (by decide +kernel)
theorem b7057 : Blocked tgt 8 s7057 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7057 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7100 : Blocked tgt 8 s7100 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s7100 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b7101 : Blocked tgt 8 s7101 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7101 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 rfl))))))))) (by decide +kernel)

theorem b7102 : Blocked tgt 8 s7102 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7102 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7103 : Blocked tgt 8 s7103 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7103 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7104 : Blocked tgt 8 s7104 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s7104 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_2708 (PetersenWireProjection.cons pv753_3632 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl))))))))) (by decide +kernel)
theorem b7105 : Blocked tgt 8 s7105 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7105 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7106 : Blocked tgt 8 s7106 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7106 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_6897 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b7107 : Blocked tgt 8 s7107 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7107 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7108 : Blocked tgt 8 s7108 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7108 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7109 : Blocked tgt 8 s7109 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7109 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7110 : Blocked tgt 8 s7110 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7110 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4137 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7111 : Blocked tgt 8 s7111 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7111 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7112 : Blocked tgt 8 s7112 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7112 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1693 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7113 : Blocked tgt 8 s7113 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7113 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b7117 : Blocked tgt 8 s7117 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7117 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7118 : Blocked tgt 8 s7118 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7118 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7119 : Blocked tgt 8 s7119 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7119 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b7120 : Blocked tgt 8 s7120 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s7120 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4622 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b7121 : Blocked tgt 8 s7121 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s7121 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1762 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b7122 : Blocked tgt 8 s7122 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7122 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3368 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7123 : Blocked tgt 8 s7123 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7123 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b7124 : Blocked tgt 8 s7124 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7124 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7125 : Blocked tgt 8 s7125 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7125 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b7126 : Blocked tgt 8 s7126 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s7126 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b7127 : Blocked tgt 8 s7127 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7127 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2938 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7128 : Blocked tgt 8 s7128 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7128 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6007 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b7129 : Blocked tgt 8 s7129 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7129 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1841 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b7130 : Blocked tgt 8 s7130 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7130 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff000a00ff000a00ff000a00ff000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7131 : Blocked tgt 8 s7131 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7131 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7132 : Blocked tgt 8 s7132 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7132 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b7133 : Blocked tgt 8 s7133 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7133 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7134 : Blocked tgt 8 s7134 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s7134 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_6886 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b7135 : Blocked tgt 8 s7135 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7135 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)

theorem b7136 : Blocked tgt 8 s7136 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7136 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7137 : Blocked tgt 8 s7137 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s7137 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1844 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b7138 : Blocked tgt 8 s7138 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s7138 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0a0affff0a0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b7139 : Blocked tgt 8 s7139 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7139 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8339 rfl))))))))) (by decide +kernel)
theorem b7140 : Blocked tgt 8 s7140 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7140 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_587 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b7141 : Blocked tgt 8 s7141 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s7141 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1850 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b7143 : Blocked tgt 8 s7143 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,false),(5,true))] s7143 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a00000a0a00000a0a00000a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xa0a00000a0a00000a0a00000a0a : BitVec 128) = 0xa0a00000a0a00000a0a00000a0a) (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b7144 : Blocked tgt 8 s7144 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7144 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4146 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7145 : Blocked tgt 8 s7145 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7145 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4146 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7146 : Blocked tgt 8 s7146 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7146 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4146 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7147 : Blocked tgt 8 s7147 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7147 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x808000008080000080800000808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b7148 : Blocked tgt 8 s7148 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7148 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x808000008080000080800000808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7177 : Blocked tgt 8 s7177 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7177 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_4893 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7178 : Blocked tgt 8 s7178 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7178 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7179 : Blocked tgt 8 s7179 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7179 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xccccc4c4ccccc4c4ccccc4c4ccccc4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)

theorem b7180 : Blocked tgt 8 s7180 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7180 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xccccc4c4ccccc4c4ccccc4c4ccccc4c4 : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7181 : Blocked tgt 8 s7181 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa,0xaaaaaaaaaaaaaaaafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000),(0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_789) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_789
theorem b7215 : Blocked tgt 8 s7215 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7215 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5568 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7216 : Blocked tgt 8 s7216 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7216 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5568 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7217 : Blocked tgt 8 s7217 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7217 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa0000000a0000000a0000000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b7218 : Blocked tgt 8 s7218 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7218 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa0000000a0000000a0000000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_1496 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
private theorem thetaPair7219i0 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7220,s7221,s7222,s7223]) (hints := [6840,6840,6968,0,777,4526,905,1,6968,4526,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7220,s7221,s7222,s7223], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7220) (b7220) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7221) (b7221) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7222) (b7222) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7223) (b7223) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i1 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7224,s7225,s7226,s7227]) (hints := [4526,4526,5934,0,9797,6840,9925,1,5934,6840,5934,2,4526,4526,9925,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7224,s7225,s7226,s7227], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7224) (b7224) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7225) (b7225) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7226) (b7226) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7227) (b7227) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i2 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word219) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7228,s7229,s7230,s7231]) (hints := [6582,6582,7478,0,4526,4526,1673,1,7478,4526,7478,2,6582,6582,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7228,s7229,s7230,s7231], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7228) (b7228) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7229) (b7229) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7230) (b7230) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7231) (b7231) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i3 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7232,s7233,s7234,s7235]) (hints := [4526,4526,7470,0,6582,6582,2697,1,7470,6582,7470,2,4526,4526,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7232,s7233,s7234,s7235], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7232) (b7232) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7233) (b7233) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7234) (b7234) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7235) (b7235) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i4 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7236,s7237,s7238,s7239]) (hints := [8654,8654,13646,0,430,4526,4745,1,12750,4526,13646,2,8654,8654,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7236,s7237,s7238,s7239], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7236) (b7236) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7237) (b7237) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7238) (b7238) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7239) (b7239) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i5 : PetersenLocalChildren.PairOK tgt 7 s7219 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7240,s7241,s7242,s7243]) (hints := [4526,4526,13614,0,462,8654,8841,1,12718,8654,13614,2,4526,4526,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7240,s7241,s7242,s7243], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7240) (b7240) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7241) (b7241) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7242) (b7242) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7243) (b7243) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i6 : PetersenLocalChildren.PairOK tgt 7 s7219 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7244,s7245,s7246,s7247]) (hints := [8645,8645,9925,0,905,905,5934,1,9925,905,9925,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7244,s7245,s7246,s7247], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7244) (b7244) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7245) (b7245) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7246) (b7246) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7247) (b7247) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i7 : PetersenLocalChildren.PairOK tgt 7 s7219 (word1,word219) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7248,s7249,s7250,s7251]) (hints := [905,905,1673,0,8645,8645,7478,1,1673,8645,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7248,s7249,s7250,s7251], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7248) (b7248) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7249) (b7249) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7250) (b7250) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7251) (b7251) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i8 : PetersenLocalChildren.PairOK tgt 7 s7219 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7252,s7253,s7254,s7255]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7252,s7253,s7254,s7255], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7252) (b7252) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7253) (b7253) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7254) (b7254) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7255) (b7255) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i9 : PetersenLocalChildren.PairOK tgt 7 s7219 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7256,s7257,s7258,s7259]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7256,s7257,s7258,s7259], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7256) (b7256) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7257) (b7257) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7258) (b7258) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7259) (b7259) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i10 : PetersenLocalChildren.PairOK tgt 7 s7219 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7260,s7261,s7262,s7263]) (hints := [905,905,8841,0,453,8645,13614,1,8841,8645,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7260,s7261,s7262,s7263], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7260) (b7260) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7261) (b7261) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7262) (b7262) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7263) (b7263) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i11 : PetersenLocalChildren.PairOK tgt 7 s7219 (word0,word219) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7264,s7265,s7266,s7267]) (hints := [8901,6966,7478,0,8901,9925,1673,1,9925,9925,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7264,s7265,s7266,s7267], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7264) (b7264) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7265) (b7265) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7266) (b7266) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7267) (b7267) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i12 : PetersenLocalChildren.PairOK tgt 7 s7219 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7268,s7269,s7270,s7271]) (hints := [9925,9925,11461,0,2185,6966,2697,1,11461,6966,11461,2,9925,9925,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7268,s7269,s7270,s7271], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7268) (b7268) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7269) (b7269) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7270) (b7270) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7271) (b7271) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i13 : PetersenLocalChildren.PairOK tgt 7 s7219 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7272,s7273,s7274,s7275]) (hints := [9925,9925,12485,0,4745,5934,4745,1,12485,5934,12485,2,9925,9925,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7272,s7273,s7274,s7275], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7272) (b7272) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7273) (b7273) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7274) (b7274) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7275) (b7275) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i14 : PetersenLocalChildren.PairOK tgt 7 s7219 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7276,s7277,s7278,s7279]) (hints := [1669,1669,13614,0,1733,9925,8841,1,9861,9925,13614,2,1669,1669,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7276,s7277,s7278,s7279], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7276) (b7276) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7277) (b7277) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7278) (b7278) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7279) (b7279) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i15 : PetersenLocalChildren.PairOK tgt 7 s7219 (word219,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7280,s7281,s7282,s7283]) (hints := [1673,1673,2697,0,10437,7478,11461,1,2697,7478,2697,2,1673,1673,11461,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7280,s7281,s7282,s7283], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7280) (b7280) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7281) (b7281) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7282) (b7282) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7283) (b7283) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i16 : PetersenLocalChildren.PairOK tgt 7 s7219 (word219,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7284,s7285,s7286,s7287]) (hints := [1673,1673,4745,0,12485,7478,12485,1,4745,7478,4745,2,1673,1673,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7284,s7285,s7286,s7287], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7284) (b7284) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7285) (b7285) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7286) (b7286) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7287) (b7287) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i17 : PetersenLocalChildren.PairOK tgt 7 s7219 (word219,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7288,s7289,s7290,s7291]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7288,s7289,s7290,s7291], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7288) (b7288) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7289) (b7289) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7290) (b7290) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7291) (b7291) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i18 : PetersenLocalChildren.PairOK tgt 7 s7219 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7292,s7293,s7294,s7295]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7292,s7293,s7294,s7295], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7292) (b7292) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7293) (b7293) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7294) (b7294) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7295) (b7295) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i19 : PetersenLocalChildren.PairOK tgt 7 s7219 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7296,s7297,s7298,s7299]) (hints := [2697,2697,8841,0,3269,11461,14646,1,8841,11461,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7296,s7297,s7298,s7299], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7296) (b7296) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7297) (b7297) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7298) (b7298) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7299) (b7299) <|
    PetersenLocalChildren.nil
private theorem thetaPair7219i20 : PetersenLocalChildren.PairOK tgt 7 s7219 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7300,s7301,s7302,s7303]) (hints := [4745,4745,8841,0,4293,12485,13614,1,8841,12485,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7300,s7301,s7302,s7303], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7300) (b7300) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7301) (b7301) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7302) (b7302) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7303) (b7303) <|
    PetersenLocalChildren.nil
theorem b7219 : Blocked tgt 8 s7219 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word219),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word219),(word1,word5),(word1,word2),(word1,word4),(word0,word219),(word0,word5),(word0,word2),(word0,word4),(word219,word5),(word219,word2),(word219,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 7 s7219 p
  exact
    PetersenLocalChildren.push thetaPair7219i0 <|
    PetersenLocalChildren.push thetaPair7219i1 <|
    PetersenLocalChildren.push thetaPair7219i2 <|
    PetersenLocalChildren.push thetaPair7219i3 <|
    PetersenLocalChildren.push thetaPair7219i4 <|
    PetersenLocalChildren.push thetaPair7219i5 <|
    PetersenLocalChildren.push thetaPair7219i6 <|
    PetersenLocalChildren.push thetaPair7219i7 <|
    PetersenLocalChildren.push thetaPair7219i8 <|
    PetersenLocalChildren.push thetaPair7219i9 <|
    PetersenLocalChildren.push thetaPair7219i10 <|
    PetersenLocalChildren.push thetaPair7219i11 <|
    PetersenLocalChildren.push thetaPair7219i12 <|
    PetersenLocalChildren.push thetaPair7219i13 <|
    PetersenLocalChildren.push thetaPair7219i14 <|
    PetersenLocalChildren.push thetaPair7219i15 <|
    PetersenLocalChildren.push thetaPair7219i16 <|
    PetersenLocalChildren.push thetaPair7219i17 <|
    PetersenLocalChildren.push thetaPair7219i18 <|
    PetersenLocalChildren.push thetaPair7219i19 <|
    PetersenLocalChildren.push thetaPair7219i20 <|
    PetersenLocalChildren.nil
theorem b7304 : Blocked tgt 8 s7304 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s7304 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff00ff0aff00ff0aff00ff0aff00ff0a : BitVec 128) = 0xa0a0a0a) (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b7305 : Blocked tgt 8 s7305 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7305 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6226 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7306 : Blocked tgt 8 s7306 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7306 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6226 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7307 : Blocked tgt 8 s7307 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7307 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1401 (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7308 : Blocked tgt 8 s7308 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7308 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500ff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b7309 : Blocked tgt 8 s7309 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7309 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500ff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b7310 : Blocked tgt 8 s7310 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7310 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xff00f500ff00f500ff00f500ff00f500 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7311 : Blocked tgt 8 s7311 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7311 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1496 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500ff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b7312 : Blocked tgt 8 s7312 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s7312 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b7313 : Blocked tgt 8 s7313 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7313 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa0a0000000000000a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b7314 : Blocked tgt 8 s7314 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7314 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0000000000000a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7341 : Blocked tgt 8 s7341 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7341 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7512 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7342 : Blocked tgt 8 s7342 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7342 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_715 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7343 : Blocked tgt 8 s7343 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7343 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_715 (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7344 : Blocked tgt 8 s7344 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7344 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfffff5f500000000fffff5f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
