import M191StartPreferredSignals
import M191ResidualC7A0G1
import M191ResidualC7A0G20
import M191ResidualC7A0G27
import M191ResidualC7A0G38
import M191ResidualC7A0G4
import M191ResidualC7A0G8
import M191ResidualC7A0G9
import M191StagedF0X2Z1G14
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G16
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G19
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G23
import M191StagedF0X2Z1G24
import M191StagedF0X2Z1G25
import M191StagedF0X2Z1G26
import M191StagedF0X2Z1G28
import M191StagedF0X2Z1G29
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G30
import M191StagedF0X2Z1G31
import M191StagedF0X2Z1G32
import M191StagedF0X2Z1G33
import M191StagedF0X2Z1G34
import M191StagedF0X2Z1G35
import M191StagedF0X2Z1G36
import M191StagedF0X2Z1G37
import M191StagedF0X2Z1G38
import M191StagedF0X2Z1G39
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G5
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G9
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows28
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows36
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows4
import M191StartPreferredRows40
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows7
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12022 : Blocked tgt 8 s12022 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050),(0x50505050505050505050505050505050,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffccffccffccffccffccffccffccffcc,0xffffccccffffccccffffccccffffcccc),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s11750) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b11750
theorem b12046 : Blocked tgt 8 s12046 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050),(0x50505050505050505050505050505050,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffff0000ffffffffffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s11790) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b11790
theorem b12148 : Blocked tgt 8 s12148 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,4,18,6,17,21,19,23,8,12,10,14,9,13,11,15,24,12,26,14,25,29,27,31,64,68,66,70,65,69,67,71,80,68,82,70,81,85,83,87,72,76,74,78,73,77,75,79,88,76,90,78,89,93,91,95,32,36,34,38,33,37,35,39,48,36,50,38,49,53,51,55,40,44,42,46,41,45,43,47,56,44,58,46,57,61,59,63,96,100,98,102,97,101,99,103,112,100,114,102,113,117,115,119,104,108,106,110,105,109,107,111,120,108,122,110,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,1,13,3,15,24,28,26,30,17,29,19,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,65,77,67,79,88,92,90,94,81,93,83,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,33,45,35,47,56,60,58,62,49,61,51,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,97,109,99,111,120,124,122,126,113,125,115,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff5050ffff5050ffff5050ffff5050,0xff0aff0aff0aff0aff0aff0aff0aff0a),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3265) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3265
theorem b12200 : Blocked tgt 8 s12200 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,4,34,6,33,37,35,39,64,68,66,70,65,69,67,71,96,68,98,70,97,101,99,103,8,12,10,14,9,13,11,15,40,12,42,14,41,45,43,47,72,76,74,78,73,77,75,79,104,76,106,78,105,109,107,111,16,20,18,22,17,21,19,23,48,20,50,22,49,53,51,55,80,84,82,86,81,85,83,87,112,84,114,86,113,117,115,119,24,28,26,30,25,29,27,31,56,28,58,30,57,61,59,63,88,92,90,94,89,93,91,95,120,92,122,94,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,1,13,3,15,40,44,42,46,33,45,35,47,72,76,74,78,65,77,67,79,104,108,106,110,97,109,99,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,17,29,19,31,56,60,58,62,49,61,51,63,88,92,90,94,81,93,83,95,120,124,122,126,113,125,115,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000),(0xffffffff50505050ffffffff50505050,0xff0aff0aff0aff0aff0aff0aff0aff0a),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3265) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3265
theorem b12424 : Blocked tgt 8 s12424 := by
  apply PetersenFastNode.node (nxt := #[s5924,s12425,s12426,s12381,s11063,s12392,s12427]) (hints := [6971,5297,6971,5295,5553,9808,4529,4529,5553,0,5553,6585,5553,11344,7473,5553,9681,1457,13649,9681,1,5553,5553,2,5553,1489,13617,5553,5679,5681,5679,5935,1548,3,1548,6971,6843,4,6843,6971,11472,4923,11472,4907,2875,6971,13649,9680,9680,8844,13361,8844,6971,5041,5041,5937,6969,6969,5937,5937,6969,11472,4921,11472,5937,10065,1841,13649,10065,9807,5937,5937,9807,5937,1873,13617,5937,7481,7481,10440,10448,10440,11464,14681,13649,14681,13649,1548,5,6,1548,14649,13617,14649,13617,4779,11472,6827,11472,14681,13649,14681,13649,2715,6843,6843,2715,14649,13617,14649,13617,11472,3377,13649,11472,11472,7473,7473,11472,3216,3280,11408,3216,13520,13520,8844,13617,13585,13585,8844,13617,8844,13617]) (by decide +kernel)
  change ∀ b ∈ [s5924,s12425,s12426,s12381,s11063,s12392,s12427], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5924) b5924 <|
    PetersenLocalChildren.push (x := s12425) b12425 <|
    PetersenLocalChildren.push (x := s12426) b12426 <|
    PetersenLocalChildren.push (x := s12381) b12381 <|
    PetersenLocalChildren.push (x := s11063) b11063 <|
    PetersenLocalChildren.push (x := s12392) b12392 <|
    PetersenLocalChildren.push (x := s12427) b12427 <|
    PetersenLocalChildren.nil
theorem b12438 : Blocked tgt 8 s12438 := by
  apply PetersenFastNode.node (nxt := #[s12439,s12452,s12453,s12454,s12385,s5106,s12455,s5109,s3312,s12456,s12457,s12458,s12459,s12460,s12461,s1735,s3159,s12462,s12315,s12463,s12464,s9962,s10881,s12465,s12466,s12467,s12468,s12469,s12470]) (hints := [4551,1570,4551,0,1,2,8670,1570,8670,930,3,930,8670,4,8670,930,1570,930,5063,1570,5959,5063,5,6,7503,7,7503,6865,1570,6865,7503,1570,7503,6865,8,6865,10462,1570,10462,2722,9,2722,10462,10,10462,1570,1570,2722,12510,1570,12510,4770,11,4770,12510,12,12510,1570,1570,4770,13639,1570,13639,8866,13,8866,13639,14,13639,1570,1570,8866,930,4293,930,4295,4551,8670,930,4551,930,4293,4293,8670,4551,4551,5959,9822,15,16,6865,4551,6865,6607,17,18,2722,4551,2722,10462,19,10462,2722,20,2722,4551,4551,10462,4770,8679,4770,455,4551,12510,4770,4551,4770,8679,8679,12510,8866,4551,8866,487,8679,21,8866,8679,8866,4551,4551,22,8670,8670,5701,930,930,5959,930,930,5701,8670,8670,5959,6865,6993,6865,802,930,7503,6865,930,6865,6993,6993,7503,930,930,2722,4945,6993,7495,2722,6993,2722,930,930,7495,930,930,4770,2897,6993,13671,4770,6993,4770,930,930,13671,930,930,8866,478,8670,13639,8866,8670,8866,930,930,13639,7503,23,7503,6865,5959,6865,7503,5959,7503,6865,24,6865,10462,5959,10462,2722,25,2722,10462,26,10462,2722,5959,2722,12510,10087,12510,4770,5959,4770,12510,5959,12510,4770,10087,4770,5959,5959,13639,8866,10087,8866,13639,10087,13639,8866,5959,8866,4801,4801,27,4817,6865,2722,6849,6865,28,4801,4801,2722,2737,2737,14703,2769,6865,4770,6833,6865,14703,2737,2737,4770,6865,6865,14929,8738,11631,8866,14929,11631,14929,6865,6865,8866,2722,2722,4770,3399,7495,14703,4770,7495,4770,2722,2722,14703,2722,2722,8866,12881,10462,14929,8866,10462,8866,2722,2722,14929,4770,4770,8866,10833,12510,14929,8866,12510,8866,4770,4770,14929]) (by decide +kernel)
  change ∀ b ∈ [s12439,s12452,s12453,s12454,s12385,s5106,s12455,s5109,s3312,s12456,s12457,s12458,s12459,s12460,s12461,s1735,s3159,s12462,s12315,s12463,s12464,s9962,s10881,s12465,s12466,s12467,s12468,s12469,s12470], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12439) b12439 <|
    PetersenLocalChildren.push (x := s12452) b12452 <|
    PetersenLocalChildren.push (x := s12453) b12453 <|
    PetersenLocalChildren.push (x := s12454) b12454 <|
    PetersenLocalChildren.push (x := s12385) b12385 <|
    PetersenLocalChildren.push (x := s5106) b5106 <|
    PetersenLocalChildren.push (x := s12455) b12455 <|
    PetersenLocalChildren.push (x := s5109) b5109 <|
    PetersenLocalChildren.push (x := s3312) b3312 <|
    PetersenLocalChildren.push (x := s12456) b12456 <|
    PetersenLocalChildren.push (x := s12457) b12457 <|
    PetersenLocalChildren.push (x := s12458) b12458 <|
    PetersenLocalChildren.push (x := s12459) b12459 <|
    PetersenLocalChildren.push (x := s12460) b12460 <|
    PetersenLocalChildren.push (x := s12461) b12461 <|
    PetersenLocalChildren.push (x := s1735) b1735 <|
    PetersenLocalChildren.push (x := s3159) b3159 <|
    PetersenLocalChildren.push (x := s12462) b12462 <|
    PetersenLocalChildren.push (x := s12315) b12315 <|
    PetersenLocalChildren.push (x := s12463) b12463 <|
    PetersenLocalChildren.push (x := s12464) b12464 <|
    PetersenLocalChildren.push (x := s9962) b9962 <|
    PetersenLocalChildren.push (x := s10881) b10881 <|
    PetersenLocalChildren.push (x := s12465) b12465 <|
    PetersenLocalChildren.push (x := s12466) b12466 <|
    PetersenLocalChildren.push (x := s12467) b12467 <|
    PetersenLocalChildren.push (x := s12468) b12468 <|
    PetersenLocalChildren.push (x := s12469) b12469 <|
    PetersenLocalChildren.push (x := s12470) b12470 <|
    PetersenLocalChildren.nil
theorem b12483 : Blocked tgt 8 s12483 := by
  apply PetersenFastNode.node (nxt := #[s1742,s6021,s12484,s12485,s12486,s12487,s12488,s12489,s12490]) (hints := [910,5299,910,5297,5555,0,4531,4531,5555,1,5555,6587,5555,11346,7475,5555,9683,5555,5555,9683,9683,5555,5555,9683,5555,1491,13619,5555,9682,5683,5681,9682,8650,8658,9674,8650,6845,9682,9682,6973,9682,4925,11474,9682,9682,2877,4750,9682,9682,910,910,9682,1426,1490,9618,1426,5043,5043,5939,6971,6971,5939,5939,6971,11474,4923,11474,5939,1843,5939,4750,5939,10067,5939,8846,13619,5939,7483,7483,10442,10450,10442,11466,1550,2,4750,1550,3,1550,1550,4,14651,13619,14651,13619,4781,11474,6829,11474,2717,2749,6813,2717,5,6845,6845,6,14651,13619,14651,13619,11474,7475,7475,11474,11474,7475,7475,11474,3218,3282,11410,3218,13522,13522,4750,13619,8846,13619,7,13619,8,13619]) (by decide +kernel)
  change ∀ b ∈ [s1742,s6021,s12484,s12485,s12486,s12487,s12488,s12489,s12490], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1742) b1742 <|
    PetersenLocalChildren.push (x := s6021) b6021 <|
    PetersenLocalChildren.push (x := s12484) b12484 <|
    PetersenLocalChildren.push (x := s12485) b12485 <|
    PetersenLocalChildren.push (x := s12486) b12486 <|
    PetersenLocalChildren.push (x := s12487) b12487 <|
    PetersenLocalChildren.push (x := s12488) b12488 <|
    PetersenLocalChildren.push (x := s12489) b12489 <|
    PetersenLocalChildren.push (x := s12490) b12490 <|
    PetersenLocalChildren.nil
theorem b12513 : Blocked tgt 8 s12513 := by
  apply PetersenFastNode.node (nxt := #[s1758,s2738,s12514,s12321,s12515,s12516,s12517,s5113,s12518,s12531,s12532,s9968,s10892,s12392,s12533,s12484,s12534,s12535,s12459,s12536,s12537,s12538,s12539,s12540,s12541,s12542,s12543,s12544,s12545,s12546,s12547,s12548,s12549,s12550,s12551]) (hints := [936,4299,936,4301,4557,9708,936,4557,936,4299,4299,9708,4557,4557,5069,9836,0,1,6613,4557,7509,6613,2,3,4557,4557,7501,11372,4,11500,6605,5,7501,4557,4557,11500,9709,9709,13677,1485,4557,12524,12781,4557,13677,9709,9709,12524,8685,6,1576,4557,4557,7,4557,4557,1576,8,9,10,4557,4557,13645,1517,9709,11,12749,9709,13645,4557,4557,12,9708,9708,4811,4813,936,5069,4811,936,4811,9708,9708,5069,6871,6999,6871,9708,9708,7509,9708,9708,6871,6999,6999,7509,9708,9708,11500,4951,6999,7501,11500,6999,11500,9708,9708,7501,9708,9708,12524,6999,6999,13677,12524,6999,12524,9708,9708,13677,8676,8676,1576,8684,9708,13,9700,9708,1576,8676,8676,14,1452,1452,8872,1516,9708,13645,9644,9708,8872,1452,1452,13645,6997,6997,7509,4941,5069,6871,7125,5069,7509,6997,6997,6871,11500,5069,11500,4949,6997,2728,11500,6997,11500,5069,5069,2728,12524,10093,12524,1869,5069,15,12524,5069,12524,10093,10093,16,9197,11125,17,5069,5069,1576,5069,5069,18,11125,11125,1576,5069,5069,13645,1901,10093,8872,13261,10093,13645,5069,5069,8872,4807,4807,19,11500,7509,11500,7493,7509,20,11500,4807,11500,3413,2743,21,12524,7509,12524,7509,7509,22,12524,2743,12524,2743,2743,23,7509,7509,1576,7509,7509,24,11637,2743,1576,7509,7509,14677,12621,25,13645,14677,26,14677,7509,7509,13645,11500,11500,12524,3405,7501,27,12524,7501,12524,11500,11500,28,10468,10468,1576,10476,11500,29,11492,11500,1576,10468,10468,30,3244,3244,13645,3308,11500,14677,11436,11500,13645,3244,3244,14677,12516,12524,1576,12516,31,32,4268,4268,8872,4332,12524,13645,12460,12524,8872,4268,4268,13645,1576,1576,8872,13645,33,13645,8872,34,8872,13645,1576,13645]) (by decide +kernel)
  change ∀ b ∈ [s1758,s2738,s12514,s12321,s12515,s12516,s12517,s5113,s12518,s12531,s12532,s9968,s10892,s12392,s12533,s12484,s12534,s12535,s12459,s12536,s12537,s12538,s12539,s12540,s12541,s12542,s12543,s12544,s12545,s12546,s12547,s12548,s12549,s12550,s12551], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1758) b1758 <|
    PetersenLocalChildren.push (x := s2738) b2738 <|
    PetersenLocalChildren.push (x := s12514) b12514 <|
    PetersenLocalChildren.push (x := s12321) b12321 <|
    PetersenLocalChildren.push (x := s12515) b12515 <|
    PetersenLocalChildren.push (x := s12516) b12516 <|
    PetersenLocalChildren.push (x := s12517) b12517 <|
    PetersenLocalChildren.push (x := s5113) b5113 <|
    PetersenLocalChildren.push (x := s12518) b12518 <|
    PetersenLocalChildren.push (x := s12531) b12531 <|
    PetersenLocalChildren.push (x := s12532) b12532 <|
    PetersenLocalChildren.push (x := s9968) b9968 <|
    PetersenLocalChildren.push (x := s10892) b10892 <|
    PetersenLocalChildren.push (x := s12392) b12392 <|
    PetersenLocalChildren.push (x := s12533) b12533 <|
    PetersenLocalChildren.push (x := s12484) b12484 <|
    PetersenLocalChildren.push (x := s12534) b12534 <|
    PetersenLocalChildren.push (x := s12535) b12535 <|
    PetersenLocalChildren.push (x := s12459) b12459 <|
    PetersenLocalChildren.push (x := s12536) b12536 <|
    PetersenLocalChildren.push (x := s12537) b12537 <|
    PetersenLocalChildren.push (x := s12538) b12538 <|
    PetersenLocalChildren.push (x := s12539) b12539 <|
    PetersenLocalChildren.push (x := s12540) b12540 <|
    PetersenLocalChildren.push (x := s12541) b12541 <|
    PetersenLocalChildren.push (x := s12542) b12542 <|
    PetersenLocalChildren.push (x := s12543) b12543 <|
    PetersenLocalChildren.push (x := s12544) b12544 <|
    PetersenLocalChildren.push (x := s12545) b12545 <|
    PetersenLocalChildren.push (x := s12546) b12546 <|
    PetersenLocalChildren.push (x := s12547) b12547 <|
    PetersenLocalChildren.push (x := s12548) b12548 <|
    PetersenLocalChildren.push (x := s12549) b12549 <|
    PetersenLocalChildren.push (x := s12550) b12550 <|
    PetersenLocalChildren.push (x := s12551) b12551 <|
    PetersenLocalChildren.nil
theorem b12642 : Blocked tgt 8 s12642 := by
  apply PetersenFastNode.node (nxt := #[s1764,s2746,s5119,s6467,s9975,s10886,s12643,s12644,s11109,s12647,s12648,s12649,s12542,s12650,s12651,s12652,s12653,s12654,s12655,s12656,s12657,s12658,s12659,s12660]) (hints := [6988,5312,6988,5314,5570,9697,6988,5570,6988,5312,5312,9697,5570,5570,5954,9825,0,1,10730,10730,11626,4546,5570,2,11626,5570,11626,10730,10730,3,5570,5570,7490,8682,10730,11489,7490,10730,7490,5570,5570,11489,9698,9698,13666,1474,5570,13537,13666,5570,13666,9698,9698,13537,5570,5570,13634,1506,9698,4,13634,9698,13634,5570,5570,5,5570,5570,6860,6602,6,7,9697,9697,5696,5698,6988,5954,5696,6988,5696,9697,9697,5954,8665,8665,1565,8673,9697,11626,9689,9697,1565,8665,8665,11626,9697,9697,11489,4940,6988,7490,11489,6988,11489,9697,9697,7490,9697,9697,13537,2892,6988,13666,13537,6988,13537,9697,9697,13666,1441,1441,8733,1505,9697,13634,9633,9697,8733,1441,1441,13634,6860,6988,6860,9697,9697,8,9697,9697,6860,6988,6988,9,6986,6986,11626,5058,5954,1565,11626,5954,11626,6986,6986,1565,11489,5954,11489,4938,6986,2717,11489,6986,11489,5954,5954,2717,13537,10082,13537,1858,5954,4765,13537,5954,13537,10082,10082,4765,5954,5954,13634,1890,10082,8733,13634,10082,13634,5954,5954,8733,6986,6986,10,5954,5954,6860,5954,5954,11,6986,6986,6860,10457,1565,10457,10465,11626,11489,10457,11626,10457,11481,1565,11489,12505,11626,12505,12513,12,13537,12505,13,12505,13529,11626,13537,3434,1565,8733,3434,11626,13634,11626,11626,8733,13634,1565,13634,7498,11626,6860,7498,14,15,11489,11489,13537,3394,7490,14698,13537,7490,13537,11489,11489,14698,3233,3233,13634,3297,11489,16,11425,11489,13634,3233,3233,17,4796,18,4796,11489,11489,6860,11489,11489,4796,6844,19,6860,5281,5281,8733,5345,13537,13634,13473,13537,8733,5281,5281,13634,2732,20,2732,13537,13537,6860,13537,13537,2732,6828,21,6860,13634,13634,6860,14666,22,23]) (by decide +kernel)
  change ∀ b ∈ [s1764,s2746,s5119,s6467,s9975,s10886,s12643,s12644,s11109,s12647,s12648,s12649,s12542,s12650,s12651,s12652,s12653,s12654,s12655,s12656,s12657,s12658,s12659,s12660], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1764) b1764 <|
    PetersenLocalChildren.push (x := s2746) b2746 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s6467) b6467 <|
    PetersenLocalChildren.push (x := s9975) b9975 <|
    PetersenLocalChildren.push (x := s10886) b10886 <|
    PetersenLocalChildren.push (x := s12643) b12643 <|
    PetersenLocalChildren.push (x := s12644) b12644 <|
    PetersenLocalChildren.push (x := s11109) b11109 <|
    PetersenLocalChildren.push (x := s12647) b12647 <|
    PetersenLocalChildren.push (x := s12648) b12648 <|
    PetersenLocalChildren.push (x := s12649) b12649 <|
    PetersenLocalChildren.push (x := s12542) b12542 <|
    PetersenLocalChildren.push (x := s12650) b12650 <|
    PetersenLocalChildren.push (x := s12651) b12651 <|
    PetersenLocalChildren.push (x := s12652) b12652 <|
    PetersenLocalChildren.push (x := s12653) b12653 <|
    PetersenLocalChildren.push (x := s12654) b12654 <|
    PetersenLocalChildren.push (x := s12655) b12655 <|
    PetersenLocalChildren.push (x := s12656) b12656 <|
    PetersenLocalChildren.push (x := s12657) b12657 <|
    PetersenLocalChildren.push (x := s12658) b12658 <|
    PetersenLocalChildren.push (x := s12659) b12659 <|
    PetersenLocalChildren.push (x := s12660) b12660 <|
    PetersenLocalChildren.nil
theorem b12790 : Blocked tgt 8 s12790 := by
  apply PetersenFastNode.node (nxt := #[s3348,s5884,s8602,s10584,s572,s12791,s2746,s12792,s12793,s12794,s12795]) (hints := [5557,5557,912,9684,912,9684,9940,9940,1680,0,1680,1,2704,11476,2704,11476,4752,13524,4752,13524,8848,2,8848,3,4,5,6975,9684,6975,9684,5941,6,6069,11613,1552,11613,1680,7477,11476,7477,11476,13653,13524,13653,13524,13621,8720,13621,8848,6847,6847,9684,912,912,9684,8652,8660,9676,8652,9684,4927,11476,9684,9684,2879,13524,9684,1428,1492,9620,1428,6975,9684,9684,6975,6973,1680,11613,1680,11476,2704,11476,2704,13524,4752,13524,4752,5941,8848,13621,8848,6973,5941,5941,6973,10444,10452,10444,11468,12492,12500,12492,13516,1680,3421,8848,1680,1680,7485,11476,3381,13524,11476,3220,3284,11412,3220,7,11476,11476,8,5268,5332,13460,5268,9,13524,13524,10,8848,14653]) (by decide +kernel)
  change ∀ b ∈ [s3348,s5884,s8602,s10584,s572,s12791,s2746,s12792,s12793,s12794,s12795], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s5884) b5884 <|
    PetersenLocalChildren.push (x := s8602) b8602 <|
    PetersenLocalChildren.push (x := s10584) b10584 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s12791) b12791 <|
    PetersenLocalChildren.push (x := s2746) b2746 <|
    PetersenLocalChildren.push (x := s12792) b12792 <|
    PetersenLocalChildren.push (x := s12793) b12793 <|
    PetersenLocalChildren.push (x := s12794) b12794 <|
    PetersenLocalChildren.push (x := s12795) b12795 <|
    PetersenLocalChildren.nil
theorem b13087 : Blocked tgt 8 s13087 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12336) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12336
theorem b13097 : Blocked tgt 8 s13097 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12431) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12431
theorem b13187 : Blocked tgt 8 s13187 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xfff0fff0fff0fff0fff0fff0fff0fff0,0xfffffffffffffffff0f0f0f0f0f0f0f0),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12494) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12494
theorem b13593 : Blocked tgt 8 s13593 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaa,0xaa00aa00aa00aa00aa00aa00aa00aa),(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12903) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12903
theorem b13720 : Blocked tgt 8 s13720 := by
  apply PetersenFastNode.node (nxt := #[s13721,s13722,s4281,s13727,s13728,s12342,s4278,s13729,s8721,s13730,s12340]) (hints := [0,1,2,3,4,6847,5,6847,9684,912,9684,8652,5941,6973,5941,6973,1680,1680,11476,2704,11476,2704,13524,4752,13524,4752,13621,8848,13621,8848,6589,6589,912,9684,912,9684,6973,9940,7227,6,7227,7,2704,11476,2704,11476,4752,13524,4752,13524,8848,8,8848,9,6847,784,6975,6847,6973,6847,7101,6847,10,7227,6847,4783,4799,6831,4783,14685,2751,14685,2719,14653,8720,14653,6847,10845,912,912,6973,912,9684,9676,912,912,4927,2704,912,912,2879,4752,912,912,14653,8848,912,6973,5941,5941,6973,4909,2704,6957,2704,11101,4752,14685,4752,6973,8848,14653,8848,2704,10452,2704,11468,4752,12500,4752,13516,8848,13621,8848,13621,2704,12637,4752,2704,2704,12605,8848,2704,4752,14653,8848,4752]) (by decide +kernel)
  change ∀ b ∈ [s13721,s13722,s4281,s13727,s13728,s12342,s4278,s13729,s8721,s13730,s12340], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13721) b13721 <|
    PetersenLocalChildren.push (x := s13722) b13722 <|
    PetersenLocalChildren.push (x := s4281) b4281 <|
    PetersenLocalChildren.push (x := s13727) b13727 <|
    PetersenLocalChildren.push (x := s13728) b13728 <|
    PetersenLocalChildren.push (x := s12342) b12342 <|
    PetersenLocalChildren.push (x := s4278) b4278 <|
    PetersenLocalChildren.push (x := s13729) b13729 <|
    PetersenLocalChildren.push (x := s8721) b8721 <|
    PetersenLocalChildren.push (x := s13730) b13730 <|
    PetersenLocalChildren.push (x := s12340) b12340 <|
    PetersenLocalChildren.nil
theorem b13741 : Blocked tgt 8 s13741 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffffffffffffffffcfcfcfcfcfcfcfc,0xfffcfffcfffcfffcfffcfffcfffcfffc)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s13714) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b13714
theorem b13806 : Blocked tgt 8 s13806 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff3030303030303030,0xff30ff30ff30ff30ff30ff30ff30ff30)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s13784) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b13784
theorem b13859 : Blocked tgt 8 s13859 := by
  apply PetersenFastNode.node (nxt := #[s13860,s13861,s13862,s13863,s13864,s13865,s426,s13866,s13867,s13868,s584,s12351,s13869,s12742,s13870,s13871,s13699,s13872,s13873,s1593,s13874,s13875,s13876,s13877,s618,s13878,s13879,s13880,s13881,s13882,s13883,s594,s13717,s596,s13884,s13885,s13886,s13887,s13888,s13889,s13890,s977,s13891,s5524,s13892,s13893,s13894,s13895,s13896,s13897,s7656,s13898,s13899,s13900,s9504,s13901,s13902,s13903]) (hints := [6894,6894,0,9731,1,9731,6634,2,3,6894,6894,9731,5988,6378,5988,6382,6894,8955,5988,6894,5988,6116,6378,8955,5604,6894,4,5604,5,6,7,8,9,6894,6894,10,7532,6894,7532,11,12,13,7532,14,7532,6894,6894,15,7524,4830,7524,4846,6894,2751,7524,6894,7524,4830,4830,2751,13700,2766,13700,2798,6894,4799,13700,6894,13700,2766,2766,4799,13668,6894,13668,8767,10506,8895,13668,10506,13668,6894,6894,8895,9731,9731,8955,447,16,5988,8955,17,8955,9731,9731,5988,9731,9731,18,19,20,21,959,22,23,959,9731,24,8699,8699,25,8707,9731,7532,9723,9731,26,8699,8699,7532,2751,9731,2751,7268,27,7524,2751,28,2751,9731,9731,7524,4799,9731,4799,13444,29,13700,4799,30,4799,9731,9731,13700,8895,1475,8895,1539,9731,13668,8895,9731,8895,1475,1475,13668,8955,8955,31,5988,5988,32,9987,5988,33,9987,8955,34,8955,8955,7532,8963,5988,35,7532,5988,7532,8955,8955,36,11523,8955,11523,2239,7020,2751,11523,7020,11523,8955,8955,2751,13571,8955,13571,4287,5988,4799,13571,5988,13571,8955,8955,4799,5988,5988,13668,8895,8955,8895,8891,8955,13668,8891,5988,8895,37,38,39,7532,40,7532,1727,41,42,1727,43,7532,2751,44,2751,7524,45,7524,2751,46,2751,7524,47,7524,4799,48,4799,13700,49,13700,4799,50,4799,13700,51,13700,8895,52,8895,13668,53,13668,8895,54,8895,13668,55,13668,2751,56,2751,10499,7532,11523,2751,7532,2751,11515,57,11523,4799,11660,4799,12547,7532,13571,4799,7532,4799,13563,11660,13571,8895,7532,8895,3468,11660,13668,8895,11660,8895,7532,7532,13668,2751,2751,4799,3428,7524,14732,4799,7524,4799,2751,2751,14732,2751,2751,8895,3331,11523,14700,8895,11523,8895,2751,2751,14700,4799,4799,8895,5379,13571,13668,8895,13571,8895,4799,4799,13668]) (by decide +kernel)
  change ∀ b ∈ [s13860,s13861,s13862,s13863,s13864,s13865,s426,s13866,s13867,s13868,s584,s12351,s13869,s12742,s13870,s13871,s13699,s13872,s13873,s1593,s13874,s13875,s13876,s13877,s618,s13878,s13879,s13880,s13881,s13882,s13883,s594,s13717,s596,s13884,s13885,s13886,s13887,s13888,s13889,s13890,s977,s13891,s5524,s13892,s13893,s13894,s13895,s13896,s13897,s7656,s13898,s13899,s13900,s9504,s13901,s13902,s13903], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13860) b13860 <|
    PetersenLocalChildren.push (x := s13861) b13861 <|
    PetersenLocalChildren.push (x := s13862) b13862 <|
    PetersenLocalChildren.push (x := s13863) b13863 <|
    PetersenLocalChildren.push (x := s13864) b13864 <|
    PetersenLocalChildren.push (x := s13865) b13865 <|
    PetersenLocalChildren.push (x := s426) b426 <|
    PetersenLocalChildren.push (x := s13866) b13866 <|
    PetersenLocalChildren.push (x := s13867) b13867 <|
    PetersenLocalChildren.push (x := s13868) b13868 <|
    PetersenLocalChildren.push (x := s584) b584 <|
    PetersenLocalChildren.push (x := s12351) b12351 <|
    PetersenLocalChildren.push (x := s13869) b13869 <|
    PetersenLocalChildren.push (x := s12742) b12742 <|
    PetersenLocalChildren.push (x := s13870) b13870 <|
    PetersenLocalChildren.push (x := s13871) b13871 <|
    PetersenLocalChildren.push (x := s13699) b13699 <|
    PetersenLocalChildren.push (x := s13872) b13872 <|
    PetersenLocalChildren.push (x := s13873) b13873 <|
    PetersenLocalChildren.push (x := s1593) b1593 <|
    PetersenLocalChildren.push (x := s13874) b13874 <|
    PetersenLocalChildren.push (x := s13875) b13875 <|
    PetersenLocalChildren.push (x := s13876) b13876 <|
    PetersenLocalChildren.push (x := s13877) b13877 <|
    PetersenLocalChildren.push (x := s618) b618 <|
    PetersenLocalChildren.push (x := s13878) b13878 <|
    PetersenLocalChildren.push (x := s13879) b13879 <|
    PetersenLocalChildren.push (x := s13880) b13880 <|
    PetersenLocalChildren.push (x := s13881) b13881 <|
    PetersenLocalChildren.push (x := s13882) b13882 <|
    PetersenLocalChildren.push (x := s13883) b13883 <|
    PetersenLocalChildren.push (x := s594) b594 <|
    PetersenLocalChildren.push (x := s13717) b13717 <|
    PetersenLocalChildren.push (x := s596) b596 <|
    PetersenLocalChildren.push (x := s13884) b13884 <|
    PetersenLocalChildren.push (x := s13885) b13885 <|
    PetersenLocalChildren.push (x := s13886) b13886 <|
    PetersenLocalChildren.push (x := s13887) b13887 <|
    PetersenLocalChildren.push (x := s13888) b13888 <|
    PetersenLocalChildren.push (x := s13889) b13889 <|
    PetersenLocalChildren.push (x := s13890) b13890 <|
    PetersenLocalChildren.push (x := s977) b977 <|
    PetersenLocalChildren.push (x := s13891) b13891 <|
    PetersenLocalChildren.push (x := s5524) b5524 <|
    PetersenLocalChildren.push (x := s13892) b13892 <|
    PetersenLocalChildren.push (x := s13893) b13893 <|
    PetersenLocalChildren.push (x := s13894) b13894 <|
    PetersenLocalChildren.push (x := s13895) b13895 <|
    PetersenLocalChildren.push (x := s13896) b13896 <|
    PetersenLocalChildren.push (x := s13897) b13897 <|
    PetersenLocalChildren.push (x := s7656) b7656 <|
    PetersenLocalChildren.push (x := s13898) b13898 <|
    PetersenLocalChildren.push (x := s13899) b13899 <|
    PetersenLocalChildren.push (x := s13900) b13900 <|
    PetersenLocalChildren.push (x := s9504) b9504 <|
    PetersenLocalChildren.push (x := s13901) b13901 <|
    PetersenLocalChildren.push (x := s13902) b13902 <|
    PetersenLocalChildren.push (x := s13903) b13903 <|
    PetersenLocalChildren.nil
theorem b13963 : Blocked tgt 8 s13963 := by
  apply PetersenFastNode.node (nxt := #[s13964,s1612,s4323,s13965,s9500,s13966,s13967,s611,s1690,s13968,s11438,s12394,s13099,s11109,s11507,s13973,s13974]) (hints := [5563,5563,0,9690,1,9690,9946,9946,7491,2,7491,3,2710,11482,2710,11482,4758,13530,4758,13530,13627,4,13627,5,6,7,8,9,6853,9690,10,9690,5947,6853,6075,7491,11,7491,6853,7483,11482,7483,11482,13659,13530,13659,13530,13627,12,13627,6853,6853,13,14,6853,9690,5691,5689,9690,8658,8666,9682,8658,9690,7227,11482,9690,9690,13403,13530,9690,1434,1498,9626,1434,9690,402,6979,4923,7491,6979,11482,2710,11482,2710,13530,4758,13530,4758,5947,1883,13627,5947,15,5947,5947,16,10450,10458,10450,11474,12498,12506,12498,13522,7491,3427,14659,7491,1686,1686,11482,3387,13530,11482,3226,3290,11418,3226,2194,11482,11482,2194,5274,5338,13466,5274,4242,13530,13530,4242,8854,8854]) (by decide +kernel)
  change ∀ b ∈ [s13964,s1612,s4323,s13965,s9500,s13966,s13967,s611,s1690,s13968,s11438,s12394,s13099,s11109,s11507,s13973,s13974], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13964) b13964 <|
    PetersenLocalChildren.push (x := s1612) b1612 <|
    PetersenLocalChildren.push (x := s4323) b4323 <|
    PetersenLocalChildren.push (x := s13965) b13965 <|
    PetersenLocalChildren.push (x := s9500) b9500 <|
    PetersenLocalChildren.push (x := s13966) b13966 <|
    PetersenLocalChildren.push (x := s13967) b13967 <|
    PetersenLocalChildren.push (x := s611) b611 <|
    PetersenLocalChildren.push (x := s1690) b1690 <|
    PetersenLocalChildren.push (x := s13968) b13968 <|
    PetersenLocalChildren.push (x := s11438) b11438 <|
    PetersenLocalChildren.push (x := s12394) b12394 <|
    PetersenLocalChildren.push (x := s13099) b13099 <|
    PetersenLocalChildren.push (x := s11109) b11109 <|
    PetersenLocalChildren.push (x := s11507) b11507 <|
    PetersenLocalChildren.push (x := s13973) b13973 <|
    PetersenLocalChildren.push (x := s13974) b13974 <|
    PetersenLocalChildren.nil
theorem b13978 : Blocked tgt 8 s13978 := by
  apply PetersenFastNode.node (nxt := #[s10485,s13979,s9504,s13980,s13981,s13983,s13984,s1614,s4324,s13985,s9501,s13986,s11440,s12395]) (hints := [0,1,2,3,6850,4,6850,5,9687,1431,9687,1431,10072,5944,10072,5944,11616,7488,1683,1683,11479,3223,11479,3223,13527,5271,13527,5271,8851,13624,5560,5560,6,1431,7,1431,1687,1687,7488,8,7488,9,7480,3223,7480,3223,4755,5271,4755,5271,8851,10,8851,11,6850,1431,12,1431,5944,6850,6072,7488,13,7488,6850,7480,3223,7480,3223,13656,5271,13656,5271,6850,8723,14914,6850,1431,5688,5686,1431,407,407,1431,7488,1431,7224,3223,1431,1431,13400,5271,1431,1431,9687,9687,1431,6976,4920,7488,6976,3223,4928,3223,5944,5271,1848,5271,1816,5944,8851,10072,5944,10447,3223,7472,3223,3360,5271,7456,5271,7488,11616,8851,7488,3223,3384,5271,3223,3223,11479,11479,3223,5271,13527,13527,5271]) (by decide +kernel)
  change ∀ b ∈ [s10485,s13979,s9504,s13980,s13981,s13983,s13984,s1614,s4324,s13985,s9501,s13986,s11440,s12395], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s10485) b10485 <|
    PetersenLocalChildren.push (x := s13979) b13979 <|
    PetersenLocalChildren.push (x := s9504) b9504 <|
    PetersenLocalChildren.push (x := s13980) b13980 <|
    PetersenLocalChildren.push (x := s13981) b13981 <|
    PetersenLocalChildren.push (x := s13983) b13983 <|
    PetersenLocalChildren.push (x := s13984) b13984 <|
    PetersenLocalChildren.push (x := s1614) b1614 <|
    PetersenLocalChildren.push (x := s4324) b4324 <|
    PetersenLocalChildren.push (x := s13985) b13985 <|
    PetersenLocalChildren.push (x := s9501) b9501 <|
    PetersenLocalChildren.push (x := s13986) b13986 <|
    PetersenLocalChildren.push (x := s11440) b11440 <|
    PetersenLocalChildren.push (x := s12395) b12395 <|
    PetersenLocalChildren.nil
theorem b14332 : Blocked tgt 8 s14332 := by
  apply PetersenFastNode.node (nxt := #[s14333,s14334,s14336,s858,s14337,s14338,s4407,s14339,s8952,s14340,s14341,s11180,s14342]) (hints := [0,1,2,3,6849,5301,4,8654,5,8654,9942,9942,1682,6,1682,7,2706,11478,2706,11478,4754,13526,4754,13526,8850,8,8850,9,10,6849,11,6849,9686,9686,5943,5685,5943,5685,7487,1682,7487,1682,10446,11478,10446,11478,12494,13526,12494,13526,13623,8850,13623,8850,6849,8654,12,8654,5685,6849,5813,6849,1554,7745,6849,4785,11478,6833,11478,2721,13526,6817,13526,6849,8722,14913,6849,8654,5943,5685,8654,8654,7487,9678,8654,11478,7479,11478,8654,13526,13655,13526,8654,398,462,8590,398,7233,1682,5685,1682,11478,2706,11478,2706,13526,4754,13526,4754,5685,8850,13365,8850,10446,11478,10446,11478,12494,13526,12494,13526,1682,13365,8850,1682,11478,3125,13526,11478,3222,3286,11414,3222,5270,5334,13462,5270]) (by decide +kernel)
  change ∀ b ∈ [s14333,s14334,s14336,s858,s14337,s14338,s4407,s14339,s8952,s14340,s14341,s11180,s14342], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14333) b14333 <|
    PetersenLocalChildren.push (x := s14334) b14334 <|
    PetersenLocalChildren.push (x := s14336) b14336 <|
    PetersenLocalChildren.push (x := s858) b858 <|
    PetersenLocalChildren.push (x := s14337) b14337 <|
    PetersenLocalChildren.push (x := s14338) b14338 <|
    PetersenLocalChildren.push (x := s4407) b4407 <|
    PetersenLocalChildren.push (x := s14339) b14339 <|
    PetersenLocalChildren.push (x := s8952) b8952 <|
    PetersenLocalChildren.push (x := s14340) b14340 <|
    PetersenLocalChildren.push (x := s14341) b14341 <|
    PetersenLocalChildren.push (x := s11180) b11180 <|
    PetersenLocalChildren.push (x := s14342) b14342 <|
    PetersenLocalChildren.nil
theorem b14350 : Blocked tgt 8 s14350 := by
  apply PetersenFastNode.node (nxt := #[s2259,s14351,s9610,s14352,s4418,s14353,s14325,s13189,s14356]) (hints := [5555,5555,910,9682,910,9682,8914,8914,11611,0,11611,1,2702,11474,2702,11474,4750,13522,4750,13522,13619,2,13619,3,1678,4,1678,5,6845,9682,6973,9682,5939,6845,6067,11611,6845,11611,6,7475,11474,7475,11474,13651,13522,13651,13522,13619,7,13619,6845,6845,1550,7741,6845,9682,910,910,9682,8650,8658,9674,8650,9682,4925,11474,9682,9682,2877,13522,9682,1426,1490,9618,1426,394,9682,9682,394,6971,6971,11474,2702,11474,2702,13522,4750,13522,4750,5939,1875,13107,5939,4915,1678,5939,1678,10442,10450,10442,11466,12490,12498,12490,13514,3419,3419,11611,13619,8,1678,7483,1678,11474,3379,13522,11474,3218,3282,11410,3218,2186,11474,11474,2186,5266,5330,13458,5266,4234,13522,13522,4234,1678,8846]) (by decide +kernel)
  change ∀ b ∈ [s2259,s14351,s9610,s14352,s4418,s14353,s14325,s13189,s14356], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2259) b2259 <|
    PetersenLocalChildren.push (x := s14351) b14351 <|
    PetersenLocalChildren.push (x := s9610) b9610 <|
    PetersenLocalChildren.push (x := s14352) b14352 <|
    PetersenLocalChildren.push (x := s4418) b4418 <|
    PetersenLocalChildren.push (x := s14353) b14353 <|
    PetersenLocalChildren.push (x := s14325) b14325 <|
    PetersenLocalChildren.push (x := s13189) b13189 <|
    PetersenLocalChildren.push (x := s14356) b14356 <|
    PetersenLocalChildren.nil
theorem b14367 : Blocked tgt 8 s14367 := by
  apply PetersenFastNode.node (nxt := #[s4429,s14368,s9614,s14369,s14370,s2274,s4701,s14371,s14372,s14373]) (hints := [5556,5556,911,9683,911,9683,9939,9939,1679,0,1679,1,2703,11475,2703,11475,4751,13523,4751,13523,8847,2,8847,3,4,5,6,7,6846,9683,6974,9683,5940,6846,6068,11612,1551,11612,6846,7476,11475,7476,11475,13652,13523,13652,13523,13620,8719,13620,6846,8,6846,6846,9,9683,911,911,9683,8651,8659,9675,8651,9683,4926,11475,9683,9683,2878,13523,9683,1427,1491,9619,1427,395,9683,9683,395,11100,1679,11612,1679,11475,2703,11475,2703,13523,4751,13523,4751,5940,8847,13620,8847,5940,6972,10443,10451,10443,11467,12491,12499,12491,13515,1679,3420,8847,1679,1679,7484,11475,3380,13523,11475,3219,3283,11411,3219,2187,11475,11475,2187,5267,5331,13459,5267,4235,13523,13523,4235,8847,14652]) (by decide +kernel)
  change ∀ b ∈ [s4429,s14368,s9614,s14369,s14370,s2274,s4701,s14371,s14372,s14373], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4429) b4429 <|
    PetersenLocalChildren.push (x := s14368) b14368 <|
    PetersenLocalChildren.push (x := s9614) b9614 <|
    PetersenLocalChildren.push (x := s14369) b14369 <|
    PetersenLocalChildren.push (x := s14370) b14370 <|
    PetersenLocalChildren.push (x := s2274) b2274 <|
    PetersenLocalChildren.push (x := s4701) b4701 <|
    PetersenLocalChildren.push (x := s14371) b14371 <|
    PetersenLocalChildren.push (x := s14372) b14372 <|
    PetersenLocalChildren.push (x := s14373) b14373 <|
    PetersenLocalChildren.nil
theorem b14376 : Blocked tgt 8 s14376 := by
  apply PetersenFastNode.node (nxt := #[s14377,s14378,s9618,s14382,s14383,s13193,s4430,s14384,s9615,s14385,s13191]) (hints := [0,1,2,3,4,6847,5,6847,9684,1428,9684,1428,10069,5941,10069,5941,11613,1680,7485,1680,11476,3220,11476,3220,13524,5268,13524,5268,8848,8848,5557,5557,912,1428,912,1428,1684,1684,1680,6,1680,7,2704,3220,2704,3220,4752,5268,4752,5268,14653,8,14653,9,6847,1428,6975,1428,5941,6847,6069,6847,1552,7743,6847,7477,3220,7477,3220,2719,5268,6815,5268,6847,10,14653,6847,1428,912,912,1428,912,1428,1428,912,1428,4927,3220,1428,1428,2879,5268,1428,1428,9684,9684,1428,4917,1680,5941,1680,3220,2704,3220,2704,5268,4752,5268,4752,5941,10069,10069,5941,1680,3220,2704,3220,1680,5268,4752,5268,1680,11613,14653,1680,3220,3381,5268,3220,3220,11476,11476,3220,5268,13524,13524,5268]) (by decide +kernel)
  change ∀ b ∈ [s14377,s14378,s9618,s14382,s14383,s13193,s4430,s14384,s9615,s14385,s13191], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14377) b14377 <|
    PetersenLocalChildren.push (x := s14378) b14378 <|
    PetersenLocalChildren.push (x := s9618) b9618 <|
    PetersenLocalChildren.push (x := s14382) b14382 <|
    PetersenLocalChildren.push (x := s14383) b14383 <|
    PetersenLocalChildren.push (x := s13193) b13193 <|
    PetersenLocalChildren.push (x := s4430) b4430 <|
    PetersenLocalChildren.push (x := s14384) b14384 <|
    PetersenLocalChildren.push (x := s9615) b9615 <|
    PetersenLocalChildren.push (x := s14385) b14385 <|
    PetersenLocalChildren.push (x := s13191) b13191 <|
    PetersenLocalChildren.nil
theorem b14389 : Blocked tgt 8 s14389 := by
  apply PetersenFastNode.node (nxt := #[s14390,s14391,s14392,s2289,s1775,s14393,s14394,s14395,s14396,s14397,s14400,s14401,s14402,s14403,s14404,s1296,s5523,s12066,s1294,s5524,s1774,s14405,s2258,s13887,s13888,s2997,s14409,s14410,s14411,s14412,s14413,s14414,s14415,s14416,s14417,s14418,s14419,s14420,s14421,s14422,s14423,s14424,s12439,s14425,s14426,s14427,s14428,s14429,s14430,s14431,s14432,s14433,s14434,s14435,s14436]) (hints := [0,1,2,6891,3,6891,5601,4,5,5601,6,6891,7,8,9,956,10,956,11,12,13,956,14,956,9984,15,5985,9984,16,8952,5985,17,5985,8952,18,8952,1724,19,7529,1724,20,21,7529,22,7529,23,24,25,7521,26,7521,2748,27,2748,7521,28,7521,2748,29,2748,13697,30,13697,4796,31,4796,13697,32,13697,4796,33,4796,13665,34,13665,8892,35,8892,13665,36,13665,8892,37,8892,6891,6891,7019,828,38,956,7019,39,7019,6891,6891,956,6379,40,5985,6379,6891,8952,6891,6891,5985,8952,41,8952,6891,6891,7529,42,43,44,7529,45,7529,6891,6891,46,4827,4827,7521,4843,6891,2748,6875,6891,7521,4827,4827,2748,2763,2763,13697,2795,6891,4796,6859,6891,13697,2763,2763,4796,6891,6891,14955,8764,47,8892,14955,48,14955,6891,6891,8892,9728,9728,8952,444,956,5985,8952,956,8952,9728,9728,5985,956,956,7271,8704,9728,7529,9720,9728,7271,956,956,7529,956,956,2748,4971,7019,7521,2748,7019,2748,956,956,7521,956,956,4796,2923,7019,13697,4796,7019,4796,956,956,13697,956,956,8892,1536,9728,13665,8892,9728,8892,956,956,13665,8952,8952,7529,8960,5985,49,7529,5985,7529,8952,8952,50,11520,8952,11520,2236,51,2748,11520,52,11520,8952,8952,2748,13568,8952,13568,4284,5985,4796,13568,5985,13568,8952,8952,4796,5985,5985,13665,8892,8952,8892,8888,8952,13665,8888,5985,8892,2748,53,2748,10496,7529,11520,2748,7529,2748,11512,54,11520,4796,11657,4796,12544,7529,13568,4796,7529,4796,13560,11657,13568,8892,7529,8892,3465,11657,13665,8892,11657,8892,7529,7529,13665,2748,2748,4796,3425,7521,14729,4796,7521,4796,2748,2748,14729,2748,2748,8892,3328,11520,14955,8892,11520,8892,2748,2748,14955,4796,4796,8892,5376,13568,14955,8892,13568,8892,4796,4796,14955]) (by decide +kernel)
  change ∀ b ∈ [s14390,s14391,s14392,s2289,s1775,s14393,s14394,s14395,s14396,s14397,s14400,s14401,s14402,s14403,s14404,s1296,s5523,s12066,s1294,s5524,s1774,s14405,s2258,s13887,s13888,s2997,s14409,s14410,s14411,s14412,s14413,s14414,s14415,s14416,s14417,s14418,s14419,s14420,s14421,s14422,s14423,s14424,s12439,s14425,s14426,s14427,s14428,s14429,s14430,s14431,s14432,s14433,s14434,s14435,s14436], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14390) b14390 <|
    PetersenLocalChildren.push (x := s14391) b14391 <|
    PetersenLocalChildren.push (x := s14392) b14392 <|
    PetersenLocalChildren.push (x := s2289) b2289 <|
    PetersenLocalChildren.push (x := s1775) b1775 <|
    PetersenLocalChildren.push (x := s14393) b14393 <|
    PetersenLocalChildren.push (x := s14394) b14394 <|
    PetersenLocalChildren.push (x := s14395) b14395 <|
    PetersenLocalChildren.push (x := s14396) b14396 <|
    PetersenLocalChildren.push (x := s14397) b14397 <|
    PetersenLocalChildren.push (x := s14400) b14400 <|
    PetersenLocalChildren.push (x := s14401) b14401 <|
    PetersenLocalChildren.push (x := s14402) b14402 <|
    PetersenLocalChildren.push (x := s14403) b14403 <|
    PetersenLocalChildren.push (x := s14404) b14404 <|
    PetersenLocalChildren.push (x := s1296) b1296 <|
    PetersenLocalChildren.push (x := s5523) b5523 <|
    PetersenLocalChildren.push (x := s12066) b12066 <|
    PetersenLocalChildren.push (x := s1294) b1294 <|
    PetersenLocalChildren.push (x := s5524) b5524 <|
    PetersenLocalChildren.push (x := s1774) b1774 <|
    PetersenLocalChildren.push (x := s14405) b14405 <|
    PetersenLocalChildren.push (x := s2258) b2258 <|
    PetersenLocalChildren.push (x := s13887) b13887 <|
    PetersenLocalChildren.push (x := s13888) b13888 <|
    PetersenLocalChildren.push (x := s2997) b2997 <|
    PetersenLocalChildren.push (x := s14409) b14409 <|
    PetersenLocalChildren.push (x := s14410) b14410 <|
    PetersenLocalChildren.push (x := s14411) b14411 <|
    PetersenLocalChildren.push (x := s14412) b14412 <|
    PetersenLocalChildren.push (x := s14413) b14413 <|
    PetersenLocalChildren.push (x := s14414) b14414 <|
    PetersenLocalChildren.push (x := s14415) b14415 <|
    PetersenLocalChildren.push (x := s14416) b14416 <|
    PetersenLocalChildren.push (x := s14417) b14417 <|
    PetersenLocalChildren.push (x := s14418) b14418 <|
    PetersenLocalChildren.push (x := s14419) b14419 <|
    PetersenLocalChildren.push (x := s14420) b14420 <|
    PetersenLocalChildren.push (x := s14421) b14421 <|
    PetersenLocalChildren.push (x := s14422) b14422 <|
    PetersenLocalChildren.push (x := s14423) b14423 <|
    PetersenLocalChildren.push (x := s14424) b14424 <|
    PetersenLocalChildren.push (x := s12439) b12439 <|
    PetersenLocalChildren.push (x := s14425) b14425 <|
    PetersenLocalChildren.push (x := s14426) b14426 <|
    PetersenLocalChildren.push (x := s14427) b14427 <|
    PetersenLocalChildren.push (x := s14428) b14428 <|
    PetersenLocalChildren.push (x := s14429) b14429 <|
    PetersenLocalChildren.push (x := s14430) b14430 <|
    PetersenLocalChildren.push (x := s14431) b14431 <|
    PetersenLocalChildren.push (x := s14432) b14432 <|
    PetersenLocalChildren.push (x := s14433) b14433 <|
    PetersenLocalChildren.push (x := s14434) b14434 <|
    PetersenLocalChildren.push (x := s14435) b14435 <|
    PetersenLocalChildren.push (x := s14436) b14436 <|
    PetersenLocalChildren.nil
theorem b14541 : Blocked tgt 8 s14541 := by
  apply PetersenFastNode.node (nxt := #[s14542,s14543,s14544,s866,s14545,s14546,s2108,s3802,s14547,s6745,s14548,s9010,s10740,s14549,s11186,s14550]) (hints := [0,1,2,3,6852,6336,4,9689,5,9689,10848,6,1685,7,1685,8,2709,9,2709,10,4757,13529,4757,13529,8853,11,8853,12,13,6852,14,6852,9689,917,5946,10848,5946,5688,7490,1685,7490,1685,7482,2709,11481,11481,13529,4757,13529,4757,13626,8853,13626,8853,6852,9689,15,9689,10848,6852,6848,6852,1557,7748,6852,4788,4804,6836,4788,2724,13529,6820,13529,6852,8725,14916,6852,9689,5946,10848,9689,8657,8665,9681,8657,9689,7482,11737,9689,9689,13402,13529,9689,1433,1497,9625,1433,7232,1685,7232,1685,8800,2709,10848,2709,13529,4757,13529,4757,14400,8853,14400,8853,1685,5700,2709,1685,12497,12505,12497,13521,1685,3168,8853,1685,13529,14432,13529,2709,2709,12868,8853,2709,5273,5337,13465,5273]) (by decide +kernel)
  change ∀ b ∈ [s14542,s14543,s14544,s866,s14545,s14546,s2108,s3802,s14547,s6745,s14548,s9010,s10740,s14549,s11186,s14550], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14542) b14542 <|
    PetersenLocalChildren.push (x := s14543) b14543 <|
    PetersenLocalChildren.push (x := s14544) b14544 <|
    PetersenLocalChildren.push (x := s866) b866 <|
    PetersenLocalChildren.push (x := s14545) b14545 <|
    PetersenLocalChildren.push (x := s14546) b14546 <|
    PetersenLocalChildren.push (x := s2108) b2108 <|
    PetersenLocalChildren.push (x := s3802) b3802 <|
    PetersenLocalChildren.push (x := s14547) b14547 <|
    PetersenLocalChildren.push (x := s6745) b6745 <|
    PetersenLocalChildren.push (x := s14548) b14548 <|
    PetersenLocalChildren.push (x := s9010) b9010 <|
    PetersenLocalChildren.push (x := s10740) b10740 <|
    PetersenLocalChildren.push (x := s14549) b14549 <|
    PetersenLocalChildren.push (x := s11186) b11186 <|
    PetersenLocalChildren.push (x := s14550) b14550 <|
    PetersenLocalChildren.nil
theorem b14611 : Blocked tgt 8 s14611 := by
  apply PetersenFastNode.node (nxt := #[s14612,s14613,s9634,s14617,s14618,s13204,s3827,s14619,s9631,s14620,s13202]) (hints := [0,1,2,3,4,6847,5,6847,9684,912,9684,912,10069,6973,5941,5941,11613,1680,11613,1680,11476,2704,11476,3220,13524,4752,13524,4752,8848,8848,6589,6589,912,9684,912,9684,6973,9940,1680,6,1680,7,2704,11476,2704,11476,4752,13524,4752,13524,13621,8,13621,9,6847,784,6975,6847,6973,6847,7101,7485,1552,7485,6847,4783,4799,6831,4783,2719,2751,6815,2719,6847,10,13621,6847,9684,912,912,6971,912,7229,1680,912,912,4927,2704,912,912,2879,4752,912,912,1492,9620,912,6973,1680,7485,1680,4925,2704,6973,2704,2845,4752,6941,4752,6973,10069,13621,6973,1680,7485,2704,1680,1680,3389,4752,1680,1680,11613,11613,1680,2704,12637,4752,2704,2704,11476,11412,2704,4752,5332,13460,4752]) (by decide +kernel)
  change ∀ b ∈ [s14612,s14613,s9634,s14617,s14618,s13204,s3827,s14619,s9631,s14620,s13202], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14612) b14612 <|
    PetersenLocalChildren.push (x := s14613) b14613 <|
    PetersenLocalChildren.push (x := s9634) b9634 <|
    PetersenLocalChildren.push (x := s14617) b14617 <|
    PetersenLocalChildren.push (x := s14618) b14618 <|
    PetersenLocalChildren.push (x := s13204) b13204 <|
    PetersenLocalChildren.push (x := s3827) b3827 <|
    PetersenLocalChildren.push (x := s14619) b14619 <|
    PetersenLocalChildren.push (x := s9631) b9631 <|
    PetersenLocalChildren.push (x := s14620) b14620 <|
    PetersenLocalChildren.push (x := s13202) b13202 <|
    PetersenLocalChildren.nil

theorem b15108 : Blocked tgt 8 s15108 := by
  apply PetersenFastNode.node (nxt := #[s15109,s4247,s15110,s4584,s12518,s15111,s15112,s15113,s15114,s15115,s15116,s15117,s895,s4589,s15118,s4590,s2545,s15119,s15120,s13887,s13888,s15121,s15122,s5283,s15123,s5524,s15124,s15125,s15126,s15127,s14118,s15128,s5282,s8083,s15129,s15130,s15131,s15132,s15133,s15134,s15135,s15136,s15137,s15138]) (hints := [6880,6880,7008,817,10750,945,7008,10750,7008,6880,6880,945,5974,10750,5974,6880,6880,8941,5974,6880,5974,6102,10750,8941,5590,10750,0,5590,6880,1,6880,6880,2,10750,10750,3,7518,10750,7518,4,5,6,7518,7,7518,10750,10750,8,7510,8686,7510,8702,10750,2737,7510,10750,7510,8686,8686,2737,13686,10750,13686,6880,6880,13557,13686,6880,13686,10750,10750,13557,13654,2494,13654,2558,10750,8881,13654,10750,13654,2494,2494,8881,9717,9717,8941,433,945,5974,8941,945,8941,9717,9717,5974,945,945,9,7008,7008,10,7008,7008,11,945,945,12,945,945,7776,8693,9717,7518,9709,9717,7776,945,945,7518,945,945,2737,4960,7008,7510,2737,7008,2737,945,945,7510,945,945,13557,7008,7008,13686,13557,7008,13557,945,945,13686,945,945,8881,1525,9717,13654,8881,9717,8881,945,945,13654,8941,8941,13,5974,5974,14,9973,5974,15,9973,8941,16,8941,8941,7518,8949,5974,7776,7518,5974,7518,8941,8941,7776,11509,8941,11509,2225,7006,2737,11509,7006,11509,8941,8941,2737,13557,8941,13557,4273,5974,17,13557,5974,13557,8941,8941,18,5974,5974,13654,8881,8941,8881,8877,8941,13654,8877,5974,8881,19,20,21,7518,22,7518,1713,23,24,1713,25,7518,2737,26,2737,7510,27,7510,2737,28,2737,7510,29,7510,13557,30,13557,13686,31,13686,4785,32,13557,4785,33,13686,8881,34,8881,13654,35,13654,8881,36,8881,13654,37,13654,2737,5712,2737,10485,7518,11509,2737,7518,2737,11501,5712,11509,12525,38,12525,12533,7518,13557,12525,7518,12525,13549,39,13557,8881,7518,8881,12630,40,13654,8881,41,8881,7518,7518,13654,2737,2737,13557,3414,7510,42,13557,7510,13557,2737,2737,43,2737,2737,8881,3317,11509,14686,8881,11509,8881,2737,2737,14686,8881,5301,8881,5365,13557,13654,8881,13557,8881,5301,5301,13654]) (by decide +kernel)
  change ∀ b ∈ [s15109,s4247,s15110,s4584,s12518,s15111,s15112,s15113,s15114,s15115,s15116,s15117,s895,s4589,s15118,s4590,s2545,s15119,s15120,s13887,s13888,s15121,s15122,s5283,s15123,s5524,s15124,s15125,s15126,s15127,s14118,s15128,s5282,s8083,s15129,s15130,s15131,s15132,s15133,s15134,s15135,s15136,s15137,s15138], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s15109) b15109 <|
    PetersenLocalChildren.push (x := s4247) b4247 <|
    PetersenLocalChildren.push (x := s15110) b15110 <|
    PetersenLocalChildren.push (x := s4584) b4584 <|
    PetersenLocalChildren.push (x := s12518) b12518 <|
    PetersenLocalChildren.push (x := s15111) b15111 <|
    PetersenLocalChildren.push (x := s15112) b15112 <|
    PetersenLocalChildren.push (x := s15113) b15113 <|
    PetersenLocalChildren.push (x := s15114) b15114 <|
    PetersenLocalChildren.push (x := s15115) b15115 <|
    PetersenLocalChildren.push (x := s15116) b15116 <|
    PetersenLocalChildren.push (x := s15117) b15117 <|
    PetersenLocalChildren.push (x := s895) b895 <|
    PetersenLocalChildren.push (x := s4589) b4589 <|
    PetersenLocalChildren.push (x := s15118) b15118 <|
    PetersenLocalChildren.push (x := s4590) b4590 <|
    PetersenLocalChildren.push (x := s2545) b2545 <|
    PetersenLocalChildren.push (x := s15119) b15119 <|
    PetersenLocalChildren.push (x := s15120) b15120 <|
    PetersenLocalChildren.push (x := s13887) b13887 <|
    PetersenLocalChildren.push (x := s13888) b13888 <|
    PetersenLocalChildren.push (x := s15121) b15121 <|
    PetersenLocalChildren.push (x := s15122) b15122 <|
    PetersenLocalChildren.push (x := s5283) b5283 <|
    PetersenLocalChildren.push (x := s15123) b15123 <|
    PetersenLocalChildren.push (x := s5524) b5524 <|
    PetersenLocalChildren.push (x := s15124) b15124 <|
    PetersenLocalChildren.push (x := s15125) b15125 <|
    PetersenLocalChildren.push (x := s15126) b15126 <|
    PetersenLocalChildren.push (x := s15127) b15127 <|
    PetersenLocalChildren.push (x := s14118) b14118 <|
    PetersenLocalChildren.push (x := s15128) b15128 <|
    PetersenLocalChildren.push (x := s5282) b5282 <|
    PetersenLocalChildren.push (x := s8083) b8083 <|
    PetersenLocalChildren.push (x := s15129) b15129 <|
    PetersenLocalChildren.push (x := s15130) b15130 <|
    PetersenLocalChildren.push (x := s15131) b15131 <|
    PetersenLocalChildren.push (x := s15132) b15132 <|
    PetersenLocalChildren.push (x := s15133) b15133 <|
    PetersenLocalChildren.push (x := s15134) b15134 <|
    PetersenLocalChildren.push (x := s15135) b15135 <|
    PetersenLocalChildren.push (x := s15136) b15136 <|
    PetersenLocalChildren.push (x := s15137) b15137 <|
    PetersenLocalChildren.push (x := s15138) b15138 <|
    PetersenLocalChildren.nil
theorem b15407 : Blocked tgt 8 s15407 := by
  apply PetersenFastNode.node (nxt := #[s15408,s15409,s15411,s908,s4154,s15412,s6829,s15413,s7859,s15414,s9294,s15415,s15416,s11221]) (hints := [0,1,2,3,6850,5302,915,9687,915,9687,5686,9943,7746,4,7746,5,7222,6,7222,7,14430,8,14430,9,14914,10,14914,11,12,6850,13,6850,9687,6978,5944,5686,5944,5686,1683,7746,1683,7746,7480,7222,11479,11479,13656,14430,13527,13527,8851,14914,8851,14914,6850,9687,786,9687,5686,6850,5814,6850,1555,7746,6850,4786,4802,6834,4786,2722,2754,6818,2722,6850,8723,14914,6850,9687,915,5686,9687,8655,8663,9679,8655,9687,7480,11735,9687,9687,13656,13783,9687,1431,1495,9623,1431,7230,7234,7230,7742,5686,10846,7222,5686,10846,5686,5686,10846,5686,14402,13366,5686,5682,5698,7730,5682,3618,3650,7714,3618,7746,3166,14914,7746,3126,3126,7222,14430,12850,12866,12850,14898,10786,10818,10786,14882]) (by decide +kernel)
  change ∀ b ∈ [s15408,s15409,s15411,s908,s4154,s15412,s6829,s15413,s7859,s15414,s9294,s15415,s15416,s11221], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s15408) b15408 <|
    PetersenLocalChildren.push (x := s15409) b15409 <|
    PetersenLocalChildren.push (x := s15411) b15411 <|
    PetersenLocalChildren.push (x := s908) b908 <|
    PetersenLocalChildren.push (x := s4154) b4154 <|
    PetersenLocalChildren.push (x := s15412) b15412 <|
    PetersenLocalChildren.push (x := s6829) b6829 <|
    PetersenLocalChildren.push (x := s15413) b15413 <|
    PetersenLocalChildren.push (x := s7859) b7859 <|
    PetersenLocalChildren.push (x := s15414) b15414 <|
    PetersenLocalChildren.push (x := s9294) b9294 <|
    PetersenLocalChildren.push (x := s15415) b15415 <|
    PetersenLocalChildren.push (x := s15416) b15416 <|
    PetersenLocalChildren.push (x := s11221) b11221 <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i0 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s5478,s5479,s5480,s5481]) (hints := [5551,0,5551,1,6583,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s5478,s5479,s5480,s5481], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5478) (b5478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5479) (b5479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5480) (b5480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5481) (b5481) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i1 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5482,s5483,s5484,s5515,s1326,s5516,s5517,s5518]) (hints := [909,0,909,1,8649,2,8649,3,909,4,909,5,8649,6,8649,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5482,s5483,s5484,s5515,s1326,s5516,s5517,s5518], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5482) (b5482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5483) (b5483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5484) (b5484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5515) (b5515) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1326) (b1326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5516) (b5516) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5517) (b5517) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5518) (b5518) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i2 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s5478,s5519,s5553,s5554]) (hints := [9934,0,9934,1,8902,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s5478,s5519,s5553,s5554], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5478) (b5478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5519) (b5519) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5553) (b5553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5554) (b5554) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i3 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s5478,s5555,s5575,s4477,s4479]) (hints := [1675,0,1675,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s5478,s5555,s5575,s4477,s4479], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5478) (b5478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5555) (b5555) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5575) (b5575) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4477) (b4477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4479) (b4479) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i4 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5576,s5577,s5578,s5579,s5580,s5581,s5582,s5583]) (hints := [2701,0,2701,1,10441,2,10441,3,2701,4,2701,5,10441,6,10441,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5576,s5577,s5578,s5579,s5580,s5581,s5582,s5583], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5576) (b5576) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5577) (b5577) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5578) (b5578) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5579) (b5579) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5580) (b5580) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5581) (b5581) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5582) (b5582) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5583) (b5583) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i5 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5584,s5585,s5586,s5612,s5613,s5614,s5615,s5616]) (hints := [4749,0,4749,1,12489,2,12489,3,4749,4,4749,5,12489,6,12489,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5584,s5585,s5586,s5612,s5613,s5614,s5615,s5616], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5584) (b5584) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5585) (b5585) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5586) (b5586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5612) (b5612) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5613) (b5613) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5614) (b5614) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5615) (b5615) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5616) (b5616) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i6 : PetersenLocalChildren.PairOK tgt 8 s5477 (word175,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5617,s5618,s5619,s5704,s5738,s5739,s5740,s5741,s5742,s5743,s5744,s5745]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s5617,s5618,s5619,s5704,s5738,s5739,s5740,s5741,s5742,s5743,s5744,s5745], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5617) (b5617) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5618) (b5618) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5619) (b5619) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5704) (b5704) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5738) (b5738) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5739) (b5739) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5740) (b5740) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5741) (b5741) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5742) (b5742) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5743) (b5743) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5744) (b5744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5745) (b5745) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i7 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5746,s5747,s5748,s5749]) (hints := [6840,6840,6968,0,8645,5550,8645,1,6968,5550,6968,2,8645,6840,8645,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5746,s5747,s5748,s5749], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5746) (b5746) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5747) (b5747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5748) (b5748) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5749) (b5749) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i8 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5750,s2956,s5444,s5751]) (hints := [5550,5550,5934,0,9805,6840,9933,1,5934,6840,5934,2,5550,5550,9933,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5750,s2956,s5444,s5751], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5750) (b5750) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2956) (b2956) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5444) (b5444) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5751) (b5751) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i9 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5752,s5753,s5754,s5755]) (hints := [7478,6840,7478,0,5550,5550,1673,1,7478,5550,7478,2,7606,6840,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5752,s5753,s5754,s5755], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5752) (b5752) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5753) (b5753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5754) (b5754) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5755) (b5755) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i10 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5756,s5757,s5758,s5759]) (hints := [5550,5550,7470,0,10437,6840,10437,1,7470,6840,7470,2,10437,5550,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5756,s5757,s5758,s5759], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5756) (b5756) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5757) (b5757) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5758) (b5758) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5759) (b5759) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i11 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5760,s5761,s5762,s5763]) (hints := [9678,9678,13646,0,12485,5550,12485,1,13646,5550,13646,2,12485,9678,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5760,s5761,s5762,s5763], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5760) (b5760) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5761) (b5761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5762) (b5762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5763) (b5763) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i12 : PetersenLocalChildren.PairOK tgt 8 s5477 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5764,s5765,s5766,s5767]) (hints := [5550,5550,13614,0,1486,9678,8841,1,13614,9678,13614,2,5550,5550,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5764,s5765,s5766,s5767], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5764) (b5764) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5765) (b5765) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5766) (b5766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5767) (b5767) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i13 : PetersenLocalChildren.PairOK tgt 8 s5477 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5768,s5769,s5770,s5771]) (hints := [8645,8645,9933,0,905,905,5934,1,9933,905,9933,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5768,s5769,s5770,s5771], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5768) (b5768) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5769) (b5769) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5770) (b5770) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5771) (b5771) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i14 : PetersenLocalChildren.PairOK tgt 8 s5477 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5772,s5773,s5774,s5775]) (hints := [8645,8645,1673,0,9677,9677,7478,1,1673,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5772,s5773,s5774,s5775], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5772) (b5772) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5773) (b5773) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5774) (b5774) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5775) (b5775) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i15 : PetersenLocalChildren.PairOK tgt 8 s5477 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5776,s5777,s5778,s5779]) (hints := [8645,8645,10437,0,4920,6968,7470,1,10437,6968,10437,2,8645,8645,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5776,s5777,s5778,s5779], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5776) (b5776) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5777) (b5777) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5778) (b5778) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5779) (b5779) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i16 : PetersenLocalChildren.PairOK tgt 8 s5477 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5780,s5781,s5782,s5783]) (hints := [8645,8645,12485,0,2872,6968,13646,1,12485,6968,12485,2,8645,8645,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5780,s5781,s5782,s5783], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5780) (b5780) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5781) (b5781) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5782) (b5782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5783) (b5783) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i17 : PetersenLocalChildren.PairOK tgt 8 s5477 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5784,s5785,s5789,s5790]) (hints := [389,389,8841,0,453,8645,13614,1,8581,8645,8841,2,389,389,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5784,s5785,s5789,s5790], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5784) (b5784) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5785) (b5785) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5789) (b5789) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5790) (b5790) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i18 : PetersenLocalChildren.PairOK tgt 8 s5477 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5791,s5792,s5793,s5794]) (hints := [8909,6966,7478,0,8909,9933,1673,1,9933,9933,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5791,s5792,s5793,s5794], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5791) (b5791) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5792) (b5792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5793) (b5793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5794) (b5794) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i19 : PetersenLocalChildren.PairOK tgt 8 s5477 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5795,s5796,s5797,s5798]) (hints := [10437,9933,10437,0,2697,6966,2697,1,10437,6966,10437,2,9933,9933,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5795,s5796,s5797,s5798], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5795) (b5795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5796) (b5796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5797) (b5797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5798) (b5798) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i20 : PetersenLocalChildren.PairOK tgt 8 s5477 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5799,s5800,s5801,s5802]) (hints := [12485,9933,12485,0,4745,5934,4745,1,12485,5934,12485,2,9933,9933,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5799,s5800,s5801,s5802], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5799) (b5799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5800) (b5800) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5801) (b5801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5802) (b5802) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i21 : PetersenLocalChildren.PairOK tgt 8 s5477 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5803,s5804,s5805,s5806]) (hints := [1677,1677,13614,0,1741,9933,8841,1,9869,9933,13614,2,1677,1677,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5803,s5804,s5805,s5806], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5803) (b5803) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5804) (b5804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5805) (b5805) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5806) (b5806) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i22 : PetersenLocalChildren.PairOK tgt 8 s5477 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5807,s5808,s5809,s5810]) (hints := [10437,1673,10437,0,11469,7478,11469,1,10437,7478,10437,2,1673,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5807,s5808,s5809,s5810], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5807) (b5807) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5808) (b5808) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5809) (b5809) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5810) (b5810) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i23 : PetersenLocalChildren.PairOK tgt 8 s5477 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5811,s5812,s5813,s5814]) (hints := [12485,1673,12485,0,13517,7478,13517,1,12485,7478,12485,2,1673,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5811,s5812,s5813,s5814], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5811) (b5811) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5812) (b5812) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5813) (b5813) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5814) (b5814) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i24 : PetersenLocalChildren.PairOK tgt 8 s5477 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5815,s5816,s5817,s5818]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5815,s5816,s5817,s5818], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5815) (b5815) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5816) (b5816) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5817) (b5817) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5818) (b5818) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i25 : PetersenLocalChildren.PairOK tgt 8 s5477 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5819,s5820,s5821,s5822]) (hints := [10437,10437,12485,0,3374,7470,14678,1,12485,7470,12485,2,10437,10437,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5819,s5820,s5821,s5822], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5819) (b5819) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5820) (b5820) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5821) (b5821) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5822) (b5822) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i26 : PetersenLocalChildren.PairOK tgt 8 s5477 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5823,s5824,s5825,s5826]) (hints := [2181,2181,8841,0,2245,10437,14646,1,10373,10437,8841,2,2181,2181,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5823,s5824,s5825,s5826], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5823) (b5823) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5824) (b5824) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5825) (b5825) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5826) (b5826) <|
    PetersenLocalChildren.nil
private theorem thetaPair5477i27 : PetersenLocalChildren.PairOK tgt 8 s5477 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5827,s5828,s5829,s5830]) (hints := [4229,4229,8841,0,4293,12485,13614,1,12421,12485,8841,2,4229,4229,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5827,s5828,s5829,s5830], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5827) (b5827) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5828) (b5828) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5829) (b5829) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5830) (b5830) <|
    PetersenLocalChildren.nil
theorem b5477 : Blocked tgt 9 s5477 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word175,word3),(word175,word1),(word175,word0),(word175,word6),(word175,word5),(word175,word2),(word175,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s5477 p
  exact
    PetersenLocalChildren.push thetaPair5477i0 <|
    PetersenLocalChildren.push thetaPair5477i1 <|
    PetersenLocalChildren.push thetaPair5477i2 <|
    PetersenLocalChildren.push thetaPair5477i3 <|
    PetersenLocalChildren.push thetaPair5477i4 <|
    PetersenLocalChildren.push thetaPair5477i5 <|
    PetersenLocalChildren.push thetaPair5477i6 <|
    PetersenLocalChildren.push thetaPair5477i7 <|
    PetersenLocalChildren.push thetaPair5477i8 <|
    PetersenLocalChildren.push thetaPair5477i9 <|
    PetersenLocalChildren.push thetaPair5477i10 <|
    PetersenLocalChildren.push thetaPair5477i11 <|
    PetersenLocalChildren.push thetaPair5477i12 <|
    PetersenLocalChildren.push thetaPair5477i13 <|
    PetersenLocalChildren.push thetaPair5477i14 <|
    PetersenLocalChildren.push thetaPair5477i15 <|
    PetersenLocalChildren.push thetaPair5477i16 <|
    PetersenLocalChildren.push thetaPair5477i17 <|
    PetersenLocalChildren.push thetaPair5477i18 <|
    PetersenLocalChildren.push thetaPair5477i19 <|
    PetersenLocalChildren.push thetaPair5477i20 <|
    PetersenLocalChildren.push thetaPair5477i21 <|
    PetersenLocalChildren.push thetaPair5477i22 <|
    PetersenLocalChildren.push thetaPair5477i23 <|
    PetersenLocalChildren.push thetaPair5477i24 <|
    PetersenLocalChildren.push thetaPair5477i25 <|
    PetersenLocalChildren.push thetaPair5477i26 <|
    PetersenLocalChildren.push thetaPair5477i27 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
