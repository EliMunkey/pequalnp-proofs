import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows16
import M191StartPreferredRows17
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3779 : Blocked tgt 7 s3779 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3779 7 _ le
  decide +kernel
theorem b3780 : Blocked tgt 7 s3780 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3780 7 _ le
  decide +kernel
theorem b3781 : Blocked tgt 7 s3781 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3781 7 _ le
  decide +kernel
theorem b3782 : Blocked tgt 7 s3782 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3782 7 _ le
  decide +kernel
theorem b3783 : Blocked tgt 7 s3783 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3783 7 _ le
  decide +kernel
theorem b3784 : Blocked tgt 7 s3784 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3784 7 _ le
  decide +kernel
theorem b3785 : Blocked tgt 7 s3785 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3785 7 _ le
  decide +kernel
theorem b3786 : Blocked tgt 7 s3786 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3786 7 _ le
  decide +kernel
theorem b3787 : Blocked tgt 7 s3787 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3787 7 _ le
  decide +kernel
theorem b3788 : Blocked tgt 7 s3788 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3788 7 _ le
  decide +kernel
theorem b3789 : Blocked tgt 7 s3789 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3789 7 _ le
  decide +kernel
theorem b3790 : Blocked tgt 7 s3790 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3790 7 _ le
  decide +kernel
theorem b3791 : Blocked tgt 7 s3791 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3791 7 _ le
  decide +kernel
theorem b3794 : Blocked tgt 7 s3794 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s3794 7 _ le
  decide +kernel
theorem b3795 : Blocked tgt 7 s3795 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s3795 7 _ le
  decide +kernel
theorem b3796 : Blocked tgt 7 s3796 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3796 7 _ le
  decide +kernel
theorem b3797 : Blocked tgt 7 s3797 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3797 7 _ le
  decide +kernel
theorem b3798 : Blocked tgt 7 s3798 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3798 7 _ le
  decide +kernel
theorem b3799 : Blocked tgt 7 s3799 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3799 7 _ le
  decide +kernel
theorem b3800 : Blocked tgt 7 s3800 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3800 7 _ le
  decide +kernel
theorem b3801 : Blocked tgt 7 s3801 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3801 7 _ le
  decide +kernel
theorem b3802 : Blocked tgt 7 s3802 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3802 7 _ le
  decide +kernel
theorem b3803 : Blocked tgt 7 s3803 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3803 7 _ le
  decide +kernel
theorem b3804 : Blocked tgt 7 s3804 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3804 7 _ le
  decide +kernel
theorem b3805 : Blocked tgt 7 s3805 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3805 7 _ le
  decide +kernel
theorem b3806 : Blocked tgt 7 s3806 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3806 7 _ le
  decide +kernel
theorem b3807 : Blocked tgt 7 s3807 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3807 7 _ le
  decide +kernel
theorem b3808 : Blocked tgt 7 s3808 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3808 7 _ le
  decide +kernel
theorem b3809 : Blocked tgt 7 s3809 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3809 7 _ le
  decide +kernel

theorem b3810 : Blocked tgt 7 s3810 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s3810 7 _ le
  decide +kernel
theorem b3811 : Blocked tgt 7 s3811 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s3811 7 _ le
  decide +kernel
theorem b3812 : Blocked tgt 7 s3812 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3812 7 _ le
  decide +kernel
theorem b3813 : Blocked tgt 7 s3813 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s3813 7 _ le
  decide +kernel
theorem b3814 : Blocked tgt 7 s3814 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s3814 7 _ le
  decide +kernel
theorem b3815 : Blocked tgt 7 s3815 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3815 7 _ le
  decide +kernel
theorem b3816 : Blocked tgt 7 s3816 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3816 7 _ le
  decide +kernel
theorem b3817 : Blocked tgt 7 s3817 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3817 7 _ le
  decide +kernel
theorem b3818 : Blocked tgt 7 s3818 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3818 7 _ le
  decide +kernel
theorem b3819 : Blocked tgt 7 s3819 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3819 7 _ le
  decide +kernel
theorem b3820 : Blocked tgt 7 s3820 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3820 7 _ le
  decide +kernel
theorem b3821 : Blocked tgt 7 s3821 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3821 7 _ le
  decide +kernel
theorem b3822 : Blocked tgt 7 s3822 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3822 7 _ le
  decide +kernel
theorem b3823 : Blocked tgt 7 s3823 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3823 7 _ le
  decide +kernel
theorem b3824 : Blocked tgt 7 s3824 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3824 7 _ le
  decide +kernel
theorem b3825 : Blocked tgt 7 s3825 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3825 7 _ le
  decide +kernel

theorem b3826 : Blocked tgt 7 s3826 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3826 7 _ le
  decide +kernel
theorem b3827 : Blocked tgt 7 s3827 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3827 7 _ le
  decide +kernel
theorem b3828 : Blocked tgt 7 s3828 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3828 7 _ le
  decide +kernel
theorem b3830 : Blocked tgt 7 s3830 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3830 7 _ le
  decide +kernel
theorem b3831 : Blocked tgt 7 s3831 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3831 7 _ le
  decide +kernel
theorem b3832 : Blocked tgt 7 s3832 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3832 7 _ le
  decide +kernel
theorem b3833 : Blocked tgt 7 s3833 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3833 7 _ le
  decide +kernel
theorem b3834 : Blocked tgt 7 s3834 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4772,773,4900,4772,6836,4522,4522,6836,4522,4772,5930,4522,7474,4522,6578,6578,4522,6836,6570,4522,8650,426,12746,8650,4522,458,12714,4522,901,8641,5674,901,901,5930,901,7474,1669,901,901,7466,2949,901,901,804,4741,901,901,13610,8837,901,10832,5930,9921,9921,7732,1669,7732,1669,2693,2693,10433,7466,12481,4741,12481,4741,14900,8837,14900,8837,6962,1669,7474,1669,10433,4914,10433,11969,12481,4741,12481,4741,5930,8837,13610,8837,1669,10433,7458,1669,1669,12481,4741,1669,1669,3410,8837,1669,4741,3370,4741,10433,8837,2241,8837,2177,4741,4289,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3835 : Blocked tgt 7 s3835 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3835 7 _ le
  decide +kernel
theorem b3836 : Blocked tgt 7 s3836 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3836 7 _ le
  decide +kernel
theorem b3837 : Blocked tgt 7 s3837 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3837 7 _ le
  decide +kernel
theorem b3838 : Blocked tgt 7 s3838 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3838 7 _ le
  decide +kernel
theorem b3839 : Blocked tgt 7 s3839 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3839 7 _ le
  decide +kernel
theorem b3840 : Blocked tgt 7 s3840 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3840 7 _ le
  decide +kernel
theorem b3841 : Blocked tgt 7 s3841 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3841 7 _ le
  decide +kernel
theorem b3842 : Blocked tgt 7 s3842 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3842 7 _ le
  decide +kernel

theorem b3843 : Blocked tgt 7 s3843 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3843 7 _ le
  decide +kernel
theorem b3844 : Blocked tgt 7 s3844 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3844 7 _ le
  decide +kernel
theorem b3845 : Blocked tgt 7 s3845 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3845 7 _ le
  decide +kernel
theorem b3846 : Blocked tgt 7 s3846 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3846 7 _ le
  decide +kernel
theorem b3847 : Blocked tgt 7 s3847 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,4522,9793,10058,4522,7474,4522,6578,6578,4522,6836,6570,4522,8650,426,12746,8650,4522,8650,8650,4522,4522,8650,8650,4522,8641,901,9921,8641,901,8641,1669,901,901,6964,10433,901,901,2868,4741,901,901,8641,8837,901,385,901,901,385,8897,8897,9921,1669,9921,6962,10433,9921,9921,4741,12481,9921,1729,1729,9921,8837,6962,9921,9921,1665,1669,10433,7458,1669,1669,12481,4741,1669,1669,11602,8837,1669,7474,1669,1669,7474,4741,3370,4741,10433,8837,10433,8837,10885,2693,2693,10433,2177,4741,12481,8837,4741,4225,4741,4741,4225,8837,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3848 : Blocked tgt 7 s3848 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3848 7 _ le
  decide +kernel
theorem b3849 : Blocked tgt 7 s3849 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3849 7 _ le
  decide +kernel
theorem b3850 : Blocked tgt 7 s3850 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3850 7 _ le
  decide +kernel
theorem b3851 : Blocked tgt 7 s3851 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3851 7 _ le
  decide +kernel
theorem b3852 : Blocked tgt 7 s3852 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3852 7 _ le
  decide +kernel
theorem b3853 : Blocked tgt 7 s3853 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3853 7 _ le
  decide +kernel
theorem b3857 : Blocked tgt 7 s3857 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(4,false))] s3857 7 _ le
  decide +kernel
theorem b3858 : Blocked tgt 7 s3858 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(4,false))] s3858 7 _ le
  decide +kernel
theorem b3859 : Blocked tgt 7 s3859 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3859 7 _ le
  decide +kernel
theorem b3860 : Blocked tgt 7 s3860 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3860 7 _ le
  decide +kernel
theorem b3861 : Blocked tgt 7 s3861 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3861 7 _ le
  decide +kernel

theorem b3862 : Blocked tgt 7 s3862 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3862 7 _ le
  decide +kernel
theorem b3863 : Blocked tgt 7 s3863 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3863 7 _ le
  decide +kernel
theorem b3864 : Blocked tgt 7 s3864 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3864 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
