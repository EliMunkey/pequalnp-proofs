import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv753_4260 : PetersenPackedPin.project r753 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv753_4814 : PetersenPackedPin.project r753 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv753_5473 : PetersenPackedPin.project r753 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv753_6170 : PetersenPackedPin.project r753 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv753_6790 : PetersenPackedPin.project r753 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv753_7474 : PetersenPackedPin.project r753 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv753_8012 : PetersenPackedPin.project r753 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv753_456 : PetersenPackedPin.project r753 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv753_5473 pv753_8012 rfl rfl
theorem pv753_1177 : PetersenPackedPin.project r753 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv753_5473 pv753_7474 rfl rfl
theorem pv753_2708 : PetersenPackedPin.project r753 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 1 pv753_4260 pv753_5473 rfl rfl
theorem pv753_3209 : PetersenPackedPin.project r753 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv753_4814 pv753_5473 rfl rfl
theorem pv753_3359 : PetersenPackedPin.project r753 (0x33330000333300003333000033330000 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 2 pv753_4814 pv753_6790 rfl rfl
theorem pv753_3632 : PetersenPackedPin.project r753 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv753_4260 pv753_5473 rfl rfl
theorem pv753_5850 : PetersenPackedPin.project r753 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv753_4260 pv753_5473 rfl rfl
theorem pv753_7095 : PetersenPackedPin.project r753 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv753_4260 pv753_6790 rfl rfl
theorem pv753_7152 : PetersenPackedPin.project r753 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xfffffffff0f0f0f0 := PetersenWireProjection.derive 3 pv753_4814 pv753_6790 rfl rfl
theorem pv753_7235 : PetersenPackedPin.project r753 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv753_5473 pv753_6790 rfl rfl
theorem pv753_2938 : PetersenPackedPin.project r753 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 2 pv753_5473 pv753_7095 rfl rfl
theorem pv753_3392 : PetersenPackedPin.project r753 (0x33332222333322223333222233332222 : BitVec 128) = 0xfcfcfcfc := PetersenWireProjection.derive 2 pv753_4814 pv753_7095 rfl rfl
theorem pv753_5857 : PetersenPackedPin.project r753 (0xfbfbfafafbfbfafafbfbfafafbfbfafa : BitVec 128) = 0xccccccccfcfcfcfc := PetersenWireProjection.derive 3 pv753_3359 pv753_5850 rfl rfl
theorem pv753_6897 : PetersenPackedPin.project r753 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv753_2708 pv753_6790 rfl rfl
theorem pv753_7285 : PetersenPackedPin.project r753 (0xfffffafafffffafafffffafafffffafa : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv753_4260 pv753_7235 rfl rfl
theorem pv753_3408 : PetersenPackedPin.project r753 (0x33333232333332323333323233333232 : BitVec 128) = 0xfcfcfcfc := PetersenWireProjection.derive 2 pv753_4814 pv753_5857 rfl rfl
end PetersenSmallStarts.M191.Residual
