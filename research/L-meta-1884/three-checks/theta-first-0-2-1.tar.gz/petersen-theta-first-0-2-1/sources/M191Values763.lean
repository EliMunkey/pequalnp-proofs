import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv763_4260 : PetersenPackedPin.project r763 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv763_4814 : PetersenPackedPin.project r763 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv763_5473 : PetersenPackedPin.project r763 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv763_6170 : PetersenPackedPin.project r763 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv763_6790 : PetersenPackedPin.project r763 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv763_7474 : PetersenPackedPin.project r763 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv763_8012 : PetersenPackedPin.project r763 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv763_1734 : PetersenPackedPin.project r763 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv763_4260 pv763_6790 rfl rfl
theorem pv763_3209 : PetersenPackedPin.project r763 (0x30303030303030303030303030303030 : BitVec 128) = 0x30303030 := PetersenWireProjection.derive 2 pv763_4814 pv763_5473 rfl rfl
theorem pv763_7095 : PetersenPackedPin.project r763 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv763_4260 pv763_6790 rfl rfl
theorem pv763_7152 : PetersenPackedPin.project r763 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv763_4814 pv763_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
