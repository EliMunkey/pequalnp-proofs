import higher.WireProjection
import M191StartPreferredCuts6
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv787_4260 : PetersenPackedPin.project r787 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc := by decide +kernel
theorem pv787_4814 : PetersenPackedPin.project r787 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv787_5473 : PetersenPackedPin.project r787 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv787_6170 : PetersenPackedPin.project r787 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv787_6790 : PetersenPackedPin.project r787 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv787_7474 : PetersenPackedPin.project r787 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv787_8012 : PetersenPackedPin.project r787 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv787_2708 : PetersenPackedPin.project r787 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv787_4260 pv787_5473 rfl rfl
theorem pv787_5745 : PetersenPackedPin.project r787 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x3300 := PetersenWireProjection.derive 2 pv787_2708 pv787_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
