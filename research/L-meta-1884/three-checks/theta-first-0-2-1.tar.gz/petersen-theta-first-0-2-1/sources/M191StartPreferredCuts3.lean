import M191StartPreferredCommon
import M15StartLabeled
import M111StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r743 (x : Fin 16) : Fin 128 := (#[0,64,4,68,8,72,12,76,16,80,20,84,24,88,28,92] : Array (Fin 128))[x.val]?.getD 0
theorem small743 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r743 tgt) 3 := by
  have a : PetersenPackedPin.project r743 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot743 : forcedConst r743 tgt = false := by decide +kernel
def r744 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small744 : NoAtMost (0xfcfcfcfcfcfcfcfc :: i6) (PetersenPackedPin.project r744 tgt) 6 := by
  have a : PetersenPackedPin.project r744 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xfcfcfcfcfcfcfcfc (by decide +kernel)
theorem hot744 : forcedConst r744 tgt = false := by decide +kernel
def r745 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small745 : NoAtMost (0xeeeeeeeeeeeeeeee :: i6) (PetersenPackedPin.project r745 tgt) 6 := by
  have a : PetersenPackedPin.project r745 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xeeeeeeeeeeeeeeee (by decide +kernel)
theorem hot745 : forcedConst r745 tgt = false := by decide +kernel
def r746 (x : Fin 16) : Fin 128 := (#[0,2,4,6,64,66,68,70,32,34,36,38,96,98,100,102] : Array (Fin 128))[x.val]?.getD 0
theorem small746 : NoAtMost (0xa0a :: i4) (PetersenPackedPin.project r746 tgt) 3 := by
  have a : PetersenPackedPin.project r746 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xa0a (by decide +kernel)
theorem hot746 : forcedConst r746 tgt = false := by decide +kernel
def r747 (x : Fin 16) : Fin 128 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30] : Array (Fin 128))[x.val]?.getD 0
theorem small747 : NoAtMost (0xa0a :: i4) (PetersenPackedPin.project r747 tgt) 3 := by
  have a : PetersenPackedPin.project r747 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xa0a (by decide +kernel)
theorem hot747 : forcedConst r747 tgt = false := by decide +kernel
def r748 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small748 : NoAtMost (0x4444444444444444 :: i6) (PetersenPackedPin.project r748 tgt) 6 := by
  have a : PetersenPackedPin.project r748 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x4444444444444444 (by decide +kernel)
theorem hot748 : forcedConst r748 tgt = false := by decide +kernel
def r749 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small749 : NoAtMost (0xc0c0c0c0c0c0c0c :: i6) (PetersenPackedPin.project r749 tgt) 6 := by
  have a : PetersenPackedPin.project r749 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xc0c0c0c0c0c0c0c (by decide +kernel)
theorem hot749 : forcedConst r749 tgt = false := by decide +kernel
def r750 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small750 : NoAtMost (0xcccccccc :: i6) (PetersenPackedPin.project r750 tgt) 6 := by
  have a : PetersenPackedPin.project r750 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xcccccccc (by decide +kernel)
theorem hot750 : forcedConst r750 tgt = false := by decide +kernel
def r751 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small751 : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r751 tgt) 6 := by
  have a : PetersenPackedPin.project r751 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xf000f000f000f0 (by decide +kernel)
theorem hot751 : forcedConst r751 tgt = false := by decide +kernel
def r752 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small752 : NoAtMost (0xaaaa0000aaaa :: i6) (PetersenPackedPin.project r752 tgt) 6 := by
  have a : PetersenPackedPin.project r752 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xaaaa0000aaaa (by decide +kernel)
theorem hot752 : forcedConst r752 tgt = false := by decide +kernel
def r753 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small753 : NoAtMost (0xfcfcfcfcfcfcfcfc :: i6) (PetersenPackedPin.project r753 tgt) 6 := by
  have a : PetersenPackedPin.project r753 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xfcfcfcfcfcfcfcfc (by decide +kernel)
theorem hot753 : forcedConst r753 tgt = false := by decide +kernel
def r754 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small754 : NoAtMost (0xeeeeeeeeeeeeeeee :: i6) (PetersenPackedPin.project r754 tgt) 6 := by
  have a : PetersenPackedPin.project r754 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xeeeeeeeeeeeeeeee (by decide +kernel)
theorem hot754 : forcedConst r754 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
