import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv756_4260 : PetersenPackedPin.project r756 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv756_4814 : PetersenPackedPin.project r756 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv756_5473 : PetersenPackedPin.project r756 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv756_6170 : PetersenPackedPin.project r756 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv756_6790 : PetersenPackedPin.project r756 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv756_7474 : PetersenPackedPin.project r756 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv756_8012 : PetersenPackedPin.project r756 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv756_1734 : PetersenPackedPin.project r756 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv756_4260 pv756_6790 rfl rfl
theorem pv756_1887 : PetersenPackedPin.project r756 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv756_6170 pv756_6790 rfl rfl
theorem pv756_2192 : PetersenPackedPin.project r756 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv756_4260 pv756_6170 rfl rfl
theorem pv756_5224 : PetersenPackedPin.project r756 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv756_4260 pv756_4814 rfl rfl
theorem pv756_6504 : PetersenPackedPin.project r756 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv756_4260 pv756_6170 rfl rfl
theorem pv756_6546 : PetersenPackedPin.project r756 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv756_4814 pv756_6170 rfl rfl
theorem pv756_7152 : PetersenPackedPin.project r756 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv756_4814 pv756_6790 rfl rfl
theorem pv756_7235 : PetersenPackedPin.project r756 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv756_5473 pv756_6790 rfl rfl
theorem pv756_7712 : PetersenPackedPin.project r756 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0xffffcccc := PetersenWireProjection.derive 3 pv756_4814 pv756_7474 rfl rfl
theorem pv756_7855 : PetersenPackedPin.project r756 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv756_6170 pv756_7474 rfl rfl
theorem pv756_4925 : PetersenPackedPin.project r756 (0xcccceeeecccceeeecccceeeecccceeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv756_1734 pv756_4814 rfl rfl
theorem pv756_4974 : PetersenPackedPin.project r756 (0xcceecceecceecceecceecceecceeccee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv756_2192 pv756_4814 rfl rfl
theorem pv756_6049 : PetersenPackedPin.project r756 (0xff00f000ff00f000ff00f000ff00f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv756_6170 pv756_7235 rfl rfl
theorem pv756_6597 : PetersenPackedPin.project r756 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv756_4260 pv756_6546 rfl rfl
theorem pv756_7206 : PetersenPackedPin.project r756 (0xffffeeeeffffeeeeffffeeeeffffeeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv756_4260 pv756_7152 rfl rfl
end PetersenSmallStarts.M191.Residual
