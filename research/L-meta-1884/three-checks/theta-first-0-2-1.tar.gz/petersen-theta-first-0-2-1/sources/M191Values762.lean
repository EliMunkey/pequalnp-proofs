import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv762_4260 : PetersenPackedPin.project r762 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv762_4814 : PetersenPackedPin.project r762 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv762_5473 : PetersenPackedPin.project r762 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv762_6170 : PetersenPackedPin.project r762 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv762_6790 : PetersenPackedPin.project r762 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv762_7474 : PetersenPackedPin.project r762 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv762_8012 : PetersenPackedPin.project r762 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv762_1734 : PetersenPackedPin.project r762 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv762_4260 pv762_6790 rfl rfl
theorem pv762_1829 : PetersenPackedPin.project r762 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 1 pv762_5473 pv762_6790 rfl rfl
theorem pv762_2192 : PetersenPackedPin.project r762 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv762_4260 pv762_6170 rfl rfl
theorem pv762_5920 : PetersenPackedPin.project r762 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xfcfcfcfc := PetersenWireProjection.derive 3 pv762_4814 pv762_5473 rfl rfl
theorem pv762_6504 : PetersenPackedPin.project r762 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv762_4260 pv762_6170 rfl rfl
theorem pv762_7095 : PetersenPackedPin.project r762 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv762_4260 pv762_6790 rfl rfl
theorem pv762_4929 : PetersenPackedPin.project r762 (0xccccfcfcccccfcfcccccfcfcccccfcfc : BitVec 128) = 0xfcfcfcfc := PetersenWireProjection.derive 3 pv762_1829 pv762_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
