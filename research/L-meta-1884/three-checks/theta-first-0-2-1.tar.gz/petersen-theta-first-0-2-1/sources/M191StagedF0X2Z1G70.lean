import higher.WireProjection
import M191Values0
import M191Values2
import M191Values5
import M191Values737
import M191Values739
import M191Values740
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredRows0
import M191StartPreferredRows33
import M191StartPreferredRows37
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows51
import M191StartPreferredRows54
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows69
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b7566 : Blocked tgt 9 s7566 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b7567 : Blocked tgt 9 s7567 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b7568 : Blocked tgt 9 s7568 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s7568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xf5f50000f5f50000f5f50000f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b7569 : Blocked tgt 9 s7569 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7569 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b7570 : Blocked tgt 9 s7570 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b8462 : Blocked tgt 9 s8462 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s8462 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b8463 : Blocked tgt 9 s8463 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s8463 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b8464 : Blocked tgt 9 s8464 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s8464 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5729 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b8465 : Blocked tgt 9 s8465 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s8465 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b8466 : Blocked tgt 9 s8466 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s8466 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b10541 : Blocked tgt 9 s10541 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10541 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b10804 : Blocked tgt 9 s10804 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s10804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b10978 : Blocked tgt 9 s10978 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s10978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b10979 : Blocked tgt 9 s10979 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10979 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b11523 : Blocked tgt 9 s11523 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11523 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b11524 : Blocked tgt 9 s11524 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s11524 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_3582 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12294 : Blocked tgt 9 s12294 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12947 : Blocked tgt 9 s12947 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12948 : Blocked tgt 9 s12948 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s12948 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_3677 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b12949 : Blocked tgt 9 s12949 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12949 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12997 : Blocked tgt 9 s12997 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12998 : Blocked tgt 9 s12998 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s12998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0x55550000555500005555000055550000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b12999 : Blocked tgt 9 s12999 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b13043 : Blocked tgt 9 s13043 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b13044 : Blocked tgt 9 s13044 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s13044 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3730 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b13045 : Blocked tgt 9 s13045 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13045 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b13649 : Blocked tgt 9 s13649 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b13650 : Blocked tgt 9 s13650 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s13650 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3759 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b13651 : Blocked tgt 9 s13651 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13651 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4429 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13759 : Blocked tgt 9 s13759 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13841 : Blocked tgt 9 s13841 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13841 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xcc00cc00cc00cc00cc00cc00cc00cc00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13988 : Blocked tgt 9 s13988 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13988 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2240 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13989 : Blocked tgt 9 s13989 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s13989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_3304 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b13990 : Blocked tgt 9 s13990 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13990 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xcccc0000cccc0000cccc0000cccc0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14077 : Blocked tgt 9 s14077 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s14077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1779 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14078 : Blocked tgt 9 s14078 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_3359 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14079 : Blocked tgt 9 s14079 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s14079 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4675 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14160 : Blocked tgt 9 s14160 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s14160 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14161 : Blocked tgt 9 s14161 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s14161 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3427 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b14162 : Blocked tgt 9 s14162 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s14162 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4753 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14283 : Blocked tgt 9 s14283 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s14283 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b14284 : Blocked tgt 9 s14284 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s14284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3485 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b14285 : Blocked tgt 9 s14285 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5241 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14490 : Blocked tgt 9 s14490 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14490 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_2860 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14491 : Blocked tgt 9 s14491 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14491 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xf0f00000f0f00000f0f00000f0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14693 : Blocked tgt 9 s14693 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_2906 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14694 : Blocked tgt 9 s14694 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s14694 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b14898 : Blocked tgt 9 s14898 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s14898 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b14899 : Blocked tgt 9 s14899 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s14899 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5425 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15084 : Blocked tgt 9 s15084 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15084 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3004 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15085 : Blocked tgt 9 s15085 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15085 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_5978 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15086 : Blocked tgt 9 s15086 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15086 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7314 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15087 : Blocked tgt 9 s15087 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15087 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_1887 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15088 : Blocked tgt 9 s15088 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2362 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15089 : Blocked tgt 9 s15089 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff00ff0000000000ff00ff0000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15181 : Blocked tgt 9 s15181 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15181 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_1252 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15182 : Blocked tgt 9 s15182 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15182 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xff00ff0000000000ff00ff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15183 : Blocked tgt 9 s15183 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15183 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff00ff00ff00ff000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15329 : Blocked tgt 9 s15329 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_531 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15330 : Blocked tgt 9 s15330 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15331 : Blocked tgt 9 s15331 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15331 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff000000000000ffff000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15454 : Blocked tgt 9 s15454 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15454 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_1294 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15455 : Blocked tgt 9 s15455 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15455 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffff000000000000ffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15456 : Blocked tgt 9 s15456 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15456 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff0000ffff00000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15544 : Blocked tgt 9 s15544 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s15544 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b15545 : Blocked tgt 9 s15545 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15545 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffff0000ffff0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15546 : Blocked tgt 9 s15546 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15546 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7397 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15547 : Blocked tgt 9 s15547 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15547 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 (PetersenWireProjection.cons pv739_8377 rfl))))))))) (by decide +kernel)
theorem b15548 : Blocked tgt 9 s15548 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15548 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_630 (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b15549 : Blocked tgt 9 s15549 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [] s15549 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_1343 (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b0 : Blocked tgt 10 s0 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [] s0 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
