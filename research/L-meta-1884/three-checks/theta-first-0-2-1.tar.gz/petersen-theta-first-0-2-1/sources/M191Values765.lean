import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv765_4260 : PetersenPackedPin.project r765 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc := by decide +kernel
theorem pv765_4814 : PetersenPackedPin.project r765 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv765_5473 : PetersenPackedPin.project r765 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv765_6170 : PetersenPackedPin.project r765 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv765_6790 : PetersenPackedPin.project r765 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv765_7474 : PetersenPackedPin.project r765 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv765_8012 : PetersenPackedPin.project r765 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv765_2708 : PetersenPackedPin.project r765 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv765_4260 pv765_5473 rfl rfl
theorem pv765_5682 : PetersenPackedPin.project r765 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x3300 := PetersenWireProjection.derive 2 pv765_2708 pv765_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
