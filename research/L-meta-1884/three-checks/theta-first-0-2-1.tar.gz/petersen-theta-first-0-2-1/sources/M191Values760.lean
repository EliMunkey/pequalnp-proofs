import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv760_4260 : PetersenPackedPin.project r760 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv760_4814 : PetersenPackedPin.project r760 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv760_5473 : PetersenPackedPin.project r760 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv760_6170 : PetersenPackedPin.project r760 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv760_6790 : PetersenPackedPin.project r760 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv760_7474 : PetersenPackedPin.project r760 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv760_8012 : PetersenPackedPin.project r760 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv760_456 : PetersenPackedPin.project r760 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0xf000f0 := PetersenWireProjection.derive 1 pv760_5473 pv760_8012 rfl rfl
theorem pv760_1734 : PetersenPackedPin.project r760 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv760_4260 pv760_6790 rfl rfl
theorem pv760_7095 : PetersenPackedPin.project r760 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv760_4260 pv760_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
