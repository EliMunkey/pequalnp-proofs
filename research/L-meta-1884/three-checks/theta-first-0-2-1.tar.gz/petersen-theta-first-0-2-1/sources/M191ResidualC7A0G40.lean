import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredRows27
import M191StartPreferredRows28
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b6124 : Blocked tgt 7 s6124 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6124 7 _ le
  decide +kernel
theorem b6125 : Blocked tgt 7 s6125 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6125 7 _ le
  decide +kernel
theorem b6126 : Blocked tgt 7 s6126 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6126 7 _ le
  decide +kernel
theorem b6127 : Blocked tgt 7 s6127 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6127 7 _ le
  decide +kernel
theorem b6128 : Blocked tgt 7 s6128 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6128 7 _ le
  decide +kernel
theorem b6129 : Blocked tgt 7 s6129 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6129 7 _ le
  decide +kernel
theorem b6130 : Blocked tgt 7 s6130 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s6130 7 _ le
  decide +kernel
theorem b6131 : Blocked tgt 7 s6131 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6131 7 _ le
  decide +kernel
theorem b6132 : Blocked tgt 7 s6132 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(5,false))] s6132 7 _ le
  decide +kernel
theorem b6133 : Blocked tgt 7 s6133 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6133 7 _ le
  decide +kernel
theorem b6134 : Blocked tgt 7 s6134 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6134 7 _ le
  decide +kernel
theorem b6135 : Blocked tgt 7 s6135 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6135 7 _ le
  decide +kernel
theorem b6136 : Blocked tgt 7 s6136 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s6136 7 _ le
  decide +kernel
theorem b6137 : Blocked tgt 7 s6137 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s6137 7 _ le
  decide +kernel
theorem b6138 : Blocked tgt 7 s6138 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6138 7 _ le
  decide +kernel
theorem b6139 : Blocked tgt 7 s6139 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6139 7 _ le
  decide +kernel
theorem b6140 : Blocked tgt 7 s6140 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6140 7 _ le
  decide +kernel
theorem b6141 : Blocked tgt 7 s6141 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6141 7 _ le
  decide +kernel
theorem b6142 : Blocked tgt 7 s6142 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6142 7 _ le
  decide +kernel
theorem b6143 : Blocked tgt 7 s6143 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6143 7 _ le
  decide +kernel
theorem b6144 : Blocked tgt 7 s6144 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6144 7 _ le
  decide +kernel
theorem b6145 : Blocked tgt 7 s6145 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6145 7 _ le
  decide +kernel
theorem b6146 : Blocked tgt 7 s6146 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6146 7 _ le
  decide +kernel
theorem b6147 : Blocked tgt 7 s6147 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6147 7 _ le
  decide +kernel
theorem b6148 : Blocked tgt 7 s6148 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6148 7 _ le
  decide +kernel
theorem b6149 : Blocked tgt 7 s6149 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6149 7 _ le
  decide +kernel
theorem b6150 : Blocked tgt 7 s6150 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6150 7 _ le
  decide +kernel

theorem b6151 : Blocked tgt 7 s6151 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6151 7 _ le
  decide +kernel
theorem b6152 : Blocked tgt 7 s6152 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6152 7 _ le
  decide +kernel
theorem b6153 : Blocked tgt 7 s6153 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6153 7 _ le
  decide +kernel
theorem b6154 : Blocked tgt 7 s6154 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6154 7 _ le
  decide +kernel
theorem b6155 : Blocked tgt 7 s6155 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6155 7 _ le
  decide +kernel
theorem b6156 : Blocked tgt 7 s6156 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6156 7 _ le
  decide +kernel
theorem b6157 : Blocked tgt 7 s6157 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s6157 7 _ le
  decide +kernel
theorem b6158 : Blocked tgt 7 s6158 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6158 7 _ le
  decide +kernel
theorem b6159 : Blocked tgt 7 s6159 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6159 7 _ le
  decide +kernel
theorem b6306 : Blocked tgt 7 s6306 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6306 7 _ le
  decide +kernel
theorem b6307 : Blocked tgt 7 s6307 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6307 7 _ le
  decide +kernel
theorem b6308 : Blocked tgt 7 s6308 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6308 7 _ le
  decide +kernel
theorem b6309 : Blocked tgt 7 s6309 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6309 7 _ le
  decide +kernel

theorem b6310 : Blocked tgt 7 s6310 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6310 7 _ le
  decide +kernel
theorem b6311 : Blocked tgt 7 s6311 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6311 7 _ le
  decide +kernel
theorem b6312 : Blocked tgt 7 s6312 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6312 7 _ le
  decide +kernel
theorem b6313 : Blocked tgt 7 s6313 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6313 7 _ le
  decide +kernel
theorem b6314 : Blocked tgt 7 s6314 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6314 7 _ le
  decide +kernel
theorem b6315 : Blocked tgt 7 s6315 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6315 7 _ le
  decide +kernel
theorem b6316 : Blocked tgt 7 s6316 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6316 7 _ le
  decide +kernel
theorem b6317 : Blocked tgt 7 s6317 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(false,(0,true),(4,false))] s6317 7 _ le
  decide +kernel
theorem b6318 : Blocked tgt 7 s6318 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6318 7 _ le
  decide +kernel
theorem b6319 : Blocked tgt 7 s6319 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6319 7 _ le
  decide +kernel
theorem b6320 : Blocked tgt 7 s6320 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6320 7 _ le
  decide +kernel
theorem b6321 : Blocked tgt 7 s6321 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6321 7 _ le
  decide +kernel
theorem b6322 : Blocked tgt 7 s6322 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6322 7 _ le
  decide +kernel
theorem b6323 : Blocked tgt 7 s6323 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6323 7 _ le
  decide +kernel
theorem b6324 : Blocked tgt 7 s6324 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6324 7 _ le
  decide +kernel
theorem b6325 : Blocked tgt 7 s6325 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6325 7 _ le
  decide +kernel

theorem b6326 : Blocked tgt 7 s6326 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6326 7 _ le
  decide +kernel
theorem b6327 : Blocked tgt 7 s6327 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6327 7 _ le
  decide +kernel
theorem b6328 : Blocked tgt 7 s6328 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6328 7 _ le
  decide +kernel
theorem b6329 : Blocked tgt 7 s6329 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6329 7 _ le
  decide +kernel
theorem b6330 : Blocked tgt 7 s6330 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6330 7 _ le
  decide +kernel
theorem b6331 : Blocked tgt 7 s6331 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6331 7 _ le
  decide +kernel
theorem b6332 : Blocked tgt 7 s6332 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6332 7 _ le
  decide +kernel
theorem b6333 : Blocked tgt 7 s6333 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6333 7 _ le
  decide +kernel
theorem b6334 : Blocked tgt 7 s6334 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6334 7 _ le
  decide +kernel
theorem b6335 : Blocked tgt 7 s6335 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6335 7 _ le
  decide +kernel
theorem b6336 : Blocked tgt 7 s6336 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6336 7 _ le
  decide +kernel
theorem b6337 : Blocked tgt 7 s6337 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s6337 7 _ le
  decide +kernel
theorem b6338 : Blocked tgt 7 s6338 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6338 7 _ le
  decide +kernel
theorem b6339 : Blocked tgt 7 s6339 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s6339 7 _ le
  decide +kernel
theorem b6340 : Blocked tgt 7 s6340 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6340 7 _ le
  decide +kernel
theorem b6341 : Blocked tgt 7 s6341 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(false,(0,true),(4,false))] s6341 7 _ le
  decide +kernel

theorem b6342 : Blocked tgt 7 s6342 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(false,(0,true),(4,false))] s6342 7 _ le
  decide +kernel
theorem b6343 : Blocked tgt 7 s6343 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(false,(0,true),(4,false))] s6343 7 _ le
  decide +kernel
theorem b6344 : Blocked tgt 7 s6344 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6344 7 _ le
  decide +kernel
theorem b6345 : Blocked tgt 7 s6345 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s6345 7 _ le
  decide +kernel
theorem b6346 : Blocked tgt 7 s6346 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6346 7 _ le
  decide +kernel
theorem b6347 : Blocked tgt 7 s6347 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6347 7 _ le
  decide +kernel
theorem b6348 : Blocked tgt 7 s6348 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6348 7 _ le
  decide +kernel
theorem b6349 : Blocked tgt 7 s6349 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6349 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
