import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv735_4260 : PetersenPackedPin.project r735 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv735_4814 : PetersenPackedPin.project r735 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv735_5473 : PetersenPackedPin.project r735 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv735_6170 : PetersenPackedPin.project r735 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv735_6790 : PetersenPackedPin.project r735 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv735_7474 : PetersenPackedPin.project r735 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv735_8012 : PetersenPackedPin.project r735 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv735_1734 : PetersenPackedPin.project r735 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv735_4260 pv735_6790 rfl rfl
theorem pv735_2192 : PetersenPackedPin.project r735 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv735_4260 pv735_6170 rfl rfl
theorem pv735_2708 : PetersenPackedPin.project r735 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv735_4260 pv735_5473 rfl rfl
theorem pv735_3632 : PetersenPackedPin.project r735 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 2 pv735_4260 pv735_5473 rfl rfl
theorem pv735_5850 : PetersenPackedPin.project r735 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv735_4260 pv735_5473 rfl rfl
theorem pv735_5920 : PetersenPackedPin.project r735 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv735_4814 pv735_5473 rfl rfl
theorem pv735_6504 : PetersenPackedPin.project r735 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv735_4260 pv735_6170 rfl rfl
theorem pv735_3666 : PetersenPackedPin.project r735 (0x54545454545454545454545454545454 : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 2 pv735_4260 pv735_5920 rfl rfl
theorem pv735_5029 : PetersenPackedPin.project r735 (0xcececececececececececececececece : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv735_2708 pv735_4814 rfl rfl
theorem pv735_5102 : PetersenPackedPin.project r735 (0xdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdc : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv735_3632 pv735_4814 rfl rfl
theorem pv735_5682 : PetersenPackedPin.project r735 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 2 pv735_2708 pv735_6170 rfl rfl
theorem pv735_5977 : PetersenPackedPin.project r735 (0xfefefefefefefefefefefefefefefefe : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv735_4260 pv735_5920 rfl rfl
theorem pv735_6308 : PetersenPackedPin.project r735 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv735_2708 pv735_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
