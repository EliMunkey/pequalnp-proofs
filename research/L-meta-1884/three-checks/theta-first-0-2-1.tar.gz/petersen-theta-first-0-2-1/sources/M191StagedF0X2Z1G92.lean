import Petersen191Symmetry
import M191StartPreferredSignals
import M191ResidualC8A0G1
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G57
import M191StagedF0X2Z1G58
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G65
import M191StagedF0X2Z1G66
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G78
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G85
import M191StagedF0X2Z1G86
import M191StagedF0X2Z1G89
import M191StagedF0X2Z1G90
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows37
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows6
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows7
import M191StartPreferredRows8
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair335i0 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s336,s337,s338,s339,s340,s341]) (hints := [5296,6842,0,1,5296,5552,9679,2,5552,5552,3,4,9679,6842,9679,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s336,s337,s338,s339,s340,s341], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s336) (b336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s337) (b337) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s338) (b338) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s339) (b339) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s340) (b340) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s341) (b341) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i1 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word69) := by
  refine PetersenLocalChildren.pair_close (bank := #[s338,s341,s342,s343,s344,s14,s345,s346]) (hints := [6844,6844,2,3,5554,5554,4,0,5554,5554,5,6,6844,6844,7,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s338,s341,s342,s343,s344,s14,s345,s346], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s338) (b338) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s341) (b341) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s342) (b342) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s343) (b343) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s344) (b344) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14) (b14) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s345) (b345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s346) (b346) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i2 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s347,s348,s379,s392,s393,s417]) (hints := [5552,5552,5936,0,6842,6842,1,2,5936,6842,5936,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s347,s348,s379,s392,s393,s417], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s347) (b347) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s348) (b348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s379) (b379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s392) (b392) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s393) (b393) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s417) (b417) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i3 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s418,s419,s431,s432]) (hints := [6582,6582,7478,0,4526,5550,1673,1,7478,5550,7478,2,6582,6582,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s418,s419,s431,s432], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s418) (b418) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s419) (b419) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s431) (b431) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s432) (b432) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i4 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s433,s434,s435,s436]) (hints := [5550,5550,7470,0,4534,6582,11469,1,7470,6582,7470,2,5550,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s433,s434,s435,s436], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s433) (b433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s434) (b434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s435) (b435) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s436) (b436) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i5 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s437,s438,s439,s440]) (hints := [9678,9678,13646,0,1454,5550,13517,1,13646,5550,13646,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s437,s438,s439,s440], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s437) (b437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s438) (b438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s439) (b439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s440) (b440) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i6 : PetersenLocalChildren.PairOK tgt 8 s335 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s441,s442,s454,s455]) (hints := [5550,5550,13614,0,1486,9678,8841,1,13614,9678,13614,2,5550,5550,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s441,s442,s454,s455], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s441) (b441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s442) (b442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s454) (b454) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s455) (b455) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i7 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word69) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s456,s457,s458,s459]) (hints := [906,9678,0,1,906,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s456,s457,s458,s459], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s456) (b456) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s457) (b457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s458) (b458) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s459) (b459) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i8 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s460,s461,s484,s485,s486,s487]) (hints := [9679,9679,5678,0,5936,1,5936,2,10191,3,5678,4,9679,9679,5936,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s460,s461,s484,s485,s486,s487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s460) (b460) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s461) (b461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s484) (b484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s485) (b485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s486) (b486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s487) (b487) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i9 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s488,s489,s490,s491]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s488,s489,s490,s491], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s488) (b488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s489) (b489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s490) (b490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s491) (b491) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i10 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s492,s493,s524,s525,s526,s527]) (hints := [9679,9679,11471,0,7472,1,7472,2,11471,3,11471,4,9679,9679,7472,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s492,s493,s524,s525,s526,s527], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s492) (b492) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s493) (b493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s524) (b524) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s525) (b525) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s526) (b526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s527) (b527) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i11 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s528,s529,s559,s560,s561,s562]) (hints := [9679,9679,13519,0,13648,1,13648,2,13519,3,13519,4,9679,9679,13648,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s528,s529,s559,s560,s561,s562], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s528) (b528) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s529) (b529) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s559) (b559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s560) (b560) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s561) (b561) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s562) (b562) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i12 : PetersenLocalChildren.PairOK tgt 8 s335 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s563,s564,s565,s566]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s563,s564,s565,s566], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s563) (b563) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s564) (b564) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s565) (b565) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s566) (b566) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i13 : PetersenLocalChildren.PairOK tgt 8 s335 (word69,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s460,s487,s567,s568,s569,s573,s574,s575]) (hints := [9937,2,5680,0,9937,3,5938,4,5680,5,5680,6,5938,7,5938,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s460,s487,s567,s568,s569,s573,s574,s575], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s460) (b460) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s487) (b487) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s567) (b567) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s568) (b568) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s569) (b569) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s573) (b573) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s574) (b574) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s575) (b575) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i14 : PetersenLocalChildren.PairOK tgt 8 s335 (word69,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s576,s577,s578,s614,s619,s651,s652,s653]) (hints := [1677,0,1677,1,7482,2,7482,3,1677,4,1677,5,7482,6,7482,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s576,s577,s578,s614,s619,s651,s652,s653], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s576) (b576) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s577) (b577) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s578) (b578) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s614) (b614) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s619) (b619) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s651) (b651) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s652) (b652) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s653) (b653) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i15 : PetersenLocalChildren.PairOK tgt 8 s335 (word69,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s654,s655,s656,s682,s683,s716,s717,s718]) (hints := [2701,0,2701,1,11473,2,11473,3,2701,4,2701,5,11473,6,11473,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s654,s655,s656,s682,s683,s716,s717,s718], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s654) (b654) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s655) (b655) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s656) (b656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s682) (b682) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s683) (b683) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s716) (b716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s717) (b717) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s718) (b718) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i16 : PetersenLocalChildren.PairOK tgt 8 s335 (word69,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s719,s720,s721,s746,s747,s779,s780,s781]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s719,s720,s721,s746,s747,s779,s780,s781], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s719) (b719) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s720) (b720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s721) (b721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s746) (b746) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s747) (b747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s779) (b779) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s780) (b780) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s781) (b781) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i17 : PetersenLocalChildren.PairOK tgt 8 s335 (word69,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s782,s783,s784,s817,s822,s851,s852,s853]) (hints := [8845,0,8845,1,13618,2,13618,3,8845,4,8845,5,13618,6,13618,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s782,s783,s784,s817,s822,s851,s852,s853], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s782) (b782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s783) (b783) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s784) (b784) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s817) (b817) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s822) (b822) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s851) (b851) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s852) (b852) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s853) (b853) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i18 : PetersenLocalChildren.PairOK tgt 8 s335 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s854,s855,s859,s860]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s854,s855,s859,s860], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s854) (b854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s855) (b855) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s859) (b859) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s860) (b860) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i19 : PetersenLocalChildren.PairOK tgt 8 s335 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s861,s862,s869,s870]) (hints := [11469,5934,11469,0,2697,6966,2697,1,11469,6966,11469,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s861,s862,s869,s870], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s861) (b861) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s862) (b862) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s869) (b869) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s870) (b870) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i20 : PetersenLocalChildren.PairOK tgt 8 s335 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s871,s872,s879,s880]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s871,s872,s879,s880], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s871) (b871) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s872) (b872) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s879) (b879) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s880) (b880) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i21 : PetersenLocalChildren.PairOK tgt 8 s335 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s881,s882,s886,s887]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s881,s882,s886,s887], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s881) (b881) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s882) (b882) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s886) (b886) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s887) (b887) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i22 : PetersenLocalChildren.PairOK tgt 8 s335 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s888,s889,s890,s891]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s888,s889,s890,s891], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s888) (b888) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s889) (b889) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s890) (b890) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s891) (b891) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i23 : PetersenLocalChildren.PairOK tgt 8 s335 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s892,s893,s896,s897]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s892,s893,s896,s897], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s892) (b892) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s893) (b893) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s896) (b896) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s897) (b897) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i24 : PetersenLocalChildren.PairOK tgt 8 s335 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s898,s899,s902,s903]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s898,s899,s902,s903], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s898) (b898) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s899) (b899) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s902) (b902) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s903) (b903) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i25 : PetersenLocalChildren.PairOK tgt 8 s335 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s904,s905,s909,s910]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s904,s905,s909,s910], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s904) (b904) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s905) (b905) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s909) (b909) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s910) (b910) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i26 : PetersenLocalChildren.PairOK tgt 8 s335 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s911,s912,s915,s916]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s911,s912,s915,s916], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s911) (b911) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s912) (b912) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s915) (b915) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s916) (b916) <|
    PetersenLocalChildren.nil
private theorem thetaPair335i27 : PetersenLocalChildren.PairOK tgt 8 s335 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s917,s918,s919,s920]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s917,s918,s919,s920], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s917) (b917) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s918) (b918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s919) (b919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s920) (b920) <|
    PetersenLocalChildren.nil
theorem b335 : Blocked tgt 9 s335 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word69),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word69),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word69,word0),(word69,word6),(word69,word5),(word69,word2),(word69,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s335 p
  exact
    PetersenLocalChildren.push thetaPair335i0 <|
    PetersenLocalChildren.push thetaPair335i1 <|
    PetersenLocalChildren.push thetaPair335i2 <|
    PetersenLocalChildren.push thetaPair335i3 <|
    PetersenLocalChildren.push thetaPair335i4 <|
    PetersenLocalChildren.push thetaPair335i5 <|
    PetersenLocalChildren.push thetaPair335i6 <|
    PetersenLocalChildren.push thetaPair335i7 <|
    PetersenLocalChildren.push thetaPair335i8 <|
    PetersenLocalChildren.push thetaPair335i9 <|
    PetersenLocalChildren.push thetaPair335i10 <|
    PetersenLocalChildren.push thetaPair335i11 <|
    PetersenLocalChildren.push thetaPair335i12 <|
    PetersenLocalChildren.push thetaPair335i13 <|
    PetersenLocalChildren.push thetaPair335i14 <|
    PetersenLocalChildren.push thetaPair335i15 <|
    PetersenLocalChildren.push thetaPair335i16 <|
    PetersenLocalChildren.push thetaPair335i17 <|
    PetersenLocalChildren.push thetaPair335i18 <|
    PetersenLocalChildren.push thetaPair335i19 <|
    PetersenLocalChildren.push thetaPair335i20 <|
    PetersenLocalChildren.push thetaPair335i21 <|
    PetersenLocalChildren.push thetaPair335i22 <|
    PetersenLocalChildren.push thetaPair335i23 <|
    PetersenLocalChildren.push thetaPair335i24 <|
    PetersenLocalChildren.push thetaPair335i25 <|
    PetersenLocalChildren.push thetaPair335i26 <|
    PetersenLocalChildren.push thetaPair335i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i0 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2586,s58,s144,s2587]) (hints := [9805,9933,6840,0,9805,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2586,s58,s144,s2587], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2586) (b2586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s58) (b58) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s144) (b144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2587) (b2587) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i1 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2588,s348,s930,s1557,s2589,s2590]) (hints := [9935,9935,907,0,9679,1,9679,2,395,3,907,4,9679,9935,9679,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2588,s348,s930,s1557,s2589,s2590], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2588) (b2588) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s348) (b348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s930) (b930) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1557) (b1557) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2589) (b2589) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2590) (b2590) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i2 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2586,s138,s2591,s7,s1718]) (hints := [9934,9934,5935,0,1,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s2586,s138,s2591,s7,s1718], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2586) (b2586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s138) (b138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2591) (b2591) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7) (b7) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1718) (b1718) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i3 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2592,s2593,s2594,s2595,s2596,s2597]) (hints := [8903,8903,1675,0,9927,9935,1,2,8911,9935,1675,3,8903,8903,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2592,s2593,s2594,s2595,s2596,s2597], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2592) (b2592) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2593) (b2593) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2594) (b2594) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2595) (b2595) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2596) (b2596) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2597) (b2597) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i4 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2598,s2599,s2622,s2623,s2624,s2625]) (hints := [9935,9935,2699,0,11471,1,11471,2,2187,3,2699,4,9935,9935,11471,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2598,s2599,s2622,s2623,s2624,s2625], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2598) (b2598) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2599) (b2599) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2622) (b2622) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2623) (b2623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2624) (b2624) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2625) (b2625) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i5 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2626,s2627,s2649,s2650,s2651,s2652]) (hints := [9935,9935,4747,0,13519,1,13519,2,4235,3,4747,4,9935,9935,13519,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2626,s2627,s2649,s2650,s2651,s2652], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2626) (b2626) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2627) (b2627) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2649) (b2649) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2650) (b2650) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2651) (b2651) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2652) (b2652) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i6 : PetersenLocalChildren.PairOK tgt 8 s2585 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2653,s2654,s2655,s2656,s2657,s2658]) (hints := [1679,1679,8843,0,9871,9935,1,2,1743,9935,8843,3,1679,1679,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2653,s2654,s2655,s2656,s2657,s2658], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2653) (b2653) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2654) (b2654) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2655) (b2655) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2656) (b2656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2657) (b2657) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2658) (b2658) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i7 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2659,s2660,s2684,s2685,s2686,s2687]) (hints := [6842,6842,6970,0,9679,1,9679,2,6970,3,6970,4,9679,6842,9679,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2659,s2660,s2684,s2685,s2686,s2687], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2659) (b2659) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2660) (b2660) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2684) (b2684) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2685) (b2685) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2686) (b2686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2687) (b2687) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i8 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2586,s2688,s2713,s2714]) (hints := [5934,6840,5934,0,6062,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2586,s2688,s2713,s2714], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2586) (b2586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2688) (b2688) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2713) (b2713) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2714) (b2714) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i9 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2715,s2716,s2748,s2749,s2750,s2751]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2715,s2716,s2748,s2749,s2750,s2751], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2715) (b2715) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2716) (b2716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2748) (b2748) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2749) (b2749) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2750) (b2750) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2751) (b2751) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i10 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2752,s2753,s2754,s2755]) (hints := [7470,4776,7470,0,11469,6840,11469,1,7470,6840,7470,2,11469,4776,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2752,s2753,s2754,s2755], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2752) (b2752) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2753) (b2753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2754) (b2754) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2755) (b2755) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i11 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2756,s2757,s2758,s2759]) (hints := [13646,2712,13646,0,13517,6840,13517,1,13646,6840,13646,2,13517,2712,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2756,s2757,s2758,s2759], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2756) (b2756) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2757) (b2757) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2758) (b2758) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2759) (b2759) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i12 : PetersenLocalChildren.PairOK tgt 8 s2585 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2760,s2761,s2792,s2793,s2794,s2795]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2760,s2761,s2792,s2793,s2794,s2795], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2760) (b2760) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2761) (b2761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2792) (b2792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2793) (b2793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2794) (b2794) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2795) (b2795) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i13 : PetersenLocalChildren.PairOK tgt 8 s2585 (word1,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2796,s2822,s2823,s2824,s2825,s2826]) (hints := [5678,0,5678,1,9679,9679,5936,2,9679,9679,5678,3,5934,4,5936,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s2796,s2822,s2823,s2824,s2825,s2826], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2796) (b2796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2822) (b2822) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2823) (b2823) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2824) (b2824) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2825) (b2825) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2826) (b2826) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i14 : PetersenLocalChildren.PairOK tgt 8 s2585 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2827,s2828,s2832,s2833]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2827,s2828,s2832,s2833], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2827) (b2827) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2828) (b2828) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2832) (b2832) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2833) (b2833) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i15 : PetersenLocalChildren.PairOK tgt 8 s2585 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2834,s2835,s2836,s2837]) (hints := [9677,9677,11469,0,4920,6968,7470,1,11469,6968,11469,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2834,s2835,s2836,s2837], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2834) (b2834) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2835) (b2835) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2836) (b2836) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2837) (b2837) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i16 : PetersenLocalChildren.PairOK tgt 8 s2585 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2838,s2839,s2840,s2841]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2838,s2839,s2840,s2841], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2838) (b2838) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2839) (b2839) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2840) (b2840) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2841) (b2841) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i17 : PetersenLocalChildren.PairOK tgt 8 s2585 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2842,s2843,s2847,s2848]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2842,s2843,s2847,s2848], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2842) (b2842) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2843) (b2843) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2847) (b2847) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2848) (b2848) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i18 : PetersenLocalChildren.PairOK tgt 8 s2585 (word13,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2849,s2850,s2851,s2852]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2849,s2850,s2851,s2852], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2849) (b2849) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2850) (b2850) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2851) (b2851) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2852) (b2852) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i19 : PetersenLocalChildren.PairOK tgt 8 s2585 (word13,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2853,s2854,s2855,s2856]) (hints := [5934,5934,7470,0,11469,6966,11469,1,7470,6966,7470,2,11469,5934,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2853,s2854,s2855,s2856], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2853) (b2853) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2854) (b2854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2855) (b2855) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2856) (b2856) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i20 : PetersenLocalChildren.PairOK tgt 8 s2585 (word13,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2857,s2858,s2859,s2860]) (hints := [10062,10062,13646,0,13517,5934,13517,1,13646,5934,13646,2,13517,10062,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2857,s2858,s2859,s2860], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2857) (b2857) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2858) (b2858) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2859) (b2859) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2860) (b2860) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i21 : PetersenLocalChildren.PairOK tgt 8 s2585 (word13,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2861,s2862,s2863,s2864]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2861,s2862,s2863,s2864], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2861) (b2861) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2862) (b2862) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2863) (b2863) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2864) (b2864) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i22 : PetersenLocalChildren.PairOK tgt 8 s2585 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2865,s2866,s2867,s2868]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2865,s2866,s2867,s2868], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2865) (b2865) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2866) (b2866) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2867) (b2867) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2868) (b2868) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i23 : PetersenLocalChildren.PairOK tgt 8 s2585 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2869,s2870,s2871,s2872]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2869,s2870,s2871,s2872], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2869) (b2869) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2870) (b2870) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2871) (b2871) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2872) (b2872) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i24 : PetersenLocalChildren.PairOK tgt 8 s2585 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2873,s2874,s2882,s2883]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2873,s2874,s2882,s2883], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2873) (b2873) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2874) (b2874) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2882) (b2882) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2883) (b2883) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i25 : PetersenLocalChildren.PairOK tgt 8 s2585 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2884,s2885,s2886,s2887]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2884,s2885,s2886,s2887], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2884) (b2884) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2885) (b2885) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2886) (b2886) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2887) (b2887) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i26 : PetersenLocalChildren.PairOK tgt 8 s2585 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2888,s2889,s2890,s2891]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2888,s2889,s2890,s2891], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2888) (b2888) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2889) (b2889) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2890) (b2890) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2891) (b2891) <|
    PetersenLocalChildren.nil
private theorem thetaPair2585i27 : PetersenLocalChildren.PairOK tgt 8 s2585 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2892,s2893,s2894,s2895]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s2892,s2893,s2894,s2895], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2892) (b2892) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2893) (b2893) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2894) (b2894) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2895) (b2895) <|
    PetersenLocalChildren.nil
theorem b2585 : Blocked tgt 9 s2585 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word13),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word13),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word13),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word13,word6),(word13,word5),(word13,word2),(word13,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s2585 p
  exact
    PetersenLocalChildren.push thetaPair2585i0 <|
    PetersenLocalChildren.push thetaPair2585i1 <|
    PetersenLocalChildren.push thetaPair2585i2 <|
    PetersenLocalChildren.push thetaPair2585i3 <|
    PetersenLocalChildren.push thetaPair2585i4 <|
    PetersenLocalChildren.push thetaPair2585i5 <|
    PetersenLocalChildren.push thetaPair2585i6 <|
    PetersenLocalChildren.push thetaPair2585i7 <|
    PetersenLocalChildren.push thetaPair2585i8 <|
    PetersenLocalChildren.push thetaPair2585i9 <|
    PetersenLocalChildren.push thetaPair2585i10 <|
    PetersenLocalChildren.push thetaPair2585i11 <|
    PetersenLocalChildren.push thetaPair2585i12 <|
    PetersenLocalChildren.push thetaPair2585i13 <|
    PetersenLocalChildren.push thetaPair2585i14 <|
    PetersenLocalChildren.push thetaPair2585i15 <|
    PetersenLocalChildren.push thetaPair2585i16 <|
    PetersenLocalChildren.push thetaPair2585i17 <|
    PetersenLocalChildren.push thetaPair2585i18 <|
    PetersenLocalChildren.push thetaPair2585i19 <|
    PetersenLocalChildren.push thetaPair2585i20 <|
    PetersenLocalChildren.push thetaPair2585i21 <|
    PetersenLocalChildren.push thetaPair2585i22 <|
    PetersenLocalChildren.push thetaPair2585i23 <|
    PetersenLocalChildren.push thetaPair2585i24 <|
    PetersenLocalChildren.push thetaPair2585i25 <|
    PetersenLocalChildren.push thetaPair2585i26 <|
    PetersenLocalChildren.push thetaPair2585i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i0 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1721,s57,s59,s145]) (hints := [6840,0,6840,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1721,s57,s59,s145], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1721) (b1721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s57) (b57) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s59) (b59) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s145) (b145) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i1 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2897,s379,s1558,s2898]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s2897,s379,s1558,s2898], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2897) (b2897) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s379) (b379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1558) (b1558) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2898) (b2898) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i2 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1721,s2586]) (hints := [9931,0,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s1721,s2586], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1721) (b1721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2586) (b2586) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i3 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1721,s5,s927]) (hints := [1,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s1721,s5,s927], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1721) (b1721) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i4 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2899,s2900,s2948,s2955,s2956,s2957,s3010,s3011]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s2899,s2900,s2948,s2955,s2956,s2957,s3010,s3011], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2899) (b2899) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2900) (b2900) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2948) (b2948) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2955) (b2955) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2956) (b2956) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2957) (b2957) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3010) (b3010) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3011) (b3011) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i5 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3012,s3013,s3020,s3021]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s3012,s3013,s3020,s3021], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3012) (b3012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3013) (b3013) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3020) (b3020) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3021) (b3021) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i6 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3022,s3023,s3030,s3031]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s3022,s3023,s3030,s3031], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3022) (b3022) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3023) (b3023) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3030) (b3030) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3031) (b3031) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i7 : PetersenLocalChildren.PairOK tgt 8 s2896 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3032,s3033,s3081,s3088,s3089,s3090,s3143,s3144]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s3032,s3033,s3081,s3088,s3089,s3090,s3143,s3144], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3032) (b3032) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3033) (b3033) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3081) (b3081) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3088) (b3088) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3089) (b3089) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3090) (b3090) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3143) (b3143) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3144) (b3144) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i8 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3145,s3151]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s3145,s3151], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3145) (b3145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3151) (b3151) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i9 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s145,s144,s2587,s2688,s3152,s2714]) (hints := [1,0,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s145,s144,s2587,s2688,s3152,s2714], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s145) (b145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s144) (b144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2587) (b2587) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2688) (b2688) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3152) (b3152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2714) (b2714) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i10 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s3152,s200,s3153]) (hints := [6840,6840,0,2,1,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s3152,s200,s3153], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3152) (b3152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s200) (b200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3153) (b3153) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i11 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3154,s3164]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s3154,s3164], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3154) (b3154) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3164) (b3164) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i12 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i13 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i14 : PetersenLocalChildren.PairOK tgt 8 s2896 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3165,s3175]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s3165,s3175], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3165) (b3165) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3175) (b3175) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i15 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3176,s3177,s3178,s3179]) (hints := [9677,9677,0,905,905,1,905,905,2,9677,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s3176,s3177,s3178,s3179], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3176) (b3176) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3177) (b3177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3178) (b3178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3179) (b3179) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i16 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3180,s3181,s3185,s1160,s3186,s3187,s3188,s3189]) (hints := [0,1,2,9681,9681,3,9681,9681,4,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s3180,s3181,s3185,s1160,s3186,s3187,s3188,s3189], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3180) (b3180) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3181) (b3181) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3185) (b3185) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1160) (b1160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3186) (b3186) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3187) (b3187) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3188) (b3188) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3189) (b3189) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i17 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i18 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i19 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i20 : PetersenLocalChildren.PairOK tgt 8 s2896 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i21 : PetersenLocalChildren.PairOK tgt 8 s2896 (word0,word13) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2586,s927]) (hints := [5932,0,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s2586,s927], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2586) (b2586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i22 : PetersenLocalChildren.PairOK tgt 8 s2896 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3190,s3191,s3192,s3193]) (hints := [7478,0,7478,1673,1,1673,7478,2,7478,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s3190,s3191,s3192,s3193], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3190) (b3190) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3191) (b3191) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3192) (b3192) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3193) (b3193) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i23 : PetersenLocalChildren.PairOK tgt 8 s2896 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3194,s3195,s3196,s3197]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s3194,s3195,s3196,s3197], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3194) (b3194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3195) (b3195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3196) (b3196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3197) (b3197) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i24 : PetersenLocalChildren.PairOK tgt 8 s2896 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3198,s3199,s3200,s3201]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s3198,s3199,s3200,s3201], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3198) (b3198) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3199) (b3199) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3200) (b3200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3201) (b3201) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i25 : PetersenLocalChildren.PairOK tgt 8 s2896 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3202,s3203,s3204,s3205]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s3202,s3203,s3204,s3205], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3202) (b3202) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3203) (b3203) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3204) (b3204) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3205) (b3205) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i26 : PetersenLocalChildren.PairOK tgt 8 s2896 (word13,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3206,s3207,s3208,s3209]) (hints := [7478,0,7478,1673,1,1673,7478,2,7478,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s3206,s3207,s3208,s3209], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3206) (b3206) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3207) (b3207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3208) (b3208) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3209) (b3209) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i27 : PetersenLocalChildren.PairOK tgt 8 s2896 (word13,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3210,s3211,s3212,s3213]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s3210,s3211,s3212,s3213], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3210) (b3210) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3211) (b3211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3212) (b3212) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3213) (b3213) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i28 : PetersenLocalChildren.PairOK tgt 8 s2896 (word13,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3214,s3215,s3216,s3217]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s3214,s3215,s3216,s3217], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3214) (b3214) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3215) (b3215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3216) (b3216) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3217) (b3217) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i29 : PetersenLocalChildren.PairOK tgt 8 s2896 (word13,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3218,s3219,s3220,s3221]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s3218,s3219,s3220,s3221], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3218) (b3218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3219) (b3219) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3220) (b3220) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3221) (b3221) <|
    PetersenLocalChildren.nil
private theorem thetaPair2896i30 : PetersenLocalChildren.PairOK tgt 8 s2896 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i31 : PetersenLocalChildren.PairOK tgt 8 s2896 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i32 : PetersenLocalChildren.PairOK tgt 8 s2896 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i33 : PetersenLocalChildren.PairOK tgt 8 s2896 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i34 : PetersenLocalChildren.PairOK tgt 8 s2896 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair2896i35 : PetersenLocalChildren.PairOK tgt 8 s2896 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b2896 : Blocked tgt 9 s2896 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word13),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word13),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word13),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word13),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word13,word6),(word13,word5),(word13,word2),(word13,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s2896 p
  exact
    PetersenLocalChildren.push thetaPair2896i0 <|
    PetersenLocalChildren.push thetaPair2896i1 <|
    PetersenLocalChildren.push thetaPair2896i2 <|
    PetersenLocalChildren.push thetaPair2896i3 <|
    PetersenLocalChildren.push thetaPair2896i4 <|
    PetersenLocalChildren.push thetaPair2896i5 <|
    PetersenLocalChildren.push thetaPair2896i6 <|
    PetersenLocalChildren.push thetaPair2896i7 <|
    PetersenLocalChildren.push thetaPair2896i8 <|
    PetersenLocalChildren.push thetaPair2896i9 <|
    PetersenLocalChildren.push thetaPair2896i10 <|
    PetersenLocalChildren.push thetaPair2896i11 <|
    PetersenLocalChildren.push thetaPair2896i12 <|
    PetersenLocalChildren.push thetaPair2896i13 <|
    PetersenLocalChildren.push thetaPair2896i14 <|
    PetersenLocalChildren.push thetaPair2896i15 <|
    PetersenLocalChildren.push thetaPair2896i16 <|
    PetersenLocalChildren.push thetaPair2896i17 <|
    PetersenLocalChildren.push thetaPair2896i18 <|
    PetersenLocalChildren.push thetaPair2896i19 <|
    PetersenLocalChildren.push thetaPair2896i20 <|
    PetersenLocalChildren.push thetaPair2896i21 <|
    PetersenLocalChildren.push thetaPair2896i22 <|
    PetersenLocalChildren.push thetaPair2896i23 <|
    PetersenLocalChildren.push thetaPair2896i24 <|
    PetersenLocalChildren.push thetaPair2896i25 <|
    PetersenLocalChildren.push thetaPair2896i26 <|
    PetersenLocalChildren.push thetaPair2896i27 <|
    PetersenLocalChildren.push thetaPair2896i28 <|
    PetersenLocalChildren.push thetaPair2896i29 <|
    PetersenLocalChildren.push thetaPair2896i30 <|
    PetersenLocalChildren.push thetaPair2896i31 <|
    PetersenLocalChildren.push thetaPair2896i32 <|
    PetersenLocalChildren.push thetaPair2896i33 <|
    PetersenLocalChildren.push thetaPair2896i34 <|
    PetersenLocalChildren.push thetaPair2896i35 <|
    PetersenLocalChildren.nil
theorem b9425 : Blocked tgt 9 s9425 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s4213) (by decide +kernel)
  exact b4213
theorem b10104 : Blocked tgt 9 s10104 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s5260) (by decide +kernel)
  exact b5260
theorem b10805 : Blocked tgt 9 s10805 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s6099) (by decide +kernel)
  exact b6099
private theorem thetaPair11232i0 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11233,s10986,s54,s11234]) (hints := [5550,0,1,5550,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11233,s10986,s54,s11234], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11233) (b11233) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10986) (b10986) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s54) (b54) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11234) (b11234) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i1 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11235,s338,s1553,s11236]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s11235,s338,s1553,s11236], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11235) (b11235) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s338) (b338) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1553) (b1553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11236) (b11236) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i2 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word31) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11233,s5,s927,s11237,s11238,s11239]) (hints := [1,0,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11233,s5,s927,s11237,s11238,s11239], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11233) (b11233) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11237) (b11237) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11238) (b11238) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11239) (b11239) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i3 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11233,s1713,s2684]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s11233,s1713,s2684], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11233) (b11233) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1713) (b1713) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2684) (b2684) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i4 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11240,s3226,s4215,s5067,s5747,s5834,s11241,s6425]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s11240,s3226,s4215,s5067,s5747,s5834,s11241,s6425], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11240) (b11240) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3226) (b3226) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4215) (b4215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5067) (b5067) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5747) (b5747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5834) (b5834) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11241) (b11241) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6425) (b6425) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i5 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11242,s6556,s7476,s11243]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s11242,s6556,s7476,s11243], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11242) (b11242) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6556) (b6556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7476) (b7476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11243) (b11243) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i6 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11244,s7573,s8372,s11245]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s11244,s7573,s8372,s11245], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11244) (b11244) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7573) (b7573) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8372) (b8372) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11245) (b11245) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i7 : PetersenLocalChildren.PairOK tgt 8 s11232 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11246,s8469,s9427,s9918,s10457,s10544,s11247,s10853]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s11246,s8469,s9427,s9918,s10457,s10544,s11247,s10853], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11246) (b11246) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8469) (b8469) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9427) (b9427) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9918) (b9918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10457) (b10457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10544) (b10544) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11247) (b11247) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10853) (b10853) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i8 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11248,s11249,s11012,s11014,s11250,s11251]) (hints := [779,0,1,2,3,4,9679,5,9679]) (by decide +kernel) ?_
  change ∀ x ∈ [s11248,s11249,s11012,s11014,s11250,s11251], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11248) (b11248) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11249) (b11249) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11012) (b11012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11014) (b11014) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11250) (b11250) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11251) (b11251) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i9 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word31) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10986,s927,s11251,s1135]) (hints := [6840,0,1,6840,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s10986,s927,s11251,s1135], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10986) (b10986) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11251) (b11251) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1135) (b1135) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i10 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11234,s2684,s2660,s3145,s11252,s11253]) (hints := [5936,0,5936,2,3,1,6064,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11234,s2684,s2660,s3145,s11252,s11253], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11234) (b11234) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2684) (b2684) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2660) (b2660) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3145) (b3145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11252) (b11252) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11253) (b11253) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i11 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11254,s11255,s11261,s11262]) (hints := [7478,0,7478,1673,1,1673,7478,2,7478,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s11254,s11255,s11261,s11262], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11254) (b11254) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11255) (b11255) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11261) (b11261) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11262) (b11262) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i12 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11263,s11264,s11265,s11266]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s11263,s11264,s11265,s11266], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11263) (b11263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11264) (b11264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11265) (b11265) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11266) (b11266) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i13 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11267,s11268,s11269,s11270]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s11267,s11268,s11269,s11270], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11267) (b11267) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11268) (b11268) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11269) (b11269) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11270) (b11270) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i14 : PetersenLocalChildren.PairOK tgt 8 s11232 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11271,s11272,s11278,s11279]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s11271,s11272,s11278,s11279], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11271) (b11271) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11272) (b11272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11278) (b11278) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11279) (b11279) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i15 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word31) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s11250,s11280]) (hints := [9676,9676,0,6967,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s11250,s11280], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11250) (b11250) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11280) (b11280) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i16 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i17 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i18 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11281,s11282]) (hints := [9675,9675,11467,7468,0,7468,11467,1,11467,9675,9675,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s11281,s11282], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11281) (b11281) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11282) (b11282) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i19 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11283,s11284]) (hints := [9675,9675,13515,13644,0,13644,13515,1,13515,9675,9675,13644]) (by decide +kernel) ?_
  change ∀ x ∈ [s11283,s11284], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11283) (b11283) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11284) (b11284) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i20 : PetersenLocalChildren.PairOK tgt 8 s11232 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i21 : PetersenLocalChildren.PairOK tgt 8 s11232 (word31,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11285,s1160,s1161,s11286]) (hints := [5676,0,5676,5934,1,5934,5676,2,5676,5934,3,5934]) (by decide +kernel) ?_
  change ∀ x ∈ [s11285,s1160,s1161,s11286], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11285) (b11285) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1160) (b1160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1161) (b1161) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11286) (b11286) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i22 : PetersenLocalChildren.PairOK tgt 8 s11232 (word31,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11287,s11288,s11293,s11294]) (hints := [7736,0,7736,1673,1,1673,7736,2,7736,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s11287,s11288,s11293,s11294], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11287) (b11287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11288) (b11288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11293) (b11293) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11294) (b11294) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i23 : PetersenLocalChildren.PairOK tgt 8 s11232 (word31,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11295,s11296,s11297,s11298]) (hints := [7212,0,7212,11469,1,11469,7212,2,7212,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s11295,s11296,s11297,s11298], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11295) (b11295) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11296) (b11296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11297) (b11297) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11298) (b11298) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i24 : PetersenLocalChildren.PairOK tgt 8 s11232 (word31,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11299,s11300,s11301,s11302]) (hints := [13388,0,13388,13517,1,13517,13388,2,13388,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s11299,s11300,s11301,s11302], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11299) (b11299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11300) (b11300) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11301) (b11301) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11302) (b11302) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i25 : PetersenLocalChildren.PairOK tgt 8 s11232 (word31,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11303,s11304,s11309,s11310]) (hints := [14904,0,14904,8841,1,8841,14904,2,14904,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s11303,s11304,s11309,s11310], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11303) (b11303) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11304) (b11304) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11309) (b11309) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11310) (b11310) <|
    PetersenLocalChildren.nil
private theorem thetaPair11232i26 : PetersenLocalChildren.PairOK tgt 8 s11232 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i27 : PetersenLocalChildren.PairOK tgt 8 s11232 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i28 : PetersenLocalChildren.PairOK tgt 8 s11232 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i29 : PetersenLocalChildren.PairOK tgt 8 s11232 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i30 : PetersenLocalChildren.PairOK tgt 8 s11232 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i31 : PetersenLocalChildren.PairOK tgt 8 s11232 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i32 : PetersenLocalChildren.PairOK tgt 8 s11232 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i33 : PetersenLocalChildren.PairOK tgt 8 s11232 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i34 : PetersenLocalChildren.PairOK tgt 8 s11232 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair11232i35 : PetersenLocalChildren.PairOK tgt 8 s11232 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b11232 : Blocked tgt 9 s11232 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word31),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word31),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word31),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word31,word0),(word31,word6),(word31,word5),(word31,word2),(word31,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s11232 p
  exact
    PetersenLocalChildren.push thetaPair11232i0 <|
    PetersenLocalChildren.push thetaPair11232i1 <|
    PetersenLocalChildren.push thetaPair11232i2 <|
    PetersenLocalChildren.push thetaPair11232i3 <|
    PetersenLocalChildren.push thetaPair11232i4 <|
    PetersenLocalChildren.push thetaPair11232i5 <|
    PetersenLocalChildren.push thetaPair11232i6 <|
    PetersenLocalChildren.push thetaPair11232i7 <|
    PetersenLocalChildren.push thetaPair11232i8 <|
    PetersenLocalChildren.push thetaPair11232i9 <|
    PetersenLocalChildren.push thetaPair11232i10 <|
    PetersenLocalChildren.push thetaPair11232i11 <|
    PetersenLocalChildren.push thetaPair11232i12 <|
    PetersenLocalChildren.push thetaPair11232i13 <|
    PetersenLocalChildren.push thetaPair11232i14 <|
    PetersenLocalChildren.push thetaPair11232i15 <|
    PetersenLocalChildren.push thetaPair11232i16 <|
    PetersenLocalChildren.push thetaPair11232i17 <|
    PetersenLocalChildren.push thetaPair11232i18 <|
    PetersenLocalChildren.push thetaPair11232i19 <|
    PetersenLocalChildren.push thetaPair11232i20 <|
    PetersenLocalChildren.push thetaPair11232i21 <|
    PetersenLocalChildren.push thetaPair11232i22 <|
    PetersenLocalChildren.push thetaPair11232i23 <|
    PetersenLocalChildren.push thetaPair11232i24 <|
    PetersenLocalChildren.push thetaPair11232i25 <|
    PetersenLocalChildren.push thetaPair11232i26 <|
    PetersenLocalChildren.push thetaPair11232i27 <|
    PetersenLocalChildren.push thetaPair11232i28 <|
    PetersenLocalChildren.push thetaPair11232i29 <|
    PetersenLocalChildren.push thetaPair11232i30 <|
    PetersenLocalChildren.push thetaPair11232i31 <|
    PetersenLocalChildren.push thetaPair11232i32 <|
    PetersenLocalChildren.push thetaPair11232i33 <|
    PetersenLocalChildren.push thetaPair11232i34 <|
    PetersenLocalChildren.push thetaPair11232i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i0 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12951,s65,s12952]) (hints := [6581,0,6839,6581,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s12951,s65,s12952], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12951) (b12951) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s65) (b65) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12952) (b12952) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i1 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12953,s434,s1566,s12954]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12953,s434,s1566,s12954], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12953) (b12953) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s434) (b434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1566) (b1566) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12954) (b12954) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i2 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12951,s1806,s2753]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s12951,s1806,s2753], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12951) (b12951) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1806) (b1806) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2753) (b2753) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i3 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12955,s3354,s4239,s5126,s5757,s5846,s12956,s6439]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12955,s3354,s4239,s5126,s5757,s5846,s12956,s6439], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12955) (b12955) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3354) (b3354) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4239) (b4239) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5126) (b5126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5757) (b5757) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5846) (b5846) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12956) (b12956) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6439) (b6439) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i4 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12957,s6591,s7489,s12958]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12957,s6591,s7489,s12958], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12957) (b12957) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6591) (b6591) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7489) (b7489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12958) (b12958) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i5 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12951,s5,s927,s12959,s12960,s12961]) (hints := [1,0,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12951,s5,s927,s12959,s12960,s12961], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12951) (b12951) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12959) (b12959) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12960) (b12960) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12961) (b12961) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i6 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12962,s7613,s8383,s12963]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12962,s7613,s8383,s12963], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12962) (b12962) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7613) (b7613) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8383) (b8383) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12963) (b12963) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i7 : PetersenLocalChildren.PairOK tgt 8 s12950 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12964,s8608,s9457,s9982,s10467,s10607,s12965,s10901]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12964,s8608,s9457,s9982,s10467,s10607,s12965,s10901], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12964) (b12964) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8608) (b8608) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9457) (b9457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9982) (b9982) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10467) (b10467) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10607) (b10607) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12965) (b12965) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10901) (b10901) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i8 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11264,s12966]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11264,s12966], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11264) (b11264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12966) (b12966) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i9 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12952,s2753,s12263,s12010]) (hints := [5934,0,5934,6840,6840,1,7094,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12952,s2753,s12263,s12010], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12952) (b12952) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2753) (b2753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12263) (b12263) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12010) (b12010) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i10 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12712,s12967]) (hints := [7476,6838,7476,1671,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12712,s12967], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12712) (b12712) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12967) (b12967) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i11 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12968,s12969,s12970,s12971]) (hints := [4792,0,1,6840,6840,2,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12968,s12969,s12970,s12971], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12968) (b12968) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12969) (b12969) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12970) (b12970) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12971) (b12971) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i12 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s12971,s7113]) (hints := [6839,6839,0,4775,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s12971,s7113], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12971) (b12971) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7113) (b7113) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i13 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i14 : PetersenLocalChildren.PairOK tgt 8 s12950 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12972,s12976]) (hints := [13612,6838,13612,8839,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s12972,s12976], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12972) (b12972) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12976) (b12976) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i15 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i16 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i17 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12977,s12978]) (hints := [9675,9675,11467,6966,6966,0,11467,6966,11467,9675,9675,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s12977,s12978], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12977) (b12977) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12978) (b12978) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i18 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12979,s11296,s12980,s12981]) (hints := [4904,4904,0,9677,9677,1,9677,9677,2,4904,4904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12979,s11296,s12980,s12981], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12979) (b12979) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11296) (b11296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12980) (b12980) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12981) (b12981) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i19 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i20 : PetersenLocalChildren.PairOK tgt 8 s12950 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i21 : PetersenLocalChildren.PairOK tgt 8 s12950 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i22 : PetersenLocalChildren.PairOK tgt 8 s12950 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i23 : PetersenLocalChildren.PairOK tgt 8 s12950 (word0,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12982,s3211,s12195,s7127]) (hints := [5934,5934,0,6966,6966,1,6966,6966,2,5934,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12982,s3211,s12195,s7127], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12982) (b12982) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3211) (b3211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12195) (b12195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7127) (b7127) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i24 : PetersenLocalChildren.PairOK tgt 8 s12950 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i25 : PetersenLocalChildren.PairOK tgt 8 s12950 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i26 : PetersenLocalChildren.PairOK tgt 8 s12950 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i27 : PetersenLocalChildren.PairOK tgt 8 s12950 (word6,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12983,s12780,s12984,s12985]) (hints := [5672,5672,0,1673,1673,1,1673,1673,2,5672,5672,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12983,s12780,s12984,s12985], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12983) (b12983) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12780) (b12780) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12984) (b12984) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12985) (b12985) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i28 : PetersenLocalChildren.PairOK tgt 8 s12950 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i29 : PetersenLocalChildren.PairOK tgt 8 s12950 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i30 : PetersenLocalChildren.PairOK tgt 8 s12950 (word5,word8) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s12970,s12986]) (hints := [11468,11468,0,7469,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s12970,s12986], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12970) (b12970) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12986) (b12986) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i31 : PetersenLocalChildren.PairOK tgt 8 s12950 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12987,s12988]) (hints := [11467,11467,13515,14676,0,14676,13515,1,13515,11467,11467,14676]) (by decide +kernel) ?_
  change ∀ x ∈ [s12987,s12988], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12987) (b12987) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12988) (b12988) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i32 : PetersenLocalChildren.PairOK tgt 8 s12950 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12950i33 : PetersenLocalChildren.PairOK tgt 8 s12950 (word8,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12989,s12990,s12991,s12992]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12989,s12990,s12991,s12992], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12989) (b12989) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12990) (b12990) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12991) (b12991) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12992) (b12992) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i34 : PetersenLocalChildren.PairOK tgt 8 s12950 (word8,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12993,s12994,s12995,s12996]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s12993,s12994,s12995,s12996], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12993) (b12993) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12994) (b12994) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12995) (b12995) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12996) (b12996) <|
    PetersenLocalChildren.nil
private theorem thetaPair12950i35 : PetersenLocalChildren.PairOK tgt 8 s12950 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b12950 : Blocked tgt 9 s12950 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word8),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word8),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word8),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word8),(word0,word2),(word0,word4),(word6,word5),(word6,word8),(word6,word2),(word6,word4),(word5,word8),(word5,word2),(word5,word4),(word8,word2),(word8,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s12950 p
  exact
    PetersenLocalChildren.push thetaPair12950i0 <|
    PetersenLocalChildren.push thetaPair12950i1 <|
    PetersenLocalChildren.push thetaPair12950i2 <|
    PetersenLocalChildren.push thetaPair12950i3 <|
    PetersenLocalChildren.push thetaPair12950i4 <|
    PetersenLocalChildren.push thetaPair12950i5 <|
    PetersenLocalChildren.push thetaPair12950i6 <|
    PetersenLocalChildren.push thetaPair12950i7 <|
    PetersenLocalChildren.push thetaPair12950i8 <|
    PetersenLocalChildren.push thetaPair12950i9 <|
    PetersenLocalChildren.push thetaPair12950i10 <|
    PetersenLocalChildren.push thetaPair12950i11 <|
    PetersenLocalChildren.push thetaPair12950i12 <|
    PetersenLocalChildren.push thetaPair12950i13 <|
    PetersenLocalChildren.push thetaPair12950i14 <|
    PetersenLocalChildren.push thetaPair12950i15 <|
    PetersenLocalChildren.push thetaPair12950i16 <|
    PetersenLocalChildren.push thetaPair12950i17 <|
    PetersenLocalChildren.push thetaPair12950i18 <|
    PetersenLocalChildren.push thetaPair12950i19 <|
    PetersenLocalChildren.push thetaPair12950i20 <|
    PetersenLocalChildren.push thetaPair12950i21 <|
    PetersenLocalChildren.push thetaPair12950i22 <|
    PetersenLocalChildren.push thetaPair12950i23 <|
    PetersenLocalChildren.push thetaPair12950i24 <|
    PetersenLocalChildren.push thetaPair12950i25 <|
    PetersenLocalChildren.push thetaPair12950i26 <|
    PetersenLocalChildren.push thetaPair12950i27 <|
    PetersenLocalChildren.push thetaPair12950i28 <|
    PetersenLocalChildren.push thetaPair12950i29 <|
    PetersenLocalChildren.push thetaPair12950i30 <|
    PetersenLocalChildren.push thetaPair12950i31 <|
    PetersenLocalChildren.push thetaPair12950i32 <|
    PetersenLocalChildren.push thetaPair12950i33 <|
    PetersenLocalChildren.push thetaPair12950i34 <|
    PetersenLocalChildren.push thetaPair12950i35 <|
    PetersenLocalChildren.nil
theorem b13046 : Blocked tgt 9 s13046 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12295) (by decide +kernel)
  exact b12295
theorem b13418 : Blocked tgt 9 s13418 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12688) (by decide +kernel)
  exact b12688
private theorem thetaPair13652i0 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13653,s77,s273]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13653,s77,s273], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13653) (b13653) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s77) (b77) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s273) (b273) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i1 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13654,s461,s484,s1153,s1579,s13655,s13656,s13657]) (hints := [909,0,909,1,2,3,909,4,909,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13654,s461,s484,s1153,s1579,s13655,s13656,s13657], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13654) (b13654) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s461) (b461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s484) (b484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1153) (b1153) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1579) (b1579) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13655) (b13655) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13656) (b13656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13657) (b13657) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i2 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13653,s1915,s1916,s3177]) (hints := [5934,0,5934,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13653,s1915,s1916,s3177], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13653) (b13653) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1915) (b1915) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1916) (b1916) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3177) (b3177) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i3 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word38) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13654,s1579,s13658,s13659,s568,s13660,s1160,s458,s1152,s13661,s13662,s13663]) (hints := [2,0,3,4,5,6,7,1,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s13654,s1579,s13658,s13659,s568,s13660,s1160,s458,s1152,s13661,s13662,s13663], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13654) (b13654) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1579) (b1579) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13658) (b13658) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13659) (b13659) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s568) (b568) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13660) (b13660) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1160) (b1160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s458) (b458) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1152) (b1152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13661) (b13661) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13662) (b13662) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13663) (b13663) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i4 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13664,s3471,s4272,s5172,s5769,s5907,s13665,s6482]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13664,s3471,s4272,s5172,s5769,s5907,s13665,s6482], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13664) (b13664) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3471) (b3471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4272) (b4272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5172) (b5172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5769) (b5769) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5907) (b5907) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13665) (b13665) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6482) (b6482) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i5 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13666,s6627,s7501,s13667]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s13666,s6627,s7501,s13667], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13666) (b13666) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6627) (b6627) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7501) (b7501) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13667) (b13667) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i6 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13668,s7640,s8397,s13669]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s13668,s7640,s8397,s13669], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13668) (b13668) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7640) (b7640) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8397) (b8397) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13669) (b13669) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i7 : PetersenLocalChildren.PairOK tgt 8 s13652 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13670,s8706,s9481,s10017,s10479,s10615,s13671,s10909]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13670,s8706,s9481,s10017,s10479,s10615,s13671,s10909], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13670) (b13670) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8706) (b8706) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9481) (b9481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10017) (b10017) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10479) (b10479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10615) (b10615) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13671) (b13671) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10909) (b10909) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i8 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11016,s11412]) (hints := [6838,6838,6966,775,0,903,6966,1,6966,6838,6838,903]) (by decide +kernel) ?_
  change ∀ x ∈ [s11016,s11412], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11016) (b11016) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11412) (b11412) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i9 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s273,s3177,s11742,s12275]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s273,s3177,s11742,s12275], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s273) (b273) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3177) (b3177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11742) (b11742) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12275) (b12275) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i10 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word38) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1160,s1152,s13672,s13673,s13674,s13675,s13688,s13689]) (hints := [2,3,4,6844,6844,0,6844,6844,1,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s1160,s1152,s13672,s13673,s13674,s13675,s13688,s13689], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1160) (b1160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1152) (b1152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13672) (b13672) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13673) (b13673) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13674) (b13674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13675) (b13675) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13688) (b13688) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13689) (b13689) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i11 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12336,s12887]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12336,s12887], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12336) (b12336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12887) (b12887) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i12 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i13 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i14 : PetersenLocalChildren.PairOK tgt 8 s13652 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13087,s13589]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13087,s13589], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13087) (b13087) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13589) (b13589) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i15 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13690,s13691,s13692,s13693]) (hints := [5678,0,1,905,905,2,5934,3,5934]) (by decide +kernel) ?_
  change ∀ x ∈ [s13690,s13691,s13692,s13693], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13690) (b13690) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13691) (b13691) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13692) (b13692) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13693) (b13693) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i16 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word38) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13693,s927,s1162]) (hints := [9676,904,1,9676,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13693,s927,s1162], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13693) (b13693) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1162) (b1162) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i17 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13694,s13702]) (hints := [903,903,1671,7476,0,7476,1671,1,1671,903,903,7476]) (by decide +kernel) ?_
  change ∀ x ∈ [s13694,s13702], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13694) (b13694) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13702) (b13702) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i18 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,901,11465,4916,6964,7466,11465,6964,11465,901,901,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i19 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,901,13513,2868,6964,13642,13513,6964,13513,901,901,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i20 : PetersenLocalChildren.PairOK tgt 8 s13652 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13703,s13711]) (hints := [903,903,8839,13612,0,13612,8839,1,8839,903,903,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s13703,s13711], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13703) (b13703) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13711) (b13711) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i21 : PetersenLocalChildren.PairOK tgt 8 s13652 (word0,word38) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13692,s927,s13712]) (hints := [5933,5933,1,5675,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13692,s927,s13712], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13692) (b13692) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13712) (b13712) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i22 : PetersenLocalChildren.PairOK tgt 8 s13652 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i23 : PetersenLocalChildren.PairOK tgt 8 s13652 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i24 : PetersenLocalChildren.PairOK tgt 8 s13652 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i25 : PetersenLocalChildren.PairOK tgt 8 s13652 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i26 : PetersenLocalChildren.PairOK tgt 8 s13652 (word38,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13713,s13714,s13720,s13731]) (hints := [7220,0,7220,1673,1,1673,7220,2,7220,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s13713,s13714,s13720,s13731], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13713) (b13713) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13714) (b13714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13720) (b13720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13731) (b13731) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i27 : PetersenLocalChildren.PairOK tgt 8 s13652 (word38,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13732,s13733,s13734,s13735]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s13732,s13733,s13734,s13735], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13732) (b13732) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13733) (b13733) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13734) (b13734) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13735) (b13735) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i28 : PetersenLocalChildren.PairOK tgt 8 s13652 (word38,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13736,s13737,s13738,s13739]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s13736,s13737,s13738,s13739], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13736) (b13736) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13737) (b13737) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13738) (b13738) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13739) (b13739) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i29 : PetersenLocalChildren.PairOK tgt 8 s13652 (word38,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13740,s13741,s13747,s13758]) (hints := [13356,0,13356,8841,1,8841,13356,2,13356,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s13740,s13741,s13747,s13758], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13740) (b13740) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13741) (b13741) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13747) (b13747) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13758) (b13758) <|
    PetersenLocalChildren.nil
private theorem thetaPair13652i30 : PetersenLocalChildren.PairOK tgt 8 s13652 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i31 : PetersenLocalChildren.PairOK tgt 8 s13652 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i32 : PetersenLocalChildren.PairOK tgt 8 s13652 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i33 : PetersenLocalChildren.PairOK tgt 8 s13652 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i34 : PetersenLocalChildren.PairOK tgt 8 s13652 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13652i35 : PetersenLocalChildren.PairOK tgt 8 s13652 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b13652 : Blocked tgt 9 s13652 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word38),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word38),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word38),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word38),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word38,word6),(word38,word5),(word38,word2),(word38,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s13652 p
  exact
    PetersenLocalChildren.push thetaPair13652i0 <|
    PetersenLocalChildren.push thetaPair13652i1 <|
    PetersenLocalChildren.push thetaPair13652i2 <|
    PetersenLocalChildren.push thetaPair13652i3 <|
    PetersenLocalChildren.push thetaPair13652i4 <|
    PetersenLocalChildren.push thetaPair13652i5 <|
    PetersenLocalChildren.push thetaPair13652i6 <|
    PetersenLocalChildren.push thetaPair13652i7 <|
    PetersenLocalChildren.push thetaPair13652i8 <|
    PetersenLocalChildren.push thetaPair13652i9 <|
    PetersenLocalChildren.push thetaPair13652i10 <|
    PetersenLocalChildren.push thetaPair13652i11 <|
    PetersenLocalChildren.push thetaPair13652i12 <|
    PetersenLocalChildren.push thetaPair13652i13 <|
    PetersenLocalChildren.push thetaPair13652i14 <|
    PetersenLocalChildren.push thetaPair13652i15 <|
    PetersenLocalChildren.push thetaPair13652i16 <|
    PetersenLocalChildren.push thetaPair13652i17 <|
    PetersenLocalChildren.push thetaPair13652i18 <|
    PetersenLocalChildren.push thetaPair13652i19 <|
    PetersenLocalChildren.push thetaPair13652i20 <|
    PetersenLocalChildren.push thetaPair13652i21 <|
    PetersenLocalChildren.push thetaPair13652i22 <|
    PetersenLocalChildren.push thetaPair13652i23 <|
    PetersenLocalChildren.push thetaPair13652i24 <|
    PetersenLocalChildren.push thetaPair13652i25 <|
    PetersenLocalChildren.push thetaPair13652i26 <|
    PetersenLocalChildren.push thetaPair13652i27 <|
    PetersenLocalChildren.push thetaPair13652i28 <|
    PetersenLocalChildren.push thetaPair13652i29 <|
    PetersenLocalChildren.push thetaPair13652i30 <|
    PetersenLocalChildren.push thetaPair13652i31 <|
    PetersenLocalChildren.push thetaPair13652i32 <|
    PetersenLocalChildren.push thetaPair13652i33 <|
    PetersenLocalChildren.push thetaPair13652i34 <|
    PetersenLocalChildren.push thetaPair13652i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i0 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word34) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s13761,s927,s13762,s13763,s13764]) (hints := [0,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s13761,s927,s13762,s13763,s13764], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13761) (b13761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13762) (b13762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13763) (b13763) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13764) (b13764) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i1 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13761,s79,s275]) (hints := [6839,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13761,s79,s275], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13761) (b13761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s79) (b79) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s275) (b275) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i2 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13765,s13766,s13767,s487,s1581,s1582,s13768,s13769]) (hints := [0,1,2,9681,3,9681,4,5,6,9681,7,9681]) (by decide +kernel) ?_
  change ∀ x ∈ [s13765,s13766,s13767,s487,s1581,s1582,s13768,s13769], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13765) (b13765) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13766) (b13766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13767) (b13767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s487) (b487) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1581) (b1581) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1582) (b1582) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13768) (b13768) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13769) (b13769) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i3 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13761,s1918,s1919,s3179]) (hints := [5934,0,5934,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13761,s1918,s1919,s3179], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13761) (b13761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1918) (b1918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1919) (b1919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3179) (b3179) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i4 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13770,s3501,s4284,s5174,s5771,s5909,s13771,s6484]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13770,s3501,s4284,s5174,s5771,s5909,s13771,s6484], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13770) (b13770) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3501) (b3501) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4284) (b4284) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5174) (b5174) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5771) (b5771) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5909) (b5909) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13771) (b13771) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6484) (b6484) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i5 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13772,s6634,s7503,s13773]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s13772,s6634,s7503,s13773], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13772) (b13772) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6634) (b6634) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7503) (b7503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13773) (b13773) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i6 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13774,s7647,s8399,s13775]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s13774,s7647,s8399,s13775], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13774) (b13774) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7647) (b7647) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8399) (b8399) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13775) (b13775) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i7 : PetersenLocalChildren.PairOK tgt 8 s13760 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13776,s8736,s9493,s10019,s10481,s10617,s13777,s10911]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13776,s8736,s9493,s10019,s10481,s10617,s13777,s10911], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13776) (b13776) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8736) (b8736) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9493) (b9493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10019) (b10019) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10481) (b10481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10617) (b10617) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13777) (b13777) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10911) (b10911) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i8 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s197,s1134,s13778,s13779,s11093,s11286,s13780,s1130]) (hints := [0,1,2,6844,3,6844,4,5,6,6844,7,6844]) (by decide +kernel) ?_
  change ∀ x ∈ [s197,s1134,s13778,s13779,s11093,s11286,s13780,s1130], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s197) (b197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1134) (b1134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13778) (b13778) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13779) (b13779) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11093) (b11093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11286) (b11286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13780) (b13780) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1130) (b1130) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i9 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s13781,s13693]) (hints := [9676,0,9676,904,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s13781,s13693], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13781) (b13781) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13693) (b13693) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i10 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s1159,s13782]) (hints := [5933,0,5933,5675,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s1159,s13782], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1159) (b1159) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13782) (b13782) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i11 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13783,s13784,s13795,s13796]) (hints := [7478,0,7478,1673,1,1673,7478,2,7478,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s13783,s13784,s13795,s13796], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13783) (b13783) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13784) (b13784) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13795) (b13795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13796) (b13796) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i12 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13797,s13798,s13799,s13800]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s13797,s13798,s13799,s13800], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13797) (b13797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13798) (b13798) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13799) (b13799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13800) (b13800) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i13 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13801,s13802,s13803,s13804]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s13801,s13802,s13803,s13804], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13801) (b13801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13802) (b13802) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13803) (b13803) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13804) (b13804) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i14 : PetersenLocalChildren.PairOK tgt 8 s13760 (word34,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13805,s13806,s13817,s13818]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s13805,s13806,s13817,s13818], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13805) (b13805) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13806) (b13806) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13817) (b13817) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13818) (b13818) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i15 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13819,s11018,s11414,s11415,s13820]) (hints := [6841,6841,0,9678,1,9678,2,3,4,9678,6841,9678]) (by decide +kernel) ?_
  change ∀ x ∈ [s13819,s11018,s11414,s11415,s13820], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13819) (b13819) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11018) (b11018) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11414) (b11414) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11415) (b11415) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13820) (b13820) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i16 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s275,s3179,s11744,s12277]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s275,s3179,s11744,s12277], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s275) (b275) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3179) (b3179) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11744) (b11744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12277) (b12277) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i17 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12344,s12889]) (hints := [6838,6838,7734,1543,0,1671,7734,1,7734,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12344,s12889], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12344) (b12344) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12889) (b12889) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i18 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4772,4772,7466,11465,6836,11465,6820,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i19 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [2708,2708,13642,13513,6836,13513,6804,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i20 : PetersenLocalChildren.PairOK tgt 8 s13760 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13095,s13591]) (hints := [6838,6838,14902,8711,0,8839,14902,1,14902,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13095,s13591], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13095) (b13095) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13591) (b13591) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i21 : PetersenLocalChildren.PairOK tgt 8 s13760 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13693,s13782,s13821,s13822]) (hints := [9677,9677,1,5934,0,5934,5932,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13693,s13782,s13821,s13822], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13693) (b13693) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13782) (b13782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13821) (b13821) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13822) (b13822) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i22 : PetersenLocalChildren.PairOK tgt 8 s13760 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i23 : PetersenLocalChildren.PairOK tgt 8 s13760 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13823,s13831]) (hints := [9675,9675,11467,7212,0,7468,11467,1,11467,9675,9675,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s13823,s13831], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13823) (b13823) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13831) (b13831) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i24 : PetersenLocalChildren.PairOK tgt 8 s13760 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13832,s13840]) (hints := [9675,9675,13515,13388,0,13644,13515,1,13515,9675,9675,13644]) (by decide +kernel) ?_
  change ∀ x ∈ [s13832,s13840], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13832) (b13832) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13840) (b13840) <|
    PetersenLocalChildren.nil
private theorem thetaPair13760i25 : PetersenLocalChildren.PairOK tgt 8 s13760 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i26 : PetersenLocalChildren.PairOK tgt 8 s13760 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i27 : PetersenLocalChildren.PairOK tgt 8 s13760 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i28 : PetersenLocalChildren.PairOK tgt 8 s13760 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i29 : PetersenLocalChildren.PairOK tgt 8 s13760 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i30 : PetersenLocalChildren.PairOK tgt 8 s13760 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7732,11465,10433,7732,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i31 : PetersenLocalChildren.PairOK tgt 8 s13760 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7732,13513,12481,7732,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i32 : PetersenLocalChildren.PairOK tgt 8 s13760 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i33 : PetersenLocalChildren.PairOK tgt 8 s13760 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i34 : PetersenLocalChildren.PairOK tgt 8 s13760 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14900,11401,11465,8837,3209,3209,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13760i35 : PetersenLocalChildren.PairOK tgt 8 s13760 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,14900,13449,13513,8837,5257,5257,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b13760 : Blocked tgt 9 s13760 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word34),(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word34,word3),(word34,word1),(word34,word0),(word34,word6),(word34,word5),(word34,word2),(word34,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s13760 p
  exact
    PetersenLocalChildren.push thetaPair13760i0 <|
    PetersenLocalChildren.push thetaPair13760i1 <|
    PetersenLocalChildren.push thetaPair13760i2 <|
    PetersenLocalChildren.push thetaPair13760i3 <|
    PetersenLocalChildren.push thetaPair13760i4 <|
    PetersenLocalChildren.push thetaPair13760i5 <|
    PetersenLocalChildren.push thetaPair13760i6 <|
    PetersenLocalChildren.push thetaPair13760i7 <|
    PetersenLocalChildren.push thetaPair13760i8 <|
    PetersenLocalChildren.push thetaPair13760i9 <|
    PetersenLocalChildren.push thetaPair13760i10 <|
    PetersenLocalChildren.push thetaPair13760i11 <|
    PetersenLocalChildren.push thetaPair13760i12 <|
    PetersenLocalChildren.push thetaPair13760i13 <|
    PetersenLocalChildren.push thetaPair13760i14 <|
    PetersenLocalChildren.push thetaPair13760i15 <|
    PetersenLocalChildren.push thetaPair13760i16 <|
    PetersenLocalChildren.push thetaPair13760i17 <|
    PetersenLocalChildren.push thetaPair13760i18 <|
    PetersenLocalChildren.push thetaPair13760i19 <|
    PetersenLocalChildren.push thetaPair13760i20 <|
    PetersenLocalChildren.push thetaPair13760i21 <|
    PetersenLocalChildren.push thetaPair13760i22 <|
    PetersenLocalChildren.push thetaPair13760i23 <|
    PetersenLocalChildren.push thetaPair13760i24 <|
    PetersenLocalChildren.push thetaPair13760i25 <|
    PetersenLocalChildren.push thetaPair13760i26 <|
    PetersenLocalChildren.push thetaPair13760i27 <|
    PetersenLocalChildren.push thetaPair13760i28 <|
    PetersenLocalChildren.push thetaPair13760i29 <|
    PetersenLocalChildren.push thetaPair13760i30 <|
    PetersenLocalChildren.push thetaPair13760i31 <|
    PetersenLocalChildren.push thetaPair13760i32 <|
    PetersenLocalChildren.push thetaPair13760i33 <|
    PetersenLocalChildren.push thetaPair13760i34 <|
    PetersenLocalChildren.push thetaPair13760i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i0 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13843,s81,s277]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13843,s81,s277], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13843) (b13843) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s81) (b81) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s277) (b277) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i1 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13844,s13845,s13846,s489,s1584,s1615,s13847,s13848]) (hints := [0,1,2,9681,3,9681,4,5,6,9681,7,9681]) (by decide +kernel) ?_
  change ∀ x ∈ [s13844,s13845,s13846,s489,s1584,s1615,s13847,s13848], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13844) (b13844) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13845) (b13845) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13846) (b13846) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s489) (b489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1584) (b1584) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1615) (b1615) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13847) (b13847) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13848) (b13848) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i2 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13843,s2066,s2828]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13843,s2066,s2828], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13843) (b13843) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2066) (b2066) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2828) (b2828) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i3 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13849,s4287,s4326,s5425,s5773,s13850,s13851,s13852]) (hints := [7482,0,7482,1,2,3,7482,4,7482,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13849,s4287,s4326,s5425,s5773,s13850,s13851,s13852], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13849) (b13849) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4287) (b4287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4326) (b4326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5425) (b5425) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5773) (b5773) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13850) (b13850) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13851) (b13851) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13852) (b13852) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i4 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word29) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13853,s13854,s13855,s578,s13856,s1164,s1326,s13857,s13858,s13859,s13904,s13905]) (hints := [0,1,2,3,4,5,6,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s13853,s13854,s13855,s578,s13856,s1164,s1326,s13857,s13858,s13859,s13904,s13905], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13853) (b13853) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13854) (b13854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13855) (b13855) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s578) (b578) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13856) (b13856) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1164) (b1164) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1326) (b1326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13857) (b13857) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13858) (b13858) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13859) (b13859) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13904) (b13904) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13905) (b13905) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i5 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13909,s6636,s7505,s13910]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s13909,s6636,s7505,s13910], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13909) (b13909) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6636) (b6636) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7505) (b7505) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13910) (b13910) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i6 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13911,s7649,s8401,s13912]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s13911,s7649,s8401,s13912], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13911) (b13911) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7649) (b7649) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8401) (b8401) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13912) (b13912) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i7 : PetersenLocalChildren.PairOK tgt 8 s13842 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13913,s8768,s9495,s10021,s10483,s10625,s13914,s10919]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13913,s8768,s9495,s10021,s10483,s10625,s13914,s10919], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13913) (b13913) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8768) (b8768) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9495) (b9495) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10021) (b10021) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10483) (b10483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10625) (b10625) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13914) (b13914) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10919) (b10919) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i8 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13915,s11020,s11417,s11441,s13916]) (hints := [6841,6841,0,9678,1,9678,2,3,4,9678,6841,9678]) (by decide +kernel) ?_
  change ∀ x ∈ [s13915,s11020,s11417,s11441,s13916], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13915) (b13915) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11020) (b11020) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11417) (b11417) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11441) (b11441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13916) (b13916) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i9 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s277,s2828,s11746,s12022]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s277,s2828,s11746,s12022], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s277) (b277) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2828) (b2828) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11746) (b11746) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12022) (b12022) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i10 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12346,s12396,s12739,s12891,s13917]) (hints := [7479,6841,7479,0,1,2,7479,3,7479,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s12346,s12396,s12739,s12891,s13917], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12346) (b12346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12396) (b12396) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12739) (b12739) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12891) (b12891) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13917) (b13917) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i11 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word29) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13918,s11096,s13919,s11288,s11369,s13920,s13921,s13922]) (hints := [6844,6844,0,1,2,3,4,5,6,6844,6844,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s13918,s11096,s13919,s11288,s11369,s13920,s13921,s13922], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13918) (b13918) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11096) (b11096) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13919) (b13919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11288) (b11288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11369) (b11369) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13920) (b13920) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13921) (b13921) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13922) (b13922) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i12 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i13 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i14 : PetersenLocalChildren.PairOK tgt 8 s13842 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13097,s13593]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13097,s13593], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13097) (b13097) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13593) (b13593) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i15 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13694,s13926]) (hints := [9675,9675,5674,5676,0,5932,5674,1,5674,9675,9675,5932]) (by decide +kernel) ?_
  change ∀ x ∈ [s13694,s13926], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13694) (b13694) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13926) (b13926) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i16 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13927,s13928,s13929,s13930]) (hints := [8653,0,1,9677,9677,2,7478,3,7478]) (by decide +kernel) ?_
  change ∀ x ∈ [s13927,s13928,s13929,s13930], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13927) (b13927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13928) (b13928) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13929) (b13929) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13930) (b13930) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i17 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word29) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13930,s927,s13931]) (hints := [9676,9676,1,8644,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13930,s927,s13931], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13930) (b13930) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13931) (b13931) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i18 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13932,s13933]) (hints := [9675,9675,11467,7212,0,7468,11467,1,11467,9675,9675,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s13932,s13933], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13932) (b13932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13933) (b13933) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i19 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13934,s13939]) (hints := [9675,9675,13515,13388,0,13644,13515,1,13515,9675,9675,13644]) (by decide +kernel) ?_
  change ∀ x ∈ [s13934,s13939], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13934) (b13934) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13939) (b13939) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i20 : PetersenLocalChildren.PairOK tgt 8 s13842 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i21 : PetersenLocalChildren.PairOK tgt 8 s13842 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13940,s13945]) (hints := [6964,6964,7476,4908,5932,0,7476,5932,7476,6964,6964,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s13940,s13945], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13940) (b13940) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13945) (b13945) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i22 : PetersenLocalChildren.PairOK tgt 8 s13842 (word0,word29) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13946,s13714,s13795,s13947]) (hints := [10836,10836,0,5934,5934,1,5934,5934,2,10836,10836,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13946,s13714,s13795,s13947], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13946) (b13946) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13714) (b13714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13795) (b13795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13947) (b13947) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i23 : PetersenLocalChildren.PairOK tgt 8 s13842 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i24 : PetersenLocalChildren.PairOK tgt 8 s13842 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i25 : PetersenLocalChildren.PairOK tgt 8 s13842 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i26 : PetersenLocalChildren.PairOK tgt 8 s13842 (word6,word29) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13929,s927,s13951]) (hints := [1672,7477,1,1672,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s13929,s927,s13951], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13929) (b13929) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13951) (b13951) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i27 : PetersenLocalChildren.PairOK tgt 8 s13842 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13952,s13953]) (hints := [10435,0,10435,11467,7476,11467,10435,7476,10435,11467,1,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s13952,s13953], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13952) (b13952) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13953) (b13953) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i28 : PetersenLocalChildren.PairOK tgt 8 s13842 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,11602,12481,13513,7474,13513,12481,7474,12481,13513,11602,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i29 : PetersenLocalChildren.PairOK tgt 8 s13842 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8837,7474,8837,3410,11602,13610,8837,11602,8837,7474,7474,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i30 : PetersenLocalChildren.PairOK tgt 8 s13842 (word29,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13954,s13955,s13956,s13957]) (hints := [10437,0,10437,11469,1,11469,10437,2,10437,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s13954,s13955,s13956,s13957], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13954) (b13954) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13955) (b13955) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13956) (b13956) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13957) (b13957) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i31 : PetersenLocalChildren.PairOK tgt 8 s13842 (word29,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13958,s13959,s13960,s13961]) (hints := [12485,0,12485,13517,1,13517,12485,2,12485,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s13958,s13959,s13960,s13961], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13958) (b13958) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13959) (b13959) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13960) (b13960) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13961) (b13961) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i32 : PetersenLocalChildren.PairOK tgt 8 s13842 (word29,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13962,s13963,s13978,s13987]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s13962,s13963,s13978,s13987], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13962) (b13962) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13963) (b13963) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13978) (b13978) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13987) (b13987) <|
    PetersenLocalChildren.nil
private theorem thetaPair13842i33 : PetersenLocalChildren.PairOK tgt 8 s13842 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i34 : PetersenLocalChildren.PairOK tgt 8 s13842 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair13842i35 : PetersenLocalChildren.PairOK tgt 8 s13842 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b13842 : Blocked tgt 9 s13842 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word29),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word29),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word29),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word29),(word0,word5),(word0,word2),(word0,word4),(word6,word29),(word6,word5),(word6,word2),(word6,word4),(word29,word5),(word29,word2),(word29,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s13842 p
  exact
    PetersenLocalChildren.push thetaPair13842i0 <|
    PetersenLocalChildren.push thetaPair13842i1 <|
    PetersenLocalChildren.push thetaPair13842i2 <|
    PetersenLocalChildren.push thetaPair13842i3 <|
    PetersenLocalChildren.push thetaPair13842i4 <|
    PetersenLocalChildren.push thetaPair13842i5 <|
    PetersenLocalChildren.push thetaPair13842i6 <|
    PetersenLocalChildren.push thetaPair13842i7 <|
    PetersenLocalChildren.push thetaPair13842i8 <|
    PetersenLocalChildren.push thetaPair13842i9 <|
    PetersenLocalChildren.push thetaPair13842i10 <|
    PetersenLocalChildren.push thetaPair13842i11 <|
    PetersenLocalChildren.push thetaPair13842i12 <|
    PetersenLocalChildren.push thetaPair13842i13 <|
    PetersenLocalChildren.push thetaPair13842i14 <|
    PetersenLocalChildren.push thetaPair13842i15 <|
    PetersenLocalChildren.push thetaPair13842i16 <|
    PetersenLocalChildren.push thetaPair13842i17 <|
    PetersenLocalChildren.push thetaPair13842i18 <|
    PetersenLocalChildren.push thetaPair13842i19 <|
    PetersenLocalChildren.push thetaPair13842i20 <|
    PetersenLocalChildren.push thetaPair13842i21 <|
    PetersenLocalChildren.push thetaPair13842i22 <|
    PetersenLocalChildren.push thetaPair13842i23 <|
    PetersenLocalChildren.push thetaPair13842i24 <|
    PetersenLocalChildren.push thetaPair13842i25 <|
    PetersenLocalChildren.push thetaPair13842i26 <|
    PetersenLocalChildren.push thetaPair13842i27 <|
    PetersenLocalChildren.push thetaPair13842i28 <|
    PetersenLocalChildren.push thetaPair13842i29 <|
    PetersenLocalChildren.push thetaPair13842i30 <|
    PetersenLocalChildren.push thetaPair13842i31 <|
    PetersenLocalChildren.push thetaPair13842i32 <|
    PetersenLocalChildren.push thetaPair13842i33 <|
    PetersenLocalChildren.push thetaPair13842i34 <|
    PetersenLocalChildren.push thetaPair13842i35 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
