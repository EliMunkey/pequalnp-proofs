import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv754_4260 : PetersenPackedPin.project r754 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv754_4814 : PetersenPackedPin.project r754 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv754_5473 : PetersenPackedPin.project r754 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv754_6170 : PetersenPackedPin.project r754 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv754_6790 : PetersenPackedPin.project r754 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv754_7474 : PetersenPackedPin.project r754 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv754_8012 : PetersenPackedPin.project r754 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv754_2708 : PetersenPackedPin.project r754 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 1 pv754_4260 pv754_5473 rfl rfl
theorem pv754_7688 : PetersenPackedPin.project r754 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv754_4260 pv754_7474 rfl rfl
theorem pv754_7588 : PetersenPackedPin.project r754 (0xffffffff0a0a0a0affffffff0a0a0a0a : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv754_2708 pv754_7474 rfl rfl
end PetersenSmallStarts.M191.Residual
