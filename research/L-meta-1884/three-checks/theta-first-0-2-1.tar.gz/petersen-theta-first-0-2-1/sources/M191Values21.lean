import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv21_4260 : PetersenPackedPin.project r21 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv21_4814 : PetersenPackedPin.project r21 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv21_5473 : PetersenPackedPin.project r21 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv21_6170 : PetersenPackedPin.project r21 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv21_6790 : PetersenPackedPin.project r21 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv21_7474 : PetersenPackedPin.project r21 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv21_8012 : PetersenPackedPin.project r21 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv21_391 : PetersenPackedPin.project r21 (0xcccccccccccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_4814 pv21_8012 rfl rfl
theorem pv21_1117 : PetersenPackedPin.project r21 (0xcccccccc00000000cccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_4814 pv21_7474 rfl rfl
theorem pv21_1177 : PetersenPackedPin.project r21 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_5473 pv21_7474 rfl rfl
theorem pv21_1734 : PetersenPackedPin.project r21 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x2222 := PetersenWireProjection.derive 1 pv21_4260 pv21_6790 rfl rfl
theorem pv21_1779 : PetersenPackedPin.project r21 (0xcccc0000cccc0000cccc0000cccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_4814 pv21_6790 rfl rfl
theorem pv21_1829 : PetersenPackedPin.project r21 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_5473 pv21_6790 rfl rfl
theorem pv21_2192 : PetersenPackedPin.project r21 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv21_4260 pv21_6170 rfl rfl
theorem pv21_2240 : PetersenPackedPin.project r21 (0xcc00cc00cc00cc00cc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_4814 pv21_6170 rfl rfl
theorem pv21_2708 : PetersenPackedPin.project r21 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv21_4260 pv21_5473 rfl rfl
theorem pv21_3209 : PetersenPackedPin.project r21 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4814 pv21_5473 rfl rfl
theorem pv21_3582 : PetersenPackedPin.project r21 (0x44444444444444444444444444444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4260 pv21_4814 rfl rfl
theorem pv21_3632 : PetersenPackedPin.project r21 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4260 pv21_5473 rfl rfl
theorem pv21_3677 : PetersenPackedPin.project r21 (0x55005500550055005500550055005500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4260 pv21_6170 rfl rfl
theorem pv21_3980 : PetersenPackedPin.project r21 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv21_4260 pv21_5473 rfl rfl
theorem pv21_4675 : PetersenPackedPin.project r21 (0xcccccccc00000000cccccccc00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv21_4814 pv21_7474 rfl rfl
theorem pv21_4753 : PetersenPackedPin.project r21 (0xcccccccccccccccc0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv21_4814 pv21_8012 rfl rfl
theorem pv21_5850 : PetersenPackedPin.project r21 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv21_4260 pv21_5473 rfl rfl
theorem pv21_5920 : PetersenPackedPin.project r21 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv21_4814 pv21_5473 rfl rfl
theorem pv21_6504 : PetersenPackedPin.project r21 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv21_4260 pv21_6170 rfl rfl
theorem pv21_6546 : PetersenPackedPin.project r21 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv21_4814 pv21_6170 rfl rfl
theorem pv21_6618 : PetersenPackedPin.project r21 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv21_5473 pv21_6170 rfl rfl
theorem pv21_1164 : PetersenPackedPin.project r21 (0xf050f05000000000f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_1177 pv21_2192 rfl rfl
theorem pv21_1168 : PetersenPackedPin.project r21 (0xf0f0505000000000f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_1177 pv21_1734 rfl rfl
theorem pv21_1817 : PetersenPackedPin.project r21 (0xf0500000f0500000f0500000f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv21_1829 pv21_2192 rfl rfl
theorem pv21_3180 : PetersenPackedPin.project r21 (0x30103010301030103010301030103010 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2192 pv21_3209 rfl rfl
theorem pv21_3666 : PetersenPackedPin.project r21 (0x54545454545454545454545454545454 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4260 pv21_5920 rfl rfl
theorem pv21_3690 : PetersenPackedPin.project r21 (0x55505550555055505550555055505550 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_4260 pv21_6618 rfl rfl
theorem pv21_3822 : PetersenPackedPin.project r21 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv21_3980 pv21_5850 rfl rfl
theorem pv21_5281 : PetersenPackedPin.project r21 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2192 pv21_5473 rfl rfl
theorem pv21_5328 : PetersenPackedPin.project r21 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_1734 pv21_5473 rfl rfl
theorem pv21_5682 : PetersenPackedPin.project r21 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2708 pv21_6170 rfl rfl
theorem pv21_5696 : PetersenPackedPin.project r21 (0xf5a0f5a0f5a0f5a0f5a0f5a0f5a0f5a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2708 pv21_6504 rfl rfl
theorem pv21_5700 : PetersenPackedPin.project r21 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2708 pv21_6546 rfl rfl
theorem pv21_5779 : PetersenPackedPin.project r21 (0xfa50fa50fa50fa50fa50fa50fa50fa50 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2192 pv21_5850 rfl rfl
theorem pv21_5870 : PetersenPackedPin.project r21 (0xfc54fc54fc54fc54fc54fc54fc54fc54 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv21_2192 pv21_5920 rfl rfl
theorem pv21_6308 : PetersenPackedPin.project r21 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv21_2708 pv21_6170 rfl rfl
theorem pv21_5876 : PetersenPackedPin.project r21 (0xfcdcfcdcfcdcfcdcfcdcfcdcfcdcfcdc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv21_3180 pv21_4814 rfl rfl
theorem pv21_7213 : PetersenPackedPin.project r21 (0xfffff050fffff050fffff050fffff050 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv21_1817 pv21_6790 rfl rfl
theorem pv21_7752 : PetersenPackedPin.project r21 (0xfffffffff050f050fffffffff050f050 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv21_1164 pv21_7474 rfl rfl
theorem pv21_7756 : PetersenPackedPin.project r21 (0xfffffffff0f05050fffffffff0f05050 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv21_1168 pv21_7474 rfl rfl
end PetersenSmallStarts.M191.Residual
