import Petersen191Symmetry
import M191StartPreferredSignals
import M191ResidualC7A0G4
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G29
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G31
import M191StagedF0X2Z1G35
import M191StagedF0X2Z1G36
import M191StagedF0X2Z1G37
import M191StagedF0X2Z1G39
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G78
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G85
import M191StagedF0X2Z1G86
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows16
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows45
import M191StartPreferredRows48
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows53
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows59
import M191StartPreferredRows6
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows7
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b784 : Blocked tgt 8 s784 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s578) (by decide +kernel)
  exact b578
theorem b2761 : Blocked tgt 8 s2761 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s2716) (by decide +kernel)
  exact b2716
theorem b2874 : Blocked tgt 8 s2874 := by
  apply PetersenFastNode.node (nxt := #[s2875,s2876,s2877,s2740,s2780,s2746,s2881]) (hints := [9808,9808,9936,9680,396,9680,9936,0,8904,9928,8912,8904,9936,11472,2188,9936,9936,13520,4236,9936,1680,9872,1744,1680,1,9936,9936,2,6843,9680,6971,9680,5937,6065,11609,3,11609,6843,7473,11472,7473,11472,13649,13520,13649,13520,13617,4,13617,6843,6843,5,6,6843,5679,9680,9680,5935,8648,8656,9672,8648,9680,4923,11472,9680,9680,2875,13520,9680,1424,1488,9616,1424,392,9680,9680,392,6969,5937,11609,6969,5937,11472,7473,11472,10065,13520,13649,13520,5937,1873,13617,5937,6969,5937,5937,6969,10440,10448,10440,11464,12488,12496,12488,13512,3417,11609,13617,1676,1676,11472,3377,13520,11472,3216,3280,11408,3216,2184,11472,11472,2184,5264,5328,13456,5264,4232,13520,13520,4232,8844,8844]) (by decide +kernel)
  change ∀ b ∈ [s2875,s2876,s2877,s2740,s2780,s2746,s2881], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2875) b2875 <|
    PetersenLocalChildren.push (x := s2876) b2876 <|
    PetersenLocalChildren.push (x := s2877) b2877 <|
    PetersenLocalChildren.push (x := s2740) b2740 <|
    PetersenLocalChildren.push (x := s2780) b2780 <|
    PetersenLocalChildren.push (x := s2746) b2746 <|
    PetersenLocalChildren.push (x := s2881) b2881 <|
    PetersenLocalChildren.nil
theorem b3165 : Blocked tgt 8 s3165 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s3154) (by decide +kernel)
  exact b3154
theorem b9509 : Blocked tgt 8 s9509 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s4379) (by decide +kernel)
  exact b4379
theorem b10919 : Blocked tgt 8 s10919 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s6500) (by decide +kernel)
  exact b6500
theorem b11304 : Blocked tgt 8 s11304 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s11288) (by decide +kernel)
  exact b11288
theorem b12972 : Blocked tgt 8 s12972 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12716) (by decide +kernel)
  exact b12716
theorem b13263 : Blocked tgt 8 s13263 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12557) (by decide +kernel)
  exact b12557
theorem b13470 : Blocked tgt 8 s13470 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12764) (by decide +kernel)
  exact b12764
theorem b13703 : Blocked tgt 8 s13703 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s13694) (by decide +kernel)
  exact b13694
theorem b13832 : Blocked tgt 8 s13832 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s13823) (by decide +kernel)
  exact b13823
theorem b14052 : Blocked tgt 8 s14052 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s13934) (by decide +kernel)
  exact b13934
private theorem thetaPair15206i0 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6836,6836,6964,773,6578,901,6964,6578,6964,6836,6836,901]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i1 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2877,s12048]) (hints := [5932,6580,5932,6326,6838,0,5932,6838,5932,6060,6580,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s2877,s12048], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s2877) (b2877) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12048) (b12048) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i2 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word220) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15207,s15208,s4264,s15209,s15210,s15211,s4655]) (hints := [5553,6585,0,5553,1,2,3,4,5,6585,6585,6]) (by decide +kernel) ?_
  change ∀ x ∈ [s15207,s15208,s4264,s15209,s15210,s15211,s4655], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15207) (b15207) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15208) (b15208) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4264) (b4264) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15209) (b15209) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15210) (b15210) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15211) (b15211) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4655) (b4655) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i3 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12563,s15212,s12767,s15213,s15214]) (hints := [11607,6583,11607,0,1,2,11607,3,11607,6583,6583,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s12563,s15212,s12767,s15213,s15214], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12563) (b12563) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15212) (b15212) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12767) (b12767) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15213) (b15213) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15214) (b15214) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i4 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4514,7466,4530,6578,2693,7466,6578,7466,4514,4514,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i5 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2450,13642,2482,6578,4741,13642,6578,13642,2450,2450,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i6 : PetersenLocalChildren.PairOK tgt 7 s15206 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13269,s15215,s13473,s15216,s15217]) (hints := [13615,6583,13615,0,1,2,13615,3,13615,6583,6583,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s13269,s15215,s13473,s15216,s15217], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s13269) (b13269) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15215) (b15215) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s13473) (b13473) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15216) (b15216) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15217) (b15217) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i7 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,389,901,5930,897,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i8 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word220) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15218,s15219,s15236,s15237,s15240,s15241,s15242,s901]) (hints := [909,909,0,1,2,3,4,5,6,909,909,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15218,s15219,s15236,s15237,s15240,s15241,s15242,s901], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15218) (b15218) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15219) (b15219) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15236) (b15236) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15237) (b15237) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15240) (b15240) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15241) (b15241) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15242) (b15242) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s901) (b901) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i9 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,11344,8649,9673,11602,9665,9673,11344,901,901,11602]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i10 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,2693,4916,6964,7466,2693,6964,2693,901,901,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i11 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,4741,2868,6964,13642,4741,6964,4741,901,901,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i12 : PetersenLocalChildren.PairOK tgt 7 s15206 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,13352,1481,9673,13610,9609,9673,13352,901,901,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i13 : PetersenLocalChildren.PairOK tgt 7 s15206 (word0,word220) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4661,s14371,s4662,s2558]) (hints := [6966,6966,0,5934,5934,1,9933,5934,2,9933,6966,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4661,s14371,s4662,s2558], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4661) (b4661) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s14371) (b14371) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s4662) (b4662) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s2558) (b2558) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i14 : PetersenLocalChildren.PairOK tgt 7 s15206 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14353,s15243]) (hints := [11092,11092,11604,5932,5932,0,11604,5932,11604,11092,11092,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14353,s15243], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s14353) (b14353) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15243) (b15243) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i15 : PetersenLocalChildren.PairOK tgt 7 s15206 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2181,11090,2693,11465,11090,11465,2689,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i16 : PetersenLocalChildren.PairOK tgt 7 s15206 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4229,5930,4741,13513,5930,13513,4737,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i17 : PetersenLocalChildren.PairOK tgt 7 s15206 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14964,s15244]) (hints := [5932,5932,13612,1868,10060,0,13612,10060,13612,5932,5932,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14964,s15244], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s14964) (b14964) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15244) (b15244) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i18 : PetersenLocalChildren.PairOK tgt 7 s15206 (word220,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13887,s13888,s15245,s15246,s5344,s15247,s5524]) (hints := [0,1,2,11609,3,11609,1676,4,5,1676,6,11609]) (by decide +kernel) ?_
  change ∀ x ∈ [s13887,s13888,s15245,s15246,s5344,s15247,s5524], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s13887) (b13887) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s13888) (b13888) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15245) (b15245) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15246) (b15246) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5344) (b5344) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15247) (b15247) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5524) (b5524) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i19 : PetersenLocalChildren.PairOK tgt 7 s15206 (word220,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15248,s15249,s15250,s15251]) (hints := [2697,0,2697,7470,1,7470,2697,2,2697,7470,3,7470]) (by decide +kernel) ?_
  change ∀ x ∈ [s15248,s15249,s15250,s15251], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15248) (b15248) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15249) (b15249) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15250) (b15250) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15251) (b15251) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i20 : PetersenLocalChildren.PairOK tgt 7 s15206 (word220,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15252,s15253,s15254,s15255]) (hints := [4745,0,4745,13646,1,13646,4745,2,4745,13646,3,13646]) (by decide +kernel) ?_
  change ∀ x ∈ [s15252,s15253,s15254,s15255], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15252) (b15252) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15253) (b15253) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15254) (b15254) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15255) (b15255) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i21 : PetersenLocalChildren.PairOK tgt 7 s15206 (word220,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14221,s14222,s15256,s15257,s5343,s15258,s10239]) (hints := [0,1,2,13617,3,13617,8844,4,5,8844,6,13617]) (by decide +kernel) ?_
  change ∀ x ∈ [s14221,s14222,s15256,s15257,s5343,s15258,s10239], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s14221) (b14221) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s14222) (b14222) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15256) (b15256) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15257) (b15257) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5343) (b5343) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15258) (b15258) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s10239) (b10239) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i22 : PetersenLocalChildren.PairOK tgt 7 s15206 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15259,s15260]) (hints := [2695,0,2695,10443,11604,11467,2695,11604,2695,11459,1,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s15259,s15260], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15259) (b15259) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15260) (b15260) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i23 : PetersenLocalChildren.PairOK tgt 7 s15206 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15261,s15262]) (hints := [4743,11604,4743,12491,0,13515,4743,1,4743,13507,11604,13515]) (by decide +kernel) ?_
  change ∀ x ∈ [s15261,s15262], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15261) (b15261) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15262) (b15262) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i24 : PetersenLocalChildren.PairOK tgt 7 s15206 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15263,s15264,s15265,s15266]) (hints := [3414,0,1,3414,11606,13614,11606,11606,2,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s15263,s15264,s15265,s15266], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15263) (b15263) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15264) (b15264) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15265) (b15265) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15266) (b15266) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i25 : PetersenLocalChildren.PairOK tgt 7 s15206 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [2693,2693,4741,3370,7466,14674,4741,7466,4741,2693,2693,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15206i26 : PetersenLocalChildren.PairOK tgt 7 s15206 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15267,s15268]) (hints := [2695,2695,13612,3275,11467,0,11403,11467,13612,2695,2695,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s15267,s15268], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15267) (b15267) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15268) (b15268) <|
    PetersenLocalChildren.nil
private theorem thetaPair15206i27 : PetersenLocalChildren.PairOK tgt 7 s15206 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15269,s15270]) (hints := [4743,4743,0,5323,13515,13612,13451,13515,1,4743,4743,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s15269,s15270], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15269) (b15269) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s15270) (b15270) <|
    PetersenLocalChildren.nil
theorem b15206 : Blocked tgt 8 s15206 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word220),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word220),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word220),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word220,word6),(word220,word5),(word220,word2),(word220,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 7 s15206 p
  exact
    PetersenLocalChildren.push thetaPair15206i0 <|
    PetersenLocalChildren.push thetaPair15206i1 <|
    PetersenLocalChildren.push thetaPair15206i2 <|
    PetersenLocalChildren.push thetaPair15206i3 <|
    PetersenLocalChildren.push thetaPair15206i4 <|
    PetersenLocalChildren.push thetaPair15206i5 <|
    PetersenLocalChildren.push thetaPair15206i6 <|
    PetersenLocalChildren.push thetaPair15206i7 <|
    PetersenLocalChildren.push thetaPair15206i8 <|
    PetersenLocalChildren.push thetaPair15206i9 <|
    PetersenLocalChildren.push thetaPair15206i10 <|
    PetersenLocalChildren.push thetaPair15206i11 <|
    PetersenLocalChildren.push thetaPair15206i12 <|
    PetersenLocalChildren.push thetaPair15206i13 <|
    PetersenLocalChildren.push thetaPair15206i14 <|
    PetersenLocalChildren.push thetaPair15206i15 <|
    PetersenLocalChildren.push thetaPair15206i16 <|
    PetersenLocalChildren.push thetaPair15206i17 <|
    PetersenLocalChildren.push thetaPair15206i18 <|
    PetersenLocalChildren.push thetaPair15206i19 <|
    PetersenLocalChildren.push thetaPair15206i20 <|
    PetersenLocalChildren.push thetaPair15206i21 <|
    PetersenLocalChildren.push thetaPair15206i22 <|
    PetersenLocalChildren.push thetaPair15206i23 <|
    PetersenLocalChildren.push thetaPair15206i24 <|
    PetersenLocalChildren.push thetaPair15206i25 <|
    PetersenLocalChildren.push thetaPair15206i26 <|
    PetersenLocalChildren.push thetaPair15206i27 <|
    PetersenLocalChildren.nil
theorem b15272 : Blocked tgt 8 s15272 := by
  apply PetersenFastNode.node (nxt := #[s2877,s572,s4711,s5240,s15245,s10084,s15256,s5421,s15273,s12583,s13289,s15274,s15277,s2987,s3120]) (hints := [6593,6593,916,9688,916,9688,5945,0,1,2,11617,3,11617,4,2708,11480,2708,11480,4756,13528,4756,13528,13625,5,13625,6,6851,9688,6979,9688,5945,6851,6073,6851,7,8,6851,11617,9,11617,6851,7481,11480,7481,11480,13657,13528,13657,13528,13625,10,13625,6851,9688,916,916,9688,9688,11,12,9688,8656,8664,9680,8656,9688,4931,11480,9688,9688,2883,13528,9688,1432,1496,9624,1432,6977,5945,5945,6977,11105,5945,11617,11105,11480,2708,11480,2708,13528,4756,13528,4756,5945,1881,13625,5945,13,11617,1684,1684,11480,7481,11480,7481,13528,13657,13528,13657,14,13625,8852,8852,10448,10456,10448,11472,12496,12504,12496,13520,3425,3425,11617,13625,11480,3385,13528,11480,3224,3288,11416,3224,5272,5336,13464,5272]) (by decide +kernel)
  change ∀ b ∈ [s2877,s572,s4711,s5240,s15245,s10084,s15256,s5421,s15273,s12583,s13289,s15274,s15277,s2987,s3120], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2877) b2877 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s4711) b4711 <|
    PetersenLocalChildren.push (x := s5240) b5240 <|
    PetersenLocalChildren.push (x := s15245) b15245 <|
    PetersenLocalChildren.push (x := s10084) b10084 <|
    PetersenLocalChildren.push (x := s15256) b15256 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s15273) b15273 <|
    PetersenLocalChildren.push (x := s12583) b12583 <|
    PetersenLocalChildren.push (x := s13289) b13289 <|
    PetersenLocalChildren.push (x := s15274) b15274 <|
    PetersenLocalChildren.push (x := s15277) b15277 <|
    PetersenLocalChildren.push (x := s2987) b2987 <|
    PetersenLocalChildren.push (x := s3120) b3120 <|
    PetersenLocalChildren.nil
private theorem thetaPair921i0 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s456,s347,s141]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s456,s347,s141], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s456) (b456) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s347) (b347) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s141) (b141) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i1 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s922,s923,s924,s457,s459,s925,s926]) (hints := [0,1,2,3,4,5,9680,6,9680]) (by decide +kernel) ?_
  change ∀ x ∈ [s922,s923,s924,s457,s459,s925,s926], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s922) (b922) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s923) (b923) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s924) (b924) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s457) (b457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s459) (b459) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s925) (b925) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s926) (b926) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i2 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word69) := by
  refine PetersenLocalChildren.pair_close (bank := #[s456,s926,s5,s927,s928,s929]) (hints := [2,0,3,4,1,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s456,s926,s5,s927,s928,s929], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s456) (b456) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s926) (b926) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s928) (b928) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s929) (b929) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i3 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s456,s348,s379,s930]) (hints := [5934,0,5934,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s456,s348,s379,s930], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s456) (b456) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s348) (b348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s379) (b379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s930) (b930) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i4 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s931,s932,s972,s978,s979,s980,s1022,s1023]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s931,s932,s972,s978,s979,s980,s1022,s1023], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s931) (b931) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s932) (b932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s972) (b972) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s978) (b978) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s979) (b979) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s980) (b980) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1022) (b1022) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1023) (b1023) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i5 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1024,s1025,s1026,s1027]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s1024,s1025,s1026,s1027], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1024) (b1024) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1025) (b1025) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1026) (b1026) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1027) (b1027) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i6 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1028,s1029,s1030,s1031]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s1028,s1029,s1030,s1031], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1028) (b1028) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1029) (b1029) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1030) (b1030) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1031) (b1031) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i7 : PetersenLocalChildren.PairOK tgt 8 s921 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1032,s1033,s1073,s1079,s1080,s1081,s1123,s1124]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s1032,s1033,s1073,s1079,s1080,s1081,s1123,s1124], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1032) (b1032) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1033) (b1033) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1073) (b1073) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1079) (b1079) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1080) (b1080) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1081) (b1081) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1123) (b1123) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1124) (b1124) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i8 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1125,s1126,s1127,s1128,s1129]) (hints := [6841,6841,0,9678,1,9678,2,3,4,9678,6841,9678]) (by decide +kernel) ?_
  change ∀ x ∈ [s1125,s1126,s1127,s1128,s1129], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1125) (b1125) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1126) (b1126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1127) (b1127) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1128) (b1128) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1129) (b1129) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i9 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word69) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1126,s1130,s1131,s1132,s197,s1133,s1134,s1135]) (hints := [6844,6844,1,2,0,3,4,5,6,6844,6844,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s1126,s1130,s1131,s1132,s197,s1133,s1134,s1135], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1126) (b1126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1130) (b1130) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1131) (b1131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1132) (b1132) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s197) (b197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1133) (b1133) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1134) (b1134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1135) (b1135) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i10 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s141,s930,s1136,s1137]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s141,s930,s1136,s1137], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s141) (b141) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s930) (b930) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1136) (b1136) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1137) (b1137) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i11 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1138,s1144]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s1138,s1144], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1138) (b1138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1144) (b1144) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i12 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i13 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i14 : PetersenLocalChildren.PairOK tgt 8 s921 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1145,s1151]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s1145,s1151], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1145) (b1145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1151) (b1151) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i15 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word69) := by
  refine PetersenLocalChildren.pair_close (bank := #[s925,s927,s1152]) (hints := [9676,9676,1,904,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s925,s927,s1152], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s925) (b925) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1152) (b1152) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i16 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1153,s1154]) (hints := [9675,9675,5674,5932,0,5932,5674,1,5674,9675,9675,5932]) (by decide +kernel) ?_
  change ∀ x ∈ [s1153,s1154], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1153) (b1153) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1154) (b1154) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i17 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i18 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1155,s1156]) (hints := [9675,9675,11467,7468,0,7468,11467,1,11467,9675,9675,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s1155,s1156], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1155) (b1155) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1156) (b1156) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i19 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1157,s1158]) (hints := [9675,9675,13515,13644,0,13644,13515,1,13515,9675,9675,13644]) (by decide +kernel) ?_
  change ∀ x ∈ [s1157,s1158], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1157) (b1157) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1158) (b1158) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i20 : PetersenLocalChildren.PairOK tgt 8 s921 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i21 : PetersenLocalChildren.PairOK tgt 8 s921 (word69,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1159,s1160,s1161,s1162]) (hints := [5676,0,5676,5934,1,5934,5676,2,5676,5934,3,5934]) (by decide +kernel) ?_
  change ∀ x ∈ [s1159,s1160,s1161,s1162], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1159) (b1159) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1160) (b1160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1161) (b1161) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1162) (b1162) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i22 : PetersenLocalChildren.PairOK tgt 8 s921 (word69,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1163,s1164,s1169,s1170]) (hints := [1673,0,1673,7478,1,7478,1673,2,1673,7478,3,7478]) (by decide +kernel) ?_
  change ∀ x ∈ [s1163,s1164,s1169,s1170], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1163) (b1163) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1164) (b1164) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1169) (b1169) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1170) (b1170) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i23 : PetersenLocalChildren.PairOK tgt 8 s921 (word69,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1171,s1172,s1173,s1174]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s1171,s1172,s1173,s1174], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1171) (b1171) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1172) (b1172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1173) (b1173) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1174) (b1174) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i24 : PetersenLocalChildren.PairOK tgt 8 s921 (word69,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1175,s1176,s1177,s1178]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s1175,s1176,s1177,s1178], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1175) (b1175) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1176) (b1176) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1177) (b1177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1178) (b1178) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i25 : PetersenLocalChildren.PairOK tgt 8 s921 (word69,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1179,s1180,s1185,s1186]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s1179,s1180,s1185,s1186], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1179) (b1179) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1180) (b1180) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1185) (b1185) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1186) (b1186) <|
    PetersenLocalChildren.nil
private theorem thetaPair921i26 : PetersenLocalChildren.PairOK tgt 8 s921 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i27 : PetersenLocalChildren.PairOK tgt 8 s921 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i28 : PetersenLocalChildren.PairOK tgt 8 s921 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i29 : PetersenLocalChildren.PairOK tgt 8 s921 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i30 : PetersenLocalChildren.PairOK tgt 8 s921 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,10441,7474,11465,10433,7474,10433,11457,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i31 : PetersenLocalChildren.PairOK tgt 8 s921 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i32 : PetersenLocalChildren.PairOK tgt 8 s921 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i33 : PetersenLocalChildren.PairOK tgt 8 s921 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i34 : PetersenLocalChildren.PairOK tgt 8 s921 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair921i35 : PetersenLocalChildren.PairOK tgt 8 s921 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b921 : Blocked tgt 9 s921 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word69),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word69),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word69),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word69,word0),(word69,word6),(word69,word5),(word69,word2),(word69,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s921 p
  exact
    PetersenLocalChildren.push thetaPair921i0 <|
    PetersenLocalChildren.push thetaPair921i1 <|
    PetersenLocalChildren.push thetaPair921i2 <|
    PetersenLocalChildren.push thetaPair921i3 <|
    PetersenLocalChildren.push thetaPair921i4 <|
    PetersenLocalChildren.push thetaPair921i5 <|
    PetersenLocalChildren.push thetaPair921i6 <|
    PetersenLocalChildren.push thetaPair921i7 <|
    PetersenLocalChildren.push thetaPair921i8 <|
    PetersenLocalChildren.push thetaPair921i9 <|
    PetersenLocalChildren.push thetaPair921i10 <|
    PetersenLocalChildren.push thetaPair921i11 <|
    PetersenLocalChildren.push thetaPair921i12 <|
    PetersenLocalChildren.push thetaPair921i13 <|
    PetersenLocalChildren.push thetaPair921i14 <|
    PetersenLocalChildren.push thetaPair921i15 <|
    PetersenLocalChildren.push thetaPair921i16 <|
    PetersenLocalChildren.push thetaPair921i17 <|
    PetersenLocalChildren.push thetaPair921i18 <|
    PetersenLocalChildren.push thetaPair921i19 <|
    PetersenLocalChildren.push thetaPair921i20 <|
    PetersenLocalChildren.push thetaPair921i21 <|
    PetersenLocalChildren.push thetaPair921i22 <|
    PetersenLocalChildren.push thetaPair921i23 <|
    PetersenLocalChildren.push thetaPair921i24 <|
    PetersenLocalChildren.push thetaPair921i25 <|
    PetersenLocalChildren.push thetaPair921i26 <|
    PetersenLocalChildren.push thetaPair921i27 <|
    PetersenLocalChildren.push thetaPair921i28 <|
    PetersenLocalChildren.push thetaPair921i29 <|
    PetersenLocalChildren.push thetaPair921i30 <|
    PetersenLocalChildren.push thetaPair921i31 <|
    PetersenLocalChildren.push thetaPair921i32 <|
    PetersenLocalChildren.push thetaPair921i33 <|
    PetersenLocalChildren.push thetaPair921i34 <|
    PetersenLocalChildren.push thetaPair921i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i0 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s1188,s1189,s1190,s1191]) (hints := [5551,0,5551,1,5293,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s1188,s1189,s1190,s1191], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1188) (b1188) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1189) (b1189) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1190) (b1190) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1191) (b1191) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i1 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s1188,s1192,s457,s459]) (hints := [906,0,906,1,9678,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s1188,s1192,s457,s459], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1188) (b1188) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1192) (b1192) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s457) (b457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s459) (b459) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i2 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s1188,s1193,s1194,s1195]) (hints := [9934,0,5935,1,9934,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s1188,s1193,s1194,s1195], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1188) (b1188) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1193) (b1193) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1194) (b1194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1195) (b1195) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i3 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1196,s1197,s1198,s1283,s1324,s1325,s1326,s1327,s1328,s1329,s1330,s1331]) (hints := [1681,0,1681,1,2,3,4,5,1681,6,1681,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s1196,s1197,s1198,s1283,s1324,s1325,s1326,s1327,s1328,s1329,s1330,s1331], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1196) (b1196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1197) (b1197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1198) (b1198) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1283) (b1283) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1324) (b1324) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1325) (b1325) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1326) (b1326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1327) (b1327) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1328) (b1328) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1329) (b1329) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1330) (b1330) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1331) (b1331) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i4 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1332,s1333,s1334,s1371,s1372,s1373,s1374,s1375]) (hints := [2701,0,2701,1,11473,2,11473,3,2701,4,2701,5,11473,6,11473,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s1332,s1333,s1334,s1371,s1372,s1373,s1374,s1375], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1332) (b1332) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1333) (b1333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1334) (b1334) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1371) (b1371) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1372) (b1372) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1373) (b1373) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1374) (b1374) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1375) (b1375) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i5 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1376,s1377,s1378,s1414,s1415,s1416,s1417,s1418]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s1376,s1377,s1378,s1414,s1415,s1416,s1417,s1418], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1376) (b1376) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1377) (b1377) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1378) (b1378) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1414) (b1414) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1415) (b1415) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1416) (b1416) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1417) (b1417) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1418) (b1418) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i6 : PetersenLocalChildren.PairOK tgt 8 s1187 (word114,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1419,s1420,s1421,s1506,s1544,s1545,s1546,s1547,s1548,s1549,s1550,s1551]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s1419,s1420,s1421,s1506,s1544,s1545,s1546,s1547,s1548,s1549,s1550,s1551], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1419) (b1419) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1420) (b1420) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1421) (b1421) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1506) (b1506) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1544) (b1544) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1545) (b1545) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1546) (b1546) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1547) (b1547) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1548) (b1548) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1549) (b1549) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1550) (b1550) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1551) (b1551) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i7 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1552,s1553,s1554,s1555]) (hints := [6840,6840,6968,0,777,5550,905,1,6968,5550,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1552,s1553,s1554,s1555], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1552) (b1552) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1553) (b1553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1554) (b1554) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1555) (b1555) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i8 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1556,s1557,s1558,s1152,s1559,s1560]) (hints := [5552,5552,5936,0,6842,6842,1,2,5936,6842,5936,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s1556,s1557,s1558,s1152,s1559,s1560], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1556) (b1556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1557) (b1557) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1558) (b1558) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1152) (b1152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1559) (b1559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1560) (b1560) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i9 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1561,s1562,s1563,s1564]) (hints := [6582,6582,7478,0,4526,5550,1673,1,7478,5550,7478,2,6582,6582,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1561,s1562,s1563,s1564], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1561) (b1561) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1562) (b1562) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1563) (b1563) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1564) (b1564) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i10 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1565,s1566,s1567,s1568]) (hints := [5550,5550,7470,0,11469,6582,11469,1,7470,6582,7470,2,11469,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1565,s1566,s1567,s1568], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1565) (b1565) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1566) (b1566) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1567) (b1567) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1568) (b1568) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i11 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1569,s1570,s1571,s1572]) (hints := [9678,9678,13646,0,13517,5550,13517,1,13646,5550,13646,2,13517,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1569,s1570,s1571,s1572], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1569) (b1569) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1570) (b1570) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1571) (b1571) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1572) (b1572) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i12 : PetersenLocalChildren.PairOK tgt 8 s1187 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1573,s1574,s1575,s1576]) (hints := [5550,5550,13614,0,1486,9678,8841,1,13614,9678,13614,2,5550,5550,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1573,s1574,s1575,s1576], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1573) (b1573) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1574) (b1574) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1575) (b1575) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1576) (b1576) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i13 : PetersenLocalChildren.PairOK tgt 8 s1187 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1577,s1578,s1579,s1580,s1581,s1582]) (hints := [395,0,5678,1,395,907,5936,2,907,907,5678,3,5934,4,5936,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s1577,s1578,s1579,s1580,s1581,s1582], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1577) (b1577) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1578) (b1578) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1579) (b1579) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1580) (b1580) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1581) (b1581) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1582) (b1582) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i14 : PetersenLocalChildren.PairOK tgt 8 s1187 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1583,s1584,s1615,s1616,s1617,s1618]) (hints := [907,907,1675,0,7224,1,7480,2,1675,3,1675,4,907,907,7480,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s1583,s1584,s1615,s1616,s1617,s1618], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1583) (b1583) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1584) (b1584) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1615) (b1615) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1616) (b1616) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1617) (b1617) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1618) (b1618) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i15 : PetersenLocalChildren.PairOK tgt 8 s1187 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1619,s1620,s1621,s1622]) (hints := [11469,905,11469,0,4920,6968,7470,1,11469,6968,11469,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1619,s1620,s1621,s1622], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1619) (b1619) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1620) (b1620) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1621) (b1621) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1622) (b1622) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i16 : PetersenLocalChildren.PairOK tgt 8 s1187 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1623,s1624,s1625,s1626]) (hints := [13517,905,13517,0,2872,6968,13646,1,13517,6968,13517,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1623,s1624,s1625,s1626], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1623) (b1623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1624) (b1624) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1625) (b1625) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1626) (b1626) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i17 : PetersenLocalChildren.PairOK tgt 8 s1187 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1627,s1628,s1657,s1658,s1659,s1660]) (hints := [907,907,8843,0,13360,1,13616,2,8843,3,8843,4,907,907,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s1627,s1628,s1657,s1658,s1659,s1660], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1627) (b1627) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1628) (b1628) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1657) (b1657) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1658) (b1658) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1659) (b1659) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1660) (b1660) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i18 : PetersenLocalChildren.PairOK tgt 8 s1187 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1661,s1662,s1663,s1664]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1661,s1662,s1663,s1664], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1661) (b1661) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1662) (b1662) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1663) (b1663) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1664) (b1664) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i19 : PetersenLocalChildren.PairOK tgt 8 s1187 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1665,s1666,s1667,s1668]) (hints := [11469,5934,11469,0,2697,6966,2697,1,11469,6966,11469,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1665,s1666,s1667,s1668], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1665) (b1665) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1666) (b1666) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1667) (b1667) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1668) (b1668) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i20 : PetersenLocalChildren.PairOK tgt 8 s1187 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1669,s1670,s1671,s1672]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1669,s1670,s1671,s1672], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1669) (b1669) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1670) (b1670) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1671) (b1671) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1672) (b1672) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i21 : PetersenLocalChildren.PairOK tgt 8 s1187 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1673,s1674,s1675,s1676]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1673,s1674,s1675,s1676], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1673) (b1673) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1674) (b1674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1675) (b1675) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1676) (b1676) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i22 : PetersenLocalChildren.PairOK tgt 8 s1187 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1677,s1678,s1679,s1680]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1677,s1678,s1679,s1680], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1677) (b1677) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1678) (b1678) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1679) (b1679) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1680) (b1680) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i23 : PetersenLocalChildren.PairOK tgt 8 s1187 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1681,s1682,s1683,s1684]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1681,s1682,s1683,s1684], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1681) (b1681) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1682) (b1682) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1683) (b1683) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1684) (b1684) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i24 : PetersenLocalChildren.PairOK tgt 8 s1187 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1685,s1686,s1693,s1694]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1685,s1686,s1693,s1694], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1685) (b1685) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1686) (b1686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1693) (b1693) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1694) (b1694) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i25 : PetersenLocalChildren.PairOK tgt 8 s1187 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1695,s1696,s1697,s1698]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1695,s1696,s1697,s1698], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1695) (b1695) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1696) (b1696) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1697) (b1697) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1698) (b1698) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i26 : PetersenLocalChildren.PairOK tgt 8 s1187 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1699,s1700,s1701,s1702]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1699,s1700,s1701,s1702], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1699) (b1699) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1700) (b1700) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1701) (b1701) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1702) (b1702) <|
    PetersenLocalChildren.nil
private theorem thetaPair1187i27 : PetersenLocalChildren.PairOK tgt 8 s1187 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s1703,s1704,s1705,s1706]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s1703,s1704,s1705,s1706], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1703) (b1703) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1704) (b1704) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1705) (b1705) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1706) (b1706) <|
    PetersenLocalChildren.nil
theorem b1187 : Blocked tgt 9 s1187 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word114,word3),(word114,word1),(word114,word0),(word114,word6),(word114,word5),(word114,word2),(word114,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s1187 p
  exact
    PetersenLocalChildren.push thetaPair1187i0 <|
    PetersenLocalChildren.push thetaPair1187i1 <|
    PetersenLocalChildren.push thetaPair1187i2 <|
    PetersenLocalChildren.push thetaPair1187i3 <|
    PetersenLocalChildren.push thetaPair1187i4 <|
    PetersenLocalChildren.push thetaPair1187i5 <|
    PetersenLocalChildren.push thetaPair1187i6 <|
    PetersenLocalChildren.push thetaPair1187i7 <|
    PetersenLocalChildren.push thetaPair1187i8 <|
    PetersenLocalChildren.push thetaPair1187i9 <|
    PetersenLocalChildren.push thetaPair1187i10 <|
    PetersenLocalChildren.push thetaPair1187i11 <|
    PetersenLocalChildren.push thetaPair1187i12 <|
    PetersenLocalChildren.push thetaPair1187i13 <|
    PetersenLocalChildren.push thetaPair1187i14 <|
    PetersenLocalChildren.push thetaPair1187i15 <|
    PetersenLocalChildren.push thetaPair1187i16 <|
    PetersenLocalChildren.push thetaPair1187i17 <|
    PetersenLocalChildren.push thetaPair1187i18 <|
    PetersenLocalChildren.push thetaPair1187i19 <|
    PetersenLocalChildren.push thetaPair1187i20 <|
    PetersenLocalChildren.push thetaPair1187i21 <|
    PetersenLocalChildren.push thetaPair1187i22 <|
    PetersenLocalChildren.push thetaPair1187i23 <|
    PetersenLocalChildren.push thetaPair1187i24 <|
    PetersenLocalChildren.push thetaPair1187i25 <|
    PetersenLocalChildren.push thetaPair1187i26 <|
    PetersenLocalChildren.push thetaPair1187i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i0 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4214,s4215,s4222,s4223]) (hints := [6840,6840,6968,0,777,5550,905,1,6968,5550,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4214,s4215,s4222,s4223], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4214) (b4214) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4215) (b4215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4222) (b4222) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4223) (b4223) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i1 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4224,s2948,s4225,s4226]) (hints := [5550,5550,5934,0,9805,6840,9933,1,5934,6840,5934,2,5550,5550,9933,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4224,s2948,s4225,s4226], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4224) (b4224) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2948) (b2948) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4225) (b4225) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4226) (b4226) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i2 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4227,s4228,s3311,s4229,s4230,s4231,s3352,s4232]) (hints := [4530,6844,0,1,4530,5554,2,3,5554,5554,4,5,6844,6844,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4227,s4228,s3311,s4229,s4230,s4231,s3352,s4232], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4227) (b4227) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4228) (b4228) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3311) (b3311) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4229) (b4229) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4230) (b4230) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4231) (b4231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3352) (b3352) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4232) (b4232) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i3 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4229,s4232,s4233,s4234,s4235,s25,s4236,s4237]) (hints := [6844,6844,2,3,5554,5554,4,0,5554,5554,5,6,6586,6844,7,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s4229,s4232,s4233,s4234,s4235,s25,s4236,s4237], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4229) (b4229) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4232) (b4232) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4233) (b4233) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4234) (b4234) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4235) (b4235) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s25) (b25) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4236) (b4236) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4237) (b4237) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i4 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4238,s4239,s4240,s4241]) (hints := [5550,5550,7470,0,4792,6840,2697,1,7470,6840,7470,2,5550,5550,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4238,s4239,s4240,s4241], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4238) (b4238) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4239) (b4239) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4240) (b4240) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4241) (b4241) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i5 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4242,s4243,s4250,s4251]) (hints := [9678,9678,13646,0,1454,5550,4745,1,13646,5550,13646,2,9678,9678,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4242,s4243,s4250,s4251], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4242) (b4242) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4243) (b4243) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4250) (b4250) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4251) (b4251) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i6 : PetersenLocalChildren.PairOK tgt 8 s4213 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4252,s4253,s4269,s4270]) (hints := [5550,5550,13614,0,1486,9678,8841,1,13614,9678,13614,2,5550,5550,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4252,s4253,s4269,s4270], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4252) (b4252) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4253) (b4253) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4269) (b4269) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4270) (b4270) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i7 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4271,s4272,s4283,s4284]) (hints := [9677,9677,9933,0,905,905,5934,1,9933,905,9933,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4271,s4272,s4283,s4284], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4271) (b4271) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4272) (b4272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4283) (b4283) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4284) (b4284) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i8 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4285,s4286,s4287,s4326,s4327,s4328,s4329,s4330]) (hints := [909,909,0,1,8657,9681,2,3,9673,9681,4,5,909,909,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4285,s4286,s4287,s4326,s4327,s4328,s4329,s4330], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4285) (b4285) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4286) (b4286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4287) (b4287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4326) (b4326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4327) (b4327) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4328) (b4328) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4329) (b4329) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4330) (b4330) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i9 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4331,s4332,s578,s4333,s4334,s4335,s4336,s4373]) (hints := [909,909,0,1,9681,9681,2,3,9681,9681,4,5,909,909,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4331,s4332,s578,s4333,s4334,s4335,s4336,s4373], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4331) (b4331) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4332) (b4332) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s578) (b578) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4333) (b4333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4334) (b4334) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4335) (b4335) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4336) (b4336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4373) (b4373) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i10 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4374,s4375,s4376,s4377]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4374,s4375,s4376,s4377], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4374) (b4374) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4375) (b4375) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4376) (b4376) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4377) (b4377) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i11 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4378,s4379,s4387,s4388]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4378,s4379,s4387,s4388], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4378) (b4378) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4379) (b4379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4387) (b4387) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4388) (b4388) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i12 : PetersenLocalChildren.PairOK tgt 8 s4213 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4389,s4390,s4397,s4398]) (hints := [905,905,8841,0,1485,9677,13614,1,8841,9677,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4389,s4390,s4397,s4398], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4389) (b4389) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4390) (b4390) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4397) (b4397) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4398) (b4398) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i13 : PetersenLocalChildren.PairOK tgt 8 s4213 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3710,s4399,s4400,s4432,s3745,s4433,s4434,s4435]) (hints := [6970,6970,0,1,9937,9937,2,3,9929,9937,4,5,9929,6970,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s3710,s4399,s4400,s4432,s3745,s4433,s4434,s4435], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3710) (b3710) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4399) (b4399) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4400) (b4400) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4432) (b4432) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3745) (b3745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4433) (b4433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4434) (b4434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4435) (b4435) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i14 : PetersenLocalChildren.PairOK tgt 8 s4213 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4399,s4433,s4436,s2241,s4437,s4438,s4439,s4440]) (hints := [8905,6970,2,0,9937,9937,3,4,9937,9937,5,1,6970,6970,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4399,s4433,s4436,s2241,s4437,s4438,s4439,s4440], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4399) (b4399) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4433) (b4433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4436) (b4436) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2241) (b2241) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4437) (b4437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4438) (b4438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4439) (b4439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4440) (b4440) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i15 : PetersenLocalChildren.PairOK tgt 8 s4213 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4441,s4442,s4443,s4444]) (hints := [9933,9933,11469,0,2697,6966,2697,1,11469,6966,11469,2,9933,9933,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4441,s4442,s4443,s4444], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4441) (b4441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4442) (b4442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4443) (b4443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4444) (b4444) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i16 : PetersenLocalChildren.PairOK tgt 8 s4213 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4445,s4446,s4459,s4460]) (hints := [9933,9933,13517,0,4745,5934,4745,1,13517,5934,13517,2,9933,9933,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4445,s4446,s4459,s4460], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4445) (b4445) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4446) (b4446) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4459) (b4459) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4460) (b4460) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i17 : PetersenLocalChildren.PairOK tgt 8 s4213 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4461,s4462,s4473,s4474]) (hints := [1677,1677,13614,0,1741,9933,8841,1,9869,9933,13614,2,1677,1677,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4461,s4462,s4473,s4474], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4461) (b4461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4462) (b4462) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4473) (b4473) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4474) (b4474) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i18 : PetersenLocalChildren.PairOK tgt 8 s4213 (word6,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4475,s5,s4476,s4477,s4478,s4479]) (hints := [1675,0,1,2,1675,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s4475,s5,s4476,s4477,s4478,s4479], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4475) (b4475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4476) (b4476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4477) (b4477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4478) (b4478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4479) (b4479) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i19 : PetersenLocalChildren.PairOK tgt 8 s4213 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4480,s4481,s4482,s4483,s4484,s4485,s4486,s4487]) (hints := [2701,0,2701,1,10449,2,11473,3,2701,4,2701,5,11465,6,11473,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4480,s4481,s4482,s4483,s4484,s4485,s4486,s4487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4480) (b4480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4481) (b4481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4482) (b4482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4483) (b4483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4484) (b4484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4485) (b4485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4486) (b4486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4487) (b4487) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i20 : PetersenLocalChildren.PairOK tgt 8 s4213 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4488,s4489,s4490,s4522,s4523,s4524,s4525,s4526]) (hints := [4749,0,4749,1,12497,2,13521,3,4749,4,4749,5,13513,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4488,s4489,s4490,s4522,s4523,s4524,s4525,s4526], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4488) (b4488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4489) (b4489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4490) (b4490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4522) (b4522) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4523) (b4523) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4524) (b4524) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4525) (b4525) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4526) (b4526) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i21 : PetersenLocalChildren.PairOK tgt 8 s4213 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4527,s4528,s4529,s4566,s4567,s4568,s4569,s4570]) (hints := [8845,0,8845,1,13618,2,13618,3,8845,4,8845,5,13618,6,13618,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4527,s4528,s4529,s4566,s4567,s4568,s4569,s4570], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4527) (b4527) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4528) (b4528) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4529) (b4529) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4566) (b4566) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4567) (b4567) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4568) (b4568) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4569) (b4569) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4570) (b4570) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i22 : PetersenLocalChildren.PairOK tgt 8 s4213 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4571,s4572,s4573,s4574,s4575,s4576,s4577,s4578]) (hints := [2701,0,2701,1,11473,2,11473,3,2701,4,2701,5,11473,6,11473,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4571,s4572,s4573,s4574,s4575,s4576,s4577,s4578], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4571) (b4571) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4572) (b4572) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4573) (b4573) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4574) (b4574) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4575) (b4575) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4576) (b4576) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4577) (b4577) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4578) (b4578) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i23 : PetersenLocalChildren.PairOK tgt 8 s4213 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4579,s4580,s4581,s4609,s4610,s4646,s4647,s4648]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4579,s4580,s4581,s4609,s4610,s4646,s4647,s4648], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4579) (b4579) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4580) (b4580) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4581) (b4581) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4609) (b4609) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4610) (b4610) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4646) (b4646) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4647) (b4647) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4648) (b4648) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i24 : PetersenLocalChildren.PairOK tgt 8 s4213 (word14,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4649,s4650,s4651,s4686,s4687,s4719,s4720,s4721]) (hints := [8845,0,8845,1,13618,2,13618,3,8845,4,8845,5,13618,6,13618,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s4649,s4650,s4651,s4686,s4687,s4719,s4720,s4721], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4649) (b4649) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4650) (b4650) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4651) (b4651) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4686) (b4686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4687) (b4687) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4719) (b4719) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4720) (b4720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4721) (b4721) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i25 : PetersenLocalChildren.PairOK tgt 8 s4213 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4722,s4723,s4724,s4725]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4722,s4723,s4724,s4725], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4722) (b4722) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4723) (b4723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4724) (b4724) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4725) (b4725) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i26 : PetersenLocalChildren.PairOK tgt 8 s4213 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4726,s4727,s4728,s4729]) (hints := [2697,2697,8841,0,3277,11469,14646,1,8841,11469,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4726,s4727,s4728,s4729], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4726) (b4726) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4727) (b4727) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4728) (b4728) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4729) (b4729) <|
    PetersenLocalChildren.nil
private theorem thetaPair4213i27 : PetersenLocalChildren.PairOK tgt 8 s4213 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4730,s4731,s4732,s4733]) (hints := [4745,4745,8841,0,5325,13517,13614,1,8841,13517,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s4730,s4731,s4732,s4733], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4730) (b4730) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4731) (b4731) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4732) (b4732) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4733) (b4733) <|
    PetersenLocalChildren.nil
theorem b4213 : Blocked tgt 9 s4213 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word6),(word3,word14),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word14),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word14),(word0,word5),(word0,word2),(word0,word4),(word6,word14),(word6,word5),(word6,word2),(word6,word4),(word14,word5),(word14,word2),(word14,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s4213 p
  exact
    PetersenLocalChildren.push thetaPair4213i0 <|
    PetersenLocalChildren.push thetaPair4213i1 <|
    PetersenLocalChildren.push thetaPair4213i2 <|
    PetersenLocalChildren.push thetaPair4213i3 <|
    PetersenLocalChildren.push thetaPair4213i4 <|
    PetersenLocalChildren.push thetaPair4213i5 <|
    PetersenLocalChildren.push thetaPair4213i6 <|
    PetersenLocalChildren.push thetaPair4213i7 <|
    PetersenLocalChildren.push thetaPair4213i8 <|
    PetersenLocalChildren.push thetaPair4213i9 <|
    PetersenLocalChildren.push thetaPair4213i10 <|
    PetersenLocalChildren.push thetaPair4213i11 <|
    PetersenLocalChildren.push thetaPair4213i12 <|
    PetersenLocalChildren.push thetaPair4213i13 <|
    PetersenLocalChildren.push thetaPair4213i14 <|
    PetersenLocalChildren.push thetaPair4213i15 <|
    PetersenLocalChildren.push thetaPair4213i16 <|
    PetersenLocalChildren.push thetaPair4213i17 <|
    PetersenLocalChildren.push thetaPair4213i18 <|
    PetersenLocalChildren.push thetaPair4213i19 <|
    PetersenLocalChildren.push thetaPair4213i20 <|
    PetersenLocalChildren.push thetaPair4213i21 <|
    PetersenLocalChildren.push thetaPair4213i22 <|
    PetersenLocalChildren.push thetaPair4213i23 <|
    PetersenLocalChildren.push thetaPair4213i24 <|
    PetersenLocalChildren.push thetaPair4213i25 <|
    PetersenLocalChildren.push thetaPair4213i26 <|
    PetersenLocalChildren.push thetaPair4213i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i0 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4476,s4224,s148]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s4476,s4224,s148], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4476) (b4476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4224) (b4224) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s148) (b148) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i1 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5261,s972,s5262,s5263]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s5261,s972,s5262,s5263], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5261) (b5261) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s972) (b972) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5262) (b5262) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5263) (b5263) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i2 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4476,s2948,s2594]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s4476,s2948,s2594], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4476) (b4476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2948) (b2948) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2594) (b2594) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i3 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5264,s5265,s5266,s4477,s4479,s5267,s4744,s5268,s4746]) (hints := [0,1,2,3,4,5,6,7,8]) (by decide +kernel) ?_
  change ∀ x ∈ [s5264,s5265,s5266,s4477,s4479,s5267,s4744,s5268,s4746], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5264) (b5264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5265) (b5265) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5266) (b5266) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4477) (b4477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4479) (b4479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5267) (b5267) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4744) (b4744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5268) (b5268) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4746) (b4746) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i4 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s4476,s5268,s5,s927,s5269,s5270]) (hints := [2,0,3,4,1,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s4476,s5268,s5,s927,s5269,s5270], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4476) (b4476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5268) (b5268) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5269) (b5269) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5270) (b5270) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i5 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5271,s5272,s5273,s5274]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s5271,s5272,s5273,s5274], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5271) (b5271) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5272) (b5272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5273) (b5273) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5274) (b5274) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i6 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5275,s5276,s5284,s5285]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s5275,s5276,s5284,s5285], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5275) (b5275) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5276) (b5276) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5284) (b5284) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5285) (b5285) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i7 : PetersenLocalChildren.PairOK tgt 8 s5260 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5286,s5287,s5331,s5345,s5346,s5347,s5396,s5397]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5286,s5287,s5331,s5345,s5346,s5347,s5396,s5397], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5286) (b5286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5287) (b5287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5331) (b5331) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5345) (b5345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5346) (b5346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5347) (b5347) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5396) (b5396) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5397) (b5397) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i8 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5398,s5401]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s5398,s5401], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5398) (b5398) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5401) (b5401) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i9 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s148,s2594,s5402,s5403]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s148,s2594,s5402,s5403], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s148) (b148) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2594) (b2594) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5402) (b5402) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5403) (b5403) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i10 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5404,s5094,s5405,s5121,s5406,s5407,s5408,s5124]) (hints := [6844,6844,0,1,2,3,4,5,6,6844,6844,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5404,s5094,s5405,s5121,s5406,s5407,s5408,s5124], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5404) (b5404) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5094) (b5094) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5405) (b5405) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5121) (b5121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5406) (b5406) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5407) (b5407) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5408) (b5408) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5124) (b5124) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i11 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5405,s5409,s5410,s5411,s231,s5412,s5413,s5414]) (hints := [6844,6844,1,2,0,3,4,5,6,6844,6844,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s5405,s5409,s5410,s5411,s231,s5412,s5413,s5414], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5405) (b5405) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5409) (b5409) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5410) (b5410) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5411) (b5411) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s231) (b231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5412) (b5412) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5413) (b5413) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5414) (b5414) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i12 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i13 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i14 : PetersenLocalChildren.PairOK tgt 8 s5260 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5415,s5423]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s5415,s5423], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5415) (b5415) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5423) (b5423) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i15 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i16 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5424,s5425,s5434,s5435]) (hints := [8645,8645,0,8653,9677,1,9669,9677,2,8645,8645,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5424,s5425,s5434,s5435], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5424) (b5424) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5425) (b5425) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5434) (b5434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5435) (b5435) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i17 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5436,s1164,s5437,s5438]) (hints := [905,905,0,9677,9677,1,9677,9677,2,905,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5436,s1164,s5437,s5438], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5436) (b5436) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1164) (b1164) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5437) (b5437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5438) (b5438) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i18 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i19 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i20 : PetersenLocalChildren.PairOK tgt 8 s5260 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i21 : PetersenLocalChildren.PairOK tgt 8 s5260 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5213,s5439,s5215,s5440]) (hints := [6966,6966,0,5934,5934,1,5934,5934,2,6966,6966,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5213,s5439,s5215,s5440], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5213) (b5213) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5439) (b5439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5215) (b5215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5440) (b5440) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i22 : PetersenLocalChildren.PairOK tgt 8 s5260 (word0,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5441,s3207,s5442,s5443]) (hints := [6966,6966,0,5934,5934,1,5934,5934,2,6966,6966,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5441,s3207,s5442,s5443], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5441) (b5441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3207) (b3207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5442) (b5442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5443) (b5443) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i23 : PetersenLocalChildren.PairOK tgt 8 s5260 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i24 : PetersenLocalChildren.PairOK tgt 8 s5260 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i25 : PetersenLocalChildren.PairOK tgt 8 s5260 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i26 : PetersenLocalChildren.PairOK tgt 8 s5260 (word6,word14) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5267,s927,s4735,s5444]) (hints := [1673,2,1,1673,0,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s5267,s927,s4735,s5444], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5267) (b5267) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4735) (b4735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5444) (b5444) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i27 : PetersenLocalChildren.PairOK tgt 8 s5260 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5445,s5446,s5447,s5448]) (hints := [10437,0,10437,10445,1,11469,10437,2,10437,11461,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s5445,s5446,s5447,s5448], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5445) (b5445) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5446) (b5446) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5447) (b5447) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5448) (b5448) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i28 : PetersenLocalChildren.PairOK tgt 8 s5260 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5449,s5450,s5451,s5452]) (hints := [12485,0,12485,12493,1,13517,12485,2,12485,13509,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s5449,s5450,s5451,s5452], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5449) (b5449) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5450) (b5450) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5451) (b5451) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5452) (b5452) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i29 : PetersenLocalChildren.PairOK tgt 8 s5260 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5453,s5454,s5461,s5462]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s5453,s5454,s5461,s5462], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5453) (b5453) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5454) (b5454) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5461) (b5461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5462) (b5462) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i30 : PetersenLocalChildren.PairOK tgt 8 s5260 (word14,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5463,s5464,s5465,s5466]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s5463,s5464,s5465,s5466], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5463) (b5463) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5464) (b5464) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5465) (b5465) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5466) (b5466) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i31 : PetersenLocalChildren.PairOK tgt 8 s5260 (word14,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5467,s5468,s5469,s5470]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s5467,s5468,s5469,s5470], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5467) (b5467) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5468) (b5468) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5469) (b5469) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5470) (b5470) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i32 : PetersenLocalChildren.PairOK tgt 8 s5260 (word14,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5471,s5472,s5475,s5476]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s5471,s5472,s5475,s5476], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5471) (b5471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5472) (b5472) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5475) (b5475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5476) (b5476) <|
    PetersenLocalChildren.nil
private theorem thetaPair5260i33 : PetersenLocalChildren.PairOK tgt 8 s5260 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i34 : PetersenLocalChildren.PairOK tgt 8 s5260 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair5260i35 : PetersenLocalChildren.PairOK tgt 8 s5260 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b5260 : Blocked tgt 9 s5260 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word14),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word14),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word14),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word14),(word0,word5),(word0,word2),(word0,word4),(word6,word14),(word6,word5),(word6,word2),(word6,word4),(word14,word5),(word14,word2),(word14,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s5260 p
  exact
    PetersenLocalChildren.push thetaPair5260i0 <|
    PetersenLocalChildren.push thetaPair5260i1 <|
    PetersenLocalChildren.push thetaPair5260i2 <|
    PetersenLocalChildren.push thetaPair5260i3 <|
    PetersenLocalChildren.push thetaPair5260i4 <|
    PetersenLocalChildren.push thetaPair5260i5 <|
    PetersenLocalChildren.push thetaPair5260i6 <|
    PetersenLocalChildren.push thetaPair5260i7 <|
    PetersenLocalChildren.push thetaPair5260i8 <|
    PetersenLocalChildren.push thetaPair5260i9 <|
    PetersenLocalChildren.push thetaPair5260i10 <|
    PetersenLocalChildren.push thetaPair5260i11 <|
    PetersenLocalChildren.push thetaPair5260i12 <|
    PetersenLocalChildren.push thetaPair5260i13 <|
    PetersenLocalChildren.push thetaPair5260i14 <|
    PetersenLocalChildren.push thetaPair5260i15 <|
    PetersenLocalChildren.push thetaPair5260i16 <|
    PetersenLocalChildren.push thetaPair5260i17 <|
    PetersenLocalChildren.push thetaPair5260i18 <|
    PetersenLocalChildren.push thetaPair5260i19 <|
    PetersenLocalChildren.push thetaPair5260i20 <|
    PetersenLocalChildren.push thetaPair5260i21 <|
    PetersenLocalChildren.push thetaPair5260i22 <|
    PetersenLocalChildren.push thetaPair5260i23 <|
    PetersenLocalChildren.push thetaPair5260i24 <|
    PetersenLocalChildren.push thetaPair5260i25 <|
    PetersenLocalChildren.push thetaPair5260i26 <|
    PetersenLocalChildren.push thetaPair5260i27 <|
    PetersenLocalChildren.push thetaPair5260i28 <|
    PetersenLocalChildren.push thetaPair5260i29 <|
    PetersenLocalChildren.push thetaPair5260i30 <|
    PetersenLocalChildren.push thetaPair5260i31 <|
    PetersenLocalChildren.push thetaPair5260i32 <|
    PetersenLocalChildren.push thetaPair5260i33 <|
    PetersenLocalChildren.push thetaPair5260i34 <|
    PetersenLocalChildren.push thetaPair5260i35 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
