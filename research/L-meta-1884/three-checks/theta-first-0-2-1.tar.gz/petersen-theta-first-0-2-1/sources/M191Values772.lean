import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv772_4260 : PetersenPackedPin.project r772 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv772_4814 : PetersenPackedPin.project r772 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv772_5473 : PetersenPackedPin.project r772 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv772_6170 : PetersenPackedPin.project r772 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv772_6790 : PetersenPackedPin.project r772 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv772_7474 : PetersenPackedPin.project r772 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv772_8012 : PetersenPackedPin.project r772 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv772_1734 : PetersenPackedPin.project r772 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv772_4260 pv772_6790 rfl rfl
theorem pv772_2963 : PetersenPackedPin.project r772 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0xf0f0000 := PetersenWireProjection.derive 2 pv772_5473 pv772_7474 rfl rfl
theorem pv772_7095 : PetersenPackedPin.project r772 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv772_4260 pv772_6790 rfl rfl
theorem pv772_7855 : PetersenPackedPin.project r772 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv772_6170 pv772_7474 rfl rfl
theorem pv772_7944 : PetersenPackedPin.project r772 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv772_6790 pv772_7474 rfl rfl
theorem pv772_2988 : PetersenPackedPin.project r772 (0xf0f0f0f0f000f000f0f0f0f0f000f00 : BitVec 128) = 0xf0f0000 := PetersenWireProjection.derive 2 pv772_5473 pv772_7855 rfl rfl
end PetersenSmallStarts.M191.Residual
