import higher.WireProjection
import M191StartPreferredCuts6
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv788_4260 : PetersenPackedPin.project r788 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv788_4814 : PetersenPackedPin.project r788 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv788_5473 : PetersenPackedPin.project r788 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv788_6790 : PetersenPackedPin.project r788 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv788_7474 : PetersenPackedPin.project r788 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
end PetersenSmallStarts.M191.Residual
