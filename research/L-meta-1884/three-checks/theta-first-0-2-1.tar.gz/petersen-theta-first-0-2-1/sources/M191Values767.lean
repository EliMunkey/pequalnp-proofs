import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv767_4260 : PetersenPackedPin.project r767 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv767_4814 : PetersenPackedPin.project r767 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv767_5473 : PetersenPackedPin.project r767 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv767_6170 : PetersenPackedPin.project r767 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv767_6790 : PetersenPackedPin.project r767 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv767_7474 : PetersenPackedPin.project r767 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv767_8012 : PetersenPackedPin.project r767 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv767_1734 : PetersenPackedPin.project r767 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv767_4260 pv767_6790 rfl rfl
theorem pv767_3004 : PetersenPackedPin.project r767 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0xf000f00 := PetersenWireProjection.derive 2 pv767_5473 pv767_8012 rfl rfl
theorem pv767_7095 : PetersenPackedPin.project r767 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv767_4260 pv767_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
