import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values11
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values35
import M191Values5
import M191Values731
import M191Values735
import M191Values740
import M191Values741
import M191Values745
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows60
import M191StartPreferredRows61
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12940 : Blocked tgt 8 s12940 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12940 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2192 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8331 rfl))))))))) (by decide +kernel)
theorem b12941 : Blocked tgt 8 s12941 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12941 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_581 (PetersenWireProjection.cons pv2_2192 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)

theorem b12942 : Blocked tgt 8 s12942 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12942 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_2192 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12943 : Blocked tgt 8 s12943 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s12943 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2192 (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7397 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b12944 : Blocked tgt 8 s12944 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12944 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_2192 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8377 rfl))))))))) (by decide +kernel)
theorem b12945 : Blocked tgt 8 s12945 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s12945 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_630 (PetersenWireProjection.cons pv11_2192 (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b12946 : Blocked tgt 8 s12946 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12946 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_2192 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b12951 : Blocked tgt 8 s12951 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(0,false),(4,false))] s12951 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffaaaaffffaaaaffffaaaaffffaaaa,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7095 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b12952 : Blocked tgt 8 s12952 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12952 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12953 : Blocked tgt 8 s12953 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(3,false))] s12953 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffaaffaaffaaffaa,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7095 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b12954 : Blocked tgt 8 s12954 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(3,false))] s12954 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffaaffaaffaaffaa,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7095 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b12955 : Blocked tgt 8 s12955 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12955 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12956 : Blocked tgt 8 s12956 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12956 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12957 : Blocked tgt 8 s12957 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12957 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12958 : Blocked tgt 8 s12958 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12958 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12959 : Blocked tgt 8 s12959 := by
  intro k le c
  apply rejects_sound r731 (0xa0a0a0a0 :: i5) 6 tgt small731 hot731 [] s12959 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv731_4260 (PetersenWireProjection.cons pv731_4814 (PetersenWireProjection.cons pv731_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r731 (0xf5f5a0a0f5f5a0a0f5f5a0a0f5f5a0a0 : BitVec 128) = 0xa0a0a0a0) (PetersenWireProjection.cons pv731_6170 (PetersenWireProjection.cons pv731_6790 (PetersenWireProjection.cons pv731_7474 (PetersenWireProjection.cons pv731_8012 rfl)))))))) (by decide +kernel)
theorem b12960 : Blocked tgt 8 s12960 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12960 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5f5a0a0f5f5a0a0f5f5a0a0f5f5a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12961 : Blocked tgt 8 s12961 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12961 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5f5a0a0f5f5a0a0f5f5a0a0f5f5a0a0 : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b12962 : Blocked tgt 8 s12962 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(4,false))] s12962 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffffaaaa,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7095 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12963 : Blocked tgt 8 s12963 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(4,false))] s12963 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffffaaaa,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7095 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12964 : Blocked tgt 8 s12964 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(4,false))] s12964 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffffaaaa,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7095 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12965 : Blocked tgt 8 s12965 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(4,false))] s12965 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffffaaaa,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7095 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12966 : Blocked tgt 8 s12966 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12966 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12967 : Blocked tgt 8 s12967 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12967 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12968 : Blocked tgt 8 s12968 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12968 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4109 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12969 : Blocked tgt 8 s12969 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12969 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12970 : Blocked tgt 8 s12970 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12970 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12971 : Blocked tgt 8 s12971 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12971 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12976 : Blocked tgt 8 s12976 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12976 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12977 : Blocked tgt 8 s12977 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12977 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12978 : Blocked tgt 8 s12978 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12978 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12979 : Blocked tgt 8 s12979 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s12979 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4641 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b12980 : Blocked tgt 8 s12980 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s12980 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1579 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)

theorem b12981 : Blocked tgt 8 s12981 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12981 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3392 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12982 : Blocked tgt 8 s12982 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12982 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5335 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12983 : Blocked tgt 8 s12983 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12983 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6030 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12984 : Blocked tgt 8 s12984 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12984 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1617 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12985 : Blocked tgt 8 s12985 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12985 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2392 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12986 : Blocked tgt 8 s12986 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12986 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12987 : Blocked tgt 8 s12987 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12987 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7095 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12988 : Blocked tgt 8 s12988 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12988 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12989 : Blocked tgt 8 s12989 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s12989 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7025 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12990 : Blocked tgt 8 s12990 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12990 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7971 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12991 : Blocked tgt 8 s12991 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12991 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1316 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12992 : Blocked tgt 8 s12992 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s12992 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1631 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12993 : Blocked tgt 8 s12993 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s12993 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7067 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b12994 : Blocked tgt 8 s12994 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12994 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8352 rfl))))))))) (by decide +kernel)
theorem b12995 : Blocked tgt 8 s12995 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12995 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_603 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12996 : Blocked tgt 8 s12996 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s12996 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1646 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)

theorem b13033 : Blocked tgt 8 s13033 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13033 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7688 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b13095 : Blocked tgt 8 s13095 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13095 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_3209 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl))))))))) (by decide +kernel)
theorem b13194 : Blocked tgt 8 s13194 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13194 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2298 (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl))))))))) (by decide +kernel)
theorem b13205 : Blocked tgt 8 s13205 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13205 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_1829 (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl))))))))) (by decide +kernel)
theorem b13259 : Blocked tgt 8 s13259 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s13259 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 (PetersenWireProjection.cons pv19_8191 rfl))))))))) (by decide +kernel)
theorem b13310 : Blocked tgt 8 s13310 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13310 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 (PetersenWireProjection.cons pv35_8295 rfl))))))))) (by decide +kernel)
theorem b13331 : Blocked tgt 8 s13331 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s13331 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7944 (PetersenWireProjection.cons pv19_8012 (PetersenWireProjection.cons pv19_8191 rfl))))))))) (by decide +kernel)
theorem b13589 : Blocked tgt 8 s13589 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13589 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl))))))))) (by decide +kernel)
theorem b13591 : Blocked tgt 8 s13591 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13591 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_351 (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_3209 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl))))))))) (by decide +kernel)
theorem b13598 : Blocked tgt 8 s13598 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s13598 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_351 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b13610 : Blocked tgt 8 s13610 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s13610 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons pv745_5473 (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons pv745_6618 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl))))))))) (by decide +kernel)
theorem b13611 : Blocked tgt 8 s13611 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13611 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_351 (PetersenWireProjection.cons pv35_2298 (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl))))))))) (by decide +kernel)
theorem b13614 : Blocked tgt 8 s13614 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13614 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_351 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b13615 : Blocked tgt 8 s13615 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13615 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_351 (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b13630 : Blocked tgt 8 s13630 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s13630 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_351 (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b13634 : Blocked tgt 8 s13634 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13634 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_351 (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8295 rfl))))))))) (by decide +kernel)
theorem b13638 : Blocked tgt 8 s13638 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13638 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_351 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b13653 : Blocked tgt 8 s13653 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(1,false),(2,false))] s13653 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc) (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b13654 : Blocked tgt 8 s13654 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13654 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13655 : Blocked tgt 8 s13655 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13655 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13656 : Blocked tgt 8 s13656 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13656 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13657 : Blocked tgt 8 s13657 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13657 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4503 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5920 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13658 : Blocked tgt 8 s13658 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13658 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13659 : Blocked tgt 8 s13659 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s13659 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13660 : Blocked tgt 8 s13660 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s13660 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_4814 (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons pv741_5920 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xfefefefefefefefefefefefefefefefe : BitVec 128) = 0xeeeeeeeeeeeeeeee) (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl))))))))) (by decide +kernel)
theorem b13661 : Blocked tgt 8 s13661 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13661 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)

theorem b13662 : Blocked tgt 8 s13662 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13662 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13663 : Blocked tgt 8 s13663 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13663 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xf4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13664 : Blocked tgt 8 s13664 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13664 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xfcfcfcfc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13665 : Blocked tgt 8 s13665 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13665 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13666 : Blocked tgt 8 s13666 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13666 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xfcfcfcfc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13667 : Blocked tgt 8 s13667 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13667 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13668 : Blocked tgt 8 s13668 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(2,false))] s13668 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xfcfcfcfc,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5920 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13669 : Blocked tgt 8 s13669 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(2,false))] s13669 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_5920 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13670 : Blocked tgt 8 s13670 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(2,false))] s13670 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xfcfcfcfc,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5920 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13671 : Blocked tgt 8 s13671 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(2,false))] s13671 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_5920 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13672 : Blocked tgt 8 s13672 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13672 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13673 : Blocked tgt 8 s13673 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13673 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xa8a8a8a8a8a8a8a8a8a8a8a8a8a8a8a8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5920 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))))) (by decide +kernel)
theorem b13674 : Blocked tgt 8 s13674 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13674 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b13688 : Blocked tgt 8 s13688 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13688 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_3666 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5920 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))))) (by decide +kernel)
theorem b13689 : Blocked tgt 8 s13689 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13689 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffffcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_3666 (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl))))))))) (by decide +kernel)

theorem b13690 : Blocked tgt 8 s13690 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s13690 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4429 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5920 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b13691 : Blocked tgt 8 s13691 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s13691 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4429 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13692 : Blocked tgt 8 s13692 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s13692 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_2800 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13693 : Blocked tgt 8 s13693 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s13693 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5920 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b13702 : Blocked tgt 8 s13702 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13702 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2240 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5920 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13711 : Blocked tgt 8 s13711 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [] s13711 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5920 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b13712 : Blocked tgt 8 s13712 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s13712 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_2800 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13713 : Blocked tgt 8 s13713 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s13713 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5863 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13731 : Blocked tgt 8 s13731 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s13731 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2536 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13732 : Blocked tgt 8 s13732 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s13732 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5880 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
