import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv734_4260 : PetersenPackedPin.project r734 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv734_4814 : PetersenPackedPin.project r734 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv734_5473 : PetersenPackedPin.project r734 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv734_6170 : PetersenPackedPin.project r734 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv734_6790 : PetersenPackedPin.project r734 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv734_7474 : PetersenPackedPin.project r734 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv734_8012 : PetersenPackedPin.project r734 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv734_1734 : PetersenPackedPin.project r734 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv734_4260 pv734_6790 rfl rfl
theorem pv734_2192 : PetersenPackedPin.project r734 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv734_4260 pv734_6170 rfl rfl
theorem pv734_2708 : PetersenPackedPin.project r734 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv734_4260 pv734_5473 rfl rfl
theorem pv734_3209 : PetersenPackedPin.project r734 (0x30303030303030303030303030303030 : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 2 pv734_4814 pv734_5473 rfl rfl
theorem pv734_5850 : PetersenPackedPin.project r734 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv734_4260 pv734_5473 rfl rfl
theorem pv734_6504 : PetersenPackedPin.project r734 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv734_4260 pv734_6170 rfl rfl
theorem pv734_7095 : PetersenPackedPin.project r734 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv734_4260 pv734_6790 rfl rfl
theorem pv734_7235 : PetersenPackedPin.project r734 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xffffccccffffcccc := PetersenWireProjection.derive 3 pv734_5473 pv734_6790 rfl rfl
theorem pv734_3238 : PetersenPackedPin.project r734 (0x3030baba3030baba3030baba3030baba : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv734_1734 pv734_3209 rfl rfl
theorem pv734_3276 : PetersenPackedPin.project r734 (0x32323232323232323232323232323232 : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 2 pv734_4814 pv734_5850 rfl rfl
theorem pv734_4406 : PetersenPackedPin.project r734 (0xbabababababababababababababababa : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv734_3209 pv734_4260 rfl rfl
theorem pv734_5568 : PetersenPackedPin.project r734 (0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv734_1734 pv734_5473 rfl rfl
theorem pv734_5682 : PetersenPackedPin.project r734 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 2 pv734_2708 pv734_6170 rfl rfl
theorem pv734_6308 : PetersenPackedPin.project r734 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv734_2708 pv734_6170 rfl rfl
theorem pv734_3228 : PetersenPackedPin.project r734 (0x30303232303032323030323230303232 : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 1 pv734_3238 pv734_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
