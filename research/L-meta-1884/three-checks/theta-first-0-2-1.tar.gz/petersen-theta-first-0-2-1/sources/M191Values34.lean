import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv34_4260 : PetersenPackedPin.project r34 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv34_4814 : PetersenPackedPin.project r34 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv34_5473 : PetersenPackedPin.project r34 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv34_6170 : PetersenPackedPin.project r34 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv34_6790 : PetersenPackedPin.project r34 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv34_7474 : PetersenPackedPin.project r34 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv34_8012 : PetersenPackedPin.project r34 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv34_630 : PetersenPackedPin.project r34 (0xffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv34_7474 pv34_8012 rfl rfl
theorem pv34_1734 : PetersenPackedPin.project r34 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaa := PetersenWireProjection.derive 1 pv34_4260 pv34_6790 rfl rfl
theorem pv34_1829 : PetersenPackedPin.project r34 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv34_5473 pv34_6790 rfl rfl
theorem pv34_1925 : PetersenPackedPin.project r34 (0xffff000000000000ffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_6790 pv34_7474 rfl rfl
theorem pv34_2192 : PetersenPackedPin.project r34 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xa0a := PetersenWireProjection.derive 1 pv34_4260 pv34_6170 rfl rfl
theorem pv34_2708 : PetersenPackedPin.project r34 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv34_4260 pv34_5473 rfl rfl
theorem pv34_3427 : PetersenPackedPin.project r34 (0x33333333000000003333333300000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_4814 pv34_7474 rfl rfl
theorem pv34_3632 : PetersenPackedPin.project r34 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_4260 pv34_5473 rfl rfl
theorem pv34_3730 : PetersenPackedPin.project r34 (0x55555555000000005555555500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_4260 pv34_7474 rfl rfl
theorem pv34_3980 : PetersenPackedPin.project r34 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv34_4260 pv34_5473 rfl rfl
theorem pv34_5850 : PetersenPackedPin.project r34 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv34_4260 pv34_5473 rfl rfl
theorem pv34_7095 : PetersenPackedPin.project r34 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffaa := PetersenWireProjection.derive 3 pv34_4260 pv34_6790 rfl rfl
theorem pv34_7774 : PetersenPackedPin.project r34 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv34_5473 pv34_7474 rfl rfl
theorem pv34_8377 : PetersenPackedPin.project r34 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv34_7474 pv34_8012 rfl rfl
theorem pv34_1817 : PetersenPackedPin.project r34 (0xf0500000f0500000f0500000f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv34_1829 pv34_2192 rfl rfl
theorem pv34_3822 : PetersenPackedPin.project r34 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv34_3980 pv34_5850 rfl rfl
theorem pv34_5281 : PetersenPackedPin.project r34 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_2192 pv34_5473 rfl rfl
theorem pv34_5328 : PetersenPackedPin.project r34 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv34_1734 pv34_5473 rfl rfl
theorem pv34_5335 : PetersenPackedPin.project r34 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv34_5473 pv34_7095 rfl rfl
theorem pv34_7213 : PetersenPackedPin.project r34 (0xfffff050fffff050fffff050fffff050 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv34_1817 pv34_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
