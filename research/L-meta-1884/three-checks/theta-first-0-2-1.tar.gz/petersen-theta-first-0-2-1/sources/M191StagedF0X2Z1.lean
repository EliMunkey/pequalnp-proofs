import M191StagedF0X2Z1G70
import M191StagedF0X2Z1G95
import M191StartPreferredRows0
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: inputs 7) tgt 10 := by
  change NoAtMost [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] tgt 10
  apply PetersenFirstInputs.root (by decide) (by
    intro w h; simp only [List.mem_cons,List.not_mem_nil,or_false] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> rfl) (by decide) (by
    constructor
    · intro e; have x := congrFun e (3:Fin 128); change true=false at x; contradiction
    · intro e; have x := congrFun e (0:Fin 128); change false=true at x; contradiction)
    #[s0,s1] [386,387,387,387,388,2179,1667,2179,774,387,903,387,388,2179,1671,2179,1418,1419,1419,1419,1420,3211,1675,3211,774,1419,903,1419,1420,3211,2695,3211,2194,387,387,387,2452,4227,1667,4227,2710,387,903,387,2452,4227,1671,4227,1418,1419,1419,1419,1420,5259,1675,5259,2710,1419,903,1419,1420,5259,4743,5259,4258,387,387,387,4516,2179,1667,2179,4774,387,903,387,4516,2179,1671,2179,5290,1419,1419,1419,5548,3211,1675,3211,4774,1419,903,1419,5548,3211,2695,3211,6322,387,387,387,6580,6964,1667,1671,6838,387,903,387,6580,7476,1671,1671,5290,1419,1419,1419,5548,5932,1675,8839,6838,1419,903,1419,5548,13612,8839,8839,8642,8643,8643,8643,8644,10435,8899,10435,774,8643,903,8643,8644,10435,1671,10435,9674,9675,9675,9675,9676,11467,9931,11467,774,9675,903,9675,9676,11467,2695,11467,10450,8643,8643,8643,10708,12483,8899,12483,2710,8643,903,8643,10708,12483,1671,12483,9674,9675,9675,9675,9676,13515,9931,13515,2710,9675,903,9675,9676,13515,4743,13515,4258,8643,8643,8643,4516,10435,8899,10435,4774,8643,903,8643,4516,10435,1671,10435,5290,9675,9675,9675,5548,11467,9931,11467,4774,9675,903,9675,5548,11467,2695,11467,6322,8643,8643,8643,6580,6964,8899,1671,6838,8643,903,8643,6580,7476,1671,1671,5290,9675,9675,9675,5548,5932,9931,5932,6838,9675,903,9675,5548,6838,0,1] (by decide +kernel)
  change ∀ b ∈ [s0,s1], Blocked tgt 10 b
  exact
    PetersenLocalChildren.push (x := s0) b0 <|
    PetersenLocalChildren.push (x := s1) b1 <|
    PetersenLocalChildren.nil
#print axioms gate_0_2_1
end PetersenSmallStarts.M191.Staged
namespace PetersenSmallStarts.M191.Preferred
open PetersenWordCost PetersenMaskCofactor
theorem gate_0_2_1 : NoAtMost (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a :: inputs 7) tgt 10 := PetersenSmallStarts.M191.Staged.gate_0_2_1
#print axioms gate_0_2_1
end PetersenSmallStarts.M191.Preferred
