import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values13
import M191Values14
import M191Values2
import M191Values5
import M191Values737
import M191Values739
import M191Values753
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows29
import M191StartPreferredRows30
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b6587 : Blocked tgt 8 s6587 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6587 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6588 : Blocked tgt 8 s6588 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6588 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3677 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6589 : Blocked tgt 8 s6589 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6589 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6590 : Blocked tgt 8 s6590 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6590 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4109 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6591 : Blocked tgt 8 s6591 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6591 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6592 : Blocked tgt 8 s6592 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6592 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6593 : Blocked tgt 8 s6593 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6593 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b6594 : Blocked tgt 8 s6594 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6594 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6595 : Blocked tgt 8 s6595 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6595 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4137 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6596 : Blocked tgt 8 s6596 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6596 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4137 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6597 : Blocked tgt 8 s6597 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6597 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6598 : Blocked tgt 8 s6598 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6598 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1693 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6599 : Blocked tgt 8 s6599 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6599 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6600 : Blocked tgt 8 s6600 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6600 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6609 : Blocked tgt 8 s6609 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6609 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6610 : Blocked tgt 8 s6610 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6610 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_3730 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6611 : Blocked tgt 8 s6611 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6611 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6624 : Blocked tgt 8 s6624 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6624 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6625 : Blocked tgt 8 s6625 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6625 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_3759 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6626 : Blocked tgt 8 s6626 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6626 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4429 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6633 : Blocked tgt 8 s6633 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6633 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2800 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6634 : Blocked tgt 8 s6634 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s6634 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_3209 (PetersenWireProjection.cons pv753_4260 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl))))))))) (by decide +kernel)
theorem b6635 : Blocked tgt 8 s6635 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6635 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4522 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6636 : Blocked tgt 8 s6636 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6636 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6546 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6637 : Blocked tgt 8 s6637 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6637 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2240 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6638 : Blocked tgt 8 s6638 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6638 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3304 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6639 : Blocked tgt 8 s6639 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6639 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4586 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6672 : Blocked tgt 8 s6672 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6672 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6673 : Blocked tgt 8 s6673 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6673 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6674 : Blocked tgt 8 s6674 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6674 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_3359 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6675 : Blocked tgt 8 s6675 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6675 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6676 : Blocked tgt 8 s6676 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6676 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4622 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6677 : Blocked tgt 8 s6677 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6677 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xcccc0808cccc0808cccc0808cccc0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6678 : Blocked tgt 8 s6678 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6678 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7168 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6679 : Blocked tgt 8 s6679 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6679 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1762 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)

theorem b6680 : Blocked tgt 8 s6680 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6680 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xc4c40000c4c40000c4c40000c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6715 : Blocked tgt 8 s6715 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6715 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3368 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6716 : Blocked tgt 8 s6716 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6716 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4675 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6721 : Blocked tgt 8 s6721 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6721 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6722 : Blocked tgt 8 s6722 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6722 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_3427 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6723 : Blocked tgt 8 s6723 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6723 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4753 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6728 : Blocked tgt 8 s6728 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6728 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6729 : Blocked tgt 8 s6729 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6729 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_3485 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6730 : Blocked tgt 8 s6730 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6730 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6731 : Blocked tgt 8 s6731 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6731 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6618 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6732 : Blocked tgt 8 s6732 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6732 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2298 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6733 : Blocked tgt 8 s6733 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6733 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6734 : Blocked tgt 8 s6734 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6734 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)

theorem b6766 : Blocked tgt 8 s6766 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6766 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6767 : Blocked tgt 8 s6767 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6767 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6768 : Blocked tgt 8 s6768 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6768 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2906 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6769 : Blocked tgt 8 s6769 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6769 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2906 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6770 : Blocked tgt 8 s6770 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6770 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6771 : Blocked tgt 8 s6771 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6771 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7285 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6772 : Blocked tgt 8 s6772 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6772 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1829 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6773 : Blocked tgt 8 s6773 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6773 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2938 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6774 : Blocked tgt 8 s6774 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6774 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2938 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6775 : Blocked tgt 8 s6775 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6775 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6786 : Blocked tgt 8 s6786 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s6786 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_1177 (PetersenWireProjection.cons pv753_4260 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl))))))))) (by decide +kernel)
theorem b6787 : Blocked tgt 8 s6787 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6787 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6788 : Blocked tgt 8 s6788 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6788 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5425 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6793 : Blocked tgt 8 s6793 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s6793 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_456 (PetersenWireProjection.cons pv753_4260 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl))))))))) (by decide +kernel)
theorem b6794 : Blocked tgt 8 s6794 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6794 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_3004 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b6795 : Blocked tgt 8 s6795 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6795 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5978 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6796 : Blocked tgt 8 s6796 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6796 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7314 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6797 : Blocked tgt 8 s6797 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6797 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1887 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6798 : Blocked tgt 8 s6798 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6798 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2362 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6799 : Blocked tgt 8 s6799 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6799 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6007 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6800 : Blocked tgt 8 s6800 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6800 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6007 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6801 : Blocked tgt 8 s6801 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s6801 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_6897 (PetersenWireProjection.cons pv13_7330 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b6802 : Blocked tgt 8 s6802 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6802 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1841 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6803 : Blocked tgt 8 s6803 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6803 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1841 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6804 : Blocked tgt 8 s6804 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6804 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff000a00ff000a00ff000a00ff000a : BitVec 128) = 0xa0a0a0a) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6805 : Blocked tgt 8 s6805 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6805 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff000a00ff000a00ff000a00ff000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6806 : Blocked tgt 8 s6806 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6806 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6055 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6807 : Blocked tgt 8 s6807 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6807 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6808 : Blocked tgt 8 s6808 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6808 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1252 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)

theorem b6809 : Blocked tgt 8 s6809 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6809 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff00ff0000000000ff00ff00000000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6810 : Blocked tgt 8 s6810 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6810 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6120 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6811 : Blocked tgt 8 s6811 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6811 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 (PetersenWireProjection.cons pv737_8295 rfl))))))))) (by decide +kernel)
theorem b6812 : Blocked tgt 8 s6812 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6812 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_531 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6813 : Blocked tgt 8 s6813 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6813 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00ff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b6814 : Blocked tgt 8 s6814 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s6814 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffff0a0affff0a0affff0a0affff0a0a,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xffff0a0affff0a0affff0a0affff0a0a) (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b6815 : Blocked tgt 8 s6815 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6815 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6816 : Blocked tgt 8 s6816 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6816 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6817 : Blocked tgt 8 s6817 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6817 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6818 : Blocked tgt 8 s6818 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6818 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6671 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6852 : Blocked tgt 8 s6852 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6852 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6853 : Blocked tgt 8 s6853 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6853 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_1294 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6854 : Blocked tgt 8 s6854 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6854 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6855 : Blocked tgt 8 s6855 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6855 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1925 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6856 : Blocked tgt 8 s6856 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6856 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6738 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6857 : Blocked tgt 8 s6857 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6857 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8331 rfl))))))))) (by decide +kernel)
theorem b6858 : Blocked tgt 8 s6858 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6858 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_581 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6859 : Blocked tgt 8 s6859 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6859 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6860 : Blocked tgt 8 s6860 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6860 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_6886 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6861 : Blocked tgt 8 s6861 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6861 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0a00000000ffff0a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6888 : Blocked tgt 8 s6888 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6888 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b6917 : Blocked tgt 8 s6917 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6917 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b6918 : Blocked tgt 8 s6918 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6918 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1844 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
