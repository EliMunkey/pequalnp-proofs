import higher.WireProjection
import M191Values1
import M191Values14
import M191Values17
import M191Values2
import M191Values21
import M191Values22
import M191Values30
import M191Values32
import M191Values35
import M191Values734
import M191Values735
import M191Values741
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts6
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows61
import M191StartPreferredRows62
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12851 : Blocked tgt 7 s12851 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12851 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffffffffffffffff0aaa0aaa0aaa0aaa : BitVec 128) = 0xffffffff00000000) rfl)))))))) (by decide +kernel)
theorem b12852 : Blocked tgt 7 s12852 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12852 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5f5f5f5f5f5f5f500a000a000a000a0 : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12853 : Blocked tgt 7 s12853 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12853 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8079 (PetersenWireProjection.cons pv35_8208 rfl)))))))) (by decide +kernel)
theorem b12854 : Blocked tgt 7 s12854 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12854 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8079 rfl)))))))) (by decide +kernel)
theorem b12855 : Blocked tgt 7 s12855 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12855 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3494 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b12856 : Blocked tgt 7 s12856 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12856 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5425 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8079 rfl)))))))) (by decide +kernel)
theorem b12857 : Blocked tgt 7 s12857 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12857 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_456 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8079 rfl)))))))) (by decide +kernel)
theorem b12858 : Blocked tgt 7 s12858 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12858 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f000a000a000a000a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12859 : Blocked tgt 7 s12859 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12859 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_443 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12860 : Blocked tgt 7 s12860 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12860 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8079 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b12861 : Blocked tgt 7 s12861 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12861 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2461 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8079 rfl)))))))) (by decide +kernel)
theorem b12862 : Blocked tgt 7 s12862 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12862 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8079 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b12863 : Blocked tgt 7 s12863 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12863 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8079 rfl)))))))) (by decide +kernel)
theorem b12864 : Blocked tgt 7 s12864 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12864 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8079 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b12865 : Blocked tgt 7 s12865 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12865 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8079 rfl)))))))) (by decide +kernel)
theorem b12866 : Blocked tgt 7 s12866 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12866 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_130 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8079 rfl)))))))) (by decide +kernel)
theorem b12904 : Blocked tgt 7 s12904 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s12904 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_2748 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b13093 : Blocked tgt 7 s13093 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13093 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x5454545454545454 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13099 : Blocked tgt 7 s13099 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13099 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffffffccffccffccffcc : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)

theorem b13107 : Blocked tgt 7 s13107 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10832,5930,6960,5930,9672,6964,6964,4900,6964,7218,7732,6964,4916,4916,6964,7466,2836,2868,6932,2836,6964,1480,8709,6964,6836,9672,6836,6964,9674,5930,5930,5672,6962,4906,7474,6962,5930,4914,7466,5930,10058,1834,13642,10058,5930,1994,10058,5930,5930,10058,6058,5930,10706,7474,8650,7474,9674,7466,8658,7466,9674,13642,4741,9674,8709,9674,1482,1482,5546,5546,9674,6836,5668,7466,7458,7458,11602,3378,14674,11602,7474,11602,11602,7474,7474,11602,11602,7474,11594,3370,13642,11594,7466,11594,11594,7466,7466,11594,11594,7466,4741,13642,13642,4741,2708,13642,13642,6804,13610,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b13189 : Blocked tgt 7 s13189 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13189 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6618 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 (PetersenWireProjection.cons pv35_8295 rfl)))))))) (by decide +kernel)

theorem b13191 : Blocked tgt 7 s13191 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13191 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfff0fff0fff0fff0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl)))))))) (by decide +kernel)
theorem b13193 : Blocked tgt 7 s13193 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13193 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x5550555055505550 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13202 : Blocked tgt 7 s13202 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13202 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfffff0f0fffff0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl)))))))) (by decide +kernel)
theorem b13204 : Blocked tgt 7 s13204 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s13204 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0x5555505055555050 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_2708 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b13291 : Blocked tgt 7 s13291 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,2256,8709,1482,10448,1482,6964,10448,5672,1673,10448,458,3280,3280,7208,3209,7208,3209,13321,5257,5320,5257,5288,5288,1417,1417,5930,5672,5930,5672,7474,11344,7474,7732,2177,3209,2177,3209,4225,5257,4225,5257,13610,8709,13610,14900,385,5930,5672,385,385,7474,1409,385,3209,4916,3209,385,5257,2868,5257,385,13352,385,385,6964,10832,5672,3792,3792,3209,8784,3209,5672,5257,1576,5257,1736,5672,1608,5800,5672,10377,3209,3265,3209,12425,5257,5313,5257,3152,3152,11344,13352,3209,3112,5257,3209,7208,3209,3209,7208,2708,5257,5257,13320]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b13676 : Blocked tgt 7 s13676 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13676 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3666 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13677 : Blocked tgt 7 s13677 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13677 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffffcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0x5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e : BitVec 128) = 0xffffffffcccccccc) (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b13678 : Blocked tgt 7 s13678 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13678 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x2020202020202020202020202020202 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_3666 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13679 : Blocked tgt 7 s13679 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13679 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3666 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5850 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13680 : Blocked tgt 7 s13680 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13680 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffffcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_3666 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5850 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b13681 : Blocked tgt 7 s13681 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13681 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffffcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_3666 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b13682 : Blocked tgt 7 s13682 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13682 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_3666 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5682 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13683 : Blocked tgt 7 s13683 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s13683 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffffcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_3666 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xf0f0f0f0f0f0f0f0) rfl)))))))) (by decide +kernel)
theorem b13684 : Blocked tgt 7 s13684 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s13684 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0x54545454545454545454545454545454 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_5745 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 rfl)))))))) (by decide +kernel)
theorem b13685 : Blocked tgt 7 s13685 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s13685 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xdcdcdcdcdcdcdcdcdcdcdcdcdcdcdcdc : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b13686 : Blocked tgt 7 s13686 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13686 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff54ff54ff54ff54ff54ff54ff54ff54 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13687 : Blocked tgt 7 s13687 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s13687 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xffffffffffffffff5454545454545454 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b13695 : Blocked tgt 7 s13695 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s13695 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_5920 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b13696 : Blocked tgt 7 s13696 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13696 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6546 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13697 : Blocked tgt 7 s13697 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s13697 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13698 : Blocked tgt 7 s13698 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13698 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xfcfcfcfc,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6546 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13699 : Blocked tgt 7 s13699 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13699 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_5920 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13700 : Blocked tgt 7 s13700 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s13700 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13701 : Blocked tgt 7 s13701 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s13701 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfcccfcccfcccfcccfcccfcccfcccfccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13715 : Blocked tgt 7 s13715 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13715 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffcfffcfffcfffcfffcfffcfffcfffc : BitVec 128) = 0xfcfcfcfc) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13716 : Blocked tgt 7 s13716 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13716 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2670 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13717 : Blocked tgt 7 s13717 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13717 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5f4f5f4f5f4f5f4f5f4f5f4f5f4f5f4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13718 : Blocked tgt 7 s13718 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13718 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaa8aaa8aaa8aaa8aaa8aaa8aaa8aaa8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13719 : Blocked tgt 7 s13719 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13719 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x55545554555455545554555455545554 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13721 : Blocked tgt 7 s13721 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13721 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80008000800080008000800080008 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13727 : Blocked tgt 7 s13727 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s13727 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xa020a020a020a020a020a020a020a02 : BitVec 128) = 0x2222222222222222) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13728 : Blocked tgt 7 s13728 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13728 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2163 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13729 : Blocked tgt 7 s13729 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s13729 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfcfcfcfc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfc00fc00fc00fc00fc00fc00fc00fc : BitVec 128) = 0xfcfcfcfc) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13730 : Blocked tgt 7 s13730 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s13730 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xfc00fc00fc00fc00fc00fc00fc00fc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_4260 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_5745 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 rfl)))))))) (by decide +kernel)
theorem b13785 : Blocked tgt 7 s13785 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(1,false),(2,false))] s13785 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0xfcfcfcfcfcfcfcfc) (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13786 : Blocked tgt 7 s13786 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [(true,(0,false),(1,false))] s13786 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0x2020202020202020202020202020202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0xaaaaaaaaeeeeeeee) (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b13787 : Blocked tgt 7 s13787 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s13787 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b13788 : Blocked tgt 7 s13788 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(1,true),(2,false))] s13788 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x30303030,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0x30303030) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13789 : Blocked tgt 7 s13789 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s13789 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xff3aff3aff3aff3aff3aff3aff3aff3a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b13790 : Blocked tgt 7 s13790 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(1,true),(2,false))] s13790 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x30303030,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf530f530f530f530f530f530f530f530 : BitVec 128) = 0x30303030) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13791 : Blocked tgt 7 s13791 := by
  intro k le c
  apply rejects_sound r786 (0x30303030 :: i5) 6 tgt small786 hot786 [(true,(0,false),(4,false))] s13791 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xff30ff30,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0xff30ff30) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)

theorem b13792 : Blocked tgt 7 s13792 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [(true,(0,false),(1,false))] s13792 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0x22222222222222222222222222222222 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xff30ff30ff30ff30ff30ff30ff30ff30 : BitVec 128) = 0xaaaaaaaaeeeeeeee) (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b13793 : Blocked tgt 7 s13793 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13793 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaa20aa20aa20aa20aa20aa20aa20aa20 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13794 : Blocked tgt 7 s13794 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13794 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x55105510551055105510551055105510 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13824 : Blocked tgt 7 s13824 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s13824 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xeeeeeeeeeeeeeeee,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0x3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a3a : BitVec 128) = 0xeeeeeeeeeeeeeeee) (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b13825 : Blocked tgt 7 s13825 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s13825 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0x30303030303030303030303030303030 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b13826 : Blocked tgt 7 s13826 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(1,true),(2,false))] s13826 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x30303030,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3209 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)

theorem b13827 : Blocked tgt 7 s13827 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(1,true),(2,false))] s13827 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x30303030,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3209 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13828 : Blocked tgt 7 s13828 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s13828 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x4444444444444444,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a08080a0a08080a0a08080a0a0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_3209 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13829 : Blocked tgt 7 s13829 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s13829 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x4444444444444444,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_3209 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13830 : Blocked tgt 7 s13830 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s13830 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5061 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13860 : Blocked tgt 7 s13860 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s13860 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13861 : Blocked tgt 7 s13861 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13861 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13862 : Blocked tgt 7 s13862 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13862 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x22222222222222222222222222222222 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13863 : Blocked tgt 7 s13863 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s13863 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13864 : Blocked tgt 7 s13864 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13864 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa080a080a080a080a080a080a080a080 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b13865 : Blocked tgt 7 s13865 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13865 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13866 : Blocked tgt 7 s13866 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13866 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2744 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b13867 : Blocked tgt 7 s13867 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13867 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xa2a0a2a0a2a0a2a0a2a0a2a0a2a0a2a : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13868 : Blocked tgt 7 s13868 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13868 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2744 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13869 : Blocked tgt 7 s13869 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13869 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13870 : Blocked tgt 7 s13870 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13870 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2192 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13871 : Blocked tgt 7 s13871 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13871 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3677 (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13872 : Blocked tgt 7 s13872 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13872 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13873 : Blocked tgt 7 s13873 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13873 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13874 : Blocked tgt 7 s13874 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13874 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xfdccfdccfdccfdccfdccfdccfdccfdcc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13875 : Blocked tgt 7 s13875 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13875 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xcccccccc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b13876 : Blocked tgt 7 s13876 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s13876 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b13877 : Blocked tgt 7 s13877 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13877 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13878 : Blocked tgt 7 s13878 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s13878 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4522 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xd0d0d0d0d0d0d0d0) (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13879 : Blocked tgt 7 s13879 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s13879 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2240 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xd0d0d0d0d0d0d0d0) (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13880 : Blocked tgt 7 s13880 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13880 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xaaaa,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)

theorem b13881 : Blocked tgt 7 s13881 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s13881 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0xaaaa,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b13883 : Blocked tgt 7 s13883 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13883 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_1117 (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13884 : Blocked tgt 7 s13884 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13884 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x5040504050405040504050405040504 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13885 : Blocked tgt 7 s13885 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13885 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6618 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13886 : Blocked tgt 7 s13886 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s13886 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b13887 : Blocked tgt 7 s13887 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13887 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b13888 : Blocked tgt 7 s13888 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13888 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
