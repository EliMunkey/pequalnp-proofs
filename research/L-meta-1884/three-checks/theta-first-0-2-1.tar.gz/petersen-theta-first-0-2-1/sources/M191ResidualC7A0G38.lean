import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts4
import M191StartPreferredRows26
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b5874 : Blocked tgt 7 s5874 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5874 7 _ le
  decide +kernel
theorem b5875 : Blocked tgt 7 s5875 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5875 7 _ le
  decide +kernel
theorem b5876 : Blocked tgt 7 s5876 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5876 7 _ le
  decide +kernel
theorem b5877 : Blocked tgt 7 s5877 := by
  intro k le c
  apply rejects_sound r760 (0xf000f0 :: i5) 6 tgt small760 hot760 [(true,(1,false),(4,false))] s5877 7 _ le
  decide +kernel
theorem b5878 : Blocked tgt 7 s5878 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5878 7 _ le
  decide +kernel
theorem b5879 : Blocked tgt 7 s5879 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5879 7 _ le
  decide +kernel
theorem b5880 : Blocked tgt 7 s5880 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5880 7 _ le
  decide +kernel
theorem b5881 : Blocked tgt 7 s5881 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5881 7 _ le
  decide +kernel
theorem b5882 : Blocked tgt 7 s5882 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5882 7 _ le
  decide +kernel
theorem b5883 : Blocked tgt 7 s5883 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5883 7 _ le
  decide +kernel
theorem b5884 : Blocked tgt 7 s5884 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5884 7 _ le
  decide +kernel

theorem b5885 : Blocked tgt 7 s5885 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5885 7 _ le
  decide +kernel
theorem b5886 : Blocked tgt 7 s5886 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5886 7 _ le
  decide +kernel
theorem b5887 : Blocked tgt 7 s5887 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5887 7 _ le
  decide +kernel
theorem b5888 : Blocked tgt 7 s5888 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5888 7 _ le
  decide +kernel
theorem b5889 : Blocked tgt 7 s5889 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5889 7 _ le
  decide +kernel
theorem b5890 : Blocked tgt 7 s5890 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5890 7 _ le
  decide +kernel
theorem b5891 : Blocked tgt 7 s5891 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5891 7 _ le
  decide +kernel
theorem b5892 : Blocked tgt 7 s5892 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5892 7 _ le
  decide +kernel
theorem b5893 : Blocked tgt 7 s5893 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5893 7 _ le
  decide +kernel
theorem b5894 : Blocked tgt 7 s5894 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5894 7 _ le
  decide +kernel
theorem b5895 : Blocked tgt 7 s5895 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s5895 7 _ le
  decide +kernel
theorem b5896 : Blocked tgt 7 s5896 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5896 7 _ le
  decide +kernel
theorem b5897 : Blocked tgt 7 s5897 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5897 7 _ le
  decide +kernel
theorem b5898 : Blocked tgt 7 s5898 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5898 7 _ le
  decide +kernel
theorem b5899 : Blocked tgt 7 s5899 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5899 7 _ le
  decide +kernel
theorem b5900 : Blocked tgt 7 s5900 := by
  intro k le c
  apply rejects_sound r738 (0xf000f000f000f0 :: i6) 6 tgt small738 hot738 [] s5900 7 _ le
  decide +kernel

theorem b5901 : Blocked tgt 7 s5901 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5901 7 _ le
  decide +kernel
theorem b5902 : Blocked tgt 7 s5902 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5902 7 _ le
  decide +kernel
theorem b5903 : Blocked tgt 7 s5903 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5903 7 _ le
  decide +kernel
theorem b5922 : Blocked tgt 7 s5922 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5922 7 _ le
  decide +kernel
theorem b5923 : Blocked tgt 7 s5923 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5923 7 _ le
  decide +kernel
theorem b5924 : Blocked tgt 7 s5924 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5924 7 _ le
  decide +kernel
theorem b5925 : Blocked tgt 7 s5925 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5925 7 _ le
  decide +kernel
theorem b5926 : Blocked tgt 7 s5926 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5926 7 _ le
  decide +kernel
theorem b5927 : Blocked tgt 7 s5927 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5927 7 _ le
  decide +kernel
theorem b5928 : Blocked tgt 7 s5928 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5928 7 _ le
  decide +kernel
theorem b5929 : Blocked tgt 7 s5929 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5929 7 _ le
  decide +kernel
theorem b5930 : Blocked tgt 7 s5930 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5930 7 _ le
  decide +kernel
theorem b5931 : Blocked tgt 7 s5931 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5931 7 _ le
  decide +kernel
theorem b5932 : Blocked tgt 7 s5932 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5932 7 _ le
  decide +kernel
theorem b5933 : Blocked tgt 7 s5933 := by
  intro k le c
  apply rejects_sound r763 (0x30303030 :: i5) 6 tgt small763 hot763 [(true,(2,false),(5,false))] s5933 7 _ le
  decide +kernel
theorem b5934 : Blocked tgt 7 s5934 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5934 7 _ le
  decide +kernel
theorem b5935 : Blocked tgt 7 s5935 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5935 7 _ le
  decide +kernel
theorem b5936 : Blocked tgt 7 s5936 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5936 7 _ le
  decide +kernel
theorem b5937 : Blocked tgt 7 s5937 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5937 7 _ le
  decide +kernel
theorem b5938 : Blocked tgt 7 s5938 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5938 7 _ le
  decide +kernel
theorem b5939 : Blocked tgt 7 s5939 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5939 7 _ le
  decide +kernel
theorem b5940 : Blocked tgt 7 s5940 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5940 7 _ le
  decide +kernel
theorem b5941 : Blocked tgt 7 s5941 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5941 7 _ le
  decide +kernel
theorem b5942 : Blocked tgt 7 s5942 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5942 7 _ le
  decide +kernel
theorem b5943 : Blocked tgt 7 s5943 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5943 7 _ le
  decide +kernel
theorem b5944 : Blocked tgt 7 s5944 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5944 7 _ le
  decide +kernel
theorem b5945 : Blocked tgt 7 s5945 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5945 7 _ le
  decide +kernel
theorem b5946 : Blocked tgt 7 s5946 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5946 7 _ le
  decide +kernel
theorem b5947 : Blocked tgt 7 s5947 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5947 7 _ le
  decide +kernel
theorem b5948 : Blocked tgt 7 s5948 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5948 7 _ le
  decide +kernel
theorem b5949 : Blocked tgt 7 s5949 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5949 7 _ le
  decide +kernel
theorem b5950 : Blocked tgt 7 s5950 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5950 7 _ le
  decide +kernel

theorem b5951 : Blocked tgt 7 s5951 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5951 7 _ le
  decide +kernel
theorem b5952 : Blocked tgt 7 s5952 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5952 7 _ le
  decide +kernel
theorem b5953 : Blocked tgt 7 s5953 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5953 7 _ le
  decide +kernel
theorem b5954 : Blocked tgt 7 s5954 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5954 7 _ le
  decide +kernel
theorem b5955 : Blocked tgt 7 s5955 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5955 7 _ le
  decide +kernel
theorem b5956 : Blocked tgt 7 s5956 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(3,false))] s5956 7 _ le
  decide +kernel
theorem b5957 : Blocked tgt 7 s5957 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5957 7 _ le
  decide +kernel
theorem b5958 : Blocked tgt 7 s5958 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5958 7 _ le
  decide +kernel
theorem b5959 : Blocked tgt 7 s5959 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5959 7 _ le
  decide +kernel
theorem b5960 : Blocked tgt 7 s5960 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5960 7 _ le
  decide +kernel
theorem b5961 : Blocked tgt 7 s5961 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5961 7 _ le
  decide +kernel
theorem b5962 : Blocked tgt 7 s5962 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5962 7 _ le
  decide +kernel
theorem b5963 : Blocked tgt 7 s5963 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5963 7 _ le
  decide +kernel
theorem b5968 : Blocked tgt 7 s5968 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5968 7 _ le
  decide +kernel
theorem b5969 : Blocked tgt 7 s5969 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5969 7 _ le
  decide +kernel
theorem b5970 : Blocked tgt 7 s5970 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5970 7 _ le
  decide +kernel

theorem b5971 : Blocked tgt 7 s5971 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5971 7 _ le
  decide +kernel
theorem b5972 : Blocked tgt 7 s5972 := by
  intro k le c
  apply rejects_sound r761 (0x55005500 :: i5) 6 tgt small761 hot761 [(true,(2,false),(4,false))] s5972 7 _ le
  decide +kernel
theorem b5973 : Blocked tgt 7 s5973 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5973 7 _ le
  decide +kernel
theorem b5974 : Blocked tgt 7 s5974 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5974 7 _ le
  decide +kernel
theorem b5975 : Blocked tgt 7 s5975 := by
  intro k le c
  apply rejects_sound r765 (0x3300 :: i4) 3 tgt small765 hot765 [] s5975 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
