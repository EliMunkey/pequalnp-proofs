import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv775_4260 : PetersenPackedPin.project r775 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv775_4814 : PetersenPackedPin.project r775 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv775_5473 : PetersenPackedPin.project r775 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv775_6170 : PetersenPackedPin.project r775 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv775_6790 : PetersenPackedPin.project r775 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv775_7474 : PetersenPackedPin.project r775 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv775_8012 : PetersenPackedPin.project r775 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv775_630 : PetersenPackedPin.project r775 (0xffffffff00000000 : BitVec 128) = 0xff0000 := PetersenWireProjection.derive 1 pv775_7474 pv775_8012 rfl rfl
theorem pv775_6504 : PetersenPackedPin.project r775 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv775_4260 pv775_6170 rfl rfl
theorem pv775_7095 : PetersenPackedPin.project r775 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv775_4260 pv775_6790 rfl rfl
theorem pv775_7855 : PetersenPackedPin.project r775 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv775_6170 pv775_7474 rfl rfl
theorem pv775_8295 : PetersenPackedPin.project r775 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv775_6170 pv775_8012 rfl rfl
theorem pv775_673 : PetersenPackedPin.project r775 (0xffffffffff00ff00 : BitVec 128) = 0xff0000 := PetersenWireProjection.derive 1 pv775_7855 pv775_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
