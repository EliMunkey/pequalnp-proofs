import M63StartData
import M63StartL5B11
import M63StartPins0
import M63StartL5B12
import M63StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b388 : Blocked tgt 6 s388 := by
  apply PetersenFastNode.node (nxt := #[s389,s390,s391,s392,s393,s394]) (hints := [2474,3434,2474,459,2800,459,2474,2800,2474,3434,3434,459,2800,2800,2488,847,3434,847,3056,3434,2488,2800,2800,847,3320,3320,3768,2288,2800,843,3768,2800,3768,3320,3320,843,2800,2800,3760,2296,3320,1355,3760,3320,3760,2800,2800,1355,720,720,0,752,2800,2379,2768,2800,1,720,720,2379,719,719,847,203,459,2488,847,459,847,719,719,2488,459,459,843,207,719,3768,843,719,843,459,459,3768,459,459,1355,2474,2474,3760,1355,2474,1355,459,459,3760,459,459,2379,426,2474,2,2379,2474,2379,459,459,3,2488,2488,3768,843,847,843,839,847,3768,839,2488,843,847,847,1615,1099,2488,1355,1615,2488,1615,847,847,1355,847,847,2639,2123,2488,2379,2639,2488,2639,847,847,2379,843,843,1355,1103,3768,1615,1355,3768,1355,843,843,1615,843,843,2379,2127,3768,2639,2379,3768,2379,843,843,2639,1355,1355,2379,1712,3760,4,2379,3760,2379,1355,1355,5]) (by decide +kernel)
  change ∀ b ∈ [s389,s390,s391,s392,s393,s394], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s389) b389 <|
    PetersenLocalChildren.push (x := s390) b390 <|
    PetersenLocalChildren.push (x := s391) b391 <|
    PetersenLocalChildren.push (x := s392) b392 <|
    PetersenLocalChildren.push (x := s393) b393 <|
    PetersenLocalChildren.push (x := s394) b394 <|
    PetersenLocalChildren.nil
theorem b395 : Blocked tgt 6 s395 := by
  apply PetersenFastNode.node (nxt := #[s396,s397,s398,s399]) (hints := [3448,457,3512,3448,2798,845,3054,2798,3318,2286,3766,3318,2798,3318,3318,2798,2798,3318,3318,2798,718,750,2766,718,717,201,845,717,457,205,841,457,457,2488,3496,457,457,3512,3512,457,457,1464,2377,457,3510,841,837,837,845,2486,3510,845,845,3510,2990,845,845,2121,2637,845,841,3766,3766,841,841,3766,3766,841,841,2125,2377,841,1353,1353,2377,0,2377,1,2377,2,2377,3]) (by decide +kernel)
  change ∀ b ∈ [s396,s397,s398,s399], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s396) b396 <|
    PetersenLocalChildren.push (x := s397) b397 <|
    PetersenLocalChildren.push (x := s398) b398 <|
    PetersenLocalChildren.push (x := s399) b399 <|
    PetersenLocalChildren.nil
theorem b400 : Blocked tgt 6 s400 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s400 6 _ le
  decide +kernel
theorem b401 : Blocked tgt 6 s401 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s401 6 _ le
  decide +kernel
theorem b402 : Blocked tgt 6 s402 := by
  apply PetersenFastNode.node (nxt := #[s403,s404,s405,s406,s407,s408,s409,s410,s411,s412]) (hints := [2804,2804,3764,2300,3324,1359,3764,3324,3764,2804,2804,1359,3194,3194,2478,3196,3324,463,3322,3324,2478,3194,3194,463,3324,3324,2996,787,2414,851,3580,2414,2996,3324,3324,851,3324,3324,3772,2292,2804,847,3772,2804,3772,3324,3324,847,1244,1244,0,1276,3324,2383,3292,3324,1,1244,1244,2383,463,1359,463,3636,3764,2,463,3764,463,1359,1359,3,851,1619,851,1103,1359,4,851,1359,851,1619,1619,5,847,1359,847,1107,1619,3772,847,1619,847,1359,1359,3772,1359,1359,2383,1716,3764,6,2383,3764,2383,1359,1359,7,723,723,851,207,463,2996,851,463,851,723,723,2996,463,463,847,211,723,3772,847,723,847,463,463,3772,463,463,2383,430,2478,8,2383,2478,2383,463,463,9,3772,2476,3772,847,851,847,843,851,3772,843,2476,847,851,851,2643,2127,2996,2383,2643,2996,2643,851,851,2383,847,847,2383,2131,3772,2643,2383,3772,2383,847,847,2643]) (by decide +kernel)
  change ∀ b ∈ [s403,s404,s405,s406,s407,s408,s409,s410,s411,s412], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s403) b403 <|
    PetersenLocalChildren.push (x := s404) b404 <|
    PetersenLocalChildren.push (x := s405) b405 <|
    PetersenLocalChildren.push (x := s406) b406 <|
    PetersenLocalChildren.push (x := s407) b407 <|
    PetersenLocalChildren.push (x := s408) b408 <|
    PetersenLocalChildren.push (x := s409) b409 <|
    PetersenLocalChildren.push (x := s410) b410 <|
    PetersenLocalChildren.push (x := s411) b411 <|
    PetersenLocalChildren.push (x := s412) b412 <|
    PetersenLocalChildren.nil
theorem b413 : Blocked tgt 6 s413 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s413 6 _ le
  decide +kernel
theorem b414 : Blocked tgt 6 s414 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s414 6 _ le
  decide +kernel
theorem b415 : Blocked tgt 6 s415 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s415 6 _ le
  decide +kernel
theorem b416 : Blocked tgt 6 s416 := by
  apply PetersenFastNode.node (nxt := #[s79,s78,s417,s418,s398,s419]) (hints := [1434,3418,1434,459,2800,459,1434,2800,1434,3418,3418,459,944,2800,944,847,3418,847,944,3418,944,2800,2800,847,3320,3320,3768,2288,2800,843,3768,2800,3768,3320,3320,843,2800,2800,3760,2296,3320,1355,3760,3320,3760,2800,2800,1355,720,720,0,752,2800,2379,2768,2800,1,720,720,2379,719,719,847,203,459,944,847,459,847,719,719,944,459,459,843,207,719,3768,843,719,843,459,459,3768,459,459,1355,410,1434,3760,1355,1434,1355,459,459,3760,459,459,2379,1434,1434,2,2379,1434,2379,459,459,3,1464,1464,3768,843,847,843,839,847,3768,839,1464,843,847,847,1615,1099,1464,1355,1615,1464,1615,847,847,1355,847,847,2639,2123,944,2379,2639,944,2639,847,847,2379,843,843,1355,1103,3768,1615,1355,3768,1355,843,843,1615,843,843,2379,2127,3768,2639,2379,3768,2379,843,843,2639,1355,1355,2379,1712,3760,4,2379,3760,2379,1355,1355,5]) (by decide +kernel)
  change ∀ b ∈ [s79,s78,s417,s418,s398,s419], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.push (x := s78) b78 <|
    PetersenLocalChildren.push (x := s417) b417 <|
    PetersenLocalChildren.push (x := s418) b418 <|
    PetersenLocalChildren.push (x := s398) b398 <|
    PetersenLocalChildren.push (x := s419) b419 <|
    PetersenLocalChildren.nil
theorem b420 : Blocked tgt 6 s420 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s420 6 _ le
  decide +kernel
theorem b421 : Blocked tgt 6 s421 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s421 6 _ le
  decide +kernel
theorem b422 : Blocked tgt 6 s422 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s422 6 _ le
  decide +kernel
theorem b423 : Blocked tgt 6 s423 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s423 6 _ le
  decide +kernel
theorem b424 : Blocked tgt 6 s424 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s424 6 _ le
  decide +kernel
theorem b425 : Blocked tgt 6 s425 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s425 6 _ le
  decide +kernel
theorem b426 : Blocked tgt 6 s426 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s426 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
