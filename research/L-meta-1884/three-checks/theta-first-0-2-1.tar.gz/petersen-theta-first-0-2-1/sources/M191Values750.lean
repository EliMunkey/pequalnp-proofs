import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv750_4260 : PetersenPackedPin.project r750 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv750_4814 : PetersenPackedPin.project r750 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv750_5473 : PetersenPackedPin.project r750 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv750_6170 : PetersenPackedPin.project r750 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv750_6790 : PetersenPackedPin.project r750 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv750_7474 : PetersenPackedPin.project r750 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv750_8012 : PetersenPackedPin.project r750 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv750_5241 : PetersenPackedPin.project r750 (0xf000f000f000f000f000f000f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv750_5473 pv750_6170 rfl rfl
theorem pv750_5850 : PetersenPackedPin.project r750 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv750_4260 pv750_5473 rfl rfl
theorem pv750_2754 : PetersenPackedPin.project r750 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 2 pv750_5241 pv750_5850 rfl rfl
theorem pv750_2529 : PetersenPackedPin.project r750 (0x2320232023202320232023202320232 : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 1 pv750_2754 pv750_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
