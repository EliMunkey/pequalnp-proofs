import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows17
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3865 : Blocked tgt 7 s3865 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,6836,4522,6836,901,901,5930,5672,9921,9921,7474,1669,7474,1669,10433,2693,10433,2693,13642,4741,12481,4741,13610,8837,13610,8837,6836,4522,4522,6836,4264,6836,5672,4264,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,5672,5930,5672,8641,1669,8641,1669,7474,2693,7466,2693,8641,4741,13642,4741,8641,8837,449,8837,385,7216,1669,7216,1669,5672,2693,7208,2693,1576,4741,5672,4741,5672,8837,13352,8837,1669,5684,2693,1669,1669,3636,4741,1669,1669,12328,8837,1669,2693,7208,4741,2693,2693,12852,8837,2693,4741,10804,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3866 : Blocked tgt 7 s3866 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3866 7 _ le
  decide +kernel
theorem b3867 : Blocked tgt 7 s3867 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3867 7 _ le
  decide +kernel
theorem b3868 : Blocked tgt 7 s3868 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3868 7 _ le
  decide +kernel
theorem b3869 : Blocked tgt 7 s3869 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3869 7 _ le
  decide +kernel
theorem b3870 : Blocked tgt 7 s3870 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3870 7 _ le
  decide +kernel
theorem b3871 : Blocked tgt 7 s3871 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3871 7 _ le
  decide +kernel
theorem b3872 : Blocked tgt 7 s3872 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3872 7 _ le
  decide +kernel
theorem b3873 : Blocked tgt 7 s3873 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3873 7 _ le
  decide +kernel
theorem b3874 : Blocked tgt 7 s3874 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3874 7 _ le
  decide +kernel
theorem b3875 : Blocked tgt 7 s3875 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3875 7 _ le
  decide +kernel
theorem b3876 : Blocked tgt 7 s3876 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3876 7 _ le
  decide +kernel
theorem b3877 : Blocked tgt 7 s3877 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3877 7 _ le
  decide +kernel

theorem b3878 : Blocked tgt 7 s3878 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3878 7 _ le
  decide +kernel
theorem b3879 : Blocked tgt 7 s3879 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3879 7 _ le
  decide +kernel
theorem b3880 : Blocked tgt 7 s3880 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3880 7 _ le
  decide +kernel
theorem b3881 : Blocked tgt 7 s3881 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3881 7 _ le
  decide +kernel
theorem b3882 : Blocked tgt 7 s3882 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3882 7 _ le
  decide +kernel
theorem b3883 : Blocked tgt 7 s3883 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3883 7 _ le
  decide +kernel
theorem b3884 : Blocked tgt 7 s3884 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3884 7 _ le
  decide +kernel
theorem b3885 : Blocked tgt 7 s3885 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3885 7 _ le
  decide +kernel
theorem b3886 : Blocked tgt 7 s3886 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3886 7 _ le
  decide +kernel
theorem b3887 : Blocked tgt 7 s3887 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3887 7 _ le
  decide +kernel
theorem b3888 : Blocked tgt 7 s3888 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3888 7 _ le
  decide +kernel
theorem b3889 : Blocked tgt 7 s3889 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [12714,13610,394,4522,8837,4522,394,8837,394,4522,13610,4522,8837,8837,385,901,13610,901,385,13610,385,901,8837,901,9857,13610,9857,8837,8837,5930,1665,8837,9857,1665,13610,5930,8837,8837,3346,1669,13610,1669,3346,13610,3346,1669,8837,1669,8837,8837,2177,2693,14642,2693,2177,14642,2177,2693,8837,2693,8837,8837,12417,4741,13610,4741,4225,13610,12417,4741,8837,4741,6836,6836,6964,773,4522,901,6964,4522,6964,6836,6836,901,4522,4522,5930,6836,6836,9857,5930,6836,5930,4522,4522,9857,7474,6836,7474,4522,4522,1669,6578,4522,7474,6578,6836,1669,4522,4522,7466,4788,6836,2693,6570,6836,7466,4522,4522,2693,2708,2708,13578,4522,4522,4741,4522,4522,13578,2708,2708,4741,5672,385,5672,901,901,5930,901,901,5672,5928,385,5930,901,901,1669,7218,385,7474,1669,385,1669,901,901,7474,901,901,2693,4916,6964,7466,2693,6964,2693,901,901,7466,901,901,4741,2868,6964,13578,4741,6964,4741,901,901,13578,6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669,5930,5930,7466,2693,6962,2693,7466,6962,7466,2693,5930,2693,1834,9857,12417,4741,5930,4741,5930,5930,12417,4741,9857,4741,1669,1669,2693,7466,7474,7466,2693,7474,2693,1669,1669,7466,1669,1669,4741,7474,7474,12417,4741,7474,4741,1669,1669,12417,2693,2693,4741,7466,7466,14610,4741,7466,4741,2693,2693,14610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3890 : Blocked tgt 7 s3890 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3890 7 _ le
  decide +kernel
theorem b3891 : Blocked tgt 7 s3891 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3891 7 _ le
  decide +kernel
theorem b3892 : Blocked tgt 7 s3892 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3892 7 _ le
  decide +kernel
theorem b3894 : Blocked tgt 7 s3894 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3894 7 _ le
  decide +kernel

theorem b3895 : Blocked tgt 7 s3895 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3895 7 _ le
  decide +kernel
theorem b3896 : Blocked tgt 7 s3896 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3896 7 _ le
  decide +kernel
theorem b3897 : Blocked tgt 7 s3897 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3897 7 _ le
  decide +kernel
theorem b3898 : Blocked tgt 7 s3898 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2708,773,2836,2708,6836,4522,4522,6836,4522,2708,5930,4522,7474,4522,6578,6578,4522,2693,6570,4522,8650,426,12746,8650,4522,458,12714,4522,901,8641,9802,901,901,5930,901,7474,1669,901,901,788,2693,901,901,13642,4997,901,901,13610,8837,901,5672,5930,9921,9921,7732,1669,7732,1669,10433,2693,10433,2693,4741,4741,12481,13642,14900,8837,14900,8837,6962,1669,7474,1669,10433,2693,10433,2693,12481,1834,12481,14017,5930,8837,13610,8837,1669,10433,2693,1669,1669,12481,14674,1669,1669,3410,8837,1669,2693,3370,12481,2693,2693,2241,8837,2693,8837,4289,8837,4225]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3899 : Blocked tgt 7 s3899 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3899 7 _ le
  decide +kernel
theorem b3900 : Blocked tgt 7 s3900 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3900 7 _ le
  decide +kernel
theorem b3901 : Blocked tgt 7 s3901 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3901 7 _ le
  decide +kernel
theorem b3902 : Blocked tgt 7 s3902 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3902 7 _ le
  decide +kernel
theorem b3903 : Blocked tgt 7 s3903 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3903 7 _ le
  decide +kernel
theorem b3904 : Blocked tgt 7 s3904 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3904 7 _ le
  decide +kernel
theorem b3905 : Blocked tgt 7 s3905 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3905 7 _ le
  decide +kernel
theorem b3906 : Blocked tgt 7 s3906 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3906 7 _ le
  decide +kernel
theorem b3907 : Blocked tgt 7 s3907 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3907 7 _ le
  decide +kernel
theorem b3908 : Blocked tgt 7 s3908 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3908 7 _ le
  decide +kernel
theorem b3909 : Blocked tgt 7 s3909 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3909 7 _ le
  decide +kernel
theorem b3910 : Blocked tgt 7 s3910 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3910 7 _ le
  decide +kernel

theorem b3911 : Blocked tgt 7 s3911 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3911 7 _ le
  decide +kernel
theorem b3912 : Blocked tgt 7 s3912 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3912 7 _ le
  decide +kernel
theorem b3913 : Blocked tgt 7 s3913 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3913 7 _ le
  decide +kernel
theorem b3914 : Blocked tgt 7 s3914 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3914 7 _ le
  decide +kernel
theorem b3915 : Blocked tgt 7 s3915 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3915 7 _ le
  decide +kernel
theorem b3916 : Blocked tgt 7 s3916 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3916 7 _ le
  decide +kernel
theorem b3920 : Blocked tgt 7 s3920 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3920 7 _ le
  decide +kernel
theorem b3921 : Blocked tgt 7 s3921 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3921 7 _ le
  decide +kernel
theorem b3922 : Blocked tgt 7 s3922 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s3922 7 _ le
  decide +kernel
theorem b3923 : Blocked tgt 7 s3923 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3923 7 _ le
  decide +kernel
theorem b3924 : Blocked tgt 7 s3924 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3924 7 _ le
  decide +kernel
theorem b3925 : Blocked tgt 7 s3925 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3925 7 _ le
  decide +kernel
theorem b3926 : Blocked tgt 7 s3926 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,6836,4522,6836,901,901,5930,9921,1665,9921,7474,1669,7474,1669,2177,2693,2177,2693,4225,4741,4225,4741,13610,8837,13610,8837,6836,4266,4520,6836,9793,9793,9800,9921,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,9921,5930,9921,385,1669,385,1669,7472,2693,7210,2693,385,4741,13642,4741,385,8837,13610,8837,385,8897,8897,9921,1669,9921,2693,10433,9921,9921,4741,12481,9921,1729,1729,9921,8837,1669,10433,2693,1669,1669,12481,4741,1669,1669,11344,8837,1669,2693,12368,4741,2693,2693,10433,8837,2693,4741,12481,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3927 : Blocked tgt 7 s3927 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3927 7 _ le
  decide +kernel
theorem b3928 : Blocked tgt 7 s3928 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3928 7 _ le
  decide +kernel
theorem b3929 : Blocked tgt 7 s3929 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3929 7 _ le
  decide +kernel
theorem b3930 : Blocked tgt 7 s3930 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3930 7 _ le
  decide +kernel
theorem b3931 : Blocked tgt 7 s3931 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3931 7 _ le
  decide +kernel
theorem b3932 : Blocked tgt 7 s3932 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3932 7 _ le
  decide +kernel
theorem b3933 : Blocked tgt 7 s3933 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3933 7 _ le
  decide +kernel
theorem b3934 : Blocked tgt 7 s3934 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3934 7 _ le
  decide +kernel
theorem b3935 : Blocked tgt 7 s3935 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3935 7 _ le
  decide +kernel
theorem b3936 : Blocked tgt 7 s3936 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3936 7 _ le
  decide +kernel
theorem b3937 : Blocked tgt 7 s3937 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3937 7 _ le
  decide +kernel
theorem b3938 : Blocked tgt 7 s3938 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3938 7 _ le
  decide +kernel
theorem b3939 : Blocked tgt 7 s3939 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3939 7 _ le
  decide +kernel
theorem b3940 : Blocked tgt 7 s3940 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3940 7 _ le
  decide +kernel
theorem b3941 : Blocked tgt 7 s3941 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3941 7 _ le
  decide +kernel
theorem b3942 : Blocked tgt 7 s3942 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3942 7 _ le
  decide +kernel
theorem b3944 : Blocked tgt 7 s3944 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3944 7 _ le
  decide +kernel
theorem b3945 : Blocked tgt 7 s3945 := by
  intro k le c
  apply rejects_sound r749 (0xc0c0c0c0c0c0c0c :: i6) 6 tgt small749 hot749 [] s3945 7 _ le
  decide +kernel
theorem b3946 : Blocked tgt 7 s3946 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3946 7 _ le
  decide +kernel

theorem b3947 : Blocked tgt 7 s3947 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3947 7 _ le
  decide +kernel
theorem b3948 : Blocked tgt 7 s3948 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,4264,4522,4522,4264,4522,6836,5930,4522,7474,4522,6578,6578,4522,4788,6570,4522,8650,426,12746,8650,4522,458,12714,4522,901,8641,9921,901,901,5930,901,7474,1669,901,901,4916,2693,901,901,2868,4741,901,901,13610,9093,901,9921,5930,9921,1665,7216,1669,7216,1669,10433,2693,10433,2693,12481,4741,12481,4741,8837,8837,13352,13610,8897,1669,9921,1669,9921,2693,10433,2693,9921,4741,12481,4741,5930,9921,9857,9857,1669,10433,2693,1669,1669,12481,4741,1669,1669,3410,14642,1669,2693,3370,4741,2693,2693,2241,10369,2693,4741,4289,12417,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b3949 : Blocked tgt 7 s3949 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3949 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
