import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows10
import M191StartPreferredRows9
import ResidualFast
import ThetaClosing
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2043 : Blocked tgt 7 s2043 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,16,20,16,22,17,21,19,23,8,12,8,14,9,13,11,15,24,28,24,30,25,29,27,31,64,68,64,70,65,69,67,71,80,84,80,86,81,85,83,87,72,76,72,78,73,77,75,79,88,92,88,94,89,93,91,95,32,36,32,38,33,37,35,39,48,52,48,54,49,53,51,55,40,44,40,46,41,45,43,47,56,60,56,62,57,61,59,63,96,100,96,102,97,101,99,103,112,116,112,118,113,117,115,119,104,108,104,110,105,109,107,111,120,124,120,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,16,20,16,22,17,21,19,23,8,12,8,14,9,13,11,15,24,28,24,30,25,29,27,31,64,68,64,70,65,69,67,71,80,84,80,86,81,85,83,87,72,76,72,78,73,77,75,79,88,92,88,94,89,93,91,95,32,36,32,38,33,37,35,39,48,52,48,54,49,53,51,55,40,44,40,46,41,45,43,47,56,60,56,62,57,61,59,63,96,100,96,102,97,101,99,103,112,116,112,118,113,117,115,119,104,108,104,110,105,109,107,111,120,124,120,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0x32323232323232323232323232323232,0x32323232323232323232323232323232),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffffafafffffafafffffafafffffafa,0xfffafffafffafffafffafffafffafffa),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1109) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1109
theorem b2048 : Blocked tgt 7 s2048 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s2048 7 _ le
  decide +kernel
theorem b2083 : Blocked tgt 7 s2083 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2083 7 _ le
  decide +kernel
theorem b2084 : Blocked tgt 7 s2084 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s2084 7 _ le
  decide +kernel
theorem b2089 : Blocked tgt 7 s2089 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2089 7 _ le
  decide +kernel
theorem b2094 : Blocked tgt 7 s2094 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(2,false),(4,false))] s2094 7 _ le
  decide +kernel
theorem b2097 : Blocked tgt 7 s2097 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2097 7 _ le
  decide +kernel
theorem b2098 : Blocked tgt 7 s2098 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s2098 7 _ le
  decide +kernel
theorem b2099 : Blocked tgt 7 s2099 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s2099 7 _ le
  decide +kernel
theorem b2102 : Blocked tgt 7 s2102 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2102 7 _ le
  decide +kernel

theorem b2108 : Blocked tgt 7 s2108 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(2,false),(4,false))] s2108 7 _ le
  decide +kernel
theorem b2109 : Blocked tgt 7 s2109 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2109 7 _ le
  decide +kernel
theorem b2110 : Blocked tgt 7 s2110 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2110 7 _ le
  decide +kernel
theorem b2117 : Blocked tgt 7 s2117 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2117 7 _ le
  decide +kernel
theorem b2123 : Blocked tgt 7 s2123 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2123 7 _ le
  decide +kernel
theorem b2132 : Blocked tgt 7 s2132 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s2132 7 _ le
  decide +kernel
theorem b2135 : Blocked tgt 7 s2135 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2135 7 _ le
  decide +kernel
theorem b2137 : Blocked tgt 7 s2137 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2137 7 _ le
  decide +kernel
theorem b2139 : Blocked tgt 7 s2139 := by
  intro k le c
  apply rejects_sound r751 (0xf000f000f000f0 :: i6) 6 tgt small751 hot751 [] s2139 7 _ le
  decide +kernel
theorem b2141 : Blocked tgt 7 s2141 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2141 7 _ le
  decide +kernel
theorem b2142 : Blocked tgt 7 s2142 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2142 7 _ le
  decide +kernel
theorem b2143 : Blocked tgt 7 s2143 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(false,(2,false),(4,true))] s2143 7 _ le
  decide +kernel
theorem b2145 : Blocked tgt 7 s2145 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2145 7 _ le
  decide +kernel
theorem b2147 : Blocked tgt 7 s2147 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2147 7 _ le
  decide +kernel
theorem b2153 : Blocked tgt 7 s2153 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2153 7 _ le
  decide +kernel
theorem b2155 : Blocked tgt 7 s2155 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2155 7 _ le
  decide +kernel
theorem b2156 : Blocked tgt 7 s2156 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2156 7 _ le
  decide +kernel
theorem b2166 : Blocked tgt 7 s2166 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2166 7 _ le
  decide +kernel
theorem b2193 : Blocked tgt 7 s2193 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2193 7 _ le
  decide +kernel
theorem b2205 : Blocked tgt 7 s2205 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2205 7 _ le
  decide +kernel

theorem b2216 : Blocked tgt 7 s2216 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2216 7 _ le
  decide +kernel
theorem b2220 : Blocked tgt 7 s2220 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2220 7 _ le
  decide +kernel
theorem b2236 : Blocked tgt 7 s2236 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2236 7 _ le
  decide +kernel
theorem b2243 : Blocked tgt 7 s2243 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s2243 7 _ le
  decide +kernel
theorem b2244 : Blocked tgt 7 s2244 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2244 7 _ le
  decide +kernel
theorem b2253 : Blocked tgt 7 s2253 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s2253 7 _ le
  decide +kernel
theorem b2254 : Blocked tgt 7 s2254 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s2254 7 _ le
  decide +kernel
theorem b2258 : Blocked tgt 7 s2258 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2258 7 _ le
  decide +kernel
theorem b2259 : Blocked tgt 7 s2259 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2259 7 _ le
  decide +kernel
theorem b2264 : Blocked tgt 7 s2264 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2264 7 _ le
  decide +kernel
theorem b2265 : Blocked tgt 7 s2265 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7466,7466,6562,5546,2693,5546,4514,2693,6562,5546,7466,5546,2693,2693,6964,901,7466,901,4916,7466,6964,901,2693,901,11465,11465,6946,9929,2693,9929,2181,2693,6946,9929,11465,9929,2693,2693,7458,1669,11465,1669,10441,11465,7458,1669,2693,1669,2693,2693,12610,4741,7466,4741,3370,7466,12610,2693,2693,4741,2693,2693,12578,8837,11465,8837,3273,11465,12578,2693,2693,8837,4772,4772,4900,773,5546,901,4900,5546,4900,4772,4772,901,5546,5546,5930,9801,4772,9929,5930,4772,5930,5546,5546,9929,4522,4772,5668,4522,5546,1669,5546,5546,5668,4772,4772,1669,9674,9674,13642,1450,5546,4741,13642,5546,13642,9674,9674,4741,5546,5546,13610,1482,9674,8837,13610,9674,13610,5546,5546,8837,9673,9673,9929,389,901,5930,9929,901,9929,9673,9673,5930,901,901,1669,8649,9673,7458,1669,9673,1669,901,901,7458,901,901,4741,804,4900,13642,4741,4900,4741,901,901,13642,901,901,8837,1481,9673,13610,8837,9673,8837,901,901,13610,8897,8897,7458,8905,9929,1669,9921,9929,7458,8897,8897,1669,9929,9929,13513,4229,5930,4741,13513,5930,13513,9929,9929,4741,1673,1673,13610,1737,9929,8837,9865,9929,13610,1673,1673,8837,1669,1669,4741,12489,5668,13513,4741,5668,4741,1669,1669,13513,1669,1669,8837,13610,11586,13610,8837,11586,8837,1669,1669,13610,4741,4741,8837,5321,13513,13610,8837,13513,8837,4741,4741,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2266 : Blocked tgt 7 s2266 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2266 7 _ le
  decide +kernel
theorem b2268 : Blocked tgt 7 s2268 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s2268 7 _ le
  decide +kernel
theorem b2270 : Blocked tgt 7 s2270 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2270 7 _ le
  decide +kernel
theorem b2271 : Blocked tgt 7 s2271 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2271 7 _ le
  decide +kernel
theorem b2272 : Blocked tgt 7 s2272 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s2272 7 _ le
  decide +kernel
theorem b2274 : Blocked tgt 7 s2274 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2274 7 _ le
  decide +kernel
theorem b2285 : Blocked tgt 7 s2285 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,0,20,2,22,17,21,19,23,32,52,34,54,49,53,51,55,64,84,66,86,81,85,83,87,96,116,98,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,0,68,2,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,8,76,10,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,16,84,18,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,24,92,26,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xfffa0000fffa0000fffa0000fffa,0xfffffffffafafafa),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_714) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_714
theorem b2288 : Blocked tgt 7 s2288 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s2288 7 _ le
  decide +kernel
theorem b2289 : Blocked tgt 7 s2289 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2289 7 _ le
  decide +kernel
theorem b2290 : Blocked tgt 7 s2290 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s2290 7 _ le
  decide +kernel
theorem b2293 : Blocked tgt 7 s2293 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2293 7 _ le
  decide +kernel
theorem b2295 : Blocked tgt 7 s2295 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2295 7 _ le
  decide +kernel
theorem b2297 : Blocked tgt 7 s2297 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2297 7 _ le
  decide +kernel
theorem b2298 : Blocked tgt 7 s2298 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2298 7 _ le
  decide +kernel
theorem b2300 : Blocked tgt 7 s2300 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s2300 7 _ le
  decide +kernel

theorem b2301 : Blocked tgt 7 s2301 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2301 7 _ le
  decide +kernel
theorem b2302 : Blocked tgt 7 s2302 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2302 7 _ le
  decide +kernel
theorem b2306 : Blocked tgt 7 s2306 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2306 7 _ le
  decide +kernel
theorem b2313 : Blocked tgt 7 s2313 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s2313 7 _ le
  decide +kernel
theorem b2321 : Blocked tgt 7 s2321 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s2321 7 _ le
  decide +kernel
theorem b2322 : Blocked tgt 7 s2322 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(1,false),(3,false))] s2322 7 _ le
  decide +kernel

theorem b2324 : Blocked tgt 7 s2324 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2324 7 _ le
  decide +kernel
theorem b2325 : Blocked tgt 7 s2325 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2325 7 _ le
  decide +kernel
theorem b2326 : Blocked tgt 7 s2326 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(0,false),(4,false))] s2326 7 _ le
  decide +kernel
theorem b2327 : Blocked tgt 7 s2327 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s2327 7 _ le
  decide +kernel
theorem b2328 : Blocked tgt 7 s2328 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2328 7 _ le
  decide +kernel
theorem b2329 : Blocked tgt 7 s2329 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s2329 7 _ le
  decide +kernel
theorem b2330 : Blocked tgt 7 s2330 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s2330 7 _ le
  decide +kernel
theorem b2331 : Blocked tgt 7 s2331 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6964,6964,5544,6836,901,6836,773,901,5544,6836,6964,6836,9673,9673,5928,9929,901,9929,389,901,5928,9673,9673,9929,901,901,7474,1669,9673,1669,8649,9673,7474,901,901,1669,901,901,7464,2693,6964,2693,4916,6964,7464,901,901,2693,901,901,13384,4741,6964,4741,2868,6964,13384,901,901,4741,901,901,13352,8837,9673,8837,1481,9673,13352,901,901,8837,9801,6320,10832,9801,6836,9929,6832,6836,10832,9929,6320,9929,6836,6836,7732,1541,5544,1669,7732,5544,7732,6836,6836,1669,4772,4772,7464,4788,6836,2693,6820,6836,7464,4772,4772,2693,2708,2708,14416,2740,6836,4741,6804,6836,14416,2708,2708,4741,6836,6836,14900,8709,10448,8837,14900,10448,14900,6836,6836,8837,8897,8897,7216,8905,9929,1669,9921,9929,7216,8897,8897,1669,9929,9929,11465,2181,10832,2693,11465,10832,11465,9929,9929,2693,9929,9929,13513,4229,5928,4741,13513,5928,13513,9929,9929,4741,1673,1673,14384,1737,9929,8837,9865,9929,14384,1673,1673,8837,1669,1669,2693,10441,7732,11465,2693,7732,2693,1669,1669,11465,1669,1669,4741,12489,7732,13513,4741,7732,4741,1669,1669,13513,1669,1669,8837,3152,11344,13352,8837,11344,8837,1669,1669,13352,2693,2693,4741,14416,7464,14416,4741,7464,4741,2693,2693,14416,2693,2693,8837,3273,11465,14900,8837,11465,8837,2693,2693,14900,4741,4741,8837,5321,13513,14900,8837,13513,8837,4741,4741,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2332 : Blocked tgt 7 s2332 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2332 7 _ le
  decide +kernel
theorem b2333 : Blocked tgt 7 s2333 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(0,false),(4,false))] s2333 7 _ le
  decide +kernel
theorem b2334 : Blocked tgt 7 s2334 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2334 7 _ le
  decide +kernel
theorem b2335 : Blocked tgt 7 s2335 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2335 7 _ le
  decide +kernel
theorem b2336 : Blocked tgt 7 s2336 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s2336 7 _ le
  decide +kernel
theorem b2337 : Blocked tgt 7 s2337 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2337 7 _ le
  decide +kernel
theorem b2340 : Blocked tgt 7 s2340 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7474,7474,5538,6578,1669,6578,4514,1669,5538,6578,7474,6578,1669,1669,9673,901,7474,901,8649,7474,9673,901,1669,901,9921,7474,9929,8897,1669,8897,8905,1669,9929,8897,7474,8897,1669,1669,11465,2693,7474,2693,10441,7474,11465,1669,1669,2693,1669,1669,13513,4741,7474,4741,12489,7474,13513,1669,1669,4741,1669,1669,12578,8837,11602,8837,3410,11602,12578,1669,1669,8837,6836,6836,6964,773,6578,901,6964,6578,6964,6836,6836,901,6578,6578,6962,6324,6836,8897,6962,6836,6962,6578,6578,8897,4530,4772,7458,4530,6578,2693,6578,6578,7458,4772,4772,2693,10706,10706,14674,2482,6578,4741,14674,6578,14674,10706,10706,4741,6578,6578,14642,2514,10706,8837,14642,10706,14642,6578,6578,8837,8641,8641,8897,389,901,6962,8897,901,8897,8641,8641,6962,901,901,2693,4916,6964,7458,2693,6964,2693,901,901,7458,901,901,4741,2868,6964,14674,4741,6964,4741,901,901,14674,901,901,8837,449,8641,14642,8837,8641,8837,901,901,14642,8897,8897,10433,2181,6962,2693,10433,6962,10433,8897,8897,2693,8897,8897,12481,4229,6962,4741,12481,6962,12481,8897,8897,4741,6962,6962,14642,8837,8897,8837,8833,8897,14642,8833,6962,8837,2693,2693,4741,14674,7458,14674,4741,7458,4741,2693,2693,14674,2693,2693,8837,2241,10433,14642,8837,10433,8837,2693,2693,14642,4741,4741,8837,4289,12481,14642,8837,12481,8837,4741,4741,14642]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2341 : Blocked tgt 7 s2341 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2341 7 _ le
  decide +kernel
theorem b2342 : Blocked tgt 7 s2342 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2342 7 _ le
  decide +kernel
theorem b2343 : Blocked tgt 7 s2343 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2343 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
