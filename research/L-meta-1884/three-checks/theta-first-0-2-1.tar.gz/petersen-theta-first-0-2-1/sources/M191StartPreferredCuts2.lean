import M191StartPreferredCommon
import M31StartLabeled
import M111StartLabeled
import M189StartLabeled
import M15StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r731 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small731 : NoAtMost (0xa0a0a0a0 :: i5) (PetersenPackedPin.project r731 tgt) 6 := by
  have a : PetersenPackedPin.project r731 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a0 (by decide +kernel)
theorem hot731 : forcedConst r731 tgt = false := by decide +kernel
def r732 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small732 : NoAtMost (0xa0a0a0a0 :: i5) (PetersenPackedPin.project r732 tgt) 6 := by
  have a : PetersenPackedPin.project r732 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a0 (by decide +kernel)
theorem hot732 : forcedConst r732 tgt = false := by decide +kernel
def r733 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small733 : NoAtMost (0xffffffffcccccccc :: i6) (PetersenPackedPin.project r733 tgt) 6 := by
  have a : PetersenPackedPin.project r733 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xffffffffcccccccc (by decide +kernel)
theorem hot733 : forcedConst r733 tgt = false := by decide +kernel
def r734 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small734 : NoAtMost (0xcccccccc :: i6) (PetersenPackedPin.project r734 tgt) 6 := by
  have a : PetersenPackedPin.project r734 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xcccccccc (by decide +kernel)
theorem hot734 : forcedConst r734 tgt = false := by decide +kernel
def r735 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small735 : NoAtMost (0xffffffffcccccccc :: i6) (PetersenPackedPin.project r735 tgt) 6 := by
  have a : PetersenPackedPin.project r735 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xffffffffcccccccc (by decide +kernel)
theorem hot735 : forcedConst r735 tgt = false := by decide +kernel
def r736 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small736 : NoAtMost (0xaaaa0000aaaa :: i6) (PetersenPackedPin.project r736 tgt) 6 := by
  have a : PetersenPackedPin.project r736 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xaaaa0000aaaa (by decide +kernel)
theorem hot736 : forcedConst r736 tgt = false := by decide +kernel
def r737 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small737 : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r737 tgt) 6 := by
  have a : PetersenPackedPin.project r737 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a (by decide +kernel)
theorem hot737 : forcedConst r737 tgt = false := by decide +kernel
def r738 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small738 : NoAtMost (0xf000f000f000f0 :: i6) (PetersenPackedPin.project r738 tgt) 6 := by
  have a : PetersenPackedPin.project r738 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xf000f000f000f0 (by decide +kernel)
theorem hot738 : forcedConst r738 tgt = false := by decide +kernel
def r739 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small739 : NoAtMost (0xa0a0a0a :: i5) (PetersenPackedPin.project r739 tgt) 6 := by
  have a : PetersenPackedPin.project r739 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xa0a0a0a (by decide +kernel)
theorem hot739 : forcedConst r739 tgt = false := by decide +kernel
def r740 (x : Fin 64) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57,60,61,64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93,96,97,100,101,104,105,108,109,112,113,116,117,120,121,124,125] : Array (Fin 128))[x.val]?.getD 0
theorem small740 : NoAtMost (0x2222222222222222 :: i6) (PetersenPackedPin.project r740 tgt) 7 := by
  have a : PetersenPackedPin.project r740 tgt = PetersenSmallStarts.M189.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M189.all_forbidden 0x2222222222222222 (by decide +kernel)
theorem hot740 : forcedConst r740 tgt = false := by decide +kernel
def r741 (x : Fin 64) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57,60,61,64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93,96,97,100,101,104,105,108,109,112,113,116,117,120,121,124,125] : Array (Fin 128))[x.val]?.getD 0
theorem small741 : NoAtMost (0xeeeeeeeeeeeeeeee :: i6) (PetersenPackedPin.project r741 tgt) 7 := by
  have a : PetersenPackedPin.project r741 tgt = PetersenSmallStarts.M189.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M189.all_forbidden 0xeeeeeeeeeeeeeeee (by decide +kernel)
theorem hot741 : forcedConst r741 tgt = false := by decide +kernel
def r742 (x : Fin 16) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108] : Array (Fin 128))[x.val]?.getD 0
theorem small742 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r742 tgt) 3 := by
  have a : PetersenPackedPin.project r742 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot742 : forcedConst r742 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
