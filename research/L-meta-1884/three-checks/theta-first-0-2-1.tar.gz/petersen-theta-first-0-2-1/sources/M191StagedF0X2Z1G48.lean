import higher.WireProjection
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values734
import M191Values735
import M191Values739
import M191Values740
import M191Values744
import M191Values745
import M191Values748
import M191Values749
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4825 : Blocked tgt 8 s4825 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4825 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5729 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4826 : Blocked tgt 8 s4826 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4826 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffff0000ffff0000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5729 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4827 : Blocked tgt 8 s4827 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4827 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4828 : Blocked tgt 8 s4828 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4828 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4948 : Blocked tgt 8 s4948 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4948 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b4949 : Blocked tgt 8 s4949 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4949 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8104 rfl))))))))) (by decide +kernel)
theorem b4950 : Blocked tgt 8 s4950 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4950 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4951 : Blocked tgt 8 s4951 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4951 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5041 : Blocked tgt 8 s5041 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s5041 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b5042 : Blocked tgt 8 s5042 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5042 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b5043 : Blocked tgt 8 s5043 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5043 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b5044 : Blocked tgt 8 s5044 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5044 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5067 : Blocked tgt 8 s5067 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5067 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5068 : Blocked tgt 8 s5068 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5068 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5069 : Blocked tgt 8 s5069 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5069 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5070 : Blocked tgt 8 s5070 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5070 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3582 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5091 : Blocked tgt 8 s5091 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5091 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5092 : Blocked tgt 8 s5092 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5092 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5093 : Blocked tgt 8 s5093 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5093 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4089 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5121 : Blocked tgt 8 s5121 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5121 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5122 : Blocked tgt 8 s5122 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5122 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5123 : Blocked tgt 8 s5123 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5123 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5124 : Blocked tgt 8 s5124 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5124 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xf0f0f0f0f0f0f0f0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3677 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5125 : Blocked tgt 8 s5125 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5125 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b5126 : Blocked tgt 8 s5126 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5126 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5127 : Blocked tgt 8 s5127 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5127 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5128 : Blocked tgt 8 s5128 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5128 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xff00ff00ff00ff00,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3705 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5129 : Blocked tgt 8 s5129 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5129 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5130 : Blocked tgt 8 s5130 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5130 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7688 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5131 : Blocked tgt 8 s5131 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5131 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5132 : Blocked tgt 8 s5132 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5132 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff0000ffff0000,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3730 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5133 : Blocked tgt 8 s5133 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5133 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5167 : Blocked tgt 8 s5167 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5167 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl))))))))) (by decide +kernel)
theorem b5168 : Blocked tgt 8 s5168 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5168 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5169 : Blocked tgt 8 s5169 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5169 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5170 : Blocked tgt 8 s5170 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5170 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3759 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5171 : Blocked tgt 8 s5171 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5171 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4429 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5172 : Blocked tgt 8 s5172 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s5172 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl))))))))) (by decide +kernel)
theorem b5173 : Blocked tgt 8 s5173 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5173 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2800 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b5174 : Blocked tgt 8 s5174 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s5174 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3209 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl))))))))) (by decide +kernel)
theorem b5175 : Blocked tgt 8 s5175 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5175 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xcc08cc08cc08cc08cc08cc08cc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5187 : Blocked tgt 8 s5187 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5187 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xc400c400c400c400c400c400c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5188 : Blocked tgt 8 s5188 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5188 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3315 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5189 : Blocked tgt 8 s5189 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5189 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4586 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5190 : Blocked tgt 8 s5190 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5190 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5191 : Blocked tgt 8 s5191 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5191 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5192 : Blocked tgt 8 s5192 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5192 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5193 : Blocked tgt 8 s5193 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5193 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4675 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5194 : Blocked tgt 8 s5194 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5194 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5195 : Blocked tgt 8 s5195 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5195 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5196 : Blocked tgt 8 s5196 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5196 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_3427 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5197 : Blocked tgt 8 s5197 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5197 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4753 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5211 : Blocked tgt 8 s5211 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5211 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b5212 : Blocked tgt 8 s5212 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5212 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b5213 : Blocked tgt 8 s5213 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5213 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5241 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5214 : Blocked tgt 8 s5214 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s5214 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons pv745_5473 (PetersenWireProjection.cons pv745_6308 (PetersenWireProjection.cons pv745_6659 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl))))))))) (by decide +kernel)
theorem b5215 : Blocked tgt 8 s5215 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s5215 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444444444444444,0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv748_2298 (PetersenWireProjection.cons pv748_2708 (PetersenWireProjection.cons pv748_4260 (PetersenWireProjection.cons pv748_4814 (PetersenWireProjection.cons pv748_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons pv748_6790 (PetersenWireProjection.cons pv748_7474 (PetersenWireProjection.cons pv748_8012 rfl))))))))) (by decide +kernel)
theorem b5216 : Blocked tgt 8 s5216 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5216 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_2884 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5217 : Blocked tgt 8 s5217 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5217 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5294 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5218 : Blocked tgt 8 s5218 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5218 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b5219 : Blocked tgt 8 s5219 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5219 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b5220 : Blocked tgt 8 s5220 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5220 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5221 : Blocked tgt 8 s5221 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5221 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5367 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5222 : Blocked tgt 8 s5222 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5222 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b5223 : Blocked tgt 8 s5223 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5223 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1177 (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b5224 : Blocked tgt 8 s5224 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5224 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_2963 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5225 : Blocked tgt 8 s5225 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5225 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5425 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b5226 : Blocked tgt 8 s5226 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s5226 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc] (PetersenWireProjection.cons pv744_2708 (PetersenWireProjection.cons pv744_4260 (PetersenWireProjection.cons pv744_4814 (PetersenWireProjection.cons pv744_5473 (PetersenWireProjection.cons pv744_6308 (PetersenWireProjection.cons pv744_6790 (PetersenWireProjection.cons pv744_7474 (PetersenWireProjection.cons pv744_8012 (PetersenWireProjection.cons pv744_8245 rfl))))))))) (by decide +kernel)
theorem b5227 : Blocked tgt 8 s5227 := by
  intro k le c
  apply rejects_sound r749 (0xc0c0c0c0c0c0c0c :: i6) 6 tgt small749 hot749 [] s5227 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xc0c0c0c0c0c0c0c,0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv749_456 (PetersenWireProjection.cons pv749_2708 (PetersenWireProjection.cons pv749_4260 (PetersenWireProjection.cons pv749_4814 (PetersenWireProjection.cons pv749_5473 (PetersenWireProjection.cons pv749_6308 (PetersenWireProjection.cons pv749_6790 (PetersenWireProjection.cons pv749_7474 (PetersenWireProjection.cons pv749_8012 rfl))))))))) (by decide +kernel)

theorem b5228 : Blocked tgt 8 s5228 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5228 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3004 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b5229 : Blocked tgt 8 s5229 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5229 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6286 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5230 : Blocked tgt 8 s5230 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5230 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7330 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5231 : Blocked tgt 8 s5231 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5231 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1896 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5232 : Blocked tgt 8 s5232 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5232 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2318 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5233 : Blocked tgt 8 s5233 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5233 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff0aff0a00000000ff0aff0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5234 : Blocked tgt 8 s5234 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5234 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7873 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b5235 : Blocked tgt 8 s5235 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5235 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5236 : Blocked tgt 8 s5236 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5236 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xf500f50000000000f500f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5237 : Blocked tgt 8 s5237 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5237 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6300 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5246 : Blocked tgt 8 s5246 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5246 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_541 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b5247 : Blocked tgt 8 s5247 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5247 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf500f500f500f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b5248 : Blocked tgt 8 s5248 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5248 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6671 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5249 : Blocked tgt 8 s5249 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5249 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b5250 : Blocked tgt 8 s5250 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5250 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b5251 : Blocked tgt 8 s5251 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5251 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1925 (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5252 : Blocked tgt 8 s5252 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5252 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6738 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5253 : Blocked tgt 8 s5253 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5253 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8331 rfl))))))))) (by decide +kernel)
theorem b5254 : Blocked tgt 8 s5254 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5254 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_581 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b5255 : Blocked tgt 8 s5255 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5255 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b5256 : Blocked tgt 8 s5256 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5256 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7397 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5257 : Blocked tgt 8 s5257 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5257 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8377 rfl))))))))) (by decide +kernel)
theorem b5258 : Blocked tgt 8 s5258 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5258 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_630 (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b5259 : Blocked tgt 8 s5259 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5259 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b5261 : Blocked tgt 8 s5261 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5261 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5262 : Blocked tgt 8 s5262 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5262 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5263 : Blocked tgt 8 s5263 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s5263 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4503 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b5264 : Blocked tgt 8 s5264 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5264 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2654 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5265 : Blocked tgt 8 s5265 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5265 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b5266 : Blocked tgt 8 s5266 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5266 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2654 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b5267 : Blocked tgt 8 s5267 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5267 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

end PetersenSmallStarts.M191.Staged
