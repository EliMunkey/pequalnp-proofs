import higher.WireProjection
import M191Values0
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values32
import M191Values35
import M191Values5
import M191Values734
import M191Values741
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows5
import M191StartPreferredRows6
import M191StartPreferredRows7
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1279 : Blocked tgt 7 s1279 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s1279 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6277 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7397 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b1280 : Blocked tgt 7 s1280 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s1280 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6277 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b1281 : Blocked tgt 7 s1281 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s1281 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_630 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6277 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)

theorem b1282 : Blocked tgt 7 s1282 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s1282 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6277 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b1284 : Blocked tgt 7 s1284 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1284 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6277 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1285 : Blocked tgt 7 s1285 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1285 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6277 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1286 : Blocked tgt 7 s1286 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1286 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaa02aa02aa02aa02aa02aa02aa02aa02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1287 : Blocked tgt 7 s1287 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1287 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1288 : Blocked tgt 7 s1288 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1288 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2163 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1289 : Blocked tgt 7 s1289 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1289 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3677 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1290 : Blocked tgt 7 s1290 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1290 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6277 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b1291 : Blocked tgt 7 s1291 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1291 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_3304 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1292 : Blocked tgt 7 s1292 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1292 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6277 (PetersenWireProjection.cons pv32_6618 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b1293 : Blocked tgt 7 s1293 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1293 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2860 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1294 : Blocked tgt 7 s1294 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1294 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1295 : Blocked tgt 7 s1295 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1295 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xfff2fff2fff2fff2fff2fff2fff2fff2 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b1296 : Blocked tgt 7 s1296 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1296 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2298 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1297 : Blocked tgt 7 s1297 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1297 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf020f020f020f020f020f020f020f02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1298 : Blocked tgt 7 s1298 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,false),(2,true)),(true,(0,false),(5,false))] s1298 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff02ff02ff02ff02ff02ff02ff02ff02,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xff02ff02ff02ff02ff02ff02ff02ff02) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)

theorem b1299 : Blocked tgt 7 s1299 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1299 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2012 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6277 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1300 : Blocked tgt 7 s1300 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1300 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5978 (PetersenWireProjection.cons pv10_6277 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1301 : Blocked tgt 7 s1301 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1301 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7314 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1302 : Blocked tgt 7 s1302 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1302 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1887 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1303 : Blocked tgt 7 s1303 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1303 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2362 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6277 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1304 : Blocked tgt 7 s1304 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s1304 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6055 (PetersenWireProjection.cons pv11_6277 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b1305 : Blocked tgt 7 s1305 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1305 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b1306 : Blocked tgt 7 s1306 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1306 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1252 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1307 : Blocked tgt 7 s1307 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s1307 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2418 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6277 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b1308 : Blocked tgt 7 s1308 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1308 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6120 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1309 : Blocked tgt 7 s1309 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1309 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6277 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b1310 : Blocked tgt 7 s1310 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1310 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_531 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6277 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1311 : Blocked tgt 7 s1311 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s1311 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2461 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6277 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b1312 : Blocked tgt 7 s1312 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1312 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff020000ff020000ff020000ff020000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1313 : Blocked tgt 7 s1313 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1313 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffffff02ffffff02ffffff02ffffff02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1314 : Blocked tgt 7 s1314 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1314 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff020000ff020000ff020000ff02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)

theorem b1315 : Blocked tgt 7 s1315 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1315 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfd000000fd000000fd000000fd0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1316 : Blocked tgt 7 s1316 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1316 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xff02ff0200000000ff02ff0200000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1317 : Blocked tgt 7 s1317 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1317 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffff02ff02ffffffffff02ff02 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b1318 : Blocked tgt 7 s1318 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1318 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff02ff0200000000ff02ff02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1319 : Blocked tgt 7 s1319 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1319 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfd00fd0000000000fd00fd00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1320 : Blocked tgt 7 s1320 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1320 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xff02ff02ff02ff020000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1321 : Blocked tgt 7 s1321 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1321 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffffffffffffffffff02ff02ff02ff02 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b1322 : Blocked tgt 7 s1322 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1322 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff02ff02ff02ff02 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1323 : Blocked tgt 7 s1323 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1323 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfd00fd00fd00fd0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1335 : Blocked tgt 7 s1335 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1335 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6879 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1336 : Blocked tgt 7 s1336 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1336 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6879 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1337 : Blocked tgt 7 s1337 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1337 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6879 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1338 : Blocked tgt 7 s1338 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1338 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6879 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1339 : Blocked tgt 7 s1339 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1339 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaa0202aaaa0202aaaa0202aaaa0202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1340 : Blocked tgt 7 s1340 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1340 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1341 : Blocked tgt 7 s1341 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1341 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1700 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b1342 : Blocked tgt 7 s1342 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1342 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1343 : Blocked tgt 7 s1343 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1343 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4429 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1344 : Blocked tgt 7 s1344 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s1344 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3209 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xffff0202ffff0202ffff0202ffff0202 : BitVec 128) = 0xffff0000ffff0000) (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b1345 : Blocked tgt 7 s1345 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1345 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6546 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffff0202ffff0202ffff0202ffff0202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1346 : Blocked tgt 7 s1346 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1346 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2240 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1347 : Blocked tgt 7 s1347 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1347 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1348 : Blocked tgt 7 s1348 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1348 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1349 : Blocked tgt 7 s1349 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,6324,5930,5546,6836,1541,7732,6836,4772,6836,6836,4772,4772,6836,6836,4772,2708,2740,6804,2708,6836,1480,13354,6836,6836,773,6964,6836,6962,1669,7474,1669,11465,6962,11465,11977,9673,9929,9673,5930,13513,4741,13513,4741,5930,1864,13354,5930,389,389,5928,901,1669,10441,10433,1669,1669,9665,8641,1669,1669,12489,4741,1669,1669,3408,14386,1669,901,7218,901,1669,2693,2693,4741,14416,4741,11465,3529,3529,11465,3209,901,11465,901,3209,4741,13513,4741,9673,13354,9673,1481,1481,901,9673,901,6964,4741,13513,13513,4741,901,13513,901,4741,901,8837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b1350 : Blocked tgt 7 s1350 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1350 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1351 : Blocked tgt 7 s1351 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1351 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0202ffff0202ffff0202ffff0202 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b1352 : Blocked tgt 7 s1352 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1352 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1353 : Blocked tgt 7 s1353 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1353 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1354 : Blocked tgt 7 s1354 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1354 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffff2f2fffff2f2fffff2f2fffff2f2 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b1355 : Blocked tgt 7 s1355 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1355 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1829 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1356 : Blocked tgt 7 s1356 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1356 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf0f02020f0f02020f0f02020f0f0202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1357 : Blocked tgt 7 s1357 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1357 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff000200ff000200ff000200ff000200 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)

theorem b1358 : Blocked tgt 7 s1358 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1358 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfd000000fd000000fd000000fd00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1359 : Blocked tgt 7 s1359 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1359 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff000200ff000200ff000200ff0002 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1360 : Blocked tgt 7 s1360 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1360 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6879 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1361 : Blocked tgt 7 s1361 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1361 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0202ffff0202ffff0202ffff0202 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b1362 : Blocked tgt 7 s1362 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1362 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6879 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1363 : Blocked tgt 7 s1363 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1363 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff020200000000ffff020200000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1364 : Blocked tgt 7 s1364 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1364 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffff0202ffffffffffff0202 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b1365 : Blocked tgt 7 s1365 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1365 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff020200000000ffff0202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1366 : Blocked tgt 7 s1366 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1366 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfdfd000000000000fdfd00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1367 : Blocked tgt 7 s1367 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1367 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0202ffff02020000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1368 : Blocked tgt 7 s1368 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1368 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffffffffff0202ffff0202 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b1369 : Blocked tgt 7 s1369 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1369 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0202ffff0202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1370 : Blocked tgt 7 s1370 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1370 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfdfd0000fdfd0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1384 : Blocked tgt 7 s1384 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1384 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0xaaaaaaaa,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7688 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1386 : Blocked tgt 7 s1386 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1386 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3730 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1389 : Blocked tgt 7 s1389 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5288,6324,5672,5288,6836,4520,7218,6836,6836,773,6964,6836,4772,4788,6820,4772,2708,6836,6836,2708,2708,6836,6836,2708,6836,8709,14900,6836,6962,4904,7218,6962,389,389,5672,901,11465,2693,11465,2693,13513,5672,13513,14025,9673,9929,9673,9800,5672,8837,13352,8837,901,1669,2693,11465,2693,11465,12745,12745,12481,13513,11346,9673,8649,8649,8837,3154,8837,7218,901,11465,2693,901,901,13513,12481,901,901,9673,6964,901,901,13352,8837,901,2693,7208,13513,2693,2693,11465,9673,2693,2693,3273,8837,2693,4741,4741,8837,5321,8837,5257,8837,9609,8837,1417]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b1397 : Blocked tgt 7 s1397 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1397 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5367 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)

theorem b1399 : Blocked tgt 7 s1399 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1399 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1177 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1510 : Blocked tgt 7 s1510 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1510 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b1512 : Blocked tgt 7 s1512 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1512 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3759 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1517 : Blocked tgt 7 s1517 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1517 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5425 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1519 : Blocked tgt 7 s1519 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1519 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_456 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b1522 : Blocked tgt 7 s1522 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s1522 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff0202020202020202 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv35_8295 rfl)))))))) (by decide +kernel)
theorem b1585 : Blocked tgt 7 s1585 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1585 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1586 : Blocked tgt 7 s1586 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1586 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1587 : Blocked tgt 7 s1587 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s1587 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xf2f2f2f2f2f2f2f2f2f2f2f2f2f2f2f2 : BitVec 128) = 0xeeeeeeeeeeeeeeee) (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b1588 : Blocked tgt 7 s1588 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1588 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5633 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1589 : Blocked tgt 7 s1589 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1589 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2509 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6546 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1590 : Blocked tgt 7 s1590 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1590 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6277 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1591 : Blocked tgt 7 s1591 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1591 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5944 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6546 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b1592 : Blocked tgt 7 s1592 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1592 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xfd00fd00fd00fd00fd00fd00fd00fd00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1593 : Blocked tgt 7 s1593 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1593 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b1594 : Blocked tgt 7 s1594 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1594 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6546 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
