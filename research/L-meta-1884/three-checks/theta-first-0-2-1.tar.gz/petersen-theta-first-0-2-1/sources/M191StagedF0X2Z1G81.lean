import M191ResidualC7A0G20
import M191ResidualC7A0G21
import M191ResidualC7A0G22
import M191ResidualC7A0G27
import M191ResidualC7A0G3
import M191ResidualC7A0G30
import M191ResidualC7A0G32
import M191ResidualC7A0G38
import M191ResidualC7A0G4
import M191ResidualC7A0G40
import M191ResidualC7A0G9
import M191StagedF0X2Z1G10
import M191StagedF0X2Z1G14
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G18
import M191StagedF0X2Z1G19
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G22
import M191StagedF0X2Z1G23
import M191StagedF0X2Z1G24
import M191StagedF0X2Z1G25
import M191StagedF0X2Z1G26
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G8
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows4
import M191StartPreferredRows5
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4749 : Blocked tgt 8 s4749 := by
  apply PetersenFastNode.node (nxt := #[s4750,s4751,s4752,s4753,s4754,s4755,s4756,s4757,s4758,s4759,s3832,s4760,s3830,s3362,s4761,s4763,s4764,s4765,s4766,s961,s4767,s4768,s4769,s4770,s3836,s2937,s3816,s3372,s4771,s4772,s4773,s4005,s4774,s3984,s941,s4775,s3797,s4776,s4777,s4778,s4779,s4780,s4781,s4782,s4783,s4784,s4785]) (hints := [6883,6883,7011,820,0,948,7011,1,7011,6883,6883,948,5977,2,5977,6883,6883,3,5977,6883,5977,6105,4,5,7521,6883,7521,1588,6,1716,6625,7,7521,6625,6883,1716,4819,4819,8,6883,6883,10480,6883,6883,9,4819,4819,10480,4819,4819,10,6883,6883,11,4569,6883,12,4569,4819,13,13689,2755,13689,2787,6883,4788,13689,6883,13689,2755,2755,4788,13657,6883,13657,8756,14,8884,13657,15,13657,6883,6883,8884,8688,8688,5719,948,948,5977,948,948,5719,8688,8688,5977,948,948,1716,8688,8688,7521,1716,8688,1716,948,948,7521,948,948,10480,7011,7011,16,10480,7011,10480,948,948,17,948,948,18,8688,8688,19,8688,8688,20,948,948,21,948,948,4788,2915,7011,13689,4788,7011,4788,948,948,13689,948,948,8884,496,8688,13657,8884,8688,8884,948,948,13657,7009,7009,7521,1716,5977,1716,7521,5977,7521,1716,7009,1716,10480,5977,10480,7009,7009,22,10480,7009,10480,12016,5977,23,9968,5977,24,9968,7009,25,7009,7009,26,5977,5977,27,12528,10105,12528,4788,5977,4788,12528,5977,12528,4788,10105,4788,5977,5977,13657,8884,10105,8884,13657,10105,13657,8884,5977,8884,1716,1716,28,10480,7521,10480,7521,7521,29,1716,1716,10480,1716,1716,30,7521,7521,31,7521,7521,32,1716,1716,33,1716,1716,4788,12528,7521,12528,4788,7521,4788,1716,1716,12528,1716,1716,8884,3457,11649,13657,8884,11649,8884,1716,1716,13657,2740,10480,34,2740,35,36,4788,10480,4788,14721,37,14721,4788,38,4788,10480,10480,14721,8884,2224,8884,2288,10480,14689,8884,10480,8884,2224,2224,14689,4788,39,4788,12528,40,12528,4788,41,4788,12528,42,12528,8884,43,8884,14689,44,14689,8884,45,8884,14689,46,14689,4788,4788,8884,4336,12528,13657,8884,12528,8884,4788,4788,13657]) (by decide +kernel)
  change ∀ b ∈ [s4750,s4751,s4752,s4753,s4754,s4755,s4756,s4757,s4758,s4759,s3832,s4760,s3830,s3362,s4761,s4763,s4764,s4765,s4766,s961,s4767,s4768,s4769,s4770,s3836,s2937,s3816,s3372,s4771,s4772,s4773,s4005,s4774,s3984,s941,s4775,s3797,s4776,s4777,s4778,s4779,s4780,s4781,s4782,s4783,s4784,s4785], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4750) b4750 <|
    PetersenLocalChildren.push (x := s4751) b4751 <|
    PetersenLocalChildren.push (x := s4752) b4752 <|
    PetersenLocalChildren.push (x := s4753) b4753 <|
    PetersenLocalChildren.push (x := s4754) b4754 <|
    PetersenLocalChildren.push (x := s4755) b4755 <|
    PetersenLocalChildren.push (x := s4756) b4756 <|
    PetersenLocalChildren.push (x := s4757) b4757 <|
    PetersenLocalChildren.push (x := s4758) b4758 <|
    PetersenLocalChildren.push (x := s4759) b4759 <|
    PetersenLocalChildren.push (x := s3832) b3832 <|
    PetersenLocalChildren.push (x := s4760) b4760 <|
    PetersenLocalChildren.push (x := s3830) b3830 <|
    PetersenLocalChildren.push (x := s3362) b3362 <|
    PetersenLocalChildren.push (x := s4761) b4761 <|
    PetersenLocalChildren.push (x := s4763) b4763 <|
    PetersenLocalChildren.push (x := s4764) b4764 <|
    PetersenLocalChildren.push (x := s4765) b4765 <|
    PetersenLocalChildren.push (x := s4766) b4766 <|
    PetersenLocalChildren.push (x := s961) b961 <|
    PetersenLocalChildren.push (x := s4767) b4767 <|
    PetersenLocalChildren.push (x := s4768) b4768 <|
    PetersenLocalChildren.push (x := s4769) b4769 <|
    PetersenLocalChildren.push (x := s4770) b4770 <|
    PetersenLocalChildren.push (x := s3836) b3836 <|
    PetersenLocalChildren.push (x := s2937) b2937 <|
    PetersenLocalChildren.push (x := s3816) b3816 <|
    PetersenLocalChildren.push (x := s3372) b3372 <|
    PetersenLocalChildren.push (x := s4771) b4771 <|
    PetersenLocalChildren.push (x := s4772) b4772 <|
    PetersenLocalChildren.push (x := s4773) b4773 <|
    PetersenLocalChildren.push (x := s4005) b4005 <|
    PetersenLocalChildren.push (x := s4774) b4774 <|
    PetersenLocalChildren.push (x := s3984) b3984 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4775) b4775 <|
    PetersenLocalChildren.push (x := s3797) b3797 <|
    PetersenLocalChildren.push (x := s4776) b4776 <|
    PetersenLocalChildren.push (x := s4777) b4777 <|
    PetersenLocalChildren.push (x := s4778) b4778 <|
    PetersenLocalChildren.push (x := s4779) b4779 <|
    PetersenLocalChildren.push (x := s4780) b4780 <|
    PetersenLocalChildren.push (x := s4781) b4781 <|
    PetersenLocalChildren.push (x := s4782) b4782 <|
    PetersenLocalChildren.push (x := s4783) b4783 <|
    PetersenLocalChildren.push (x := s4784) b4784 <|
    PetersenLocalChildren.push (x := s4785) b4785 <|
    PetersenLocalChildren.nil
theorem b4914 : Blocked tgt 8 s4914 := by
  apply PetersenFastNode.node (nxt := #[s4915,s4851,s4916,s4853,s3946,s4917,s3944,s3433,s4918,s4919,s4921,s4922,s4923,s969,s4924,s4925,s4886,s4926,s4888,s4927,s3950,s2945,s3942,s3445,s4928,s4899,s4929,s4901,s4930,s4138,s4931,s4109,s4932,s4933,s4934,s4935,s4936,s4783,s4937,s4938,s4939,s4940,s4941,s4942,s4943,s4819,s4944,s4945,s4946,s941,s4947,s3921]) (hints := [6888,6888,7016,825,8702,953,7016,8702,7016,6888,6888,953,5982,8702,5982,9845,6888,9973,5982,6888,5982,6110,8702,9973,7526,6888,7526,8702,8702,1721,7526,8702,7526,10758,6888,1721,7518,8702,7518,4840,6888,2745,7518,6888,7518,8702,8702,2745,8702,8702,13694,2792,6888,4793,12798,6888,13694,8702,8702,4793,510,6888,0,510,8702,1,8702,8702,2,6888,6888,3,6888,6888,4,8702,8702,5,4574,8702,6,4574,6888,7,8693,8693,9973,953,953,5982,9973,953,9973,8693,8693,5982,953,953,1721,8693,8693,7526,1721,8693,1721,953,953,7526,953,953,2745,4968,7016,7518,2745,7016,2745,953,953,7518,953,953,4793,2920,7016,13694,4793,7016,4793,953,953,13694,953,953,8,501,8693,9,8629,8693,10,953,953,11,953,953,12,8693,8693,13,8693,8693,14,953,953,15,8949,7014,7526,8949,9973,1721,9973,9973,7526,1721,7014,1721,9973,9973,10485,2745,7014,2745,10485,7014,10485,9973,9973,2745,9973,9973,12533,4793,5982,4793,12533,5982,12533,9973,9973,4793,5982,5982,16,9973,9973,17,9909,9973,18,9909,5982,19,1717,5982,20,9973,9973,21,9973,9973,22,5982,5982,23,1721,1721,2745,10485,7526,10485,2745,7526,2745,1721,1721,10485,1721,1721,4793,12533,7526,12533,4793,7526,4793,1721,1721,12533,1721,1721,24,11654,11654,25,11654,11654,26,1721,1721,27,1721,1721,28,11654,11654,29,11654,11654,30,1721,1721,31,2745,2745,4793,3422,7518,14726,4793,7518,4793,2745,2745,14726,2745,2745,32,2293,10485,33,10421,10485,34,2745,2745,35,2745,2745,36,10485,10485,37,10485,10485,38,2745,2745,39,4793,4793,40,4341,12533,41,12469,12533,42,4793,4793,43,4793,4793,44,12533,12533,45,12533,12533,46,4793,4793,47,8889,48,49,8889,50,51]) (by decide +kernel)
  change ∀ b ∈ [s4915,s4851,s4916,s4853,s3946,s4917,s3944,s3433,s4918,s4919,s4921,s4922,s4923,s969,s4924,s4925,s4886,s4926,s4888,s4927,s3950,s2945,s3942,s3445,s4928,s4899,s4929,s4901,s4930,s4138,s4931,s4109,s4932,s4933,s4934,s4935,s4936,s4783,s4937,s4938,s4939,s4940,s4941,s4942,s4943,s4819,s4944,s4945,s4946,s941,s4947,s3921], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4915) b4915 <|
    PetersenLocalChildren.push (x := s4851) b4851 <|
    PetersenLocalChildren.push (x := s4916) b4916 <|
    PetersenLocalChildren.push (x := s4853) b4853 <|
    PetersenLocalChildren.push (x := s3946) b3946 <|
    PetersenLocalChildren.push (x := s4917) b4917 <|
    PetersenLocalChildren.push (x := s3944) b3944 <|
    PetersenLocalChildren.push (x := s3433) b3433 <|
    PetersenLocalChildren.push (x := s4918) b4918 <|
    PetersenLocalChildren.push (x := s4919) b4919 <|
    PetersenLocalChildren.push (x := s4921) b4921 <|
    PetersenLocalChildren.push (x := s4922) b4922 <|
    PetersenLocalChildren.push (x := s4923) b4923 <|
    PetersenLocalChildren.push (x := s969) b969 <|
    PetersenLocalChildren.push (x := s4924) b4924 <|
    PetersenLocalChildren.push (x := s4925) b4925 <|
    PetersenLocalChildren.push (x := s4886) b4886 <|
    PetersenLocalChildren.push (x := s4926) b4926 <|
    PetersenLocalChildren.push (x := s4888) b4888 <|
    PetersenLocalChildren.push (x := s4927) b4927 <|
    PetersenLocalChildren.push (x := s3950) b3950 <|
    PetersenLocalChildren.push (x := s2945) b2945 <|
    PetersenLocalChildren.push (x := s3942) b3942 <|
    PetersenLocalChildren.push (x := s3445) b3445 <|
    PetersenLocalChildren.push (x := s4928) b4928 <|
    PetersenLocalChildren.push (x := s4899) b4899 <|
    PetersenLocalChildren.push (x := s4929) b4929 <|
    PetersenLocalChildren.push (x := s4901) b4901 <|
    PetersenLocalChildren.push (x := s4930) b4930 <|
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s4931) b4931 <|
    PetersenLocalChildren.push (x := s4109) b4109 <|
    PetersenLocalChildren.push (x := s4932) b4932 <|
    PetersenLocalChildren.push (x := s4933) b4933 <|
    PetersenLocalChildren.push (x := s4934) b4934 <|
    PetersenLocalChildren.push (x := s4935) b4935 <|
    PetersenLocalChildren.push (x := s4936) b4936 <|
    PetersenLocalChildren.push (x := s4783) b4783 <|
    PetersenLocalChildren.push (x := s4937) b4937 <|
    PetersenLocalChildren.push (x := s4938) b4938 <|
    PetersenLocalChildren.push (x := s4939) b4939 <|
    PetersenLocalChildren.push (x := s4940) b4940 <|
    PetersenLocalChildren.push (x := s4941) b4941 <|
    PetersenLocalChildren.push (x := s4942) b4942 <|
    PetersenLocalChildren.push (x := s4943) b4943 <|
    PetersenLocalChildren.push (x := s4819) b4819 <|
    PetersenLocalChildren.push (x := s4944) b4944 <|
    PetersenLocalChildren.push (x := s4945) b4945 <|
    PetersenLocalChildren.push (x := s4946) b4946 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4947) b4947 <|
    PetersenLocalChildren.push (x := s3921) b3921 <|
    PetersenLocalChildren.nil
theorem b5045 : Blocked tgt 8 s5045 := by
  apply PetersenFastNode.node (nxt := #[s5046,s5047,s5048,s5049,s2901,s2664,s5050,s5051,s4750,s5052,s5053,s5054,s5055,s5056,s5057,s5058,s5059,s5060,s5061,s5062,s5063,s5064,s5065,s5066]) (hints := [797,0,797,4290,4546,8665,797,4546,797,8665,1,8665,4546,4546,6860,4288,2,3,4546,4546,5954,9945,4,5,6602,4546,7498,6602,6,7,4546,4546,7490,10457,8,10457,6594,9,7490,4546,4546,10457,8674,8674,13666,450,4546,12505,12770,4546,13666,8674,8674,12505,4546,4546,13634,482,8674,10,12738,8674,13634,4546,4546,11,8665,8665,6860,6988,12,13,8665,8665,5696,5826,797,5954,797,797,5696,8665,8665,5954,797,797,1693,8665,8665,7498,8665,8665,1693,797,797,7498,8665,8665,10457,7490,14,7490,10457,15,10457,8665,8665,7490,8665,8665,12505,13666,16,13666,12505,17,12505,8665,8665,13666,409,409,8861,473,8665,13634,8601,8665,8861,409,409,13634,5696,18,5696,5954,6860,5954,5696,6860,5696,5954,19,5954,6860,6860,7756,7498,20,7498,7756,21,7756,7498,6860,7498,4796,4796,7232,10457,6860,10457,6844,6860,7232,10457,4796,10457,2732,2732,13408,12505,6860,12505,6828,6860,13408,12505,2732,12505,6860,6860,14924,13634,22,13634,14924,23,14924,13634,6860,13634,6986,6986,7498,4930,5954,1693,7498,5954,7498,6986,6986,1693,10457,5954,10457,4938,6986,2717,10457,6986,10457,5954,5954,2717,12505,10082,12505,1858,5954,4765,12505,5954,12505,10082,10082,4765,5954,5954,13634,1890,10082,8861,13634,10082,13634,5954,5954,8861,1693,1693,2717,10457,7498,10457,7482,7498,2717,10457,1693,10457,11626,11626,14698,12505,7498,12505,14698,7498,14698,12505,11626,12505,7498,7498,14666,3434,11626,13634,14666,11626,14666,7498,7498,13634,10457,10457,12505,3394,7490,14698,12505,7490,12505,10457,10457,14698,2201,2201,13634,2265,10457,14666,10393,10457,13634,2201,2201,14666,4249,4249,8861,4313,12505,13634,12441,12505,8861,4249,4249,13634]) (by decide +kernel)
  change ∀ b ∈ [s5046,s5047,s5048,s5049,s2901,s2664,s5050,s5051,s4750,s5052,s5053,s5054,s5055,s5056,s5057,s5058,s5059,s5060,s5061,s5062,s5063,s5064,s5065,s5066], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5046) b5046 <|
    PetersenLocalChildren.push (x := s5047) b5047 <|
    PetersenLocalChildren.push (x := s5048) b5048 <|
    PetersenLocalChildren.push (x := s5049) b5049 <|
    PetersenLocalChildren.push (x := s2901) b2901 <|
    PetersenLocalChildren.push (x := s2664) b2664 <|
    PetersenLocalChildren.push (x := s5050) b5050 <|
    PetersenLocalChildren.push (x := s5051) b5051 <|
    PetersenLocalChildren.push (x := s4750) b4750 <|
    PetersenLocalChildren.push (x := s5052) b5052 <|
    PetersenLocalChildren.push (x := s5053) b5053 <|
    PetersenLocalChildren.push (x := s5054) b5054 <|
    PetersenLocalChildren.push (x := s5055) b5055 <|
    PetersenLocalChildren.push (x := s5056) b5056 <|
    PetersenLocalChildren.push (x := s5057) b5057 <|
    PetersenLocalChildren.push (x := s5058) b5058 <|
    PetersenLocalChildren.push (x := s5059) b5059 <|
    PetersenLocalChildren.push (x := s5060) b5060 <|
    PetersenLocalChildren.push (x := s5061) b5061 <|
    PetersenLocalChildren.push (x := s5062) b5062 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s5064) b5064 <|
    PetersenLocalChildren.push (x := s5065) b5065 <|
    PetersenLocalChildren.push (x := s5066) b5066 <|
    PetersenLocalChildren.nil
theorem b5134 : Blocked tgt 8 s5134 := by
  apply PetersenFastNode.node (nxt := #[s5135,s5136,s2911,s2763,s5137,s5138,s4761,s5139,s4799,s5140,s5141,s5142,s4962,s5143,s5144,s5145,s5146,s5147,s5150,s5065,s5151,s5152,s5153,s5154,s5090,s5155,s5157,s5119,s5158,s5159,s5160,s5161,s5162,s5163,s5164,s5165,s5166]) (hints := [7001,0,7001,8678,8687,8678,7001,8687,7001,8678,1,8678,5967,8687,5967,9830,2,3,7511,8687,7511,10743,4,5,7503,8687,7503,10470,6,10470,7503,7,7503,8687,8687,10470,8687,8687,13679,12518,8,12518,12783,9,13679,8687,8687,12518,495,10,8746,495,8687,11,8687,8687,8746,12,13,14,4559,8687,6873,4559,15,16,8678,8678,5709,5711,7001,5967,5709,7001,5709,8678,8678,5967,7001,7001,7769,8678,8678,7511,8678,8678,7769,7001,7001,7511,8678,8678,10470,4953,7001,7503,10470,7001,10470,8678,8678,7503,8678,8678,12518,2905,7001,13679,12518,7001,12518,8678,8678,13679,422,422,8746,486,8678,17,8614,8678,8746,422,422,18,6873,7001,6873,8678,8678,19,8678,8678,6873,7001,7001,20,6999,6999,7511,4943,5967,7769,7511,5967,7511,6999,6999,7769,10470,5967,10470,4951,6999,2730,10470,6999,10470,5967,5967,2730,12518,10095,12518,1871,5967,4778,12518,5967,12518,10095,10095,4778,5967,5967,21,2031,10095,8746,10095,10095,22,5967,5967,8746,5967,5967,23,10095,10095,6873,6095,10095,24,5967,5967,6873,5705,5705,2730,10470,7511,10470,7495,7511,2730,10470,5705,10470,11639,11639,14711,12518,7511,12518,14711,7511,14711,12518,11639,12518,7511,7511,8746,11639,11639,25,11639,11639,8746,7511,7511,26,7511,7511,6873,11639,11639,27,11639,11639,6873,7511,7511,28,10470,10470,12518,3407,7503,14711,12518,7503,12518,10470,10470,14711,2214,2214,8746,2278,10470,29,10406,10470,8746,2214,2214,30,7503,7503,4809,10470,10470,6873,10470,10470,4809,7503,7503,6873,4262,4262,8746,4326,12518,31,12454,12518,8746,4262,4262,32,2745,33,2745,12518,12518,6873,12518,12518,2745,6841,34,6873,13647,8746,6873,13647,35,36]) (by decide +kernel)
  change ∀ b ∈ [s5135,s5136,s2911,s2763,s5137,s5138,s4761,s5139,s4799,s5140,s5141,s5142,s4962,s5143,s5144,s5145,s5146,s5147,s5150,s5065,s5151,s5152,s5153,s5154,s5090,s5155,s5157,s5119,s5158,s5159,s5160,s5161,s5162,s5163,s5164,s5165,s5166], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5135) b5135 <|
    PetersenLocalChildren.push (x := s5136) b5136 <|
    PetersenLocalChildren.push (x := s2911) b2911 <|
    PetersenLocalChildren.push (x := s2763) b2763 <|
    PetersenLocalChildren.push (x := s5137) b5137 <|
    PetersenLocalChildren.push (x := s5138) b5138 <|
    PetersenLocalChildren.push (x := s4761) b4761 <|
    PetersenLocalChildren.push (x := s5139) b5139 <|
    PetersenLocalChildren.push (x := s4799) b4799 <|
    PetersenLocalChildren.push (x := s5140) b5140 <|
    PetersenLocalChildren.push (x := s5141) b5141 <|
    PetersenLocalChildren.push (x := s5142) b5142 <|
    PetersenLocalChildren.push (x := s4962) b4962 <|
    PetersenLocalChildren.push (x := s5143) b5143 <|
    PetersenLocalChildren.push (x := s5144) b5144 <|
    PetersenLocalChildren.push (x := s5145) b5145 <|
    PetersenLocalChildren.push (x := s5146) b5146 <|
    PetersenLocalChildren.push (x := s5147) b5147 <|
    PetersenLocalChildren.push (x := s5150) b5150 <|
    PetersenLocalChildren.push (x := s5065) b5065 <|
    PetersenLocalChildren.push (x := s5151) b5151 <|
    PetersenLocalChildren.push (x := s5152) b5152 <|
    PetersenLocalChildren.push (x := s5153) b5153 <|
    PetersenLocalChildren.push (x := s5154) b5154 <|
    PetersenLocalChildren.push (x := s5090) b5090 <|
    PetersenLocalChildren.push (x := s5155) b5155 <|
    PetersenLocalChildren.push (x := s5157) b5157 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s5158) b5158 <|
    PetersenLocalChildren.push (x := s5159) b5159 <|
    PetersenLocalChildren.push (x := s5160) b5160 <|
    PetersenLocalChildren.push (x := s5161) b5161 <|
    PetersenLocalChildren.push (x := s5162) b5162 <|
    PetersenLocalChildren.push (x := s5163) b5163 <|
    PetersenLocalChildren.push (x := s5164) b5164 <|
    PetersenLocalChildren.push (x := s5165) b5165 <|
    PetersenLocalChildren.push (x := s5166) b5166 <|
    PetersenLocalChildren.nil
theorem b5176 : Blocked tgt 8 s5176 := by
  apply PetersenFastNode.node (nxt := #[s5177,s5178,s1007,s941,s5179,s4859,s4990,s5185,s1140,s5063,s5186]) (hints := [4533,4533,0,8652,1,8652,9932,9932,7485,2,3,4,2704,10444,2704,10444,4752,12492,4752,12492,8848,5,8848,6,6847,8652,7,8652,5941,6847,6069,7485,8,7485,6847,6847,9,10,6847,7477,10444,7477,10444,13653,12492,13653,12492,13621,8720,13621,6847,8652,5685,5683,8652,7229,8652,7485,8652,912,8652,7221,10444,8652,8652,13397,12492,8652,396,460,8588,396,6973,4917,7485,6973,10843,5941,5941,10843,10444,2704,10444,2704,12492,4752,12492,4752,5941,8848,13621,8848,1680,1680,2704,10444,2704,10444,4752,12492,4752,12492,8848,3421,8848,7485,2704,10444,2704,10444,4752,12492,4752,12492,8848,13621,8848,13621,10444,3381,12492,10444,2188,2252,10380,2188,4236,4300,12428,4236]) (by decide +kernel)
  change ∀ b ∈ [s5177,s5178,s1007,s941,s5179,s4859,s4990,s5185,s1140,s5063,s5186], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5177) b5177 <|
    PetersenLocalChildren.push (x := s5178) b5178 <|
    PetersenLocalChildren.push (x := s1007) b1007 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s5179) b5179 <|
    PetersenLocalChildren.push (x := s4859) b4859 <|
    PetersenLocalChildren.push (x := s4990) b4990 <|
    PetersenLocalChildren.push (x := s5185) b5185 <|
    PetersenLocalChildren.push (x := s1140) b1140 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s5186) b5186 <|
    PetersenLocalChildren.nil
theorem b5198 : Blocked tgt 8 s5198 := by
  apply PetersenFastNode.node (nxt := #[s5199,s5200,s5201,s4919,s5202,s5203,s969,s5204,s5205,s5209,s5147,s5065,s5210]) (hints := [4535,4535,0,8654,1,8654,9934,9934,1682,2,2706,10446,2706,10446,4754,12494,4754,12494,13623,3,13623,4,5,6,7,8,6849,8654,9,8654,5943,6849,6071,7487,1554,7487,6849,7479,10446,7479,10446,13655,12494,13655,12494,13623,10,13623,6849,6849,11,12,6849,8654,5943,5685,8654,1682,8654,8654,7487,8654,7479,10446,8654,8654,13399,12494,8654,462,8654,13623,8654,398,6975,1682,7487,1682,10446,2706,10446,2706,12494,4754,12494,4754,5943,1879,13623,5943,5685,5943,5943,5685,1682,10446,2706,10446,1682,12494,4754,12494,1682,3423,14655,1682,1682,7487,7487,1682,10446,3383,12494,10446,2190,10446,10446,2190,2190,10446,10446,2190,4238,12494,12494,4238,4238,12494,12494,4238,8850,8850]) (by decide +kernel)
  change ∀ b ∈ [s5199,s5200,s5201,s4919,s5202,s5203,s969,s5204,s5205,s5209,s5147,s5065,s5210], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5199) b5199 <|
    PetersenLocalChildren.push (x := s5200) b5200 <|
    PetersenLocalChildren.push (x := s5201) b5201 <|
    PetersenLocalChildren.push (x := s4919) b4919 <|
    PetersenLocalChildren.push (x := s5202) b5202 <|
    PetersenLocalChildren.push (x := s5203) b5203 <|
    PetersenLocalChildren.push (x := s969) b969 <|
    PetersenLocalChildren.push (x := s5204) b5204 <|
    PetersenLocalChildren.push (x := s5205) b5205 <|
    PetersenLocalChildren.push (x := s5209) b5209 <|
    PetersenLocalChildren.push (x := s5147) b5147 <|
    PetersenLocalChildren.push (x := s5065) b5065 <|
    PetersenLocalChildren.push (x := s5210) b5210 <|
    PetersenLocalChildren.nil
theorem b5238 : Blocked tgt 8 s5238 := by
  apply PetersenFastNode.node (nxt := #[s5239,s4899,s5018,s941,s5240,s5115,s5155,s5119,s5245]) (hints := [4531,4531,910,8650,910,8650,9930,9930,11611,0,2702,10442,2702,10442,4750,12490,4750,12490,13619,1,13619,2,3,4,6845,8650,6973,8650,5939,6845,6067,11611,5,11611,6845,7475,10442,7475,10442,13651,12490,13651,12490,13619,6,13619,6845,6845,7,8,6845,8650,910,910,8650,910,8650,8650,910,8650,4925,10442,8650,8650,2877,12490,8650,394,458,8586,394,910,8650,8650,910,6971,5939,11611,6971,10442,2702,10442,2702,12490,4750,12490,4750,5939,1875,13619,5939,6971,5939,5939,6971,2702,10442,2702,10442,4750,12490,4750,12490,3419,11611,13619,1678,1678,10442,3379,12490,10442,2186,2250,10378,2186,2702,10442,10442,2702,4234,4298,12426,4234,4750,12490,12490,4750,8846,8846]) (by decide +kernel)
  change ∀ b ∈ [s5239,s4899,s5018,s941,s5240,s5115,s5155,s5119,s5245], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5239) b5239 <|
    PetersenLocalChildren.push (x := s4899) b4899 <|
    PetersenLocalChildren.push (x := s5018) b5018 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s5240) b5240 <|
    PetersenLocalChildren.push (x := s5115) b5115 <|
    PetersenLocalChildren.push (x := s5155) b5155 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s5245) b5245 <|
    PetersenLocalChildren.nil
theorem b5331 : Blocked tgt 8 s5331 := by
  apply PetersenFastNode.node (nxt := #[s5332,s5333,s5336,s5337,s5338,s4138,s4931,s5339,s5340,s5328,s5341,s5330,s5342,s4711,s5343,s5344]) (hints := [6852,789,6980,6852,5946,9817,5946,6074,8666,8666,9690,6852,6852,9690,9690,10722,7482,4804,7482,9690,9690,2756,13658,9690,1498,1498,9690,6852,6852,9690,5562,5562,9689,917,9945,9689,917,8665,9681,917,917,9689,9689,917,917,4932,2709,917,917,2884,4757,917,917,1497,9625,917,917,9689,9689,917,6978,9945,9937,9937,8913,9945,9945,6978,9945,2709,11481,9945,9945,4757,13529,9945,5946,9945,9881,9881,1689,9945,9945,5946,1685,1685,2709,10457,2709,11473,4757,12505,4757,13521,0,1,2,3,4,5,6,7,2709,11481,2709,11481,4757,13529,4757,13529,8,9,10,11,12,13,14,15,2709,3386,4757,2709,2709,3289,11417,2709,2709,11481,11481,2709,4757,5337,13465,4757,4757,13529,13529,4757,8853,8853]) (by decide +kernel)
  change ∀ b ∈ [s5332,s5333,s5336,s5337,s5338,s4138,s4931,s5339,s5340,s5328,s5341,s5330,s5342,s4711,s5343,s5344], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5332) b5332 <|
    PetersenLocalChildren.push (x := s5333) b5333 <|
    PetersenLocalChildren.push (x := s5336) b5336 <|
    PetersenLocalChildren.push (x := s5337) b5337 <|
    PetersenLocalChildren.push (x := s5338) b5338 <|
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s4931) b4931 <|
    PetersenLocalChildren.push (x := s5339) b5339 <|
    PetersenLocalChildren.push (x := s5340) b5340 <|
    PetersenLocalChildren.push (x := s5328) b5328 <|
    PetersenLocalChildren.push (x := s5341) b5341 <|
    PetersenLocalChildren.push (x := s5330) b5330 <|
    PetersenLocalChildren.push (x := s5342) b5342 <|
    PetersenLocalChildren.push (x := s4711) b4711 <|
    PetersenLocalChildren.push (x := s5343) b5343 <|
    PetersenLocalChildren.push (x := s5344) b5344 <|
    PetersenLocalChildren.nil
theorem b5347 : Blocked tgt 8 s5347 := by
  apply PetersenFastNode.node (nxt := #[s5348,s5349,s5350,s4968,s5351,s4970,s5352,s5353,s5354,s5355,s5356,s5357,s5358,s5359,s5361,s5362,s5363,s1112,s5364,s5365,s5005,s5366,s5007,s5367,s5368,s3132,s5369,s5370,s5017,s5371,s5019,s5372,s5373,s5374,s5375,s5376,s5377,s1092,s5378,s5379,s5380,s5381,s5382,s5383,s5384,s5385,s5386,s5387,s5388,s5389,s5390,s5391,s5392,s5393,s5394,s5395]) (hints := [6892,6892,7020,829,5602,957,7020,5602,7020,6892,6892,957,10114,5602,10114,1601,6892,1729,10114,6892,10114,10242,5602,1729,5602,5602,13666,1538,0,8893,13666,1,13666,5602,5602,8893,4578,6892,2,4578,5602,3,5602,5602,4,6892,6892,5,6892,6892,6,5602,5602,7,5602,5602,8,6634,6892,9,11650,5602,11650,4844,6892,2749,11650,6892,11650,5602,5602,2749,13698,1474,13698,1506,5602,4797,13698,5602,13698,1474,1474,4797,1473,1473,1729,957,957,10114,1729,957,1729,1473,1473,10114,957,957,8893,13410,10,13666,8893,11,8893,957,957,13666,957,957,12,449,1473,13,1465,1473,14,957,957,15,957,957,16,1473,1473,17,1473,1473,18,957,957,19,957,957,2749,4972,7020,11650,2749,7020,2749,957,957,11650,957,957,4797,2924,7020,13698,4797,7020,4797,957,957,13698,1729,1729,13666,8893,10114,8893,9921,10114,13666,1729,1729,8893,11146,11146,20,1729,1729,21,1721,1729,22,1721,11146,23,11146,11146,24,1729,1729,25,1729,1729,26,11146,11146,27,1729,1729,3265,2749,11146,2749,3265,11146,3265,1729,1729,2749,1729,1729,5313,4797,5986,4797,5313,5986,5313,1729,1729,4797,8893,8893,28,13666,13666,29,13666,13666,30,8893,8893,31,8893,8893,32,13666,13666,33,13666,13666,34,8893,8893,35,2749,8893,2749,3458,14698,11650,2749,14698,2749,8893,8893,11650,4797,8893,4797,13666,13666,13698,4797,13666,4797,8893,8893,13698,1725,36,37,1725,38,39,2749,40,2749,2241,41,3265,2749,42,2749,3257,43,3265,4797,44,4797,4289,45,5313,4797,46,4797,5305,47,5313,2749,48,2749,3265,49,3265,2749,50,2749,3265,51,3265,4797,52,4797,5313,53,5313,4797,54,4797,5313,55,5313,2749,2749,4797,12682,7522,14730,4797,7522,4797,2749,2749,14730]) (by decide +kernel)
  change ∀ b ∈ [s5348,s5349,s5350,s4968,s5351,s4970,s5352,s5353,s5354,s5355,s5356,s5357,s5358,s5359,s5361,s5362,s5363,s1112,s5364,s5365,s5005,s5366,s5007,s5367,s5368,s3132,s5369,s5370,s5017,s5371,s5019,s5372,s5373,s5374,s5375,s5376,s5377,s1092,s5378,s5379,s5380,s5381,s5382,s5383,s5384,s5385,s5386,s5387,s5388,s5389,s5390,s5391,s5392,s5393,s5394,s5395], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5348) b5348 <|
    PetersenLocalChildren.push (x := s5349) b5349 <|
    PetersenLocalChildren.push (x := s5350) b5350 <|
    PetersenLocalChildren.push (x := s4968) b4968 <|
    PetersenLocalChildren.push (x := s5351) b5351 <|
    PetersenLocalChildren.push (x := s4970) b4970 <|
    PetersenLocalChildren.push (x := s5352) b5352 <|
    PetersenLocalChildren.push (x := s5353) b5353 <|
    PetersenLocalChildren.push (x := s5354) b5354 <|
    PetersenLocalChildren.push (x := s5355) b5355 <|
    PetersenLocalChildren.push (x := s5356) b5356 <|
    PetersenLocalChildren.push (x := s5357) b5357 <|
    PetersenLocalChildren.push (x := s5358) b5358 <|
    PetersenLocalChildren.push (x := s5359) b5359 <|
    PetersenLocalChildren.push (x := s5361) b5361 <|
    PetersenLocalChildren.push (x := s5362) b5362 <|
    PetersenLocalChildren.push (x := s5363) b5363 <|
    PetersenLocalChildren.push (x := s1112) b1112 <|
    PetersenLocalChildren.push (x := s5364) b5364 <|
    PetersenLocalChildren.push (x := s5365) b5365 <|
    PetersenLocalChildren.push (x := s5005) b5005 <|
    PetersenLocalChildren.push (x := s5366) b5366 <|
    PetersenLocalChildren.push (x := s5007) b5007 <|
    PetersenLocalChildren.push (x := s5367) b5367 <|
    PetersenLocalChildren.push (x := s5368) b5368 <|
    PetersenLocalChildren.push (x := s3132) b3132 <|
    PetersenLocalChildren.push (x := s5369) b5369 <|
    PetersenLocalChildren.push (x := s5370) b5370 <|
    PetersenLocalChildren.push (x := s5017) b5017 <|
    PetersenLocalChildren.push (x := s5371) b5371 <|
    PetersenLocalChildren.push (x := s5019) b5019 <|
    PetersenLocalChildren.push (x := s5372) b5372 <|
    PetersenLocalChildren.push (x := s5373) b5373 <|
    PetersenLocalChildren.push (x := s5374) b5374 <|
    PetersenLocalChildren.push (x := s5375) b5375 <|
    PetersenLocalChildren.push (x := s5376) b5376 <|
    PetersenLocalChildren.push (x := s5377) b5377 <|
    PetersenLocalChildren.push (x := s1092) b1092 <|
    PetersenLocalChildren.push (x := s5378) b5378 <|
    PetersenLocalChildren.push (x := s5379) b5379 <|
    PetersenLocalChildren.push (x := s5380) b5380 <|
    PetersenLocalChildren.push (x := s5381) b5381 <|
    PetersenLocalChildren.push (x := s5382) b5382 <|
    PetersenLocalChildren.push (x := s5383) b5383 <|
    PetersenLocalChildren.push (x := s5384) b5384 <|
    PetersenLocalChildren.push (x := s5385) b5385 <|
    PetersenLocalChildren.push (x := s5386) b5386 <|
    PetersenLocalChildren.push (x := s5387) b5387 <|
    PetersenLocalChildren.push (x := s5388) b5388 <|
    PetersenLocalChildren.push (x := s5389) b5389 <|
    PetersenLocalChildren.push (x := s5390) b5390 <|
    PetersenLocalChildren.push (x := s5391) b5391 <|
    PetersenLocalChildren.push (x := s5392) b5392 <|
    PetersenLocalChildren.push (x := s5393) b5393 <|
    PetersenLocalChildren.push (x := s5394) b5394 <|
    PetersenLocalChildren.push (x := s5395) b5395 <|
    PetersenLocalChildren.nil
theorem b5415 : Blocked tgt 8 s5415 := by
  apply PetersenFastNode.node (nxt := #[s5137,s5348,s5416,s5417,s5119,s5418,s5419,s5420,s5421,s5422]) (hints := [6974,9683,6974,9682,5940,9811,8660,9684,0,9684,10716,7476,11347,7476,9684,9684,13395,13652,9684,1492,1492,9684,1,5556,5556,9683,5684,5682,9683,8651,8659,9675,8651,6974,9683,9683,6974,9683,4926,11475,9683,9683,2878,13523,9683,1427,1491,9619,1427,6846,9683,9683,6974,6972,5940,5940,6972,6972,5940,5940,6972,11475,4924,11475,5940,13523,1844,13523,10068,5940,2004,10068,5940,5940,10068,6068,5940,7484,7484,10443,10451,10443,11467,12491,12499,12491,13515,8719,2,8719,3,6846,4,6846,5,2703,11475,2703,11475,14684,13523,14684,13523,8719,6,8719,7,6846,8,6846,9,11475,3380,13523,11475,3219,3283,11411,3219,7476,11475,11475,7476,5267,5331,13459,5267,2718,13523,13523,6814,13620,13620]) (by decide +kernel)
  change ∀ b ∈ [s5137,s5348,s5416,s5417,s5119,s5418,s5419,s5420,s5421,s5422], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5137) b5137 <|
    PetersenLocalChildren.push (x := s5348) b5348 <|
    PetersenLocalChildren.push (x := s5416) b5416 <|
    PetersenLocalChildren.push (x := s5417) b5417 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s5418) b5418 <|
    PetersenLocalChildren.push (x := s5419) b5419 <|
    PetersenLocalChildren.push (x := s5420) b5420 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s5422) b5422 <|
    PetersenLocalChildren.nil
theorem b5454 : Blocked tgt 8 s5454 := by
  apply PetersenFastNode.node (nxt := #[s5455,s5333,s5456,s5457,s4138,s4552,s5240,s5458,s5416,s5119,s5459,s5460]) (hints := [5558,5558,913,8653,913,8653,9933,9933,11614,0,2705,10445,2705,10445,4753,12493,4753,12493,13622,1,13622,2,3,4,5,6,6848,8653,6976,8653,5942,6848,6070,11614,7,11614,6848,7478,10445,7478,10445,13654,12493,13654,12493,13622,8,13622,6848,6848,9,10,6848,8653,913,913,8653,913,8653,8653,913,8653,4928,10445,8653,8653,2880,12493,8653,1429,1485,8597,1429,397,8653,8653,397,6974,5942,11614,6974,10445,2705,10445,2705,12493,4753,12493,4753,5942,1878,13622,5942,6974,5942,5942,6974,2705,10445,2705,10445,4753,12493,4753,12493,3422,3422,11614,13622,11,11614,1681,1681,10445,3382,12493,10445,3221,3277,10389,3221,2189,10445,10445,2189,5269,5325,12437,5269,4237,12493,12493,4237,8849,8849]) (by decide +kernel)
  change ∀ b ∈ [s5455,s5333,s5456,s5457,s4138,s4552,s5240,s5458,s5416,s5119,s5459,s5460], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5455) b5455 <|
    PetersenLocalChildren.push (x := s5333) b5333 <|
    PetersenLocalChildren.push (x := s5456) b5456 <|
    PetersenLocalChildren.push (x := s5457) b5457 <|
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s4552) b4552 <|
    PetersenLocalChildren.push (x := s5240) b5240 <|
    PetersenLocalChildren.push (x := s5458) b5458 <|
    PetersenLocalChildren.push (x := s5416) b5416 <|
    PetersenLocalChildren.push (x := s5119) b5119 <|
    PetersenLocalChildren.push (x := s5459) b5459 <|
    PetersenLocalChildren.push (x := s5460) b5460 <|
    PetersenLocalChildren.nil
theorem b5854 : Blocked tgt 8 s5854 := by
  apply PetersenFastNode.node (nxt := #[s2968,s5138,s5855,s5856,s5857,s5858,s5859,s5860,s5861,s5862,s991,s5863,s5864,s5865,s5866,s5869,s5870,s5871,s5874,s5875,s5876,s5877,s5878,s3007,s5879,s5880,s5881,s5882,s5883,s5884,s5885,s5886,s5887,s5888,s5889,s5890,s5891,s5892,s5893,s5894,s5895,s5896,s5897,s5898,s5899,s5900,s5901,s5902,s5903]) (hints := [7013,10497,7013,950,10755,950,7013,10755,7013,950,10497,950,5979,10755,5979,8818,0,8946,5979,1,5979,10235,10755,8946,7523,10755,7523,8699,2,1718,7523,3,7523,10755,10755,1718,7515,8691,7515,8707,10755,2742,7515,10755,7515,8691,8691,2742,13691,10755,13691,4790,4,4790,13691,5,13691,10755,10755,4790,2563,6,7,10755,10755,8,8886,9,8886,6627,10755,10,6627,9,11,8690,8690,8946,438,950,5979,8946,950,8946,8690,8690,5979,950,950,1718,7267,12,7523,1718,13,1718,950,950,7523,950,950,2742,4965,7013,7515,2742,7013,2742,950,950,7515,950,950,4790,2917,7013,13691,4790,7013,4790,950,950,13691,950,950,8886,498,8690,14,8886,8690,8886,950,950,15,7013,7013,16,950,950,17,950,950,18,7013,7013,19,8946,8946,7523,1718,5979,1718,9970,5979,7523,8946,8946,1718,8946,8946,10482,2230,7011,2742,10482,7011,10482,8946,8946,2742,8946,8946,12530,4278,5979,4790,12530,5979,12530,8946,8946,4790,5979,5979,20,8886,8946,8886,8882,8946,21,8882,5979,8886,5979,5979,22,8946,8946,23,8946,8946,24,5979,5979,25,1718,1718,2742,7515,7523,7515,2742,7523,2742,1718,1718,7515,1718,1718,4790,3427,7523,13691,4790,7523,4790,1718,1718,13691,1718,1718,8886,11651,11651,26,8886,11651,8886,1718,1718,27,7523,7523,28,1718,1718,29,1718,1718,30,7523,7523,31,2742,2742,4790,3419,7515,14723,4790,7515,4790,2742,2742,14723,2742,2742,8886,2290,10482,32,8886,10482,8886,2742,2742,33,7515,7515,34,2742,2742,35,2742,2742,36,7515,7515,37,4790,4790,8886,4338,12530,38,8886,12530,8886,4790,4790,39,40,41,42,4790,4790,43,4790,4790,44,45,46,47,8886,8886,10,13659,8,48]) (by decide +kernel)
  change ∀ b ∈ [s2968,s5138,s5855,s5856,s5857,s5858,s5859,s5860,s5861,s5862,s991,s5863,s5864,s5865,s5866,s5869,s5870,s5871,s5874,s5875,s5876,s5877,s5878,s3007,s5879,s5880,s5881,s5882,s5883,s5884,s5885,s5886,s5887,s5888,s5889,s5890,s5891,s5892,s5893,s5894,s5895,s5896,s5897,s5898,s5899,s5900,s5901,s5902,s5903], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2968) b2968 <|
    PetersenLocalChildren.push (x := s5138) b5138 <|
    PetersenLocalChildren.push (x := s5855) b5855 <|
    PetersenLocalChildren.push (x := s5856) b5856 <|
    PetersenLocalChildren.push (x := s5857) b5857 <|
    PetersenLocalChildren.push (x := s5858) b5858 <|
    PetersenLocalChildren.push (x := s5859) b5859 <|
    PetersenLocalChildren.push (x := s5860) b5860 <|
    PetersenLocalChildren.push (x := s5861) b5861 <|
    PetersenLocalChildren.push (x := s5862) b5862 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s5863) b5863 <|
    PetersenLocalChildren.push (x := s5864) b5864 <|
    PetersenLocalChildren.push (x := s5865) b5865 <|
    PetersenLocalChildren.push (x := s5866) b5866 <|
    PetersenLocalChildren.push (x := s5869) b5869 <|
    PetersenLocalChildren.push (x := s5870) b5870 <|
    PetersenLocalChildren.push (x := s5871) b5871 <|
    PetersenLocalChildren.push (x := s5874) b5874 <|
    PetersenLocalChildren.push (x := s5875) b5875 <|
    PetersenLocalChildren.push (x := s5876) b5876 <|
    PetersenLocalChildren.push (x := s5877) b5877 <|
    PetersenLocalChildren.push (x := s5878) b5878 <|
    PetersenLocalChildren.push (x := s3007) b3007 <|
    PetersenLocalChildren.push (x := s5879) b5879 <|
    PetersenLocalChildren.push (x := s5880) b5880 <|
    PetersenLocalChildren.push (x := s5881) b5881 <|
    PetersenLocalChildren.push (x := s5882) b5882 <|
    PetersenLocalChildren.push (x := s5883) b5883 <|
    PetersenLocalChildren.push (x := s5884) b5884 <|
    PetersenLocalChildren.push (x := s5885) b5885 <|
    PetersenLocalChildren.push (x := s5886) b5886 <|
    PetersenLocalChildren.push (x := s5887) b5887 <|
    PetersenLocalChildren.push (x := s5888) b5888 <|
    PetersenLocalChildren.push (x := s5889) b5889 <|
    PetersenLocalChildren.push (x := s5890) b5890 <|
    PetersenLocalChildren.push (x := s5891) b5891 <|
    PetersenLocalChildren.push (x := s5892) b5892 <|
    PetersenLocalChildren.push (x := s5893) b5893 <|
    PetersenLocalChildren.push (x := s5894) b5894 <|
    PetersenLocalChildren.push (x := s5895) b5895 <|
    PetersenLocalChildren.push (x := s5896) b5896 <|
    PetersenLocalChildren.push (x := s5897) b5897 <|
    PetersenLocalChildren.push (x := s5898) b5898 <|
    PetersenLocalChildren.push (x := s5899) b5899 <|
    PetersenLocalChildren.push (x := s5900) b5900 <|
    PetersenLocalChildren.push (x := s5901) b5901 <|
    PetersenLocalChildren.push (x := s5902) b5902 <|
    PetersenLocalChildren.push (x := s5903) b5903 <|
    PetersenLocalChildren.nil
theorem b5967 : Blocked tgt 8 s5967 := by
  apply PetersenFastNode.node (nxt := #[s5968,s5969,s5970,s5971,s5866,s5972,s5973,s5871,s5974,s5975,s5976,s5977,s5978,s5979,s5980,s5981,s5941,s5982,s5983,s5984,s5985,s5986,s991,s5987,s5988,s5989,s5990,s5991,s5992,s5993,s5994,s5995,s5996,s5997,s5998,s5999,s6000,s6001,s6002,s6003,s6004,s5961,s6005,s6006,s6007]) (hints := [6881,6881,0,6623,6623,8686,6623,6623,1,6881,6881,8686,5975,6623,5975,6369,6881,8942,5975,6881,5975,6103,6623,8942,6623,6623,7519,4567,2,1714,7519,3,7519,6623,6623,1714,7511,4559,7511,4575,6623,2738,7511,6623,7511,4559,4559,2738,13687,10751,13687,2527,6623,4786,13687,6623,13687,10751,10751,4786,13655,6623,13655,2559,10751,4,13655,10751,13655,6623,6623,5,6881,6881,6,6623,6623,7,6623,6623,8,6881,6881,9,8686,8686,8942,5975,10,5975,8942,11,8942,8686,8686,5975,1714,8686,1714,7519,12,7519,1714,13,1714,8686,8686,7519,2738,8686,2738,7511,14,7511,2738,15,2738,8686,8686,7511,4786,8686,4786,13431,16,13687,4786,17,4786,8686,8686,13687,494,18,19,8686,8686,20,13655,21,13655,946,8686,22,946,21,23,8942,8942,7519,1714,5975,1714,9966,5975,7519,8942,8942,1714,8942,8942,10478,2226,7007,2738,10478,7007,10478,8942,8942,2738,8942,8942,12526,4274,5975,4786,12526,5975,12526,8942,8942,4786,5975,5975,13655,8942,8942,24,8942,8942,13655,5975,5975,25,5717,5717,26,8942,8942,27,8942,8942,28,5717,5717,29,1714,1714,2738,7511,7519,7511,2738,7519,2738,1714,1714,7511,1714,1714,4786,3423,7519,13687,4786,7519,4786,1714,1714,13687,1714,1714,14687,3455,11647,13655,14687,11647,14687,1714,1714,13655,1714,1714,30,7519,7519,31,7519,7519,32,1714,1714,33,2738,2738,4786,3415,7511,14719,4786,7511,4786,2738,2738,14719,2738,2738,13655,10478,10478,14687,10478,10478,13655,2738,2738,14687,2738,2738,34,10478,10478,35,10478,10478,36,2738,2738,37,4786,4786,38,12526,12526,13655,12526,12526,39,4786,4786,13655,4786,4786,40,12526,12526,41,12526,12526,42,4786,4786,43,8882,13655,22,8882,20,44]) (by decide +kernel)
  change ∀ b ∈ [s5968,s5969,s5970,s5971,s5866,s5972,s5973,s5871,s5974,s5975,s5976,s5977,s5978,s5979,s5980,s5981,s5941,s5982,s5983,s5984,s5985,s5986,s991,s5987,s5988,s5989,s5990,s5991,s5992,s5993,s5994,s5995,s5996,s5997,s5998,s5999,s6000,s6001,s6002,s6003,s6004,s5961,s6005,s6006,s6007], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5968) b5968 <|
    PetersenLocalChildren.push (x := s5969) b5969 <|
    PetersenLocalChildren.push (x := s5970) b5970 <|
    PetersenLocalChildren.push (x := s5971) b5971 <|
    PetersenLocalChildren.push (x := s5866) b5866 <|
    PetersenLocalChildren.push (x := s5972) b5972 <|
    PetersenLocalChildren.push (x := s5973) b5973 <|
    PetersenLocalChildren.push (x := s5871) b5871 <|
    PetersenLocalChildren.push (x := s5974) b5974 <|
    PetersenLocalChildren.push (x := s5975) b5975 <|
    PetersenLocalChildren.push (x := s5976) b5976 <|
    PetersenLocalChildren.push (x := s5977) b5977 <|
    PetersenLocalChildren.push (x := s5978) b5978 <|
    PetersenLocalChildren.push (x := s5979) b5979 <|
    PetersenLocalChildren.push (x := s5980) b5980 <|
    PetersenLocalChildren.push (x := s5981) b5981 <|
    PetersenLocalChildren.push (x := s5941) b5941 <|
    PetersenLocalChildren.push (x := s5982) b5982 <|
    PetersenLocalChildren.push (x := s5983) b5983 <|
    PetersenLocalChildren.push (x := s5984) b5984 <|
    PetersenLocalChildren.push (x := s5985) b5985 <|
    PetersenLocalChildren.push (x := s5986) b5986 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s5987) b5987 <|
    PetersenLocalChildren.push (x := s5988) b5988 <|
    PetersenLocalChildren.push (x := s5989) b5989 <|
    PetersenLocalChildren.push (x := s5990) b5990 <|
    PetersenLocalChildren.push (x := s5991) b5991 <|
    PetersenLocalChildren.push (x := s5992) b5992 <|
    PetersenLocalChildren.push (x := s5993) b5993 <|
    PetersenLocalChildren.push (x := s5994) b5994 <|
    PetersenLocalChildren.push (x := s5995) b5995 <|
    PetersenLocalChildren.push (x := s5996) b5996 <|
    PetersenLocalChildren.push (x := s5997) b5997 <|
    PetersenLocalChildren.push (x := s5998) b5998 <|
    PetersenLocalChildren.push (x := s5999) b5999 <|
    PetersenLocalChildren.push (x := s6000) b6000 <|
    PetersenLocalChildren.push (x := s6001) b6001 <|
    PetersenLocalChildren.push (x := s6002) b6002 <|
    PetersenLocalChildren.push (x := s6003) b6003 <|
    PetersenLocalChildren.push (x := s6004) b6004 <|
    PetersenLocalChildren.push (x := s5961) b5961 <|
    PetersenLocalChildren.push (x := s6005) b6005 <|
    PetersenLocalChildren.push (x := s6006) b6006 <|
    PetersenLocalChildren.push (x := s6007) b6007 <|
    PetersenLocalChildren.nil
theorem b6019 : Blocked tgt 8 s6019 := by
  apply PetersenFastNode.node (nxt := #[s2990,s6020,s6021,s6022,s6023,s6024,s6025,s3003,s6026,s6027,s6028,s6029,s5943,s6030,s6031,s5946,s6032,s6033,s6034,s6035,s6036,s6037,s991,s6038,s6039,s6040,s6041,s6042,s6043,s6044,s6045,s6046,s6047,s6048,s6049,s6050,s6051,s6052,s6053,s6054,s6055,s6056,s6057,s6058,s6059,s6060,s6065,s6066,s6067]) (hints := [6885,6885,7013,822,6627,950,7013,6627,7013,6885,6885,950,5979,6627,5979,6373,6885,0,5979,6885,5979,6107,6627,1,6627,6627,7523,4571,2,1718,7523,3,7523,6627,6627,1718,7515,4563,7515,4579,6627,2742,7515,6627,7515,4563,4563,2742,10755,10755,4,6627,6627,4790,6627,6627,5,10755,10755,4790,10755,10755,6,6627,6627,7,6627,6627,8,10755,10755,9,13659,6627,13659,2563,10755,8886,13659,10755,13659,6627,6627,8886,8690,8690,5721,950,950,5979,950,950,5721,8690,8690,5979,950,950,1718,7267,10,7523,1718,11,1718,950,950,7523,950,950,2742,4965,7013,7515,2742,7013,2742,950,950,7515,950,950,4790,2917,7013,12,4790,7013,4790,950,950,13,8690,8690,14,950,950,15,950,950,16,8690,8690,17,950,950,8886,498,8690,13659,8886,8690,8886,950,950,13659,7011,7011,7523,1718,5979,1718,7523,5979,7523,1718,7011,1718,10482,5979,10482,2742,7011,2742,10482,7011,10482,2742,5979,2742,4278,18,19,5979,5979,20,4790,21,4790,8946,5979,22,8946,21,23,5979,5979,13659,8886,24,8886,13659,25,13659,8886,5979,8886,1718,1718,2742,7515,7523,7515,2742,7523,2742,1718,1718,7515,1718,1718,4790,7523,7523,26,4790,7523,4790,1718,1718,27,11651,11651,28,1718,1718,29,1718,1718,30,11651,11651,31,1718,1718,8886,3459,11651,13659,8886,11651,8886,1718,1718,13659,2742,2742,4790,7515,7515,32,4790,7515,4790,2742,2742,33,10482,10482,34,2742,2742,35,2742,2742,36,10482,10482,37,2742,2742,8886,2290,10482,14691,8886,10482,8886,2742,2742,14691,4790,4790,22,12530,20,38,4790,4790,8886,13659,39,13659,8886,40,8886,4790,4790,13659,41,42,43,8886,44,8886,45,46,47,8886,48,8886]) (by decide +kernel)
  change ∀ b ∈ [s2990,s6020,s6021,s6022,s6023,s6024,s6025,s3003,s6026,s6027,s6028,s6029,s5943,s6030,s6031,s5946,s6032,s6033,s6034,s6035,s6036,s6037,s991,s6038,s6039,s6040,s6041,s6042,s6043,s6044,s6045,s6046,s6047,s6048,s6049,s6050,s6051,s6052,s6053,s6054,s6055,s6056,s6057,s6058,s6059,s6060,s6065,s6066,s6067], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2990) b2990 <|
    PetersenLocalChildren.push (x := s6020) b6020 <|
    PetersenLocalChildren.push (x := s6021) b6021 <|
    PetersenLocalChildren.push (x := s6022) b6022 <|
    PetersenLocalChildren.push (x := s6023) b6023 <|
    PetersenLocalChildren.push (x := s6024) b6024 <|
    PetersenLocalChildren.push (x := s6025) b6025 <|
    PetersenLocalChildren.push (x := s3003) b3003 <|
    PetersenLocalChildren.push (x := s6026) b6026 <|
    PetersenLocalChildren.push (x := s6027) b6027 <|
    PetersenLocalChildren.push (x := s6028) b6028 <|
    PetersenLocalChildren.push (x := s6029) b6029 <|
    PetersenLocalChildren.push (x := s5943) b5943 <|
    PetersenLocalChildren.push (x := s6030) b6030 <|
    PetersenLocalChildren.push (x := s6031) b6031 <|
    PetersenLocalChildren.push (x := s5946) b5946 <|
    PetersenLocalChildren.push (x := s6032) b6032 <|
    PetersenLocalChildren.push (x := s6033) b6033 <|
    PetersenLocalChildren.push (x := s6034) b6034 <|
    PetersenLocalChildren.push (x := s6035) b6035 <|
    PetersenLocalChildren.push (x := s6036) b6036 <|
    PetersenLocalChildren.push (x := s6037) b6037 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s6038) b6038 <|
    PetersenLocalChildren.push (x := s6039) b6039 <|
    PetersenLocalChildren.push (x := s6040) b6040 <|
    PetersenLocalChildren.push (x := s6041) b6041 <|
    PetersenLocalChildren.push (x := s6042) b6042 <|
    PetersenLocalChildren.push (x := s6043) b6043 <|
    PetersenLocalChildren.push (x := s6044) b6044 <|
    PetersenLocalChildren.push (x := s6045) b6045 <|
    PetersenLocalChildren.push (x := s6046) b6046 <|
    PetersenLocalChildren.push (x := s6047) b6047 <|
    PetersenLocalChildren.push (x := s6048) b6048 <|
    PetersenLocalChildren.push (x := s6049) b6049 <|
    PetersenLocalChildren.push (x := s6050) b6050 <|
    PetersenLocalChildren.push (x := s6051) b6051 <|
    PetersenLocalChildren.push (x := s6052) b6052 <|
    PetersenLocalChildren.push (x := s6053) b6053 <|
    PetersenLocalChildren.push (x := s6054) b6054 <|
    PetersenLocalChildren.push (x := s6055) b6055 <|
    PetersenLocalChildren.push (x := s6056) b6056 <|
    PetersenLocalChildren.push (x := s6057) b6057 <|
    PetersenLocalChildren.push (x := s6058) b6058 <|
    PetersenLocalChildren.push (x := s6059) b6059 <|
    PetersenLocalChildren.push (x := s6060) b6060 <|
    PetersenLocalChildren.push (x := s6065) b6065 <|
    PetersenLocalChildren.push (x := s6066) b6066 <|
    PetersenLocalChildren.push (x := s6067) b6067 <|
    PetersenLocalChildren.nil
theorem b6167 : Blocked tgt 8 s6167 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,1,10,3,12,13,14,15,72,1,74,3,76,77,78,79,40,33,42,35,44,45,46,47,104,33,106,35,108,109,110,111,24,17,26,19,28,29,30,31,88,17,90,19,92,93,94,95,56,49,58,51,60,61,62,63,120,49,122,51,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,1,10,3,12,13,14,15,72,1,74,3,76,77,78,79,40,33,42,35,44,45,46,47,104,33,106,35,108,109,110,111,24,17,26,19,28,29,30,31,88,17,90,19,92,93,94,95,56,49,58,51,60,61,62,63,120,49,122,51,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf500f500f500f500f500f500f500f500,0xf5f5f5f5f5f5f5f50000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4952) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4952
theorem b6404 : Blocked tgt 8 s6404 := by
  apply PetersenFastNode.node (nxt := #[s6405,s6406,s6407,s6408,s2958,s2665,s5050,s3231,s6409,s6410,s6411,s6412,s6413,s6414,s6415,s6416,s6417,s6418,s6419,s6420,s6421,s6422,s6423,s6424]) (hints := [797,0,797,6346,6602,8665,797,6602,797,8665,1,8665,6602,6602,6860,6344,2,3,5954,6602,5954,8921,4,5,6602,6602,7498,4546,6,7,7490,4538,7490,4554,6602,10457,7490,6602,7490,4538,4538,10457,13666,10730,13666,2506,6602,12505,13666,6602,13666,10730,10730,12505,13634,6602,13634,2538,10730,8,13634,10730,13634,6602,6602,9,8665,8665,6860,6988,10,11,8665,8665,5696,5826,797,5954,797,797,5696,8665,8665,5954,8665,8665,1693,7498,12,7498,1693,13,1693,8665,8665,7498,8665,8665,10457,7490,14,7490,10457,15,10457,8665,8665,7490,8665,8665,12505,13666,16,13666,12505,17,12505,8665,8665,13666,409,409,8861,473,8665,13634,8601,8665,8861,409,409,13634,5696,18,5696,5954,6860,5954,5696,6860,5696,5954,19,5954,6860,6860,7756,7498,20,7498,7756,21,7756,7498,6860,7498,4796,4796,7232,10457,6860,10457,6844,6860,7232,10457,4796,10457,2732,2732,13408,12505,6860,12505,6828,6860,13408,12505,2732,12505,6860,6860,14924,13634,22,13634,14924,23,14924,13634,6860,13634,6986,6986,7498,4930,5954,1693,7498,5954,7498,6986,6986,1693,10457,5954,10457,4938,6986,2717,10457,6986,10457,5954,5954,2717,12505,10082,12505,1858,5954,4765,12505,5954,12505,10082,10082,4765,5954,5954,13634,1890,10082,8861,13634,10082,13634,5954,5954,8861,10457,1693,10457,7490,7498,7490,10457,7498,10457,7482,1693,7490,12505,11626,12505,3402,7498,13666,12505,7498,12505,11626,11626,13666,7498,7498,14666,3434,11626,13634,14666,11626,14666,7498,7498,13634,10457,10457,12505,3394,7490,14698,12505,7490,12505,10457,10457,14698,2201,2201,13634,2265,10457,14666,10393,10457,13634,2201,2201,14666,4249,4249,8861,4313,12505,13634,12441,12505,8861,4249,4249,13634]) (by decide +kernel)
  change ∀ b ∈ [s6405,s6406,s6407,s6408,s2958,s2665,s5050,s3231,s6409,s6410,s6411,s6412,s6413,s6414,s6415,s6416,s6417,s6418,s6419,s6420,s6421,s6422,s6423,s6424], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6405) b6405 <|
    PetersenLocalChildren.push (x := s6406) b6406 <|
    PetersenLocalChildren.push (x := s6407) b6407 <|
    PetersenLocalChildren.push (x := s6408) b6408 <|
    PetersenLocalChildren.push (x := s2958) b2958 <|
    PetersenLocalChildren.push (x := s2665) b2665 <|
    PetersenLocalChildren.push (x := s5050) b5050 <|
    PetersenLocalChildren.push (x := s3231) b3231 <|
    PetersenLocalChildren.push (x := s6409) b6409 <|
    PetersenLocalChildren.push (x := s6410) b6410 <|
    PetersenLocalChildren.push (x := s6411) b6411 <|
    PetersenLocalChildren.push (x := s6412) b6412 <|
    PetersenLocalChildren.push (x := s6413) b6413 <|
    PetersenLocalChildren.push (x := s6414) b6414 <|
    PetersenLocalChildren.push (x := s6415) b6415 <|
    PetersenLocalChildren.push (x := s6416) b6416 <|
    PetersenLocalChildren.push (x := s6417) b6417 <|
    PetersenLocalChildren.push (x := s6418) b6418 <|
    PetersenLocalChildren.push (x := s6419) b6419 <|
    PetersenLocalChildren.push (x := s6420) b6420 <|
    PetersenLocalChildren.push (x := s6421) b6421 <|
    PetersenLocalChildren.push (x := s6422) b6422 <|
    PetersenLocalChildren.push (x := s6423) b6423 <|
    PetersenLocalChildren.push (x := s6424) b6424 <|
    PetersenLocalChildren.nil
theorem b6447 : Blocked tgt 8 s6447 := by
  apply PetersenFastNode.node (nxt := #[s2968,s2764,s5137,s3424,s6130,s6448,s6449,s6450,s6323,s6451,s6452,s6453,s6454,s6455,s6456,s6457,s6459,s6423,s6460,s6461,s6462,s6463,s6464,s6465,s6466,s6467,s6468,s6469,s6470,s6471,s6472,s6473,s6474,s6475,s6476]) (hints := [6999,10483,6999,10485,10741,8676,6999,10741,6999,10483,10483,8676,5965,10741,5965,8804,0,1,7509,10741,7509,8685,2,3,7501,8677,7501,8693,10741,10468,7501,10741,7501,8677,8677,10468,13677,10741,13677,12388,4,12516,13677,5,13677,10741,10741,12516,2549,6,8744,2549,10741,7,10741,10741,8744,8,9,10,6613,10741,6871,6613,11,12,8676,8676,5707,5709,6999,5965,5707,6999,5707,8676,8676,5965,8676,8676,7767,7253,13,7509,7767,14,7767,8676,8676,7509,8676,8676,10468,4951,6999,7501,10468,6999,10468,8676,8676,7501,8676,8676,12516,2903,6999,13677,12516,6999,12516,8676,8676,13677,420,420,8744,484,8676,15,8612,8676,8744,420,420,16,6871,6999,6871,8676,8676,17,8676,8676,6871,6999,6999,18,6997,6997,7509,4941,5965,7767,7509,5965,7509,6997,6997,7767,10468,5965,10468,4949,6997,2728,10468,6997,10468,5965,5965,2728,12516,10093,12516,1869,5965,4776,12516,5965,12516,10093,10093,4776,5965,5965,19,2029,10093,8744,10093,10093,20,5965,5965,8744,5965,5965,21,10093,10093,6871,6093,10093,22,5965,5965,6871,10468,5703,10468,7501,7509,7501,10468,7509,10468,7493,5703,7501,12516,11637,12516,3413,7509,13677,12516,7509,12516,11637,11637,13677,7509,7509,8744,11637,11637,23,11637,11637,8744,7509,7509,24,7509,7509,6871,11637,11637,25,11637,11637,6871,7509,7509,26,10468,10468,12516,3405,7501,14709,12516,7501,12516,10468,10468,14709,2212,2212,8744,2276,10468,27,10404,10468,8744,2212,2212,28,7501,7501,4807,10468,10468,6871,10468,10468,4807,7501,7501,6871,4260,4260,8744,4324,12516,29,12452,12516,8744,4260,4260,30,2743,31,2743,12516,12516,6871,12516,12516,2743,6839,32,6871,13645,8744,6871,13645,33,34]) (by decide +kernel)
  change ∀ b ∈ [s2968,s2764,s5137,s3424,s6130,s6448,s6449,s6450,s6323,s6451,s6452,s6453,s6454,s6455,s6456,s6457,s6459,s6423,s6460,s6461,s6462,s6463,s6464,s6465,s6466,s6467,s6468,s6469,s6470,s6471,s6472,s6473,s6474,s6475,s6476], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2968) b2968 <|
    PetersenLocalChildren.push (x := s2764) b2764 <|
    PetersenLocalChildren.push (x := s5137) b5137 <|
    PetersenLocalChildren.push (x := s3424) b3424 <|
    PetersenLocalChildren.push (x := s6130) b6130 <|
    PetersenLocalChildren.push (x := s6448) b6448 <|
    PetersenLocalChildren.push (x := s6449) b6449 <|
    PetersenLocalChildren.push (x := s6450) b6450 <|
    PetersenLocalChildren.push (x := s6323) b6323 <|
    PetersenLocalChildren.push (x := s6451) b6451 <|
    PetersenLocalChildren.push (x := s6452) b6452 <|
    PetersenLocalChildren.push (x := s6453) b6453 <|
    PetersenLocalChildren.push (x := s6454) b6454 <|
    PetersenLocalChildren.push (x := s6455) b6455 <|
    PetersenLocalChildren.push (x := s6456) b6456 <|
    PetersenLocalChildren.push (x := s6457) b6457 <|
    PetersenLocalChildren.push (x := s6459) b6459 <|
    PetersenLocalChildren.push (x := s6423) b6423 <|
    PetersenLocalChildren.push (x := s6460) b6460 <|
    PetersenLocalChildren.push (x := s6461) b6461 <|
    PetersenLocalChildren.push (x := s6462) b6462 <|
    PetersenLocalChildren.push (x := s6463) b6463 <|
    PetersenLocalChildren.push (x := s6464) b6464 <|
    PetersenLocalChildren.push (x := s6465) b6465 <|
    PetersenLocalChildren.push (x := s6466) b6466 <|
    PetersenLocalChildren.push (x := s6467) b6467 <|
    PetersenLocalChildren.push (x := s6468) b6468 <|
    PetersenLocalChildren.push (x := s6469) b6469 <|
    PetersenLocalChildren.push (x := s6470) b6470 <|
    PetersenLocalChildren.push (x := s6471) b6471 <|
    PetersenLocalChildren.push (x := s6472) b6472 <|
    PetersenLocalChildren.push (x := s6473) b6473 <|
    PetersenLocalChildren.push (x := s6474) b6474 <|
    PetersenLocalChildren.push (x := s6475) b6475 <|
    PetersenLocalChildren.push (x := s6476) b6476 <|
    PetersenLocalChildren.nil
theorem b6640 : Blocked tgt 8 s6640 := by
  apply PetersenFastNode.node (nxt := #[s6641,s6642,s2612,s6573,s6643,s6644,s6645,s6646,s6647,s6648,s6649,s6650,s6651,s6652,s6653,s6654,s6655,s6656,s6657,s6658,s6659,s6661,s2325,s6662,s6628,s6663,s6664,s6665,s6666,s6667,s6668,s6669,s6670,s6671]) (hints := [6870,6870,6998,4564,4564,0,6998,4564,6998,6870,6870,1,5964,4564,5964,6358,6870,2,5964,6870,5964,6092,4564,3,4564,4564,7508,1575,4,1703,5588,5,7508,4564,4564,1703,7500,4806,7500,4564,4564,6,5580,4564,7500,5580,4806,7,4806,4806,8,4564,4564,11499,4564,4564,9,4806,4806,11499,13676,8692,13676,468,4564,4775,13676,4564,13676,8692,8692,4775,13644,4564,13644,500,8692,8871,13644,8692,13644,4564,4564,8871,5706,10,5706,5964,6998,5964,5706,6998,5706,5964,11,5964,1703,6998,1703,7252,12,7508,1703,13,1703,6998,6998,7508,4950,14,15,4950,6998,7500,6998,6998,16,7500,17,7500,935,6998,11499,935,18,19,4775,2870,4775,2902,6998,13676,4775,6998,4775,2870,2870,13676,8871,6998,8871,13644,20,13644,8871,21,8871,6998,6998,13644,6996,6996,7508,1703,5964,1703,7508,5964,7508,1703,6996,1703,9963,5964,7500,9963,6996,22,7500,6996,7500,5964,5964,23,11499,5706,11499,5964,5964,24,11499,5964,11499,12011,5706,25,13547,10092,13547,4775,5964,4775,13547,5964,13547,4775,10092,4775,5964,5964,13644,8871,10092,8871,13644,10092,13644,8871,5964,8871,1703,1703,26,7500,7508,7500,7492,7508,27,1703,1703,7500,1703,1703,10467,10475,7508,11499,10467,7508,10467,1703,1703,11499,1703,1703,4775,12523,7508,13547,4775,7508,4775,1703,1703,13547,1703,1703,8871,3444,11636,13644,8871,11636,8871,1703,1703,13644,28,29,30,11499,7500,11499,2727,7500,31,2727,16,11499,4775,11628,4775,13547,7500,13547,4775,7500,4775,13547,11628,13547,8871,7500,8871,3436,11628,14676,8871,11628,8871,7500,7500,14676,4775,11499,4775,13676,32,13676,4775,33,4775,11499,11499,13676,8871,3243,8871,3307,11499,13644,8871,11499,8871,3243,3243,13644,4775,4775,8871,5355,13547,13644,8871,13547,8871,4775,4775,13644]) (by decide +kernel)
  change ∀ b ∈ [s6641,s6642,s2612,s6573,s6643,s6644,s6645,s6646,s6647,s6648,s6649,s6650,s6651,s6652,s6653,s6654,s6655,s6656,s6657,s6658,s6659,s6661,s2325,s6662,s6628,s6663,s6664,s6665,s6666,s6667,s6668,s6669,s6670,s6671], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6641) b6641 <|
    PetersenLocalChildren.push (x := s6642) b6642 <|
    PetersenLocalChildren.push (x := s2612) b2612 <|
    PetersenLocalChildren.push (x := s6573) b6573 <|
    PetersenLocalChildren.push (x := s6643) b6643 <|
    PetersenLocalChildren.push (x := s6644) b6644 <|
    PetersenLocalChildren.push (x := s6645) b6645 <|
    PetersenLocalChildren.push (x := s6646) b6646 <|
    PetersenLocalChildren.push (x := s6647) b6647 <|
    PetersenLocalChildren.push (x := s6648) b6648 <|
    PetersenLocalChildren.push (x := s6649) b6649 <|
    PetersenLocalChildren.push (x := s6650) b6650 <|
    PetersenLocalChildren.push (x := s6651) b6651 <|
    PetersenLocalChildren.push (x := s6652) b6652 <|
    PetersenLocalChildren.push (x := s6653) b6653 <|
    PetersenLocalChildren.push (x := s6654) b6654 <|
    PetersenLocalChildren.push (x := s6655) b6655 <|
    PetersenLocalChildren.push (x := s6656) b6656 <|
    PetersenLocalChildren.push (x := s6657) b6657 <|
    PetersenLocalChildren.push (x := s6658) b6658 <|
    PetersenLocalChildren.push (x := s6659) b6659 <|
    PetersenLocalChildren.push (x := s6661) b6661 <|
    PetersenLocalChildren.push (x := s2325) b2325 <|
    PetersenLocalChildren.push (x := s6662) b6662 <|
    PetersenLocalChildren.push (x := s6628) b6628 <|
    PetersenLocalChildren.push (x := s6663) b6663 <|
    PetersenLocalChildren.push (x := s6664) b6664 <|
    PetersenLocalChildren.push (x := s6665) b6665 <|
    PetersenLocalChildren.push (x := s6666) b6666 <|
    PetersenLocalChildren.push (x := s6667) b6667 <|
    PetersenLocalChildren.push (x := s6668) b6668 <|
    PetersenLocalChildren.push (x := s6669) b6669 <|
    PetersenLocalChildren.push (x := s6670) b6670 <|
    PetersenLocalChildren.push (x := s6671) b6671 <|
    PetersenLocalChildren.nil
theorem b6681 : Blocked tgt 8 s6681 := by
  apply PetersenFastNode.node (nxt := #[s6682,s6683,s6684,s6685,s572,s705,s661,s6686,s6687,s6632,s6689,s6690,s6691,s6692,s6693,s6694,s6695,s690,s691,s6696,s6697,s6698,s6699,s6700,s6701,s6702,s6703,s2614,s6575,s6704,s6705,s6706,s6707,s6708,s6709,s6710,s6712,s6713,s6714]) (hints := [5585,0,5585,6875,1,6875,5585,2,5585,6875,3,6875,940,4,940,9712,5,6,9968,7,5969,9968,8,10871,5969,9,5969,10871,10,10871,1708,11,1708,7771,12,7771,1708,13,1708,7771,14,7771,7505,15,7505,11504,16,11504,2732,17,7505,2732,18,11504,4780,19,4780,13552,20,13552,4780,21,4780,13552,22,13552,8876,23,8876,14939,24,14939,8876,25,8876,14939,26,14939,6875,6875,4939,812,5585,940,4939,5585,4939,6875,6875,940,6359,6359,10871,6363,6875,27,6871,6875,10871,6359,6359,28,6875,6875,7771,4561,5585,1708,7771,5585,7771,6875,6875,1708,11376,5585,7505,6875,6875,11504,6875,6875,7505,11504,5585,11504,2747,2747,14455,2779,6875,13552,6843,6875,14455,2747,2747,13552,6875,6875,14939,2295,10487,8876,14939,10487,14939,6875,6875,8876,10871,29,10871,428,940,5969,10871,940,10871,5967,30,5969,7771,940,7771,7513,31,7513,7771,32,7771,940,940,7513,11504,940,11504,7505,33,7505,11504,34,11504,940,940,7505,13552,940,13552,843,4939,13681,13552,4939,13552,940,940,13681,14939,940,14939,13393,35,13649,14939,36,14939,940,940,13649,7255,10871,7255,7259,5969,7771,7255,5969,7255,7767,10871,7771,11504,5969,11504,10871,10871,37,11504,10871,11504,12016,5969,38,13552,10871,13552,4780,5969,4780,13552,5969,13552,10871,10871,4780,14423,5969,14423,14427,10871,14939,14423,10871,14423,14935,5969,14939,10472,1708,10472,10480,7771,11504,10472,7771,10472,11496,1708,11504,12520,3643,12520,12528,7771,13552,12520,7771,12520,13544,3643,13552,7771,7771,14939,3191,11383,13649,14939,11383,14939,7771,7771,13649,11504,11504,13552,14455,7505,14455,13552,7505,13552,11504,11504,14455,3248,3248,8876,3312,11504,14939,11440,11504,8876,3248,3248,14939,5296,5296,10811,5360,13552,14939,13488,13552,10811,5296,5296,14939]) (by decide +kernel)
  change ∀ b ∈ [s6682,s6683,s6684,s6685,s572,s705,s661,s6686,s6687,s6632,s6689,s6690,s6691,s6692,s6693,s6694,s6695,s690,s691,s6696,s6697,s6698,s6699,s6700,s6701,s6702,s6703,s2614,s6575,s6704,s6705,s6706,s6707,s6708,s6709,s6710,s6712,s6713,s6714], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6682) b6682 <|
    PetersenLocalChildren.push (x := s6683) b6683 <|
    PetersenLocalChildren.push (x := s6684) b6684 <|
    PetersenLocalChildren.push (x := s6685) b6685 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s705) b705 <|
    PetersenLocalChildren.push (x := s661) b661 <|
    PetersenLocalChildren.push (x := s6686) b6686 <|
    PetersenLocalChildren.push (x := s6687) b6687 <|
    PetersenLocalChildren.push (x := s6632) b6632 <|
    PetersenLocalChildren.push (x := s6689) b6689 <|
    PetersenLocalChildren.push (x := s6690) b6690 <|
    PetersenLocalChildren.push (x := s6691) b6691 <|
    PetersenLocalChildren.push (x := s6692) b6692 <|
    PetersenLocalChildren.push (x := s6693) b6693 <|
    PetersenLocalChildren.push (x := s6694) b6694 <|
    PetersenLocalChildren.push (x := s6695) b6695 <|
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s691) b691 <|
    PetersenLocalChildren.push (x := s6696) b6696 <|
    PetersenLocalChildren.push (x := s6697) b6697 <|
    PetersenLocalChildren.push (x := s6698) b6698 <|
    PetersenLocalChildren.push (x := s6699) b6699 <|
    PetersenLocalChildren.push (x := s6700) b6700 <|
    PetersenLocalChildren.push (x := s6701) b6701 <|
    PetersenLocalChildren.push (x := s6702) b6702 <|
    PetersenLocalChildren.push (x := s6703) b6703 <|
    PetersenLocalChildren.push (x := s2614) b2614 <|
    PetersenLocalChildren.push (x := s6575) b6575 <|
    PetersenLocalChildren.push (x := s6704) b6704 <|
    PetersenLocalChildren.push (x := s6705) b6705 <|
    PetersenLocalChildren.push (x := s6706) b6706 <|
    PetersenLocalChildren.push (x := s6707) b6707 <|
    PetersenLocalChildren.push (x := s6708) b6708 <|
    PetersenLocalChildren.push (x := s6709) b6709 <|
    PetersenLocalChildren.push (x := s6710) b6710 <|
    PetersenLocalChildren.push (x := s6712) b6712 <|
    PetersenLocalChildren.push (x := s6713) b6713 <|
    PetersenLocalChildren.push (x := s6714) b6714 <|
    PetersenLocalChildren.nil
theorem b6724 : Blocked tgt 8 s6724 := by
  apply PetersenFastNode.node (nxt := #[s6659,s6725,s6710,s6726,s679,s6702,s6727]) (hints := [6843,9680,6585,6843,5937,6331,5937,6065,6585,1548,7481,6585,4537,4537,6585,4779,4779,6585,5553,5553,13649,2489,13649,10713,13617,2521,13617,6585,6843,6585,6585,6843,9680,5937,5679,9680,1676,8656,1676,8648,9680,0,11472,9680,1,9680,9680,2,4748,13393,4748,9680,1488,9680,13617,908,908,6969,1676,7481,1676,11472,6969,11472,11984,9936,9936,6969,5937,13520,4748,13520,4748,5937,1873,13617,5937,5679,5937,5937,5679,1676,10448,10440,1676,1676,7481,7481,1676,1676,12496,4748,1676,1676,3417,14649,1676,1676,7481,7481,1676,2700,2700,4748,14681,4748,11472,3216,11472,11472,3216,3216,11472,11472,3216,4748,13520,4748,13520,13617,14649,13617,14649,3,4,5,6,4748,13520,13520,4748,4748,13520,13520,4748,8844,8844]) (by decide +kernel)
  change ∀ b ∈ [s6659,s6725,s6710,s6726,s679,s6702,s6727], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6659) b6659 <|
    PetersenLocalChildren.push (x := s6725) b6725 <|
    PetersenLocalChildren.push (x := s6710) b6710 <|
    PetersenLocalChildren.push (x := s6726) b6726 <|
    PetersenLocalChildren.push (x := s679) b679 <|
    PetersenLocalChildren.push (x := s6702) b6702 <|
    PetersenLocalChildren.push (x := s6727) b6727 <|
    PetersenLocalChildren.nil
theorem b6819 : Blocked tgt 8 s6819 := by
  apply PetersenFastNode.node (nxt := #[s2618,s6578,s6820,s6821,s6822,s6823,s6602,s6824,s6825,s6826,s6827,s6828,s6670,s6829,s2345,s6830,s6777,s6831,s6764,s6832,s6834,s6835,s6836,s6837,s6838,s6839,s6840,s6841,s6842,s6843,s6844,s6845,s6846,s6847,s6848,s6849,s6850,s6851]) (hints := [6874,6874,7002,811,4568,939,7002,4568,7002,6874,6874,939,5968,4568,5968,4314,6874,0,5968,6874,5968,6096,4568,1,4568,4568,7512,1579,2,1707,5592,3,7512,4568,4568,1707,7504,4810,7504,4568,4568,4,5584,4568,7504,5584,4810,5,10744,10744,14712,2520,4568,6,12792,4568,14712,10744,10744,7,8696,8,9,4568,4568,11503,4568,4568,10,11503,11,11503,13648,4568,13648,2552,10744,8875,13648,10744,13648,4568,4568,8875,9711,9711,5710,939,939,5968,939,939,5710,9711,9711,5968,939,939,1707,8687,9711,7512,1707,9711,1707,939,939,7512,939,939,7246,9711,9711,7504,9711,9711,7246,939,939,7504,939,939,14454,2906,7002,14712,6970,7002,14454,939,939,14712,939,939,11503,7002,7002,12,11503,7002,11503,939,939,13,939,939,8875,1519,9711,13648,8875,9711,8875,939,939,13648,7000,7000,7512,1707,5968,1707,7512,5968,7512,1707,7000,1707,9967,5968,7504,9967,7000,14,7504,7000,7504,5968,5968,15,10096,10096,14712,5968,5968,16,5968,5968,14712,10096,10096,17,11503,10096,11503,5968,5968,18,11503,5968,11503,12015,10096,19,5968,5968,13648,8875,10096,8875,13648,10096,13648,8875,5968,8875,1707,1707,20,7504,7512,7504,7496,7512,21,1707,1707,7504,1707,1707,14712,3416,7512,22,14712,7512,14712,1707,1707,23,1707,1707,10471,10479,7512,11503,10471,7512,10471,1707,1707,11503,1707,1707,8875,3448,11640,13648,8875,11640,8875,1707,1707,13648,3408,24,25,3408,7504,14712,7504,7504,26,14712,27,14712,28,29,30,11503,7504,11503,2731,7504,31,2731,27,11503,8875,7504,8875,12632,32,14680,8875,33,8875,7504,7504,14680,4779,14712,11503,4779,34,35,8875,36,8875,13648,14712,13648,8875,14712,8875,13648,37,13648,8875,3247,8875,3311,11503,13648,8875,11503,8875,3247,3247,13648]) (by decide +kernel)
  change ∀ b ∈ [s2618,s6578,s6820,s6821,s6822,s6823,s6602,s6824,s6825,s6826,s6827,s6828,s6670,s6829,s2345,s6830,s6777,s6831,s6764,s6832,s6834,s6835,s6836,s6837,s6838,s6839,s6840,s6841,s6842,s6843,s6844,s6845,s6846,s6847,s6848,s6849,s6850,s6851], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2618) b2618 <|
    PetersenLocalChildren.push (x := s6578) b6578 <|
    PetersenLocalChildren.push (x := s6820) b6820 <|
    PetersenLocalChildren.push (x := s6821) b6821 <|
    PetersenLocalChildren.push (x := s6822) b6822 <|
    PetersenLocalChildren.push (x := s6823) b6823 <|
    PetersenLocalChildren.push (x := s6602) b6602 <|
    PetersenLocalChildren.push (x := s6824) b6824 <|
    PetersenLocalChildren.push (x := s6825) b6825 <|
    PetersenLocalChildren.push (x := s6826) b6826 <|
    PetersenLocalChildren.push (x := s6827) b6827 <|
    PetersenLocalChildren.push (x := s6828) b6828 <|
    PetersenLocalChildren.push (x := s6670) b6670 <|
    PetersenLocalChildren.push (x := s6829) b6829 <|
    PetersenLocalChildren.push (x := s2345) b2345 <|
    PetersenLocalChildren.push (x := s6830) b6830 <|
    PetersenLocalChildren.push (x := s6777) b6777 <|
    PetersenLocalChildren.push (x := s6831) b6831 <|
    PetersenLocalChildren.push (x := s6764) b6764 <|
    PetersenLocalChildren.push (x := s6832) b6832 <|
    PetersenLocalChildren.push (x := s6834) b6834 <|
    PetersenLocalChildren.push (x := s6835) b6835 <|
    PetersenLocalChildren.push (x := s6836) b6836 <|
    PetersenLocalChildren.push (x := s6837) b6837 <|
    PetersenLocalChildren.push (x := s6838) b6838 <|
    PetersenLocalChildren.push (x := s6839) b6839 <|
    PetersenLocalChildren.push (x := s6840) b6840 <|
    PetersenLocalChildren.push (x := s6841) b6841 <|
    PetersenLocalChildren.push (x := s6842) b6842 <|
    PetersenLocalChildren.push (x := s6843) b6843 <|
    PetersenLocalChildren.push (x := s6844) b6844 <|
    PetersenLocalChildren.push (x := s6845) b6845 <|
    PetersenLocalChildren.push (x := s6846) b6846 <|
    PetersenLocalChildren.push (x := s6847) b6847 <|
    PetersenLocalChildren.push (x := s6848) b6848 <|
    PetersenLocalChildren.push (x := s6849) b6849 <|
    PetersenLocalChildren.push (x := s6850) b6850 <|
    PetersenLocalChildren.push (x := s6851) b6851 <|
    PetersenLocalChildren.nil
theorem b6922 : Blocked tgt 8 s6922 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffffff0a0affff0a0a,0xffffffffff0aff0affffffffff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4581) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4581
end PetersenSmallStarts.M191.Staged
