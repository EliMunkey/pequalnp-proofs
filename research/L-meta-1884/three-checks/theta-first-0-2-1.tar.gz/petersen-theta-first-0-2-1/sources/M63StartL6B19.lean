import M63StartData
import M63StartPins0
import M63StartL5B19
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b647 : Blocked tgt 6 s647 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(1,false),(2,false))] s647 6 _ le
  decide +kernel
theorem b648 : Blocked tgt 6 s648 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s648 6 _ le
  decide +kernel
theorem b649 : Blocked tgt 6 s649 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s649 6 _ le
  decide +kernel
theorem b650 : Blocked tgt 6 s650 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s650 6 _ le
  decide +kernel
theorem b651 : Blocked tgt 6 s651 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s651 6 _ le
  decide +kernel
theorem b652 : Blocked tgt 6 s652 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s652 6 _ le
  decide +kernel
theorem b653 : Blocked tgt 6 s653 := by
  apply PetersenFastNode.node (nxt := #[s654]) (hints := [2795,3445,2859,2795,2665,3445,3445,2665,3445,2283,3763,3445,3445,390,3509,3445,2405,2421,3429,2405,1365,1397,3413,1365,714,842,3507,2475,3763,3507,198,198,2859,454,1610,1350,1610,1350,2634,2374,2634,2374,202,202,714,3763,0,454,714,454,714,1350,1610,1350,714,2374,2634,2374,454,838,1350,1610,1350,1610,2374,2634,2374,2634,454,1610,1350,454,454,2634,2374,454,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s654], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s654) b654 <|
    PetersenLocalChildren.nil
theorem b655 : Blocked tgt 6 s655 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s655 6 _ le
  decide +kernel
theorem b656 : Blocked tgt 6 s656 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s656 6 _ le
  decide +kernel
theorem b657 : Blocked tgt 6 s657 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(1,false),(2,false))] s657 6 _ le
  decide +kernel
theorem b658 : Blocked tgt 6 s658 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s658 6 _ le
  decide +kernel
theorem b659 : Blocked tgt 6 s659 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s659 6 _ le
  decide +kernel
theorem b660 : Blocked tgt 6 s660 := by
  apply PetersenFastNode.node (nxt := #[s661]) (hints := [3445,390,3509,3445,2795,778,2987,2795,3315,2283,3763,3315,3185,2795,2795,3185,2795,2291,3755,2795,715,747,2763,715,714,198,842,714,454,202,838,454,454,194,454,2485,1350,454,454,1461,2374,454,3507,838,842,838,842,0,842,1350,1610,842,842,2374,2634,842,838,3633,838,1610,1350,838,838,2634,2374,838,1090,1350,1090,1350,2114,2374,2114,2374,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s661], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s661) b661 <|
    PetersenLocalChildren.nil
theorem b662 : Blocked tgt 6 s662 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s662 6 _ le
  decide +kernel
theorem b663 : Blocked tgt 6 s663 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s663 6 _ le
  decide +kernel
theorem b664 : Blocked tgt 6 s664 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s664 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
