import Petersen191Symmetry
import M191StartPreferredSignals
import M191ResidualC8A0G1
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G65
import M191StagedF0X2Z1G66
import M191StagedF0X2Z1G67
import M191StagedF0X2Z1G68
import M191StagedF0X2Z1G69
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G85
import M191StagedF0X2Z1G86
import M191StagedF0X2Z1G88
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows14
import M191StartPreferredRows16
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows21
import M191StartPreferredRows23
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows32
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows4
import M191StartPreferredRows40
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows69
import M191StartPreferredRows7
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair14492i0 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14493,s101,s297]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14493,s101,s297], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14493) (b14493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s101) (b101) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s297) (b297) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i1 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14494,s862,s1666,s14495]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s14494,s862,s1666,s14495], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14494) (b14494) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s862) (b862) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1666) (b1666) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14495) (b14495) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i2 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14493,s2093,s2130,s3195]) (hints := [6966,0,6966,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14493,s2093,s2130,s3195], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14493) (b14493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2093) (b2093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2130) (b2130) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3195) (b3195) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i3 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14496,s3793,s4442,s5218,s5796,s6015,s14497,s6516]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14496,s3793,s4442,s5218,s5796,s6015,s14497,s6516], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14496) (b14496) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3793) (b3793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4442) (b4442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5218) (b5218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5796) (b5796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6015) (b6015) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14497) (b14497) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6516) (b6516) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i4 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14498,s6735,s6766,s7123,s7531,s14499,s14500,s14501]) (hints := [2701,0,2701,1,2,3,2701,4,2701,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14498,s6735,s6766,s7123,s7531,s14499,s14500,s14501], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14498) (b14498) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6735) (b6735) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6766) (b6766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7123) (b7123) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7531) (b7531) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14499) (b14499) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14500) (b14500) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14501) (b14501) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i5 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14498,s7531,s14502,s14503,s2320,s14504,s3211,s6816,s7131,s14505,s14506,s14507]) (hints := [2,0,3,4,5,6,7,1,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s14498,s7531,s14502,s14503,s2320,s14504,s3211,s6816,s7131,s14505,s14506,s14507], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14498) (b14498) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7531) (b7531) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14502) (b14502) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14503) (b14503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2320) (b2320) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14504) (b14504) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3211) (b3211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6816) (b6816) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7131) (b7131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14505) (b14505) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14506) (b14506) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14507) (b14507) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i6 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14508,s7751,s8427,s14509]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14508,s7751,s8427,s14509], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14508) (b14508) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7751) (b7751) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8427) (b8427) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14509) (b14509) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i7 : PetersenLocalChildren.PairOK tgt 8 s14492 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14510,s9002,s9623,s10063,s10506,s10727,s14511,s10947]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14510,s9002,s9623,s10063,s10506,s10727,s14511,s10947], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14510) (b14510) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9002) (b9002) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9623) (b9623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10063) (b10063) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10506) (b10506) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10727) (b10727) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14511) (b14511) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10947) (b10947) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i8 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11184,s11485]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11184,s11485], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11184) (b11184) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11485) (b11485) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i9 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s297,s3195,s11766,s12283]) (hints := [6966,0,6966,6840,6840,1,7094,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s297,s3195,s11766,s12283], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s297) (b297) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3195) (b3195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11766) (b11766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12283) (b12283) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i10 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12479,s12912]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12479,s12912], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12479) (b12479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12912) (b12912) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i11 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14512,s14513]) (hints := [4774,4774,0,4790,6838,2695,6822,6838,1,4774,4774,2695]) (by decide +kernel) ?_
  change ∀ x ∈ [s14512,s14513], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14512) (b14512) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14513) (b14513) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i12 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3211,s7131,s14514,s14515,s14516,s14517,s14536,s14537]) (hints := [2,3,4,6844,6844,0,6844,6844,1,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s3211,s7131,s14514,s14515,s14516,s14517,s14536,s14537], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3211) (b3211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7131) (b7131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14514) (b14514) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14515) (b14515) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14516) (b14516) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14517) (b14517) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14536) (b14536) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14537) (b14537) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i13 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i14 : PetersenLocalChildren.PairOK tgt 8 s14492 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13197,s13614]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13197,s13614], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13197) (b13197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13614) (b13614) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i15 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,10832,901,901,6962,901,901,10832,9673,9673,6962]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i16 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i17 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14059,s14538]) (hints := [9675,9675,2695,4918,6966,0,2695,6966,2695,9675,9675,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14059,s14538], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14059) (b14059) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14538) (b14538) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i18 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14539,s13733,s14540,s14541]) (hints := [9677,9677,0,905,905,1,905,905,2,9677,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14539,s13733,s14540,s14541], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14539) (b14539) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13733) (b13733) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14540) (b14540) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14541) (b14541) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i19 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i20 : PetersenLocalChildren.PairOK tgt 8 s14492 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i21 : PetersenLocalChildren.PairOK tgt 8 s14492 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14348,s14486]) (hints := [6964,6964,7476,1671,0,1671,7476,1,7476,1671,6964,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s14348,s14486], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14348) (b14348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14486) (b14486) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i22 : PetersenLocalChildren.PairOK tgt 8 s14492 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14551,s14552,s14553,s14554]) (hints := [4918,0,1,6966,6966,2,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s14551,s14552,s14553,s14554], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14551) (b14551) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14552) (b14552) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14553) (b14553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14554) (b14554) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i23 : PetersenLocalChildren.PairOK tgt 8 s14492 (word0,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14554,s927,s14555]) (hints := [5933,6965,1,5933,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14554,s927,s14555], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14554) (b14554) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14555) (b14555) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i24 : PetersenLocalChildren.PairOK tgt 8 s14492 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,11090,13513,4741,6962,4741,13513,6962,13513,4741,11090,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i25 : PetersenLocalChildren.PairOK tgt 8 s14492 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13610,6962,13610,8837,11090,8837,13610,11090,13610,8837,6962,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i26 : PetersenLocalChildren.PairOK tgt 8 s14492 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14556,s14557]) (hints := [1671,1671,2695,7476,7476,0,2695,7476,2695,1671,1671,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14556,s14557], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14556) (b14556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14557) (b14557) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i27 : PetersenLocalChildren.PairOK tgt 8 s14492 (word6,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14558,s14559,s14560,s14359,s14561,s14562,s14599,s14600]) (hints := [0,1,2,1677,1677,3,1677,1677,4,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14558,s14559,s14560,s14359,s14561,s14562,s14599,s14600], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14558) (b14558) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14559) (b14559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14560) (b14560) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14359) (b14359) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14561) (b14561) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14562) (b14562) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14599) (b14599) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14600) (b14600) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i28 : PetersenLocalChildren.PairOK tgt 8 s14492 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,12489,7474,13513,12481,7474,12481,13505,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i29 : PetersenLocalChildren.PairOK tgt 8 s14492 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14492i30 : PetersenLocalChildren.PairOK tgt 8 s14492 (word5,word18) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14553,s927,s7126]) (hints := [11468,2696,1,11468,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14553,s927,s7126], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14553) (b14553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7126) (b7126) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i31 : PetersenLocalChildren.PairOK tgt 8 s14492 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14601,s14602]) (hints := [13515,2695,13515,14676,0,14676,13515,1,13515,2695,2695,14676]) (by decide +kernel) ?_
  change ∀ x ∈ [s14601,s14602], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14601) (b14601) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14602) (b14602) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i32 : PetersenLocalChildren.PairOK tgt 8 s14492 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14603,s14604]) (hints := [2695,2695,8839,14644,0,14644,8839,1,8839,2695,2695,14644]) (by decide +kernel) ?_
  change ∀ x ∈ [s14603,s14604], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14603) (b14603) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14604) (b14604) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i33 : PetersenLocalChildren.PairOK tgt 8 s14492 (word18,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14605,s14606,s14607,s14608]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s14605,s14606,s14607,s14608], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14605) (b14605) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14606) (b14606) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14607) (b14607) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14608) (b14608) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i34 : PetersenLocalChildren.PairOK tgt 8 s14492 (word18,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14609,s14610,s14611,s14621]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s14609,s14610,s14611,s14621], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14609) (b14609) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14610) (b14610) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14611) (b14611) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14621) (b14621) <|
    PetersenLocalChildren.nil
private theorem thetaPair14492i35 : PetersenLocalChildren.PairOK tgt 8 s14492 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b14492 : Blocked tgt 9 s14492 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word18),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word18),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word18),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word18),(word0,word2),(word0,word4),(word6,word5),(word6,word18),(word6,word2),(word6,word4),(word5,word18),(word5,word2),(word5,word4),(word18,word2),(word18,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s14492 p
  exact
    PetersenLocalChildren.push thetaPair14492i0 <|
    PetersenLocalChildren.push thetaPair14492i1 <|
    PetersenLocalChildren.push thetaPair14492i2 <|
    PetersenLocalChildren.push thetaPair14492i3 <|
    PetersenLocalChildren.push thetaPair14492i4 <|
    PetersenLocalChildren.push thetaPair14492i5 <|
    PetersenLocalChildren.push thetaPair14492i6 <|
    PetersenLocalChildren.push thetaPair14492i7 <|
    PetersenLocalChildren.push thetaPair14492i8 <|
    PetersenLocalChildren.push thetaPair14492i9 <|
    PetersenLocalChildren.push thetaPair14492i10 <|
    PetersenLocalChildren.push thetaPair14492i11 <|
    PetersenLocalChildren.push thetaPair14492i12 <|
    PetersenLocalChildren.push thetaPair14492i13 <|
    PetersenLocalChildren.push thetaPair14492i14 <|
    PetersenLocalChildren.push thetaPair14492i15 <|
    PetersenLocalChildren.push thetaPair14492i16 <|
    PetersenLocalChildren.push thetaPair14492i17 <|
    PetersenLocalChildren.push thetaPair14492i18 <|
    PetersenLocalChildren.push thetaPair14492i19 <|
    PetersenLocalChildren.push thetaPair14492i20 <|
    PetersenLocalChildren.push thetaPair14492i21 <|
    PetersenLocalChildren.push thetaPair14492i22 <|
    PetersenLocalChildren.push thetaPair14492i23 <|
    PetersenLocalChildren.push thetaPair14492i24 <|
    PetersenLocalChildren.push thetaPair14492i25 <|
    PetersenLocalChildren.push thetaPair14492i26 <|
    PetersenLocalChildren.push thetaPair14492i27 <|
    PetersenLocalChildren.push thetaPair14492i28 <|
    PetersenLocalChildren.push thetaPair14492i29 <|
    PetersenLocalChildren.push thetaPair14492i30 <|
    PetersenLocalChildren.push thetaPair14492i31 <|
    PetersenLocalChildren.push thetaPair14492i32 <|
    PetersenLocalChildren.push thetaPair14492i33 <|
    PetersenLocalChildren.push thetaPair14492i34 <|
    PetersenLocalChildren.push thetaPair14492i35 <|
    PetersenLocalChildren.nil
theorem b14826 : Blocked tgt 9 s14826 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s14622) (by decide +kernel)
  exact b14622
theorem b14987 : Blocked tgt 9 s14987 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s14387) (by decide +kernel)
  exact b14387
private theorem thetaPair15332i0 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15333,s125,s321]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15333,s125,s321], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15333) (b15333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s125) (b125) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s321) (b321) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i1 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15334,s905,s1696,s15335]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s15334,s905,s1696,s15335], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15334) (b15334) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s905) (b905) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1696) (b1696) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15335) (b15335) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i2 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15333,s2562,s2885]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15333,s2562,s2885], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15333) (b15333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2562) (b2562) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2885) (b2885) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i3 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15336,s4146,s4723,s5249,s5820,s6087,s15337,s6540]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15336,s4146,s4723,s5249,s5820,s6087,s15337,s6540], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15336) (b15336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4146) (b4146) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4723) (b4723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5249) (b5249) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5820) (b5820) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6087) (b6087) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15337) (b15337) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6540) (b6540) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i4 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15338,s6819,s6852,s7132,s7555,s15339,s15340,s15341]) (hints := [7474,0,7474,1,2,3,7474,4,7474,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15338,s6819,s6852,s7132,s7555,s15339,s15340,s15341], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15338) (b15338) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6819) (b6819) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6852) (b6852) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7132) (b7132) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7555) (b7555) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15339) (b15339) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15340) (b15340) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15341) (b15341) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i5 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15342,s7849,s7880,s8030,s8451,s15343,s15344,s15345]) (hints := [14682,0,14682,1,2,3,14682,4,14682,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15342,s7849,s7880,s8030,s8451,s15343,s15344,s15345], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15342) (b15342) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7849) (b7849) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7880) (b7880) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8030) (b8030) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8451) (b8451) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15343) (b15343) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15344) (b15344) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15345) (b15345) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i6 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15346,s15347,s15348,s6862,s15349,s7135,s7342,s15350,s15351,s15352,s15373,s15374]) (hints := [0,1,2,3,4,5,6,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s15346,s15347,s15348,s6862,s15349,s7135,s7342,s15350,s15351,s15352,s15373,s15374], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15346) (b15346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15347) (b15347) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15348) (b15348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6862) (b6862) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15349) (b15349) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7135) (b7135) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7342) (b7342) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15350) (b15350) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15351) (b15351) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15352) (b15352) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15373) (b15373) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15374) (b15374) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i7 : PetersenLocalChildren.PairOK tgt 8 s15332 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15375,s9286,s9770,s10093,s10530,s10801,s15376,s10975]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15375,s9286,s9770,s10093,s10530,s10801,s15376,s10975], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15375) (b15375) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9286) (b9286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9770) (b9770) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10093) (b10093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10530) (b10530) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10801) (b10801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15376) (b15376) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10975) (b10975) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i8 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11218,s11512]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11218,s11512], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11218) (b11218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11512) (b11512) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i9 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s321,s2885,s11790,s12052]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s321,s2885,s11790,s12052], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s321) (b321) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2885) (b2885) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11790) (b11790) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12052) (b12052) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i10 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12677,s12936]) (hints := [7476,6838,7476,1543,0,1671,7476,1,7476,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12677,s12936], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12677) (b12677) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12936) (b12936) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i11 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12987,s15377]) (hints := [7468,4774,7468,4790,6838,0,7468,6838,7468,4774,4774,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s12987,s15377], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12987) (b12987) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15377) (b15377) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i12 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13033,s15378]) (hints := [14676,2710,14676,2742,6838,0,14676,6838,14676,2710,2710,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s13033,s15378], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13033) (b13033) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15378) (b15378) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i13 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15379,s15380,s15381,s12990,s15382,s15383,s15403,s15404]) (hints := [0,1,2,6844,6844,3,6844,6844,4,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15379,s15380,s15381,s12990,s15382,s15383,s15403,s15404], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15379) (b15379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15380) (b15380) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15381) (b15381) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12990) (b12990) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15382) (b15382) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15383) (b15383) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15403) (b15403) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15404) (b15404) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i14 : PetersenLocalChildren.PairOK tgt 8 s15332 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13331,s13638]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13331,s13638], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13331) (b13331) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13638) (b13638) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i15 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i16 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,1669,8649,9673,7474,9665,9673,1669,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i17 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,7208,4916,6964,7466,6948,6964,7208,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i18 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,14416,2868,6964,14674,6932,6964,14416,9673,9673,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i19 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15405,s14070,s15406,s15407]) (hints := [9677,9677,0,6968,6968,1,6968,6968,2,9677,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15405,s14070,s15406,s15407], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15405) (b15405) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14070) (b14070) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15406) (b15406) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15407) (b15407) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i20 : PetersenLocalChildren.PairOK tgt 8 s15332 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i21 : PetersenLocalChildren.PairOK tgt 8 s15332 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,1669,5930,1669,7474,5930,7474,1669,6962,1669]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i22 : PetersenLocalChildren.PairOK tgt 8 s15332 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14601,s15417]) (hints := [5932,5932,7468,4916,6964,0,7468,6964,7468,5932,5932,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14601,s15417], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14601) (b14601) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15417) (b15417) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i23 : PetersenLocalChildren.PairOK tgt 8 s15332 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14775,s15418]) (hints := [10060,10060,14676,5932,5932,0,5932,5932,14676,10060,10060,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14775,s15418], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14775) (b14775) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15418) (b15418) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i24 : PetersenLocalChildren.PairOK tgt 8 s15332 (word0,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15419,s14606,s14671,s15420]) (hints := [10062,10062,0,5934,5934,1,5934,5934,2,10062,10062,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15419,s14606,s14671,s15420], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15419) (b15419) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14606) (b14606) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14671) (b14671) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15420) (b15420) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i25 : PetersenLocalChildren.PairOK tgt 8 s15332 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i26 : PetersenLocalChildren.PairOK tgt 8 s15332 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15434,s15435]) (hints := [1671,1671,0,7468,7476,7468,7460,7476,1,1671,1671,7468]) (by decide +kernel) ?_
  change ∀ x ∈ [s15434,s15435], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15434) (b15434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15435) (b15435) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i27 : PetersenLocalChildren.PairOK tgt 8 s15332 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15170,s15436]) (hints := [1671,1671,14676,3380,7476,0,14676,7476,14676,1671,1671,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s15170,s15436], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15170) (b15170) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15436) (b15436) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i28 : PetersenLocalChildren.PairOK tgt 8 s15332 (word6,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15437,s15173,s15438,s15439]) (hints := [1673,1673,0,7478,7478,1,7478,7478,2,1673,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15437,s15173,s15438,s15439], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15437) (b15437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15173) (b15173) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15438) (b15438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15439) (b15439) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i29 : PetersenLocalChildren.PairOK tgt 8 s15332 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15332i30 : PetersenLocalChildren.PairOK tgt 8 s15332 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15440,s15441,s15442,s15443]) (hints := [3374,0,1,7470,7470,2,14678,3,14678]) (by decide +kernel) ?_
  change ∀ x ∈ [s15440,s15441,s15442,s15443], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15440) (b15440) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15441) (b15441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15442) (b15442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15443) (b15443) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i31 : PetersenLocalChildren.PairOK tgt 8 s15332 (word5,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15443,s927,s15444]) (hints := [11468,7469,1,11468,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15443,s927,s15444], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15443) (b15443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15444) (b15444) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i32 : PetersenLocalChildren.PairOK tgt 8 s15332 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15445,s15446]) (hints := [8839,7468,8839,12596,0,14644,8839,1,8839,7468,7468,14644]) (by decide +kernel) ?_
  change ∀ x ∈ [s15445,s15446], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15445) (b15445) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15446) (b15446) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i33 : PetersenLocalChildren.PairOK tgt 8 s15332 (word2,word19) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15442,s927,s15447]) (hints := [13516,14677,1,13516,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15442,s927,s15447], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15442) (b15442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15447) (b15447) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i34 : PetersenLocalChildren.PairOK tgt 8 s15332 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15448,s15449]) (hints := [8839,0,8839,13612,14676,13612,8839,14676,8839,13612,1,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s15448,s15449], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15448) (b15448) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15449) (b15449) <|
    PetersenLocalChildren.nil
private theorem thetaPair15332i35 : PetersenLocalChildren.PairOK tgt 8 s15332 (word19,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15450,s15451,s15452,s15453]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s15450,s15451,s15452,s15453], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15450) (b15450) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15451) (b15451) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15452) (b15452) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15453) (b15453) <|
    PetersenLocalChildren.nil
theorem b15332 : Blocked tgt 9 s15332 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word19),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word19),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word19),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word19),(word0,word4),(word6,word5),(word6,word2),(word6,word19),(word6,word4),(word5,word2),(word5,word19),(word5,word4),(word2,word19),(word2,word4),(word19,word4)], PetersenLocalChildren.PairOK tgt 8 s15332 p
  exact
    PetersenLocalChildren.push thetaPair15332i0 <|
    PetersenLocalChildren.push thetaPair15332i1 <|
    PetersenLocalChildren.push thetaPair15332i2 <|
    PetersenLocalChildren.push thetaPair15332i3 <|
    PetersenLocalChildren.push thetaPair15332i4 <|
    PetersenLocalChildren.push thetaPair15332i5 <|
    PetersenLocalChildren.push thetaPair15332i6 <|
    PetersenLocalChildren.push thetaPair15332i7 <|
    PetersenLocalChildren.push thetaPair15332i8 <|
    PetersenLocalChildren.push thetaPair15332i9 <|
    PetersenLocalChildren.push thetaPair15332i10 <|
    PetersenLocalChildren.push thetaPair15332i11 <|
    PetersenLocalChildren.push thetaPair15332i12 <|
    PetersenLocalChildren.push thetaPair15332i13 <|
    PetersenLocalChildren.push thetaPair15332i14 <|
    PetersenLocalChildren.push thetaPair15332i15 <|
    PetersenLocalChildren.push thetaPair15332i16 <|
    PetersenLocalChildren.push thetaPair15332i17 <|
    PetersenLocalChildren.push thetaPair15332i18 <|
    PetersenLocalChildren.push thetaPair15332i19 <|
    PetersenLocalChildren.push thetaPair15332i20 <|
    PetersenLocalChildren.push thetaPair15332i21 <|
    PetersenLocalChildren.push thetaPair15332i22 <|
    PetersenLocalChildren.push thetaPair15332i23 <|
    PetersenLocalChildren.push thetaPair15332i24 <|
    PetersenLocalChildren.push thetaPair15332i25 <|
    PetersenLocalChildren.push thetaPair15332i26 <|
    PetersenLocalChildren.push thetaPair15332i27 <|
    PetersenLocalChildren.push thetaPair15332i28 <|
    PetersenLocalChildren.push thetaPair15332i29 <|
    PetersenLocalChildren.push thetaPair15332i30 <|
    PetersenLocalChildren.push thetaPair15332i31 <|
    PetersenLocalChildren.push thetaPair15332i32 <|
    PetersenLocalChildren.push thetaPair15332i33 <|
    PetersenLocalChildren.push thetaPair15332i34 <|
    PetersenLocalChildren.push thetaPair15332i35 <|
    PetersenLocalChildren.nil
theorem b15457 : Blocked tgt 9 s15457 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s15090) (by decide +kernel)
  exact b15090
end PetersenSmallStarts.M191.Staged
