import higher.WireProjection
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values32
import M191Values39
import M191Values41
import M191Values5
import M191Values734
import M191Values739
import M191Values740
import M191Values755
import M191Values765
import M191Values787
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts4
import M191StartPreferredCuts6
import M191StartPreferredRows1
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows30
import M191StartPreferredRows35
import M191StartPreferredRows41
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows48
import M191StartPreferredRows51
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows67
import M191StartPreferredRows7
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2742 : Blocked tgt 5 s2742 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4264,4264,4520,8641,6962,4520,6578,6578,4520,4914,6568,4520,8648,424,12744,8648,4520,456,12712,4520,6324,8641,6324,6580,8641,4916,10433,8641,8641,2868,12481,8641,385,449,8577,385,4260,4276,6308,4260,2196,2228,6292,2196,6324,3152,14516,6324,10433,3112,12481,10433,2177,2241,10369,2177,4225,4289,12417,4225]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact

    PetersenLocalChildren.nil
theorem b2782 : Blocked tgt 5 s2782 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2256,5672,5672,1417,6962,4904,7218,6962,5672,4914,7208,5672,1480,1576,5576,1480,5672,1480,5544,5544,6964,393,7732,6964,1417,4916,3209,1417,1417,2868,5257,1417,1545,1417,1417,6580,2177,2185,2177,3201,4225,4233,4225,5249,6324,3152,6324,7348,3209,3112,5257,3209,4260,3209,3209,6308,2196,5257,5257,6292]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact

    PetersenLocalChildren.nil
theorem b2880 : Blocked tgt 5 s2880 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s2880 5 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf8f8f8f8f8f8f8f8f8c8f8c8f8c8f8c8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))) (by decide +kernel)
theorem b12726 : Blocked tgt 5 s12726 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12726 5 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xf0f0,0x0,0x0,0xff00,0xaaaa] (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa) rfl)))))) (by decide +kernel)
theorem b12727 : Blocked tgt 5 s12727 := by
  intro k le c
  apply rejects_sound r41 i4 3 tgt small41 hot41 [] s12727 5 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xf0f0,0x0,0xaaaa,0xff00,0x0] (PetersenWireProjection.cons pv41_4814 (PetersenWireProjection.cons pv41_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv41_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffffffff00000000aaaaaaaa00000000 : BitVec 128) = 0x0) rfl)))))) (by decide +kernel)
theorem b12770 : Blocked tgt 5 s12770 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12770 5 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))) (by decide +kernel)
theorem b15224 : Blocked tgt 5 s15224 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5288,5288,5544,9673,6578,4520,7218,6578,5544,4530,7208,5544,9672,1448,13384,9672,5544,1480,13352,5544,8641,8649,9665,8641,9673,7208,11465,9673,9673,13384,13513,9673,1417,1481,9609,1417,10433,10441,10433,11457,12481,12489,12481,13505,7218,3152,14386,7218,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 4 b
  exact

    PetersenLocalChildren.nil
theorem b360 : Blocked tgt 6 s360 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s360 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_5029 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b513 : Blocked tgt 6 s513 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s513 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffffccccffffcccccececccccececccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b1613 : Blocked tgt 6 s1613 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s1613 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0xcccc,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b2729 : Blocked tgt 6 s2729 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s2729 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b2878 : Blocked tgt 6 s2878 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2878 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b2902 : Blocked tgt 6 s2902 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s2902 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5157 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b2912 : Blocked tgt 6 s2912 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false)),(true,(2,false),(7,false))] s2912 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv740_4514 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffffffffaaaaaaaa) rfl))))))) (by decide +kernel)
theorem b2913 : Blocked tgt 6 s2913 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s2913 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0xaaaaaaaa,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5841 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b2919 : Blocked tgt 6 s2919 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2919 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl))))))) (by decide +kernel)
theorem b2959 : Blocked tgt 6 s2959 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s2959 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5157 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5682 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b2969 : Blocked tgt 6 s2969 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s2969 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xf0f0,0xcccc,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5425 (PetersenWireProjection.cons pv17_5682 (PetersenWireProjection.cons pv17_5850 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl))))))) (by decide +kernel)
theorem b2970 : Blocked tgt 6 s2970 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s2970 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0xf500f500,0xaaaaaaaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_5841 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b2978 : Blocked tgt 6 s2978 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6324,6836,8897,6836,4520,6836,773,6964,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,8897,4904,8641,389,8641,8897,8897,2181,10433,8897,8897,4229,12481,8897,13352,8837,8833,8833,7216,901,7216,901,7208,2693,7208,2693,13384,4741,13384,4741,13352,8837,13352,8837,901,4916,2693,901,901,2868,4741,901,901,449,8837,901,2693,3112,4741,2693,2693,2241,8837,2693,4741,4289,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b2979 : Blocked tgt 6 s2979 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2979 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_5682 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl))))))) (by decide +kernel)
theorem b3257 : Blocked tgt 6 s3257 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3257 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7447 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3258 : Blocked tgt 6 s3258 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3258 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffff00000000eeeeeeee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_8012 rfl))))))) (by decide +kernel)
theorem b3364 : Blocked tgt 6 s3364 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3364 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7081 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b3435 : Blocked tgt 6 s3435 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s3435 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 (PetersenWireProjection.cons pv8_8208 rfl))))))) (by decide +kernel)
theorem b3436 : Blocked tgt 6 s3436 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3436 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7439 (PetersenWireProjection.cons pv11_8208 rfl))))))) (by decide +kernel)
theorem b3437 : Blocked tgt 6 s3437 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3437 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8180 rfl))))))) (by decide +kernel)
theorem b3447 : Blocked tgt 6 s3447 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3447 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0xff0aff0a] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7439 (PetersenWireProjection.cons pv739_8305 rfl))))))) (by decide +kernel)
theorem b3448 : Blocked tgt 6 s3448 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3448 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffffffffffffffffaa0aaa0aaa0aaa0a : BitVec 128) = 0xffffffff00000000) rfl))))))) (by decide +kernel)
theorem b3481 : Blocked tgt 6 s3481 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3481 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5917 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3530 : Blocked tgt 6 s3530 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3530 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5075 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3539 : Blocked tgt 6 s3539 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3539 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5107 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)

theorem b3549 : Blocked tgt 6 s3549 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3549 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xff0aff0a,0xcccccccc,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffceffceccccccccffceffcecccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3575 : Blocked tgt 6 s3575 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3575 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x3333,0xaaaa,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x33323332333233323332333233323332 : BitVec 128) = 0x3333) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b3596 : Blocked tgt 6 s3596 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3596 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xccfdccfdccfdccfdcccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3599 : Blocked tgt 6 s3599 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3599 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf2f2f2f2f2f2f2f2,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_3315 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xccc8ccc8ccc8ccc8ccc8ccc8ccc8ccc8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b3600 : Blocked tgt 6 s3600 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3600 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3315 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xfffa0000fffa0000fffa0000fffa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))) (by decide +kernel)
theorem b3619 : Blocked tgt 6 s3619 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3619 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xa0a0a0a,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7148 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b3682 : Blocked tgt 6 s3682 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3682 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xddddddddddddddddcccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b3693 : Blocked tgt 6 s3693 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3693 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xffffffffffffffffc0c0c0c0c0c0c0c0 : BitVec 128) = 0xffffffff00000000) rfl))))))) (by decide +kernel)
theorem b3728 : Blocked tgt 6 s3728 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3728 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_541 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfffa0000fffa0000fffa0000fffa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b4063 : Blocked tgt 6 s4063 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4063 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xc0c0c0c0ccc8ccc8c0c0c0c0ccc8ccc8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b4064 : Blocked tgt 6 s4064 := by
  intro k le c
  apply rejects_sound r755 (0x4444 :: i4) 3 tgt small755 hot755 [] s4064 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444,0x0,0xcccc,0x0,0x0,0xff00,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r755 (0x30303030333233323030303033323332 : BitVec 128) = 0x4444) (PetersenWireProjection.cons pv755_4260 (PetersenWireProjection.cons pv755_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r755 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv755_6790 (PetersenWireProjection.cons pv755_7474 (PetersenWireProjection.cons pv755_8012 rfl))))))) (by decide +kernel)
theorem b4074 : Blocked tgt 6 s4074 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4074 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffffffffffffffff00000000ff0aff0a : BitVec 128) = 0xff00) rfl))))))) (by decide +kernel)
theorem b4075 : Blocked tgt 6 s4075 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4075 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0x55005500550055005500550055005500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffffffffffffffff00000000ff0aff0a : BitVec 128) = 0xff00) rfl))))))) (by decide +kernel)
theorem b4095 : Blocked tgt 6 s4095 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,4520,9921,5672,4520,7218,4520,6578,6578,4520,4788,6568,4520,8648,424,12744,8648,4520,456,12712,4520,8641,901,9921,8641,901,8641,1669,901,901,4916,2693,901,901,2868,4741,901,901,449,8837,901,8897,8897,9921,1669,9921,2693,10433,9921,9921,4741,12481,9921,1665,1729,9857,1665,1669,10433,2693,1669,1669,12481,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,2241,8837,2693,4741,4289,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b4096 : Blocked tgt 6 s4096 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4096 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x888888888888888888cc88cc88cc88cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b4159 : Blocked tgt 6 s4159 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,4264,9793,5928,4264,7216,4264,6320,6320,4264,4788,6312,4264,8650,424,12490,8650,4264,458,12456,4264,8641,901,9921,8641,901,8641,1669,901,901,4916,2693,901,901,2868,4741,901,901,449,8837,901,8897,8897,9921,1669,9921,2693,11969,9921,9921,4741,14017,9921,1665,1729,9857,1665,1669,7208,2693,1669,1669,3120,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,3146,8837,2693,4741,13352,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil

theorem b4160 : Blocked tgt 6 s4160 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4160 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xc0c0c0c0c0c0ccccc0c0c0c0c0c0cccc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b4256 : Blocked tgt 6 s4256 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4256 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0xff00ff00] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7439 (PetersenWireProjection.cons pv739_8295 rfl))))))) (by decide +kernel)
theorem b4257 : Blocked tgt 6 s4257 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4257 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8184 rfl))))))) (by decide +kernel)
theorem b4304 : Blocked tgt 6 s4304 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4304 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xa0a0a0a,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6534 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b4342 : Blocked tgt 6 s4342 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4342 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x3333,0xaaaa,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x33323332333233323332333233323332 : BitVec 128) = 0x3333) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b4366 : Blocked tgt 6 s4366 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4366 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xccfdccfdccfdccfdcccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b4369 : Blocked tgt 6 s4369 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4369 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf2f2f2f2f2f2f2f2,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_3315 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4582 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b4762 : Blocked tgt 6 s4762 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4762 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_1850 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8191 rfl))))))) (by decide +kernel)
theorem b4920 : Blocked tgt 6 s4920 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4920 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xffffffffffffffff0808080808080808 : BitVec 128) = 0xffffffff00000000) rfl))))))) (by decide +kernel)
theorem b5148 : Blocked tgt 6 s5148 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5148 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 (PetersenWireProjection.cons pv8_8208 rfl))))))) (by decide +kernel)
theorem b5149 : Blocked tgt 6 s5149 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9800,5930,1992,5930,8709,456,6964,6964,7732,7474,7732,7474,2693,7466,2693,7466,4741,13386,4741,13640,6836,13354,6836,13610,458,5930,5930,5672,6962,4906,7474,6962,5930,4914,7466,5930,1994,1834,6090,1994,5930,1866,6058,5930,2514,7474,458,7474,458,7466,2693,7466,458,4554,4741,458,4522,4522,458,13610,5668,7466,7458,7458,11602,3378,14674,11602,7474,3410,14642,7474,11594,3370,13642,11594,7466,3402,13610,7466,2708,13610,13578,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b5156 : Blocked tgt 6 s5156 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,5674,5672,5928,6964,456,8709,6964,6964,11346,11344,6964,4900,4916,6948,4900,2836,2868,6932,2836,6836,773,6836,6964,458,5930,5930,6962,11090,5930,4050,4050,5930,9042,7466,5930,1994,1834,6090,1994,5930,1866,6058,5930,2514,2514,7474,7474,458,7466,2693,7466,458,4554,4741,458,4522,4522,458,13610,2693,7466,11586,7466,11602,12618,14674,11602,3410,3410,11602,13610,11594,3370,13642,11594,7466,3402,13610,7466,2708,13610,13578,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b5180 : Blocked tgt 6 s5180 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s5180 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b5181 : Blocked tgt 6 s5181 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5181 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2744 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)

theorem b5182 : Blocked tgt 6 s5182 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s5182 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
theorem b5183 : Blocked tgt 6 s5183 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5183 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b5184 : Blocked tgt 6 s5184 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5184 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b5206 : Blocked tgt 6 s5206 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5206 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a0a0a2a2a2a2a2a2a2a2a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b5207 : Blocked tgt 6 s5207 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5207 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfdfdfdfdfdfdfdfdcccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b5208 : Blocked tgt 6 s5208 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5208 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)
theorem b5241 : Blocked tgt 6 s5241 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5241 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b5242 : Blocked tgt 6 s5242 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5242 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b5243 : Blocked tgt 6 s5243 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4520,6836,5672,4520,6836,773,6964,6836,6836,4520,6578,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,456,12712,6836,8641,901,8641,9921,6962,4904,7218,6962,10433,2693,10433,2693,12481,4741,12481,4741,5672,1608,13352,5672,901,8641,1669,901,901,4916,2693,901,901,2868,4741,901,901,449,8837,901,2693,10433,2693,10433,4741,12481,4741,12481,7218,3152,14386,7218,2693,3112,4741,2693,2693,2241,10369,2693,4741,4289,12417,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b5244 : Blocked tgt 6 s5244 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s5244 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b5334 : Blocked tgt 6 s5334 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s5334 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0xa0a0a0a] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xff0aff0aff0aff0aff00ff00ff00ff00 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a0a0a) rfl))))))) (by decide +kernel)
theorem b5335 : Blocked tgt 6 s5335 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5335 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffffffffffffffff0a000a000a000a00 : BitVec 128) = 0xffff0000) rfl))))))) (by decide +kernel)
theorem b5360 : Blocked tgt 6 s5360 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(6,false))] s5360 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xdddddddd00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xdddddddd00000000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xff08ff08ff08ff08ff08ff08ff08ff08 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 rfl))))))) (by decide +kernel)
theorem b5867 : Blocked tgt 6 s5867 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5867 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_5682 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7439 (PetersenWireProjection.cons pv11_8208 rfl))))))) (by decide +kernel)
theorem b5868 : Blocked tgt 6 s5868 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5868 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5682 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8180 rfl))))))) (by decide +kernel)
theorem b5872 : Blocked tgt 6 s5872 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5872 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7447 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b5873 : Blocked tgt 6 s5873 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5873 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffff00000000eeeeeeee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_5682 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_8012 rfl))))))) (by decide +kernel)
theorem b6061 : Blocked tgt 6 s6061 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(2,false),(3,false)),(false,(0,false),(5,true))] s6061 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfff0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_667 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl))))))) (by decide +kernel)
theorem b6062 : Blocked tgt 6 s6062 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(2,false),(3,false)),(false,(0,false),(5,true))] s6062 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfff0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_667 (PetersenWireProjection.cons pv2_2748 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl))))))) (by decide +kernel)
theorem b6063 : Blocked tgt 6 s6063 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(2,false),(3,false)),(false,(0,false),(5,true))] s6063 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfff0,0xaaaaaaaa,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_667 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl))))))) (by decide +kernel)
theorem b6064 : Blocked tgt 6 s6064 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(2,false),(3,false)),(false,(0,false),(5,true))] s6064 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfff0,0xcccccccc,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_667 (PetersenWireProjection.cons pv2_2652 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl))))))) (by decide +kernel)
theorem b6458 : Blocked tgt 6 s6458 := by
  intro k le c
  apply rejects_sound r765 (0x3300 :: i4) 3 tgt small765 hot765 [] s6458 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x3300,0x0,0xf0f0,0xaaaa,0xcccc] (PetersenWireProjection.cons pv765_4814 (PetersenWireProjection.cons pv765_5473 (PetersenWireProjection.cons pv765_5682 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xf5f5f5f5f5f5f5f5c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv765_6790 (PetersenWireProjection.cons pv765_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc) rfl))))))) (by decide +kernel)
theorem b6660 : Blocked tgt 6 s6660 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6660 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xffff0808ffff0808ffff0808ffff0808 : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 (PetersenWireProjection.cons pv1_8208 rfl))))))) (by decide +kernel)
theorem b6688 : Blocked tgt 6 s6688 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6688 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x5555,0x0,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_3408 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b6711 : Blocked tgt 6 s6711 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6711 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xccccfdfdccccfdfdcccccccccccccccc : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b6833 : Blocked tgt 6 s6833 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,5928,11849,5928,6056,4272,1541,5296,4272,7208,4272,5288,5288,13386,432,13386,8656,13352,464,13352,4272,9673,901,11977,9673,901,8649,1669,901,901,9673,2693,901,901,2868,4741,901,901,1481,8837,901,10945,10953,11969,10945,9929,9929,11977,2693,11977,4741,16073,11977,3721,3785,11913,3721,1669,7208,2693,1669,1669,3120,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,3146,8837,2693,4741,13352,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b7863 : Blocked tgt 6 s7863 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,1448,13897,5928,1448,2224,424,3248,2224,1448,432,3240,1448,13386,1448,9674,9674,1448,8709,9640,1448,9673,901,14025,9673,901,8649,1669,901,901,4916,2693,901,901,9673,4741,901,901,1481,8837,901,12993,13001,14017,12993,14025,2693,16073,14025,9929,9929,14025,4741,5769,5833,13961,5769,1669,7208,2693,1669,1669,3120,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,3146,8837,2693,4741,13352,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b9232 : Blocked tgt 6 s9232 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,5672,9865,5672,6056,7218,456,7218,2512,7208,464,7208,1480,1480,2740,5576,1480,13352,1480,5544,5544,1417,901,9865,1417,901,393,1669,901,901,4916,2693,901,901,2868,4741,901,901,1417,8837,901,8833,8841,9857,8833,3209,2693,3209,9865,5257,4741,5257,9865,1673,1673,9865,8837,1669,2185,2693,1669,1669,4233,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,3209,8837,2693,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b9299 : Blocked tgt 6 s9299 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,5928,9737,5928,6056,7216,458,7216,2256,7208,464,7208,1482,1482,2740,5322,1482,13352,1482,5288,5288,1417,901,9865,1417,901,393,1669,901,901,4916,2693,901,901,2868,4741,901,901,1417,8837,901,8833,8841,9857,8833,9865,2693,11913,9865,9865,4741,13961,9865,1673,1673,9865,8837,1669,7208,2693,1669,1669,3120,4741,1669,1669,3152,8837,1669,2693,3112,4741,2693,2693,3146,8837,2693,4741,13352,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b9958 : Blocked tgt 6 s9958 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,5034,5032,5032,1541,456,901,901,6836,7218,6836,7474,2693,7210,2693,7464,4741,13386,4741,13640,8837,13354,8837,13608,458,5034,5034,8833,6962,4906,7090,6962,5034,4914,7082,5034,9162,938,13258,9162,5034,970,13226,5034,2514,7474,458,7474,458,7466,2693,7466,458,4554,4741,458,4522,4522,458,13610,4772,7466,7458,7458,11602,3378,14674,11602,7474,3410,14642,7474,11594,3370,13642,11594,7466,3402,13610,7466,4741,13610,13578,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b9971 : Blocked tgt 6 s9971 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,5674,5672,5928,901,456,1541,901,6836,773,6836,6964,901,4916,2693,901,901,2868,4741,901,901,13354,13352,901,5034,5034,5930,6962,11090,5930,11218,11090,5930,9042,7466,5930,9162,1834,13258,9162,5930,1866,13226,5930,2514,2514,7474,7474,458,7466,2693,7466,458,4554,4741,458,4522,4522,458,13610,4772,7466,11586,7466,11602,12618,14674,11602,3410,3410,11602,13610,11594,3370,13642,11594,7466,3402,13610,7466,4741,13610,13578,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b10053 : Blocked tgt 6 s10053 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s10053 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)
theorem b10087 : Blocked tgt 6 s10087 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,6836,5672,5800,6836,773,6964,6836,6836,456,7218,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,1480,5544,6836,1417,901,1417,9865,6962,4904,7218,6962,3209,2693,3209,2693,5257,4741,5257,4741,5672,1608,13352,5672,901,393,1669,901,901,4916,2693,901,901,2868,4741,901,901,1417,8837,901,2693,2185,2693,3201,4741,4233,4741,5249,7218,3152,14386,7218,2693,3112,4741,2693,2693,3209,3209,2693,4741,5257,5257,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b10877 : Blocked tgt 6 s10877 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s10877 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x3300,0xcccc,0xaaaa,0xf0f0] (PetersenWireProjection.cons pv787_4814 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_5745 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl))))))) (by decide +kernel)
theorem b11439 : Blocked tgt 6 s11439 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,false),(1,true))] s11439 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x2222222222222222,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x22222222222222222222222222222222 : BitVec 128) = 0x2222222222222222) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0f0c0f0c0f0c0f0c0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))) (by decide +kernel)
theorem b12352 : Blocked tgt 6 s12352 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12352 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_5920 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
theorem b12353 : Blocked tgt 6 s12353 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12353 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
theorem b12354 : Blocked tgt 6 s12354 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12354 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xfdccfdccfdccfdccfdccfdccfdccfdcc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
