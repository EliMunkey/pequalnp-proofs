import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv764_4260 : PetersenPackedPin.project r764 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv764_4814 : PetersenPackedPin.project r764 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv764_5473 : PetersenPackedPin.project r764 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv764_6170 : PetersenPackedPin.project r764 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv764_6790 : PetersenPackedPin.project r764 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv764_7474 : PetersenPackedPin.project r764 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv764_8012 : PetersenPackedPin.project r764 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv764_1734 : PetersenPackedPin.project r764 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv764_4260 pv764_6790 rfl rfl
theorem pv764_3427 : PetersenPackedPin.project r764 (0x33333333000000003333333300000000 : BitVec 128) = 0x33330000 := PetersenWireProjection.derive 2 pv764_4814 pv764_7474 rfl rfl
theorem pv764_6504 : PetersenPackedPin.project r764 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv764_4260 pv764_6170 rfl rfl
theorem pv764_7095 : PetersenPackedPin.project r764 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv764_4260 pv764_6790 rfl rfl
theorem pv764_7855 : PetersenPackedPin.project r764 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv764_6170 pv764_7474 rfl rfl
theorem pv764_7944 : PetersenPackedPin.project r764 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv764_6790 pv764_7474 rfl rfl
theorem pv764_3463 : PetersenPackedPin.project r764 (0x33333333330033003333333333003300 : BitVec 128) = 0x33330000 := PetersenWireProjection.derive 2 pv764_4814 pv764_7855 rfl rfl
theorem pv764_3476 : PetersenPackedPin.project r764 (0x33333333333300003333333333330000 : BitVec 128) = 0x33330000 := PetersenWireProjection.derive 2 pv764_4814 pv764_7944 rfl rfl
end PetersenSmallStarts.M191.Residual
