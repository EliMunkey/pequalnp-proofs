import higher.WireProjection
import M191Values1
import M191Values13
import M191Values14
import M191Values2
import M191Values32
import M191Values737
import M191Values739
import M191Values740
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3387 : Blocked tgt 8 s3387 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3387 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3388 : Blocked tgt 8 s3388 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3388 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0x55550000555500005555000055550000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b3389 : Blocked tgt 8 s3389 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3389 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b3418 : Blocked tgt 8 s3418 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3418 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3419 : Blocked tgt 8 s3419 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3419 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3730 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3420 : Blocked tgt 8 s3420 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3420 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3468 : Blocked tgt 8 s3468 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3468 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3469 : Blocked tgt 8 s3469 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3469 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3759 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3470 : Blocked tgt 8 s3470 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3470 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4429 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3500 : Blocked tgt 8 s3500 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3500 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3532 : Blocked tgt 8 s3532 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3532 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xcc08cc08cc08cc08cc08cc08cc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3569 : Blocked tgt 8 s3569 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3569 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xc400c400c400c400c400c400c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3604 : Blocked tgt 8 s3604 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3604 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xcccc0000cccc0000cccc0000cccc0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3638 : Blocked tgt 8 s3638 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3638 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1779 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3639 : Blocked tgt 8 s3639 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3639 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_3359 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b3640 : Blocked tgt 8 s3640 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3640 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4675 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3672 : Blocked tgt 8 s3672 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3672 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3673 : Blocked tgt 8 s3673 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3673 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3427 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3674 : Blocked tgt 8 s3674 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3674 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4753 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3708 : Blocked tgt 8 s3708 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s3708 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b3709 : Blocked tgt 8 s3709 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3709 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3485 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3710 : Blocked tgt 8 s3710 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3710 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5241 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b3792 : Blocked tgt 8 s3792 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3792 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xf0f00000f0f00000f0f00000f0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)

theorem b3854 : Blocked tgt 8 s3854 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3854 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2906 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b3855 : Blocked tgt 8 s3855 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3855 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3917 : Blocked tgt 8 s3917 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3917 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3918 : Blocked tgt 8 s3918 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3918 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5425 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3967 : Blocked tgt 8 s3967 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3967 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3004 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b3968 : Blocked tgt 8 s3968 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s3968 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xff0a0000ff0a0000ff0a0000ff0a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4025 : Blocked tgt 8 s4025 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4025 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xf5000000f5000000f5000000f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4026 : Blocked tgt 8 s4026 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4026 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xff0aff0a00000000ff0aff0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4087 : Blocked tgt 8 s4087 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4087 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xf500f50000000000f500f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4088 : Blocked tgt 8 s4088 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4088 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xff0aff0aff0aff0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4144 : Blocked tgt 8 s4144 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4144 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xf500f500f500f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4145 : Blocked tgt 8 s4145 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4145 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff000000000000ffff000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4179 : Blocked tgt 8 s4179 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4179 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_1294 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4180 : Blocked tgt 8 s4180 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4180 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffff000000000000ffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4181 : Blocked tgt 8 s4181 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4181 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff0000ffff00000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4207 : Blocked tgt 8 s4207 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4207 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4208 : Blocked tgt 8 s4208 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4208 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffff0000ffff0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4209 : Blocked tgt 8 s4209 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4209 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7397 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)

theorem b4210 : Blocked tgt 8 s4210 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4210 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 (PetersenWireProjection.cons pv739_8377 rfl)))))))) (by decide +kernel)
theorem b4211 : Blocked tgt 8 s4211 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4211 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_630 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4212 : Blocked tgt 8 s4212 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4212 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_1343 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b4214 : Blocked tgt 8 s4214 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4214 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4222 : Blocked tgt 8 s4222 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4222 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4223 : Blocked tgt 8 s4223 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4223 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_3582 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4224 : Blocked tgt 8 s4224 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4224 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4225 : Blocked tgt 8 s4225 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4225 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4226 : Blocked tgt 8 s4226 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4226 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_3632 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4227 : Blocked tgt 8 s4227 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4227 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4228 : Blocked tgt 8 s4228 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4228 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4059 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4229 : Blocked tgt 8 s4229 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4229 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b4230 : Blocked tgt 8 s4230 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4230 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4231 : Blocked tgt 8 s4231 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4231 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4232 : Blocked tgt 8 s4232 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4232 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3677 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)

theorem b4233 : Blocked tgt 8 s4233 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4233 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4089 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4234 : Blocked tgt 8 s4234 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4234 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4089 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4235 : Blocked tgt 8 s4235 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4235 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4236 : Blocked tgt 8 s4236 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4236 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4237 : Blocked tgt 8 s4237 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4237 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3677 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4238 : Blocked tgt 8 s4238 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4238 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4109 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4239 : Blocked tgt 8 s4239 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4239 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7095 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b4240 : Blocked tgt 8 s4240 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4240 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4241 : Blocked tgt 8 s4241 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4241 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4242 : Blocked tgt 8 s4242 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4242 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4250 : Blocked tgt 8 s4250 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4250 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4251 : Blocked tgt 8 s4251 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4251 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3730 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b4252 : Blocked tgt 8 s4252 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4252 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b4269 : Blocked tgt 8 s4269 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4269 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b4270 : Blocked tgt 8 s4270 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4270 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3759 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b4271 : Blocked tgt 8 s4271 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4271 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4429 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4283 : Blocked tgt 8 s4283 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4283 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4284 : Blocked tgt 8 s4284 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4284 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_3209 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4285 : Blocked tgt 8 s4285 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4285 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xcc00cc00cc00cc00cc00cc00cc00cc00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b4286 : Blocked tgt 8 s4286 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4286 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4522 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4326 : Blocked tgt 8 s4326 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4326 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4327 : Blocked tgt 8 s4327 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4327 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2240 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b4328 : Blocked tgt 8 s4328 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4328 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2240 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4329 : Blocked tgt 8 s4329 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s4329 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_3304 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b4330 : Blocked tgt 8 s4330 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4330 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3304 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4331 : Blocked tgt 8 s4331 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4331 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4565 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4332 : Blocked tgt 8 s4332 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4332 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xcc08cc08cc08cc08cc08cc08cc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b4333 : Blocked tgt 8 s4333 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4333 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6568 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)

theorem b4334 : Blocked tgt 8 s4334 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4334 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2224 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4335 : Blocked tgt 8 s4335 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4335 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xc400c400c400c400c400c400c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4373 : Blocked tgt 8 s4373 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4373 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_3315 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b4374 : Blocked tgt 8 s4374 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4374 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4586 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4375 : Blocked tgt 8 s4375 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4375 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b4376 : Blocked tgt 8 s4376 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4376 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b4377 : Blocked tgt 8 s4377 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4377 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4378 : Blocked tgt 8 s4378 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4378 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4675 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4387 : Blocked tgt 8 s4387 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4387 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4388 : Blocked tgt 8 s4388 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4388 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3427 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b4389 : Blocked tgt 8 s4389 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4389 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4753 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4397 : Blocked tgt 8 s4397 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s4397 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b4398 : Blocked tgt 8 s4398 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4398 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_3485 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)

theorem b4399 : Blocked tgt 8 s4399 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4399 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b4432 : Blocked tgt 8 s4432 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4432 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6618 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b4433 : Blocked tgt 8 s4433 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4433 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2298 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
