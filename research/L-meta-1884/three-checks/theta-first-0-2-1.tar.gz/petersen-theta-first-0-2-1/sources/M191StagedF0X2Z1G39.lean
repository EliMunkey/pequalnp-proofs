import higher.WireProjection
import M191Values1
import M191Values14
import M191Values19
import M191Values2
import M191Values32
import M191Values35
import M191Values38
import M191Values39
import M191Values41
import M191Values5
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredRows67
import M191StartPreferredRows68
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b15207 : Blocked tgt 7 s15207 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15207 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a0a0a0a000a000a000a000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15208 : Blocked tgt 7 s15208 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s15208 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8317 rfl)))))))) (by decide +kernel)
theorem b15209 : Blocked tgt 7 s15209 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15209 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b15210 : Blocked tgt 7 s15210 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15210 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xa0a0a0a0a0a0a0a0aaa0aaa0aaa0aaa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15211 : Blocked tgt 7 s15211 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15211 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15212 : Blocked tgt 7 s15212 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s15212 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b15213 : Blocked tgt 7 s15213 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s15213 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2192 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b15214 : Blocked tgt 7 s15214 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15214 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x55005500550055005500550055005500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15215 : Blocked tgt 7 s15215 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s15215 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl)))))))) (by decide +kernel)
theorem b15216 : Blocked tgt 7 s15216 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s15216 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x5555,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_351 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b15217 : Blocked tgt 7 s15217 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15217 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x55555555555555550000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl)))))))) (by decide +kernel)
theorem b15218 : Blocked tgt 7 s15218 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s15218 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xc4c4c4c4c4c4c4c4c400c400c400c400 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15236 : Blocked tgt 7 s15236 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15236 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0x0,0xcccc,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15240 : Blocked tgt 7 s15240 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s15240 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b15241 : Blocked tgt 7 s15241 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15241 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xaaaa,0xf0f0,0x0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15242 : Blocked tgt 7 s15242 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s15242 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15243 : Blocked tgt 7 s15243 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15243 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15244 : Blocked tgt 7 s15244 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15244 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl)))))))) (by decide +kernel)
theorem b15245 : Blocked tgt 7 s15245 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15245 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15246 : Blocked tgt 7 s15246 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15246 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfff5fff5fff5fff5ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15247 : Blocked tgt 7 s15247 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s15247 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2327 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf500f500) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)

theorem b15248 : Blocked tgt 7 s15248 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15248 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5f50000f5f50000f5000000f5000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15249 : Blocked tgt 7 s15249 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15249 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffff5f5fffff5f5fffff500fffff500 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15250 : Blocked tgt 7 s15250 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15250 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f5f50000f5000000f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15251 : Blocked tgt 7 s15251 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15251 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa0a00000a0a00000aff00000aff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15252 : Blocked tgt 7 s15252 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15252 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f5f5f500000000f500f50000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15253 : Blocked tgt 7 s15253 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15253 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xfffffffff5f5f5f5fffffffff500f500 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15254 : Blocked tgt 7 s15254 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15254 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5f5f5f500000000f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15255 : Blocked tgt 7 s15255 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15255 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa0a0a0a000000000aff0aff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15256 : Blocked tgt 7 s15256 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15256 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl)))))))) (by decide +kernel)
theorem b15257 : Blocked tgt 7 s15257 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15257 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffffffffffffffff500f500f500f500 : BitVec 128) = 0xffff0000) rfl)))))))) (by decide +kernel)
theorem b15258 : Blocked tgt 7 s15258 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s15258 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf5f50000,0x0,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_475 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf5f50000) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl)))))))) (by decide +kernel)
theorem b15259 : Blocked tgt 7 s15259 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15259 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xff000000ff000000ff000000ff000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15260 : Blocked tgt 7 s15260 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15260 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b15261 : Blocked tgt 7 s15261 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15261 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15262 : Blocked tgt 7 s15262 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15262 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xff00ff0000000000ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15263 : Blocked tgt 7 s15263 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s15263 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf500f500) (PetersenWireProjection.cons pv5_6120 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)

theorem b15264 : Blocked tgt 7 s15264 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s15264 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf5f50000,0x0,0x0,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf5f50000) (PetersenWireProjection.cons pv2_6120 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl)))))))) (by decide +kernel)
theorem b15265 : Blocked tgt 7 s15265 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s15265 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf5f50000,0x0,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_531 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf5f50000) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl)))))))) (by decide +kernel)
theorem b15266 : Blocked tgt 7 s15266 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s15266 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2461 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf500f500) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15267 : Blocked tgt 7 s15267 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15267 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xff00,0x0,0xffff,0xf0f0,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b15268 : Blocked tgt 7 s15268 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15268 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xff00,0x0,0xffff,0xf0f0] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 rfl)))))))) (by decide +kernel)
theorem b15269 : Blocked tgt 7 s15269 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15269 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 rfl)))))))) (by decide +kernel)
theorem b15270 : Blocked tgt 7 s15270 := by
  intro k le c
  apply rejects_sound r41 i4 3 tgt small41 hot41 [] s15270 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffffffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv41_4260 (PetersenWireProjection.cons pv41_4814 (PetersenWireProjection.cons pv41_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv41_6170 (PetersenWireProjection.cons pv41_6790 (PetersenWireProjection.cons pv41_7474 rfl)))))))) (by decide +kernel)
theorem b15273 : Blocked tgt 7 s15273 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15273 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15277 : Blocked tgt 7 s15277 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s15277 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15285 : Blocked tgt 7 s15285 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s15285 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x5f5f5f5f5f5f5f5f5f0a5f0a5f0a5f0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b15286 : Blocked tgt 7 s15286 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,true),(4,false))] s15286 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x55550000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0x55555555555555555500550055005500 : BitVec 128) = 0x55550000) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15287 : Blocked tgt 7 s15287 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,true),(3,false))] s15287 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x55005500,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0x55555555555555555500550055005500 : BitVec 128) = 0x55005500) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl)))))))) (by decide +kernel)
theorem b15291 : Blocked tgt 7 s15291 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s15291 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x888888888888888888cc88cc88cc88cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15295 : Blocked tgt 7 s15295 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,5288,5546,5546,901,9673,901,9673,5930,9929,5930,9929,7474,11344,1669,1669,2693,11465,2693,11465,4741,13513,4741,13513,13610,13352,8837,8837,5288,9673,5544,5288,5288,9801,5672,5288,10448,4264,11344,10448,5288,11337,7208,5288,13384,13385,13384,13512,5288,2256,13352,5288,9673,901,9929,9673,8641,8649,9665,8641,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,8897,8905,9921,8897,9929,8784,11465,9929,9929,1576,13513,9929,1673,1737,9865,1673,10433,10441,10433,11457,12481,12489,12481,13505,3152,3152,11344,13352,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil

theorem b15296 : Blocked tgt 7 s15296 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15296 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x808080808080808080a080a080a080a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15297 : Blocked tgt 7 s15297 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(1,true),(4,false))] s15297 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x33330000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0x33333333333333333300330033003300 : BitVec 128) = 0x33330000) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15298 : Blocked tgt 7 s15298 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(1,true),(3,false))] s15298 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x33003300,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0x33333333333333333300330033003300 : BitVec 128) = 0x33003300) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl)))))))) (by decide +kernel)
theorem b15299 : Blocked tgt 7 s15299 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,5546,901,9673,901,5288,5288,9801,1541,4264,1541,10448,2693,11337,2693,5288,4741,13385,4741,13512,8709,2256,8709,5288,6836,9673,6964,9673,5930,5672,5930,6058,7474,1541,7474,6836,7466,11465,7466,11465,13642,13513,13642,13513,13610,8709,13610,6836,9673,901,5672,9673,8641,8649,9665,8641,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,10832,4776,11344,10832,11465,8784,11465,5672,13513,1576,13513,9800,5672,1608,13352,5672,10433,10441,10433,11457,12481,12489,12481,13505,1541,3152,8709,1541,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b15300 : Blocked tgt 7 s15300 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15300 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x888888888888888888aa88aa88aa88aa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15305 : Blocked tgt 7 s15305 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(2,true),(4,false))] s15305 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f0f0f0f0f0f0f0f000f000f000f00 : BitVec 128) = 0xf0f0000) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15306 : Blocked tgt 7 s15306 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(2,true),(3,false))] s15306 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf000f00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf0f0f0f0f0f0f0f0f000f000f000f00 : BitVec 128) = 0xf000f00) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl)))))))) (by decide +kernel)
theorem b15307 : Blocked tgt 7 s15307 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s15307 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xffff,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xafafafafafafafafafaaafaaafaaafaa : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b15308 : Blocked tgt 7 s15308 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15308 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a0a0a0a0aaa0aaa0aaa0aa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15353 : Blocked tgt 7 s15353 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15353 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a00000a0a0a0a0a0a00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15354 : Blocked tgt 7 s15354 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15354 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0aaaaa0a0a0a0a0a0aaaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b15355 : Blocked tgt 7 s15355 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s15355 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xc4c4c4c4c4c40000c4c4c4c4c4c40000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15356 : Blocked tgt 7 s15356 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15356 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xffff,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfdfdfdfdfdfdccccfdfdfdfdfdfdcccc : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15357 : Blocked tgt 7 s15357 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s15357 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x80808080808cccc080808080808cccc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15358 : Blocked tgt 7 s15358 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15358 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xffff,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f5f0f0f5f5f5f5f5f5f0f0 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15359 : Blocked tgt 7 s15359 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15359 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xffff,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f50000f5f5f5f5f5f50000 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15360 : Blocked tgt 7 s15360 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s15360 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r38 (0xf0f00000f0f00000f0f00000f0f0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv38_4260 (PetersenWireProjection.cons pv38_4814 (PetersenWireProjection.cons pv38_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r38 (0xf5f5f5f5f5f50000f5f5f5f5f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv38_6170 (PetersenWireProjection.cons pv38_7474 (PetersenWireProjection.cons pv38_8012 rfl)))))))) (by decide +kernel)
theorem b15361 : Blocked tgt 7 s15361 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15361 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xffff,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5f5f5f5f5f50000f5f5f5f5f5f50000 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15362 : Blocked tgt 7 s15362 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s15362 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv38_2963 (PetersenWireProjection.cons pv38_4260 (PetersenWireProjection.cons pv38_4814 (PetersenWireProjection.cons pv38_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r38 (0xf5f5f5f5f5f50000f5f5f5f5f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv38_6170 (PetersenWireProjection.cons pv38_6790 (PetersenWireProjection.cons pv38_8012 rfl)))))))) (by decide +kernel)
theorem b15363 : Blocked tgt 7 s15363 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15363 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500f500f5000000f500f500f5000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15364 : Blocked tgt 7 s15364 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15364 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfff5fff5fff5ff00fff5fff5fff5ff00 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15365 : Blocked tgt 7 s15365 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15365 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf500f500f5000000f500f500f50000 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15366 : Blocked tgt 7 s15366 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15366 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa000a000a00ff000a000a000a00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15367 : Blocked tgt 7 s15367 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15367 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfffff5f5ffff0000fffff5f5ffff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15368 : Blocked tgt 7 s15368 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15368 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffffffff5f50000fffffffff5f50000 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b15369 : Blocked tgt 7 s15369 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15369 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f5f5f5f5f500000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15370 : Blocked tgt 7 s15370 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15370 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffffffffffffffff5f5f5f5f5f50000 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b15371 : Blocked tgt 7 s15371 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15371 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5f5f5f5f5f50000 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15372 : Blocked tgt 7 s15372 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15372 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa0a0a0a0a0affff0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b15384 : Blocked tgt 7 s15384 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15384 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x5f5f5f5f5f5f0a0a5f5f5f5f5f5f0a0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15385 : Blocked tgt 7 s15385 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15385 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x5f5f5f5f5f5f0a0a5f5f5f5f5f5f0a0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15386 : Blocked tgt 7 s15386 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(3,false),(4,false)),(false,(1,true),(0,false))] s15386 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x5555550055555500,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x55555555555500005555555555550000 : BitVec 128) = 0x5555550055555500) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)

theorem b15387 : Blocked tgt 7 s15387 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(3,false),(4,false)),(false,(1,true),(0,false))] s15387 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x5555550055555500,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x55555555555500005555555555550000 : BitVec 128) = 0x5555550055555500) (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b15388 : Blocked tgt 7 s15388 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15388 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15389 : Blocked tgt 7 s15389 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15389 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15390 : Blocked tgt 7 s15390 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15390 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_5682 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15391 : Blocked tgt 7 s15391 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15391 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15392 : Blocked tgt 7 s15392 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15392 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1496 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15393 : Blocked tgt 7 s15393 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15393 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_3753 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7588 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b15394 : Blocked tgt 7 s15394 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15394 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_893 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15395 : Blocked tgt 7 s15395 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15395 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8104 rfl)))))))) (by decide +kernel)
theorem b15396 : Blocked tgt 7 s15396 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15396 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0xff00,0x0,0xffff,0xf0f0] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_5745 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 rfl)))))))) (by decide +kernel)
theorem b15397 : Blocked tgt 7 s15397 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15397 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xffff,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xddddddddddddccccddddddddddddcccc : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15398 : Blocked tgt 7 s15398 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s15398 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xa0a0a0a0a0a0f0f0a0a0a0a0a0a0f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b15399 : Blocked tgt 7 s15399 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15399 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xff55ff55ff55ff00ff55ff55ff55ff00 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15400 : Blocked tgt 7 s15400 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15400 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2112 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b15401 : Blocked tgt 7 s15401 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s15401 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffffff5555555555550000 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b15402 : Blocked tgt 7 s15402 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s15402 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0x5555555555550000 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)

theorem b15408 : Blocked tgt 7 s15408 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15408 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x2020202020200000202020202020000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
