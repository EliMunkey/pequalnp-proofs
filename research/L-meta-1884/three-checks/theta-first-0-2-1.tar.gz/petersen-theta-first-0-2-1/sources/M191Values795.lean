import higher.WireProjection
import M191StartPreferredCuts7
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv795_4260 : PetersenPackedPin.project r795 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv795_4814 : PetersenPackedPin.project r795 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv795_5473 : PetersenPackedPin.project r795 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv795_6170 : PetersenPackedPin.project r795 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv795_6790 : PetersenPackedPin.project r795 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv795_7474 : PetersenPackedPin.project r795 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv795_8012 : PetersenPackedPin.project r795 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv795_456 : PetersenPackedPin.project r795 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv795_5473 pv795_8012 rfl rfl
theorem pv795_1734 : PetersenPackedPin.project r795 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xc0c0c0c0c0c0c0c := PetersenWireProjection.derive 1 pv795_4260 pv795_6790 rfl rfl
theorem pv795_2298 : PetersenPackedPin.project r795 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv795_5473 pv795_6170 rfl rfl
theorem pv795_3209 : PetersenPackedPin.project r795 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv795_4814 pv795_5473 rfl rfl
theorem pv795_7235 : PetersenPackedPin.project r795 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv795_5473 pv795_6790 rfl rfl
theorem pv795_5328 : PetersenPackedPin.project r795 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv795_1734 pv795_5473 rfl rfl
theorem pv795_5568 : PetersenPackedPin.project r795 (0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa : BitVec 128) = 0xc0c0c0c0c0c0c0c := PetersenWireProjection.derive 3 pv795_1734 pv795_5473 rfl rfl
end PetersenSmallStarts.M191.Residual
