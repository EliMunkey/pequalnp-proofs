import M63StartData
import M63StartPins0
import M63StartL5B11
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b370 : Blocked tgt 6 s370 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s370 6 _ le
  decide +kernel
theorem b371 : Blocked tgt 6 s371 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s371 6 _ le
  decide +kernel
theorem b372 : Blocked tgt 6 s372 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s372 6 _ le
  decide +kernel
theorem b373 : Blocked tgt 6 s373 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s373 6 _ le
  decide +kernel
theorem b374 : Blocked tgt 6 s374 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s374 6 _ le
  decide +kernel
theorem b375 : Blocked tgt 6 s375 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s375 6 _ le
  decide +kernel
theorem b376 : Blocked tgt 6 s376 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s376 6 _ le
  decide +kernel
theorem b378 : Blocked tgt 6 s378 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s378 6 _ le
  decide +kernel
theorem b379 : Blocked tgt 6 s379 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s379 6 _ le
  decide +kernel
theorem b380 : Blocked tgt 6 s380 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s380 6 _ le
  decide +kernel
theorem b381 : Blocked tgt 6 s381 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s381 6 _ le
  decide +kernel
theorem b382 : Blocked tgt 6 s382 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s382 6 _ le
  decide +kernel
theorem b383 : Blocked tgt 6 s383 := by
  apply PetersenFastNode.node (nxt := #[s384]) (hints := [3509,454,3509,454,2795,778,2987,2795,3315,2795,2795,3315,3315,2795,2795,3315,2795,2291,3755,2795,715,747,2763,715,714,198,842,714,454,714,714,454,454,714,714,454,454,2485,1350,454,454,1461,2374,454,2475,842,842,3893,0,842,842,3507,842,1094,1610,842,842,2118,2634,842,838,838,1350,1610,1350,1610,2374,2634,2374,2634,1350,1610,1350,1610,2374,2634,2374,2634,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s384], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s384) b384 <|
    PetersenLocalChildren.nil
theorem b385 : Blocked tgt 6 s385 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s385 6 _ le
  decide +kernel
theorem b386 : Blocked tgt 6 s386 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s386 6 _ le
  decide +kernel
theorem b387 : Blocked tgt 6 s387 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s387 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
