import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv32_4260 : PetersenPackedPin.project r32 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv32_4814 : PetersenPackedPin.project r32 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv32_5473 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv32_6170 : PetersenPackedPin.project r32 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xffff := by decide +kernel
theorem pv32_6790 : PetersenPackedPin.project r32 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv32_7474 : PetersenPackedPin.project r32 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv32_8012 : PetersenPackedPin.project r32 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv32_351 : PetersenPackedPin.project r32 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0xaa := PetersenWireProjection.derive 1 pv32_4260 pv32_8012 rfl rfl
theorem pv32_456 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5473 pv32_8012 rfl rfl
theorem pv32_1073 : PetersenPackedPin.project r32 (0xaaaaaaaa00000000aaaaaaaa : BitVec 128) = 0xa0a := PetersenWireProjection.derive 1 pv32_4260 pv32_7474 rfl rfl
theorem pv32_1177 : PetersenPackedPin.project r32 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5473 pv32_7474 rfl rfl
theorem pv32_1734 : PetersenPackedPin.project r32 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv32_4260 pv32_6790 rfl rfl
theorem pv32_1779 : PetersenPackedPin.project r32 (0xcccc0000cccc0000cccc0000cccc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv32_4814 pv32_6790 rfl rfl
theorem pv32_1829 : PetersenPackedPin.project r32 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5473 pv32_6790 rfl rfl
theorem pv32_1925 : PetersenPackedPin.project r32 (0xffff000000000000ffff00000000 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv32_6790 pv32_7474 rfl rfl
theorem pv32_2192 : PetersenPackedPin.project r32 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_4260 pv32_6170 rfl rfl
theorem pv32_2240 : PetersenPackedPin.project r32 (0xcc00cc00cc00cc00cc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_4814 pv32_6170 rfl rfl
theorem pv32_2298 : PetersenPackedPin.project r32 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5473 pv32_6170 rfl rfl
theorem pv32_2362 : PetersenPackedPin.project r32 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_6170 pv32_6790 rfl rfl
theorem pv32_2418 : PetersenPackedPin.project r32 (0xff00ff0000000000ff00ff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_6170 pv32_7474 rfl rfl
theorem pv32_2461 : PetersenPackedPin.project r32 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_6170 pv32_8012 rfl rfl
theorem pv32_2708 : PetersenPackedPin.project r32 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv32_4260 pv32_5473 rfl rfl
theorem pv32_2800 : PetersenPackedPin.project r32 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv32_4814 pv32_5473 rfl rfl
theorem pv32_2963 : PetersenPackedPin.project r32 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv32_5473 pv32_7474 rfl rfl
theorem pv32_3004 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv32_5473 pv32_8012 rfl rfl
theorem pv32_3157 : PetersenPackedPin.project r32 (0x22222222222222222222222222222222 : BitVec 128) = 0x2222 := PetersenWireProjection.derive 1 pv32_4260 pv32_4814 rfl rfl
theorem pv32_3209 : PetersenPackedPin.project r32 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_4814 pv32_5473 rfl rfl
theorem pv32_3632 : PetersenPackedPin.project r32 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_4260 pv32_5473 rfl rfl
theorem pv32_3980 : PetersenPackedPin.project r32 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_4260 pv32_5473 rfl rfl
theorem pv32_4159 : PetersenPackedPin.project r32 (0xaaaaaaaa00000000aaaaaaaa00000000 : BitVec 128) = 0xa0a0 := PetersenWireProjection.derive 0 pv32_4260 pv32_7474 rfl rfl
theorem pv32_4429 : PetersenPackedPin.project r32 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_4814 pv32_5473 rfl rfl
theorem pv32_5367 : PetersenPackedPin.project r32 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_5473 pv32_7474 rfl rfl
theorem pv32_5425 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_5473 pv32_8012 rfl rfl
theorem pv32_5850 : PetersenPackedPin.project r32 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_4260 pv32_5473 rfl rfl
theorem pv32_5920 : PetersenPackedPin.project r32 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv32_4814 pv32_5473 rfl rfl
theorem pv32_6504 : PetersenPackedPin.project r32 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_6170 rfl rfl
theorem pv32_6546 : PetersenPackedPin.project r32 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4814 pv32_6170 rfl rfl
theorem pv32_6618 : PetersenPackedPin.project r32 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_5473 pv32_6170 rfl rfl
theorem pv32_7095 : PetersenPackedPin.project r32 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_4260 pv32_6790 rfl rfl
theorem pv32_7152 : PetersenPackedPin.project r32 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv32_4814 pv32_6790 rfl rfl
theorem pv32_7235 : PetersenPackedPin.project r32 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_5473 pv32_6790 rfl rfl
theorem pv32_7314 : PetersenPackedPin.project r32 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_6170 pv32_6790 rfl rfl
theorem pv32_7774 : PetersenPackedPin.project r32 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv32_5473 pv32_7474 rfl rfl
theorem pv32_7855 : PetersenPackedPin.project r32 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_6170 pv32_7474 rfl rfl
theorem pv32_7944 : PetersenPackedPin.project r32 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv32_6790 pv32_7474 rfl rfl
theorem pv32_8245 : PetersenPackedPin.project r32 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv32_5473 pv32_8012 rfl rfl
theorem pv32_8295 : PetersenPackedPin.project r32 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_6170 pv32_8012 rfl rfl
theorem pv32_8331 : PetersenPackedPin.project r32 (0xffffffffffffffffffff0000ffff0000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv32_6790 pv32_8012 rfl rfl
theorem pv32_8377 : PetersenPackedPin.project r32 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0xfff0 := PetersenWireProjection.derive 3 pv32_7474 pv32_8012 rfl rfl
theorem pv32_112 : PetersenPackedPin.project r32 (0xa000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_351 pv32_6618 rfl rfl
theorem pv32_130 : PetersenPackedPin.project r32 (0xaa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_351 pv32_6170 rfl rfl
theorem pv32_141 : PetersenPackedPin.project r32 (0xf000f000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_456 pv32_6170 rfl rfl
theorem pv32_802 : PetersenPackedPin.project r32 (0xaa00aa0000000000aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1073 pv32_6170 rfl rfl
theorem pv32_836 : PetersenPackedPin.project r32 (0xf000f00000000000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1177 pv32_6170 rfl rfl
theorem pv32_1164 : PetersenPackedPin.project r32 (0xf050f05000000000f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1177 pv32_2192 rfl rfl
theorem pv32_1168 : PetersenPackedPin.project r32 (0xf0f0505000000000f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1177 pv32_1734 rfl rfl
theorem pv32_1401 : PetersenPackedPin.project r32 (0xa0000000a0000000a0000000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1734 pv32_6618 rfl rfl
theorem pv32_1565 : PetersenPackedPin.project r32 (0x3333000033000000333300003300 : BitVec 128) = 0x3333 := PetersenWireProjection.derive 2 pv32_7152 pv32_7855 rfl rfl
theorem pv32_1817 : PetersenPackedPin.project r32 (0xf0500000f0500000f0500000f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_1829 pv32_2192 rfl rfl
theorem pv32_1912 : PetersenPackedPin.project r32 (0xffaa0000ffaa0000ffaa0000ffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 1 pv32_6504 pv32_6790 rfl rfl
theorem pv32_1960 : PetersenPackedPin.project r32 (0xffff0000ff000000ffff0000ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_6790 pv32_7855 rfl rfl
theorem pv32_2003 : PetersenPackedPin.project r32 (0xffff0000ffff0000ff000000ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_6790 pv32_8295 rfl rfl
theorem pv32_2012 : PetersenPackedPin.project r32 (0x20002000200020002000200020002 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2192 pv32_5920 rfl rfl
theorem pv32_2024 : PetersenPackedPin.project r32 (0xa000a000a000a000a000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2192 pv32_5473 rfl rfl
theorem pv32_2059 : PetersenPackedPin.project r32 (0x220022002200220022002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2192 pv32_4814 rfl rfl
theorem pv32_2063 : PetersenPackedPin.project r32 (0x300030003000300030003000300030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2298 pv32_4814 rfl rfl
theorem pv32_2093 : PetersenPackedPin.project r32 (0x440044004400440044004400440044 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2240 pv32_4260 rfl rfl
theorem pv32_2099 : PetersenPackedPin.project r32 (0x500050005000500050005000500050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2298 pv32_4260 rfl rfl
theorem pv32_2198 : PetersenPackedPin.project r32 (0xaa00aa00aa00aaf0faf0faf0faf0fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_456 pv32_2192 rfl rfl
theorem pv32_2313 : PetersenPackedPin.project r32 (0xf0aafa00f0aafa00f0aafa00f0aafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_1734 pv32_2298 rfl rfl
theorem pv32_2339 : PetersenPackedPin.project r32 (0xfa00fa00fa00fa00fa00fa00fa00fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5850 pv32_6170 rfl rfl
theorem pv32_2392 : PetersenPackedPin.project r32 (0xff00aa00ff00aa00ff00aa00ff00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_6170 pv32_7095 rfl rfl
theorem pv32_2448 : PetersenPackedPin.project r32 (0xff00ff00f000f000ff00ff00f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_6170 pv32_7774 rfl rfl
theorem pv32_2884 : PetersenPackedPin.project r32 (0xf0a0f0a0f0a0f0a0f0a0f0a0f0a0f0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_5473 pv32_6504 rfl rfl
theorem pv32_2938 : PetersenPackedPin.project r32 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv32_5473 pv32_7095 rfl rfl
theorem pv32_2988 : PetersenPackedPin.project r32 (0xf0f0f0f0f000f000f0f0f0f0f000f00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_5473 pv32_7855 rfl rfl
theorem pv32_3248 : PetersenPackedPin.project r32 (0x30ba30ba30ba30ba30ba30ba30ba30ba : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_2192 pv32_3209 rfl rfl
theorem pv32_3744 : PetersenPackedPin.project r32 (0x55555555550055005555555555005500 : BitVec 128) = 0x5555 := PetersenWireProjection.derive 2 pv32_4260 pv32_7855 rfl rfl
theorem pv32_3822 : PetersenPackedPin.project r32 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv32_3980 pv32_5850 rfl rfl
theorem pv32_4406 : PetersenPackedPin.project r32 (0xbabababababababababababababababa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_3209 pv32_4260 rfl rfl
theorem pv32_4974 : PetersenPackedPin.project r32 (0xcceecceecceecceecceecceecceeccee : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv32_2192 pv32_4814 rfl rfl
theorem pv32_5281 : PetersenPackedPin.project r32 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_2192 pv32_5473 rfl rfl
theorem pv32_5288 : PetersenPackedPin.project r32 (0xf0c0f0c0f0c0f0c0f0c0f0c0f0c0f0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_5473 pv32_6546 rfl rfl
theorem pv32_5328 : PetersenPackedPin.project r32 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv32_1734 pv32_5473 rfl rfl
theorem pv32_5408 : PetersenPackedPin.project r32 (0xf0f0f0f0f000f000f0f0f0f0f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_5473 pv32_7855 rfl rfl
theorem pv32_5456 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0f000f000f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_5473 pv32_8295 rfl rfl
theorem pv32_5568 : PetersenPackedPin.project r32 (0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_1734 pv32_5473 rfl rfl
theorem pv32_5614 : PetersenPackedPin.project r32 (0xf0faf0faf0faf0faf0faf0faf0faf0fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_2192 pv32_5473 rfl rfl
theorem pv32_5761 : PetersenPackedPin.project r32 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x5555 := PetersenWireProjection.derive 2 pv32_2708 pv32_8295 rfl rfl
theorem pv32_5856 : PetersenPackedPin.project r32 (0xfafffafafafffafafafffafafafffafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_2362 pv32_5850 rfl rfl
theorem pv32_6255 : PetersenPackedPin.project r32 (0xff00ffaaff00ffaaff00ffaaff00ffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1734 pv32_6170 rfl rfl
theorem pv32_6308 : PetersenPackedPin.project r32 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_2708 pv32_6170 rfl rfl
theorem pv32_6347 : PetersenPackedPin.project r32 (0xff22ff22ff22ff22ff22ff22ff22ff22 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_3157 pv32_6170 rfl rfl
theorem pv32_6456 : PetersenPackedPin.project r32 (0xffa0ffa0ffa0ffa0ffa0ffa0ffa0ffa0 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_3980 pv32_6170 rfl rfl
theorem pv32_6457 : PetersenPackedPin.project r32 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv32_6504 pv32_6790 rfl rfl
theorem pv32_6484 : PetersenPackedPin.project r32 (0xffaaffaaff00ff00ffaaffaaff00ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4159 pv32_6170 rfl rfl
theorem pv32_6512 : PetersenPackedPin.project r32 (0xffafffafffaaffaaffafffafffaaffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_2963 pv32_6504 rfl rfl
theorem pv32_6568 : PetersenPackedPin.project r32 (0xffceffceffceffceffceffceffceffce : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_2708 pv32_6546 rfl rfl
theorem pv32_6597 : PetersenPackedPin.project r32 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_6546 rfl rfl
theorem pv32_6628 : PetersenPackedPin.project r32 (0xfff0fffafff0fffafff0fffafff0fffa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1734 pv32_6618 rfl rfl
theorem pv32_6659 : PetersenPackedPin.project r32 (0xfffafffafffafffafffafffafffafffa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_6618 rfl rfl
theorem pv32_6858 : PetersenPackedPin.project r32 (0xffff00aaffff00aaffff00aaffff00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_2192 pv32_6790 rfl rfl
theorem pv32_6897 : PetersenPackedPin.project r32 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv32_2708 pv32_6790 rfl rfl
theorem pv32_7372 : PetersenPackedPin.project r32 (0xffffffaaffffffaaffffffaaffffffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_7314 rfl rfl
theorem pv32_7380 : PetersenPackedPin.project r32 (0xffffffccffffffccffffffccffffffcc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4814 pv32_7314 rfl rfl
theorem pv32_7865 : PetersenPackedPin.project r32 (0xffffffffff00ffaaffffffffff00ffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1734 pv32_7855 rfl rfl
theorem pv32_7903 : PetersenPackedPin.project r32 (0xffffffffffaaffaaffffffffffaaffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_7855 rfl rfl
theorem pv32_7913 : PetersenPackedPin.project r32 (0xffffffffffccffccffffffffffccffcc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4814 pv32_7855 rfl rfl
theorem pv32_7931 : PetersenPackedPin.project r32 (0xfffffffffff0fff0fffffffffff0fff0 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_5473 pv32_7855 rfl rfl
theorem pv32_7997 : PetersenPackedPin.project r32 (0xffffffffffffff00ffffffffffffff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_6170 pv32_7944 rfl rfl
theorem pv32_8079 : PetersenPackedPin.project r32 (0xffffffffffffffff00aa00aa00aa00aa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv32_2192 pv32_8012 rfl rfl
theorem pv32_8255 : PetersenPackedPin.project r32 (0xfffffffffffffffff0faf0faf0faf0fa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv32_2192 pv32_8245 rfl rfl
theorem pv32_8303 : PetersenPackedPin.project r32 (0xffffffffffffffffff00ffaaff00ffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1734 pv32_8295 rfl rfl
theorem pv32_8305 : PetersenPackedPin.project r32 (0xffffffffffffffffff0aff0aff0aff0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_2708 pv32_8295 rfl rfl
theorem pv32_8317 : PetersenPackedPin.project r32 (0xffffffffffffffffffaaffaaffaaffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4260 pv32_8295 rfl rfl
theorem pv32_8319 : PetersenPackedPin.project r32 (0xffffffffffffffffffccffccffccffcc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_4814 pv32_8295 rfl rfl
theorem pv32_8416 : PetersenPackedPin.project r32 (0xffffffffffffffffffffffffff00ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_6170 pv32_8377 rfl rfl
theorem pv32_470 : PetersenPackedPin.project r32 (0xf0faf0faf0faf0fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2198 pv32_8012 rfl rfl
theorem pv32_1969 : PetersenPackedPin.project r32 (0xffff0000ffaa0000ffff0000ffaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_6790 pv32_7865 rfl rfl
theorem pv32_2308 : PetersenPackedPin.project r32 (0xf000fa00f000fa00f000fa00f000fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_2313 pv32_6170 rfl rfl
theorem pv32_2407 : PetersenPackedPin.project r32 (0xff00fa00ff00fa00ff00fa00ff00fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_5856 pv32_6170 rfl rfl
theorem pv32_2993 : PetersenPackedPin.project r32 (0xf0f0f0f0f0a0f0a0f0f0f0f0f0a0f0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv32_5473 pv32_6512 rfl rfl
theorem pv32_3242 : PetersenPackedPin.project r32 (0x30323032303230323032303230323032 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv32_3248 pv32_4814 rfl rfl
theorem pv32_4943 : PetersenPackedPin.project r32 (0xccccffffccccffccccccffffccccffcc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1565 pv32_4814 rfl rfl
theorem pv32_5476 : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0f0faf0faf0faf0fa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_112 pv32_5473 rfl rfl
theorem pv32_6226 : PetersenPackedPin.project r32 (0xff00ff0aff00ff0aff00ff0aff00ff0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_1401 pv32_6170 rfl rfl
theorem pv32_6277 : PetersenPackedPin.project r32 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_2012 pv32_6170 rfl rfl
theorem pv32_6429 : PetersenPackedPin.project r32 (0xff5aff5aff5aff5aff5aff5aff5aff5a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv32_3822 pv32_6170 rfl rfl
theorem pv32_7213 : PetersenPackedPin.project r32 (0xfffff050fffff050fffff050fffff050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv32_1817 pv32_6790 rfl rfl
theorem pv32_7752 : PetersenPackedPin.project r32 (0xfffffffff050f050fffffffff050f050 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv32_1164 pv32_7474 rfl rfl
theorem pv32_7756 : PetersenPackedPin.project r32 (0xfffffffff0f05050fffffffff0f05050 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv32_1168 pv32_7474 rfl rfl
theorem pv32_8074 : PetersenPackedPin.project r32 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv32_112 pv32_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
