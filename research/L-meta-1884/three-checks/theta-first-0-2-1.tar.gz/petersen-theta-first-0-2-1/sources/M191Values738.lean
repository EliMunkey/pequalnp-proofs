import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv738_4260 : PetersenPackedPin.project r738 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv738_4814 : PetersenPackedPin.project r738 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv738_5473 : PetersenPackedPin.project r738 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv738_6170 : PetersenPackedPin.project r738 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv738_6790 : PetersenPackedPin.project r738 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv738_7474 : PetersenPackedPin.project r738 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv738_8012 : PetersenPackedPin.project r738 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv738_1734 : PetersenPackedPin.project r738 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv738_4260 pv738_6790 rfl rfl
theorem pv738_8191 : PetersenPackedPin.project r738 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv738_4260 pv738_8012 rfl rfl
theorem pv738_1366 : PetersenPackedPin.project r738 (0xffffffff00000000aaaaaaaa : BitVec 128) = 0xf000f000f000f0 := PetersenWireProjection.derive 2 pv738_7474 pv738_8191 rfl rfl
theorem pv738_8059 : PetersenPackedPin.project r738 (0xffffffffffffffff0000aaaa0000aaaa : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv738_1734 pv738_8012 rfl rfl
theorem pv738_1349 : PetersenPackedPin.project r738 (0xffffffff000000000000aaaa : BitVec 128) = 0xf000f000f000f0 := PetersenWireProjection.derive 2 pv738_7474 pv738_8059 rfl rfl
end PetersenSmallStarts.M191.Residual
