import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows32
import ResidualFast
import ThetaClosing
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b7170 : Blocked tgt 7 s7170 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7170 7 _ le
  decide +kernel
theorem b7171 : Blocked tgt 7 s7171 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7171 7 _ le
  decide +kernel
theorem b7172 : Blocked tgt 7 s7172 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7172 7 _ le
  decide +kernel
theorem b7173 : Blocked tgt 7 s7173 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7173 7 _ le
  decide +kernel
theorem b7174 : Blocked tgt 7 s7174 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7174 7 _ le
  decide +kernel
theorem b7175 : Blocked tgt 7 s7175 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7175 7 _ le
  decide +kernel
theorem b7176 : Blocked tgt 7 s7176 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7176 7 _ le
  decide +kernel
theorem b7183 : Blocked tgt 7 s7183 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7183 7 _ le
  decide +kernel
theorem b7185 : Blocked tgt 7 s7185 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7185 7 _ le
  decide +kernel
theorem b7186 : Blocked tgt 7 s7186 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7186 7 _ le
  decide +kernel
theorem b7187 : Blocked tgt 7 s7187 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7187 7 _ le
  decide +kernel
theorem b7188 : Blocked tgt 7 s7188 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s7188 7 _ le
  decide +kernel
theorem b7189 : Blocked tgt 7 s7189 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s7189 7 _ le
  decide +kernel

theorem b7190 : Blocked tgt 7 s7190 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7190 7 _ le
  decide +kernel
theorem b7191 : Blocked tgt 7 s7191 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,32,36,32,38,33,37,35,39,64,68,64,70,65,69,67,71,96,100,96,102,97,101,99,103,8,12,8,14,9,13,11,15,40,44,40,46,41,45,43,47,72,76,72,78,73,77,75,79,104,108,104,110,105,109,107,111,16,20,16,22,17,21,17,23,48,52,48,54,49,53,49,55,80,84,80,86,81,85,81,87,112,116,112,118,113,117,113,119,24,28,24,30,25,29,25,31,56,60,56,62,57,61,57,63,88,92,88,94,89,93,89,95,120,124,120,126,121,125,121,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,32,36,32,38,33,37,35,39,64,68,64,68,65,69,67,71,96,100,96,100,97,101,99,103,8,12,8,14,9,13,11,15,40,44,40,46,41,45,43,47,72,76,72,76,73,77,75,79,104,108,104,108,105,109,107,111,16,20,16,22,17,21,19,23,48,52,48,54,49,53,51,55,80,84,80,84,81,85,83,87,112,116,112,116,113,117,115,119,24,28,24,30,25,29,27,31,56,60,56,62,57,61,59,63,88,92,88,92,89,93,91,95,120,124,120,124,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xc0c0c8c8c0c0c8c8c0c0c8c8c0c0c8c8,0x8888888888888888c8c8c8c8c8c8c8c8),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa,0xaaaaaaaaaaaaaaaafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000),(0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1214) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1214
theorem b7192 : Blocked tgt 7 s7192 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7192 7 _ le
  decide +kernel
theorem b7193 : Blocked tgt 7 s7193 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7193 7 _ le
  decide +kernel
theorem b7194 : Blocked tgt 7 s7194 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s7194 7 _ le
  decide +kernel
theorem b7195 : Blocked tgt 7 s7195 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s7195 7 _ le
  decide +kernel
theorem b7196 : Blocked tgt 7 s7196 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s7196 7 _ le
  decide +kernel
theorem b7197 : Blocked tgt 7 s7197 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7197 7 _ le
  decide +kernel
theorem b7198 : Blocked tgt 7 s7198 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7198 7 _ le
  decide +kernel
theorem b7199 : Blocked tgt 7 s7199 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7199 7 _ le
  decide +kernel
theorem b7200 : Blocked tgt 7 s7200 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7200 7 _ le
  decide +kernel
theorem b7201 : Blocked tgt 7 s7201 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7201 7 _ le
  decide +kernel
theorem b7202 : Blocked tgt 7 s7202 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7202 7 _ le
  decide +kernel
theorem b7203 : Blocked tgt 7 s7203 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7203 7 _ le
  decide +kernel
theorem b7204 : Blocked tgt 7 s7204 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7204 7 _ le
  decide +kernel
theorem b7205 : Blocked tgt 7 s7205 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7205 7 _ le
  decide +kernel

theorem b7206 : Blocked tgt 7 s7206 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7206 7 _ le
  decide +kernel
theorem b7207 : Blocked tgt 7 s7207 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7207 7 _ le
  decide +kernel
theorem b7208 : Blocked tgt 7 s7208 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7208 7 _ le
  decide +kernel
theorem b7209 : Blocked tgt 7 s7209 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7209 7 _ le
  decide +kernel
theorem b7210 : Blocked tgt 7 s7210 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7210 7 _ le
  decide +kernel
theorem b7211 : Blocked tgt 7 s7211 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7211 7 _ le
  decide +kernel
theorem b7212 : Blocked tgt 7 s7212 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7212 7 _ le
  decide +kernel
theorem b7213 : Blocked tgt 7 s7213 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7213 7 _ le
  decide +kernel
theorem b7214 : Blocked tgt 7 s7214 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7214 7 _ le
  decide +kernel
theorem b7220 : Blocked tgt 7 s7220 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7220 7 _ le
  decide +kernel
theorem b7221 : Blocked tgt 7 s7221 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7221 7 _ le
  decide +kernel
theorem b7222 : Blocked tgt 7 s7222 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7222 7 _ le
  decide +kernel
theorem b7223 : Blocked tgt 7 s7223 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7223 7 _ le
  decide +kernel
theorem b7224 : Blocked tgt 7 s7224 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7224 7 _ le
  decide +kernel
theorem b7225 : Blocked tgt 7 s7225 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7225 7 _ le
  decide +kernel
theorem b7226 : Blocked tgt 7 s7226 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7226 7 _ le
  decide +kernel

theorem b7227 : Blocked tgt 7 s7227 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7227 7 _ le
  decide +kernel
theorem b7228 : Blocked tgt 7 s7228 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7228 7 _ le
  decide +kernel
theorem b7229 : Blocked tgt 7 s7229 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7229 7 _ le
  decide +kernel
theorem b7230 : Blocked tgt 7 s7230 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7230 7 _ le
  decide +kernel
theorem b7231 : Blocked tgt 7 s7231 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7231 7 _ le
  decide +kernel
theorem b7232 : Blocked tgt 7 s7232 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7232 7 _ le
  decide +kernel
theorem b7233 : Blocked tgt 7 s7233 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7233 7 _ le
  decide +kernel
theorem b7234 : Blocked tgt 7 s7234 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7234 7 _ le
  decide +kernel
theorem b7235 : Blocked tgt 7 s7235 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7235 7 _ le
  decide +kernel
theorem b7236 : Blocked tgt 7 s7236 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7236 7 _ le
  decide +kernel
theorem b7237 : Blocked tgt 7 s7237 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7237 7 _ le
  decide +kernel
theorem b7238 : Blocked tgt 7 s7238 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7238 7 _ le
  decide +kernel
theorem b7239 : Blocked tgt 7 s7239 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7239 7 _ le
  decide +kernel
theorem b7240 : Blocked tgt 7 s7240 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7240 7 _ le
  decide +kernel
theorem b7241 : Blocked tgt 7 s7241 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7241 7 _ le
  decide +kernel
theorem b7242 : Blocked tgt 7 s7242 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7242 7 _ le
  decide +kernel
theorem b7243 : Blocked tgt 7 s7243 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7243 7 _ le
  decide +kernel
theorem b7244 : Blocked tgt 7 s7244 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7244 7 _ le
  decide +kernel
theorem b7245 : Blocked tgt 7 s7245 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s7245 7 _ le
  decide +kernel
theorem b7246 : Blocked tgt 7 s7246 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7246 7 _ le
  decide +kernel
theorem b7247 : Blocked tgt 7 s7247 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7247 7 _ le
  decide +kernel
theorem b7248 : Blocked tgt 7 s7248 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7248 7 _ le
  decide +kernel
theorem b7249 : Blocked tgt 7 s7249 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7249 7 _ le
  decide +kernel
theorem b7250 : Blocked tgt 7 s7250 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7250 7 _ le
  decide +kernel
theorem b7251 : Blocked tgt 7 s7251 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7251 7 _ le
  decide +kernel
theorem b7252 : Blocked tgt 7 s7252 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7252 7 _ le
  decide +kernel
theorem b7253 : Blocked tgt 7 s7253 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7253 7 _ le
  decide +kernel
theorem b7254 : Blocked tgt 7 s7254 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7254 7 _ le
  decide +kernel
theorem b7255 : Blocked tgt 7 s7255 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7255 7 _ le
  decide +kernel
theorem b7256 : Blocked tgt 7 s7256 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7256 7 _ le
  decide +kernel
theorem b7257 : Blocked tgt 7 s7257 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7257 7 _ le
  decide +kernel
theorem b7258 : Blocked tgt 7 s7258 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7258 7 _ le
  decide +kernel

theorem b7259 : Blocked tgt 7 s7259 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7259 7 _ le
  decide +kernel
theorem b7260 : Blocked tgt 7 s7260 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7260 7 _ le
  decide +kernel
theorem b7261 : Blocked tgt 7 s7261 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,4522,4522,6836,4522,9793,5930,4522,6578,4522,7474,6578,4522,6578,7466,4522,8650,426,12746,8650,4522,458,12714,4522,6836,4522,4522,6836,8641,5930,9921,8641,1669,8641,1669,7474,2693,7466,2693,8641,4741,13386,4741,8641,449,8641,13610,901,901,8897,8897,9921,1669,9921,2181,11457,9921,9921,4741,12481,9921,1665,9921,9921,1665,1665,9921,9921,1665,1669,10433,2693,1669,1669,12481,4741,1669,1669,3410,14642,1669,1669,7474,7474,1669,2693,3370,4741,2693,2693,11457,11457,2693,2693,11457,11457,2693,4741,12481,12481,4741,4741,12481,12481,4741,8837,8837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Residual
