import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv35_4260 : PetersenPackedPin.project r35 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv35_4814 : PetersenPackedPin.project r35 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv35_5473 : PetersenPackedPin.project r35 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv35_6170 : PetersenPackedPin.project r35 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv35_6790 : PetersenPackedPin.project r35 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv35_7474 : PetersenPackedPin.project r35 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv35_8012 : PetersenPackedPin.project r35 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff := by decide +kernel
theorem pv35_351 : PetersenPackedPin.project r35 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_4260 pv35_8012 rfl rfl
theorem pv35_456 : PetersenPackedPin.project r35 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_5473 pv35_8012 rfl rfl
theorem pv35_581 : PetersenPackedPin.project r35 (0xffff0000ffff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_6790 pv35_8012 rfl rfl
theorem pv35_630 : PetersenPackedPin.project r35 (0xffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_7474 pv35_8012 rfl rfl
theorem pv35_1734 : PetersenPackedPin.project r35 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaa := PetersenWireProjection.derive 1 pv35_4260 pv35_6790 rfl rfl
theorem pv35_1829 : PetersenPackedPin.project r35 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_5473 pv35_6790 rfl rfl
theorem pv35_2192 : PetersenPackedPin.project r35 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xa0a := PetersenWireProjection.derive 1 pv35_4260 pv35_6170 rfl rfl
theorem pv35_2298 : PetersenPackedPin.project r35 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_5473 pv35_6170 rfl rfl
theorem pv35_2708 : PetersenPackedPin.project r35 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv35_4260 pv35_5473 rfl rfl
theorem pv35_2906 : PetersenPackedPin.project r35 (0xf0f00000f0f00000f0f00000f0f0000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv35_5473 pv35_6790 rfl rfl
theorem pv35_3209 : PetersenPackedPin.project r35 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv35_4814 pv35_5473 rfl rfl
theorem pv35_3632 : PetersenPackedPin.project r35 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv35_4260 pv35_5473 rfl rfl
theorem pv35_3980 : PetersenPackedPin.project r35 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_4260 pv35_5473 rfl rfl
theorem pv35_4429 : PetersenPackedPin.project r35 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_4814 pv35_5473 rfl rfl
theorem pv35_5850 : PetersenPackedPin.project r35 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv35_4260 pv35_5473 rfl rfl
theorem pv35_5920 : PetersenPackedPin.project r35 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv35_4814 pv35_5473 rfl rfl
theorem pv35_6618 : PetersenPackedPin.project r35 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv35_5473 pv35_6170 rfl rfl
theorem pv35_7095 : PetersenPackedPin.project r35 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffaa := PetersenWireProjection.derive 3 pv35_4260 pv35_6790 rfl rfl
theorem pv35_7152 : PetersenPackedPin.project r35 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffcc := PetersenWireProjection.derive 3 pv35_4814 pv35_6790 rfl rfl
theorem pv35_7235 : PetersenPackedPin.project r35 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv35_5473 pv35_6790 rfl rfl
theorem pv35_7397 : PetersenPackedPin.project r35 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_7474 pv35_8012 rfl rfl
theorem pv35_7855 : PetersenPackedPin.project r35 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv35_6170 pv35_7474 rfl rfl
theorem pv35_8191 : PetersenPackedPin.project r35 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_4260 pv35_8012 rfl rfl
theorem pv35_8208 : PetersenPackedPin.project r35 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_4814 pv35_8012 rfl rfl
theorem pv35_8245 : PetersenPackedPin.project r35 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_5473 pv35_8012 rfl rfl
theorem pv35_8295 : PetersenPackedPin.project r35 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_6170 pv35_8012 rfl rfl
theorem pv35_8331 : PetersenPackedPin.project r35 (0xffffffffffffffffffff0000ffff0000 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_6790 pv35_8012 rfl rfl
theorem pv35_60 : PetersenPackedPin.project r35 (0xa0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_351 pv35_7235 rfl rfl
theorem pv35_64 : PetersenPackedPin.project r35 (0x222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_351 pv35_7152 rfl rfl
theorem pv35_85 : PetersenPackedPin.project r35 (0xaaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_351 pv35_6790 rfl rfl
theorem pv35_208 : PetersenPackedPin.project r35 (0xf0f0a0a0f0f0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_7095 pv35_8245 rfl rfl
theorem pv35_264 : PetersenPackedPin.project r35 (0x3333222233332222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_7095 pv35_8208 rfl rfl
theorem pv35_348 : PetersenPackedPin.project r35 (0xaaaaaaaaaa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_351 pv35_7855 rfl rfl
theorem pv35_603 : PetersenPackedPin.project r35 (0xffffaaaaffffaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_7095 pv35_8012 rfl rfl
theorem pv35_1366 : PetersenPackedPin.project r35 (0xffffffff00000000aaaaaaaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv35_7474 pv35_8191 rfl rfl
theorem pv35_1740 : PetersenPackedPin.project r35 (0xaaaa0000aaaaf0f0fafaf0f0fafa : BitVec 128) = 0xaa := PetersenWireProjection.derive 3 pv35_456 pv35_1734 rfl rfl
theorem pv35_3822 : PetersenPackedPin.project r35 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv35_3980 pv35_5850 rfl rfl
theorem pv35_5335 : PetersenPackedPin.project r35 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_5473 pv35_7095 rfl rfl
theorem pv35_5408 : PetersenPackedPin.project r35 (0xf0f0f0f0f000f000f0f0f0f0f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_5473 pv35_7855 rfl rfl
theorem pv35_5851 : PetersenPackedPin.project r35 (0xfafafafafafafafafffffafafffffafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv35_581 pv35_5850 rfl rfl
theorem pv35_8059 : PetersenPackedPin.project r35 (0xffffffffffffffff0000aaaa0000aaaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_1734 pv35_8012 rfl rfl
theorem pv35_8079 : PetersenPackedPin.project r35 (0xffffffffffffffff00aa00aa00aa00aa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_2192 pv35_8012 rfl rfl
theorem pv35_8104 : PetersenPackedPin.project r35 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_2708 pv35_8012 rfl rfl
theorem pv35_8219 : PetersenPackedPin.project r35 (0xffffffffffffffffcccceeeecccceeee : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_1734 pv35_8208 rfl rfl
theorem pv35_8223 : PetersenPackedPin.project r35 (0xffffffffffffffffcceecceecceeccee : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_2192 pv35_8208 rfl rfl
theorem pv35_8252 : PetersenPackedPin.project r35 (0xfffffffffffffffff0f0fafaf0f0fafa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_1734 pv35_8245 rfl rfl
theorem pv35_8255 : PetersenPackedPin.project r35 (0xfffffffffffffffff0faf0faf0faf0fa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_2192 pv35_8245 rfl rfl
theorem pv35_8305 : PetersenPackedPin.project r35 (0xffffffffffffffffff0aff0aff0aff0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_2708 pv35_8295 rfl rfl
theorem pv35_8352 : PetersenPackedPin.project r35 (0xffffffffffffffffffffaaaaffffaaaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_4260 pv35_8331 rfl rfl
theorem pv35_465 : PetersenPackedPin.project r35 (0xf0f0fafaf0f0fafa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_1740 pv35_8012 rfl rfl
theorem pv35_620 : PetersenPackedPin.project r35 (0xfffffafafffffafa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv35_5851 pv35_8012 rfl rfl
theorem pv35_1349 : PetersenPackedPin.project r35 (0xffffffff000000000000aaaa : BitVec 128) = 0xffff := PetersenWireProjection.derive 2 pv35_7474 pv35_8059 rfl rfl
theorem pv35_5486 : PetersenPackedPin.project r35 (0xf0f0f0f0f0f0f0f0fffffafafffffafa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv35_208 pv35_5473 rfl rfl
theorem pv35_7407 : PetersenPackedPin.project r35 (0xffffffff000000000000aaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv35_7474 pv35_8059 rfl rfl
theorem pv35_8049 : PetersenPackedPin.project r35 (0xffffffffffffffff00000a0a00000a0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_60 pv35_8012 rfl rfl
theorem pv35_8050 : PetersenPackedPin.project r35 (0xffffffffffffffff0000222200002222 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_64 pv35_8012 rfl rfl
theorem pv35_8113 : PetersenPackedPin.project r35 (0xffffffffffffffff0f0f0a0a0f0f0a0a : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_208 pv35_8012 rfl rfl
theorem pv35_8139 : PetersenPackedPin.project r35 (0xffffffffffffffff3333222233332222 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_264 pv35_8012 rfl rfl
theorem pv35_8189 : PetersenPackedPin.project r35 (0xffffffffffffffffaaaaaaaaaa00aa00 : BitVec 128) = 0xffff := PetersenWireProjection.derive 3 pv35_348 pv35_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
