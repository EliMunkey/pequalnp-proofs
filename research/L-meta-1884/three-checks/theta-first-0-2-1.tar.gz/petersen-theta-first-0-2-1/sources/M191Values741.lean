import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv741_4260 : PetersenPackedPin.project r741 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv741_4814 : PetersenPackedPin.project r741 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv741_5473 : PetersenPackedPin.project r741 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv741_6170 : PetersenPackedPin.project r741 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv741_6790 : PetersenPackedPin.project r741 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv741_7474 : PetersenPackedPin.project r741 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv741_8012 : PetersenPackedPin.project r741 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv741_5850 : PetersenPackedPin.project r741 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv741_4260 pv741_5473 rfl rfl
theorem pv741_5920 : PetersenPackedPin.project r741 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv741_4814 pv741_5473 rfl rfl
theorem pv741_4514 : PetersenPackedPin.project r741 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv741_4814 pv741_5850 rfl rfl
end PetersenSmallStarts.M191.Residual
