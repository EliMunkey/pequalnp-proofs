import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv11_4260 : PetersenPackedPin.project r11 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv11_4814 : PetersenPackedPin.project r11 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv11_5473 : PetersenPackedPin.project r11 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv11_6170 : PetersenPackedPin.project r11 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv11_6790 : PetersenPackedPin.project r11 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv11_7474 : PetersenPackedPin.project r11 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv11_8012 : PetersenPackedPin.project r11 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv11_351 : PetersenPackedPin.project r11 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_8012 rfl rfl
theorem pv11_391 : PetersenPackedPin.project r11 (0xcccccccccccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4814 pv11_8012 rfl rfl
theorem pv11_630 : PetersenPackedPin.project r11 (0xffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_7474 pv11_8012 rfl rfl
theorem pv11_1073 : PetersenPackedPin.project r11 (0xaaaaaaaa00000000aaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_7474 rfl rfl
theorem pv11_1177 : PetersenPackedPin.project r11 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv11_5473 pv11_7474 rfl rfl
theorem pv11_1734 : PetersenPackedPin.project r11 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_6790 rfl rfl
theorem pv11_1925 : PetersenPackedPin.project r11 (0xffff000000000000ffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6790 pv11_7474 rfl rfl
theorem pv11_2192 : PetersenPackedPin.project r11 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_6170 rfl rfl
theorem pv11_2240 : PetersenPackedPin.project r11 (0xcc00cc00cc00cc00cc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4814 pv11_6170 rfl rfl
theorem pv11_2418 : PetersenPackedPin.project r11 (0xff00ff0000000000ff00ff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6170 pv11_7474 rfl rfl
theorem pv11_2708 : PetersenPackedPin.project r11 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_5473 rfl rfl
theorem pv11_2963 : PetersenPackedPin.project r11 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_5473 pv11_7474 rfl rfl
theorem pv11_3157 : PetersenPackedPin.project r11 (0x22222222222222222222222222222222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_4260 pv11_4814 rfl rfl
theorem pv11_3427 : PetersenPackedPin.project r11 (0x33333333000000003333333300000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4814 pv11_7474 rfl rfl
theorem pv11_3582 : PetersenPackedPin.project r11 (0x44444444444444444444444444444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4260 pv11_4814 rfl rfl
theorem pv11_3632 : PetersenPackedPin.project r11 (0x50505050505050505050505050505050 : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv11_4260 pv11_5473 rfl rfl
theorem pv11_3677 : PetersenPackedPin.project r11 (0x55005500550055005500550055005500 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 2 pv11_4260 pv11_6170 rfl rfl
theorem pv11_3705 : PetersenPackedPin.project r11 (0x55550000555500005555000055550000 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv11_4260 pv11_6790 rfl rfl
theorem pv11_3730 : PetersenPackedPin.project r11 (0x55555555000000005555555500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4260 pv11_7474 rfl rfl
theorem pv11_3980 : PetersenPackedPin.project r11 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_4260 pv11_5473 rfl rfl
theorem pv11_4059 : PetersenPackedPin.project r11 (0xaa00aa00aa00aa00aa00aa00aa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_4260 pv11_6170 rfl rfl
theorem pv11_4109 : PetersenPackedPin.project r11 (0xaaaa0000aaaa0000aaaa0000aaaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_4260 pv11_6790 rfl rfl
theorem pv11_4429 : PetersenPackedPin.project r11 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_4814 pv11_5473 rfl rfl
theorem pv11_5224 : PetersenPackedPin.project r11 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4260 pv11_4814 rfl rfl
theorem pv11_5367 : PetersenPackedPin.project r11 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_5473 pv11_7474 rfl rfl
theorem pv11_5850 : PetersenPackedPin.project r11 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv11_4260 pv11_5473 rfl rfl
theorem pv11_5920 : PetersenPackedPin.project r11 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv11_4814 pv11_5473 rfl rfl
theorem pv11_6055 : PetersenPackedPin.project r11 (0xff00ff0000000000ff00ff0000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_6170 pv11_7474 rfl rfl
theorem pv11_6504 : PetersenPackedPin.project r11 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_4260 pv11_6170 rfl rfl
theorem pv11_6618 : PetersenPackedPin.project r11 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xeeee := PetersenWireProjection.derive 3 pv11_5473 pv11_6170 rfl rfl
theorem pv11_7095 : PetersenPackedPin.project r11 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv11_4260 pv11_6790 rfl rfl
theorem pv11_7152 : PetersenPackedPin.project r11 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv11_4814 pv11_6790 rfl rfl
theorem pv11_7235 : PetersenPackedPin.project r11 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xfafa := PetersenWireProjection.derive 3 pv11_5473 pv11_6790 rfl rfl
theorem pv11_7397 : PetersenPackedPin.project r11 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_7474 pv11_8012 rfl rfl
theorem pv11_7688 : PetersenPackedPin.project r11 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4260 pv11_7474 rfl rfl
theorem pv11_7712 : PetersenPackedPin.project r11 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4814 pv11_7474 rfl rfl
theorem pv11_7774 : PetersenPackedPin.project r11 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv11_5473 pv11_7474 rfl rfl
theorem pv11_7855 : PetersenPackedPin.project r11 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_6170 pv11_7474 rfl rfl
theorem pv11_8191 : PetersenPackedPin.project r11 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv11_4260 pv11_8012 rfl rfl
theorem pv11_8208 : PetersenPackedPin.project r11 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv11_4814 pv11_8012 rfl rfl
theorem pv11_60 : PetersenPackedPin.project r11 (0xa0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_351 pv11_7235 rfl rfl
theorem pv11_112 : PetersenPackedPin.project r11 (0xa000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_351 pv11_6618 rfl rfl
theorem pv11_720 : PetersenPackedPin.project r11 (0x22220000000000002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1073 pv11_7152 rfl rfl
theorem pv11_732 : PetersenPackedPin.project r11 (0xa0a0000000000000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_1177 pv11_1734 rfl rfl
theorem pv11_766 : PetersenPackedPin.project r11 (0xa000a00000000000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_2192 pv11_7774 rfl rfl
theorem pv11_1401 : PetersenPackedPin.project r11 (0xa0000000a0000000a0000000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1734 pv11_6618 rfl rfl
theorem pv11_1431 : PetersenPackedPin.project r11 (0xaa000000aa000000aa000000aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1734 pv11_6170 rfl rfl
theorem pv11_1496 : PetersenPackedPin.project r11 (0xa0a00000a0a00000a0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1734 pv11_5473 rfl rfl
theorem pv11_1546 : PetersenPackedPin.project r11 (0x2222000022220000222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1734 pv11_4814 rfl rfl
theorem pv11_1631 : PetersenPackedPin.project r11 (0x5555000000000000555500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_1925 pv11_4260 rfl rfl
theorem pv11_1639 : PetersenPackedPin.project r11 (0x5555000044440000555500004444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_7095 pv11_7712 rfl rfl
theorem pv11_1693 : PetersenPackedPin.project r11 (0xa0a00000a0a00000a0a00000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_1734 pv11_5473 rfl rfl
theorem pv11_1944 : PetersenPackedPin.project r11 (0xffff0000aaaa0000ffff0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6790 pv11_7688 rfl rfl
theorem pv11_1945 : PetersenPackedPin.project r11 (0xffff0000cccc0000ffff0000cccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6790 pv11_7712 rfl rfl
theorem pv11_2012 : PetersenPackedPin.project r11 (0x20002000200020002000200020002 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_2192 pv11_5920 rfl rfl
theorem pv11_2024 : PetersenPackedPin.project r11 (0xa000a000a000a000a000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_2192 pv11_5473 rfl rfl
theorem pv11_2059 : PetersenPackedPin.project r11 (0x220022002200220022002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_2192 pv11_4814 rfl rfl
theorem pv11_2440 : PetersenPackedPin.project r11 (0xff00ff00aa00aa00ff00ff00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6170 pv11_7688 rfl rfl
theorem pv11_2441 : PetersenPackedPin.project r11 (0xff00ff00cc00cc00ff00ff00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6170 pv11_7712 rfl rfl
theorem pv11_2517 : PetersenPackedPin.project r11 (0x2020202020202020202020202020202 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_2708 pv11_4814 rfl rfl
theorem pv11_2979 : PetersenPackedPin.project r11 (0xf0f0f0f0a0a0a0a0f0f0f0f0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_5473 pv11_7688 rfl rfl
theorem pv11_3049 : PetersenPackedPin.project r11 (0xf0fafaf0000aaaa0f0fafaf0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_1734 pv11_2963 rfl rfl
theorem pv11_3057 : PetersenPackedPin.project r11 (0xfaf0faf00aa00aa0faf0faf00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2192 pv11_2963 rfl rfl
theorem pv11_3735 : PetersenPackedPin.project r11 (0x55555555444444445555555544444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4260 pv11_7712 rfl rfl
theorem pv11_3788 : PetersenPackedPin.project r11 (0x5555aaaa5555aaaa5555aaaa5555aaaa : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv11_4109 pv11_7095 rfl rfl
theorem pv11_3797 : PetersenPackedPin.project r11 (0x55aa55aa55aa55aa55aa55aa55aa55aa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 2 pv11_4059 pv11_6504 rfl rfl
theorem pv11_4514 : PetersenPackedPin.project r11 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_4814 pv11_5850 rfl rfl
theorem pv11_4925 : PetersenPackedPin.project r11 (0xcccceeeecccceeeecccceeeecccceeee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_1734 pv11_4814 rfl rfl
theorem pv11_4974 : PetersenPackedPin.project r11 (0xcceecceecceecceecceecceecceeccee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2192 pv11_4814 rfl rfl
theorem pv11_5029 : PetersenPackedPin.project r11 (0xcececececececececececececececece : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2708 pv11_4814 rfl rfl
theorem pv11_5201 : PetersenPackedPin.project r11 (0xeeeecccceeeecccceeeecccceeeecccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4109 pv11_4814 rfl rfl
theorem pv11_5568 : PetersenPackedPin.project r11 (0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv11_1734 pv11_5473 rfl rfl
theorem pv11_5614 : PetersenPackedPin.project r11 (0xf0faf0faf0faf0faf0faf0faf0faf0fa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv11_2192 pv11_5473 rfl rfl
theorem pv11_5682 : PetersenPackedPin.project r11 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 2 pv11_2708 pv11_6170 rfl rfl
theorem pv11_6308 : PetersenPackedPin.project r11 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_2708 pv11_6170 rfl rfl
theorem pv11_7439 : PetersenPackedPin.project r11 (0xffffffff00000000aaaaaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv11_7474 pv11_8191 rfl rfl
theorem pv11_7528 : PetersenPackedPin.project r11 (0xffffffff0000aaaaffffffff0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_1734 pv11_7474 rfl rfl
theorem pv11_7558 : PetersenPackedPin.project r11 (0xffffffff00aa00aaffffffff00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2192 pv11_7474 rfl rfl
theorem pv11_7588 : PetersenPackedPin.project r11 (0xffffffff0a0a0a0affffffff0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2708 pv11_7474 rfl rfl
theorem pv11_7684 : PetersenPackedPin.project r11 (0xffffffffaaaa0000ffffffffaaaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4109 pv11_7474 rfl rfl
theorem pv11_7725 : PetersenPackedPin.project r11 (0xffffffffcccceeeeffffffffcccceeee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_1734 pv11_7712 rfl rfl
theorem pv11_7730 : PetersenPackedPin.project r11 (0xffffffffcceecceeffffffffcceeccee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2192 pv11_7712 rfl rfl
theorem pv11_7734 : PetersenPackedPin.project r11 (0xffffffffcecececeffffffffcececece : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_2708 pv11_7712 rfl rfl
theorem pv11_7749 : PetersenPackedPin.project r11 (0xffffffffeeeeeeeeffffffffeeeeeeee : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_4260 pv11_7712 rfl rfl
theorem pv11_7913 : PetersenPackedPin.project r11 (0xffffffffffccffccffffffffffccffcc : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_4814 pv11_7855 rfl rfl
theorem pv11_8104 : PetersenPackedPin.project r11 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv11_2708 pv11_8012 rfl rfl
theorem pv11_1934 : PetersenPackedPin.project r11 (0xffff00000a0a0000ffff00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_6790 pv11_7588 rfl rfl
theorem pv11_2968 : PetersenPackedPin.project r11 (0xf0f0f0f00000a0a0f0f0f0f00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_3049 pv11_5473 rfl rfl
theorem pv11_2971 : PetersenPackedPin.project r11 (0xf0f0f0f000a000a0f0f0f0f000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv11_3057 pv11_5473 rfl rfl
theorem pv11_3434 : PetersenPackedPin.project r11 (0x33333333000022223333333300002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4814 pv11_7528 rfl rfl
theorem pv11_3438 : PetersenPackedPin.project r11 (0x33333333002200223333333300220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv11_4814 pv11_7558 rfl rfl
theorem pv11_6226 : PetersenPackedPin.project r11 (0xff00ff0aff00ff0aff00ff0aff00ff0a : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_1401 pv11_6170 rfl rfl
theorem pv11_6277 : PetersenPackedPin.project r11 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv11_2012 pv11_6170 rfl rfl
theorem pv11_7515 : PetersenPackedPin.project r11 (0xffffffff00002222ffffffff00002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_720 pv11_7474 rfl rfl
theorem pv11_7526 : PetersenPackedPin.project r11 (0xffffffff0000a0a0ffffffff0000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_732 pv11_7474 rfl rfl
theorem pv11_7549 : PetersenPackedPin.project r11 (0xffffffff000a000affffffff000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv11_766 pv11_7474 rfl rfl
theorem pv11_8049 : PetersenPackedPin.project r11 (0xffffffffffffffff00000a0a00000a0a : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv11_60 pv11_8012 rfl rfl
theorem pv11_8074 : PetersenPackedPin.project r11 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv11_112 pv11_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
