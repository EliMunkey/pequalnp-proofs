import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv1_4260 : PetersenPackedPin.project r1 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv1_4814 : PetersenPackedPin.project r1 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv1_5473 : PetersenPackedPin.project r1 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv1_6170 : PetersenPackedPin.project r1 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv1_6790 : PetersenPackedPin.project r1 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv1_7474 : PetersenPackedPin.project r1 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv1_8012 : PetersenPackedPin.project r1 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv1_391 : PetersenPackedPin.project r1 (0xcccccccccccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_4814 pv1_8012 rfl rfl
theorem pv1_1117 : PetersenPackedPin.project r1 (0xcccccccc00000000cccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_4814 pv1_7474 rfl rfl
theorem pv1_1734 : PetersenPackedPin.project r1 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 1 pv1_4260 pv1_6790 rfl rfl
theorem pv1_1779 : PetersenPackedPin.project r1 (0xcccc0000cccc0000cccc0000cccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_4814 pv1_6790 rfl rfl
theorem pv1_1829 : PetersenPackedPin.project r1 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0xcc00cc00cc00cc := PetersenWireProjection.derive 1 pv1_5473 pv1_6790 rfl rfl
theorem pv1_2192 : PetersenPackedPin.project r1 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 1 pv1_4260 pv1_6170 rfl rfl
theorem pv1_2240 : PetersenPackedPin.project r1 (0xcc00cc00cc00cc00cc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_4814 pv1_6170 rfl rfl
theorem pv1_2708 : PetersenPackedPin.project r1 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 1 pv1_4260 pv1_5473 rfl rfl
theorem pv1_2800 : PetersenPackedPin.project r1 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_4814 pv1_5473 rfl rfl
theorem pv1_3157 : PetersenPackedPin.project r1 (0x22222222222222222222222222222222 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv1_4260 pv1_4814 rfl rfl
theorem pv1_3209 : PetersenPackedPin.project r1 (0x30303030303030303030303030303030 : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 2 pv1_4814 pv1_5473 rfl rfl
theorem pv1_3359 : PetersenPackedPin.project r1 (0x33330000333300003333000033330000 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 2 pv1_4814 pv1_6790 rfl rfl
theorem pv1_3582 : PetersenPackedPin.project r1 (0x44444444444444444444444444444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_4260 pv1_4814 rfl rfl
theorem pv1_3897 : PetersenPackedPin.project r1 (0x88888888888888888888888888888888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4260 pv1_4814 rfl rfl
theorem pv1_4429 : PetersenPackedPin.project r1 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_5473 rfl rfl
theorem pv1_4522 : PetersenPackedPin.project r1 (0xcc00cc00cc00cc00cc00cc00cc00cc00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_6170 rfl rfl
theorem pv1_4586 : PetersenPackedPin.project r1 (0xcccc0000cccc0000cccc0000cccc0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_6790 rfl rfl
theorem pv1_4675 : PetersenPackedPin.project r1 (0xcccccccc00000000cccccccc00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7474 rfl rfl
theorem pv1_4753 : PetersenPackedPin.project r1 (0xcccccccccccccccc0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_8012 rfl rfl
theorem pv1_5224 : PetersenPackedPin.project r1 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv1_4260 pv1_4814 rfl rfl
theorem pv1_5850 : PetersenPackedPin.project r1 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv1_4260 pv1_5473 rfl rfl
theorem pv1_5920 : PetersenPackedPin.project r1 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv1_4814 pv1_5473 rfl rfl
theorem pv1_6504 : PetersenPackedPin.project r1 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xfafafafafafafafa := PetersenWireProjection.derive 3 pv1_4260 pv1_6170 rfl rfl
theorem pv1_6546 : PetersenPackedPin.project r1 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv1_4814 pv1_6170 rfl rfl
theorem pv1_6618 : PetersenPackedPin.project r1 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv1_5473 pv1_6170 rfl rfl
theorem pv1_7095 : PetersenPackedPin.project r1 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffaaffaaffaaffaa := PetersenWireProjection.derive 3 pv1_4260 pv1_6790 rfl rfl
theorem pv1_7152 : PetersenPackedPin.project r1 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv1_4814 pv1_6790 rfl rfl
theorem pv1_7235 : PetersenPackedPin.project r1 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xffccffccffccffcc := PetersenWireProjection.derive 3 pv1_5473 pv1_6790 rfl rfl
theorem pv1_7314 : PetersenPackedPin.project r1 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0xfff0fff0fff0fff0 := PetersenWireProjection.derive 3 pv1_6170 pv1_6790 rfl rfl
theorem pv1_7688 : PetersenPackedPin.project r1 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0xffffaaaaffffaaaa := PetersenWireProjection.derive 3 pv1_4260 pv1_7474 rfl rfl
theorem pv1_7712 : PetersenPackedPin.project r1 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv1_4814 pv1_7474 rfl rfl
theorem pv1_7774 : PetersenPackedPin.project r1 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xffffccccffffcccc := PetersenWireProjection.derive 3 pv1_5473 pv1_7474 rfl rfl
theorem pv1_7855 : PetersenPackedPin.project r1 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xfffff0f0fffff0f0 := PetersenWireProjection.derive 3 pv1_6170 pv1_7474 rfl rfl
theorem pv1_7944 : PetersenPackedPin.project r1 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffffff00ffffff00 := PetersenWireProjection.derive 3 pv1_6790 pv1_7474 rfl rfl
theorem pv1_8191 : PetersenPackedPin.project r1 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffffffffaaaaaaaa := PetersenWireProjection.derive 3 pv1_4260 pv1_8012 rfl rfl
theorem pv1_8208 : PetersenPackedPin.project r1 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv1_4814 pv1_8012 rfl rfl
theorem pv1_8245 : PetersenPackedPin.project r1 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xffffffffcccccccc := PetersenWireProjection.derive 3 pv1_5473 pv1_8012 rfl rfl
theorem pv1_8295 : PetersenPackedPin.project r1 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xfffffffff0f0f0f0 := PetersenWireProjection.derive 3 pv1_6170 pv1_8012 rfl rfl
theorem pv1_8331 : PetersenPackedPin.project r1 (0xffffffffffffffffffff0000ffff0000 : BitVec 128) = 0xffffffffff00ff00 := PetersenWireProjection.derive 3 pv1_6790 pv1_8012 rfl rfl
theorem pv1_135 : PetersenPackedPin.project r1 (0xcc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_391 pv1_6170 rfl rfl
theorem pv1_278 : PetersenPackedPin.project r1 (0x4444444444444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_391 pv1_4260 rfl rfl
theorem pv1_373 : PetersenPackedPin.project r1 (0xcc44cc44cc44cc44 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_391 pv1_2192 rfl rfl
theorem pv1_379 : PetersenPackedPin.project r1 (0xcccc4444cccc4444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_391 pv1_1734 rfl rfl
theorem pv1_667 : PetersenPackedPin.project r1 (0xfffffffff0f0f0f0 : BitVec 128) = 0xffffcccc := PetersenWireProjection.derive 1 pv1_7774 pv1_8012 rfl rfl
theorem pv1_738 : PetersenPackedPin.project r1 (0xcccc000000000000cccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1117 pv1_6790 rfl rfl
theorem pv1_817 : PetersenPackedPin.project r1 (0xcc00cc0000000000cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1117 pv1_6170 rfl rfl
theorem pv1_905 : PetersenPackedPin.project r1 (0xc0c0c0c000000000c0c0c0c : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1117 pv1_5473 rfl rfl
theorem pv1_1007 : PetersenPackedPin.project r1 (0x444444440000000044444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1117 pv1_4260 rfl rfl
theorem pv1_1366 : PetersenPackedPin.project r1 (0xffffffff00000000aaaaaaaa : BitVec 128) = 0xffff0000aaaa := PetersenWireProjection.derive 2 pv1_7474 pv1_8191 rfl rfl
theorem pv1_1441 : PetersenPackedPin.project r1 (0xcc000000cc000000cc000000cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1779 pv1_6170 rfl rfl
theorem pv1_1482 : PetersenPackedPin.project r1 (0x404000004040000040400000404 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1779 pv1_5850 rfl rfl
theorem pv1_1503 : PetersenPackedPin.project r1 (0xc0c00000c0c00000c0c00000c0c : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1779 pv1_5473 rfl rfl
theorem pv1_1546 : PetersenPackedPin.project r1 (0x2222000022220000222200002222 : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 1 pv1_1734 pv1_4814 rfl rfl
theorem pv1_1579 : PetersenPackedPin.project r1 (0x4444000044440000444400004444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1779 pv1_4260 rfl rfl
theorem pv1_1678 : PetersenPackedPin.project r1 (0x8888000088880000888800008888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_1734 pv1_4814 rfl rfl
theorem pv1_1760 : PetersenPackedPin.project r1 (0xc0c00000c0c00000c0c00000c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_1779 pv1_5473 rfl rfl
theorem pv1_1762 : PetersenPackedPin.project r1 (0xc4c40000c4c40000c4c40000c4c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_1779 pv1_2708 rfl rfl
theorem pv1_2012 : PetersenPackedPin.project r1 (0x20002000200020002000200020002 : BitVec 128) = 0x202020202020202 := PetersenWireProjection.derive 1 pv1_2192 pv1_5920 rfl rfl
theorem pv1_2029 : PetersenPackedPin.project r1 (0xc000c000c000c000c000c000c000c : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_2240 pv1_5473 rfl rfl
theorem pv1_2059 : PetersenPackedPin.project r1 (0x220022002200220022002200220022 : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 1 pv1_2192 pv1_4814 rfl rfl
theorem pv1_2093 : PetersenPackedPin.project r1 (0x440044004400440044004400440044 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_2240 pv1_4260 rfl rfl
theorem pv1_2140 : PetersenPackedPin.project r1 (0x880088008800880088008800880088 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_2192 pv1_4814 rfl rfl
theorem pv1_2224 : PetersenPackedPin.project r1 (0xc400c400c400c400c400c400c400c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_2240 pv1_2708 rfl rfl
theorem pv1_2517 : PetersenPackedPin.project r1 (0x2020202020202020202020202020202 : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 1 pv1_2708 pv1_4814 rfl rfl
theorem pv1_2584 : PetersenPackedPin.project r1 (0x4040404040404040404040404040404 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv1_2800 pv1_4260 rfl rfl
theorem pv1_2627 : PetersenPackedPin.project r1 (0x8080808080808080808080808080808 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_2708 pv1_4814 rfl rfl
theorem pv1_2774 : PetersenPackedPin.project r1 (0xc040c040c040c040c040c040c040c04 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_2192 pv1_2800 rfl rfl
theorem pv1_2779 : PetersenPackedPin.project r1 (0xc0c04040c0c04040c0c04040c0c0404 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_1734 pv1_2800 rfl rfl
theorem pv1_2780 : PetersenPackedPin.project r1 (0xc0c08080c0c08080c0c08080c0c0808 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_2800 pv1_7095 rfl rfl
theorem pv1_3173 : PetersenPackedPin.project r1 (0x2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv1_4260 pv1_4429 rfl rfl
theorem pv1_3276 : PetersenPackedPin.project r1 (0x32323232323232323232323232323232 : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 2 pv1_4814 pv1_5850 rfl rfl
theorem pv1_3392 : PetersenPackedPin.project r1 (0x33332222333322223333222233332222 : BitVec 128) = 0xffaaffaaffaaffaa := PetersenWireProjection.derive 2 pv1_4814 pv1_7095 rfl rfl
theorem pv1_3463 : PetersenPackedPin.project r1 (0x33333333330033003333333333003300 : BitVec 128) = 0xfffff0f0fffff0f0 := PetersenWireProjection.derive 2 pv1_4814 pv1_7855 rfl rfl
theorem pv1_4424 : PetersenPackedPin.project r1 (0xc040c040c040c040c040c040c040c040 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_2192 pv1_4429 rfl rfl
theorem pv1_4425 : PetersenPackedPin.project r1 (0xc0c04040c0c04040c0c04040c0c04040 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_1734 pv1_4429 rfl rfl
theorem pv1_4481 : PetersenPackedPin.project r1 (0xc0c0eaeac0c0eaeac0c0eaeac0c0eaea : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv1_1734 pv1_4429 rfl rfl
theorem pv1_4490 : PetersenPackedPin.project r1 (0xc0eac0eac0eac0eac0eac0eac0eac0ea : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 3 pv1_2192 pv1_4429 rfl rfl
theorem pv1_4503 : PetersenPackedPin.project r1 (0xc4c4c4c4c4c4c4c4c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_2708 pv1_4814 rfl rfl
theorem pv1_4514 : PetersenPackedPin.project r1 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_5850 rfl rfl
theorem pv1_4574 : PetersenPackedPin.project r1 (0xcc44cc44cc44cc44cc44cc44cc44cc44 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_2192 pv1_4814 rfl rfl
theorem pv1_4579 : PetersenPackedPin.project r1 (0xcc88cc88cc88cc88cc88cc88cc88cc88 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_6504 rfl rfl
theorem pv1_4582 : PetersenPackedPin.project r1 (0xccc0ccc0ccc0ccc0ccc0ccc0ccc0ccc0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_6618 rfl rfl
theorem pv1_4630 : PetersenPackedPin.project r1 (0xcccc4444cccc4444cccc4444cccc4444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_1734 pv1_4814 rfl rfl
theorem pv1_4641 : PetersenPackedPin.project r1 (0xcccc8888cccc8888cccc8888cccc8888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7095 rfl rfl
theorem pv1_4659 : PetersenPackedPin.project r1 (0xccccc0c0ccccc0c0ccccc0c0ccccc0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7235 rfl rfl
theorem pv1_4663 : PetersenPackedPin.project r1 (0xcccccc00cccccc00cccccc00cccccc00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7314 rfl rfl
theorem pv1_4718 : PetersenPackedPin.project r1 (0xcccccccc88888888cccccccc88888888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7688 rfl rfl
theorem pv1_4722 : PetersenPackedPin.project r1 (0xccccccccc0c0c0c0ccccccccc0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7774 rfl rfl
theorem pv1_4732 : PetersenPackedPin.project r1 (0xcccccccccc00cc00cccccccccc00cc00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7855 rfl rfl
theorem pv1_4745 : PetersenPackedPin.project r1 (0xcccccccccccc0000cccccccccccc0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7944 rfl rfl
theorem pv1_4785 : PetersenPackedPin.project r1 (0xcccccccccccccccc8888888888888888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_8191 rfl rfl
theorem pv1_4790 : PetersenPackedPin.project r1 (0xccccccccccccccccc0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_8245 rfl rfl
theorem pv1_4796 : PetersenPackedPin.project r1 (0xcccccccccccccccccc00cc00cc00cc00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_8295 rfl rfl
theorem pv1_4921 : PetersenPackedPin.project r1 (0xcccceeeecccceeee0000aaaa0000aaaa : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv1_1734 pv1_4753 rfl rfl
theorem pv1_4925 : PetersenPackedPin.project r1 (0xcccceeeecccceeeecccceeeecccceeee : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv1_1734 pv1_4814 rfl rfl
theorem pv1_4974 : PetersenPackedPin.project r1 (0xcceecceecceecceecceecceecceeccee : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 3 pv1_2192 pv1_4814 rfl rfl
theorem pv1_5012 : PetersenPackedPin.project r1 (0xce0ace0ace0ace0ace0ace0ace0ace0a : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 3 pv1_2708 pv1_4522 rfl rfl
theorem pv1_5029 : PetersenPackedPin.project r1 (0xcececececececececececececececece : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 3 pv1_2708 pv1_4814 rfl rfl
theorem pv1_5157 : PetersenPackedPin.project r1 (0xeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaea : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv1_4260 pv1_4429 rfl rfl
theorem pv1_5682 : PetersenPackedPin.project r1 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xd0d0d0d0d0d0d0d0 := PetersenWireProjection.derive 2 pv1_2708 pv1_6170 rfl rfl
theorem pv1_6308 : PetersenPackedPin.project r1 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xf2f2f2f2f2f2f2f2 := PetersenWireProjection.derive 3 pv1_2708 pv1_6170 rfl rfl
theorem pv1_6897 : PetersenPackedPin.project r1 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xff22ff22ff22ff22 := PetersenWireProjection.derive 3 pv1_2708 pv1_6790 rfl rfl
theorem pv1_7004 : PetersenPackedPin.project r1 (0xffff8888ffff8888ffff8888ffff8888 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv1_3897 pv1_6790 rfl rfl
theorem pv1_7206 : PetersenPackedPin.project r1 (0xffffeeeeffffeeeeffffeeeeffffeeee : BitVec 128) = 0xffaaffaaffaaffaa := PetersenWireProjection.derive 3 pv1_4260 pv1_7152 rfl rfl
theorem pv1_7285 : PetersenPackedPin.project r1 (0xfffffafafffffafafffffafafffffafa : BitVec 128) = 0xffeeffeeffeeffee := PetersenWireProjection.derive 3 pv1_4260 pv1_7235 rfl rfl
theorem pv1_7380 : PetersenPackedPin.project r1 (0xffffffccffffffccffffffccffffffcc : BitVec 128) = 0xfff0fff0fff0fff0 := PetersenWireProjection.derive 3 pv1_4814 pv1_7314 rfl rfl
theorem pv1_7903 : PetersenPackedPin.project r1 (0xffffffffffaaffaaffffffffffaaffaa : BitVec 128) = 0xfffffafafffffafa := PetersenWireProjection.derive 3 pv1_4260 pv1_7855 rfl rfl
theorem pv1_7913 : PetersenPackedPin.project r1 (0xffffffffffccffccffffffffffccffcc : BitVec 128) = 0xfffff0f0fffff0f0 := PetersenWireProjection.derive 3 pv1_4814 pv1_7855 rfl rfl
theorem pv1_7971 : PetersenPackedPin.project r1 (0xffffffffffffaaaaffffffffffffaaaa : BitVec 128) = 0xffffffaaffffffaa := PetersenWireProjection.derive 3 pv1_4260 pv1_7944 rfl rfl
theorem pv1_8180 : PetersenPackedPin.project r1 (0xffffffffffffffff8888888888888888 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv1_3897 pv1_8012 rfl rfl
theorem pv1_3315 : PetersenPackedPin.project r1 (0x33023302330233023302330233023302 : BitVec 128) = 0xf2f2f2f2f2f2f2f2 := PetersenWireProjection.derive 2 pv1_4814 pv1_6308 rfl rfl
theorem pv1_4472 : PetersenPackedPin.project r1 (0xc0c0c4c4c0c0c4c4c0c0c4c4c0c0c4c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv1_2780 pv1_4814 rfl rfl
theorem pv1_4473 : PetersenPackedPin.project r1 (0xc0c0c8c8c0c0c8c8c0c0c8c8c0c0c8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4481 pv1_4814 rfl rfl
theorem pv1_4485 : PetersenPackedPin.project r1 (0xc0c8c0c8c0c8c0c8c0c8c0c8c0c8c0c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4490 pv1_4814 rfl rfl
theorem pv1_4565 : PetersenPackedPin.project r1 (0xcc08cc08cc08cc08cc08cc08cc08cc08 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_5012 rfl rfl
theorem pv1_4622 : PetersenPackedPin.project r1 (0xcccc0808cccc0808cccc0808cccc0808 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_6897 rfl rfl
theorem pv1_4662 : PetersenPackedPin.project r1 (0xccccc8c8ccccc8c8ccccc8c8ccccc8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7285 rfl rfl
theorem pv1_4741 : PetersenPackedPin.project r1 (0xcccccccccc88cc88cccccccccc88cc88 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7903 rfl rfl
theorem pv1_4749 : PetersenPackedPin.project r1 (0xcccccccccccc8888cccccccccccc8888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_7971 rfl rfl
theorem pv1_4765 : PetersenPackedPin.project r1 (0xcccccccccccccccc0000888800008888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv1_4814 pv1_4921 rfl rfl
theorem pv1_6277 : PetersenPackedPin.project r1 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xf2f2f2f2f2f2f2f2 := PetersenWireProjection.derive 3 pv1_2012 pv1_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
