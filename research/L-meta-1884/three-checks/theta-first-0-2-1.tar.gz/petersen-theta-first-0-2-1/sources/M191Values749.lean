import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv749_4260 : PetersenPackedPin.project r749 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv749_4814 : PetersenPackedPin.project r749 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv749_5473 : PetersenPackedPin.project r749 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv749_6170 : PetersenPackedPin.project r749 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv749_6790 : PetersenPackedPin.project r749 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv749_7474 : PetersenPackedPin.project r749 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv749_8012 : PetersenPackedPin.project r749 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv749_456 : PetersenPackedPin.project r749 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0xc0c0c0c0c0c0c0c := PetersenWireProjection.derive 1 pv749_5473 pv749_8012 rfl rfl
theorem pv749_1734 : PetersenPackedPin.project r749 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv749_4260 pv749_6790 rfl rfl
theorem pv749_2708 : PetersenPackedPin.project r749 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv749_4260 pv749_5473 rfl rfl
theorem pv749_5850 : PetersenPackedPin.project r749 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv749_4260 pv749_5473 rfl rfl
theorem pv749_8191 : PetersenPackedPin.project r749 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv749_4260 pv749_8012 rfl rfl
theorem pv749_501 : PetersenPackedPin.project r749 (0xfafafafafafafafa : BitVec 128) = 0xc0c0c0c0c0c0c0c := PetersenWireProjection.derive 1 pv749_5850 pv749_8012 rfl rfl
theorem pv749_6308 : PetersenPackedPin.project r749 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv749_2708 pv749_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
