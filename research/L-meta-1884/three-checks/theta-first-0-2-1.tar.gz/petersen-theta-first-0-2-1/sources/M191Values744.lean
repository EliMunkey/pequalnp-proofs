import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv744_4260 : PetersenPackedPin.project r744 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv744_4814 : PetersenPackedPin.project r744 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv744_5473 : PetersenPackedPin.project r744 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv744_6170 : PetersenPackedPin.project r744 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv744_6790 : PetersenPackedPin.project r744 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv744_7474 : PetersenPackedPin.project r744 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv744_8012 : PetersenPackedPin.project r744 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv744_1734 : PetersenPackedPin.project r744 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv744_4260 pv744_6790 rfl rfl
theorem pv744_2192 : PetersenPackedPin.project r744 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv744_4260 pv744_6170 rfl rfl
theorem pv744_2708 : PetersenPackedPin.project r744 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv744_4260 pv744_5473 rfl rfl
theorem pv744_8245 : PetersenPackedPin.project r744 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv744_5473 pv744_8012 rfl rfl
theorem pv744_6308 : PetersenPackedPin.project r744 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv744_2708 pv744_6170 rfl rfl
theorem pv744_8275 : PetersenPackedPin.project r744 (0xfffffffffffffffffafafafafafafafa : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv744_4260 pv744_8245 rfl rfl
end PetersenSmallStarts.M191.Residual
