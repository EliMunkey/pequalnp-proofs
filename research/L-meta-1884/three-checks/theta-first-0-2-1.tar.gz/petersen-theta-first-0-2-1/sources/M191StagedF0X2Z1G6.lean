import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values2
import M191Values38
import M191Values39
import M191Values5
import M191Values734
import M191Values735
import M191Values745
import M191Values753
import M191Values754
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows7
import ResidualFast
import ThetaClosing
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1595 : Blocked tgt 7 s1595 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1595 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xfdccfdccfdccfdccfdccfdccfdccfdcc : BitVec 128) = 0xfafafafafafafafa) (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1596 : Blocked tgt 7 s1596 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1596 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1597 : Blocked tgt 7 s1597 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1597 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x20202020000000002020202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1598 : Blocked tgt 7 s1598 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1598 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffffffffffffffff0202020202020202 : BitVec 128) = 0xffffffff00000000) rfl)))))))) (by decide +kernel)
theorem b1599 : Blocked tgt 7 s1599 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1599 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xfdfdfdfdfdfdfdfd0000000000000000 : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b1600 : Blocked tgt 7 s1600 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1600 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1601 : Blocked tgt 7 s1601 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1601 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1602 : Blocked tgt 7 s1602 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1602 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1603 : Blocked tgt 7 s1603 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s1603 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xf0f0f0f0f0f0f0f0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_3677 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1604 : Blocked tgt 7 s1604 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [(true,(6,false),(1,false))] s1604 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xffffffffaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0x2020202020202020202020202020202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xffffffffaaaaaaaa) (PetersenWireProjection.cons pv745_6618 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl)))))))) (by decide +kernel)
theorem b1605 : Blocked tgt 7 s1605 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1605 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xcccc,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2517 (PetersenWireProjection.cons pv13_2860 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6546 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b1606 : Blocked tgt 7 s1606 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,false),(1,true))] s1606 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x2020202020202020202020202020202 : BitVec 128) = 0x2222222222222222) (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_5288 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b1607 : Blocked tgt 7 s1607 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,false),(1,true))] s1607 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2063 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x2020202020202020202020202020202 : BitVec 128) = 0x2222222222222222) (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)

theorem b1608 : Blocked tgt 7 s1608 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s1608 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2240 (PetersenWireProjection.cons pv1_2517 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6546 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b1609 : Blocked tgt 7 s1609 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s1609 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2240 (PetersenWireProjection.cons pv1_2517 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b1610 : Blocked tgt 7 s1610 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1610 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2517 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5978 (PetersenWireProjection.cons pv10_6546 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1611 : Blocked tgt 7 s1611 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1611 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2362 (PetersenWireProjection.cons pv10_2517 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6546 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b1614 : Blocked tgt 7 s1614 := by
  intro k le c
  apply rejects_sound r746 (0xa0a :: i4) 3 tgt small746 hot746 [] s1614 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a,0x0,0x0,0xcccc,0x0,0x0,0xff00,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xffccffccffccffcc : BitVec 128) = 0xa0a) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0x2020202020202020202020202020202 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r746 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0) rfl)))))))) (by decide +kernel)
theorem b1635 : Blocked tgt 7 s1635 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s1635 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8208 rfl)))))))) (by decide +kernel)
theorem b1687 : Blocked tgt 7 s1687 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1687 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5944 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8295 rfl)))))))) (by decide +kernel)
theorem b1688 : Blocked tgt 7 s1688 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1688 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0xff00ff00] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfdfdfdfdfdfdfdfd0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8295 rfl)))))))) (by decide +kernel)
theorem b1689 : Blocked tgt 7 s1689 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1689 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x2020202020202020200020002000200 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1690 : Blocked tgt 7 s1690 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1690 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x2000200020002 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b1691 : Blocked tgt 7 s1691 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s1691 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xfdfdfdfdfdfdfdfdfd00fd00fd00fd00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b1692 : Blocked tgt 7 s1692 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s1692 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_135 (PetersenWireProjection.cons pv1_2517 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b2344 : Blocked tgt 7 s2344 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2344 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1863 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2345 : Blocked tgt 7 s2345 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2345 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7285 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2348 : Blocked tgt 7 s2348 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2348 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7992 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2352 : Blocked tgt 7 s2352 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2352 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8366 rfl)))))))) (by decide +kernel)
theorem b2365 : Blocked tgt 7 s2365 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2365 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xaaaafafaaaaafafaaaaafafaaaaafafa : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2545 : Blocked tgt 7 s2545 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s2545 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv38_2604 (PetersenWireProjection.cons pv38_4260 (PetersenWireProjection.cons pv38_4814 (PetersenWireProjection.cons pv38_5473 (PetersenWireProjection.cons pv38_6170 (PetersenWireProjection.cons pv38_6790 (PetersenWireProjection.cons pv38_7474 (PetersenWireProjection.cons pv38_8012 rfl)))))))) (by decide +kernel)
theorem b2552 : Blocked tgt 7 s2552 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,1,6,3,8,9,10,11,12,13,14,15,16,17,18,19,20,17,22,19,24,25,26,27,28,29,30,31,32,33,34,35,36,33,38,35,40,41,42,43,44,45,46,47,48,49,50,51,52,49,54,51,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,1,6,3,8,9,10,11,12,13,14,15,16,17,18,19,20,17,22,19,24,25,26,27,28,29,30,31,32,33,34,35,36,33,38,35,40,41,42,43,44,45,46,47,48,49,50,51,52,49,54,51,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xf0f0f0f0f0f0f0f0f000f000f000f00,0xf0f0f0f0f0f0f0f0f000f000f000f00),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1009) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1009
theorem b2558 : Blocked tgt 7 s2558 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s2558 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x5050505050505050500050005000500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl)))))))) (by decide +kernel)
theorem b2564 : Blocked tgt 7 s2564 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,4,3,6,16,20,18,22,17,21,19,23,8,12,10,14,9,12,11,14,24,28,26,30,25,29,27,31,64,68,66,70,65,68,67,70,80,84,82,86,81,85,83,87,72,76,74,78,73,76,75,78,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,1,3,3,16,20,18,22,17,17,19,19,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,33,35,35,48,52,50,54,49,49,51,51,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0x55555555555500005555555555550000,0xf0f0f0f0f0f0f0f0f000f000f000f00),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1009) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1009
theorem b2571 : Blocked tgt 7 s2571 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s2571 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r38 (0x5050505050500000505050505050000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv38_4260 (PetersenWireProjection.cons pv38_4814 (PetersenWireProjection.cons pv38_5473 (PetersenWireProjection.cons pv38_6170 (PetersenWireProjection.cons pv38_6790 (PetersenWireProjection.cons pv38_7474 (PetersenWireProjection.cons pv38_8012 rfl)))))))) (by decide +kernel)
theorem b2600 : Blocked tgt 7 s2600 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2600 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2601 : Blocked tgt 7 s2601 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2601 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2602 : Blocked tgt 7 s2602 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s2602 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_3632 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5850 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl)))))))) (by decide +kernel)
theorem b2603 : Blocked tgt 7 s2603 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2603 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2604 : Blocked tgt 7 s2604 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2604 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_6897 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2605 : Blocked tgt 7 s2605 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2605 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2606 : Blocked tgt 7 s2606 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2606 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2607 : Blocked tgt 7 s2607 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2607 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2608 : Blocked tgt 7 s2608 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,9673,9673,5928,6964,8649,7732,6964,9673,6964,11465,9673,9801,9673,9673,4900,9673,2868,13513,9673,1417,1481,9609,1417,6324,9673,9673,6580,6962,4906,7474,6962,5930,6962,6962,5930,5930,6962,9674,5930,10058,1834,13642,10058,5930,1994,10058,5930,5930,10058,6058,5930,10433,7474,7474,11457,5668,7474,7474,5668,11602,3378,14674,11602,7474,11602,11602,7474,7474,11602,11602,7474,7466,7466,13642,14674,13642,14674,3209,3273,11401,3209,3593,11465,11465,6324,13642,14674,13642,14674,1673,9737,1737,1673,4772,9801,9801,1545,5257,13642,13642,5257,2196,13642,13642,6292,13610,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2609 : Blocked tgt 7 s2609 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2609 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2610 : Blocked tgt 7 s2610 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2610 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2611 : Blocked tgt 7 s2611 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2611 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xffff0000ffff0000) (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2612 : Blocked tgt 7 s2612 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2612 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2613 : Blocked tgt 7 s2613 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2613 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2614 : Blocked tgt 7 s2614 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2614 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3368 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2615 : Blocked tgt 7 s2615 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2615 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xfafa0000fafa0000fafa0000fafa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2616 : Blocked tgt 7 s2616 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2616 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1863 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2617 : Blocked tgt 7 s2617 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2617 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2618 : Blocked tgt 7 s2618 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2618 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2619 : Blocked tgt 7 s2619 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2619 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2620 : Blocked tgt 7 s2620 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2620 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2621 : Blocked tgt 7 s2621 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2621 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2628 : Blocked tgt 7 s2628 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2628 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5224 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7588 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b2630 : Blocked tgt 7 s2630 := by
  intro k le c
  apply rejects_sound r754 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small754 hot754 [] s2630 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r754 (0x50505050505050505050505050505050 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv754_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r754 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv754_6170 (PetersenWireProjection.cons pv754_6790 (PetersenWireProjection.cons pv754_7474 (PetersenWireProjection.cons pv754_7588 (PetersenWireProjection.cons pv754_8012 rfl)))))))) (by decide +kernel)
theorem b2632 : Blocked tgt 7 s2632 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5288,5290,5288,5544,8641,8649,9665,8641,6324,9673,9673,6580,9673,4916,11465,9673,9673,6964,13513,9673,9801,9673,9673,389,1417,1481,9609,1417,4522,4522,5546,6962,6962,5546,5546,6578,5546,4914,7466,5546,1450,1450,5546,10058,10058,5546,5546,9674,5546,1866,13610,5546,7474,7474,10433,7466,10433,7466,12481,12489,12481,13505,8897,9793,8897,8905,14642,13610,14642,13610,4260,7466,6308,7466,2228,13513,6324,13513,2708,9801,6324,9801,14642,13610,14642,13610,11594,7466,7466,11594,11594,7466,7466,11594,7466,3402,13610,7466,13642,13642,5257,13610,13449,13610,1545,13610,1609,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2638 : Blocked tgt 7 s2638 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2638 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4514 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7588 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b2661 : Blocked tgt 7 s2661 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2661 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2662 : Blocked tgt 7 s2662 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2662 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2663 : Blocked tgt 7 s2663 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2663 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5154 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b2664 : Blocked tgt 7 s2664 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2664 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2665 : Blocked tgt 7 s2665 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2665 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2666 : Blocked tgt 7 s2666 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2666 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2667 : Blocked tgt 7 s2667 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2667 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2668 : Blocked tgt 7 s2668 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2668 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b2669 : Blocked tgt 7 s2669 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2669 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b2670 : Blocked tgt 7 s2670 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2670 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2671 : Blocked tgt 7 s2671 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2671 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2672 : Blocked tgt 7 s2672 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2672 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2673 : Blocked tgt 7 s2673 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2673 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2674 : Blocked tgt 7 s2674 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2674 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2675 : Blocked tgt 7 s2675 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2675 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2676 : Blocked tgt 7 s2676 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2676 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_5224 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b2677 : Blocked tgt 7 s2677 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2677 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2678 : Blocked tgt 7 s2678 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2678 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaea : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2679 : Blocked tgt 7 s2679 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2679 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3063 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)

theorem b2680 : Blocked tgt 7 s2680 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9673,389,9673,5546,5546,7474,9793,7474,8897,9801,6324,7466,11465,7466,9801,13642,13513,13642,9801,13610,9737,13610,1545,5672,9673,9673,5928,8641,8649,9665,8641,9673,6964,9673,7210,11465,9673,9673,13386,13513,9673,1417,1481,9609,1417,6962,4906,7474,6962,10832,5930,5930,6832,5930,11465,7466,11465,10058,13513,13642,13513,5930,1866,13610,5930,7474,7732,10433,10441,10433,11457,12481,12489,12481,13505,7474,3410,14642,7474,4772,11465,6820,11465,2708,13513,6804,13513,6836,13610,14900,13610,11465,3370,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2681 : Blocked tgt 7 s2681 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2681 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2682 : Blocked tgt 7 s2682 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9673,389,9673,5546,5546,7474,9793,7474,8769,7466,11465,7466,9801,13642,13513,13642,9801,13610,9737,13610,1673,9801,1545,5802,9673,9673,5930,8641,8649,9665,8641,9673,7466,11465,9673,9673,13386,13513,9673,1417,1481,9609,1417,9673,6964,6962,4906,7474,6962,5930,11465,7466,11465,10058,13513,13642,13513,5930,1866,13610,5930,5672,5930,5930,5672,10433,10441,10433,11457,12481,12489,12481,13505,7474,3410,14642,7474,6836,7474,7474,7732,11465,3370,13513,11465,3209,3273,11401,3209,4772,11465,11465,6820,5257,5321,13449,5257,2708,13513,13513,6804,13610,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2683 : Blocked tgt 7 s2683 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2683 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_438 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2689 : Blocked tgt 7 s2689 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2689 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2690 : Blocked tgt 7 s2690 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2690 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2691 : Blocked tgt 7 s2691 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2691 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2692 : Blocked tgt 7 s2692 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false)),(false,(2,true),(0,false))] s2692 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x50505050505050505050505050505050,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xfafafafafafafafafafafafafafafafa,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_3632 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_5850 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2693 : Blocked tgt 7 s2693 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false)),(false,(2,true),(0,false))] s2693 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_3632 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2694 : Blocked tgt 7 s2694 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2694 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2695 : Blocked tgt 7 s2695 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2695 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2696 : Blocked tgt 7 s2696 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2696 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2697 : Blocked tgt 7 s2697 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2697 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2698 : Blocked tgt 7 s2698 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2698 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b2699 : Blocked tgt 7 s2699 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2699 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b2700 : Blocked tgt 7 s2700 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s2700 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xffffffffcccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5102 (PetersenWireProjection.cons pv735_5850 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)

theorem b2701 : Blocked tgt 7 s2701 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false))] s2701 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xfafafafafafafafafafafafafafafafa,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5850 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2702 : Blocked tgt 7 s2702 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false)),(false,(2,true),(0,false))] s2702 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_3632 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2703 : Blocked tgt 7 s2703 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s2703 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0xff50ff50ff50ff50ff50ff50ff50ff50 : BitVec 128) = 0xeeeeeeeeeeeeeeee) (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl)))))))) (by decide +kernel)
theorem b2704 : Blocked tgt 7 s2704 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2704 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2099 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
