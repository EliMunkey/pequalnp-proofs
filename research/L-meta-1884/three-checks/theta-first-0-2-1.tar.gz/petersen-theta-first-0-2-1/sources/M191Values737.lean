import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv737_4260 : PetersenPackedPin.project r737 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv737_4814 : PetersenPackedPin.project r737 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv737_5473 : PetersenPackedPin.project r737 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv737_6170 : PetersenPackedPin.project r737 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv737_6790 : PetersenPackedPin.project r737 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv737_7474 : PetersenPackedPin.project r737 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv737_8012 : PetersenPackedPin.project r737 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv737_531 : PetersenPackedPin.project r737 (0xff00ff00ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv737_6170 pv737_8012 rfl rfl
theorem pv737_1252 : PetersenPackedPin.project r737 (0xff00ff0000000000ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv737_6170 pv737_7474 rfl rfl
theorem pv737_1294 : PetersenPackedPin.project r737 (0xffff000000000000ffff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv737_6790 pv737_7474 rfl rfl
theorem pv737_1734 : PetersenPackedPin.project r737 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv737_4260 pv737_6790 rfl rfl
theorem pv737_1887 : PetersenPackedPin.project r737 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv737_6170 pv737_6790 rfl rfl
theorem pv737_2298 : PetersenPackedPin.project r737 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 1 pv737_5473 pv737_6170 rfl rfl
theorem pv737_2362 : PetersenPackedPin.project r737 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_6170 pv737_6790 rfl rfl
theorem pv737_2708 : PetersenPackedPin.project r737 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 1 pv737_4260 pv737_5473 rfl rfl
theorem pv737_2860 : PetersenPackedPin.project r737 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_5473 pv737_6170 rfl rfl
theorem pv737_2906 : PetersenPackedPin.project r737 (0xf0f00000f0f00000f0f00000f0f0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_5473 pv737_6790 rfl rfl
theorem pv737_3304 : PetersenPackedPin.project r737 (0x33003300330033003300330033003300 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_4814 pv737_6170 rfl rfl
theorem pv737_3359 : PetersenPackedPin.project r737 (0x33330000333300003333000033330000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_4814 pv737_6790 rfl rfl
theorem pv737_3677 : PetersenPackedPin.project r737 (0x55005500550055005500550055005500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_4260 pv737_6170 rfl rfl
theorem pv737_5224 : PetersenPackedPin.project r737 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv737_4260 pv737_4814 rfl rfl
theorem pv737_5241 : PetersenPackedPin.project r737 (0xf000f000f000f000f000f000f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv737_5473 pv737_6170 rfl rfl
theorem pv737_5850 : PetersenPackedPin.project r737 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xfafafafa := PetersenWireProjection.derive 3 pv737_4260 pv737_5473 rfl rfl
theorem pv737_5978 : PetersenPackedPin.project r737 (0xff000000ff000000ff000000ff000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv737_6170 pv737_6790 rfl rfl
theorem pv737_6504 : PetersenPackedPin.project r737 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv737_4260 pv737_6170 rfl rfl
theorem pv737_6546 : PetersenPackedPin.project r737 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv737_4814 pv737_6170 rfl rfl
theorem pv737_6618 : PetersenPackedPin.project r737 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv737_5473 pv737_6170 rfl rfl
theorem pv737_7095 : PetersenPackedPin.project r737 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv737_4260 pv737_6790 rfl rfl
theorem pv737_7235 : PetersenPackedPin.project r737 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv737_5473 pv737_6790 rfl rfl
theorem pv737_7314 : PetersenPackedPin.project r737 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv737_6170 pv737_6790 rfl rfl
theorem pv737_7944 : PetersenPackedPin.project r737 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv737_6790 pv737_7474 rfl rfl
theorem pv737_8191 : PetersenPackedPin.project r737 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffaaffaa := PetersenWireProjection.derive 3 pv737_4260 pv737_8012 rfl rfl
theorem pv737_8295 : PetersenPackedPin.project r737 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv737_6170 pv737_8012 rfl rfl
theorem pv737_1496 : PetersenPackedPin.project r737 (0xa0a00000a0a00000a0a00000a0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 1 pv737_1734 pv737_5473 rfl rfl
theorem pv737_2754 : PetersenPackedPin.project r737 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xfafafafa := PetersenWireProjection.derive 2 pv737_5241 pv737_5850 rfl rfl
theorem pv737_2938 : PetersenPackedPin.project r737 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 2 pv737_5473 pv737_7095 rfl rfl
theorem pv737_3249 : PetersenPackedPin.project r737 (0x31003100310031003100310031003100 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_2708 pv737_3304 rfl rfl
theorem pv737_3276 : PetersenPackedPin.project r737 (0x32323232323232323232323232323232 : BitVec 128) = 0x32323232 := PetersenWireProjection.derive 2 pv737_4814 pv737_5850 rfl rfl
theorem pv737_5029 : PetersenPackedPin.project r737 (0xcececececececececececececececece : BitVec 128) = 0xcececece := PetersenWireProjection.derive 3 pv737_2708 pv737_4814 rfl rfl
theorem pv737_5682 : PetersenPackedPin.project r737 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv737_2708 pv737_6170 rfl rfl
theorem pv737_5745 : PetersenPackedPin.project r737 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xf500f500 := PetersenWireProjection.derive 2 pv737_2708 pv737_8012 rfl rfl
theorem pv737_6308 : PetersenPackedPin.project r737 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 3 pv737_2708 pv737_6170 rfl rfl
theorem pv737_6457 : PetersenPackedPin.project r737 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv737_6504 pv737_6790 rfl rfl
theorem pv737_6897 : PetersenPackedPin.project r737 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 3 pv737_2708 pv737_6790 rfl rfl
theorem pv737_5946 : PetersenPackedPin.project r737 (0xfdccfdccfdccfdccfdccfdccfdccfdcc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv737_3249 pv737_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
