import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv739_4260 : PetersenPackedPin.project r739 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv739_4814 : PetersenPackedPin.project r739 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv739_5473 : PetersenPackedPin.project r739 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv739_6170 : PetersenPackedPin.project r739 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv739_6790 : PetersenPackedPin.project r739 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv739_7474 : PetersenPackedPin.project r739 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv739_8012 : PetersenPackedPin.project r739 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv739_456 : PetersenPackedPin.project r739 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 1 pv739_5473 pv739_8012 rfl rfl
theorem pv739_630 : PetersenPackedPin.project r739 (0xffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv739_7474 pv739_8012 rfl rfl
theorem pv739_1343 : PetersenPackedPin.project r739 (0xffffffff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_7474 pv739_8012 rfl rfl
theorem pv739_2708 : PetersenPackedPin.project r739 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a0a0a := PetersenWireProjection.derive 1 pv739_4260 pv739_5473 rfl rfl
theorem pv739_2963 : PetersenPackedPin.project r739 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_5473 pv739_7474 rfl rfl
theorem pv739_3004 : PetersenPackedPin.project r739 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_5473 pv739_8012 rfl rfl
theorem pv739_3427 : PetersenPackedPin.project r739 (0x33333333000000003333333300000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_4814 pv739_7474 rfl rfl
theorem pv739_3485 : PetersenPackedPin.project r739 (0x33333333333333330000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_4814 pv739_8012 rfl rfl
theorem pv739_3730 : PetersenPackedPin.project r739 (0x55555555000000005555555500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_4260 pv739_7474 rfl rfl
theorem pv739_3759 : PetersenPackedPin.project r739 (0x55555555555555550000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_4260 pv739_8012 rfl rfl
theorem pv739_5224 : PetersenPackedPin.project r739 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv739_4260 pv739_4814 rfl rfl
theorem pv739_5425 : PetersenPackedPin.project r739 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv739_5473 pv739_8012 rfl rfl
theorem pv739_6504 : PetersenPackedPin.project r739 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xffaaffaa := PetersenWireProjection.derive 3 pv739_4260 pv739_6170 rfl rfl
theorem pv739_7397 : PetersenPackedPin.project r739 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv739_7474 pv739_8012 rfl rfl
theorem pv739_7774 : PetersenPackedPin.project r739 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv739_5473 pv739_7474 rfl rfl
theorem pv739_8191 : PetersenPackedPin.project r739 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv739_4260 pv739_8012 rfl rfl
theorem pv739_8295 : PetersenPackedPin.project r739 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv739_6170 pv739_8012 rfl rfl
theorem pv739_8377 : PetersenPackedPin.project r739 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv739_7474 pv739_8012 rfl rfl
theorem pv739_3259 : PetersenPackedPin.project r739 (0x31313131313131310000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_2708 pv739_3485 rfl rfl
theorem pv739_5029 : PetersenPackedPin.project r739 (0xcececececececececececececececece : BitVec 128) = 0xcececece := PetersenWireProjection.derive 3 pv739_2708 pv739_4814 rfl rfl
theorem pv739_5682 : PetersenPackedPin.project r739 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xf500f500 := PetersenWireProjection.derive 2 pv739_2708 pv739_6170 rfl rfl
theorem pv739_5729 : PetersenPackedPin.project r739 (0xf5f5f5f500000000f5f5f5f500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_2708 pv739_7474 rfl rfl
theorem pv739_5745 : PetersenPackedPin.project r739 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv739_2708 pv739_8012 rfl rfl
theorem pv739_6308 : PetersenPackedPin.project r739 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xff0aff0a := PetersenWireProjection.derive 3 pv739_2708 pv739_6170 rfl rfl
theorem pv739_6897 : PetersenPackedPin.project r739 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xffff0a0a := PetersenWireProjection.derive 3 pv739_2708 pv739_6790 rfl rfl
theorem pv739_7439 : PetersenPackedPin.project r739 (0xffffffff00000000aaaaaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv739_7474 pv739_8191 rfl rfl
theorem pv739_7760 : PetersenPackedPin.project r739 (0xfffffffff0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv739_7774 pv739_8012 rfl rfl
theorem pv739_8305 : PetersenPackedPin.project r739 (0xffffffffffffffffff0aff0aff0aff0a : BitVec 128) = 0xff0aff0a := PetersenWireProjection.derive 3 pv739_2708 pv739_8295 rfl rfl
theorem pv739_5958 : PetersenPackedPin.project r739 (0xfdfdfdfdfdfdfdfdcccccccccccccccc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv739_3259 pv739_4814 rfl rfl
end PetersenSmallStarts.M191.Residual
