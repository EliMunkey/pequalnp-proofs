import M191ResidualC7A0G1
import M191ResidualC7A0G4
import M191StagedF0X2Z1G10
import M191StagedF0X2Z1G11
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G5
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G9
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows2
import M191StartPreferredRows3
import M191StartPreferredRows4
import M191StartPreferredRows5
import M191StartPreferredRows6
import M191StartPreferredRows7
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b493 : Blocked tgt 8 s493 := by
  apply PetersenFastNode.node (nxt := #[s494,s495,s369,s409,s496,s497,s498,s499,s500,s501,s502,s503,s504,s505,s506,s507,s508,s509,s510,s511,s512,s514,s515,s516,s480,s517,s518,s519,s520,s521,s522,s523]) (hints := [6868,6868,6996,5578,5578,0,6996,5578,6996,6868,6868,1,5578,5578,5962,6868,6868,2,5962,6868,5962,5578,5578,3,6354,6354,7506,4554,5578,1701,7378,5578,7506,6354,6354,1701,5578,5578,7498,4562,6354,4,7370,6354,7498,5578,5578,5,5322,4804,6,5322,5578,9705,5578,5578,7,9705,4804,9705,9706,9706,13674,1482,5578,13545,13674,5578,13674,9706,9706,13545,5578,5578,13642,1514,9706,8869,13642,9706,13642,5578,5578,8869,9961,8,5704,9961,6996,5962,5704,6996,5704,5962,9,5962,1701,6996,1701,7250,10,7506,1701,11,1701,6996,6996,7506,4948,12,13,4948,6996,7498,6996,6996,14,7498,15,7498,16,17,18,9705,6996,9705,933,6996,19,933,15,9705,4773,2868,4773,13545,6996,13545,4773,6996,4773,13545,2868,13545,8869,6996,8869,13642,20,13642,8869,21,8869,6996,6996,13642,6994,6994,7506,1701,5962,1701,7506,5962,7506,1701,6994,1701,5962,5962,7498,4946,6994,22,7498,6994,7498,5962,5962,23,9705,5704,9705,5962,5962,24,9705,5962,9705,10217,5704,25,13545,10090,13545,4773,5962,4773,13545,5962,13545,4773,10090,4773,5962,5962,13642,8869,10090,8869,13642,10090,13642,8869,5962,8869,1701,1701,26,7498,7506,7498,7490,7506,27,1701,1701,7498,8673,1701,8673,8681,7506,9705,8673,7506,8673,9697,1701,9705,12513,1701,12513,12521,7506,13545,12513,7506,12513,13537,1701,13545,1701,1701,8869,3442,11634,13642,8869,11634,8869,1701,1701,13642,9705,7498,9705,11497,28,29,13545,11626,13545,3402,7498,14706,13545,7498,13545,11626,11626,14706,8869,7498,8869,3434,11626,14674,8869,11626,8869,7498,7498,14674,9705,9705,13545,13674,30,13674,13545,31,13545,9705,9705,13674,1449,1449,8869,1513,9705,13642,9641,9705,8869,1449,1449,13642,5289,5289,8869,5353,13545,13642,13481,13545,8869,5289,5289,13642]) (by decide +kernel)
  change ∀ b ∈ [s494,s495,s369,s409,s496,s497,s498,s499,s500,s501,s502,s503,s504,s505,s506,s507,s508,s509,s510,s511,s512,s514,s515,s516,s480,s517,s518,s519,s520,s521,s522,s523], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s494) b494 <|
    PetersenLocalChildren.push (x := s495) b495 <|
    PetersenLocalChildren.push (x := s369) b369 <|
    PetersenLocalChildren.push (x := s409) b409 <|
    PetersenLocalChildren.push (x := s496) b496 <|
    PetersenLocalChildren.push (x := s497) b497 <|
    PetersenLocalChildren.push (x := s498) b498 <|
    PetersenLocalChildren.push (x := s499) b499 <|
    PetersenLocalChildren.push (x := s500) b500 <|
    PetersenLocalChildren.push (x := s501) b501 <|
    PetersenLocalChildren.push (x := s502) b502 <|
    PetersenLocalChildren.push (x := s503) b503 <|
    PetersenLocalChildren.push (x := s504) b504 <|
    PetersenLocalChildren.push (x := s505) b505 <|
    PetersenLocalChildren.push (x := s506) b506 <|
    PetersenLocalChildren.push (x := s507) b507 <|
    PetersenLocalChildren.push (x := s508) b508 <|
    PetersenLocalChildren.push (x := s509) b509 <|
    PetersenLocalChildren.push (x := s510) b510 <|
    PetersenLocalChildren.push (x := s511) b511 <|
    PetersenLocalChildren.push (x := s512) b512 <|
    PetersenLocalChildren.push (x := s514) b514 <|
    PetersenLocalChildren.push (x := s515) b515 <|
    PetersenLocalChildren.push (x := s516) b516 <|
    PetersenLocalChildren.push (x := s480) b480 <|
    PetersenLocalChildren.push (x := s517) b517 <|
    PetersenLocalChildren.push (x := s518) b518 <|
    PetersenLocalChildren.push (x := s519) b519 <|
    PetersenLocalChildren.push (x := s520) b520 <|
    PetersenLocalChildren.push (x := s521) b521 <|
    PetersenLocalChildren.push (x := s522) b522 <|
    PetersenLocalChildren.push (x := s523) b523 <|
    PetersenLocalChildren.nil
theorem b721 : Blocked tgt 8 s721 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffcecececeffffffffcececece,0xffffceceffffceceffffceceffffcece),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s656) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b656
theorem b747 : Blocked tgt 8 s747 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xcececece00000000cececece,0xcece0000cece0000cece0000cece),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s683) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b683
theorem b817 : Blocked tgt 8 s817 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffcececececececece,0xffceffceffceffceffceffceffceffce)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s614) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b614
theorem b822 : Blocked tgt 8 s822 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xcececececececece,0xce00ce00ce00ce00ce00ce00ce00ce),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s619) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b619
theorem b872 : Blocked tgt 8 s872 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xfffffffff0f0f0f0fffffffff0f0f0f0,0xfffff0f0fffff0f0fffff0f0fffff0f0),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s862) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b862
theorem b882 : Blocked tgt 8 s882 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffffffffffffffff0f0f0f0f0f0f0f0,0xfff0fff0fff0fff0fff0fff0fff0fff0)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s855) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b855
theorem b912 : Blocked tgt 8 s912 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffffff0000ffff0000,0xffffffffff00ff00ffffffffff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s893) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b893
theorem b1073 : Blocked tgt 8 s1073 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s972) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b972
theorem b1081 : Blocked tgt 8 s1081 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s980) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b980
theorem b1138 : Blocked tgt 8 s1138 := by
  apply PetersenFastNode.node (nxt := #[s359,s989,s1139,s1140,s1141,s1142,s1143]) (hints := [5297,5553,9680,5553,5295,5553,0,4529,4529,5553,1,5553,6585,5553,11472,7473,5553,9681,1457,13649,9681,5553,1489,13617,5553,9680,908,9680,5937,5679,9680,8648,8656,9672,8648,6843,9680,9680,2,9680,7473,11472,9680,9680,13649,13520,9680,1424,1488,9616,1424,5679,5937,5679,5937,1548,3,1548,4,6843,5,6843,6,2700,11472,2700,11472,4748,13520,4748,13520,8844,13617,8844,13617,5041,5041,5937,6969,6969,5937,5937,6969,11472,4921,11472,5937,13520,1841,13520,10065,5937,1873,13617,5937,7481,7481,10440,10448,10440,11464,12488,12496,12488,13512,14649,13617,14649,13617,4779,11472,6827,11472,14681,13520,14681,13520,14649,13617,14649,13617,11472,3377,13520,11472,3216,3280,11408,3216,5264,5328,13456,5264]) (by decide +kernel)
  change ∀ b ∈ [s359,s989,s1139,s1140,s1141,s1142,s1143], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s359) b359 <|
    PetersenLocalChildren.push (x := s989) b989 <|
    PetersenLocalChildren.push (x := s1139) b1139 <|
    PetersenLocalChildren.push (x := s1140) b1140 <|
    PetersenLocalChildren.push (x := s1141) b1141 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s1143) b1143 <|
    PetersenLocalChildren.nil
theorem b1180 : Blocked tgt 8 s1180 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffcececececececece,0xffceffceffceffceffceffceffceffce)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1164) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1164
theorem b1378 : Blocked tgt 8 s1378 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff02020202ffffffff02020202,0xffff0202ffff0202ffff0202ffff0202),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1334) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1334
theorem b1421 : Blocked tgt 8 s1421 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,11,12,13,14,15,72,65,74,75,76,77,78,79,40,33,42,43,44,45,46,47,104,97,106,107,108,109,110,111,24,17,26,27,28,29,30,31,88,81,90,91,92,93,94,95,56,49,58,59,60,61,62,63,120,113,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0202020202020202,0xff02ff02ff02ff02ff02ff02ff02ff02)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1198) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1198
theorem b1506 : Blocked tgt 8 s1506 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0202020202020202,0xff02ff02ff02ff02ff02ff02ff02ff02)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1283) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1283
theorem b1584 : Blocked tgt 8 s1584 := by
  apply PetersenFastNode.node (nxt := #[s1585,s1586,s1587,s1588,s1589,s1590,s1591,s1592,s615,s1593,s1594,s1595,s1345,s1596,s1389,s1597,s1598,s1599,s1600,s1601,s1602,s1603,s1604,s1605,s1606,s1607,s1608,s1609,s1610,s1611,s1612,s1614]) (hints := [6868,9705,6868,5320,0,1,9705,9705,5704,9961,2,3,7250,4,7250,9705,9705,5,8681,9705,7250,8681,6,7,933,4,933,9705,9705,8,933,9705,933,9,10,11,2725,9705,2725,11497,12,11497,2725,13,2725,9705,9705,11497,4773,9705,4773,13545,14,13545,4773,15,4773,9705,9705,13545,8869,1449,8869,9641,9705,16,8869,9705,8869,1449,1449,17,5576,5576,5704,6868,6868,18,5704,6868,5704,5576,5576,19,6868,6868,7250,4552,5576,20,7250,5576,7250,6868,6868,21,6868,6868,6996,805,5576,933,6996,5576,6996,6868,6868,933,4804,4804,7240,11497,6868,11497,6852,6868,7240,11497,4804,11497,2740,2740,13416,13545,6868,13545,6836,6868,13416,13545,2740,13545,6868,6868,14932,8741,9704,8869,14932,9704,14932,6868,6868,8869,6994,6994,7250,4936,5704,22,7250,5704,7250,6994,6994,23,421,10864,24,421,5704,933,5704,5704,25,933,10864,933,11497,5704,11497,2725,6994,2725,11497,6994,11497,2725,5704,2725,13545,9832,13545,4773,5704,4773,13545,5704,13545,4773,9832,4773,5704,5704,13384,8869,9832,8869,13384,9832,13384,8869,5704,8869,933,7250,933,1701,26,27,10465,28,10465,11497,7250,11497,10465,7250,10465,11497,29,11497,12513,11378,12513,13545,7250,13545,12513,7250,12513,13545,11378,13545,8869,7250,8869,3186,11378,13384,8869,11378,8869,7250,7250,13384,10465,933,10465,11497,6996,11497,10465,6996,10465,11497,933,11497,12513,933,12513,13545,6996,13545,12513,6996,12513,13545,933,13545,933,933,8869,13384,30,13384,8869,31,8869,933,933,13384,11497,11497,13545,3144,7240,14706,13545,7240,13545,11497,11497,14706,3241,3241,8869,3305,11497,14932,11433,11497,8869,3241,3241,14932,5289,5289,8869,5353,13545,14932,13481,13545,8869,5289,5289,14932]) (by decide +kernel)
  change ∀ b ∈ [s1585,s1586,s1587,s1588,s1589,s1590,s1591,s1592,s615,s1593,s1594,s1595,s1345,s1596,s1389,s1597,s1598,s1599,s1600,s1601,s1602,s1603,s1604,s1605,s1606,s1607,s1608,s1609,s1610,s1611,s1612,s1614], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1585) b1585 <|
    PetersenLocalChildren.push (x := s1586) b1586 <|
    PetersenLocalChildren.push (x := s1587) b1587 <|
    PetersenLocalChildren.push (x := s1588) b1588 <|
    PetersenLocalChildren.push (x := s1589) b1589 <|
    PetersenLocalChildren.push (x := s1590) b1590 <|
    PetersenLocalChildren.push (x := s1591) b1591 <|
    PetersenLocalChildren.push (x := s1592) b1592 <|
    PetersenLocalChildren.push (x := s615) b615 <|
    PetersenLocalChildren.push (x := s1593) b1593 <|
    PetersenLocalChildren.push (x := s1594) b1594 <|
    PetersenLocalChildren.push (x := s1595) b1595 <|
    PetersenLocalChildren.push (x := s1345) b1345 <|
    PetersenLocalChildren.push (x := s1596) b1596 <|
    PetersenLocalChildren.push (x := s1389) b1389 <|
    PetersenLocalChildren.push (x := s1597) b1597 <|
    PetersenLocalChildren.push (x := s1598) b1598 <|
    PetersenLocalChildren.push (x := s1599) b1599 <|
    PetersenLocalChildren.push (x := s1600) b1600 <|
    PetersenLocalChildren.push (x := s1601) b1601 <|
    PetersenLocalChildren.push (x := s1602) b1602 <|
    PetersenLocalChildren.push (x := s1603) b1603 <|
    PetersenLocalChildren.push (x := s1604) b1604 <|
    PetersenLocalChildren.push (x := s1605) b1605 <|
    PetersenLocalChildren.push (x := s1606) b1606 <|
    PetersenLocalChildren.push (x := s1607) b1607 <|
    PetersenLocalChildren.push (x := s1608) b1608 <|
    PetersenLocalChildren.push (x := s1609) b1609 <|
    PetersenLocalChildren.push (x := s1610) b1610 <|
    PetersenLocalChildren.push (x := s1611) b1611 <|
    PetersenLocalChildren.push (x := s1612) b1612 <|
    PetersenLocalChildren.push (x := s1614) b1614 <|
    PetersenLocalChildren.nil
theorem b1686 : Blocked tgt 8 s1686 := by
  apply PetersenFastNode.node (nxt := #[s1309,s1687,s1522,s1688,s1689,s1321,s1690,s1691,s1612,s1692]) (hints := [5556,5298,911,9683,9939,9939,11612,0,11612,1,2703,11475,2703,11475,4751,13523,4751,13523,13620,2,13620,3,4,5,6,7,6846,783,6974,6846,5556,6846,5940,5556,6588,5556,11612,6588,5556,11475,7476,11475,9684,13523,13652,13523,5556,1492,13620,5556,6588,5556,5556,6588,399,399,911,5938,911,11356,11354,911,11475,4926,11475,911,13523,2878,13523,911,911,13364,13362,911,911,8,9,911,6972,5940,11612,6972,11475,2703,11475,2703,13523,4751,13523,4751,5940,1876,13620,5940,6972,5940,5940,6972,10443,10451,10443,11467,12491,12499,12491,13515,3420,11612,13620,1679,1679,11475,3380,13523,11475,3219,3283,11411,3219,2187,11475,11475,2187,5267,5331,13459,5267,4235,13523,13523,4235,8847,8847]) (by decide +kernel)
  change ∀ b ∈ [s1309,s1687,s1522,s1688,s1689,s1321,s1690,s1691,s1612,s1692], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1309) b1309 <|
    PetersenLocalChildren.push (x := s1687) b1687 <|
    PetersenLocalChildren.push (x := s1522) b1522 <|
    PetersenLocalChildren.push (x := s1688) b1688 <|
    PetersenLocalChildren.push (x := s1689) b1689 <|
    PetersenLocalChildren.push (x := s1321) b1321 <|
    PetersenLocalChildren.push (x := s1690) b1690 <|
    PetersenLocalChildren.push (x := s1691) b1691 <|
    PetersenLocalChildren.push (x := s1612) b1612 <|
    PetersenLocalChildren.push (x := s1692) b1692 <|
    PetersenLocalChildren.nil

theorem b2627 : Blocked tgt 8 s2627 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,33,38,35,96,97,98,99,100,97,102,99,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,49,54,51,112,113,114,115,116,113,118,115,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,41,46,43,104,105,106,107,108,105,110,107,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,57,62,59,120,121,122,123,124,121,126,123] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,17,22,19,80,81,82,83,84,81,86,83,48,49,50,51,52,49,54,51,112,113,114,115,116,113,118,115,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,25,30,27,88,89,90,91,92,89,94,91,56,57,58,59,60,57,62,59,120,121,122,123,124,121,126,123] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff0a0a0a0affffffff0a0a0a0a,0xffff0a0affff0a0affff0a0affff0a0a),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2599) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2599
theorem b2828 : Blocked tgt 8 s2828 := by
  apply PetersenFastNode.node (nxt := #[s1600,s2829,s2830,s2728,s2680,s2831]) (hints := [9807,9807,9935,9679,0,9679,9935,1,8903,9935,9935,8903,8903,9935,9935,8903,9935,11471,2187,9935,9935,13519,4235,9935,1679,9871,1743,1679,6842,9679,2,9679,5936,6064,7480,3,7480,6842,6842,4,5,6842,7472,11471,7472,11471,13648,13519,13648,13519,13616,8715,13616,6842,5678,9679,9679,5934,8655,9679,7480,9679,8647,9679,7216,11471,9679,9679,13392,13519,9679,1423,1487,9615,1423,6968,4912,7480,6968,10838,5936,5936,10838,5936,11471,7472,11471,10064,13519,13648,13519,5936,8843,13616,8843,1675,1675,10439,11471,10439,11471,12487,13519,12487,13519,8843,3416,8843,7480,10439,11471,10439,11471,12487,13519,12487,13519,8843,13616,8843,13616,11471,3376,13519,11471,3215,3279,11407,3215,5263,5327,13455,5263]) (by decide +kernel)
  change ∀ b ∈ [s1600,s2829,s2830,s2728,s2680,s2831], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1600) b1600 <|
    PetersenLocalChildren.push (x := s2829) b2829 <|
    PetersenLocalChildren.push (x := s2830) b2830 <|
    PetersenLocalChildren.push (x := s2728) b2728 <|
    PetersenLocalChildren.push (x := s2680) b2680 <|
    PetersenLocalChildren.push (x := s2831) b2831 <|
    PetersenLocalChildren.nil
theorem b2900 : Blocked tgt 8 s2900 := by
  apply PetersenFastNode.node (nxt := #[s2901,s2903,s2904,s2905,s2906,s2907,s941,s2908,s2909,s2910,s2911,s2914,s2915,s2916,s2917,s2918,s2920,s953,s2921,s2922,s2923,s2924,s2925,s2926,s2927,s2928,s2929,s2930,s2931,s2932,s2933,s2934,s2935,s2936,s2937,s2938,s2939,s2940,s2941,s2942,s2943,s2944,s2945,s2946,s2947]) (hints := [6881,6881,7009,818,0,946,7009,1,7009,6881,6881,946,9838,2,3,6881,6881,4,9966,5,9966,4567,6881,6,4567,5,7,7519,6881,7519,1586,8,1714,7519,9,7519,6881,6881,1714,7511,4817,7511,4833,6881,2738,7511,6881,7511,4817,4817,2738,13687,2753,13687,2785,6881,4786,13687,6881,13687,2753,2753,4786,13655,6881,13655,8754,10,8882,13655,11,13655,6881,6881,8882,8686,8686,9966,946,946,12,9966,946,9966,8686,8686,13,14,15,16,946,946,17,946,946,18,19,20,21,946,946,1714,8686,8686,7519,1714,8686,1714,946,946,7519,946,946,2738,4961,7009,7511,2738,7009,2738,946,946,7511,946,946,4786,2913,7009,13687,4786,7009,4786,946,946,13687,946,946,8882,494,8686,13655,8882,8686,8882,946,946,13655,9966,9966,6,5975,4,22,8942,23,7519,8942,9966,1714,9966,9966,7519,1714,24,1714,9966,9966,10478,2738,25,2738,10478,26,10478,9966,9966,2738,9966,9966,12526,4786,27,4786,12526,28,12526,9966,9966,4786,1710,1710,13655,1774,9966,8882,9902,9966,13655,1710,1710,8882,7519,29,7519,1714,30,1714,7519,31,7519,1714,32,1714,7511,33,7511,2738,34,2738,7511,35,7511,2738,36,2738,13687,37,13687,4786,38,4786,13687,39,13687,4786,40,4786,13655,41,13655,8882,42,8882,13655,43,13655,8882,44,8882,1714,1714,2738,10478,7519,10478,2738,7519,2738,1714,1714,10478,1714,1714,4786,12526,7519,12526,4786,7519,4786,1714,1714,12526,1714,1714,8882,3455,11647,13655,8882,11647,8882,1714,1714,13655,2738,2738,4786,3415,7511,14719,4786,7511,4786,2738,2738,14719,2738,2738,8882,2286,10478,14687,8882,10478,8882,2738,2738,14687,4786,4786,8882,4334,12526,13655,8882,12526,8882,4786,4786,13655]) (by decide +kernel)
  change ∀ b ∈ [s2901,s2903,s2904,s2905,s2906,s2907,s941,s2908,s2909,s2910,s2911,s2914,s2915,s2916,s2917,s2918,s2920,s953,s2921,s2922,s2923,s2924,s2925,s2926,s2927,s2928,s2929,s2930,s2931,s2932,s2933,s2934,s2935,s2936,s2937,s2938,s2939,s2940,s2941,s2942,s2943,s2944,s2945,s2946,s2947], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2901) b2901 <|
    PetersenLocalChildren.push (x := s2903) b2903 <|
    PetersenLocalChildren.push (x := s2904) b2904 <|
    PetersenLocalChildren.push (x := s2905) b2905 <|
    PetersenLocalChildren.push (x := s2906) b2906 <|
    PetersenLocalChildren.push (x := s2907) b2907 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s2908) b2908 <|
    PetersenLocalChildren.push (x := s2909) b2909 <|
    PetersenLocalChildren.push (x := s2910) b2910 <|
    PetersenLocalChildren.push (x := s2911) b2911 <|
    PetersenLocalChildren.push (x := s2914) b2914 <|
    PetersenLocalChildren.push (x := s2915) b2915 <|
    PetersenLocalChildren.push (x := s2916) b2916 <|
    PetersenLocalChildren.push (x := s2917) b2917 <|
    PetersenLocalChildren.push (x := s2918) b2918 <|
    PetersenLocalChildren.push (x := s2920) b2920 <|
    PetersenLocalChildren.push (x := s953) b953 <|
    PetersenLocalChildren.push (x := s2921) b2921 <|
    PetersenLocalChildren.push (x := s2922) b2922 <|
    PetersenLocalChildren.push (x := s2923) b2923 <|
    PetersenLocalChildren.push (x := s2924) b2924 <|
    PetersenLocalChildren.push (x := s2925) b2925 <|
    PetersenLocalChildren.push (x := s2926) b2926 <|
    PetersenLocalChildren.push (x := s2927) b2927 <|
    PetersenLocalChildren.push (x := s2928) b2928 <|
    PetersenLocalChildren.push (x := s2929) b2929 <|
    PetersenLocalChildren.push (x := s2930) b2930 <|
    PetersenLocalChildren.push (x := s2931) b2931 <|
    PetersenLocalChildren.push (x := s2932) b2932 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s2934) b2934 <|
    PetersenLocalChildren.push (x := s2935) b2935 <|
    PetersenLocalChildren.push (x := s2936) b2936 <|
    PetersenLocalChildren.push (x := s2937) b2937 <|
    PetersenLocalChildren.push (x := s2938) b2938 <|
    PetersenLocalChildren.push (x := s2939) b2939 <|
    PetersenLocalChildren.push (x := s2940) b2940 <|
    PetersenLocalChildren.push (x := s2941) b2941 <|
    PetersenLocalChildren.push (x := s2942) b2942 <|
    PetersenLocalChildren.push (x := s2943) b2943 <|
    PetersenLocalChildren.push (x := s2944) b2944 <|
    PetersenLocalChildren.push (x := s2945) b2945 <|
    PetersenLocalChildren.push (x := s2946) b2946 <|
    PetersenLocalChildren.push (x := s2947) b2947 <|
    PetersenLocalChildren.nil
theorem b2957 : Blocked tgt 8 s2957 := by
  apply PetersenFastNode.node (nxt := #[s2958,s2960,s2961,s2962,s2963,s2964,s2965,s2966,s991,s2967,s2968,s2971,s2972,s2973,s2974,s2975,s2976,s2977,s2980,s1003,s2981,s2982,s2983,s2984,s2985,s2986,s2987,s2988,s2989,s2990,s2991,s2992,s2993,s2994,s2995,s2996,s2997,s2998,s2999,s3000,s3001,s3002,s3003,s3004,s3005,s3006,s3007,s3008,s3009]) (hints := [6885,6885,7013,822,0,950,7013,1,7013,6885,6885,950,6373,2,3,6885,6885,4,8946,5,8946,7523,6885,7523,1590,6,1718,7523,7,7523,6885,6885,1718,6627,6885,8,6627,5,9,7515,4821,7515,4837,6885,2742,7515,6885,7515,4821,4821,2742,13691,2757,13691,2789,6885,4790,13691,6885,13691,2757,2757,4790,13659,6885,13659,8758,10,8886,13659,11,13659,6885,6885,8886,8690,8690,8946,438,950,12,8946,950,8946,8690,8690,13,950,950,1718,7267,14,7523,1718,15,1718,950,950,7523,16,17,18,950,950,19,950,950,20,21,22,23,950,950,2742,4965,7013,7515,2742,7013,2742,950,950,7515,950,950,4790,2917,7013,13691,4790,7013,4790,950,950,13691,950,950,8886,498,8690,13659,8886,8690,8886,950,950,13659,8946,8946,7523,1718,24,1718,9970,25,7523,8946,8946,1718,8946,8946,8,5979,4,26,8946,8946,10482,2230,27,2742,10482,28,10482,8946,8946,2742,8946,8946,12530,4278,29,4790,12530,30,12530,8946,8946,4790,13659,31,13659,8886,8946,8886,8882,8946,13659,8882,32,8886,7523,7523,33,1718,1718,34,1718,1718,35,7523,7523,36,1718,1718,2742,7515,7523,7515,2742,7523,2742,1718,1718,7515,1718,1718,4790,3427,7523,13691,4790,7523,4790,1718,1718,13691,1718,1718,8886,3459,11651,13659,8886,11651,8886,1718,1718,13659,7515,37,7515,2742,38,2742,7515,39,7515,2742,40,2742,13691,41,13691,4790,42,4790,13691,43,13691,4790,44,4790,13659,45,13659,8886,46,8886,13659,47,13659,8886,48,8886,2742,2742,4790,3419,7515,14723,4790,7515,4790,2742,2742,14723,2742,2742,8886,2290,10482,14691,8886,10482,8886,2742,2742,14691,4790,4790,8886,4338,12530,13659,8886,12530,8886,4790,4790,13659]) (by decide +kernel)
  change ∀ b ∈ [s2958,s2960,s2961,s2962,s2963,s2964,s2965,s2966,s991,s2967,s2968,s2971,s2972,s2973,s2974,s2975,s2976,s2977,s2980,s1003,s2981,s2982,s2983,s2984,s2985,s2986,s2987,s2988,s2989,s2990,s2991,s2992,s2993,s2994,s2995,s2996,s2997,s2998,s2999,s3000,s3001,s3002,s3003,s3004,s3005,s3006,s3007,s3008,s3009], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2958) b2958 <|
    PetersenLocalChildren.push (x := s2960) b2960 <|
    PetersenLocalChildren.push (x := s2961) b2961 <|
    PetersenLocalChildren.push (x := s2962) b2962 <|
    PetersenLocalChildren.push (x := s2963) b2963 <|
    PetersenLocalChildren.push (x := s2964) b2964 <|
    PetersenLocalChildren.push (x := s2965) b2965 <|
    PetersenLocalChildren.push (x := s2966) b2966 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s2967) b2967 <|
    PetersenLocalChildren.push (x := s2968) b2968 <|
    PetersenLocalChildren.push (x := s2971) b2971 <|
    PetersenLocalChildren.push (x := s2972) b2972 <|
    PetersenLocalChildren.push (x := s2973) b2973 <|
    PetersenLocalChildren.push (x := s2974) b2974 <|
    PetersenLocalChildren.push (x := s2975) b2975 <|
    PetersenLocalChildren.push (x := s2976) b2976 <|
    PetersenLocalChildren.push (x := s2977) b2977 <|
    PetersenLocalChildren.push (x := s2980) b2980 <|
    PetersenLocalChildren.push (x := s1003) b1003 <|
    PetersenLocalChildren.push (x := s2981) b2981 <|
    PetersenLocalChildren.push (x := s2982) b2982 <|
    PetersenLocalChildren.push (x := s2983) b2983 <|
    PetersenLocalChildren.push (x := s2984) b2984 <|
    PetersenLocalChildren.push (x := s2985) b2985 <|
    PetersenLocalChildren.push (x := s2986) b2986 <|
    PetersenLocalChildren.push (x := s2987) b2987 <|
    PetersenLocalChildren.push (x := s2988) b2988 <|
    PetersenLocalChildren.push (x := s2989) b2989 <|
    PetersenLocalChildren.push (x := s2990) b2990 <|
    PetersenLocalChildren.push (x := s2991) b2991 <|
    PetersenLocalChildren.push (x := s2992) b2992 <|
    PetersenLocalChildren.push (x := s2993) b2993 <|
    PetersenLocalChildren.push (x := s2994) b2994 <|
    PetersenLocalChildren.push (x := s2995) b2995 <|
    PetersenLocalChildren.push (x := s2996) b2996 <|
    PetersenLocalChildren.push (x := s2997) b2997 <|
    PetersenLocalChildren.push (x := s2998) b2998 <|
    PetersenLocalChildren.push (x := s2999) b2999 <|
    PetersenLocalChildren.push (x := s3000) b3000 <|
    PetersenLocalChildren.push (x := s3001) b3001 <|
    PetersenLocalChildren.push (x := s3002) b3002 <|
    PetersenLocalChildren.push (x := s3003) b3003 <|
    PetersenLocalChildren.push (x := s3004) b3004 <|
    PetersenLocalChildren.push (x := s3005) b3005 <|
    PetersenLocalChildren.push (x := s3006) b3006 <|
    PetersenLocalChildren.push (x := s3007) b3007 <|
    PetersenLocalChildren.push (x := s3008) b3008 <|
    PetersenLocalChildren.push (x := s3009) b3009 <|
    PetersenLocalChildren.nil
theorem b3023 : Blocked tgt 8 s3023 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff0a0a0a0affffffff0a0a0a0a,0xffff0a0affff0a0affff0a0affff0a0a),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3013) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3013
theorem b3081 : Blocked tgt 8 s3081 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2948) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2948
theorem b3226 : Blocked tgt 8 s3226 := by
  apply PetersenFastNode.node (nxt := #[s3227,s3228,s3229,s3230,s941,s938,s2901,s3231,s3232,s3233,s3234,s3235,s3236,s3237,s3238,s3239,s3240,s3241,s953,s954,s3242,s3243,s3244,s3245,s3246,s3247,s3248,s3249,s3250,s3251,s3252,s3253,s3254,s3255,s3256,s3259,s3260]) (hints := [810,0,1,4559,4559,2,938,3,938,4559,4559,4,6873,3,5,4559,4559,5967,9958,6,9958,5967,7,5967,4559,4559,9958,7511,8,7511,4559,4559,1706,6615,4559,7511,6615,9,1706,4559,4559,7503,2730,10,2730,6607,11,7503,4559,4559,2730,8687,8687,13679,463,4559,4778,12783,4559,13679,8687,8687,4778,4559,4559,13647,495,8687,8874,12751,8687,13647,4559,4559,8874,938,938,4,7001,2,12,8678,8678,9958,938,938,5967,9958,938,9958,8678,8678,5967,938,938,1706,8678,8678,7511,1706,8678,1706,938,938,7511,938,938,2730,7503,13,7503,2730,14,2730,938,938,7503,938,938,4778,13679,15,13679,4778,16,4778,938,938,13679,938,938,8874,486,8678,13647,8874,8678,8874,938,938,13647,5709,17,5709,9958,18,9958,5709,19,5709,9958,20,9958,7769,21,7769,1706,22,1706,7769,23,7769,1706,24,1706,7245,25,7245,2730,26,2730,7245,27,7245,2730,28,2730,13421,29,13421,4778,30,4778,13421,31,13421,4778,32,4778,14937,33,14937,8874,34,8874,14937,35,14937,8874,36,8874,8934,6999,7511,8934,9958,1706,9958,9958,7511,1706,6999,1706,9958,9958,10470,2730,6999,2730,10470,6999,10470,9958,9958,2730,9958,9958,12518,4778,5967,4778,12518,5967,12518,9958,9958,4778,1702,1702,13647,1766,9958,8874,9894,9958,13647,1702,1702,8874,1706,1706,2730,10470,7511,10470,2730,7511,2730,1706,1706,10470,1706,1706,4778,12518,7511,12518,4778,7511,4778,1706,1706,12518,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,2730,2730,4778,3407,7503,14711,4778,7503,4778,2730,2730,14711,2730,2730,8874,2278,10470,14679,8874,10470,8874,2730,2730,14679,4778,4778,8874,4326,12518,13647,8874,12518,8874,4778,4778,13647]) (by decide +kernel)
  change ∀ b ∈ [s3227,s3228,s3229,s3230,s941,s938,s2901,s3231,s3232,s3233,s3234,s3235,s3236,s3237,s3238,s3239,s3240,s3241,s953,s954,s3242,s3243,s3244,s3245,s3246,s3247,s3248,s3249,s3250,s3251,s3252,s3253,s3254,s3255,s3256,s3259,s3260], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3227) b3227 <|
    PetersenLocalChildren.push (x := s3228) b3228 <|
    PetersenLocalChildren.push (x := s3229) b3229 <|
    PetersenLocalChildren.push (x := s3230) b3230 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s938) b938 <|
    PetersenLocalChildren.push (x := s2901) b2901 <|
    PetersenLocalChildren.push (x := s3231) b3231 <|
    PetersenLocalChildren.push (x := s3232) b3232 <|
    PetersenLocalChildren.push (x := s3233) b3233 <|
    PetersenLocalChildren.push (x := s3234) b3234 <|
    PetersenLocalChildren.push (x := s3235) b3235 <|
    PetersenLocalChildren.push (x := s3236) b3236 <|
    PetersenLocalChildren.push (x := s3237) b3237 <|
    PetersenLocalChildren.push (x := s3238) b3238 <|
    PetersenLocalChildren.push (x := s3239) b3239 <|
    PetersenLocalChildren.push (x := s3240) b3240 <|
    PetersenLocalChildren.push (x := s3241) b3241 <|
    PetersenLocalChildren.push (x := s953) b953 <|
    PetersenLocalChildren.push (x := s954) b954 <|
    PetersenLocalChildren.push (x := s3242) b3242 <|
    PetersenLocalChildren.push (x := s3243) b3243 <|
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s3245) b3245 <|
    PetersenLocalChildren.push (x := s3246) b3246 <|
    PetersenLocalChildren.push (x := s3247) b3247 <|
    PetersenLocalChildren.push (x := s3248) b3248 <|
    PetersenLocalChildren.push (x := s3249) b3249 <|
    PetersenLocalChildren.push (x := s3250) b3250 <|
    PetersenLocalChildren.push (x := s3251) b3251 <|
    PetersenLocalChildren.push (x := s3252) b3252 <|
    PetersenLocalChildren.push (x := s3253) b3253 <|
    PetersenLocalChildren.push (x := s3254) b3254 <|
    PetersenLocalChildren.push (x := s3255) b3255 <|
    PetersenLocalChildren.push (x := s3256) b3256 <|
    PetersenLocalChildren.push (x := s3259) b3259 <|
    PetersenLocalChildren.push (x := s3260) b3260 <|
    PetersenLocalChildren.nil
theorem b3354 : Blocked tgt 8 s3354 := by
  apply PetersenFastNode.node (nxt := #[s3234,s3355,s3356,s3300,s3318,s3357,s3358,s3359,s3360,s3361,s941,s3362,s3363,s3365,s3366,s3367,s3368,s3248,s3369,s3370,s3371,s2937,s3280,s3372,s3373,s3338,s3374,s3375,s3376,s3377,s3378,s3379,s3380,s3381,s3382,s3383,s3384,s3385,s3386]) (hints := [6875,6875,7003,940,0,940,7003,1,7003,6875,6875,940,5969,2,5969,9960,6875,9960,5969,6875,5969,7129,3,9960,7513,6875,7513,1708,4,1708,6617,5,7513,6617,6875,1708,4827,6,7,6875,6875,8,2732,9,2732,4561,6875,10,4561,9,11,13681,2747,13681,2779,6875,4780,13681,6875,13681,2747,2747,4780,13649,6875,13649,8876,12,8876,13649,13,13649,6875,6875,8876,8680,8680,9960,940,940,5969,9960,940,9960,8680,8680,5969,940,940,1708,8680,8680,7513,1708,8680,1708,940,940,7513,940,940,2732,7003,7003,14,2732,7003,2732,940,940,15,4939,4939,16,940,940,17,940,940,18,4939,4939,19,940,940,4780,2907,7003,13681,4780,7003,4780,940,940,13681,940,940,8876,488,8680,13649,8876,8680,8876,940,940,13649,8936,7001,7513,8936,9960,1708,9960,9960,7513,1708,7001,1708,9960,9960,10472,2732,7001,2732,10472,7001,10472,9960,9960,2732,5969,5969,20,9960,9960,21,9960,9960,22,5969,5969,23,9960,9960,12520,4780,5969,4780,12520,5969,12520,9960,9960,4780,1704,1704,13649,1768,9960,8876,9896,9960,13649,1704,1704,8876,1708,1708,2732,10472,7513,10472,2732,7513,2732,1708,1708,10472,5707,5707,24,1708,1708,25,1708,1708,26,5707,5707,27,1708,1708,4780,12520,7513,12520,4780,7513,4780,1708,1708,12520,1708,1708,8876,3449,11641,13649,8876,11641,8876,1708,1708,13649,2732,2732,10,7505,8,28,2732,2732,4780,14713,29,14713,4780,30,4780,2732,2732,14713,2732,2732,8876,2280,10472,14681,8876,10472,8876,2732,2732,14681,13681,31,13681,4780,32,4780,13681,33,13681,4780,34,4780,13649,35,13649,8876,36,8876,13649,37,13649,8876,38,8876,4780,4780,8876,4328,12520,13649,8876,12520,8876,4780,4780,13649]) (by decide +kernel)
  change ∀ b ∈ [s3234,s3355,s3356,s3300,s3318,s3357,s3358,s3359,s3360,s3361,s941,s3362,s3363,s3365,s3366,s3367,s3368,s3248,s3369,s3370,s3371,s2937,s3280,s3372,s3373,s3338,s3374,s3375,s3376,s3377,s3378,s3379,s3380,s3381,s3382,s3383,s3384,s3385,s3386], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3234) b3234 <|
    PetersenLocalChildren.push (x := s3355) b3355 <|
    PetersenLocalChildren.push (x := s3356) b3356 <|
    PetersenLocalChildren.push (x := s3300) b3300 <|
    PetersenLocalChildren.push (x := s3318) b3318 <|
    PetersenLocalChildren.push (x := s3357) b3357 <|
    PetersenLocalChildren.push (x := s3358) b3358 <|
    PetersenLocalChildren.push (x := s3359) b3359 <|
    PetersenLocalChildren.push (x := s3360) b3360 <|
    PetersenLocalChildren.push (x := s3361) b3361 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3362) b3362 <|
    PetersenLocalChildren.push (x := s3363) b3363 <|
    PetersenLocalChildren.push (x := s3365) b3365 <|
    PetersenLocalChildren.push (x := s3366) b3366 <|
    PetersenLocalChildren.push (x := s3367) b3367 <|
    PetersenLocalChildren.push (x := s3368) b3368 <|
    PetersenLocalChildren.push (x := s3248) b3248 <|
    PetersenLocalChildren.push (x := s3369) b3369 <|
    PetersenLocalChildren.push (x := s3370) b3370 <|
    PetersenLocalChildren.push (x := s3371) b3371 <|
    PetersenLocalChildren.push (x := s2937) b2937 <|
    PetersenLocalChildren.push (x := s3280) b3280 <|
    PetersenLocalChildren.push (x := s3372) b3372 <|
    PetersenLocalChildren.push (x := s3373) b3373 <|
    PetersenLocalChildren.push (x := s3338) b3338 <|
    PetersenLocalChildren.push (x := s3374) b3374 <|
    PetersenLocalChildren.push (x := s3375) b3375 <|
    PetersenLocalChildren.push (x := s3376) b3376 <|
    PetersenLocalChildren.push (x := s3377) b3377 <|
    PetersenLocalChildren.push (x := s3378) b3378 <|
    PetersenLocalChildren.push (x := s3379) b3379 <|
    PetersenLocalChildren.push (x := s3380) b3380 <|
    PetersenLocalChildren.push (x := s3381) b3381 <|
    PetersenLocalChildren.push (x := s3382) b3382 <|
    PetersenLocalChildren.push (x := s3383) b3383 <|
    PetersenLocalChildren.push (x := s3384) b3384 <|
    PetersenLocalChildren.push (x := s3385) b3385 <|
    PetersenLocalChildren.push (x := s3386) b3386 <|
    PetersenLocalChildren.nil
theorem b3421 : Blocked tgt 8 s3421 := by
  apply PetersenFastNode.node (nxt := #[s3422,s3423,s2911,s3424,s3425,s3426,s3363,s3427,s3396,s3428,s3429,s3430,s3431,s3432,s941,s3433,s3434,s3438,s3439,s3256,s3440,s3441,s3442,s3443,s3444,s2945,s3294,s3445,s3446,s3449,s3450,s3348,s3451,s3452,s3453,s3454,s3455,s3384,s3456,s3457,s3458,s3459,s3460,s3461,s3462,s3415,s3463,s3464,s3465,s3466,s3467]) (hints := [7015,0,7015,952,8701,952,7015,8701,7015,952,1,952,5981,8701,5981,9844,2,9972,5981,3,5981,8701,8701,9972,7525,4,7525,8701,8701,1720,7525,8701,7525,10757,5,1720,7517,8701,7517,2744,6,2744,7517,7,7517,8701,8701,2744,8701,8701,13693,4792,8,4792,12797,9,13693,8701,8701,4792,509,10,11,8701,8701,12,8888,13,8888,4573,8701,14,4573,13,15,8692,8692,9972,952,952,5981,9972,952,9972,8692,8692,5981,952,952,1720,8692,8692,7525,1720,8692,1720,952,952,7525,952,952,2744,4967,7015,7517,2744,7015,2744,952,952,7517,952,952,4792,2919,7015,13693,4792,7015,4792,952,952,13693,952,952,8888,500,8692,16,8888,8692,8888,952,952,17,7015,7015,18,952,952,19,952,952,20,7015,7015,21,8948,7013,7525,8948,9972,1720,9972,9972,7525,1720,7013,1720,9972,9972,10484,2744,7013,2744,10484,7013,10484,9972,9972,2744,9972,9972,12532,4792,5981,4792,12532,5981,12532,9972,9972,4792,1716,1716,22,1780,9972,8888,9908,9972,23,1716,1716,8888,5981,5981,24,9972,9972,25,9972,9972,26,5981,5981,27,1720,1720,2744,10484,7525,10484,2744,7525,2744,1720,1720,10484,1720,1720,4792,12532,7525,12532,4792,7525,4792,1720,1720,12532,1720,1720,8888,11653,11653,28,8888,11653,8888,1720,1720,29,7525,7525,30,1720,1720,31,1720,1720,32,7525,7525,33,2744,2744,4792,3421,7517,14725,4792,7517,4792,2744,2744,14725,2744,2744,8888,2292,10484,34,8888,10484,8888,2744,2744,35,7517,7517,36,2744,2744,37,2744,2744,38,7517,7517,39,4792,4792,8888,4340,12532,40,8888,12532,8888,4792,4792,41,42,43,44,4792,4792,45,4792,4792,46,47,48,49,8888,8888,14,13661,12,50]) (by decide +kernel)
  change ∀ b ∈ [s3422,s3423,s2911,s3424,s3425,s3426,s3363,s3427,s3396,s3428,s3429,s3430,s3431,s3432,s941,s3433,s3434,s3438,s3439,s3256,s3440,s3441,s3442,s3443,s3444,s2945,s3294,s3445,s3446,s3449,s3450,s3348,s3451,s3452,s3453,s3454,s3455,s3384,s3456,s3457,s3458,s3459,s3460,s3461,s3462,s3415,s3463,s3464,s3465,s3466,s3467], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3422) b3422 <|
    PetersenLocalChildren.push (x := s3423) b3423 <|
    PetersenLocalChildren.push (x := s2911) b2911 <|
    PetersenLocalChildren.push (x := s3424) b3424 <|
    PetersenLocalChildren.push (x := s3425) b3425 <|
    PetersenLocalChildren.push (x := s3426) b3426 <|
    PetersenLocalChildren.push (x := s3363) b3363 <|
    PetersenLocalChildren.push (x := s3427) b3427 <|
    PetersenLocalChildren.push (x := s3396) b3396 <|
    PetersenLocalChildren.push (x := s3428) b3428 <|
    PetersenLocalChildren.push (x := s3429) b3429 <|
    PetersenLocalChildren.push (x := s3430) b3430 <|
    PetersenLocalChildren.push (x := s3431) b3431 <|
    PetersenLocalChildren.push (x := s3432) b3432 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3433) b3433 <|
    PetersenLocalChildren.push (x := s3434) b3434 <|
    PetersenLocalChildren.push (x := s3438) b3438 <|
    PetersenLocalChildren.push (x := s3439) b3439 <|
    PetersenLocalChildren.push (x := s3256) b3256 <|
    PetersenLocalChildren.push (x := s3440) b3440 <|
    PetersenLocalChildren.push (x := s3441) b3441 <|
    PetersenLocalChildren.push (x := s3442) b3442 <|
    PetersenLocalChildren.push (x := s3443) b3443 <|
    PetersenLocalChildren.push (x := s3444) b3444 <|
    PetersenLocalChildren.push (x := s2945) b2945 <|
    PetersenLocalChildren.push (x := s3294) b3294 <|
    PetersenLocalChildren.push (x := s3445) b3445 <|
    PetersenLocalChildren.push (x := s3446) b3446 <|
    PetersenLocalChildren.push (x := s3449) b3449 <|
    PetersenLocalChildren.push (x := s3450) b3450 <|
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s3451) b3451 <|
    PetersenLocalChildren.push (x := s3452) b3452 <|
    PetersenLocalChildren.push (x := s3453) b3453 <|
    PetersenLocalChildren.push (x := s3454) b3454 <|
    PetersenLocalChildren.push (x := s3455) b3455 <|
    PetersenLocalChildren.push (x := s3384) b3384 <|
    PetersenLocalChildren.push (x := s3456) b3456 <|
    PetersenLocalChildren.push (x := s3457) b3457 <|
    PetersenLocalChildren.push (x := s3458) b3458 <|
    PetersenLocalChildren.push (x := s3459) b3459 <|
    PetersenLocalChildren.push (x := s3460) b3460 <|
    PetersenLocalChildren.push (x := s3461) b3461 <|
    PetersenLocalChildren.push (x := s3462) b3462 <|
    PetersenLocalChildren.push (x := s3415) b3415 <|
    PetersenLocalChildren.push (x := s3463) b3463 <|
    PetersenLocalChildren.push (x := s3464) b3464 <|
    PetersenLocalChildren.push (x := s3465) b3465 <|
    PetersenLocalChildren.push (x := s3466) b3466 <|
    PetersenLocalChildren.push (x := s3467) b3467 <|
    PetersenLocalChildren.nil
theorem b3471 : Blocked tgt 8 s3471 := by
  apply PetersenFastNode.node (nxt := #[s2915,s3302,s3472,s953,s943,s3473,s3474,s3475,s3476,s3477,s941,s955,s3478,s3479,s3480,s3482,s3483,s3484,s3485,s3486,s3487,s3488,s3489,s3490,s3491,s3492,s3493,s3494,s3495,s3496,s3497,s3498,s3499]) (hints := [6869,6869,6997,806,4555,934,6997,4555,6997,6869,6869,934,4555,4555,5963,6869,6869,0,5963,6869,5963,4555,4555,1,4297,4297,2,4555,4555,3,4555,4555,4,4297,4297,5,7507,6869,7507,4555,4555,1702,6611,4555,7507,6611,6869,1702,4555,4555,7499,4821,6869,2726,6603,6869,7499,4555,4555,2726,8683,8683,13675,459,4555,4774,12779,4555,13675,8683,8683,4774,4555,4555,13643,491,8683,8870,12747,8683,13643,4555,4555,8870,5707,6,7,934,934,8,5963,9,5963,934,934,10,8674,9,11,934,934,1702,7507,12,7507,1702,13,1702,934,934,7507,934,934,2726,4949,6997,7499,2726,6997,2726,934,934,7499,934,934,4774,2901,6997,13675,4774,6997,4774,934,934,13675,934,934,8870,13643,14,13643,8870,15,8870,934,934,13643,9954,5963,10,9954,8,16,6995,6995,7507,1702,5963,1702,7507,5963,7507,1702,6995,1702,10466,5963,10466,2726,6995,2726,10466,6995,10466,2726,5963,2726,12514,10091,12514,4774,5963,4774,12514,5963,12514,4774,10091,4774,5963,5963,13643,8870,10091,8870,13643,10091,13643,8870,5963,8870,7249,17,7249,1702,18,1702,7249,19,7249,1702,20,1702,10466,21,10466,2726,22,2726,10466,23,10466,2726,24,2726,12514,25,12514,4774,26,4774,12514,27,12514,4774,28,4774,13385,29,13385,8870,30,8870,13385,31,13385,8870,32,8870,1702,1702,2726,10466,7507,10466,2726,7507,2726,1702,1702,10466,1702,1702,4774,12514,7507,12514,4774,7507,4774,1702,1702,12514,1702,1702,8870,3443,11635,13643,8870,11635,8870,1702,1702,13643,2726,2726,4774,3403,7499,14707,4774,7499,4774,2726,2726,14707,2726,2726,8870,2274,10466,14675,8870,10466,8870,2726,2726,14675,4774,4774,8870,4322,12514,13643,8870,12514,8870,4774,4774,13643]) (by decide +kernel)
  change ∀ b ∈ [s2915,s3302,s3472,s953,s943,s3473,s3474,s3475,s3476,s3477,s941,s955,s3478,s3479,s3480,s3482,s3483,s3484,s3485,s3486,s3487,s3488,s3489,s3490,s3491,s3492,s3493,s3494,s3495,s3496,s3497,s3498,s3499], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2915) b2915 <|
    PetersenLocalChildren.push (x := s3302) b3302 <|
    PetersenLocalChildren.push (x := s3472) b3472 <|
    PetersenLocalChildren.push (x := s953) b953 <|
    PetersenLocalChildren.push (x := s943) b943 <|
    PetersenLocalChildren.push (x := s3473) b3473 <|
    PetersenLocalChildren.push (x := s3474) b3474 <|
    PetersenLocalChildren.push (x := s3475) b3475 <|
    PetersenLocalChildren.push (x := s3476) b3476 <|
    PetersenLocalChildren.push (x := s3477) b3477 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s955) b955 <|
    PetersenLocalChildren.push (x := s3478) b3478 <|
    PetersenLocalChildren.push (x := s3479) b3479 <|
    PetersenLocalChildren.push (x := s3480) b3480 <|
    PetersenLocalChildren.push (x := s3482) b3482 <|
    PetersenLocalChildren.push (x := s3483) b3483 <|
    PetersenLocalChildren.push (x := s3484) b3484 <|
    PetersenLocalChildren.push (x := s3485) b3485 <|
    PetersenLocalChildren.push (x := s3486) b3486 <|
    PetersenLocalChildren.push (x := s3487) b3487 <|
    PetersenLocalChildren.push (x := s3488) b3488 <|
    PetersenLocalChildren.push (x := s3489) b3489 <|
    PetersenLocalChildren.push (x := s3490) b3490 <|
    PetersenLocalChildren.push (x := s3491) b3491 <|
    PetersenLocalChildren.push (x := s3492) b3492 <|
    PetersenLocalChildren.push (x := s3493) b3493 <|
    PetersenLocalChildren.push (x := s3494) b3494 <|
    PetersenLocalChildren.push (x := s3495) b3495 <|
    PetersenLocalChildren.push (x := s3496) b3496 <|
    PetersenLocalChildren.push (x := s3497) b3497 <|
    PetersenLocalChildren.push (x := s3498) b3498 <|
    PetersenLocalChildren.push (x := s3499) b3499 <|
    PetersenLocalChildren.nil
theorem b3501 : Blocked tgt 8 s3501 := by
  apply PetersenFastNode.node (nxt := #[s937,s3502,s3242,s935,s941,s3503,s3477,s952,s3504,s3505,s3506,s3507,s3508,s3509,s3510,s3511,s3512,s3513,s3514,s3515,s3516,s3517,s3518,s3519,s3520,s3521,s3522,s2916,s3303,s3523,s3524,s3525,s3526,s3527,s3528,s3529,s3531]) (hints := [4559,0,4559,6873,1,6873,4559,2,4559,6873,3,6873,938,4,8678,938,5,6,9958,4,5967,9958,7,8,7511,9,7511,1706,10,1706,7511,11,7511,1706,12,1706,10470,13,10470,2730,14,2730,10470,15,10470,2730,16,2730,12518,17,12518,4778,18,4778,12518,19,12518,4778,20,4778,13647,21,13647,8874,22,8874,13647,23,13647,8874,24,8874,6873,6873,25,4303,4559,8678,4557,4559,26,6873,6873,8678,4559,4559,5967,6873,6873,27,6873,6873,5967,4559,4559,28,6873,6873,7769,1578,4559,1706,7769,4559,7769,6873,6873,1706,4809,4809,7503,4825,6873,2730,6857,6873,7503,4809,4809,2730,2745,2745,13679,2777,6873,4778,6841,6873,13679,2745,2745,4778,6873,6873,14937,8746,8687,8874,14937,8687,14937,6873,6873,8874,8678,8678,8,5967,6,5967,10214,29,30,1706,31,1706,8678,8678,7511,1706,8678,1706,7509,32,7511,2730,8678,2730,7247,33,7503,2730,34,2730,8678,8678,7503,4778,8678,4778,13423,35,13679,4778,36,4778,8678,8678,13679,8874,422,8874,486,8678,13647,8874,8678,8874,422,422,13647,6999,6999,7511,1706,5967,1706,7511,5967,7511,1706,6999,1706,10470,5967,10470,2730,6999,2730,10470,6999,10470,2730,5967,2730,12518,10095,12518,4778,5967,4778,12518,5967,12518,4778,10095,4778,5967,5967,13647,8874,10095,8874,13647,10095,13647,8874,5967,8874,1706,1706,2730,5721,7769,10470,2730,7769,2730,1706,1706,10470,1706,1706,4778,3673,7769,12518,4778,7769,4778,1706,1706,12518,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,2730,2730,4778,3407,7503,14711,4778,7503,4778,2730,2730,14711,2730,2730,8874,12889,10470,14937,8874,10470,8874,2730,2730,14937,4778,4778,8874,10841,12518,14937,8874,12518,8874,4778,4778,14937]) (by decide +kernel)
  change ∀ b ∈ [s937,s3502,s3242,s935,s941,s3503,s3477,s952,s3504,s3505,s3506,s3507,s3508,s3509,s3510,s3511,s3512,s3513,s3514,s3515,s3516,s3517,s3518,s3519,s3520,s3521,s3522,s2916,s3303,s3523,s3524,s3525,s3526,s3527,s3528,s3529,s3531], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s937) b937 <|
    PetersenLocalChildren.push (x := s3502) b3502 <|
    PetersenLocalChildren.push (x := s3242) b3242 <|
    PetersenLocalChildren.push (x := s935) b935 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3503) b3503 <|
    PetersenLocalChildren.push (x := s3477) b3477 <|
    PetersenLocalChildren.push (x := s952) b952 <|
    PetersenLocalChildren.push (x := s3504) b3504 <|
    PetersenLocalChildren.push (x := s3505) b3505 <|
    PetersenLocalChildren.push (x := s3506) b3506 <|
    PetersenLocalChildren.push (x := s3507) b3507 <|
    PetersenLocalChildren.push (x := s3508) b3508 <|
    PetersenLocalChildren.push (x := s3509) b3509 <|
    PetersenLocalChildren.push (x := s3510) b3510 <|
    PetersenLocalChildren.push (x := s3511) b3511 <|
    PetersenLocalChildren.push (x := s3512) b3512 <|
    PetersenLocalChildren.push (x := s3513) b3513 <|
    PetersenLocalChildren.push (x := s3514) b3514 <|
    PetersenLocalChildren.push (x := s3515) b3515 <|
    PetersenLocalChildren.push (x := s3516) b3516 <|
    PetersenLocalChildren.push (x := s3517) b3517 <|
    PetersenLocalChildren.push (x := s3518) b3518 <|
    PetersenLocalChildren.push (x := s3519) b3519 <|
    PetersenLocalChildren.push (x := s3520) b3520 <|
    PetersenLocalChildren.push (x := s3521) b3521 <|
    PetersenLocalChildren.push (x := s3522) b3522 <|
    PetersenLocalChildren.push (x := s2916) b2916 <|
    PetersenLocalChildren.push (x := s3303) b3303 <|
    PetersenLocalChildren.push (x := s3523) b3523 <|
    PetersenLocalChildren.push (x := s3524) b3524 <|
    PetersenLocalChildren.push (x := s3525) b3525 <|
    PetersenLocalChildren.push (x := s3526) b3526 <|
    PetersenLocalChildren.push (x := s3527) b3527 <|
    PetersenLocalChildren.push (x := s3528) b3528 <|
    PetersenLocalChildren.push (x := s3529) b3529 <|
    PetersenLocalChildren.push (x := s3531) b3531 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
