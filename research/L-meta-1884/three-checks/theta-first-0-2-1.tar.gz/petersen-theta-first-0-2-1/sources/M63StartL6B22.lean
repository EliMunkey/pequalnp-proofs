import M63StartData
import M63StartPins0
import M63StartL5B20
import M63StartL5B19
import M63StartL5B1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b711 : Blocked tgt 6 s711 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s711 6 _ le
  decide +kernel
theorem b712 : Blocked tgt 6 s712 := by
  apply PetersenFastNode.node (nxt := #[s699,s713,s714]) (hints := [3447,2669,3447,2795,716,2861,204,204,716,3765,456,196,1352,3629,1352,716,2376,0,2376,716,2797,780,2859,2797,3317,2285,3765,3317,3447,2797,2797,3447,2797,2293,3757,2797,717,749,2765,717,3765,460,3765,1,2,844,844,452,3757,1096,3757,844,844,2120,2636,844,3765,840,1352,3757,3749,3749,1685,1717,3733,1685,456,3757,1352,3757,456,2636,2376,456,1677,1709,3725,1677]) (by decide +kernel)
  change ∀ b ∈ [s699,s713,s714], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s699) b699 <|
    PetersenLocalChildren.push (x := s713) b713 <|
    PetersenLocalChildren.push (x := s714) b714 <|
    PetersenLocalChildren.nil
theorem b715 : Blocked tgt 6 s715 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s715 6 _ le
  decide +kernel
theorem b716 : Blocked tgt 6 s716 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s716 6 _ le
  decide +kernel
theorem b717 : Blocked tgt 6 s717 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s717 6 _ le
  decide +kernel
theorem b718 : Blocked tgt 6 s718 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s718 6 _ le
  decide +kernel
theorem b719 : Blocked tgt 6 s719 := by
  apply PetersenFastNode.node (nxt := #[s661,s713]) (hints := [843,0,843,2988,2666,2796,2666,2796,715,715,835,4020,835,3508,1611,3756,1611,3756,2635,3476,2635,1428,3316,2796,3316,2796,843,971,451,843,3764,3764,843,3756,1091,3756,843,2635,2115,843,2666,2796,2796,2666,3316,2796,2796,3316,2796,2292,3756,2796,716,748,2764,716,451,1,835,451,1611,3756,1611,3756,2635,1458,2635,451,835,3756,1091,3756,835,2635,2115,2635,1676,1708,3724,1676]) (by decide +kernel)
  change ∀ b ∈ [s661,s713], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s661) b661 <|
    PetersenLocalChildren.push (x := s713) b713 <|
    PetersenLocalChildren.nil
theorem b720 : Blocked tgt 6 s720 := by
  apply PetersenFastNode.node (nxt := #[s721,s722,s724]) (hints := [3509,2797,2667,2797,716,716,840,3765,840,3509,1096,3509,1096,2485,844,2989,844,0,2636,3477,2636,1429,2667,2797,2797,2667,3317,2285,3765,3317,2797,3317,3317,2797,2797,3317,3317,2797,717,749,2765,717,456,3765,840,3765,456,2483,1096,456,844,456,844,972,2636,1459,2636,456,840,3765,3765,840,1,3765,3765,836,1685,1717,3733,1685,3757,3757,2636,2,2636,1096,844,2120,2636,844]) (by decide +kernel)
  change ∀ b ∈ [s721,s722,s724], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s721) b721 <|
    PetersenLocalChildren.push (x := s722) b722 <|
    PetersenLocalChildren.push (x := s724) b724 <|
    PetersenLocalChildren.nil
theorem b725 : Blocked tgt 6 s725 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s725 6 _ le
  decide +kernel
theorem b726 : Blocked tgt 6 s726 := by
  apply PetersenFastNode.node (nxt := #[s690,s727,s724]) (hints := [1367,2797,1367,2797,456,716,844,2989,840,1685,840,1685,1579,1709,1579,1709,2376,0,2376,1,1367,2797,2797,1367,2797,780,2859,2797,1237,2285,1685,1237,1709,1237,1709,1773,717,749,2765,717,844,456,972,456,1685,840,1685,456,1709,1431,1709,456,1431,2376,456,1685,840,1685,836,1709,2,1709,844,844,2120,2636,844,840,1685,1685,1701,840,1685,1685,840,1677,1677]) (by decide +kernel)
  change ∀ b ∈ [s690,s727,s724], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s727) b727 <|
    PetersenLocalChildren.push (x := s724) b724 <|
    PetersenLocalChildren.nil
theorem b728 : Blocked tgt 6 s728 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s728 6 _ le
  decide +kernel
theorem b730 : Blocked tgt 6 s730 := by
  apply PetersenFastNode.node (nxt := #[s50,s731,s732,s733]) (hints := [2798,2798,3448,457,3576,3448,781,781,3448,845,3448,777,3896,3448,2408,2424,3432,2408,1368,1400,3416,1368,3512,457,0,457,2990,845,2990,845,3766,841,3766,841,3758,1353,3758,1353,1,2377,2,2377,717,201,845,717,457,205,841,457,457,3630,1353,457,457,3,2377,457,3510,841,837,837,845,1097,1613,845,845,2121,2637,845,841,1101,1353,841,841,2125,2377,841,1353,1710,2377,1353]) (by decide +kernel)
  change ∀ b ∈ [s50,s731,s732,s733], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s731) b731 <|
    PetersenLocalChildren.push (x := s732) b732 <|
    PetersenLocalChildren.push (x := s733) b733 <|
    PetersenLocalChildren.nil
theorem b734 : Blocked tgt 6 s734 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s734 6 _ le
  decide +kernel
theorem b735 : Blocked tgt 6 s735 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s735 6 _ le
  decide +kernel
theorem b736 : Blocked tgt 6 s736 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s736 6 _ le
  decide +kernel
theorem b737 : Blocked tgt 6 s737 := by
  apply PetersenFastNode.node (nxt := #[s738]) (hints := [3445,2667,2793,3445,2795,778,2987,2795,3315,2795,2795,3315,3315,2795,2795,3315,2795,2291,3755,2795,715,747,2763,715,714,2859,842,714,838,714,838,966,454,454,714,194,1350,3627,1350,714,2374,0,2374,714,3507,838,842,838,3507,842,842,3507,842,1350,1610,842,842,2374,2634,842,838,3763,838,1610,1350,838,838,2634,2374,838,1090,1350,1090,1350,2114,2374,2114,2374,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s738], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s738) b738 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
