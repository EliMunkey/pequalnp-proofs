import higher.WireProjection
import M191Values0
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values734
import M191Values735
import M191Values741
import M191Values745
import M191Values748
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows8
import M191StartPreferredRows9
import ResidualFast
import ThetaClosing
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1918 : Blocked tgt 8 s1918 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s1918 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0x0,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0x30303030303030303030303030303030 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_4814 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b1919 : Blocked tgt 8 s1919 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1919 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b2066 : Blocked tgt 8 s2066 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s2066 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_4814 (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl))))))))) (by decide +kernel)

theorem b2070 : Blocked tgt 8 s2070 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s2070 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv741_4260 (PetersenWireProjection.cons pv741_4814 (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl))))))))) (by decide +kernel)
theorem b2082 : Blocked tgt 8 s2082 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfff0fff0fff0fff0fff0fff0fff0fff0,0xfff0fff0fff0fff0fff0fff0fff0fff0),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_868) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_868
theorem b2090 : Blocked tgt 8 s2090 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2090 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b2093 : Blocked tgt 8 s2093 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,17,22,19,24,25,26,27,28,25,30,27,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,49,54,51,56,57,58,59,60,57,62,59,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,81,86,83,88,89,90,91,92,89,94,91,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,113,118,115,120,121,122,123,124,121,126,123] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,17,22,19,24,25,26,27,28,25,30,27,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,49,54,51,56,57,58,59,60,57,62,59,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,81,86,83,88,89,90,91,92,89,94,91,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,113,118,115,120,121,122,123,124,121,126,123] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xfffff0f0fffff0f0fffff0f0fffff0f0,0xfffff0f0fffff0f0fffff0f0fffff0f0),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_1034) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_1034
theorem b2130 : Blocked tgt 8 s2130 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffff0f0fffff0f0fffff0f0fffff0f0,0xffaaffaaffaaffaaffaaffaaffaaffaa),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_866) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_866
theorem b2140 : Blocked tgt 8 s2140 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,17,19,19,48,52,50,54,49,49,51,51,80,84,82,86,81,81,83,83,112,116,114,118,113,113,115,115,24,28,26,30,25,25,27,27,56,60,58,62,57,57,59,59,88,92,90,94,89,89,91,91,120,124,122,126,121,121,123,123] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,68,67,70,96,100,98,102,97,100,99,102,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,76,75,78,104,108,106,110,105,108,107,110,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,84,83,86,112,116,114,118,113,116,115,118,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,92,91,94,120,124,122,126,121,124,123,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xf0f00000f0f00000f0f00000f0f0,0xaaaaaaaaaaaaaaaa),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000),(0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_184) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_184
theorem b2159 : Blocked tgt 8 s2159 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2159 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b2241 : Blocked tgt 8 s2241 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffafffafffafffafffafffafffafffa,0xfffafffafffafffafffafffafffafffa),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_1003) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_1003
theorem b2320 : Blocked tgt 8 s2320 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xfffffafafffffafafffffafafffffafa,0xfffafffafffafffafffafffafffafffa),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_1003) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_1003
theorem b2542 : Blocked tgt 8 s2542 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffff00ff00ffffffffff00ff00,0xffffffffff00ff00ffffffffff00ff00),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_871) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_871
theorem b2549 : Blocked tgt 8 s2549 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffff0000ffffffffffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_872) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_872
theorem b2562 : Blocked tgt 8 s2562 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xffffffffffff0000ffffffffffff0000,0xffffffffffff0000ffffffffffff0000),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s2_872) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b2_872
theorem b2586 : Blocked tgt 8 s2586 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false))] s2586 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xfafafafafafafafafafafafafafafafa,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5850 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b2587 : Blocked tgt 8 s2587 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2587 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2588 : Blocked tgt 8 s2588 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2588 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2589 : Blocked tgt 8 s2589 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2589 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2590 : Blocked tgt 8 s2590 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2590 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4503 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2591 : Blocked tgt 8 s2591 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false))] s2591 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xfafafafafafafafafafafafafafafafa,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_5850 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)

theorem b2592 : Blocked tgt 8 s2592 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2592 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2654 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2593 : Blocked tgt 8 s2593 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2593 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2594 : Blocked tgt 8 s2594 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2594 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2595 : Blocked tgt 8 s2595 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2595 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2596 : Blocked tgt 8 s2596 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2596 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2597 : Blocked tgt 8 s2597 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2597 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2598 : Blocked tgt 8 s2598 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2598 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2672 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2622 : Blocked tgt 8 s2622 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2622 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2623 : Blocked tgt 8 s2623 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2623 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2624 : Blocked tgt 8 s2624 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2624 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2625 : Blocked tgt 8 s2625 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2625 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xff00ff00ff00ff00,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5f50000f5f50000f5f50000f5f50000 : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2626 : Blocked tgt 8 s2626 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2626 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2649 : Blocked tgt 8 s2649 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2649 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7588 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2650 : Blocked tgt 8 s2650 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2650 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b2651 : Blocked tgt 8 s2651 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2651 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2652 : Blocked tgt 8 s2652 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2652 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5729 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2653 : Blocked tgt 8 s2653 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2653 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2654 : Blocked tgt 8 s2654 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2654 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b2655 : Blocked tgt 8 s2655 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2655 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8104 rfl))))))))) (by decide +kernel)
theorem b2656 : Blocked tgt 8 s2656 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2656 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2657 : Blocked tgt 8 s2657 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2657 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b2658 : Blocked tgt 8 s2658 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2658 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2659 : Blocked tgt 8 s2659 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2659 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2684 : Blocked tgt 8 s2684 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2684 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2685 : Blocked tgt 8 s2685 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2685 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2686 : Blocked tgt 8 s2686 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2686 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2687 : Blocked tgt 8 s2687 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2687 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3582 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2713 : Blocked tgt 8 s2713 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2713 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b2714 : Blocked tgt 8 s2714 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2714 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2715 : Blocked tgt 8 s2715 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2715 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2748 : Blocked tgt 8 s2748 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2748 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2749 : Blocked tgt 8 s2749 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2749 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2750 : Blocked tgt 8 s2750 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2750 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2751 : Blocked tgt 8 s2751 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2751 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xf0f0f0f0f0f0f0f0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3677 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2752 : Blocked tgt 8 s2752 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2752 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2753 : Blocked tgt 8 s2753 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2753 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2754 : Blocked tgt 8 s2754 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2754 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2755 : Blocked tgt 8 s2755 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2755 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xff00ff00ff00ff00,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3705 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2756 : Blocked tgt 8 s2756 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2756 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2757 : Blocked tgt 8 s2757 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2757 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7688 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2758 : Blocked tgt 8 s2758 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2758 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2759 : Blocked tgt 8 s2759 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2759 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff0000ffff0000,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3730 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2760 : Blocked tgt 8 s2760 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2760 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2792 : Blocked tgt 8 s2792 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2792 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl))))))))) (by decide +kernel)
theorem b2793 : Blocked tgt 8 s2793 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2793 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2794 : Blocked tgt 8 s2794 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2794 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2795 : Blocked tgt 8 s2795 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2795 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3759 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b2822 : Blocked tgt 8 s2822 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2822 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2823 : Blocked tgt 8 s2823 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s2823 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5850 (PetersenWireProjection.cons pv735_5977 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl))))))))) (by decide +kernel)
theorem b2824 : Blocked tgt 8 s2824 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2824 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x4040404040404040404040404040404 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2825 : Blocked tgt 8 s2825 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2825 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2826 : Blocked tgt 8 s2826 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2826 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl))))))))) (by decide +kernel)
theorem b2827 : Blocked tgt 8 s2827 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2827 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xcc00cc00cc00cc00cc00cc00cc00cc00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2832 : Blocked tgt 8 s2832 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2832 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2240 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2833 : Blocked tgt 8 s2833 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2833 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3304 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b2834 : Blocked tgt 8 s2834 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2834 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4586 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b2835 : Blocked tgt 8 s2835 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2835 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2836 : Blocked tgt 8 s2836 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2836 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2837 : Blocked tgt 8 s2837 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2837 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2838 : Blocked tgt 8 s2838 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2838 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4675 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2839 : Blocked tgt 8 s2839 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2839 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b2840 : Blocked tgt 8 s2840 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2840 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2841 : Blocked tgt 8 s2841 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2841 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_3427 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b2842 : Blocked tgt 8 s2842 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2842 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4753 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2847 : Blocked tgt 8 s2847 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2847 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2848 : Blocked tgt 8 s2848 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s2848 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5850 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
theorem b2849 : Blocked tgt 8 s2849 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2849 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfa00fa00fa00fa00fa00fa00fa00fa00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b2850 : Blocked tgt 8 s2850 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s2850 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons pv745_6659 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl))))))))) (by decide +kernel)
theorem b2851 : Blocked tgt 8 s2851 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s2851 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444444444444444,0x0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xfa00fa00fa00fa00fa00fa00fa00fa : BitVec 128) = 0x4444444444444444) (PetersenWireProjection.cons pv748_2708 (PetersenWireProjection.cons pv748_4260 (PetersenWireProjection.cons pv748_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv748_6170 (PetersenWireProjection.cons pv748_6790 (PetersenWireProjection.cons pv748_7474 (PetersenWireProjection.cons pv748_8012 rfl))))))))) (by decide +kernel)
theorem b2852 : Blocked tgt 8 s2852 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2852 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0x5000500050005000500050005000500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b2853 : Blocked tgt 8 s2853 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2853 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xfafa0000fafa0000fafa0000fafa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b2854 : Blocked tgt 8 s2854 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2854 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7285 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b2855 : Blocked tgt 8 s2855 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2855 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1863 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b2856 : Blocked tgt 8 s2856 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2856 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x5050000050500000505000005050000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b2857 : Blocked tgt 8 s2857 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2857 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xfafafafa00000000fafafafa00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b2858 : Blocked tgt 8 s2858 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2858 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5850 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7812 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b2859 : Blocked tgt 8 s2859 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2859 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1218 (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5850 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b2860 : Blocked tgt 8 s2860 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s2860 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0x5050505000000000505050500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5850 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b2861 : Blocked tgt 8 s2861 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s2861 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xfafafafafafafafa0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_5850 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
