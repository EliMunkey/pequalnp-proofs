import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows1
import M191StartPreferredRows2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b378 : Blocked tgt 7 s378 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s378 7 _ le
  decide +kernel
theorem b380 : Blocked tgt 7 s380 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s380 7 _ le
  decide +kernel
theorem b381 : Blocked tgt 7 s381 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(1,false))] s381 7 _ le
  decide +kernel
theorem b382 : Blocked tgt 7 s382 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s382 7 _ le
  decide +kernel
theorem b383 : Blocked tgt 7 s383 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s383 7 _ le
  decide +kernel
theorem b384 : Blocked tgt 7 s384 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s384 7 _ le
  decide +kernel
theorem b385 : Blocked tgt 7 s385 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s385 7 _ le
  decide +kernel
theorem b386 : Blocked tgt 7 s386 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s386 7 _ le
  decide +kernel

theorem b387 : Blocked tgt 7 s387 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s387 7 _ le
  decide +kernel
theorem b388 : Blocked tgt 7 s388 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s388 7 _ le
  decide +kernel
theorem b389 : Blocked tgt 7 s389 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(1,false))] s389 7 _ le
  decide +kernel
theorem b390 : Blocked tgt 7 s390 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s390 7 _ le
  decide +kernel
theorem b391 : Blocked tgt 7 s391 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s391 7 _ le
  decide +kernel
theorem b394 : Blocked tgt 7 s394 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s394 7 _ le
  decide +kernel
theorem b395 : Blocked tgt 7 s395 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s395 7 _ le
  decide +kernel
theorem b396 : Blocked tgt 7 s396 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s396 7 _ le
  decide +kernel
theorem b397 : Blocked tgt 7 s397 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s397 7 _ le
  decide +kernel
theorem b398 : Blocked tgt 7 s398 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s398 7 _ le
  decide +kernel
theorem b399 : Blocked tgt 7 s399 := by
  intro k le c
  apply rejects_sound r733 (0xffffffffcccccccc :: i6) 6 tgt small733 hot733 [] s399 7 _ le
  decide +kernel
theorem b400 : Blocked tgt 7 s400 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s400 7 _ le
  decide +kernel
theorem b401 : Blocked tgt 7 s401 := by
  intro k le c
  apply rejects_sound r733 (0xffffffffcccccccc :: i6) 6 tgt small733 hot733 [] s401 7 _ le
  decide +kernel
theorem b402 : Blocked tgt 7 s402 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s402 7 _ le
  decide +kernel
theorem b403 : Blocked tgt 7 s403 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s403 7 _ le
  decide +kernel
theorem b404 : Blocked tgt 7 s404 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s404 7 _ le
  decide +kernel
theorem b405 : Blocked tgt 7 s405 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s405 7 _ le
  decide +kernel
theorem b406 : Blocked tgt 7 s406 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s406 7 _ le
  decide +kernel
theorem b407 : Blocked tgt 7 s407 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s407 7 _ le
  decide +kernel
theorem b408 : Blocked tgt 7 s408 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s408 7 _ le
  decide +kernel
theorem b409 : Blocked tgt 7 s409 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s409 7 _ le
  decide +kernel
theorem b410 : Blocked tgt 7 s410 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s410 7 _ le
  decide +kernel
theorem b411 : Blocked tgt 7 s411 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s411 7 _ le
  decide +kernel
theorem b412 : Blocked tgt 7 s412 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s412 7 _ le
  decide +kernel
theorem b413 : Blocked tgt 7 s413 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s413 7 _ le
  decide +kernel
theorem b414 : Blocked tgt 7 s414 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s414 7 _ le
  decide +kernel
theorem b415 : Blocked tgt 7 s415 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s415 7 _ le
  decide +kernel
theorem b416 : Blocked tgt 7 s416 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s416 7 _ le
  decide +kernel
theorem b420 : Blocked tgt 7 s420 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s420 7 _ le
  decide +kernel
theorem b421 : Blocked tgt 7 s421 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s421 7 _ le
  decide +kernel
theorem b422 : Blocked tgt 7 s422 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s422 7 _ le
  decide +kernel
theorem b423 : Blocked tgt 7 s423 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s423 7 _ le
  decide +kernel

theorem b424 : Blocked tgt 7 s424 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s424 7 _ le
  decide +kernel
theorem b425 : Blocked tgt 7 s425 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s425 7 _ le
  decide +kernel
theorem b426 : Blocked tgt 7 s426 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(2,false))] s426 7 _ le
  decide +kernel
theorem b427 : Blocked tgt 7 s427 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s427 7 _ le
  decide +kernel
theorem b428 : Blocked tgt 7 s428 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s428 7 _ le
  decide +kernel
theorem b429 : Blocked tgt 7 s429 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s429 7 _ le
  decide +kernel
theorem b430 : Blocked tgt 7 s430 := by
  intro k le c
  apply rejects_sound r736 (0xaaaa0000aaaa :: i6) 6 tgt small736 hot736 [] s430 7 _ le
  decide +kernel
theorem b449 : Blocked tgt 7 s449 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(5,false))] s449 7 _ le
  decide +kernel
theorem b450 : Blocked tgt 7 s450 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s450 7 _ le
  decide +kernel
theorem b462 : Blocked tgt 7 s462 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s462 7 _ le
  decide +kernel
theorem b463 : Blocked tgt 7 s463 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s463 7 _ le
  decide +kernel
theorem b464 : Blocked tgt 7 s464 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s464 7 _ le
  decide +kernel
theorem b465 : Blocked tgt 7 s465 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s465 7 _ le
  decide +kernel
theorem b466 : Blocked tgt 7 s466 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s466 7 _ le
  decide +kernel
theorem b467 : Blocked tgt 7 s467 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s467 7 _ le
  decide +kernel
theorem b468 : Blocked tgt 7 s468 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s468 7 _ le
  decide +kernel
theorem b469 : Blocked tgt 7 s469 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s469 7 _ le
  decide +kernel
theorem b470 : Blocked tgt 7 s470 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s470 7 _ le
  decide +kernel
theorem b471 : Blocked tgt 7 s471 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [] s471 7 _ le
  decide +kernel
theorem b472 : Blocked tgt 7 s472 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(1,false),(2,false))] s472 7 _ le
  decide +kernel
theorem b473 : Blocked tgt 7 s473 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(2,false))] s473 7 _ le
  decide +kernel
theorem b474 : Blocked tgt 7 s474 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s474 7 _ le
  decide +kernel
theorem b475 : Blocked tgt 7 s475 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s475 7 _ le
  decide +kernel

theorem b476 : Blocked tgt 7 s476 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s476 7 _ le
  decide +kernel
theorem b477 : Blocked tgt 7 s477 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s477 7 _ le
  decide +kernel
theorem b478 : Blocked tgt 7 s478 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s478 7 _ le
  decide +kernel
theorem b479 : Blocked tgt 7 s479 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s479 7 _ le
  decide +kernel
theorem b480 : Blocked tgt 7 s480 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s480 7 _ le
  decide +kernel
theorem b481 : Blocked tgt 7 s481 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s481 7 _ le
  decide +kernel
theorem b482 : Blocked tgt 7 s482 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s482 7 _ le
  decide +kernel
theorem b483 : Blocked tgt 7 s483 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s483 7 _ le
  decide +kernel
theorem b494 : Blocked tgt 7 s494 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s494 7 _ le
  decide +kernel
theorem b495 : Blocked tgt 7 s495 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s495 7 _ le
  decide +kernel
theorem b496 : Blocked tgt 7 s496 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s496 7 _ le
  decide +kernel
theorem b497 : Blocked tgt 7 s497 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s497 7 _ le
  decide +kernel
theorem b498 : Blocked tgt 7 s498 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s498 7 _ le
  decide +kernel
theorem b499 : Blocked tgt 7 s499 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s499 7 _ le
  decide +kernel
theorem b500 : Blocked tgt 7 s500 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s500 7 _ le
  decide +kernel
theorem b501 : Blocked tgt 7 s501 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s501 7 _ le
  decide +kernel

theorem b502 : Blocked tgt 7 s502 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s502 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
