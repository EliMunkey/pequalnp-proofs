import M191StartPreferredSignals
import M191ResidualC7A0G1
import M191ResidualC7A0G20
import M191ResidualC7A0G4
import M191ResidualC7A0G8
import M191ResidualC7A0G9
import M191ResidualC8A0G1
import M191StagedF0X2Z1G11
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G19
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G22
import M191StagedF0X2Z1G25
import M191StagedF0X2Z1G26
import M191StagedF0X2Z1G28
import M191StagedF0X2Z1G29
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G30
import M191StagedF0X2Z1G32
import M191StagedF0X2Z1G33
import M191StagedF0X2Z1G34
import M191StagedF0X2Z1G35
import M191StagedF0X2Z1G36
import M191StagedF0X2Z1G37
import M191StagedF0X2Z1G38
import M191StagedF0X2Z1G39
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G78
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G9
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows26
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows40
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows68
import M191StartPreferredRows7
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b9691 : Blocked tgt 8 s9691 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,65,74,67,76,77,78,79,40,41,42,43,44,45,46,47,104,97,106,99,108,109,110,111,24,25,26,27,28,29,30,31,88,81,90,83,92,93,94,95,56,57,58,59,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffffffffff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4529) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4529
theorem b9898 : Blocked tgt 8 s9898 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,1,66,3,68,69,70,70,32,33,34,35,36,37,38,38,96,33,98,35,100,101,102,102,16,17,18,19,20,21,22,22,80,17,82,19,84,85,86,86,48,49,50,51,52,53,54,54,112,49,114,51,116,117,118,118,8,9,10,11,12,13,14,14,72,9,74,11,76,77,78,78,40,41,42,43,44,45,46,46,104,41,106,43,108,109,110,110,24,25,26,27,28,29,30,30,88,25,90,27,92,93,94,94,56,57,58,59,60,61,62,62,120,57,122,59,124,125,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,65,66,67,68,69,70,70,32,33,34,35,36,37,38,38,96,97,98,99,100,101,102,102,16,17,18,19,20,21,22,22,80,81,82,83,84,85,86,86,48,49,50,51,52,53,54,54,112,113,114,115,116,117,118,118,8,1,10,3,12,13,14,14,72,65,74,67,76,77,78,78,40,33,42,35,44,45,46,46,104,97,106,99,108,109,110,110,24,17,26,19,28,29,30,30,88,81,90,83,92,93,94,94,56,49,58,51,60,61,62,62,120,113,122,115,124,125,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5045) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5045
theorem b9944 : Blocked tgt 8 s9944 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,12,14,14,72,9,74,11,76,76,78,78,40,41,42,43,44,44,46,46,104,41,106,43,108,108,110,110,24,25,26,27,28,28,30,30,88,25,90,27,92,92,94,94,56,57,58,59,60,60,62,62,120,57,122,59,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,1,10,3,12,13,14,15,72,65,74,67,76,76,78,78,40,33,42,35,44,45,46,47,104,97,106,99,108,108,110,110,24,17,26,19,28,29,30,31,88,81,90,83,92,92,94,94,56,49,58,51,60,61,62,63,120,113,122,115,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5134) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5134
theorem b10021 : Blocked tgt 8 s10021 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5198) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5198
theorem b10130 : Blocked tgt 8 s10130 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5415) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5415
theorem b10169 : Blocked tgt 8 s10169 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,65,74,67,76,77,78,79,40,41,42,43,44,45,46,47,104,97,106,99,108,109,110,111,24,25,26,27,28,29,30,31,88,81,90,83,92,93,94,95,56,57,58,59,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffffffffff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5454) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5454
theorem b10556 : Blocked tgt 8 s10556 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5854) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5854
theorem b10625 : Blocked tgt 8 s10625 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5967) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5967
theorem b10727 : Blocked tgt 8 s10727 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xfffff0f0fffff0f0fffff0f0fffff0f0,0xfffffffff0f0f0f0fffffffff0f0f0f0),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s6019) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b6019
theorem b10834 : Blocked tgt 8 s10834 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,1,66,3,68,69,70,70,32,33,34,35,36,37,38,38,96,33,98,35,100,101,102,102,16,17,18,19,20,21,22,22,80,17,82,19,84,85,86,86,48,49,50,51,52,53,54,54,112,49,114,51,116,117,118,118,8,9,10,11,12,13,14,14,72,9,74,11,76,77,78,78,40,41,42,43,44,45,46,46,104,41,106,43,108,109,110,110,24,25,26,27,28,29,30,30,88,25,90,27,92,93,94,94,56,57,58,59,60,61,62,62,120,57,122,59,124,125,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,65,66,67,68,69,70,70,32,33,34,35,36,37,38,38,96,97,98,99,100,101,102,102,16,17,18,19,20,21,22,22,80,81,82,83,84,85,86,86,48,49,50,51,52,53,54,54,112,113,114,115,116,117,118,118,8,1,10,3,12,13,14,14,72,65,74,67,76,77,78,78,40,33,42,35,44,45,46,46,104,97,106,99,108,109,110,110,24,17,26,19,28,29,30,30,88,81,90,83,92,93,94,94,56,49,58,51,60,61,62,62,120,113,122,115,124,125,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s6404) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b6404
theorem b10867 : Blocked tgt 8 s10867 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,12,14,14,72,9,74,11,76,76,78,78,40,41,42,43,44,44,46,46,104,41,106,43,108,108,110,110,24,25,26,27,28,28,30,30,88,25,90,27,92,92,94,94,56,57,58,59,60,60,62,62,120,57,122,59,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,1,10,3,12,13,14,15,72,65,74,67,76,76,78,78,40,33,42,35,44,45,46,47,104,97,106,99,108,108,110,110,24,17,26,19,28,29,30,31,88,81,90,83,92,92,94,94,56,49,58,51,60,61,62,63,120,113,122,115,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s6447) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b6447
theorem b11288 : Blocked tgt 8 s11288 := by
  apply PetersenFastNode.node (nxt := #[s3244,s11289,s572,s11290,s8487,s10572,s11113,s2680,s11291,s11292]) (hints := [5556,5556,911,9683,911,9683,9939,9939,1679,0,1679,1,2,3,2703,11475,2703,11475,4751,13523,4751,13523,8847,4,8847,5,783,9683,6,9683,5940,7,6068,7484,1551,7484,1679,6846,6846,7476,11475,7476,11475,13652,13523,13652,13523,13620,8847,13620,8847,9683,911,911,9683,8651,8659,9675,8651,9683,6974,9683,7220,11475,9683,9683,13396,13523,9683,1427,1491,9619,1427,6972,1679,7484,1679,10842,5940,5940,10842,11475,2703,11475,2703,13523,4751,13523,4751,5940,8847,13620,8847,1679,7742,10443,10451,10443,11467,12491,12499,12491,13515,1679,3420,8847,1679,8,11475,9,11475,14426,13523,14426,13523,14910,8847,14910,8847,11475,3380,13523,11475,3219,3283,11411,3219,5267,5331,13459,5267]) (by decide +kernel)
  change ∀ b ∈ [s3244,s11289,s572,s11290,s8487,s10572,s11113,s2680,s11291,s11292], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s11289) b11289 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s11290) b11290 <|
    PetersenLocalChildren.push (x := s8487) b8487 <|
    PetersenLocalChildren.push (x := s10572) b10572 <|
    PetersenLocalChildren.push (x := s11113) b11113 <|
    PetersenLocalChildren.push (x := s2680) b2680 <|
    PetersenLocalChildren.push (x := s11291) b11291 <|
    PetersenLocalChildren.push (x := s11292) b11292 <|
    PetersenLocalChildren.nil
theorem b11454 : Blocked tgt 8 s11454 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,65,64,67,68,69,68,68,32,33,34,35,36,37,38,38,96,97,96,99,100,101,100,100,16,17,18,19,20,21,22,22,80,81,80,83,84,85,84,84,48,49,50,51,52,53,54,54,112,113,112,115,116,117,116,116,8,9,10,11,12,13,14,14,72,73,72,75,76,77,76,76,40,41,42,43,44,45,46,46,104,105,104,107,108,109,108,108,24,25,26,27,28,29,30,30,88,89,88,91,92,93,92,92,56,57,58,59,60,61,62,62,120,121,120,123,124,125,124,124] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,6,64,65,66,67,68,69,70,70,32,33,34,35,36,37,38,38,96,97,98,99,100,101,102,102,16,17,18,19,20,21,22,22,80,81,82,83,84,85,86,86,48,49,50,51,52,53,54,54,112,113,114,115,116,117,118,118,8,9,8,11,12,13,12,12,72,73,72,75,76,77,76,76,40,41,40,43,44,45,44,44,104,105,104,107,108,109,108,108,24,25,24,27,28,29,28,28,88,89,88,91,92,93,92,92,56,57,56,59,60,61,60,60,120,121,120,123,124,125,124,124] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0x22222222222222222222222222222222,0x22222222222222222222222222222222),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffcccccccccccccccc,0xffccffccffccffccffccffccffccffcc)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s11417) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b11417
theorem b12346 : Blocked tgt 8 s12346 := by
  apply PetersenFastNode.node (nxt := #[s12347,s12348,s1729,s2728,s12349,s12312,s12350,s1140,s12351,s12368,s12369,s12372,s12373,s9956,s10876,s12338,s12374,s12375,s12376,s12377,s12378,s12379,s12380,s12381,s12383,s12384,s12385,s12386,s12387,s12388,s12389,s12390,s12391,s12392,s12393,s12394,s12395]) (hints := [5325,5325,0,4559,4559,8686,4557,4559,1,4557,5325,8686,4559,4559,5071,9838,2,3,6615,4559,7511,6615,4,5,1578,6,1578,4559,4559,7,4559,4559,1578,8,9,10,4559,4559,7503,11374,11,11502,6607,12,7503,4559,4559,11502,8687,8687,13679,463,4559,13550,12783,4559,13679,8687,8687,13550,4559,4559,13647,495,8687,13,12751,8687,13647,4559,4559,14,8686,8686,5709,5071,15,5071,5069,16,5709,8686,8686,5071,6873,17,6873,8686,8686,7511,8686,8686,6873,7511,18,7511,8678,8686,1578,8678,19,20,8686,8686,11502,7247,21,7503,10734,22,11502,8686,8686,7503,8686,8686,13550,13423,23,13679,12782,24,13550,8686,8686,13679,430,430,8874,494,8686,13647,8622,8686,8874,430,430,13647,6999,6999,7511,4943,5071,6873,7127,5071,7511,6999,6999,6873,4813,10869,25,5071,5071,1578,5071,5071,26,1578,10869,1578,11502,5071,11502,4951,6999,2730,11502,6999,11502,5071,5071,2730,13550,9199,13550,975,5071,4778,13550,5071,13550,9199,9199,4778,5071,5071,13647,1007,9199,8874,13263,9199,13647,5071,5071,8874,6873,6873,27,7511,7511,1578,7511,7511,28,6873,6873,1578,4809,4809,29,11502,7511,11502,7495,7511,30,11502,4809,11502,11639,11639,14711,13550,7511,13550,14711,7511,14711,13550,11639,13550,7511,7511,14679,3447,11639,13647,14679,11639,14679,7511,7511,13647,10470,1578,10470,10478,31,11502,10470,32,10470,11494,1578,11502,12518,1578,12518,12526,33,13550,12518,34,12518,13542,1578,13550,1578,1578,8874,13647,35,13647,8874,36,8874,13647,1578,13647,11502,11502,13550,3407,7503,14711,13550,7503,13550,11502,11502,14711,3246,3246,13647,3310,11502,14679,11438,11502,13647,3246,3246,14679,5294,5294,8874,5358,13550,13647,13486,13550,8874,5294,5294,13647]) (by decide +kernel)
  change ∀ b ∈ [s12347,s12348,s1729,s2728,s12349,s12312,s12350,s1140,s12351,s12368,s12369,s12372,s12373,s9956,s10876,s12338,s12374,s12375,s12376,s12377,s12378,s12379,s12380,s12381,s12383,s12384,s12385,s12386,s12387,s12388,s12389,s12390,s12391,s12392,s12393,s12394,s12395], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12347) b12347 <|
    PetersenLocalChildren.push (x := s12348) b12348 <|
    PetersenLocalChildren.push (x := s1729) b1729 <|
    PetersenLocalChildren.push (x := s2728) b2728 <|
    PetersenLocalChildren.push (x := s12349) b12349 <|
    PetersenLocalChildren.push (x := s12312) b12312 <|
    PetersenLocalChildren.push (x := s12350) b12350 <|
    PetersenLocalChildren.push (x := s1140) b1140 <|
    PetersenLocalChildren.push (x := s12351) b12351 <|
    PetersenLocalChildren.push (x := s12368) b12368 <|
    PetersenLocalChildren.push (x := s12369) b12369 <|
    PetersenLocalChildren.push (x := s12372) b12372 <|
    PetersenLocalChildren.push (x := s12373) b12373 <|
    PetersenLocalChildren.push (x := s9956) b9956 <|
    PetersenLocalChildren.push (x := s10876) b10876 <|
    PetersenLocalChildren.push (x := s12338) b12338 <|
    PetersenLocalChildren.push (x := s12374) b12374 <|
    PetersenLocalChildren.push (x := s12375) b12375 <|
    PetersenLocalChildren.push (x := s12376) b12376 <|
    PetersenLocalChildren.push (x := s12377) b12377 <|
    PetersenLocalChildren.push (x := s12378) b12378 <|
    PetersenLocalChildren.push (x := s12379) b12379 <|
    PetersenLocalChildren.push (x := s12380) b12380 <|
    PetersenLocalChildren.push (x := s12381) b12381 <|
    PetersenLocalChildren.push (x := s12383) b12383 <|
    PetersenLocalChildren.push (x := s12384) b12384 <|
    PetersenLocalChildren.push (x := s12385) b12385 <|
    PetersenLocalChildren.push (x := s12386) b12386 <|
    PetersenLocalChildren.push (x := s12387) b12387 <|
    PetersenLocalChildren.push (x := s12388) b12388 <|
    PetersenLocalChildren.push (x := s12389) b12389 <|
    PetersenLocalChildren.push (x := s12390) b12390 <|
    PetersenLocalChildren.push (x := s12391) b12391 <|
    PetersenLocalChildren.push (x := s12392) b12392 <|
    PetersenLocalChildren.push (x := s12393) b12393 <|
    PetersenLocalChildren.push (x := s12394) b12394 <|
    PetersenLocalChildren.push (x := s12395) b12395 <|
    PetersenLocalChildren.nil
theorem b12557 : Blocked tgt 8 s12557 := by
  apply PetersenFastNode.node (nxt := #[s1760,s2740,s12558,s12323,s12559,s12560,s10131,s12561,s12562,s5115,s12563,s12582,s12583,s12394,s12585,s12496,s12586,s12587,s12461,s12588,s12589,s12590,s12591,s12592,s12593,s12594,s12595,s12596,s12597,s12598,s12599,s12550,s12600,s12601,s12602]) (hints := [936,5323,936,5325,5581,8676,936,5581,936,5323,5323,8676,5581,5581,5965,8932,0,1,6613,5581,11637,6613,2,3,5581,5581,7501,10468,4,10468,7501,5,7501,5581,5581,10468,8685,8685,13677,1485,5581,12516,12781,5581,13677,8685,8685,12516,5581,5581,13645,1517,8685,6,12749,8685,13645,5581,5581,7,4557,8,1576,4557,5581,9,5581,5581,1576,10,11,12,8676,8676,5707,5709,936,5965,5707,936,5707,8676,8676,5965,6871,6999,6871,8676,8676,11637,8676,8676,6871,6999,6999,11637,8676,8676,10468,4951,6999,7501,10468,6999,10468,8676,8676,7501,8676,8676,12516,2903,6999,13677,12516,6999,12516,8676,8676,13677,1452,1452,13387,1508,8676,13645,8620,8676,13387,1452,1452,13645,420,420,1576,8676,8676,13,8676,8676,1576,420,420,14,6997,6997,11637,5965,5965,6871,7125,5965,11637,6997,6997,6871,10468,5965,10468,4949,6997,2728,10468,6997,10468,5965,5965,2728,12516,9197,12516,1869,5965,4776,12516,5965,12516,9197,9197,4776,5965,5965,13645,1901,9197,15,13261,9197,13645,5965,5965,16,5069,6997,17,5069,5965,1576,5965,5965,18,6997,6997,1576,4807,4807,19,10468,11637,10468,11621,11637,20,10468,4807,10468,11637,11637,14709,12516,6871,12516,14709,6871,14709,12516,11637,12516,3445,6871,21,3445,11637,13645,11637,11637,22,13645,6871,13645,6871,6871,23,11637,11637,1576,7509,11637,24,7509,6871,1576,10468,10468,12516,3405,7501,14709,12516,7501,12516,10468,10468,14709,3244,3244,13645,3300,10468,25,10412,10468,13645,3244,3244,26,2212,2212,1576,10468,10468,27,10468,10468,1576,2212,2212,28,5292,5292,29,5348,12516,13645,12460,12516,30,5292,5292,13645,4260,4260,1576,12516,12516,31,12516,12516,1576,4260,4260,32,13645,13645,1576,14677,33,34]) (by decide +kernel)
  change ∀ b ∈ [s1760,s2740,s12558,s12323,s12559,s12560,s10131,s12561,s12562,s5115,s12563,s12582,s12583,s12394,s12585,s12496,s12586,s12587,s12461,s12588,s12589,s12590,s12591,s12592,s12593,s12594,s12595,s12596,s12597,s12598,s12599,s12550,s12600,s12601,s12602], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1760) b1760 <|
    PetersenLocalChildren.push (x := s2740) b2740 <|
    PetersenLocalChildren.push (x := s12558) b12558 <|
    PetersenLocalChildren.push (x := s12323) b12323 <|
    PetersenLocalChildren.push (x := s12559) b12559 <|
    PetersenLocalChildren.push (x := s12560) b12560 <|
    PetersenLocalChildren.push (x := s10131) b10131 <|
    PetersenLocalChildren.push (x := s12561) b12561 <|
    PetersenLocalChildren.push (x := s12562) b12562 <|
    PetersenLocalChildren.push (x := s5115) b5115 <|
    PetersenLocalChildren.push (x := s12563) b12563 <|
    PetersenLocalChildren.push (x := s12582) b12582 <|
    PetersenLocalChildren.push (x := s12583) b12583 <|
    PetersenLocalChildren.push (x := s12394) b12394 <|
    PetersenLocalChildren.push (x := s12585) b12585 <|
    PetersenLocalChildren.push (x := s12496) b12496 <|
    PetersenLocalChildren.push (x := s12586) b12586 <|
    PetersenLocalChildren.push (x := s12587) b12587 <|
    PetersenLocalChildren.push (x := s12461) b12461 <|
    PetersenLocalChildren.push (x := s12588) b12588 <|
    PetersenLocalChildren.push (x := s12589) b12589 <|
    PetersenLocalChildren.push (x := s12590) b12590 <|
    PetersenLocalChildren.push (x := s12591) b12591 <|
    PetersenLocalChildren.push (x := s12592) b12592 <|
    PetersenLocalChildren.push (x := s12593) b12593 <|
    PetersenLocalChildren.push (x := s12594) b12594 <|
    PetersenLocalChildren.push (x := s12595) b12595 <|
    PetersenLocalChildren.push (x := s12596) b12596 <|
    PetersenLocalChildren.push (x := s12597) b12597 <|
    PetersenLocalChildren.push (x := s12598) b12598 <|
    PetersenLocalChildren.push (x := s12599) b12599 <|
    PetersenLocalChildren.push (x := s12550) b12550 <|
    PetersenLocalChildren.push (x := s12600) b12600 <|
    PetersenLocalChildren.push (x := s12601) b12601 <|
    PetersenLocalChildren.push (x := s12602) b12602 <|
    PetersenLocalChildren.nil
theorem b12716 : Blocked tgt 8 s12716 := by
  apply PetersenFastNode.node (nxt := #[s12717,s8564,s12718,s12719]) (hints := [905,5294,905,5292,5550,9933,4526,4526,5550,0,5550,6582,5550,11469,7470,5550,1454,1454,5550,13517,5550,9678,5550,1,13614,5550,9677,5678,5676,9677,8645,8653,9669,8645,6840,9677,9677,6968,9677,4920,11469,9677,9677,6968,13517,9677,2840,9677,9677,2840,1421,1485,9613,1421,5038,5038,5934,6966,6966,5934,5934,6966,11469,4918,11469,5934,13517,1966,13517,10062,10062,5934,5934,10062,5934,1870,13614,5934,7478,7478,10437,10445,10437,11461,12485,12493,12485,13509,1545,1545,1673,2,14646,13614,14646,13614,4776,11469,6824,11469,2744,13517,6840,13517,3,6840,6840,2712,14646,13614,14646,13614,11469,7470,13517,11469,11598,11469,11469,11598,3213,3277,11405,3213,13517,13646,5261,5325,13453,5261,10776,13614,10776,13614]) (by decide +kernel)
  change ∀ b ∈ [s12717,s8564,s12718,s12719], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12717) b12717 <|
    PetersenLocalChildren.push (x := s8564) b8564 <|
    PetersenLocalChildren.push (x := s12718) b12718 <|
    PetersenLocalChildren.push (x := s12719) b12719 <|
    PetersenLocalChildren.nil
theorem b12723 : Blocked tgt 8 s12723 := by
  apply PetersenFastNode.node (nxt := #[s5855,s10557,s12724,s12730,s12731,s12732,s12733,s12734,s5421,s12735,s12736]) (hints := [912,9684,912,9683,5941,9812,8661,8661,9685,0,9685,10717,7477,11348,7477,9685,9685,13396,13653,9685,1493,1493,9685,1,5557,5557,9684,5685,5683,9684,8652,8660,9676,8652,6975,9684,9684,6975,9684,4927,11476,9684,9684,2879,13524,9684,1428,1492,9620,1428,6975,9684,9684,6975,9173,5941,5941,6973,6973,5941,5941,6973,11476,4925,11476,5941,13524,1845,13524,10069,5941,2005,10069,5941,5941,10069,6069,5941,7485,7485,10444,10452,10444,11468,12492,12500,12492,13516,1680,2,8848,1680,1552,1552,1680,3,4,11476,5,11476,14685,13524,14685,13524,8720,8720,6,8848,7,8,6847,6847,11476,3381,13524,11476,3220,3284,11412,3220,7477,11476,11476,7477,5268,5332,13460,5268,9,13524,13524,10,13621,13621]) (by decide +kernel)
  change ∀ b ∈ [s5855,s10557,s12724,s12730,s12731,s12732,s12733,s12734,s5421,s12735,s12736], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5855) b5855 <|
    PetersenLocalChildren.push (x := s10557) b10557 <|
    PetersenLocalChildren.push (x := s12724) b12724 <|
    PetersenLocalChildren.push (x := s12730) b12730 <|
    PetersenLocalChildren.push (x := s12731) b12731 <|
    PetersenLocalChildren.push (x := s12732) b12732 <|
    PetersenLocalChildren.push (x := s12733) b12733 <|
    PetersenLocalChildren.push (x := s12734) b12734 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s12735) b12735 <|
    PetersenLocalChildren.push (x := s12736) b12736 <|
    PetersenLocalChildren.nil
theorem b12739 : Blocked tgt 8 s12739 := by
  apply PetersenFastNode.node (nxt := #[s12740,s1602,s12741,s423,s12742,s8569,s10567,s12748,s12749,s2728,s12387,s12750,s12751]) (hints := [4535,4535,0,8662,1,8662,9942,9942,7487,2,1682,3,1682,4,2706,11478,2706,11478,4754,13526,4754,13526,8850,5,8850,6,7,8662,8,8662,5943,9,5047,7487,6849,1554,1554,10,1682,7479,11478,7479,11478,13655,13526,13655,13526,13623,8850,13623,8850,8662,5687,5685,8662,7231,8662,8662,7487,8654,8654,8662,7223,10710,8662,8662,13399,12758,8662,406,470,8598,406,6975,4919,7487,6975,10845,1682,5943,1682,11478,2706,11478,2706,13526,4754,13526,4754,5943,8850,13623,8850,11,1682,7487,1682,12,11478,7471,11478,11615,13526,14687,13526,7487,8850,14655,8850,10446,10454,10446,11470,12494,12502,12494,13518,1682,13623,8850,1682,11478,3383,13526,11478,3222,3286,11414,3222,5270,5334,13462,5270]) (by decide +kernel)
  change ∀ b ∈ [s12740,s1602,s12741,s423,s12742,s8569,s10567,s12748,s12749,s2728,s12387,s12750,s12751], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12740) b12740 <|
    PetersenLocalChildren.push (x := s1602) b1602 <|
    PetersenLocalChildren.push (x := s12741) b12741 <|
    PetersenLocalChildren.push (x := s423) b423 <|
    PetersenLocalChildren.push (x := s12742) b12742 <|
    PetersenLocalChildren.push (x := s8569) b8569 <|
    PetersenLocalChildren.push (x := s10567) b10567 <|
    PetersenLocalChildren.push (x := s12748) b12748 <|
    PetersenLocalChildren.push (x := s12749) b12749 <|
    PetersenLocalChildren.push (x := s2728) b2728 <|
    PetersenLocalChildren.push (x := s12387) b12387 <|
    PetersenLocalChildren.push (x := s12750) b12750 <|
    PetersenLocalChildren.push (x := s12751) b12751 <|
    PetersenLocalChildren.nil
theorem b12764 : Blocked tgt 8 s12764 := by
  apply PetersenFastNode.node (nxt := #[s12765,s9442,s12766,s3333,s12767,s2740,s12724,s12773,s12593,s12774,s12775]) (hints := [5557,5557,912,8652,912,8652,8908,8908,11613,0,2704,10444,2704,10444,4752,12492,4752,12492,13621,1,13621,2,1680,3,1680,4,6975,8652,6975,8652,5941,5,6069,11613,6847,7477,10444,7477,10444,13653,12492,13653,12492,13621,6,13621,7,1552,1552,8,1680,8652,912,912,8652,6975,8652,8652,6975,8652,4927,10444,8652,8652,2879,12492,8652,1428,1484,8596,1428,396,8652,8652,396,6973,5941,11613,6973,10444,2704,10444,2704,12492,4752,12492,4752,5941,1877,13621,5941,6973,1680,5941,1680,9,10444,11597,10444,11613,12492,14685,12492,3421,3421,11613,13621,10,1680,7485,1680,10444,3381,12492,10444,3220,3276,10388,3220,2188,10444,10444,2188,5268,5324,12436,5268,4236,12492,12492,4236,1680,8848]) (by decide +kernel)
  change ∀ b ∈ [s12765,s9442,s12766,s3333,s12767,s2740,s12724,s12773,s12593,s12774,s12775], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12765) b12765 <|
    PetersenLocalChildren.push (x := s9442) b9442 <|
    PetersenLocalChildren.push (x := s12766) b12766 <|
    PetersenLocalChildren.push (x := s3333) b3333 <|
    PetersenLocalChildren.push (x := s12767) b12767 <|
    PetersenLocalChildren.push (x := s2740) b2740 <|
    PetersenLocalChildren.push (x := s12724) b12724 <|
    PetersenLocalChildren.push (x := s12773) b12773 <|
    PetersenLocalChildren.push (x := s12593) b12593 <|
    PetersenLocalChildren.push (x := s12774) b12774 <|
    PetersenLocalChildren.push (x := s12775) b12775 <|
    PetersenLocalChildren.nil
theorem b13105 : Blocked tgt 8 s13105 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffccccffffccccffffccccffffcccc,0xffffffffccccccccffffffffcccccccc),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12424) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12424
theorem b13197 : Blocked tgt 8 s13197 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xfffff0f0fffff0f0fffff0f0fffff0f0,0xfffffffff0f0f0f0fffffffff0f0f0f0),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12483) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12483
theorem b13694 : Blocked tgt 8 s13694 := by
  apply PetersenFastNode.node (nxt := #[s13695,s13696,s13697,s4273,s13698,s474,s13699,s8713,s10634,s13700,s12338,s13701]) (hints := [6848,5558,5686,0,1,9685,2,9685,7486,3,7486,4,913,5,913,6,2705,11477,2705,11477,4753,13525,4753,13525,8849,7,8849,8,5686,6848,5814,9,9685,6848,9685,6848,10,7486,6848,6848,785,6976,6848,4784,11477,6832,11477,2720,13525,6816,13525,6848,8721,14912,6848,9685,5684,6974,4918,7486,6974,10846,913,5686,913,11477,2705,11477,2705,13525,4753,13525,4753,5686,8849,13622,8849,8661,8661,9685,7486,11,9685,9685,8653,9685,2705,11477,9685,9685,4753,13525,9685,1429,1493,9621,1429,913,1681,10445,11477,10445,11477,12493,13525,12493,13525,8849,3422,8849,7486,10445,11477,10445,11477,12493,13525,12493,13525,913,13622,8849,913,11477,3382,13525,11477,3221,3285,11413,3221,5269,5333,13461,5269]) (by decide +kernel)
  change ∀ b ∈ [s13695,s13696,s13697,s4273,s13698,s474,s13699,s8713,s10634,s13700,s12338,s13701], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13695) b13695 <|
    PetersenLocalChildren.push (x := s13696) b13696 <|
    PetersenLocalChildren.push (x := s13697) b13697 <|
    PetersenLocalChildren.push (x := s4273) b4273 <|
    PetersenLocalChildren.push (x := s13698) b13698 <|
    PetersenLocalChildren.push (x := s474) b474 <|
    PetersenLocalChildren.push (x := s13699) b13699 <|
    PetersenLocalChildren.push (x := s8713) b8713 <|
    PetersenLocalChildren.push (x := s10634) b10634 <|
    PetersenLocalChildren.push (x := s13700) b13700 <|
    PetersenLocalChildren.push (x := s12338) b12338 <|
    PetersenLocalChildren.push (x := s13701) b13701 <|
    PetersenLocalChildren.nil
theorem b13747 : Blocked tgt 8 s13747 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xfcfcfcfcfcfcfcfc,0xfc00fc00fc00fc00fc00fc00fc00fc),(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s13720) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b13720
theorem b13823 : Blocked tgt 8 s13823 := by
  apply PetersenFastNode.node (nxt := #[s13824,s13825,s3527,s13826,s6650,s13827,s13828,s13829,s8760,s10683,s11032,s13830]) (hints := [6976,0,6848,5558,5942,1,1681,2,1681,3,7222,4,7222,5,6,9685,7,9685,4753,13525,4753,13525,8849,8,8849,9,6976,6848,10,6848,5942,5684,6976,1681,7228,1681,7222,6976,4928,4928,9685,913,9685,11,13525,4753,13525,4753,6976,8849,13622,8849,5942,6848,6070,6848,1553,7744,6848,4784,6848,6848,4784,4784,9685,6848,9685,2720,13525,6816,13525,6848,8721,14912,6848,6972,1681,7228,1681,5942,4924,7222,5942,9685,5942,9685,5940,13525,4753,13525,4753,5942,8849,13622,8849,1681,7744,7744,1681,8653,8661,8653,9677,12493,12501,12493,13517,1681,3164,8849,1681,9685,11477,13525,3126,13525,11350,8849,14912,8849,14912,9685,13398,13525,9685,1429,1493,9621,1429,5269,5333,13461,5269]) (by decide +kernel)
  change ∀ b ∈ [s13824,s13825,s3527,s13826,s6650,s13827,s13828,s13829,s8760,s10683,s11032,s13830], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13824) b13824 <|
    PetersenLocalChildren.push (x := s13825) b13825 <|
    PetersenLocalChildren.push (x := s3527) b3527 <|
    PetersenLocalChildren.push (x := s13826) b13826 <|
    PetersenLocalChildren.push (x := s6650) b6650 <|
    PetersenLocalChildren.push (x := s13827) b13827 <|
    PetersenLocalChildren.push (x := s13828) b13828 <|
    PetersenLocalChildren.push (x := s13829) b13829 <|
    PetersenLocalChildren.push (x := s8760) b8760 <|
    PetersenLocalChildren.push (x := s10683) b10683 <|
    PetersenLocalChildren.push (x := s11032) b11032 <|
    PetersenLocalChildren.push (x := s13830) b13830 <|
    PetersenLocalChildren.nil
theorem b13905 : Blocked tgt 8 s13905 := by
  apply PetersenFastNode.node (nxt := #[s13876,s13906,s572,s631,s5179,s13889,s10027,s10925,s11424,s1142,s13907,s12369,s13908,s2987]) (hints := [6850,6334,0,9687,1,9687,8911,8911,2,3,7488,4,7488,5,2707,11479,2707,11479,4755,13527,4755,13527,8851,6,8851,7,6850,9687,8,9687,5944,6850,6072,6850,9,10,6850,7488,11,7488,6850,7480,11479,7480,11479,13656,13527,13656,13527,13624,8723,13624,6850,9687,5688,5686,9687,9687,12,915,9687,8655,8663,9679,8655,9687,7224,11479,9687,9687,13400,13527,9687,1431,1495,9623,1431,10846,5944,5944,10846,6976,4920,7488,6976,11479,2707,11479,2707,13527,4755,13527,4755,5944,8851,13624,8851,13,7488,1683,1683,11479,7480,11479,7480,13527,13656,13527,13656,8851,13624,8851,13624,10447,10455,10447,11471,12495,12503,12495,13519,8851,3424,8851,7488,11479,3384,13527,11479,3223,3287,11415,3223,5271,5335,13463,5271]) (by decide +kernel)
  change ∀ b ∈ [s13876,s13906,s572,s631,s5179,s13889,s10027,s10925,s11424,s1142,s13907,s12369,s13908,s2987], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13876) b13876 <|
    PetersenLocalChildren.push (x := s13906) b13906 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s631) b631 <|
    PetersenLocalChildren.push (x := s5179) b5179 <|
    PetersenLocalChildren.push (x := s13889) b13889 <|
    PetersenLocalChildren.push (x := s10027) b10027 <|
    PetersenLocalChildren.push (x := s10925) b10925 <|
    PetersenLocalChildren.push (x := s11424) b11424 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s13907) b13907 <|
    PetersenLocalChildren.push (x := s12369) b12369 <|
    PetersenLocalChildren.push (x := s13908) b13908 <|
    PetersenLocalChildren.push (x := s2987) b2987 <|
    PetersenLocalChildren.nil
theorem b13922 : Blocked tgt 8 s13922 := by
  apply PetersenFastNode.node (nxt := #[s572,s13923,s3538,s13924,s8774,s10633,s1142,s13925]) (hints := [0,1,6844,6328,909,9681,909,9681,5938,9937,7482,2,7482,3,7474,11473,7474,11473,13650,13521,13650,13521,13618,4,13618,5,6844,6,9681,7,9681,6972,10840,5938,10840,5938,1677,7482,1677,7482,11473,7474,11473,7474,13521,13650,13521,13650,8845,13618,8845,13618,6844,9681,7100,9681,5938,6844,6840,7482,1677,7482,6844,7474,11473,7474,11473,13650,13521,13650,13521,13618,8717,13618,6844,9681,5682,5680,9681,8649,8657,9673,8649,9681,7218,11473,9681,9681,13394,13521,9681,1425,1489,9617,1425,6970,4914,7482,6970,11473,4922,11473,5938,13521,1842,13521,10066,5938,1874,13618,5938,10441,10449,10441,11465,12489,12497,12489,13513,7482,3418,14650,7482,11473,3378,13521,11473,3217,3281,11409,3217,5265,5329,13457,5265]) (by decide +kernel)
  change ∀ b ∈ [s572,s13923,s3538,s13924,s8774,s10633,s1142,s13925], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s13923) b13923 <|
    PetersenLocalChildren.push (x := s3538) b3538 <|
    PetersenLocalChildren.push (x := s13924) b13924 <|
    PetersenLocalChildren.push (x := s8774) b8774 <|
    PetersenLocalChildren.push (x := s10633) b10633 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s13925) b13925 <|
    PetersenLocalChildren.nil
theorem b13934 : Blocked tgt 8 s13934 := by
  apply PetersenFastNode.node (nxt := #[s4303,s13935,s538,s13882,s7650,s13936,s13937,s1597,s8784,s10645,s12381,s11063,s13938]) (hints := [6849,5301,9942,9942,7231,0,7231,1,6977,2,6977,3,2706,11478,2706,11478,13399,4,13399,5,6,9686,7,9686,8850,8,8850,9,5685,6849,5813,6849,10,7231,6849,6849,11,6977,6849,4785,11478,6833,11478,2721,6849,6849,2721,2721,9686,6849,9686,6849,8722,14913,6849,6975,4917,7231,6975,10845,5685,5685,6973,11478,2706,11478,2706,10071,1845,13399,10071,9686,5685,9686,9813,5685,8850,13365,8850,1682,1682,10446,11478,10446,11478,11615,3391,14687,11615,8662,8662,7231,9686,8850,3423,8850,7231,10446,11478,10446,11478,2881,2881,6977,13399,12,9686,8654,9686,8850,13365,8850,6977,11478,3381,13399,11478,9686,7221,9686,11478,3222,3286,11414,3222,9686,13526,8850,14913,8850,14913,1430,1494,9622,1430]) (by decide +kernel)
  change ∀ b ∈ [s4303,s13935,s538,s13882,s7650,s13936,s13937,s1597,s8784,s10645,s12381,s11063,s13938], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4303) b4303 <|
    PetersenLocalChildren.push (x := s13935) b13935 <|
    PetersenLocalChildren.push (x := s538) b538 <|
    PetersenLocalChildren.push (x := s13882) b13882 <|
    PetersenLocalChildren.push (x := s7650) b7650 <|
    PetersenLocalChildren.push (x := s13936) b13936 <|
    PetersenLocalChildren.push (x := s13937) b13937 <|
    PetersenLocalChildren.push (x := s1597) b1597 <|
    PetersenLocalChildren.push (x := s8784) b8784 <|
    PetersenLocalChildren.push (x := s10645) b10645 <|
    PetersenLocalChildren.push (x := s12381) b12381 <|
    PetersenLocalChildren.push (x := s11063) b11063 <|
    PetersenLocalChildren.push (x := s13938) b13938 <|
    PetersenLocalChildren.nil
theorem b13940 : Blocked tgt 8 s13940 := by
  apply PetersenFastNode.node (nxt := #[s13941,s1604,s592,s13885,s2244,s13942,s8790,s10647,s11430,s13943,s13944]) (hints := [5557,5557,0,9684,1,9684,9940,9940,1680,2,1680,3,7485,4,7485,5,2704,11476,2704,11476,4752,13524,4752,13524,8848,6,8848,7,6847,9684,8,9684,4917,6847,5045,6847,1552,7743,6847,7485,6847,7485,9,7477,11476,7477,11476,13653,13524,13653,13524,13621,8720,13621,6847,9684,4917,4915,9684,9684,8652,8660,8660,9684,7485,9684,7221,11476,9684,9684,13397,13524,9684,1428,1492,9620,1428,7231,1680,4917,1680,6973,6973,11476,2704,11476,2704,13524,4752,13524,4752,4917,8848,13109,8848,10,1680,1680,7485,10444,11476,10444,11476,12492,13524,12492,13524,1680,13621,8848,1680,10444,11476,10444,11476,12492,13524,12492,13524,7485,8848,14653,8848,11476,3381,13524,11476,3220,3284,11412,3220,5268,5332,13460,5268]) (by decide +kernel)
  change ∀ b ∈ [s13941,s1604,s592,s13885,s2244,s13942,s8790,s10647,s11430,s13943,s13944], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s13941) b13941 <|
    PetersenLocalChildren.push (x := s1604) b1604 <|
    PetersenLocalChildren.push (x := s592) b592 <|
    PetersenLocalChildren.push (x := s13885) b13885 <|
    PetersenLocalChildren.push (x := s2244) b2244 <|
    PetersenLocalChildren.push (x := s13942) b13942 <|
    PetersenLocalChildren.push (x := s8790) b8790 <|
    PetersenLocalChildren.push (x := s10647) b10647 <|
    PetersenLocalChildren.push (x := s11430) b11430 <|
    PetersenLocalChildren.push (x := s13943) b13943 <|
    PetersenLocalChildren.push (x := s13944) b13944 <|
    PetersenLocalChildren.nil
theorem b14562 : Blocked tgt 8 s14562 := by
  apply PetersenFastNode.node (nxt := #[s14563,s14564,s14569,s14570,s3813,s14571,s14572,s14573,s14574,s14575,s14576,s14577,s14578,s14579,s868,s14580,s14581,s2139,s14582,s14583,s14584,s14585,s14586,s14587,s7753,s14588,s14589,s14590,s9022,s9625,s14591,s14592,s10761,s14593,s14594,s11188,s14595,s14596,s14597,s13199,s14598]) (hints := [1710,1710,0,1,2,3,4,5,6,1710,1710,7,7515,7515,8,6877,1710,6877,1582,1710,9,7515,7515,6877,8682,1710,8682,942,7515,942,8682,7515,8682,942,1710,942,7515,7515,5963,1710,1710,7003,1710,1710,5963,7003,7515,7003,11498,1710,11498,2734,7515,2734,10474,7515,11498,10474,1710,2734,12522,1710,12522,4782,7515,4782,12522,7515,12522,1710,1710,4782,1710,1710,12619,8878,11643,8878,3451,11643,12619,1710,1710,8878,6619,10,6877,6619,11,12,942,13,942,8682,14,8682,942,15,942,8682,16,8682,7003,10,7003,9962,17,18,2734,19,2734,11498,20,11498,2734,21,2734,11498,22,11498,4782,23,4782,12522,24,12522,4782,25,4782,12522,26,12522,8878,27,8878,28,29,30,8878,31,8878,32,33,34,6877,6877,7005,814,35,942,7005,36,7005,6877,6877,942,7003,12,7003,6877,6877,18,7131,37,38,4813,4813,7499,4829,6877,2734,6861,6877,7499,4813,4813,2734,14715,2749,14715,2781,6877,4782,14715,6877,14715,2749,2749,4782,14683,6877,14683,8750,39,8878,14683,40,14683,6877,6877,8878,10873,8682,10873,942,942,7003,942,942,10873,7001,8682,7003,942,942,2734,4957,7005,7499,2734,7005,2734,942,942,7499,942,942,4782,2909,7005,14715,4782,7005,4782,942,942,14715,942,942,8878,14427,8682,14683,8878,8682,8878,942,942,14683,4955,5963,11498,2734,7003,2734,7003,7003,11498,2734,5963,2734,11131,11131,14715,4782,7003,4782,14715,7003,14715,4782,11131,4782,7003,7003,14683,8878,11131,8878,14683,11131,14683,8878,7003,8878,2734,2734,4782,14715,7499,14715,4782,7499,4782,2734,2734,14715,2734,2734,8878,14683,11498,14683,8878,11498,8878,2734,2734,14683,4782,4782,8878,14683,14715,14683,8878,14715,8878,4782,4782,14683]) (by decide +kernel)
  change ∀ b ∈ [s14563,s14564,s14569,s14570,s3813,s14571,s14572,s14573,s14574,s14575,s14576,s14577,s14578,s14579,s868,s14580,s14581,s2139,s14582,s14583,s14584,s14585,s14586,s14587,s7753,s14588,s14589,s14590,s9022,s9625,s14591,s14592,s10761,s14593,s14594,s11188,s14595,s14596,s14597,s13199,s14598], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s14563) b14563 <|
    PetersenLocalChildren.push (x := s14564) b14564 <|
    PetersenLocalChildren.push (x := s14569) b14569 <|
    PetersenLocalChildren.push (x := s14570) b14570 <|
    PetersenLocalChildren.push (x := s3813) b3813 <|
    PetersenLocalChildren.push (x := s14571) b14571 <|
    PetersenLocalChildren.push (x := s14572) b14572 <|
    PetersenLocalChildren.push (x := s14573) b14573 <|
    PetersenLocalChildren.push (x := s14574) b14574 <|
    PetersenLocalChildren.push (x := s14575) b14575 <|
    PetersenLocalChildren.push (x := s14576) b14576 <|
    PetersenLocalChildren.push (x := s14577) b14577 <|
    PetersenLocalChildren.push (x := s14578) b14578 <|
    PetersenLocalChildren.push (x := s14579) b14579 <|
    PetersenLocalChildren.push (x := s868) b868 <|
    PetersenLocalChildren.push (x := s14580) b14580 <|
    PetersenLocalChildren.push (x := s14581) b14581 <|
    PetersenLocalChildren.push (x := s2139) b2139 <|
    PetersenLocalChildren.push (x := s14582) b14582 <|
    PetersenLocalChildren.push (x := s14583) b14583 <|
    PetersenLocalChildren.push (x := s14584) b14584 <|
    PetersenLocalChildren.push (x := s14585) b14585 <|
    PetersenLocalChildren.push (x := s14586) b14586 <|
    PetersenLocalChildren.push (x := s14587) b14587 <|
    PetersenLocalChildren.push (x := s7753) b7753 <|
    PetersenLocalChildren.push (x := s14588) b14588 <|
    PetersenLocalChildren.push (x := s14589) b14589 <|
    PetersenLocalChildren.push (x := s14590) b14590 <|
    PetersenLocalChildren.push (x := s9022) b9022 <|
    PetersenLocalChildren.push (x := s9625) b9625 <|
    PetersenLocalChildren.push (x := s14591) b14591 <|
    PetersenLocalChildren.push (x := s14592) b14592 <|
    PetersenLocalChildren.push (x := s10761) b10761 <|
    PetersenLocalChildren.push (x := s14593) b14593 <|
    PetersenLocalChildren.push (x := s14594) b14594 <|
    PetersenLocalChildren.push (x := s11188) b11188 <|
    PetersenLocalChildren.push (x := s14595) b14595 <|
    PetersenLocalChildren.push (x := s14596) b14596 <|
    PetersenLocalChildren.push (x := s14597) b14597 <|
    PetersenLocalChildren.push (x := s13199) b13199 <|
    PetersenLocalChildren.push (x := s14598) b14598 <|
    PetersenLocalChildren.nil
theorem b14961 : Blocked tgt 8 s14961 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,12,13,14,15,40,41,42,43,44,45,46,47,104,105,106,107,44,45,46,47,24,25,26,27,28,29,30,31,88,89,90,91,28,29,30,31,56,57,58,59,60,61,62,63,120,121,122,123,60,61,62,63] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,68,69,70,71,40,41,42,43,44,45,46,47,104,105,106,107,100,101,102,103,24,25,26,27,28,29,30,31,88,89,90,91,84,85,86,87,56,57,58,59,60,61,62,63,120,121,122,123,116,117,118,119] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xfffffffffffffffff0f0f0f0f0f0f0f0,0xfff0fff0fff0fff0fff0fff0fff0fff0),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffffffffff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s14350) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b14350
theorem b15284 : Blocked tgt 8 s15284 := by
  apply PetersenFastNode.node (nxt := #[s572,s15285,s4094,s15286,s9231,s15287,s5421,s15288,s15291]) (hints := [0,1,6587,6587,910,9682,910,9682,5939,9938,11611,2,11611,3,7475,11474,7475,11474,13651,13522,13651,13522,13619,4,13619,5,6845,6,9682,7,9682,8,6971,5939,6971,5939,1678,11611,1678,7483,11474,7475,11474,7475,13522,13651,13522,13651,8846,13619,8846,13619,6845,9682,6973,9682,5939,6845,7099,11611,1678,11611,6845,7475,11474,7475,11474,13651,13522,13651,13522,13619,8846,13619,6845,9682,5683,5681,9682,8650,8658,9674,8650,9682,7219,11474,9682,9682,13395,13522,9682,1426,1490,9618,1426,11099,5939,11611,11099,11474,9051,11474,5939,13522,1843,13522,10067,5939,1875,13619,5939,10442,10450,10442,11466,12490,12498,12490,13514,3419,3419,11611,13619,11474,3379,13522,11474,3218,3282,11410,3218,5266,5330,13458,5266]) (by decide +kernel)
  change ∀ b ∈ [s572,s15285,s4094,s15286,s9231,s15287,s5421,s15288,s15291], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s15285) b15285 <|
    PetersenLocalChildren.push (x := s4094) b4094 <|
    PetersenLocalChildren.push (x := s15286) b15286 <|
    PetersenLocalChildren.push (x := s9231) b9231 <|
    PetersenLocalChildren.push (x := s15287) b15287 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s15288) b15288 <|
    PetersenLocalChildren.push (x := s15291) b15291 <|
    PetersenLocalChildren.nil

theorem b15420 : Blocked tgt 8 s15420 := by
  apply PetersenFastNode.node (nxt := #[s15421,s6876,s6907,s2571,s4158,s15422,s6832,s15423,s7862,s15424,s9298,s15425,s15426,s15427,s15428,s15433]) (hints := [0,1,2,3,5562,5562,917,9689,917,9689,9945,9945,7490,4,7490,5,7482,6,7482,7,14690,8,14690,9,13626,10,13626,11,6852,12,6852,13,9689,14,9689,15,5946,5946,1685,7490,1685,7490,2709,7482,11481,11481,4757,14690,13529,13529,8853,13626,8853,13626,6852,9689,6980,9689,10074,6852,10202,7490,1557,7490,6852,7482,4804,7482,4788,14690,2756,14690,2724,13626,8725,13626,6852,9689,917,917,9689,8657,8665,9681,8657,9689,7226,7224,9689,9689,14434,14432,9689,1433,1497,9625,1433,7490,1685,7490,1685,7482,2709,7482,2709,14690,4757,14690,4757,13626,8853,13626,8853,1685,7482,7474,7474,11618,3394,14690,11618,7490,3426,14658,7490,3386,3386,7482,14690,7482,12610,13626,7482,4757,13626,14626,13626]) (by decide +kernel)
  change ∀ b ∈ [s15421,s6876,s6907,s2571,s4158,s15422,s6832,s15423,s7862,s15424,s9298,s15425,s15426,s15427,s15428,s15433], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s15421) b15421 <|
    PetersenLocalChildren.push (x := s6876) b6876 <|
    PetersenLocalChildren.push (x := s6907) b6907 <|
    PetersenLocalChildren.push (x := s2571) b2571 <|
    PetersenLocalChildren.push (x := s4158) b4158 <|
    PetersenLocalChildren.push (x := s15422) b15422 <|
    PetersenLocalChildren.push (x := s6832) b6832 <|
    PetersenLocalChildren.push (x := s15423) b15423 <|
    PetersenLocalChildren.push (x := s7862) b7862 <|
    PetersenLocalChildren.push (x := s15424) b15424 <|
    PetersenLocalChildren.push (x := s9298) b9298 <|
    PetersenLocalChildren.push (x := s15425) b15425 <|
    PetersenLocalChildren.push (x := s15426) b15426 <|
    PetersenLocalChildren.push (x := s15427) b15427 <|
    PetersenLocalChildren.push (x := s15428) b15428 <|
    PetersenLocalChildren.push (x := s15433) b15433 <|
    PetersenLocalChildren.nil
private theorem thetaPair136i0 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word17) := by
  refine PetersenLocalChildren.pair_close (bank := #[s137,s138,s139,s7,s9]) (hints := [5551,5551,6841,0,1,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s137,s138,s139,s7,s9], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s137) (b137) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s138) (b138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s139) (b139) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7) (b7) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9) (b9) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i1 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s140,s141,s142,s143]) (hints := [905,5292,905,0,5294,5550,9677,1,905,5550,905,2,5292,5292,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s140,s141,s142,s143], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s140) (b140) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s141) (b141) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s142) (b142) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s143) (b143) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i2 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s137,s57,s144,s145]) (hints := [5550,5550,5934,0,9805,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s137,s57,s144,s145], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s137) (b137) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s57) (b57) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s144) (b144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s145) (b145) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i3 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s146,s147,s148,s149,s150,s151]) (hints := [1675,6584,1675,0,4528,5552,1,2,1675,5552,1675,3,6584,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s146,s147,s148,s149,s150,s151], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s146) (b146) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s147) (b147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s148) (b148) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s149) (b149) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s150) (b150) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s151) (b151) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i4 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s152,s153,s154,s155]) (hints := [2697,5550,2697,0,4534,6582,11469,1,2697,6582,2697,2,5550,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s152,s153,s154,s155], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s152) (b152) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s153) (b153) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s154) (b154) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s155) (b155) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i5 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s156,s157,s158,s159]) (hints := [4745,9678,4745,0,1454,5550,13517,1,4745,5550,4745,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s156,s157,s158,s159], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s156) (b156) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s157) (b157) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s158) (b158) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s159) (b159) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i6 : PetersenLocalChildren.PairOK tgt 8 s136 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s160,s161,s162,s163,s164,s165]) (hints := [8843,5552,8843,0,1488,9680,1,2,8843,9680,8843,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s160,s161,s162,s163,s164,s165], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s160) (b160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s161) (b161) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s162) (b162) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s163) (b163) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s164) (b164) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s165) (b165) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i7 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s166,s167,s196,s197,s198,s199]) (hints := [9679,6842,9679,0,779,1,907,2,9679,3,9679,4,6842,6842,907,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s166,s167,s196,s197,s198,s199], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s166) (b166) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s167) (b167) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s196) (b196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s197) (b197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s198) (b198) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s199) (b199) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i8 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s137,s200,s201,s202]) (hints := [5934,6840,5934,0,6062,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s137,s200,s201,s202], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s137) (b137) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s200) (b200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s201) (b201) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s202) (b202) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i9 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s203,s204,s230,s231,s232,s233]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s203,s204,s230,s231,s232,s233], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s203) (b203) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s204) (b204) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s230) (b230) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s231) (b231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s232) (b232) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s233) (b233) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i10 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s234,s235,s236,s237]) (hints := [11469,4776,11469,0,4792,6840,2697,1,11469,6840,11469,2,4776,4776,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s234,s235,s236,s237], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s234) (b234) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s235) (b235) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s236) (b236) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s237) (b237) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i11 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s238,s239,s240,s241]) (hints := [13517,2712,13517,0,2744,6840,4745,1,13517,6840,13517,2,2712,2712,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s238,s239,s240,s241], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s238) (b238) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s239) (b239) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s240) (b240) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s241) (b241) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i12 : PetersenLocalChildren.PairOK tgt 8 s136 (word17,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s242,s243,s268,s269,s270,s271]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s242,s243,s268,s269,s270,s271], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s242) (b242) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s243) (b243) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s268) (b268) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s269) (b269) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s270) (b270) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s271) (b271) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i13 : PetersenLocalChildren.PairOK tgt 8 s136 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s272,s273,s274,s275]) (hints := [9677,9677,5676,0,905,905,5934,1,905,905,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s272,s273,s274,s275], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s272) (b272) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s273) (b273) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s274) (b274) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s275) (b275) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i14 : PetersenLocalChildren.PairOK tgt 8 s136 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s276,s277,s278,s279]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s276,s277,s278,s279], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s276) (b276) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s277) (b277) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s278) (b278) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s279) (b279) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i15 : PetersenLocalChildren.PairOK tgt 8 s136 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s280,s281,s282,s283]) (hints := [9677,9677,11469,0,4920,6968,7470,1,11469,6968,11469,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s280,s281,s282,s283], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s280) (b280) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s281) (b281) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s282) (b282) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s283) (b283) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i16 : PetersenLocalChildren.PairOK tgt 8 s136 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s284,s285,s286,s287]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s284,s285,s286,s287], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s284) (b284) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s285) (b285) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s286) (b286) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s287) (b287) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i17 : PetersenLocalChildren.PairOK tgt 8 s136 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s288,s289,s290,s291]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s288,s289,s290,s291], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s288) (b288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s289) (b289) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s290) (b290) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s291) (b291) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i18 : PetersenLocalChildren.PairOK tgt 8 s136 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s292,s293,s294,s295]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s292,s293,s294,s295], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s292) (b292) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s293) (b293) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s294) (b294) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s295) (b295) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i19 : PetersenLocalChildren.PairOK tgt 8 s136 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s296,s297,s298,s299]) (hints := [11469,5934,11469,0,2697,6966,2697,1,11469,6966,11469,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s296,s297,s298,s299], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s296) (b296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s297) (b297) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s298) (b298) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s299) (b299) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i20 : PetersenLocalChildren.PairOK tgt 8 s136 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s300,s301,s302,s303]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s300,s301,s302,s303], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s300) (b300) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s301) (b301) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s302) (b302) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s303) (b303) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i21 : PetersenLocalChildren.PairOK tgt 8 s136 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s304,s305,s306,s307]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s304,s305,s306,s307], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s304) (b304) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s305) (b305) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s306) (b306) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s307) (b307) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i22 : PetersenLocalChildren.PairOK tgt 8 s136 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s308,s309,s310,s311]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s308,s309,s310,s311], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s308) (b308) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s309) (b309) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s310) (b310) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s311) (b311) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i23 : PetersenLocalChildren.PairOK tgt 8 s136 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s312,s313,s314,s315]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s312,s313,s314,s315], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s312) (b312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s313) (b313) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s314) (b314) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s315) (b315) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i24 : PetersenLocalChildren.PairOK tgt 8 s136 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s316,s317,s318,s319]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s316,s317,s318,s319], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s316) (b316) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s317) (b317) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s318) (b318) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s319) (b319) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i25 : PetersenLocalChildren.PairOK tgt 8 s136 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s320,s321,s322,s323]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s320,s321,s322,s323], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s320) (b320) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s321) (b321) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s322) (b322) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s323) (b323) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i26 : PetersenLocalChildren.PairOK tgt 8 s136 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s324,s325,s326,s327]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s324,s325,s326,s327], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s324) (b324) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s325) (b325) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s326) (b326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s327) (b327) <|
    PetersenLocalChildren.nil
private theorem thetaPair136i27 : PetersenLocalChildren.PairOK tgt 8 s136 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s328,s329,s330,s331]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s328,s329,s330,s331], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s328) (b328) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s329) (b329) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s330) (b330) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s331) (b331) <|
    PetersenLocalChildren.nil
theorem b136 : Blocked tgt 9 s136 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word17),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word17,word1),(word17,word0),(word17,word6),(word17,word5),(word17,word2),(word17,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s136 p
  exact
    PetersenLocalChildren.push thetaPair136i0 <|
    PetersenLocalChildren.push thetaPair136i1 <|
    PetersenLocalChildren.push thetaPair136i2 <|
    PetersenLocalChildren.push thetaPair136i3 <|
    PetersenLocalChildren.push thetaPair136i4 <|
    PetersenLocalChildren.push thetaPair136i5 <|
    PetersenLocalChildren.push thetaPair136i6 <|
    PetersenLocalChildren.push thetaPair136i7 <|
    PetersenLocalChildren.push thetaPair136i8 <|
    PetersenLocalChildren.push thetaPair136i9 <|
    PetersenLocalChildren.push thetaPair136i10 <|
    PetersenLocalChildren.push thetaPair136i11 <|
    PetersenLocalChildren.push thetaPair136i12 <|
    PetersenLocalChildren.push thetaPair136i13 <|
    PetersenLocalChildren.push thetaPair136i14 <|
    PetersenLocalChildren.push thetaPair136i15 <|
    PetersenLocalChildren.push thetaPair136i16 <|
    PetersenLocalChildren.push thetaPair136i17 <|
    PetersenLocalChildren.push thetaPair136i18 <|
    PetersenLocalChildren.push thetaPair136i19 <|
    PetersenLocalChildren.push thetaPair136i20 <|
    PetersenLocalChildren.push thetaPair136i21 <|
    PetersenLocalChildren.push thetaPair136i22 <|
    PetersenLocalChildren.push thetaPair136i23 <|
    PetersenLocalChildren.push thetaPair136i24 <|
    PetersenLocalChildren.push thetaPair136i25 <|
    PetersenLocalChildren.push thetaPair136i26 <|
    PetersenLocalChildren.push thetaPair136i27 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
