import M191ResidualC7A0G1
import M191ResidualC7A0G32
import M191ResidualC7A0G4
import M191ResidualC7A0G8
import M191StagedF0X2Z1G0
import M191StagedF0X2Z1G1
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G16
import M191StagedF0X2Z1G2
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G24
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G78
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows4
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows45
import M191StartPreferredRows5
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows59
import M191StartPreferredRows60
import M191StartPreferredRows64
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows7
import M191StartPreferredRows8
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2780 : Blocked tgt 7 s2780 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,9,74,11,13,13,15,15,40,41,42,43,44,45,46,47,104,41,106,43,45,45,47,47,24,25,26,27,28,29,30,31,88,25,90,27,29,29,31,31,56,57,58,59,60,61,62,63,120,57,122,59,61,61,63,63] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,65,74,67,69,69,71,71,40,41,42,43,44,44,46,46,104,97,106,99,101,101,103,103,24,25,26,27,28,28,30,30,88,81,90,83,85,85,87,87,56,57,58,59,60,60,62,62,120,113,122,115,117,117,119,119] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa),(0xffffffffffffffffff00ff00ff00ff00,0xffffffffffffffffff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2740) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2740
theorem b2877 : Blocked tgt 7 s2877 := by
  apply PetersenFastNode.node (nxt := #[s2878,s2741,s2781,s2879]) (hints := [6328,9677,6584,9677,9805,9805,0,9933,5934,6062,11606,1,11606,6328,7470,11469,7470,11469,13646,13517,13646,13517,13614,2,13614,6328,9677,3,9933,9677,5676,9677,9677,5932,8645,8653,9669,8645,9677,7214,11469,9677,9677,13390,13517,9677,1421,1485,9613,1421,6966,9933,9933,5934,8901,8909,9925,8901,9933,7470,11469,9933,9933,13646,13517,9933,1677,1741,9869,1677,11094,5934,11606,11094,5934,11469,7470,11469,10062,13517,13646,13517,5934,1870,13614,5934,10437,10445,10437,11461,12485,12493,12485,13509,3414,3414,11606,13614,11469,3374,13517,11469,3213,3277,11405,3213,5261,5325,13453,5261]) (by decide +kernel)
  change ∀ b ∈ [s2878,s2741,s2781,s2879], Blocked tgt 6 b
  exact
    PetersenLocalChildren.push (x := s2878) b2878 <|
    PetersenLocalChildren.push (x := s2741) b2741 <|
    PetersenLocalChildren.push (x := s2781) b2781 <|
    PetersenLocalChildren.push (x := s2879) b2879 <|
    PetersenLocalChildren.nil
theorem b13289 : Blocked tgt 7 s13289 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,68,70,70,32,33,34,35,36,37,38,39,96,33,98,35,100,100,102,102,16,17,18,19,20,21,22,23,80,17,82,19,84,84,86,86,48,49,50,51,52,53,54,55,112,49,114,51,116,116,118,118,8,9,10,11,12,13,14,15,72,9,74,11,13,13,15,15,40,41,42,43,44,45,46,47,104,41,106,43,45,45,47,47,24,25,26,27,28,29,30,31,88,25,90,27,29,29,31,31,56,57,58,59,60,61,62,63,120,57,122,59,61,61,63,63] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,12,14,14,72,65,74,67,69,69,71,71,40,33,42,35,44,44,46,46,104,97,106,99,101,101,103,103,24,17,26,19,28,28,30,30,88,81,90,83,85,85,87,87,56,49,58,51,60,60,62,62,120,113,122,115,117,117,119,119] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f5f500f500f500f500,0xf5f5f5f5f5f5f5f5f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12583) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12583
theorem b13473 : Blocked tgt 7 s13473 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,13,78,15,40,41,42,43,44,45,46,47,104,41,106,43,108,45,110,47,24,25,26,27,28,29,30,31,88,25,90,27,92,29,94,31,56,57,58,59,60,61,62,63,120,57,122,59,124,61,126,63] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,69,78,71,40,33,42,35,44,45,46,47,104,97,106,99,108,101,110,103,24,17,26,19,28,29,30,31,88,81,90,83,92,85,94,87,56,49,58,51,60,61,62,63,120,113,122,115,124,117,126,119] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f5f500f500f500f500,0xf5f5f5f5f5f5f5f5f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s12767) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b12767
theorem b15219 : Blocked tgt 7 s15219 := by
  apply PetersenFastNode.node (nxt := #[s2879,s15220,s12769,s15221,s13475,s15222,s15223,s15225,s14354,s15226,s14965,s15227,s15228,s15229,s15230,s15231,s15232,s15233,s15234,s15235]) (hints := [5564,5564,5692,6344,6856,0,5692,6856,5692,5564,5564,1,6856,6856,6984,793,5564,921,6984,5564,6984,6856,6856,921,6856,6856,7238,4540,5564,2,7238,5564,7238,6856,6856,3,4792,4792,7228,4808,6856,2713,6840,6856,7228,4792,4792,2713,2728,2728,13404,2760,6856,4761,6824,6856,13404,2728,2728,4761,6856,6856,13372,1500,9692,4,13372,9692,13372,6856,6856,5,9693,6,9693,409,5692,921,9693,5692,9693,9949,7,921,6982,6982,7238,4924,5692,8,7238,5692,7238,6982,6982,9,11485,5692,11485,2201,6982,2713,11485,6982,11485,2709,5692,2713,13533,9820,13533,4249,5692,4761,13533,5692,13533,4757,9820,4761,5692,5692,13372,1628,9820,10,13372,9820,13372,5692,5692,11,921,921,12,8669,9693,7238,1689,9693,13,921,921,7238,921,921,2713,4936,6984,7228,2713,6984,2713,921,921,7228,921,921,4761,2888,6984,13404,4761,6984,4761,921,921,13404,921,921,14,1501,9693,13372,8857,9693,15,921,921,13372,2713,16,2713,10461,7238,11485,2713,7238,2713,11477,17,11485,4761,11364,4761,12509,7238,13533,4761,7238,4761,13525,11364,13533,7238,7238,14406,3172,11364,13372,14406,11364,14406,7238,7238,13372,2713,2713,4761,3132,7228,14436,4761,7228,4761,2713,2713,14436,2713,2713,13372,3293,11485,14406,11421,11485,13372,2713,2713,14406,4761,4761,18,5341,13533,13372,13469,13533,19,4761,4761,13372]) (by decide +kernel)
  change ∀ b ∈ [s2879,s15220,s12769,s15221,s13475,s15222,s15223,s15225,s14354,s15226,s14965,s15227,s15228,s15229,s15230,s15231,s15232,s15233,s15234,s15235], Blocked tgt 6 b
  exact
    PetersenLocalChildren.push (x := s2879) b2879 <|
    PetersenLocalChildren.push (x := s15220) b15220 <|
    PetersenLocalChildren.push (x := s12769) b12769 <|
    PetersenLocalChildren.push (x := s15221) b15221 <|
    PetersenLocalChildren.push (x := s13475) b13475 <|
    PetersenLocalChildren.push (x := s15222) b15222 <|
    PetersenLocalChildren.push (x := s15223) b15223 <|
    PetersenLocalChildren.push (x := s15225) b15225 <|
    PetersenLocalChildren.push (x := s14354) b14354 <|
    PetersenLocalChildren.push (x := s15226) b15226 <|
    PetersenLocalChildren.push (x := s14965) b14965 <|
    PetersenLocalChildren.push (x := s15227) b15227 <|
    PetersenLocalChildren.push (x := s15228) b15228 <|
    PetersenLocalChildren.push (x := s15229) b15229 <|
    PetersenLocalChildren.push (x := s15230) b15230 <|
    PetersenLocalChildren.push (x := s15231) b15231 <|
    PetersenLocalChildren.push (x := s15232) b15232 <|
    PetersenLocalChildren.push (x := s15233) b15233 <|
    PetersenLocalChildren.push (x := s15234) b15234 <|
    PetersenLocalChildren.push (x := s15235) b15235 <|
    PetersenLocalChildren.nil
theorem b15274 : Blocked tgt 7 s15274 := by
  apply PetersenFastNode.node (nxt := #[s2879,s5243,s15275,s10087,s15276,s12584,s13290]) (hints := [6843,5551,5679,0,908,9680,908,9680,7225,1,7225,2,2700,11472,2700,11472,4748,13520,4748,13520,13359,3,13359,4,5679,6843,5807,6843,9680,6971,9680,6843,5,7225,6843,4779,11472,6827,11472,2715,13520,6811,13520,6843,6,13359,6843,9680,908,9680,908,6969,4911,7225,6969,11472,2700,11472,2700,13520,4748,13520,4748,5679,1615,13359,5679,8648,8656,9672,8648,9680,4923,11472,9680,9680,2875,13520,9680,1424,1488,9616,1424,10440,10448,10440,11464,12488,12496,12488,13512,7225,3159,14393,7225,11472,3119,13520,11472,3216,3280,11408,3216,5264,5328,13456,5264]) (by decide +kernel)
  change ∀ b ∈ [s2879,s5243,s15275,s10087,s15276,s12584,s13290], Blocked tgt 6 b
  exact
    PetersenLocalChildren.push (x := s2879) b2879 <|
    PetersenLocalChildren.push (x := s5243) b5243 <|
    PetersenLocalChildren.push (x := s15275) b15275 <|
    PetersenLocalChildren.push (x := s10087) b10087 <|
    PetersenLocalChildren.push (x := s15276) b15276 <|
    PetersenLocalChildren.push (x := s12584) b12584 <|
    PetersenLocalChildren.push (x := s13290) b13290 <|
    PetersenLocalChildren.nil
theorem b348 : Blocked tgt 8 s348 := by
  apply PetersenFastNode.node (nxt := #[s349,s350,s351,s352,s353,s354,s355,s356,s357,s358,s359,s361,s362,s364,s365,s366,s367,s368,s369,s370,s371,s372,s373,s374,s375,s376,s377,s378]) (hints := [10085,6864,0,9701,1,9701,2,3,4,9701,6864,9701,6864,6864,5,9957,1,9957,9829,6,7,9829,6864,9957,5574,6864,5958,5574,8,9,7502,6864,7502,1569,10,1697,7502,11,7502,6864,6864,1697,7494,4800,7494,11493,6864,11493,7494,6864,7494,11493,4800,11493,13670,2736,13670,13541,6864,13541,13670,6864,13670,13541,2736,13541,13638,6864,13638,8737,12,8865,13638,13,13638,6864,6864,8865,9701,9701,9957,417,14,15,5700,16,5700,9701,9701,5958,9701,9701,5700,5958,17,5958,8669,8669,1697,8677,9701,7502,9693,9701,1697,8669,8669,7502,9701,9701,11493,7494,18,7494,11493,19,11493,9701,9701,7494,9701,9701,13541,13670,20,13670,13541,21,13541,9701,9701,13670,1445,1445,8865,1509,9701,13638,9637,9701,8865,1445,1445,13638,5700,22,5700,9957,9957,5958,9957,9957,5700,5958,23,5958,8925,8925,1697,9949,9957,7502,8933,9957,1697,8925,8925,7502,9957,9957,2721,11493,24,11493,2209,25,2721,9957,9957,11493,9957,9957,4769,13541,26,13541,4257,27,4769,9957,9957,13541,1701,1701,8865,9893,9957,13638,1765,9957,8865,1701,1701,13638,6990,6990,7502,1697,5958,1697,7502,5958,7502,1697,6990,1697,5958,5958,7494,11493,6990,11493,7494,6990,7494,11493,5958,11493,10086,10086,13670,13541,5958,13541,13670,5958,13670,13541,10086,13541,5958,5958,13638,8865,10086,8865,13638,10086,13638,8865,5958,8865,10461,1697,10461,10469,7502,11493,10461,7502,10461,11485,1697,11493,12509,1697,12509,12517,7502,13541,12509,7502,12509,13533,1697,13541,1697,1697,8865,3438,11630,13638,8865,11630,8865,1697,1697,13638,11493,11493,13541,3398,7494,14702,13541,7494,13541,11493,11493,14702,3237,3237,8865,3301,11493,14670,11429,11493,8865,3237,3237,14670,5285,5285,8865,5349,13541,13638,13477,13541,8865,5285,5285,13638]) (by decide +kernel)
  change ∀ b ∈ [s349,s350,s351,s352,s353,s354,s355,s356,s357,s358,s359,s361,s362,s364,s365,s366,s367,s368,s369,s370,s371,s372,s373,s374,s375,s376,s377,s378], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s349) b349 <|
    PetersenLocalChildren.push (x := s350) b350 <|
    PetersenLocalChildren.push (x := s351) b351 <|
    PetersenLocalChildren.push (x := s352) b352 <|
    PetersenLocalChildren.push (x := s353) b353 <|
    PetersenLocalChildren.push (x := s354) b354 <|
    PetersenLocalChildren.push (x := s355) b355 <|
    PetersenLocalChildren.push (x := s356) b356 <|
    PetersenLocalChildren.push (x := s357) b357 <|
    PetersenLocalChildren.push (x := s358) b358 <|
    PetersenLocalChildren.push (x := s359) b359 <|
    PetersenLocalChildren.push (x := s361) b361 <|
    PetersenLocalChildren.push (x := s362) b362 <|
    PetersenLocalChildren.push (x := s364) b364 <|
    PetersenLocalChildren.push (x := s365) b365 <|
    PetersenLocalChildren.push (x := s366) b366 <|
    PetersenLocalChildren.push (x := s367) b367 <|
    PetersenLocalChildren.push (x := s368) b368 <|
    PetersenLocalChildren.push (x := s369) b369 <|
    PetersenLocalChildren.push (x := s370) b370 <|
    PetersenLocalChildren.push (x := s371) b371 <|
    PetersenLocalChildren.push (x := s372) b372 <|
    PetersenLocalChildren.push (x := s373) b373 <|
    PetersenLocalChildren.push (x := s374) b374 <|
    PetersenLocalChildren.push (x := s375) b375 <|
    PetersenLocalChildren.push (x := s376) b376 <|
    PetersenLocalChildren.push (x := s377) b377 <|
    PetersenLocalChildren.push (x := s378) b378 <|
    PetersenLocalChildren.nil
theorem b442 : Blocked tgt 8 s442 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s419) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b419
theorem b529 : Blocked tgt 8 s529 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,33,36,37,38,39,96,97,98,97,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,49,52,53,54,55,112,113,114,113,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,41,44,45,46,47,104,105,106,105,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,57,60,61,62,63,120,121,122,121,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,17,20,21,22,23,80,81,82,81,84,85,86,87,48,49,50,49,52,53,54,55,112,113,114,113,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,25,28,29,30,31,88,89,90,89,92,93,94,95,56,57,58,57,60,61,62,63,120,121,122,121,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffccccccccffffffffcccccccc,0xffffccccffffccccffffccccffffcccc),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s493) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b493
theorem b578 : Blocked tgt 8 s578 := by
  apply PetersenFastNode.node (nxt := #[s579,s580,s423,s581,s582,s426,s583,s584,s474,s585,s586,s587,s572,s588,s589,s502,s590,s538,s591,s592,s593,s594,s595,s596,s597,s598,s599,s600,s601,s602,s603,s604,s605,s606,s607,s608,s609,s610,s611,s612,s613]) (hints := [6877,6877,0,5331,5587,9714,5585,5587,1,6877,6877,9714,5587,5587,5971,9842,6877,9970,5971,6877,5971,5587,5587,9970,6619,6619,7515,4563,5587,2,7515,5587,7515,6619,6619,3,6877,6877,4,5587,5587,5,5587,5587,6,6877,6877,7,5587,5587,7507,4571,6619,2734,7507,6619,7507,5587,5587,2734,9715,9715,13683,1491,5587,4782,13683,5587,13683,9715,9715,4782,5587,5587,13651,1523,9715,8878,13651,9715,13651,5587,5587,8878,9714,9714,9970,5715,8,5971,9970,9,9970,9714,9714,5971,8682,8682,10,8690,9714,7515,9706,9714,11,8682,8682,7515,942,9714,12,942,13,14,2734,9714,2734,7251,15,7507,2734,16,2734,9714,9714,7507,4782,9714,4782,13427,17,13683,4782,18,4782,9714,9714,13683,8878,1458,8878,1522,9714,13651,8878,9714,8878,1458,1458,13651,7003,7003,7515,9970,9970,19,9962,9970,7515,9962,7003,20,8938,10873,21,9970,9970,22,9970,9970,23,10873,10873,24,9970,9970,11506,2734,7003,2734,11506,7003,11506,9970,9970,2734,9970,9970,13554,4782,5971,4782,13554,5971,13554,9970,9970,4782,1714,1714,13651,1778,9970,8878,9906,9970,13651,1714,1714,8878,1710,7515,12,1710,25,26,2734,27,2734,10482,7515,11506,2734,7515,2734,11498,28,11506,4782,11643,4782,12530,7515,13554,4782,7515,4782,13546,11643,13554,8878,7515,8878,3451,11643,13651,8878,11643,8878,7515,7515,13651,2734,29,2734,11506,30,11506,2734,31,2734,11506,32,11506,4782,33,4782,13554,34,13554,4782,35,4782,13554,36,13554,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651,2734,2734,4782,3411,7507,14715,4782,7507,4782,2734,2734,14715,2734,2734,8878,3314,11506,14683,8878,11506,8878,2734,2734,14683,4782,4782,8878,5362,13554,13651,8878,13554,8878,4782,4782,13651]) (by decide +kernel)
  change ∀ b ∈ [s579,s580,s423,s581,s582,s426,s583,s584,s474,s585,s586,s587,s572,s588,s589,s502,s590,s538,s591,s592,s593,s594,s595,s596,s597,s598,s599,s600,s601,s602,s603,s604,s605,s606,s607,s608,s609,s610,s611,s612,s613], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s579) b579 <|
    PetersenLocalChildren.push (x := s580) b580 <|
    PetersenLocalChildren.push (x := s423) b423 <|
    PetersenLocalChildren.push (x := s581) b581 <|
    PetersenLocalChildren.push (x := s582) b582 <|
    PetersenLocalChildren.push (x := s426) b426 <|
    PetersenLocalChildren.push (x := s583) b583 <|
    PetersenLocalChildren.push (x := s584) b584 <|
    PetersenLocalChildren.push (x := s474) b474 <|
    PetersenLocalChildren.push (x := s585) b585 <|
    PetersenLocalChildren.push (x := s586) b586 <|
    PetersenLocalChildren.push (x := s587) b587 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s588) b588 <|
    PetersenLocalChildren.push (x := s589) b589 <|
    PetersenLocalChildren.push (x := s502) b502 <|
    PetersenLocalChildren.push (x := s590) b590 <|
    PetersenLocalChildren.push (x := s538) b538 <|
    PetersenLocalChildren.push (x := s591) b591 <|
    PetersenLocalChildren.push (x := s592) b592 <|
    PetersenLocalChildren.push (x := s593) b593 <|
    PetersenLocalChildren.push (x := s594) b594 <|
    PetersenLocalChildren.push (x := s595) b595 <|
    PetersenLocalChildren.push (x := s596) b596 <|
    PetersenLocalChildren.push (x := s597) b597 <|
    PetersenLocalChildren.push (x := s598) b598 <|
    PetersenLocalChildren.push (x := s599) b599 <|
    PetersenLocalChildren.push (x := s600) b600 <|
    PetersenLocalChildren.push (x := s601) b601 <|
    PetersenLocalChildren.push (x := s602) b602 <|
    PetersenLocalChildren.push (x := s603) b603 <|
    PetersenLocalChildren.push (x := s604) b604 <|
    PetersenLocalChildren.push (x := s605) b605 <|
    PetersenLocalChildren.push (x := s606) b606 <|
    PetersenLocalChildren.push (x := s607) b607 <|
    PetersenLocalChildren.push (x := s608) b608 <|
    PetersenLocalChildren.push (x := s609) b609 <|
    PetersenLocalChildren.push (x := s610) b610 <|
    PetersenLocalChildren.push (x := s611) b611 <|
    PetersenLocalChildren.push (x := s612) b612 <|
    PetersenLocalChildren.push (x := s613) b613 <|
    PetersenLocalChildren.nil
theorem b1145 : Blocked tgt 8 s1145 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xcececececececececececececececece,0xcececececececececececececececece),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffaaaaaaaaaaaaaaaa,0xffaaffaaffaaffaaffaaffaaffaaffaa)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1138) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1138
theorem b1628 : Blocked tgt 8 s1628 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,64,67,68,69,68,69,32,33,34,35,36,37,38,39,96,97,96,99,100,101,100,101,16,17,18,19,20,21,22,23,80,81,80,83,84,85,84,85,48,49,50,51,52,53,54,55,112,113,112,115,116,117,116,117,8,9,10,11,12,13,14,15,72,73,72,75,76,77,76,77,40,41,42,43,44,45,46,47,104,105,104,107,108,109,108,109,24,25,26,27,28,29,30,31,88,89,88,91,92,93,92,93,56,57,58,59,60,61,62,63,120,121,120,123,124,125,124,125] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,8,11,12,13,12,13,72,73,72,75,76,77,76,77,40,41,40,43,44,45,44,45,104,105,104,107,108,109,108,109,24,25,24,27,28,29,28,29,88,89,88,91,92,93,92,93,56,57,56,59,60,61,60,61,120,121,120,123,124,125,124,125] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0x2020202020202020202020202020202,0x2020202020202020202020202020202),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffcccccccccccccccc,0xffccffccffccffccffccffccffccffcc)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s1584) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b1584
theorem b2716 : Blocked tgt 8 s2716 := by
  apply PetersenFastNode.node (nxt := #[s359,s2717,s1786,s209,s2718,s2719,s2720,s2721,s2604,s2722,s2632,s2723,s2724,s2725,s2726,s2727,s2728,s2730,s2680,s2731,s2732,s2733,s2734,s2704,s2735,s1793,s2736,s2737,s2738,s2739,s2740,s2743,s2744,s2745,s2746,s2747]) (hints := [9837,9837,937,9709,0,9709,425,1,937,9709,9837,9709,5582,9837,5966,5582,2,3,8933,8933,1577,9829,9837,4,8941,9837,1577,8933,8933,5,9837,9837,6872,6360,6,7,7502,9837,7502,11501,8,11501,7502,9,7502,9837,9837,11501,13678,9837,13678,13549,10,13549,13678,11,13678,9837,9837,13549,13646,1581,13646,9773,9837,12,13646,9837,13646,1581,1581,13,5708,14,5708,9709,9709,5966,9709,9709,5708,5964,15,5966,8677,8677,1577,8685,9709,16,9701,9709,1577,8677,8677,17,6872,7000,6872,9709,9709,18,9709,9709,6872,7000,7000,19,9709,9709,11501,4952,7000,7502,11501,7000,11501,9709,9709,7502,9709,9709,13549,2904,7000,13678,13549,7000,13549,9709,9709,13678,1453,1453,8873,1517,9709,13646,9645,9709,8873,1453,1453,13646,5070,6998,20,5070,5966,1577,5966,5966,21,6998,6998,1577,6998,6998,22,5966,5966,6872,5966,5966,23,6998,6998,6872,5966,5966,7502,11501,6998,11501,7502,6998,7502,11501,5966,11501,10094,10094,13678,13549,5966,13549,13678,5966,13678,13549,10094,13549,5966,5966,13646,1902,10094,8873,13646,10094,13646,5966,5966,8873,7510,1577,6872,7510,24,25,10469,1577,10469,10477,26,11501,10469,27,10469,11493,1577,11501,12517,1577,12517,12525,28,13549,12517,29,12517,13541,1577,13549,14678,1577,14678,13646,30,13646,14678,31,14678,13646,1577,13646,4808,4808,32,11501,6872,11501,6856,6872,33,11501,4808,11501,14710,2744,14710,13549,6872,13549,14710,6872,14710,13549,2744,13549,14678,6872,14678,13646,34,13646,14678,35,14678,13646,6872,13646,11501,11501,13549,3406,7502,14710,13549,7502,13549,11501,11501,14710,3245,3245,13646,3309,11501,14678,11437,11501,13646,3245,3245,14678,5293,5293,8873,5357,13549,13646,13485,13549,8873,5293,5293,13646]) (by decide +kernel)
  change ∀ b ∈ [s359,s2717,s1786,s209,s2718,s2719,s2720,s2721,s2604,s2722,s2632,s2723,s2724,s2725,s2726,s2727,s2728,s2730,s2680,s2731,s2732,s2733,s2734,s2704,s2735,s1793,s2736,s2737,s2738,s2739,s2740,s2743,s2744,s2745,s2746,s2747], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s359) b359 <|
    PetersenLocalChildren.push (x := s2717) b2717 <|
    PetersenLocalChildren.push (x := s1786) b1786 <|
    PetersenLocalChildren.push (x := s209) b209 <|
    PetersenLocalChildren.push (x := s2718) b2718 <|
    PetersenLocalChildren.push (x := s2719) b2719 <|
    PetersenLocalChildren.push (x := s2720) b2720 <|
    PetersenLocalChildren.push (x := s2721) b2721 <|
    PetersenLocalChildren.push (x := s2604) b2604 <|
    PetersenLocalChildren.push (x := s2722) b2722 <|
    PetersenLocalChildren.push (x := s2632) b2632 <|
    PetersenLocalChildren.push (x := s2723) b2723 <|
    PetersenLocalChildren.push (x := s2724) b2724 <|
    PetersenLocalChildren.push (x := s2725) b2725 <|
    PetersenLocalChildren.push (x := s2726) b2726 <|
    PetersenLocalChildren.push (x := s2727) b2727 <|
    PetersenLocalChildren.push (x := s2728) b2728 <|
    PetersenLocalChildren.push (x := s2730) b2730 <|
    PetersenLocalChildren.push (x := s2680) b2680 <|
    PetersenLocalChildren.push (x := s2731) b2731 <|
    PetersenLocalChildren.push (x := s2732) b2732 <|
    PetersenLocalChildren.push (x := s2733) b2733 <|
    PetersenLocalChildren.push (x := s2734) b2734 <|
    PetersenLocalChildren.push (x := s2704) b2704 <|
    PetersenLocalChildren.push (x := s2735) b2735 <|
    PetersenLocalChildren.push (x := s1793) b1793 <|
    PetersenLocalChildren.push (x := s2736) b2736 <|
    PetersenLocalChildren.push (x := s2737) b2737 <|
    PetersenLocalChildren.push (x := s2738) b2738 <|
    PetersenLocalChildren.push (x := s2739) b2739 <|
    PetersenLocalChildren.push (x := s2740) b2740 <|
    PetersenLocalChildren.push (x := s2743) b2743 <|
    PetersenLocalChildren.push (x := s2744) b2744 <|
    PetersenLocalChildren.push (x := s2745) b2745 <|
    PetersenLocalChildren.push (x := s2746) b2746 <|
    PetersenLocalChildren.push (x := s2747) b2747 <|
    PetersenLocalChildren.nil
theorem b2843 : Blocked tgt 8 s2843 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffffcccccccccccccccc,0xffccffccffccffccffccffccffccffcc)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2828) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2828
theorem b3033 : Blocked tgt 8 s3033 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2900) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2900
theorem b3090 : Blocked tgt 8 s3090 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s2957) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b2957
theorem b3145 : Blocked tgt 8 s3145 := by
  apply PetersenFastNode.node (nxt := #[s3146,s2901,s2958,s3034,s3091,s3147,s3148,s3149,s2679,s3150,s191]) (hints := [784,9684,784,9684,6847,0,9940,5557,7485,1,7485,2,7477,11476,7477,11476,13653,13524,13653,13524,13621,3,13621,4,9684,6975,9684,784,784,9684,5,9684,9684,6,8652,8660,9676,8652,9684,7477,11476,9684,9684,13653,13524,9684,1428,1492,9620,1428,7,6847,6847,8,9,6847,6847,10,6847,7485,7743,7485,4783,11476,6831,11476,2719,13524,6815,13524,6847,13621,14911,13621,5941,7485,1680,7485,1680,11476,2704,11476,2704,13524,4752,13524,4752,13621,8848,13621,8848,7485,1680,7485,1680,7477,11476,7477,11476,13653,13524,13653,13524,13621,8848,13621,8848,10444,10452,10444,11468,12492,12500,12492,13516,7485,3421,14653,7485,11476,3381,13524,11476,3220,3284,11412,3220,5268,5332,13460,5268]) (by decide +kernel)
  change ∀ b ∈ [s3146,s2901,s2958,s3034,s3091,s3147,s3148,s3149,s2679,s3150,s191], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3146) b3146 <|
    PetersenLocalChildren.push (x := s2901) b2901 <|
    PetersenLocalChildren.push (x := s2958) b2958 <|
    PetersenLocalChildren.push (x := s3034) b3034 <|
    PetersenLocalChildren.push (x := s3091) b3091 <|
    PetersenLocalChildren.push (x := s3147) b3147 <|
    PetersenLocalChildren.push (x := s3148) b3148 <|
    PetersenLocalChildren.push (x := s3149) b3149 <|
    PetersenLocalChildren.push (x := s2679) b2679 <|
    PetersenLocalChildren.push (x := s3150) b3150 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.nil
theorem b3154 : Blocked tgt 8 s3154 := by
  apply PetersenFastNode.node (nxt := #[s2909,s2965,s3155,s3042,s3101,s3156,s3157,s3158,s3159,s3160,s2704,s3161,s3162,s3163,s219]) (hints := [916,9688,916,9688,9816,5561,1556,0,1556,1,6851,2,7481,11480,7481,11480,13657,13528,13657,13528,13625,3,13625,4,9688,916,916,9688,5,9688,9688,6,8656,8664,9680,8656,6851,9688,9688,6979,9688,4931,11480,9688,9688,2883,13528,9688,1432,1496,9624,1432,5945,7,1556,8,1556,9,6851,10,6851,11480,2708,11480,2708,13528,4756,13528,4756,13625,8852,13625,8852,11,1556,12,1556,13,6851,14,6851,7481,11480,7481,11480,13657,13528,13657,13528,13625,8852,13625,8852,7489,7489,10448,10456,10448,11472,12496,12504,12496,13520,14657,13625,14657,13625,4787,11480,6835,11480,14689,13528,14689,13528,14657,13625,14657,13625,11480,3385,13528,11480,3224,3288,11416,3224,5272,5336,13464,5272]) (by decide +kernel)
  change ∀ b ∈ [s2909,s2965,s3155,s3042,s3101,s3156,s3157,s3158,s3159,s3160,s2704,s3161,s3162,s3163,s219], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2909) b2909 <|
    PetersenLocalChildren.push (x := s2965) b2965 <|
    PetersenLocalChildren.push (x := s3155) b3155 <|
    PetersenLocalChildren.push (x := s3042) b3042 <|
    PetersenLocalChildren.push (x := s3101) b3101 <|
    PetersenLocalChildren.push (x := s3156) b3156 <|
    PetersenLocalChildren.push (x := s3157) b3157 <|
    PetersenLocalChildren.push (x := s3158) b3158 <|
    PetersenLocalChildren.push (x := s3159) b3159 <|
    PetersenLocalChildren.push (x := s3160) b3160 <|
    PetersenLocalChildren.push (x := s2704) b2704 <|
    PetersenLocalChildren.push (x := s3161) b3161 <|
    PetersenLocalChildren.push (x := s3162) b3162 <|
    PetersenLocalChildren.push (x := s3163) b3163 <|
    PetersenLocalChildren.push (x := s219) b219 <|
    PetersenLocalChildren.nil
theorem b3181 : Blocked tgt 8 s3181 := by
  apply PetersenFastNode.node (nxt := #[s3182,s3183,s2918,s2977,s3051,s3110,s2798,s2711,s3184,s1962]) (hints := [6846,0,911,9683,911,9683,9939,1,1679,2,1679,3,2703,11475,2703,11475,4751,13523,4751,13523,8847,4,8847,5,6846,9683,6974,9683,6,7,6846,8,6846,1551,7742,6846,4782,11475,6830,11475,2718,13523,6814,13523,6846,8719,14910,6846,9683,911,911,9683,9683,9,8651,8659,9675,8651,9683,4926,11475,9683,9683,2878,13523,9683,1427,1491,9619,1427,5682,7226,1679,7226,1679,11475,2703,11475,2703,13523,4751,13523,4751,13362,8847,13362,8847,7226,1679,7226,1679,7218,11475,7218,11475,13394,13523,13394,13523,13362,8847,13362,8847,10443,10451,10443,11467,12491,12499,12491,13515,1679,3162,8847,1679,11475,3122,13523,11475,3219,3283,11411,3219,5267,5331,13459,5267]) (by decide +kernel)
  change ∀ b ∈ [s3182,s3183,s2918,s2977,s3051,s3110,s2798,s2711,s3184,s1962], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3182) b3182 <|
    PetersenLocalChildren.push (x := s3183) b3183 <|
    PetersenLocalChildren.push (x := s2918) b2918 <|
    PetersenLocalChildren.push (x := s2977) b2977 <|
    PetersenLocalChildren.push (x := s3051) b3051 <|
    PetersenLocalChildren.push (x := s3110) b3110 <|
    PetersenLocalChildren.push (x := s2798) b2798 <|
    PetersenLocalChildren.push (x := s2711) b2711 <|
    PetersenLocalChildren.push (x := s3184) b3184 <|
    PetersenLocalChildren.push (x := s1962) b1962 <|
    PetersenLocalChildren.nil
theorem b4379 : Blocked tgt 8 s4379 := by
  apply PetersenFastNode.node (nxt := #[s4303,s4380,s538,s4381,s4382,s4319,s4383,s4384,s4385,s607,s4354,s4386]) (hints := [6848,5302,6976,6848,5558,9813,5942,5558,4534,4534,5558,6848,6848,5558,5558,6590,5558,4800,7478,5558,9686,1462,13654,9686,2720,5558,5558,2720,5558,1494,13622,5558,9941,5686,9941,5940,6976,0,1,6976,6976,2,3,6976,2705,4928,2705,4912,2880,6976,13654,913,913,8849,13366,8849,6976,6974,9941,9933,9933,8909,9941,9941,6974,9941,2705,11477,9941,9941,1846,13654,9941,9941,5942,5942,9941,1685,1749,9877,1685,1681,1681,2705,10453,2705,11469,14686,13654,14686,13654,4,5,6,7,8849,13622,8849,13622,2705,11477,2705,11477,14686,13654,14686,13654,8,9,10,11,8849,13622,8849,13622,2705,3382,13654,2705,2705,7478,7478,2705,2705,3285,8849,2705,4753,4753,8849,13622,8849,13590,8849,13622,8849,13622]) (by decide +kernel)
  change ∀ b ∈ [s4303,s4380,s538,s4381,s4382,s4319,s4383,s4384,s4385,s607,s4354,s4386], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4303) b4303 <|
    PetersenLocalChildren.push (x := s4380) b4380 <|
    PetersenLocalChildren.push (x := s538) b538 <|
    PetersenLocalChildren.push (x := s4381) b4381 <|
    PetersenLocalChildren.push (x := s4382) b4382 <|
    PetersenLocalChildren.push (x := s4319) b4319 <|
    PetersenLocalChildren.push (x := s4383) b4383 <|
    PetersenLocalChildren.push (x := s4384) b4384 <|
    PetersenLocalChildren.push (x := s4385) b4385 <|
    PetersenLocalChildren.push (x := s607) b607 <|
    PetersenLocalChildren.push (x := s4354) b4354 <|
    PetersenLocalChildren.push (x := s4386) b4386 <|
    PetersenLocalChildren.nil
theorem b5287 : Blocked tgt 8 s5287 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xff0aff0aff0aff0aff0aff0aff0aff0a,0xffffffffffffffff0a0a0a0a0a0a0a0a),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4914) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4914
theorem b5425 : Blocked tgt 8 s5425 := by
  apply PetersenFastNode.node (nxt := #[s5426,s5427,s5428,s5429,s957,s4311,s5179,s5295,s5359,s5430,s5431,s5063,s5432,s5433]) (hints := [4536,4536,0,8663,1,8663,9943,9943,7488,2,3,4,5,6,2707,11479,2707,11479,4755,13527,4755,13527,8851,7,8851,8,6850,8663,9,8663,5944,6850,6072,7488,10,7488,6850,6850,11,12,6850,7480,11479,7480,11479,13656,13527,13656,13527,13624,8723,13624,6850,8663,5688,5686,8663,7232,8663,8663,7488,8655,8655,8663,7224,10711,8663,8663,13400,12759,8663,407,471,8599,407,6976,4920,7488,6976,10846,5944,5944,10846,11479,2707,11479,2707,13527,4755,13527,4755,5944,8851,13624,8851,13,7488,1683,1683,2707,11479,2707,11479,4755,13527,4755,13527,8851,3424,8851,7488,10447,10455,10447,11471,12495,12503,12495,13519,8851,13624,8851,13624,11479,3384,13527,11479,3223,3287,11415,3223,5271,5335,13463,5271]) (by decide +kernel)
  change ∀ b ∈ [s5426,s5427,s5428,s5429,s957,s4311,s5179,s5295,s5359,s5430,s5431,s5063,s5432,s5433], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5426) b5426 <|
    PetersenLocalChildren.push (x := s5427) b5427 <|
    PetersenLocalChildren.push (x := s5428) b5428 <|
    PetersenLocalChildren.push (x := s5429) b5429 <|
    PetersenLocalChildren.push (x := s957) b957 <|
    PetersenLocalChildren.push (x := s4311) b4311 <|
    PetersenLocalChildren.push (x := s5179) b5179 <|
    PetersenLocalChildren.push (x := s5295) b5295 <|
    PetersenLocalChildren.push (x := s5359) b5359 <|
    PetersenLocalChildren.push (x := s5430) b5430 <|
    PetersenLocalChildren.push (x := s5431) b5431 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s5432) b5432 <|
    PetersenLocalChildren.push (x := s5433) b5433 <|
    PetersenLocalChildren.nil
theorem b6256 : Blocked tgt 8 s6256 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf500f500f500f500f500f500f500f500,0xf5f5f5f5f5f5f5f50000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5347) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5347
theorem b6500 : Blocked tgt 8 s6500 := by
  apply PetersenFastNode.node (nxt := #[s6501,s6502,s5566,s6267,s6503,s6504,s1019,s6505,s6506,s6507,s6457,s6423,s6508]) (hints := [6591,6591,0,8654,1,8654,8910,8910,1682,2,2706,10446,2706,10446,4754,12494,4754,12494,13623,3,13623,4,5,6,7,8,6849,8654,9,8654,5943,6849,6071,7487,1554,7487,6849,7479,10446,7479,10446,13655,12494,13655,12494,13623,10,13623,6849,6849,11,12,6849,8654,5943,5685,8654,8654,7487,1682,8654,8654,7479,10446,8654,8654,13399,12494,8654,462,8654,13623,8654,398,6975,1682,7487,1682,10446,2706,10446,2706,12494,4754,12494,4754,5943,1879,13623,5943,5685,5943,5943,5685,10446,7479,10446,1682,12494,3391,12494,1682,1682,3423,14655,1682,1682,7487,7487,1682,10446,3383,12494,10446,2190,10446,10446,2190,2190,10446,10446,2190,4238,12494,12494,4238,4238,12494,12494,4238,8850,8850]) (by decide +kernel)
  change ∀ b ∈ [s6501,s6502,s5566,s6267,s6503,s6504,s1019,s6505,s6506,s6507,s6457,s6423,s6508], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6501) b6501 <|
    PetersenLocalChildren.push (x := s6502) b6502 <|
    PetersenLocalChildren.push (x := s5566) b5566 <|
    PetersenLocalChildren.push (x := s6267) b6267 <|
    PetersenLocalChildren.push (x := s6503) b6503 <|
    PetersenLocalChildren.push (x := s6504) b6504 <|
    PetersenLocalChildren.push (x := s1019) b1019 <|
    PetersenLocalChildren.push (x := s6505) b6505 <|
    PetersenLocalChildren.push (x := s6506) b6506 <|
    PetersenLocalChildren.push (x := s6507) b6507 <|
    PetersenLocalChildren.push (x := s6457) b6457 <|
    PetersenLocalChildren.push (x := s6423) b6423 <|
    PetersenLocalChildren.push (x := s6508) b6508 <|
    PetersenLocalChildren.nil
theorem b7649 : Blocked tgt 8 s7649 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff0a0a0a0affffffff0a0a0a0a,0xffff0a0affff0a0affff0a0affff0a0a),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s6724) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b6724
theorem b7849 : Blocked tgt 8 s7849 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,17,50,19,52,53,54,55,112,81,114,83,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,25,58,27,60,61,62,63,120,89,122,91,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,33,50,35,52,53,54,55,112,97,114,99,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,41,58,43,60,61,62,63,120,105,122,107,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff0a0a0a0affffffff0a0a0a0a,0xffff0a0affff0a0affff0a0affff0a0a),(0xffffffffffff0000ffffffffffff0000,0xffffffffffff0000ffffffffffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s6819) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b6819
theorem b8006 : Blocked tgt 8 s8006 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,12,14,14,72,73,74,75,76,76,78,78,40,41,42,43,44,44,46,46,104,105,106,107,108,108,110,110,24,25,26,27,28,28,30,30,88,89,90,91,92,92,94,94,56,57,58,59,60,60,62,62,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,68,70,70,32,33,34,35,36,37,38,39,96,97,98,99,100,100,102,102,16,17,18,19,20,21,22,23,80,81,82,83,84,84,86,86,48,49,50,51,52,53,54,55,112,113,114,115,116,116,118,118,8,9,10,11,12,13,14,15,72,73,74,75,76,76,78,78,40,41,42,43,44,45,46,47,104,105,106,107,108,108,110,110,24,25,26,27,28,29,30,31,88,89,90,91,92,92,94,94,56,57,58,59,60,61,62,63,120,121,122,123,124,124,126,126] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff0a0a0a0affffffff0a0a0a0a,0xffff0a0affff0a0affff0a0affff0a0a),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s7114) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b7114
theorem b8469 : Blocked tgt 8 s8469 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee,0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3226) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3226
theorem b8554 : Blocked tgt 8 s8554 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3421) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3421
theorem b8706 : Blocked tgt 8 s8706 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc,0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3471) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3471
theorem b8736 : Blocked tgt 8 s8736 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0x30303030303030303030303030303030,0x30303030303030303030303030303030),(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3501) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3501
theorem b8768 : Blocked tgt 8 s8768 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3675) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3675
theorem b8813 : Blocked tgt 8 s8813 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffccccffffccccffffccccffffcccc,0xffffffffccccccccffffffffcccccccc),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3641) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3641
theorem b8946 : Blocked tgt 8 s8946 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xfff0fff0fff0fff0fff0fff0fff0fff0,0xfffffffffffffffff0f0f0f0f0f0f0f0),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s3919) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b3919
theorem b9286 : Blocked tgt 8 s9286 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffff0000ffffffffffff0000,0xffffffffffff0000ffffffffffff0000),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4146) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4146
theorem b9440 : Blocked tgt 8 s9440 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffffffffffffffffaaaaaaaaaaaaaaaa),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4253) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4253
theorem b9495 : Blocked tgt 8 s9495 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,9,10,11,12,13,14,15,72,73,74,75,76,77,78,79,40,41,42,43,44,45,46,47,104,105,106,107,108,109,110,111,24,25,26,27,28,29,30,31,88,89,90,91,92,93,94,95,56,57,58,59,60,61,62,63,120,121,122,123,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffccffccffccffccffccffccffccffcc,0xffffffffffffffffcccccccccccccccc),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffffffffffff0000000000000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0a0a0a0a0a0a0a0a,0xff0aff0aff0aff0aff0aff0aff0aff0a)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s4390) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b4390
end PetersenSmallStarts.M191.Staged
