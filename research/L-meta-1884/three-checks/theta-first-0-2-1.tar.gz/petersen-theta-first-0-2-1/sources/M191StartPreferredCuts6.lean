import M191StartPreferredCommon
import M111StartLabeled
import M15StartLabeled
import M31StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r779 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small779 : NoAtMost (0x3333000033330000 :: i6) (PetersenPackedPin.project r779 tgt) 6 := by
  have a : PetersenPackedPin.project r779 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x3333000033330000 (by decide +kernel)
theorem hot779 : forcedConst r779 tgt = false := by decide +kernel
def r780 (x : Fin 16) : Fin 128 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30] : Array (Fin 128))[x.val]?.getD 0
theorem small780 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r780 tgt) 3 := by
  have a : PetersenPackedPin.project r780 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot780 : forcedConst r780 tgt = false := by decide +kernel
def r781 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small781 : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r781 tgt) 6 := by
  have a : PetersenPackedPin.project r781 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xeeeeeeee (by decide +kernel)
theorem hot781 : forcedConst r781 tgt = false := by decide +kernel
def r782 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small782 : NoAtMost (0x50505050 :: i5) (PetersenPackedPin.project r782 tgt) 6 := by
  have a : PetersenPackedPin.project r782 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x50505050 (by decide +kernel)
theorem hot782 : forcedConst r782 tgt = false := by decide +kernel
def r783 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small783 : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r783 tgt) 6 := by
  have a : PetersenPackedPin.project r783 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf000f0 (by decide +kernel)
theorem hot783 : forcedConst r783 tgt = false := by decide +kernel
def r784 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small784 : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r784 tgt) 6 := by
  have a : PetersenPackedPin.project r784 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xffffaaaa (by decide +kernel)
theorem hot784 : forcedConst r784 tgt = false := by decide +kernel
def r785 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small785 : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r785 tgt) 6 := by
  have a : PetersenPackedPin.project r785 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xfcfcfcfc (by decide +kernel)
theorem hot785 : forcedConst r785 tgt = false := by decide +kernel
def r786 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small786 : NoAtMost (0x30303030 :: i5) (PetersenPackedPin.project r786 tgt) 6 := by
  have a : PetersenPackedPin.project r786 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x30303030 (by decide +kernel)
theorem hot786 : forcedConst r786 tgt = false := by decide +kernel
def r787 (x : Fin 16) : Fin 128 := (#[0,16,1,17,32,48,33,49,64,80,65,81,96,112,97,113] : Array (Fin 128))[x.val]?.getD 0
theorem small787 : NoAtMost (0x3300 :: i4) (PetersenPackedPin.project r787 tgt) 3 := by
  have a : PetersenPackedPin.project r787 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hot787 : forcedConst r787 tgt = false := by decide +kernel
def r788 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small788 : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r788 tgt) 6 := by
  have a : PetersenPackedPin.project r788 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xfff0fff0 (by decide +kernel)
theorem hot788 : forcedConst r788 tgt = false := by decide +kernel
def r789 (x : Fin 16) : Fin 128 := (#[0,2,1,3,32,34,33,35,64,66,65,67,96,98,97,99] : Array (Fin 128))[x.val]?.getD 0
theorem small789 : NoAtMost (0x3300 :: i4) (PetersenPackedPin.project r789 tgt) 3 := by
  have a : PetersenPackedPin.project r789 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hot789 : forcedConst r789 tgt = false := by decide +kernel
def r790 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small790 : NoAtMost (0xf0f0 :: i5) (PetersenPackedPin.project r790 tgt) 6 := by
  have a : PetersenPackedPin.project r790 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf0f0 (by decide +kernel)
theorem hot790 : forcedConst r790 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
