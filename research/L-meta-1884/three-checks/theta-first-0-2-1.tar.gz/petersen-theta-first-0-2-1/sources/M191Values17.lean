import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv17_4260 : PetersenPackedPin.project r17 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv17_4814 : PetersenPackedPin.project r17 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv17_5473 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv17_6170 : PetersenPackedPin.project r17 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv17_6790 : PetersenPackedPin.project r17 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv17_7474 : PetersenPackedPin.project r17 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv17_8012 : PetersenPackedPin.project r17 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv17_351 : PetersenPackedPin.project r17 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_4260 pv17_8012 rfl rfl
theorem pv17_1343 : PetersenPackedPin.project r17 (0xffffffff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_7474 pv17_8012 rfl rfl
theorem pv17_1734 : PetersenPackedPin.project r17 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_4260 pv17_6790 rfl rfl
theorem pv17_2192 : PetersenPackedPin.project r17 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_4260 pv17_6170 rfl rfl
theorem pv17_2461 : PetersenPackedPin.project r17 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_6170 pv17_8012 rfl rfl
theorem pv17_2708 : PetersenPackedPin.project r17 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_4260 pv17_5473 rfl rfl
theorem pv17_3004 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_5473 pv17_8012 rfl rfl
theorem pv17_3157 : PetersenPackedPin.project r17 (0x22222222222222222222222222222222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_4260 pv17_4814 rfl rfl
theorem pv17_3485 : PetersenPackedPin.project r17 (0x33333333333333330000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_4814 pv17_8012 rfl rfl
theorem pv17_3677 : PetersenPackedPin.project r17 (0x55005500550055005500550055005500 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv17_4260 pv17_6170 rfl rfl
theorem pv17_3705 : PetersenPackedPin.project r17 (0x55550000555500005555000055550000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv17_4260 pv17_6790 rfl rfl
theorem pv17_4059 : PetersenPackedPin.project r17 (0xaa00aa00aa00aa00aa00aa00aa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_4260 pv17_6170 rfl rfl
theorem pv17_4109 : PetersenPackedPin.project r17 (0xaaaa0000aaaa0000aaaa0000aaaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_4260 pv17_6790 rfl rfl
theorem pv17_5425 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_5473 pv17_8012 rfl rfl
theorem pv17_5850 : PetersenPackedPin.project r17 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv17_4260 pv17_5473 rfl rfl
theorem pv17_5920 : PetersenPackedPin.project r17 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xeeee := PetersenWireProjection.derive 3 pv17_4814 pv17_5473 rfl rfl
theorem pv17_6504 : PetersenPackedPin.project r17 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_4260 pv17_6170 rfl rfl
theorem pv17_6546 : PetersenPackedPin.project r17 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xfafa := PetersenWireProjection.derive 3 pv17_4814 pv17_6170 rfl rfl
theorem pv17_6618 : PetersenPackedPin.project r17 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xfcfc := PetersenWireProjection.derive 3 pv17_5473 pv17_6170 rfl rfl
theorem pv17_7095 : PetersenPackedPin.project r17 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv17_4260 pv17_6790 rfl rfl
theorem pv17_7152 : PetersenPackedPin.project r17 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffaa := PetersenWireProjection.derive 3 pv17_4814 pv17_6790 rfl rfl
theorem pv17_7235 : PetersenPackedPin.project r17 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xffcc := PetersenWireProjection.derive 3 pv17_5473 pv17_6790 rfl rfl
theorem pv17_7688 : PetersenPackedPin.project r17 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_4260 pv17_7474 rfl rfl
theorem pv17_7855 : PetersenPackedPin.project r17 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_6170 pv17_7474 rfl rfl
theorem pv17_8191 : PetersenPackedPin.project r17 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_4260 pv17_8012 rfl rfl
theorem pv17_8208 : PetersenPackedPin.project r17 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv17_4814 pv17_8012 rfl rfl
theorem pv17_8295 : PetersenPackedPin.project r17 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_6170 pv17_8012 rfl rfl
theorem pv17_8377 : PetersenPackedPin.project r17 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_7474 pv17_8012 rfl rfl
theorem pv17_60 : PetersenPackedPin.project r17 (0xa0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_351 pv17_7235 rfl rfl
theorem pv17_64 : PetersenPackedPin.project r17 (0x222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_351 pv17_7152 rfl rfl
theorem pv17_112 : PetersenPackedPin.project r17 (0xa000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_351 pv17_6618 rfl rfl
theorem pv17_114 : PetersenPackedPin.project r17 (0x22002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_351 pv17_6546 rfl rfl
theorem pv17_348 : PetersenPackedPin.project r17 (0xaaaaaaaaaa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_351 pv17_7855 rfl rfl
theorem pv17_1366 : PetersenPackedPin.project r17 (0xffffffff00000000aaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_7474 pv17_8191 rfl rfl
theorem pv17_1401 : PetersenPackedPin.project r17 (0xa0000000a0000000a0000000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_1734 pv17_6618 rfl rfl
theorem pv17_1431 : PetersenPackedPin.project r17 (0xaa000000aa000000aa000000aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_1734 pv17_6170 rfl rfl
theorem pv17_1496 : PetersenPackedPin.project r17 (0xa0a00000a0a00000a0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_1734 pv17_5473 rfl rfl
theorem pv17_1546 : PetersenPackedPin.project r17 (0x2222000022220000222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_1734 pv17_4814 rfl rfl
theorem pv17_1991 : PetersenPackedPin.project r17 (0xffff0000ffff0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_6790 pv17_8191 rfl rfl
theorem pv17_2012 : PetersenPackedPin.project r17 (0x20002000200020002000200020002 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_2192 pv17_5920 rfl rfl
theorem pv17_2024 : PetersenPackedPin.project r17 (0xa000a000a000a000a000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_2192 pv17_5473 rfl rfl
theorem pv17_2059 : PetersenPackedPin.project r17 (0x220022002200220022002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_2192 pv17_4814 rfl rfl
theorem pv17_2477 : PetersenPackedPin.project r17 (0xff00ff00ff00ff00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_6170 pv17_8191 rfl rfl
theorem pv17_2517 : PetersenPackedPin.project r17 (0x2020202020202020202020202020202 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv17_2708 pv17_4814 rfl rfl
theorem pv17_3016 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_5473 pv17_8191 rfl rfl
theorem pv17_3502 : PetersenPackedPin.project r17 (0x33333333333333332222222222222222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_4814 pv17_8191 rfl rfl
theorem pv17_3788 : PetersenPackedPin.project r17 (0x5555aaaa5555aaaa5555aaaa5555aaaa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv17_4109 pv17_7095 rfl rfl
theorem pv17_3797 : PetersenPackedPin.project r17 (0x55aa55aa55aa55aa55aa55aa55aa55aa : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv17_4059 pv17_6504 rfl rfl
theorem pv17_5201 : PetersenPackedPin.project r17 (0xeeeecccceeeecccceeeecccceeeecccc : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv17_4109 pv17_4814 rfl rfl
theorem pv17_5562 : PetersenPackedPin.project r17 (0xf0f0fafaf0f0fafa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_1734 pv17_5425 rfl rfl
theorem pv17_5614 : PetersenPackedPin.project r17 (0xf0faf0faf0faf0faf0faf0faf0faf0fa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv17_2192 pv17_5473 rfl rfl
theorem pv17_5682 : PetersenPackedPin.project r17 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 2 pv17_2708 pv17_6170 rfl rfl
theorem pv17_6308 : PetersenPackedPin.project r17 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_2708 pv17_6170 rfl rfl
theorem pv17_7439 : PetersenPackedPin.project r17 (0xffffffff00000000aaaaaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_7474 pv17_8191 rfl rfl
theorem pv17_8059 : PetersenPackedPin.project r17 (0xffffffffffffffff0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_1734 pv17_8012 rfl rfl
theorem pv17_8079 : PetersenPackedPin.project r17 (0xffffffffffffffff00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_2192 pv17_8012 rfl rfl
theorem pv17_8104 : PetersenPackedPin.project r17 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_2708 pv17_8012 rfl rfl
theorem pv17_8388 : PetersenPackedPin.project r17 (0xffffffffffffffffffffffff00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_2192 pv17_8377 rfl rfl
theorem pv17_1349 : PetersenPackedPin.project r17 (0xffffffff000000000000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_7474 pv17_8059 rfl rfl
theorem pv17_2467 : PetersenPackedPin.project r17 (0xff00ff00ff00ff000000aa000000aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_6170 pv17_8059 rfl rfl
theorem pv17_3008 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f00000a0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_5473 pv17_8059 rfl rfl
theorem pv17_3010 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f000a000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_5473 pv17_8079 rfl rfl
theorem pv17_3491 : PetersenPackedPin.project r17 (0x33333333333333330000222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_4814 pv17_8059 rfl rfl
theorem pv17_3494 : PetersenPackedPin.project r17 (0x33333333333333330022002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv17_4814 pv17_8079 rfl rfl
theorem pv17_5433 : PetersenPackedPin.project r17 (0xf0f0f0f0f0f0f0f00000a0a00000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv17_5473 pv17_5562 rfl rfl
theorem pv17_6226 : PetersenPackedPin.project r17 (0xff00ff0aff00ff0aff00ff0aff00ff0a : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_1401 pv17_6170 rfl rfl
theorem pv17_6277 : PetersenPackedPin.project r17 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv17_2012 pv17_6170 rfl rfl
theorem pv17_8049 : PetersenPackedPin.project r17 (0xffffffffffffffff00000a0a00000a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_60 pv17_8012 rfl rfl
theorem pv17_8050 : PetersenPackedPin.project r17 (0xffffffffffffffff0000222200002222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_64 pv17_8012 rfl rfl
theorem pv17_8074 : PetersenPackedPin.project r17 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_112 pv17_8012 rfl rfl
theorem pv17_8075 : PetersenPackedPin.project r17 (0xffffffffffffffff0022002200220022 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_114 pv17_8012 rfl rfl
theorem pv17_8189 : PetersenPackedPin.project r17 (0xffffffffffffffffaaaaaaaaaa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv17_348 pv17_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
