import M191StartPreferredSignals
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G58
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows24
import M191StartPreferredRows29
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows32
import M191StartPreferredRows33
import M191StartPreferredRows35
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows48
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows55
import M191StartPreferredRows57
import M191StartPreferredRows6
import M191StartPreferredRows7
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair7142i0 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s7143,s7144,s7145,s7146]) (hints := [5551,0,6583,1,5551,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s7143,s7144,s7145,s7146], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7143) (b7143) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7144) (b7144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7145) (b7145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7146) (b7146) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i1 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7147,s7148,s7149,s7177,s1372,s7178,s7179,s7180]) (hints := [909,0,909,1,9681,2,9681,3,909,4,909,5,9681,6,9681,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s7147,s7148,s7149,s7177,s1372,s7178,s7179,s7180], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7147) (b7147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7148) (b7148) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7149) (b7149) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7177) (b7177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1372) (b1372) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7178) (b7178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7179) (b7179) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7180) (b7180) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i2 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s7143,s7181,s7215,s7216]) (hints := [9934,0,5935,1,9934,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s7143,s7181,s7215,s7216], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7143) (b7143) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7181) (b7181) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7215) (b7215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7216) (b7216) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i3 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7217,s7218,s7219,s7304,s7305,s7306,s5580,s7307,s7308,s7309,s7310,s7311]) (hints := [1681,0,1681,1,2,3,4,5,1681,6,1681,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s7217,s7218,s7219,s7304,s7305,s7306,s5580,s7307,s7308,s7309,s7310,s7311], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7217) (b7217) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7218) (b7218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7219) (b7219) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7304) (b7304) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7305) (b7305) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7306) (b7306) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5580) (b5580) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7307) (b7307) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7308) (b7308) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7309) (b7309) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7310) (b7310) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7311) (b7311) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i4 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s7143,s7312,s6815,s6817]) (hints := [2698,0,2698,1,11470,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s7143,s7312,s6815,s6817], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7143) (b7143) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7312) (b7312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6815) (b6815) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6817) (b6817) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i5 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7313,s7314,s7315,s7341,s7342,s7343,s7344,s7345]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s7313,s7314,s7315,s7341,s7342,s7343,s7344,s7345], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7313) (b7313) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7314) (b7314) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7315) (b7315) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7341) (b7341) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7342) (b7342) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7343) (b7343) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7344) (b7344) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7345) (b7345) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i6 : PetersenLocalChildren.PairOK tgt 8 s7142 (word139,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7346,s7347,s7348,s7433,s7467,s7468,s7469,s7470,s7471,s7472,s7473,s7474]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s7346,s7347,s7348,s7433,s7467,s7468,s7469,s7470,s7471,s7472,s7473,s7474], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7346) (b7346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7347) (b7347) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7348) (b7348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7433) (b7433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7467) (b7467) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7468) (b7468) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7469) (b7469) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7470) (b7470) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7471) (b7471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7472) (b7472) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7473) (b7473) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7474) (b7474) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i7 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7475,s7476,s7477,s7478]) (hints := [6840,6840,6968,0,9677,6582,9677,1,6968,6582,6968,2,9677,6840,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7475,s7476,s7477,s7478], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7475) (b7475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7476) (b7476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7477) (b7477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7478) (b7478) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i8 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7479,s2623,s3020,s7131,s7480,s7481]) (hints := [5936,6584,5936,0,6330,6842,1,2,5936,6842,5936,3,6064,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s7479,s2623,s3020,s7131,s7480,s7481], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7479) (b7479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2623) (b2623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3020) (b3020) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7131) (b7131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7480) (b7480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7481) (b7481) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i9 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7482,s7483,s7484,s7485,s7486,s7487]) (hints := [6584,6584,7480,0,1547,1,1675,2,7480,3,7480,4,6584,6584,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s7482,s7483,s7484,s7485,s7486,s7487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7482) (b7482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7483) (b7483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7484) (b7484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7485) (b7485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7486) (b7486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7487) (b7487) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i10 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7488,s7489,s7490,s7491]) (hints := [7470,4776,7470,0,6582,6582,2697,1,7470,6582,7470,2,7598,4776,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7488,s7489,s7490,s7491], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7488) (b7488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7489) (b7489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7490) (b7490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7491) (b7491) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i11 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7492,s7493,s7494,s7495]) (hints := [13646,10710,13646,0,13517,6582,13517,1,13646,6582,13646,2,13517,10710,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7492,s7493,s7494,s7495], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7492) (b7492) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7493) (b7493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7494) (b7494) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7495) (b7495) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i12 : PetersenLocalChildren.PairOK tgt 8 s7142 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7496,s7497,s7498,s7499]) (hints := [13614,6582,13614,0,2518,10710,8841,1,13614,10710,13614,2,6582,6582,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7496,s7497,s7498,s7499], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7496) (b7496) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7497) (b7497) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7498) (b7498) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7499) (b7499) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i13 : PetersenLocalChildren.PairOK tgt 8 s7142 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7500,s7501,s7502,s7503]) (hints := [9677,9677,5676,0,905,905,5934,1,905,905,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7500,s7501,s7502,s7503], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7500) (b7500) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7501) (b7501) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7502) (b7502) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7503) (b7503) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i14 : PetersenLocalChildren.PairOK tgt 8 s7142 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7504,s7505,s7506,s7507]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7504,s7505,s7506,s7507], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7504) (b7504) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7505) (b7505) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7506) (b7506) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7507) (b7507) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i15 : PetersenLocalChildren.PairOK tgt 8 s7142 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7508,s7509,s7510,s7511]) (hints := [9677,9677,2697,0,4920,6968,7470,1,2697,6968,2697,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7508,s7509,s7510,s7511], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7508) (b7508) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7509) (b7509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7510) (b7510) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7511) (b7511) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i16 : PetersenLocalChildren.PairOK tgt 8 s7142 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7512,s7513,s7514,s7515]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7512,s7513,s7514,s7515], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7512) (b7512) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7513) (b7513) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7514) (b7514) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7515) (b7515) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i17 : PetersenLocalChildren.PairOK tgt 8 s7142 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7516,s7517,s7524,s7525]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7516,s7517,s7524,s7525], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7516) (b7516) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7517) (b7517) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7524) (b7524) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7525) (b7525) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i18 : PetersenLocalChildren.PairOK tgt 8 s7142 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7526,s7527,s7528,s7529]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7526,s7527,s7528,s7529], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7526) (b7526) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7527) (b7527) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7528) (b7528) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7529) (b7529) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i19 : PetersenLocalChildren.PairOK tgt 8 s7142 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7530,s7531,s7532,s7533]) (hints := [2185,5934,7470,0,2185,6966,2697,1,7470,6966,7470,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7530,s7531,s7532,s7533], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7530) (b7530) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7531) (b7531) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7532) (b7532) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7533) (b7533) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i20 : PetersenLocalChildren.PairOK tgt 8 s7142 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7534,s7535,s7536,s7537]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7534,s7535,s7536,s7537], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7534) (b7534) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7535) (b7535) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7536) (b7536) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7537) (b7537) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i21 : PetersenLocalChildren.PairOK tgt 8 s7142 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7538,s7539,s7540,s7541]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7538,s7539,s7540,s7541], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7538) (b7538) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7539) (b7539) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7540) (b7540) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7541) (b7541) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i22 : PetersenLocalChildren.PairOK tgt 8 s7142 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7542,s7543,s7544,s7545]) (hints := [1673,1673,2697,0,7470,7478,7470,1,2697,7478,2697,2,1673,1673,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7542,s7543,s7544,s7545], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7542) (b7542) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7543) (b7543) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7544) (b7544) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7545) (b7545) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i23 : PetersenLocalChildren.PairOK tgt 8 s7142 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7546,s7547,s7548,s7549]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7546,s7547,s7548,s7549], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7546) (b7546) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7547) (b7547) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7548) (b7548) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7549) (b7549) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i24 : PetersenLocalChildren.PairOK tgt 8 s7142 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7550,s7551,s7552,s7553]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7550,s7551,s7552,s7553], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7550) (b7550) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7551) (b7551) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7552) (b7552) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7553) (b7553) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i25 : PetersenLocalChildren.PairOK tgt 8 s7142 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7554,s7555,s7556,s7557]) (hints := [13517,2697,13517,0,3374,7470,14678,1,13517,7470,13517,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7554,s7555,s7556,s7557], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7554) (b7554) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7555) (b7555) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7556) (b7556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7557) (b7557) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i26 : PetersenLocalChildren.PairOK tgt 8 s7142 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7558,s7559,s7560,s7561]) (hints := [2697,2697,8841,0,3406,11598,14646,1,8841,11598,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7558,s7559,s7560,s7561], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7558) (b7558) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7559) (b7559) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7560) (b7560) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7561) (b7561) <|
    PetersenLocalChildren.nil
private theorem thetaPair7142i27 : PetersenLocalChildren.PairOK tgt 8 s7142 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7562,s7563,s7564,s7565]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7562,s7563,s7564,s7565], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7562) (b7562) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7563) (b7563) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7564) (b7564) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7565) (b7565) <|
    PetersenLocalChildren.nil
theorem b7142 : Blocked tgt 9 s7142 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word139,word3),(word139,word1),(word139,word0),(word139,word6),(word139,word5),(word139,word2),(word139,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s7142 p
  exact
    PetersenLocalChildren.push thetaPair7142i0 <|
    PetersenLocalChildren.push thetaPair7142i1 <|
    PetersenLocalChildren.push thetaPair7142i2 <|
    PetersenLocalChildren.push thetaPair7142i3 <|
    PetersenLocalChildren.push thetaPair7142i4 <|
    PetersenLocalChildren.push thetaPair7142i5 <|
    PetersenLocalChildren.push thetaPair7142i6 <|
    PetersenLocalChildren.push thetaPair7142i7 <|
    PetersenLocalChildren.push thetaPair7142i8 <|
    PetersenLocalChildren.push thetaPair7142i9 <|
    PetersenLocalChildren.push thetaPair7142i10 <|
    PetersenLocalChildren.push thetaPair7142i11 <|
    PetersenLocalChildren.push thetaPair7142i12 <|
    PetersenLocalChildren.push thetaPair7142i13 <|
    PetersenLocalChildren.push thetaPair7142i14 <|
    PetersenLocalChildren.push thetaPair7142i15 <|
    PetersenLocalChildren.push thetaPair7142i16 <|
    PetersenLocalChildren.push thetaPair7142i17 <|
    PetersenLocalChildren.push thetaPair7142i18 <|
    PetersenLocalChildren.push thetaPair7142i19 <|
    PetersenLocalChildren.push thetaPair7142i20 <|
    PetersenLocalChildren.push thetaPair7142i21 <|
    PetersenLocalChildren.push thetaPair7142i22 <|
    PetersenLocalChildren.push thetaPair7142i23 <|
    PetersenLocalChildren.push thetaPair7142i24 <|
    PetersenLocalChildren.push thetaPair7142i25 <|
    PetersenLocalChildren.push thetaPair7142i26 <|
    PetersenLocalChildren.push thetaPair7142i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i0 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word7) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12799,s12800,s12801,s12802,s12803,s231,s12804,s12805,s12806]) (hints := [5555,6845,5555,0,1,2,3,4,5555,5,5555,6,6587,6845,7,8]) (by decide +kernel) ?_
  change ∀ x ∈ [s12799,s12800,s12801,s12802,s12803,s231,s12804,s12805,s12806], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12799) (b12799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12800) (b12800) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12801) (b12801) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12802) (b12802) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12803) (b12803) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s231) (b231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12804) (b12804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12805) (b12805) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12806) (b12806) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i1 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12807,s12808,s12827,s11369,s12828,s12829]) (hints := [9679,6842,9679,0,8647,1,8647,2,9679,3,9679,4,8647,6842,8647,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12807,s12808,s12827,s11369,s12828,s12829], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12807) (b12807) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12808) (b12808) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12827) (b12827) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11369) (b11369) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12828) (b12828) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12829) (b12829) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i2 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12799,s231,s12804,s12830,s12831,s12832,s12833,s12834]) (hints := [5938,1,5938,2,6844,6844,3,4,5938,6844,5938,0,7098,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12799,s231,s12804,s12830,s12831,s12832,s12833,s12834], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12799) (b12799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s231) (b231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12804) (b12804) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12830) (b12830) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12831) (b12831) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12832) (b12832) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12833) (b12833) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12834) (b12834) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i3 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12835,s5410,s12503,s12505]) (hints := [7478,6840,7478,0,1545,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12835,s5410,s12503,s12505], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12835) (b12835) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5410) (b5410) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12503) (b12503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12505) (b12505) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i4 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12836,s12837,s12838,s12839]) (hints := [11469,4776,11469,0,10437,6840,10437,1,11469,6840,11469,2,10437,4776,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12836,s12837,s12838,s12839], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12836) (b12836) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12837) (b12837) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12838) (b12838) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12839) (b12839) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i5 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12840,s12841,s12842,s12843]) (hints := [13517,2712,13517,0,12485,6840,12485,1,13517,6840,13517,2,12485,2712,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12840,s12841,s12842,s12843], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12840) (b12840) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12841) (b12841) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12842) (b12842) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12843) (b12843) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i6 : PetersenLocalChildren.PairOK tgt 8 s12798 (word12,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12844,s12845,s12867,s12868,s12869,s12870]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12844,s12845,s12867,s12868,s12869,s12870], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12844) (b12844) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12845) (b12845) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12867) (b12867) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12868) (b12868) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12869) (b12869) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12870) (b12870) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i7 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12871,s1144,s12872,s12873]) (hints := [905,5292,905,0,8645,5550,8645,1,905,5550,905,2,8645,5292,8645,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12871,s1144,s12872,s12873], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12871) (b12871) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1144) (b1144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12872) (b12872) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12873) (b12873) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i8 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12835,s1779,s2749,s3164]) (hints := [8901,5550,5934,0,8901,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12835,s1779,s2749,s3164], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12835) (b12835) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1779) (b1779) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2749) (b2749) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3164) (b3164) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i9 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12799,s12805,s12806,s5406,s5407,s12874,s12875,s12876]) (hints := [7482,1,7482,2,5554,5554,3,4,7482,5554,7482,0,7610,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12799,s12805,s12806,s5406,s5407,s12874,s12875,s12876], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12799) (b12799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12805) (b12805) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12806) (b12806) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5406) (b5406) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5407) (b5407) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12874) (b12874) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12875) (b12875) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12876) (b12876) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i10 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12877,s6586,s7107,s7485,s12878,s12879]) (hints := [2699,5552,2699,0,10439,1,10439,2,2699,3,2699,4,10439,5552,10439,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12877,s6586,s7107,s7485,s12878,s12879], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12877) (b12877) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6586) (b6586) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7107) (b7107) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7485) (b7485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12878) (b12878) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12879) (b12879) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i11 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12880,s8008,s12881,s12882]) (hints := [4745,9678,4745,0,12485,5550,12485,1,4745,5550,4745,2,12485,9678,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12880,s8008,s12881,s12882], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12880) (b12880) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8008) (b8008) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12881) (b12881) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12882) (b12882) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i12 : PetersenLocalChildren.PairOK tgt 8 s12798 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12883,s9978,s10136,s12884,s10897,s12885]) (hints := [8843,5552,8843,0,1488,9680,1,2,8843,9680,8843,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12883,s9978,s10136,s12884,s10897,s12885], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12883) (b12883) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9978) (b9978) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10136) (b10136) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12884) (b12884) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10897) (b10897) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12885) (b12885) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i13 : PetersenLocalChildren.PairOK tgt 8 s12798 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12886,s12887,s12888,s12889]) (hints := [8645,8645,5676,0,905,905,5934,1,905,905,5676,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12886,s12887,s12888,s12889], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12886) (b12886) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12887) (b12887) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12888) (b12888) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12889) (b12889) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i14 : PetersenLocalChildren.PairOK tgt 8 s12798 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12890,s12891,s12892,s12893]) (hints := [8645,8645,7736,0,9677,9677,7478,1,9677,9677,7736,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12890,s12891,s12892,s12893], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12890) (b12890) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12891) (b12891) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12892) (b12892) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12893) (b12893) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i15 : PetersenLocalChildren.PairOK tgt 8 s12798 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12894,s12895,s12896,s12897]) (hints := [8645,8645,10437,0,4920,6968,7470,1,10437,6968,10437,2,8645,8645,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12894,s12895,s12896,s12897], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12894) (b12894) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12895) (b12895) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12896) (b12896) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12897) (b12897) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i16 : PetersenLocalChildren.PairOK tgt 8 s12798 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12898,s12899,s12900,s12901]) (hints := [8645,8645,12485,0,2872,6968,13646,1,12485,6968,12485,2,8645,8645,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12898,s12899,s12900,s12901], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12898) (b12898) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12899) (b12899) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12900) (b12900) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12901) (b12901) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i17 : PetersenLocalChildren.PairOK tgt 8 s12798 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12902,s12903,s12905,s12906]) (hints := [389,389,8841,0,453,8645,13614,1,8581,8645,8841,2,389,389,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12902,s12903,s12905,s12906], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12902) (b12902) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12903) (b12903) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12905) (b12905) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12906) (b12906) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i18 : PetersenLocalChildren.PairOK tgt 8 s12798 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12907,s12908,s12909,s12910]) (hints := [6966,6966,7478,0,4910,5934,7736,1,7478,5934,7478,2,6966,6966,7736,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12907,s12908,s12909,s12910], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12907) (b12907) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12908) (b12908) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12909) (b12909) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12910) (b12910) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i19 : PetersenLocalChildren.PairOK tgt 8 s12798 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12911,s12912,s12913,s12914]) (hints := [10437,5934,10437,0,2697,6966,2697,1,10437,6966,10437,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12911,s12912,s12913,s12914], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12911) (b12911) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12912) (b12912) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12913) (b12913) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12914) (b12914) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i20 : PetersenLocalChildren.PairOK tgt 8 s12798 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12915,s12916,s12917,s12918]) (hints := [12485,10062,12485,0,4745,5934,4745,1,12485,5934,12485,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12915,s12916,s12917,s12918], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12915) (b12915) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12916) (b12916) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12917) (b12917) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12918) (b12918) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i21 : PetersenLocalChildren.PairOK tgt 8 s12798 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12919,s12920,s12921,s12922]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12919,s12920,s12921,s12922], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12919) (b12919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12920) (b12920) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12921) (b12921) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12922) (b12922) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i22 : PetersenLocalChildren.PairOK tgt 8 s12798 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12923,s12924,s12925,s12926]) (hints := [10437,5672,10437,0,11469,7478,11469,1,10437,7478,10437,2,11469,5672,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12923,s12924,s12925,s12926], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12923) (b12923) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12924) (b12924) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12925) (b12925) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12926) (b12926) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i23 : PetersenLocalChildren.PairOK tgt 8 s12798 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12927,s12928,s12929,s12930]) (hints := [12485,11606,12485,0,13517,7478,13517,1,12485,7478,12485,2,13517,11606,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12927,s12928,s12929,s12930], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12927) (b12927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12928) (b12928) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12929) (b12929) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12930) (b12930) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i24 : PetersenLocalChildren.PairOK tgt 8 s12798 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12931,s12932,s12933,s12934]) (hints := [8841,7478,8841,0,3414,11606,13614,1,8841,11606,8841,2,7478,7478,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12931,s12932,s12933,s12934], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12931) (b12931) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12932) (b12932) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12933) (b12933) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12934) (b12934) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i25 : PetersenLocalChildren.PairOK tgt 8 s12798 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12935,s12936,s12937,s12938]) (hints := [10437,10437,12485,0,3374,7470,14678,1,12485,7470,12485,2,10437,10437,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12935,s12936,s12937,s12938], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12935) (b12935) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12936) (b12936) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12937) (b12937) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12938) (b12938) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i26 : PetersenLocalChildren.PairOK tgt 8 s12798 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12939,s12940,s12941,s12942]) (hints := [2181,2181,8841,0,2245,10437,14646,1,10373,10437,8841,2,2181,2181,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12939,s12940,s12941,s12942], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12939) (b12939) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12940) (b12940) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12941) (b12941) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12942) (b12942) <|
    PetersenLocalChildren.nil
private theorem thetaPair12798i27 : PetersenLocalChildren.PairOK tgt 8 s12798 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12943,s12944,s12945,s12946]) (hints := [4229,4229,8841,0,4293,12485,13614,1,12421,12485,8841,2,4229,4229,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12943,s12944,s12945,s12946], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12943) (b12943) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12944) (b12944) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12945) (b12945) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12946) (b12946) <|
    PetersenLocalChildren.nil
theorem b12798 : Blocked tgt 9 s12798 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word12,word7),(word12,word1),(word12,word0),(word12,word6),(word12,word5),(word12,word2),(word12,word4),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s12798 p
  exact
    PetersenLocalChildren.push thetaPair12798i0 <|
    PetersenLocalChildren.push thetaPair12798i1 <|
    PetersenLocalChildren.push thetaPair12798i2 <|
    PetersenLocalChildren.push thetaPair12798i3 <|
    PetersenLocalChildren.push thetaPair12798i4 <|
    PetersenLocalChildren.push thetaPair12798i5 <|
    PetersenLocalChildren.push thetaPair12798i6 <|
    PetersenLocalChildren.push thetaPair12798i7 <|
    PetersenLocalChildren.push thetaPair12798i8 <|
    PetersenLocalChildren.push thetaPair12798i9 <|
    PetersenLocalChildren.push thetaPair12798i10 <|
    PetersenLocalChildren.push thetaPair12798i11 <|
    PetersenLocalChildren.push thetaPair12798i12 <|
    PetersenLocalChildren.push thetaPair12798i13 <|
    PetersenLocalChildren.push thetaPair12798i14 <|
    PetersenLocalChildren.push thetaPair12798i15 <|
    PetersenLocalChildren.push thetaPair12798i16 <|
    PetersenLocalChildren.push thetaPair12798i17 <|
    PetersenLocalChildren.push thetaPair12798i18 <|
    PetersenLocalChildren.push thetaPair12798i19 <|
    PetersenLocalChildren.push thetaPair12798i20 <|
    PetersenLocalChildren.push thetaPair12798i21 <|
    PetersenLocalChildren.push thetaPair12798i22 <|
    PetersenLocalChildren.push thetaPair12798i23 <|
    PetersenLocalChildren.push thetaPair12798i24 <|
    PetersenLocalChildren.push thetaPair12798i25 <|
    PetersenLocalChildren.push thetaPair12798i26 <|
    PetersenLocalChildren.push thetaPair12798i27 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
