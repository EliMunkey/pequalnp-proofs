import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv766_4260 : PetersenPackedPin.project r766 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv766_4814 : PetersenPackedPin.project r766 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv766_5473 : PetersenPackedPin.project r766 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv766_6170 : PetersenPackedPin.project r766 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv766_6790 : PetersenPackedPin.project r766 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv766_7474 : PetersenPackedPin.project r766 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv766_8012 : PetersenPackedPin.project r766 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv766_1734 : PetersenPackedPin.project r766 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv766_4260 pv766_6790 rfl rfl
theorem pv766_6504 : PetersenPackedPin.project r766 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv766_4260 pv766_6170 rfl rfl
theorem pv766_7095 : PetersenPackedPin.project r766 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv766_4260 pv766_6790 rfl rfl
theorem pv766_8245 : PetersenPackedPin.project r766 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xfff0fff0 := PetersenWireProjection.derive 3 pv766_5473 pv766_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
