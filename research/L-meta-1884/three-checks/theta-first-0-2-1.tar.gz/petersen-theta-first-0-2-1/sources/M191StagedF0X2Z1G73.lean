import M191ResidualC7A0G1
import M191ResidualC7A0G20
import M191ResidualC7A0G21
import M191ResidualC7A0G22
import M191ResidualC7A0G4
import M191ResidualC7A0G8
import M191ResidualC7A0G9
import M191StagedF0X2Z1G10
import M191StagedF0X2Z1G11
import M191StagedF0X2Z1G12
import M191StagedF0X2Z1G13
import M191StagedF0X2Z1G2
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G5
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G9
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows4
import M191StartPreferredRows5
import M191StartPreferredRows6
import M191StartPreferredRows7
import M191StartPreferredRows8
import M191StartPreferredRows9
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2599 : Blocked tgt 8 s2599 := by
  apply PetersenFastNode.node (nxt := #[s2600,s2601,s2602,s2603,s2604,s2605,s2606,s2607,s2142,s2141,s2608,s2609,s2610,s2611,s2612,s2613,s375,s2614,s2615,s2616,s2145,s2123,s2617,s2102,s2618,s2619,s2620,s2621]) (hints := [6352,6352,6992,9701,0,9701,6608,1,6992,9701,6352,9701,5958,6352,5958,6086,2,3,7502,6352,7502,1569,4,1697,7502,5,7502,6352,6352,1697,11877,4800,6,11493,6352,11493,6352,6352,7,11493,4800,11493,4800,4800,8,9957,6352,9957,9829,6352,9,9829,4800,9957,13670,2224,13670,13541,6352,13541,13670,6352,13670,13541,2224,13541,13638,6352,13638,8737,10,8865,13638,11,13638,6352,6352,8865,5700,12,5700,9701,9701,5958,9701,9701,5700,5956,13,5958,8669,8669,1697,8677,9701,7502,9693,9701,1697,8669,8669,7502,9701,9701,11493,6992,6992,14,11493,6992,11493,9701,9701,15,9957,929,9957,9701,9701,16,9701,9701,9957,417,929,17,9701,9701,13541,2896,6992,13670,13541,6992,13541,9701,9701,13670,1445,1445,8865,1509,9701,13638,9637,9701,8865,1445,1445,13638,6990,6990,7502,1697,5958,1697,7502,5958,7502,1697,6990,1697,5958,5958,18,11493,6990,11493,6990,6990,19,11493,5958,11493,5958,5958,20,9957,6990,9957,6990,6990,21,9957,5958,9957,10086,10086,13670,13541,5958,13541,13670,5958,13670,13541,10086,13541,5958,5958,13638,8865,10086,8865,13638,10086,13638,8865,5958,8865,10461,1697,10461,10469,7502,11493,10461,7502,10461,11485,1697,11493,8925,1697,8925,9949,7502,9957,8925,7502,8925,8933,1697,9957,12509,1697,12509,12517,7502,13541,12509,7502,12509,13533,1697,13541,1697,1697,8865,3438,11630,13638,8865,11630,8865,1697,1697,13638,9957,11493,9957,2209,22,23,11493,11493,13541,14702,24,14702,13541,25,13541,11493,11493,14702,3237,3237,8865,3301,11493,14670,11429,11493,8865,3237,3237,14670,9957,9957,4769,13541,26,13541,4257,27,4769,9957,9957,13541,1701,1701,8865,9893,9957,14670,1765,9957,8865,1701,1701,14670,5285,5285,8865,5349,13541,13638,13477,13541,8865,5285,5285,13638]) (by decide +kernel)
  change ∀ b ∈ [s2600,s2601,s2602,s2603,s2604,s2605,s2606,s2607,s2142,s2141,s2608,s2609,s2610,s2611,s2612,s2613,s375,s2614,s2615,s2616,s2145,s2123,s2617,s2102,s2618,s2619,s2620,s2621], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2600) b2600 <|
    PetersenLocalChildren.push (x := s2601) b2601 <|
    PetersenLocalChildren.push (x := s2602) b2602 <|
    PetersenLocalChildren.push (x := s2603) b2603 <|
    PetersenLocalChildren.push (x := s2604) b2604 <|
    PetersenLocalChildren.push (x := s2605) b2605 <|
    PetersenLocalChildren.push (x := s2606) b2606 <|
    PetersenLocalChildren.push (x := s2607) b2607 <|
    PetersenLocalChildren.push (x := s2142) b2142 <|
    PetersenLocalChildren.push (x := s2141) b2141 <|
    PetersenLocalChildren.push (x := s2608) b2608 <|
    PetersenLocalChildren.push (x := s2609) b2609 <|
    PetersenLocalChildren.push (x := s2610) b2610 <|
    PetersenLocalChildren.push (x := s2611) b2611 <|
    PetersenLocalChildren.push (x := s2612) b2612 <|
    PetersenLocalChildren.push (x := s2613) b2613 <|
    PetersenLocalChildren.push (x := s375) b375 <|
    PetersenLocalChildren.push (x := s2614) b2614 <|
    PetersenLocalChildren.push (x := s2615) b2615 <|
    PetersenLocalChildren.push (x := s2616) b2616 <|
    PetersenLocalChildren.push (x := s2145) b2145 <|
    PetersenLocalChildren.push (x := s2123) b2123 <|
    PetersenLocalChildren.push (x := s2617) b2617 <|
    PetersenLocalChildren.push (x := s2102) b2102 <|
    PetersenLocalChildren.push (x := s2618) b2618 <|
    PetersenLocalChildren.push (x := s2619) b2619 <|
    PetersenLocalChildren.push (x := s2620) b2620 <|
    PetersenLocalChildren.push (x := s2621) b2621 <|
    PetersenLocalChildren.nil
theorem b2660 : Blocked tgt 8 s2660 := by
  apply PetersenFastNode.node (nxt := #[s350,s2661,s2662,s2663,s381,s170,s2664,s2665,s2600,s2666,s2628,s2667,s2668,s2669,s2670,s2671,s2672,s2673,s2674,s2675,s2676,s2677,s2678,s2679,s2680,s2681,s2682,s2683]) (hints := [9957,9957,801,9701,0,9701,417,1,801,9701,9957,9701,9829,9957,6864,9829,2,3,5574,9957,5958,5574,4,5,7502,8925,7502,9949,9957,6,7502,9957,7502,8925,8925,7,7494,9957,7494,11493,8,11493,7494,9,7494,9957,9957,11493,13670,9957,13670,13541,10,13541,13670,11,13670,9957,9957,13541,13638,1701,13638,9893,9957,12,13638,9957,13638,1701,1701,13,9701,9701,6864,6992,14,15,5830,16,5700,9701,9701,5958,9701,9701,5700,5958,17,5958,8669,8669,1697,8677,9701,7502,9693,9701,1697,8669,8669,7502,9701,9701,11493,7494,18,7494,11493,19,11493,9701,9701,7494,9701,9701,13541,13670,20,13670,13541,21,13541,9701,9701,13670,1445,1445,8865,1509,9701,13638,9637,9701,8865,1445,1445,13638,5700,22,5700,5958,6864,5958,5700,6864,5700,5958,23,5958,6864,6864,7760,7502,24,7502,7760,25,7760,7502,6864,7502,4800,4800,7236,11493,6864,11493,6848,6864,7236,11493,4800,11493,2736,2736,13412,13541,6864,13541,6832,6864,13412,13541,2736,13541,6864,6864,14928,13638,26,13638,14928,27,14928,13638,6864,13638,6990,6990,7502,4934,5958,1697,7502,5958,7502,6990,6990,1697,5958,5958,7494,11493,6990,11493,7494,6990,7494,11493,5958,11493,10086,10086,13670,13541,5958,13541,13670,5958,13670,13541,10086,13541,5958,5958,13638,1894,10086,8865,13638,10086,13638,5958,5958,8865,10461,1697,10461,10469,7502,11493,10461,7502,10461,11485,1697,11493,12509,11630,12509,12517,7502,13541,12509,7502,12509,13533,11630,13541,7502,7502,14670,3438,11630,13638,14670,11630,14670,7502,7502,13638,11493,11493,13541,3398,7494,14702,13541,7494,13541,11493,11493,14702,3237,3237,13638,3301,11493,14670,11429,11493,13638,3237,3237,14670,5285,5285,8865,5349,13541,13638,13477,13541,8865,5285,5285,13638]) (by decide +kernel)
  change ∀ b ∈ [s350,s2661,s2662,s2663,s381,s170,s2664,s2665,s2600,s2666,s2628,s2667,s2668,s2669,s2670,s2671,s2672,s2673,s2674,s2675,s2676,s2677,s2678,s2679,s2680,s2681,s2682,s2683], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s350) b350 <|
    PetersenLocalChildren.push (x := s2661) b2661 <|
    PetersenLocalChildren.push (x := s2662) b2662 <|
    PetersenLocalChildren.push (x := s2663) b2663 <|
    PetersenLocalChildren.push (x := s381) b381 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s2664) b2664 <|
    PetersenLocalChildren.push (x := s2665) b2665 <|
    PetersenLocalChildren.push (x := s2600) b2600 <|
    PetersenLocalChildren.push (x := s2666) b2666 <|
    PetersenLocalChildren.push (x := s2628) b2628 <|
    PetersenLocalChildren.push (x := s2667) b2667 <|
    PetersenLocalChildren.push (x := s2668) b2668 <|
    PetersenLocalChildren.push (x := s2669) b2669 <|
    PetersenLocalChildren.push (x := s2670) b2670 <|
    PetersenLocalChildren.push (x := s2671) b2671 <|
    PetersenLocalChildren.push (x := s2672) b2672 <|
    PetersenLocalChildren.push (x := s2673) b2673 <|
    PetersenLocalChildren.push (x := s2674) b2674 <|
    PetersenLocalChildren.push (x := s2675) b2675 <|
    PetersenLocalChildren.push (x := s2676) b2676 <|
    PetersenLocalChildren.push (x := s2677) b2677 <|
    PetersenLocalChildren.push (x := s2678) b2678 <|
    PetersenLocalChildren.push (x := s2679) b2679 <|
    PetersenLocalChildren.push (x := s2680) b2680 <|
    PetersenLocalChildren.push (x := s2681) b2681 <|
    PetersenLocalChildren.push (x := s2682) b2682 <|
    PetersenLocalChildren.push (x := s2683) b2683 <|
    PetersenLocalChildren.nil
theorem b2688 : Blocked tgt 8 s2688 := by
  apply PetersenFastNode.node (nxt := #[s2689,s2690,s357,s2691,s2692,s2693,s2694,s2695,s2602,s2696,s2630,s2697,s2698,s2699,s2700,s2679,s2701,s2702,s2703,s2704,s2705,s2706,s2707,s2708,s2709,s2710,s2711,s2712]) (hints := [9829,9957,6864,9829,0,1,6992,9957,6992,9701,2,9701,6992,3,6992,9701,9957,9701,5574,9957,6086,5574,4,5,7760,8925,7760,9949,9957,6,7760,9957,7760,8925,8925,7,7494,9957,7494,11493,8,11493,7494,9,7494,9957,9957,11493,13670,9957,13670,13541,10,13541,13670,11,13670,9957,9957,13541,14928,1701,14928,9893,9957,12,14928,9957,14928,1701,1701,13,9701,6864,9701,6992,14,6992,9701,15,9701,6864,6864,6992,5958,6864,6086,5958,16,17,7502,6864,7502,7760,18,7760,7502,19,7502,6864,6864,7760,11493,4800,11493,6848,6864,20,11493,6864,11493,4800,4800,21,13541,2736,13541,6832,6864,22,13541,6864,13541,2736,2736,23,13638,6864,13638,14928,24,14928,13638,25,13638,6864,6864,14928,5828,26,5828,9701,9701,6086,9701,9701,5828,6084,27,6086,8669,8669,7760,8677,9701,7502,9693,9701,7760,8669,8669,7502,9701,9701,11493,4944,6992,7494,11493,6992,11493,9701,9701,7494,9701,9701,13541,2896,6992,13670,13541,6992,13541,9701,9701,13670,1445,1445,14928,1509,9701,13638,9637,9701,14928,1445,1445,13638,7118,7118,7502,7760,6086,7760,7502,6086,7502,7760,7118,7760,6086,6086,7494,11493,7118,11493,7494,7118,7494,11493,6086,11493,10214,10214,13670,13541,6086,13541,13670,6086,13670,13541,10214,13541,6086,6086,13638,14928,10214,14928,13638,10214,13638,14928,6086,14928,10461,5696,10461,10469,7760,11493,10461,7760,10461,11485,5696,11493,12509,3632,12509,12517,7760,13541,12509,7760,12509,13533,3632,13541,7760,7760,14928,3438,11630,13638,14928,11630,14928,7760,7760,13638,11493,11493,13541,3398,7494,14702,13541,7494,13541,11493,11493,14702,3237,3237,12864,3301,11493,14928,11429,11493,12864,3237,3237,14928,5285,5285,10800,5349,13541,14928,13477,13541,10800,5285,5285,14928]) (by decide +kernel)
  change ∀ b ∈ [s2689,s2690,s357,s2691,s2692,s2693,s2694,s2695,s2602,s2696,s2630,s2697,s2698,s2699,s2700,s2679,s2701,s2702,s2703,s2704,s2705,s2706,s2707,s2708,s2709,s2710,s2711,s2712], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2689) b2689 <|
    PetersenLocalChildren.push (x := s2690) b2690 <|
    PetersenLocalChildren.push (x := s357) b357 <|
    PetersenLocalChildren.push (x := s2691) b2691 <|
    PetersenLocalChildren.push (x := s2692) b2692 <|
    PetersenLocalChildren.push (x := s2693) b2693 <|
    PetersenLocalChildren.push (x := s2694) b2694 <|
    PetersenLocalChildren.push (x := s2695) b2695 <|
    PetersenLocalChildren.push (x := s2602) b2602 <|
    PetersenLocalChildren.push (x := s2696) b2696 <|
    PetersenLocalChildren.push (x := s2630) b2630 <|
    PetersenLocalChildren.push (x := s2697) b2697 <|
    PetersenLocalChildren.push (x := s2698) b2698 <|
    PetersenLocalChildren.push (x := s2699) b2699 <|
    PetersenLocalChildren.push (x := s2700) b2700 <|
    PetersenLocalChildren.push (x := s2679) b2679 <|
    PetersenLocalChildren.push (x := s2701) b2701 <|
    PetersenLocalChildren.push (x := s2702) b2702 <|
    PetersenLocalChildren.push (x := s2703) b2703 <|
    PetersenLocalChildren.push (x := s2704) b2704 <|
    PetersenLocalChildren.push (x := s2705) b2705 <|
    PetersenLocalChildren.push (x := s2706) b2706 <|
    PetersenLocalChildren.push (x := s2707) b2707 <|
    PetersenLocalChildren.push (x := s2708) b2708 <|
    PetersenLocalChildren.push (x := s2709) b2709 <|
    PetersenLocalChildren.push (x := s2710) b2710 <|
    PetersenLocalChildren.push (x := s2711) b2711 <|
    PetersenLocalChildren.push (x := s2712) b2712 <|
    PetersenLocalChildren.nil
theorem b2796 : Blocked tgt 8 s2796 := by
  apply PetersenFastNode.node (nxt := #[s2797,s2798,s2799,s2800,s2022,s2023,s2801,s2802,s2803,s2610,s2804,s2638,s2805,s2806,s2807,s2808,s2809,s2711,s2810,s2726,s2811,s2771,s2812,s2027,s2813,s2814,s2815,s2816,s2817,s2818,s2819,s2820,s2821]) (hints := [9834,9962,6869,9834,0,1,9962,9962,934,9706,2,9706,422,3,934,9706,9962,9706,9962,9962,5705,4,5,6,8930,8930,1702,9954,9962,7,8938,9962,1702,8930,8930,8,9962,9962,2726,11498,9,11498,2214,10,2726,9962,9962,11498,9962,9962,4774,13546,11,13546,4262,12,4774,9962,9962,13546,1706,1706,8870,9898,9962,13,1770,9962,8870,1706,1706,14,6869,6869,6997,9706,15,9706,6997,16,6997,9706,6869,9706,5705,6869,5705,5833,17,18,6869,6869,7765,1574,19,1702,7765,20,7765,6869,6869,1702,4805,4805,7241,11498,6869,11498,6853,6869,7241,11498,4805,11498,2741,2741,13417,13546,6869,13546,6837,6869,13417,13546,2741,13546,6869,6869,14933,8742,21,8870,14933,22,14933,6869,6869,8870,9706,9706,5705,5961,23,24,8674,8674,1702,8682,9706,25,9698,9706,1702,8674,8674,26,9706,9706,11498,4949,6997,27,11498,6997,11498,9706,9706,28,9706,9706,13546,2901,6997,29,13546,6997,13546,9706,9706,30,1450,1450,8870,1514,9706,31,9642,9706,8870,1450,1450,32,7249,10865,7249,1702,5705,1702,7249,5705,7249,1702,10865,1702,5705,5705,7241,11498,10865,11498,7241,10865,7241,11498,5705,11498,9833,9833,13417,13546,5705,13546,13417,5705,13417,13546,9833,13546,5705,5705,13385,8870,9833,8870,13385,9833,13385,8870,5705,8870,10466,1702,10466,10474,7765,11498,10466,7765,10466,11490,1702,11498,12514,1702,12514,12522,7765,13546,12514,7765,12514,13538,1702,13546,1702,1702,8870,3185,11377,13385,8870,11377,8870,1702,1702,13385,11498,11498,13546,3145,7241,14449,13546,7241,13546,11498,11498,14449,3242,3242,8870,3306,11498,14933,11434,11498,8870,3242,3242,14933,5290,5290,8870,5354,13546,14933,13482,13546,8870,5290,5290,14933]) (by decide +kernel)
  change ∀ b ∈ [s2797,s2798,s2799,s2800,s2022,s2023,s2801,s2802,s2803,s2610,s2804,s2638,s2805,s2806,s2807,s2808,s2809,s2711,s2810,s2726,s2811,s2771,s2812,s2027,s2813,s2814,s2815,s2816,s2817,s2818,s2819,s2820,s2821], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2797) b2797 <|
    PetersenLocalChildren.push (x := s2798) b2798 <|
    PetersenLocalChildren.push (x := s2799) b2799 <|
    PetersenLocalChildren.push (x := s2800) b2800 <|
    PetersenLocalChildren.push (x := s2022) b2022 <|
    PetersenLocalChildren.push (x := s2023) b2023 <|
    PetersenLocalChildren.push (x := s2801) b2801 <|
    PetersenLocalChildren.push (x := s2802) b2802 <|
    PetersenLocalChildren.push (x := s2803) b2803 <|
    PetersenLocalChildren.push (x := s2610) b2610 <|
    PetersenLocalChildren.push (x := s2804) b2804 <|
    PetersenLocalChildren.push (x := s2638) b2638 <|
    PetersenLocalChildren.push (x := s2805) b2805 <|
    PetersenLocalChildren.push (x := s2806) b2806 <|
    PetersenLocalChildren.push (x := s2807) b2807 <|
    PetersenLocalChildren.push (x := s2808) b2808 <|
    PetersenLocalChildren.push (x := s2809) b2809 <|
    PetersenLocalChildren.push (x := s2711) b2711 <|
    PetersenLocalChildren.push (x := s2810) b2810 <|
    PetersenLocalChildren.push (x := s2726) b2726 <|
    PetersenLocalChildren.push (x := s2811) b2811 <|
    PetersenLocalChildren.push (x := s2771) b2771 <|
    PetersenLocalChildren.push (x := s2812) b2812 <|
    PetersenLocalChildren.push (x := s2027) b2027 <|
    PetersenLocalChildren.push (x := s2813) b2813 <|
    PetersenLocalChildren.push (x := s2814) b2814 <|
    PetersenLocalChildren.push (x := s2815) b2815 <|
    PetersenLocalChildren.push (x := s2816) b2816 <|
    PetersenLocalChildren.push (x := s2817) b2817 <|
    PetersenLocalChildren.push (x := s2818) b2818 <|
    PetersenLocalChildren.push (x := s2819) b2819 <|
    PetersenLocalChildren.push (x := s2820) b2820 <|
    PetersenLocalChildren.push (x := s2821) b2821 <|
    PetersenLocalChildren.nil
theorem b2948 : Blocked tgt 8 s2948 := by
  apply PetersenFastNode.node (nxt := #[s2909,s2949,s1786,s1782,s2950,s2951,s2926,s1770,s2952,s2933,s2953,s2935,s2954,s1774,s1296,s1776]) (hints := [6852,789,6980,6852,9817,6852,9945,5562,5562,6852,0,1,6852,6852,2,3,6852,7482,4804,7482,4788,13658,2756,13658,2724,13626,8725,13626,6852,9689,917,9945,9689,4,917,917,5,917,8665,9681,917,917,9689,9689,917,917,4932,2709,917,917,2884,4757,917,917,1497,8853,917,9945,5946,6,9945,9937,9937,8913,9945,9945,7,9945,2709,11481,9945,9945,4757,13529,9945,1689,1753,9881,1689,8,9,10,11,12,13,14,15,7482,2709,7482,2709,13658,4757,13658,4757,13626,8853,13626,8853,1685,1685,2709,10457,2709,11473,4757,12505,4757,13521,8853,13626,8853,13626,2709,11481,2709,11481,4757,13529,4757,13529,8853,13626,8853,13626,2709,3386,4757,2709,2709,3289,8853,2709,4757,5337,8853,4757]) (by decide +kernel)
  change ∀ b ∈ [s2909,s2949,s1786,s1782,s2950,s2951,s2926,s1770,s2952,s2933,s2953,s2935,s2954,s1774,s1296,s1776], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2909) b2909 <|
    PetersenLocalChildren.push (x := s2949) b2949 <|
    PetersenLocalChildren.push (x := s1786) b1786 <|
    PetersenLocalChildren.push (x := s1782) b1782 <|
    PetersenLocalChildren.push (x := s2950) b2950 <|
    PetersenLocalChildren.push (x := s2951) b2951 <|
    PetersenLocalChildren.push (x := s2926) b2926 <|
    PetersenLocalChildren.push (x := s1770) b1770 <|
    PetersenLocalChildren.push (x := s2952) b2952 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s2953) b2953 <|
    PetersenLocalChildren.push (x := s2935) b2935 <|
    PetersenLocalChildren.push (x := s2954) b2954 <|
    PetersenLocalChildren.push (x := s1774) b1774 <|
    PetersenLocalChildren.push (x := s1296) b1296 <|
    PetersenLocalChildren.push (x := s1776) b1776 <|
    PetersenLocalChildren.nil
theorem b3013 : Blocked tgt 8 s3013 := by
  apply PetersenFastNode.node (nxt := #[s2602,s3014,s3015,s3016,s2123,s1810,s3017,s3018,s3019,s1814,s1355,s1816]) (hints := [6848,785,6976,6848,6336,6848,0,6590,6590,7486,1553,7486,6848,4784,6848,6848,4784,4784,6848,6848,4784,13654,2752,13654,2720,13622,8721,13622,6848,9685,913,913,9685,1,913,913,2,913,8661,1681,913,913,6976,11477,913,913,9685,9685,913,913,2880,4753,913,913,1493,8849,913,5942,5942,7486,1681,7486,1681,11477,3,11477,11989,9941,9941,4,5,13525,4753,13525,4753,13622,8849,13622,8849,7486,1681,7486,1681,6,11477,7,11477,8,9,10,11,13654,4753,13654,4753,13622,8849,13622,8849,1681,10453,10445,1681,1681,7486,7486,1681,1681,12501,4753,1681,1681,3422,8849,1681,2705,2705,4753,14686,4753,11477,8849,3285,8849,3221,4753,13525,4753,13525,8849,14654,8849,14654,4753,5333,8849,4753]) (by decide +kernel)
  change ∀ b ∈ [s2602,s3014,s3015,s3016,s2123,s1810,s3017,s3018,s3019,s1814,s1355,s1816], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2602) b2602 <|
    PetersenLocalChildren.push (x := s3014) b3014 <|
    PetersenLocalChildren.push (x := s3015) b3015 <|
    PetersenLocalChildren.push (x := s3016) b3016 <|
    PetersenLocalChildren.push (x := s2123) b2123 <|
    PetersenLocalChildren.push (x := s1810) b1810 <|
    PetersenLocalChildren.push (x := s3017) b3017 <|
    PetersenLocalChildren.push (x := s3018) b3018 <|
    PetersenLocalChildren.push (x := s3019) b3019 <|
    PetersenLocalChildren.push (x := s1814) b1814 <|
    PetersenLocalChildren.push (x := s1355) b1355 <|
    PetersenLocalChildren.push (x := s1816) b1816 <|
    PetersenLocalChildren.nil
theorem b3265 : Blocked tgt 8 s3265 := by
  apply PetersenFastNode.node (nxt := #[s941,s3266,s2907,s3267,s3268,s3242,s3269,s3270,s3271,s3272,s3273,s3274,s3275,s3276,s3277,s3278,s3279,s3280,s3281,s3282,s3283,s3284,s3285,s3286,s3287,s3288,s3289,s3290,s3291,s3292,s3293,s3294,s3295,s3296,s3297,s3298,s3299,s3300,s3301,s3302,s3303,s3304,s3305,s3306,s3307,s3308,s3309]) (hints := [4569,0,4569,6883,1,2,948,3,948,7011,4,7011,948,5,948,7011,6,7011,9968,0,9968,5977,7,8,1716,9,1716,7779,10,7779,1716,11,1716,7779,12,7779,2740,13,2740,14,15,16,2740,17,2740,18,19,20,4788,21,4788,22,23,24,4788,25,4788,26,27,28,8884,29,8884,14947,30,14947,8884,31,8884,14947,32,14947,7011,4311,7011,948,4569,948,7011,4569,7011,948,4311,948,4569,4569,8,9968,2,9968,6105,33,34,7779,35,7779,4569,4569,1716,7779,4569,7779,6625,36,1716,4569,4569,7513,2740,37,2740,6617,38,7513,4569,4569,2740,8697,8697,13689,473,4569,4788,12793,4569,13689,8697,8697,4788,14947,4569,14947,505,8697,8884,14947,8697,14947,4569,4569,8884,8688,8688,9968,7011,7011,39,7011,7011,9968,8688,8688,40,7011,7011,7779,8688,8688,7521,7779,8688,7779,7011,7011,7521,4947,4947,2740,4963,7011,7513,6995,7011,2740,4947,4947,7513,2883,2883,4788,2915,7011,13689,6979,7011,4788,2883,2883,13689,7011,7011,14947,496,8688,13657,14947,8688,14947,7011,7011,13657,8944,41,7521,7779,9968,7779,9968,9968,7521,7779,42,7779,9968,9968,10480,2740,43,2740,10480,44,10480,9968,9968,2740,9968,9968,12528,4788,45,4788,12528,46,12528,9968,9968,4788,1712,1712,13657,14947,9968,14947,9904,9968,13657,14947,1712,14947,5715,5715,2740,5731,7779,10480,7763,7779,2740,5715,5715,10480,3651,3651,4788,3683,7779,12528,7747,7779,4788,3651,3651,12528,7779,7779,14947,3457,11649,13657,14947,11649,14947,7779,7779,13657,2740,2740,4788,3417,7513,14721,4788,7513,4788,2740,2740,14721,12883,2740,12883,12899,10480,14947,12883,10480,12883,14931,2740,14947,10819,4788,10819,10851,12528,14947,10819,12528,10819,14915,4788,14947]) (by decide +kernel)
  change ∀ b ∈ [s941,s3266,s2907,s3267,s3268,s3242,s3269,s3270,s3271,s3272,s3273,s3274,s3275,s3276,s3277,s3278,s3279,s3280,s3281,s3282,s3283,s3284,s3285,s3286,s3287,s3288,s3289,s3290,s3291,s3292,s3293,s3294,s3295,s3296,s3297,s3298,s3299,s3300,s3301,s3302,s3303,s3304,s3305,s3306,s3307,s3308,s3309], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3266) b3266 <|
    PetersenLocalChildren.push (x := s2907) b2907 <|
    PetersenLocalChildren.push (x := s3267) b3267 <|
    PetersenLocalChildren.push (x := s3268) b3268 <|
    PetersenLocalChildren.push (x := s3242) b3242 <|
    PetersenLocalChildren.push (x := s3269) b3269 <|
    PetersenLocalChildren.push (x := s3270) b3270 <|
    PetersenLocalChildren.push (x := s3271) b3271 <|
    PetersenLocalChildren.push (x := s3272) b3272 <|
    PetersenLocalChildren.push (x := s3273) b3273 <|
    PetersenLocalChildren.push (x := s3274) b3274 <|
    PetersenLocalChildren.push (x := s3275) b3275 <|
    PetersenLocalChildren.push (x := s3276) b3276 <|
    PetersenLocalChildren.push (x := s3277) b3277 <|
    PetersenLocalChildren.push (x := s3278) b3278 <|
    PetersenLocalChildren.push (x := s3279) b3279 <|
    PetersenLocalChildren.push (x := s3280) b3280 <|
    PetersenLocalChildren.push (x := s3281) b3281 <|
    PetersenLocalChildren.push (x := s3282) b3282 <|
    PetersenLocalChildren.push (x := s3283) b3283 <|
    PetersenLocalChildren.push (x := s3284) b3284 <|
    PetersenLocalChildren.push (x := s3285) b3285 <|
    PetersenLocalChildren.push (x := s3286) b3286 <|
    PetersenLocalChildren.push (x := s3287) b3287 <|
    PetersenLocalChildren.push (x := s3288) b3288 <|
    PetersenLocalChildren.push (x := s3289) b3289 <|
    PetersenLocalChildren.push (x := s3290) b3290 <|
    PetersenLocalChildren.push (x := s3291) b3291 <|
    PetersenLocalChildren.push (x := s3292) b3292 <|
    PetersenLocalChildren.push (x := s3293) b3293 <|
    PetersenLocalChildren.push (x := s3294) b3294 <|
    PetersenLocalChildren.push (x := s3295) b3295 <|
    PetersenLocalChildren.push (x := s3296) b3296 <|
    PetersenLocalChildren.push (x := s3297) b3297 <|
    PetersenLocalChildren.push (x := s3298) b3298 <|
    PetersenLocalChildren.push (x := s3299) b3299 <|
    PetersenLocalChildren.push (x := s3300) b3300 <|
    PetersenLocalChildren.push (x := s3301) b3301 <|
    PetersenLocalChildren.push (x := s3302) b3302 <|
    PetersenLocalChildren.push (x := s3303) b3303 <|
    PetersenLocalChildren.push (x := s3304) b3304 <|
    PetersenLocalChildren.push (x := s3305) b3305 <|
    PetersenLocalChildren.push (x := s3306) b3306 <|
    PetersenLocalChildren.push (x := s3307) b3307 <|
    PetersenLocalChildren.push (x := s3308) b3308 <|
    PetersenLocalChildren.push (x := s3309) b3309 <|
    PetersenLocalChildren.nil
theorem b3311 : Blocked tgt 8 s3311 := by
  apply PetersenFastNode.node (nxt := #[s2909,s3312,s3313,s3314,s3315,s3316,s941,s3317,s3318,s3319,s423,s3320,s3321,s3244,s3322,s3323,s3324,s3325,s3326,s2933,s3274,s3327,s3328,s3329,s3330,s3331,s3332,s3333,s3334,s3335,s3336,s3337,s3338,s3339,s3340,s3341,s3342,s3343,s3344,s3345,s3346,s3347,s3348,s3349,s3350]) (hints := [7009,4309,7009,946,4567,946,7009,4567,7009,946,4309,946,4567,4567,5975,9838,0,9966,5975,1,5975,4567,4567,9966,1586,2,3,4567,4567,4,1714,5,1714,4567,4567,6,6881,5,7,4567,4567,7511,2738,8,2738,6615,9,7511,4567,4567,2738,8695,8695,13687,471,4567,4786,12791,4567,13687,8695,8695,4786,4567,4567,13655,503,8695,8882,12759,8695,13655,4567,4567,8882,8686,8686,9966,946,946,5975,9966,946,9966,8686,8686,5975,946,946,1714,8686,8686,10,1714,8686,1714,946,946,11,7009,7009,12,946,946,13,946,946,14,7009,7009,15,946,946,2738,4961,7009,7511,2738,7009,2738,946,946,7511,946,946,4786,2913,7009,13687,4786,7009,4786,946,946,13687,946,946,8882,494,8686,13655,8882,8686,8882,946,946,13655,8942,7007,16,8942,9966,1714,9966,9966,17,1714,7007,1714,7007,7007,18,9966,9966,19,9966,9966,20,7007,7007,21,9966,9966,10478,2738,7007,2738,10478,7007,10478,9966,9966,2738,9966,9966,12526,4786,5975,4786,12526,5975,12526,9966,9966,4786,1710,1710,13655,1774,9966,8882,9902,9966,13655,1710,1710,8882,1714,1714,6,7519,4,22,1714,1714,2738,10478,23,10478,2738,24,2738,1714,1714,10478,1714,1714,4786,12526,25,12526,4786,26,4786,1714,1714,12526,1714,1714,8882,13655,27,13655,8882,28,8882,1714,1714,13655,29,30,31,2738,32,2738,33,34,35,2738,36,2738,14719,37,14719,4786,38,4786,14719,39,14719,4786,40,4786,14687,41,14687,8882,42,8882,14687,43,14687,8882,44,8882,2738,2738,4786,3415,7511,14719,4786,7511,4786,2738,2738,14719,2738,2738,8882,2286,10478,14687,8882,10478,8882,2738,2738,14687,4786,4786,8882,4334,12526,13655,8882,12526,8882,4786,4786,13655]) (by decide +kernel)
  change ∀ b ∈ [s2909,s3312,s3313,s3314,s3315,s3316,s941,s3317,s3318,s3319,s423,s3320,s3321,s3244,s3322,s3323,s3324,s3325,s3326,s2933,s3274,s3327,s3328,s3329,s3330,s3331,s3332,s3333,s3334,s3335,s3336,s3337,s3338,s3339,s3340,s3341,s3342,s3343,s3344,s3345,s3346,s3347,s3348,s3349,s3350], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2909) b2909 <|
    PetersenLocalChildren.push (x := s3312) b3312 <|
    PetersenLocalChildren.push (x := s3313) b3313 <|
    PetersenLocalChildren.push (x := s3314) b3314 <|
    PetersenLocalChildren.push (x := s3315) b3315 <|
    PetersenLocalChildren.push (x := s3316) b3316 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3317) b3317 <|
    PetersenLocalChildren.push (x := s3318) b3318 <|
    PetersenLocalChildren.push (x := s3319) b3319 <|
    PetersenLocalChildren.push (x := s423) b423 <|
    PetersenLocalChildren.push (x := s3320) b3320 <|
    PetersenLocalChildren.push (x := s3321) b3321 <|
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s3322) b3322 <|
    PetersenLocalChildren.push (x := s3323) b3323 <|
    PetersenLocalChildren.push (x := s3324) b3324 <|
    PetersenLocalChildren.push (x := s3325) b3325 <|
    PetersenLocalChildren.push (x := s3326) b3326 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s3274) b3274 <|
    PetersenLocalChildren.push (x := s3327) b3327 <|
    PetersenLocalChildren.push (x := s3328) b3328 <|
    PetersenLocalChildren.push (x := s3329) b3329 <|
    PetersenLocalChildren.push (x := s3330) b3330 <|
    PetersenLocalChildren.push (x := s3331) b3331 <|
    PetersenLocalChildren.push (x := s3332) b3332 <|
    PetersenLocalChildren.push (x := s3333) b3333 <|
    PetersenLocalChildren.push (x := s3334) b3334 <|
    PetersenLocalChildren.push (x := s3335) b3335 <|
    PetersenLocalChildren.push (x := s3336) b3336 <|
    PetersenLocalChildren.push (x := s3337) b3337 <|
    PetersenLocalChildren.push (x := s3338) b3338 <|
    PetersenLocalChildren.push (x := s3339) b3339 <|
    PetersenLocalChildren.push (x := s3340) b3340 <|
    PetersenLocalChildren.push (x := s3341) b3341 <|
    PetersenLocalChildren.push (x := s3342) b3342 <|
    PetersenLocalChildren.push (x := s3343) b3343 <|
    PetersenLocalChildren.push (x := s3344) b3344 <|
    PetersenLocalChildren.push (x := s3345) b3345 <|
    PetersenLocalChildren.push (x := s3346) b3346 <|
    PetersenLocalChildren.push (x := s3347) b3347 <|
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s3349) b3349 <|
    PetersenLocalChildren.push (x := s3350) b3350 <|
    PetersenLocalChildren.nil
theorem b3390 : Blocked tgt 8 s3390 := by
  apply PetersenFastNode.node (nxt := #[s3391,s3392,s3393,s3394,s941,s3395,s3396,s3397,s3398,s3399,s3400,s3252,s3401,s3402,s3403,s2941,s3288,s3404,s3405,s3344,s3406,s3407,s3408,s3409,s3410,s3380,s3411,s3412,s3413,s3414,s3415,s3416,s3417]) (hints := [6869,6869,6997,934,4555,934,6997,4555,6997,6869,6869,934,4555,4555,5963,9954,6869,9954,5963,6869,5963,4555,4555,9954,7507,6869,7507,4555,4555,1702,6611,4555,7507,6611,6869,1702,4555,4555,7499,4821,6869,2726,6603,6869,7499,4555,4555,2726,459,0,1,4555,4555,2,4774,3,4774,4555,4555,4,8683,3,5,4555,4555,13643,8870,6,8870,12747,7,13643,4555,4555,8870,8674,8674,9954,934,934,5963,9954,934,9954,8674,8674,5963,934,934,1702,8674,8674,7507,1702,8674,1702,934,934,7507,934,934,2726,4949,6997,7499,2726,6997,2726,934,934,7499,934,934,4774,6997,6997,8,4774,6997,4774,934,934,9,2869,2869,10,934,934,11,934,934,12,2869,2869,13,934,934,8870,482,8674,13643,8870,8674,8870,934,934,13643,8930,6995,7507,8930,9954,1702,9954,9954,7507,1702,6995,1702,9954,9954,10466,2726,6995,2726,10466,6995,10466,9954,9954,2726,9954,9954,12514,4774,5963,4774,12514,5963,12514,9954,9954,4774,10091,10091,14,9954,9954,15,9954,9954,16,10091,10091,17,1698,1698,13643,1762,9954,8870,9890,9954,13643,1698,1698,8870,1702,1702,2726,10466,7507,10466,2726,7507,2726,1702,1702,10466,1702,1702,4774,12514,7507,12514,4774,7507,4774,1702,1702,12514,11635,11635,18,1702,1702,19,1702,1702,20,11635,11635,21,1702,1702,8870,3443,11635,13643,8870,11635,8870,1702,1702,13643,2726,2726,4774,7499,7499,22,4774,7499,4774,2726,2726,23,11627,11627,24,2726,2726,25,2726,2726,26,11627,11627,27,2726,2726,8870,2274,10466,14675,8870,10466,8870,2726,2726,14675,4774,4774,4,13675,2,28,4774,4774,8870,4322,12514,13643,8870,12514,8870,4774,4774,13643,10805,29,10805,8870,30,8870,10805,31,10805,8870,32,8870]) (by decide +kernel)
  change ∀ b ∈ [s3391,s3392,s3393,s3394,s941,s3395,s3396,s3397,s3398,s3399,s3400,s3252,s3401,s3402,s3403,s2941,s3288,s3404,s3405,s3344,s3406,s3407,s3408,s3409,s3410,s3380,s3411,s3412,s3413,s3414,s3415,s3416,s3417], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3391) b3391 <|
    PetersenLocalChildren.push (x := s3392) b3392 <|
    PetersenLocalChildren.push (x := s3393) b3393 <|
    PetersenLocalChildren.push (x := s3394) b3394 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3395) b3395 <|
    PetersenLocalChildren.push (x := s3396) b3396 <|
    PetersenLocalChildren.push (x := s3397) b3397 <|
    PetersenLocalChildren.push (x := s3398) b3398 <|
    PetersenLocalChildren.push (x := s3399) b3399 <|
    PetersenLocalChildren.push (x := s3400) b3400 <|
    PetersenLocalChildren.push (x := s3252) b3252 <|
    PetersenLocalChildren.push (x := s3401) b3401 <|
    PetersenLocalChildren.push (x := s3402) b3402 <|
    PetersenLocalChildren.push (x := s3403) b3403 <|
    PetersenLocalChildren.push (x := s2941) b2941 <|
    PetersenLocalChildren.push (x := s3288) b3288 <|
    PetersenLocalChildren.push (x := s3404) b3404 <|
    PetersenLocalChildren.push (x := s3405) b3405 <|
    PetersenLocalChildren.push (x := s3344) b3344 <|
    PetersenLocalChildren.push (x := s3406) b3406 <|
    PetersenLocalChildren.push (x := s3407) b3407 <|
    PetersenLocalChildren.push (x := s3408) b3408 <|
    PetersenLocalChildren.push (x := s3409) b3409 <|
    PetersenLocalChildren.push (x := s3410) b3410 <|
    PetersenLocalChildren.push (x := s3380) b3380 <|
    PetersenLocalChildren.push (x := s3411) b3411 <|
    PetersenLocalChildren.push (x := s3412) b3412 <|
    PetersenLocalChildren.push (x := s3413) b3413 <|
    PetersenLocalChildren.push (x := s3414) b3414 <|
    PetersenLocalChildren.push (x := s3415) b3415 <|
    PetersenLocalChildren.push (x := s3416) b3416 <|
    PetersenLocalChildren.push (x := s3417) b3417 <|
    PetersenLocalChildren.nil
theorem b3745 : Blocked tgt 8 s3745 := by
  apply PetersenFastNode.node (nxt := #[s3328,s3746,s3274,s3747,s3748,s3749,s3507,s3750,s941,s3751,s3752,s2933,s2254,s3753,s3754,s3755,s3756,s3757,s3758,s3759,s3760,s3761,s3762,s3763,s3764,s3325,s3765,s3766,s3767,s3768,s3769,s3770,s3771]) (hints := [4555,0,4555,6869,1,6869,4555,2,4555,6869,3,6869,8674,4,8674,934,5,934,8674,6,8674,934,7,934,9954,8,9954,6995,9,10,1702,8,7507,1702,11,12,10466,13,10466,2726,14,2726,10466,15,10466,2726,16,2726,12514,17,12514,4774,18,4774,12514,19,12514,4774,20,4774,13643,21,13643,8870,22,8870,13643,23,13643,8870,24,8870,6869,6869,6997,806,4555,934,6997,4555,6997,6869,6869,934,4555,4555,5963,6869,6869,9954,6869,6869,5963,4555,4555,9954,6869,6869,7507,4555,4555,25,6611,4555,7507,6869,6869,26,4805,4805,7499,4821,6869,2726,6853,6869,7499,4805,4805,2726,2741,2741,13675,2773,6869,4774,6837,6869,13675,2741,2741,4774,6869,6869,14933,8742,8683,8870,14933,8683,14933,6869,6869,8870,8674,8674,9954,934,934,5963,934,934,9954,8674,8674,5963,934,934,7249,8674,8674,7507,8674,8674,7249,934,934,7507,934,934,2726,4949,6997,7499,2726,6997,2726,934,934,7499,934,934,4774,2901,6997,13675,4774,6997,4774,934,934,13675,934,934,8870,482,8674,13643,8870,8674,8870,934,934,13643,7507,10,7507,9954,9954,12,8019,27,28,9954,9954,10466,2726,29,2726,10466,30,10466,2726,9954,2726,9954,9954,12514,4774,5963,4774,12514,5963,12514,4774,9954,4774,1698,1698,13643,8870,9954,8870,9890,9954,13643,8870,1698,8870,2726,31,2726,10466,7507,10466,2726,7507,2726,10466,32,10466,4774,11635,4774,12514,7507,12514,4774,7507,4774,12514,11635,12514,8870,7507,8870,3443,11635,13643,8870,11635,8870,7507,7507,13643,2726,2726,4774,3403,7499,14707,4774,7499,4774,2726,2726,14707,2726,2726,8870,12885,10466,14933,8870,10466,8870,2726,2726,14933,4774,4774,8870,10837,12514,14933,8870,12514,8870,4774,4774,14933]) (by decide +kernel)
  change ∀ b ∈ [s3328,s3746,s3274,s3747,s3748,s3749,s3507,s3750,s941,s3751,s3752,s2933,s2254,s3753,s3754,s3755,s3756,s3757,s3758,s3759,s3760,s3761,s3762,s3763,s3764,s3325,s3765,s3766,s3767,s3768,s3769,s3770,s3771], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3328) b3328 <|
    PetersenLocalChildren.push (x := s3746) b3746 <|
    PetersenLocalChildren.push (x := s3274) b3274 <|
    PetersenLocalChildren.push (x := s3747) b3747 <|
    PetersenLocalChildren.push (x := s3748) b3748 <|
    PetersenLocalChildren.push (x := s3749) b3749 <|
    PetersenLocalChildren.push (x := s3507) b3507 <|
    PetersenLocalChildren.push (x := s3750) b3750 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3751) b3751 <|
    PetersenLocalChildren.push (x := s3752) b3752 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s2254) b2254 <|
    PetersenLocalChildren.push (x := s3753) b3753 <|
    PetersenLocalChildren.push (x := s3754) b3754 <|
    PetersenLocalChildren.push (x := s3755) b3755 <|
    PetersenLocalChildren.push (x := s3756) b3756 <|
    PetersenLocalChildren.push (x := s3757) b3757 <|
    PetersenLocalChildren.push (x := s3758) b3758 <|
    PetersenLocalChildren.push (x := s3759) b3759 <|
    PetersenLocalChildren.push (x := s3760) b3760 <|
    PetersenLocalChildren.push (x := s3761) b3761 <|
    PetersenLocalChildren.push (x := s3762) b3762 <|
    PetersenLocalChildren.push (x := s3763) b3763 <|
    PetersenLocalChildren.push (x := s3764) b3764 <|
    PetersenLocalChildren.push (x := s3325) b3325 <|
    PetersenLocalChildren.push (x := s3765) b3765 <|
    PetersenLocalChildren.push (x := s3766) b3766 <|
    PetersenLocalChildren.push (x := s3767) b3767 <|
    PetersenLocalChildren.push (x := s3768) b3768 <|
    PetersenLocalChildren.push (x := s3769) b3769 <|
    PetersenLocalChildren.push (x := s3770) b3770 <|
    PetersenLocalChildren.push (x := s3771) b3771 <|
    PetersenLocalChildren.nil
theorem b3772 : Blocked tgt 8 s3772 := by
  apply PetersenFastNode.node (nxt := #[s2925,s3773,s2935,s3270,s3774,s3775,s3487,s3776,s941,s2933,s3723,s3751,s3777,s3778,s3779,s3780,s3781,s3782,s3783,s3784,s3785,s3786,s3787,s3788,s3789,s2927,s3305,s3552,s3601,s3766,s3767,s3790,s3791]) (hints := [6869,0,6869,4555,1,4555,6869,2,6869,4555,3,4555,934,4,934,8674,5,8674,934,6,934,8674,7,8674,9954,8,6995,9954,9,10,1702,8,1702,7507,11,12,2726,13,2726,10466,14,10466,2726,15,2726,10466,16,10466,4774,17,4774,12514,18,12514,4774,19,4774,12514,20,12514,8870,21,8870,13643,22,13643,8870,23,8870,13643,24,13643,4297,4297,6997,4299,4555,8674,4553,4555,6997,4297,4297,8674,4555,4555,6995,6869,6869,25,6995,6869,6995,4555,4555,26,6869,6869,7765,4555,4555,1702,4555,4555,7765,6869,6869,1702,4555,4555,7499,10466,6869,10466,6603,6869,7499,4555,4555,10466,8683,8683,13675,459,4555,12514,12779,4555,13675,8683,8683,12514,4555,4555,13643,491,8683,8870,12747,8683,13643,4555,4555,8870,8674,8674,10865,934,934,6995,934,934,10865,8674,8674,6995,934,934,1702,8674,8674,27,8674,8674,1702,934,934,28,8674,8674,10466,7243,6997,7499,10466,6997,10466,8674,8674,7499,8674,8674,12514,13419,6997,13675,12514,6997,12514,8674,8674,13675,418,418,13385,482,8674,13643,8610,8674,13385,418,418,13643,6995,6995,12,1702,10,1702,8019,29,30,10466,4931,10466,2726,6995,2726,10466,6995,10466,2726,4931,2726,12514,11123,12514,4774,6995,4774,12514,6995,12514,4774,11123,4774,13643,6995,13643,8870,11123,8870,13643,11123,13643,8870,6995,8870,1702,1702,2726,10466,7765,10466,2726,7765,2726,10466,1702,10466,1702,1702,4774,12514,7765,12514,4774,7765,4774,12514,1702,12514,1702,1702,8870,13643,31,13643,8870,32,8870,13643,1702,13643,10466,10466,12514,3403,7499,14707,12514,7499,12514,10466,10466,14707,2210,2210,13643,2274,10466,14675,10402,10466,13643,2210,2210,14675,4258,4258,8870,4322,12514,13643,12450,12514,8870,4258,4258,13643]) (by decide +kernel)
  change ∀ b ∈ [s2925,s3773,s2935,s3270,s3774,s3775,s3487,s3776,s941,s2933,s3723,s3751,s3777,s3778,s3779,s3780,s3781,s3782,s3783,s3784,s3785,s3786,s3787,s3788,s3789,s2927,s3305,s3552,s3601,s3766,s3767,s3790,s3791], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2925) b2925 <|
    PetersenLocalChildren.push (x := s3773) b3773 <|
    PetersenLocalChildren.push (x := s2935) b2935 <|
    PetersenLocalChildren.push (x := s3270) b3270 <|
    PetersenLocalChildren.push (x := s3774) b3774 <|
    PetersenLocalChildren.push (x := s3775) b3775 <|
    PetersenLocalChildren.push (x := s3487) b3487 <|
    PetersenLocalChildren.push (x := s3776) b3776 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s3723) b3723 <|
    PetersenLocalChildren.push (x := s3751) b3751 <|
    PetersenLocalChildren.push (x := s3777) b3777 <|
    PetersenLocalChildren.push (x := s3778) b3778 <|
    PetersenLocalChildren.push (x := s3779) b3779 <|
    PetersenLocalChildren.push (x := s3780) b3780 <|
    PetersenLocalChildren.push (x := s3781) b3781 <|
    PetersenLocalChildren.push (x := s3782) b3782 <|
    PetersenLocalChildren.push (x := s3783) b3783 <|
    PetersenLocalChildren.push (x := s3784) b3784 <|
    PetersenLocalChildren.push (x := s3785) b3785 <|
    PetersenLocalChildren.push (x := s3786) b3786 <|
    PetersenLocalChildren.push (x := s3787) b3787 <|
    PetersenLocalChildren.push (x := s3788) b3788 <|
    PetersenLocalChildren.push (x := s3789) b3789 <|
    PetersenLocalChildren.push (x := s2927) b2927 <|
    PetersenLocalChildren.push (x := s3305) b3305 <|
    PetersenLocalChildren.push (x := s3552) b3552 <|
    PetersenLocalChildren.push (x := s3601) b3601 <|
    PetersenLocalChildren.push (x := s3766) b3766 <|
    PetersenLocalChildren.push (x := s3767) b3767 <|
    PetersenLocalChildren.push (x := s3790) b3790 <|
    PetersenLocalChildren.push (x := s3791) b3791 <|
    PetersenLocalChildren.nil
theorem b3793 : Blocked tgt 8 s3793 := by
  apply PetersenFastNode.node (nxt := #[s2928,s3306,s3794,s3795,s3796,s2937,s3797,s3798,s3621,s3799,s3800,s3489,s3801,s3802,s3724,s3768,s3803,s3804,s3805,s3806,s941,s3807,s3808,s3809,s3810,s3811,s3812,s3732,s3780,s3813,s3814,s3815,s3816,s3817,s3818,s3819,s3820,s3821,s3822,s3823,s3824,s3825,s3826,s3827,s3828]) (hints := [6881,6881,7009,818,4567,946,7009,4567,7009,6881,6881,946,4567,4567,7007,6881,6881,0,7007,6881,7007,4567,4567,1,7519,6881,7519,4567,4567,1714,6623,4567,7519,6623,6881,1714,4567,4567,2,4833,6881,2738,6865,6881,3,4567,4567,2738,4567,4567,4,6881,6881,5,6881,6881,6,4567,4567,7,8695,8695,13687,471,4567,4786,12791,4567,13687,8695,8695,4786,4567,4567,13655,503,8695,8882,12759,8695,13655,4567,4567,8882,8686,8686,10877,946,946,7007,946,946,10877,8686,8686,7007,946,946,1714,8686,8686,7519,1714,8686,1714,946,946,7519,946,946,2738,4961,7009,8,2738,7009,2738,946,946,9,8686,8686,10,946,946,11,946,946,12,8686,8686,13,946,946,4786,2913,7009,13687,4786,7009,4786,946,946,13687,946,946,8882,494,8686,13655,8882,8686,8882,946,946,13655,7007,7007,7519,1714,14,1714,7519,15,7519,1714,7007,1714,4959,16,17,7007,7007,18,2738,19,2738,9966,7007,20,9966,19,21,12526,11135,12526,4786,7007,4786,12526,7007,12526,4786,11135,4786,13655,7007,13655,8882,11135,8882,13655,11135,13655,8882,7007,8882,1714,1714,2738,7519,7519,22,2738,7519,2738,1714,1714,23,24,25,26,1714,1714,27,1714,1714,28,29,30,31,1714,1714,4786,12526,7519,12526,4786,7519,4786,1714,1714,12526,1714,1714,8882,3455,11647,13655,8882,11647,8882,1714,1714,13655,2738,2738,20,10478,18,32,2738,2738,4786,14719,33,14719,4786,34,4786,2738,2738,14719,2738,2738,8882,14687,35,14687,8882,36,8882,2738,2738,14687,12526,37,12526,4786,38,4786,12526,39,12526,4786,40,4786,13655,41,13655,8882,42,8882,13655,43,13655,8882,44,8882,4786,4786,8882,4334,12526,13655,8882,12526,8882,4786,4786,13655]) (by decide +kernel)
  change ∀ b ∈ [s2928,s3306,s3794,s3795,s3796,s2937,s3797,s3798,s3621,s3799,s3800,s3489,s3801,s3802,s3724,s3768,s3803,s3804,s3805,s3806,s941,s3807,s3808,s3809,s3810,s3811,s3812,s3732,s3780,s3813,s3814,s3815,s3816,s3817,s3818,s3819,s3820,s3821,s3822,s3823,s3824,s3825,s3826,s3827,s3828], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2928) b2928 <|
    PetersenLocalChildren.push (x := s3306) b3306 <|
    PetersenLocalChildren.push (x := s3794) b3794 <|
    PetersenLocalChildren.push (x := s3795) b3795 <|
    PetersenLocalChildren.push (x := s3796) b3796 <|
    PetersenLocalChildren.push (x := s2937) b2937 <|
    PetersenLocalChildren.push (x := s3797) b3797 <|
    PetersenLocalChildren.push (x := s3798) b3798 <|
    PetersenLocalChildren.push (x := s3621) b3621 <|
    PetersenLocalChildren.push (x := s3799) b3799 <|
    PetersenLocalChildren.push (x := s3800) b3800 <|
    PetersenLocalChildren.push (x := s3489) b3489 <|
    PetersenLocalChildren.push (x := s3801) b3801 <|
    PetersenLocalChildren.push (x := s3802) b3802 <|
    PetersenLocalChildren.push (x := s3724) b3724 <|
    PetersenLocalChildren.push (x := s3768) b3768 <|
    PetersenLocalChildren.push (x := s3803) b3803 <|
    PetersenLocalChildren.push (x := s3804) b3804 <|
    PetersenLocalChildren.push (x := s3805) b3805 <|
    PetersenLocalChildren.push (x := s3806) b3806 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3807) b3807 <|
    PetersenLocalChildren.push (x := s3808) b3808 <|
    PetersenLocalChildren.push (x := s3809) b3809 <|
    PetersenLocalChildren.push (x := s3810) b3810 <|
    PetersenLocalChildren.push (x := s3811) b3811 <|
    PetersenLocalChildren.push (x := s3812) b3812 <|
    PetersenLocalChildren.push (x := s3732) b3732 <|
    PetersenLocalChildren.push (x := s3780) b3780 <|
    PetersenLocalChildren.push (x := s3813) b3813 <|
    PetersenLocalChildren.push (x := s3814) b3814 <|
    PetersenLocalChildren.push (x := s3815) b3815 <|
    PetersenLocalChildren.push (x := s3816) b3816 <|
    PetersenLocalChildren.push (x := s3817) b3817 <|
    PetersenLocalChildren.push (x := s3818) b3818 <|
    PetersenLocalChildren.push (x := s3819) b3819 <|
    PetersenLocalChildren.push (x := s3820) b3820 <|
    PetersenLocalChildren.push (x := s3821) b3821 <|
    PetersenLocalChildren.push (x := s3822) b3822 <|
    PetersenLocalChildren.push (x := s3823) b3823 <|
    PetersenLocalChildren.push (x := s3824) b3824 <|
    PetersenLocalChildren.push (x := s3825) b3825 <|
    PetersenLocalChildren.push (x := s3826) b3826 <|
    PetersenLocalChildren.push (x := s3827) b3827 <|
    PetersenLocalChildren.push (x := s3828) b3828 <|
    PetersenLocalChildren.nil
theorem b3829 : Blocked tgt 8 s3829 := by
  apply PetersenFastNode.node (nxt := #[s3830,s3831,s3280,s3832,s3833,s3834,s3511,s3835,s941,s3836,s3837,s3838,s3839,s3755,s3840,s3841,s3805,s3842,s3843,s3844,s3845,s3846,s3847,s3848,s3849,s2929,s3307,s3725,s3769,s3850,s3851,s3852,s3853]) (hints := [4555,0,4555,4805,1,4805,4555,2,4555,4805,3,4805,8674,4,8674,934,5,934,8674,6,8674,934,7,934,9954,8,6995,9954,9,10,7507,11,7507,1702,12,1702,7507,13,7507,1702,14,1702,2726,8,10466,2726,15,16,12514,17,12514,4774,18,4774,12514,19,12514,4774,20,4774,13643,21,13643,8870,22,8870,13643,23,13643,8870,24,8870,4805,4805,4933,806,4555,934,4933,4555,4933,4805,4805,934,4555,4555,6995,4805,4805,25,4805,4805,6995,4555,4555,26,4805,4805,5701,1574,4555,1702,5701,4555,5701,4805,4805,1702,4805,4805,7499,6869,6869,10466,6603,6869,7499,4805,4805,10466,8683,8683,13675,4774,4805,4774,4773,4805,13675,4773,8683,4774,4805,4805,12869,8742,8683,8870,12869,8683,12869,4805,4805,8870,8674,8674,10865,934,934,6995,934,934,10865,8674,8674,6995,934,934,1702,8674,8674,7507,1702,8674,1702,934,934,7507,934,934,10466,6997,6997,7499,10466,6997,10466,934,934,7499,934,934,4774,837,4933,13675,4774,4933,4774,934,934,13675,934,934,8870,482,8674,13643,8870,8674,8870,934,934,13643,6995,6995,7507,1702,27,1702,7507,28,7507,1702,6995,1702,10466,10,10466,6995,6995,16,12002,29,30,12514,11123,12514,4774,6995,4774,12514,6995,12514,4774,11123,4774,13643,6995,13643,8870,11123,8870,13643,11123,13643,8870,6995,8870,1702,1702,31,10466,7507,10466,7491,7507,32,1702,1702,10466,1702,1702,4774,1605,5701,12514,4774,5701,4774,1702,1702,12514,1702,1702,8870,3443,11635,13643,8870,11635,8870,1702,1702,13643,4774,10466,4774,3403,7499,14707,4774,7499,4774,10466,10466,14707,8870,2210,8870,2274,10466,14675,8870,10466,8870,2210,2210,14675,4774,4774,8870,8773,12514,12869,8870,12514,8870,4774,4774,12869]) (by decide +kernel)
  change ∀ b ∈ [s3830,s3831,s3280,s3832,s3833,s3834,s3511,s3835,s941,s3836,s3837,s3838,s3839,s3755,s3840,s3841,s3805,s3842,s3843,s3844,s3845,s3846,s3847,s3848,s3849,s2929,s3307,s3725,s3769,s3850,s3851,s3852,s3853], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3830) b3830 <|
    PetersenLocalChildren.push (x := s3831) b3831 <|
    PetersenLocalChildren.push (x := s3280) b3280 <|
    PetersenLocalChildren.push (x := s3832) b3832 <|
    PetersenLocalChildren.push (x := s3833) b3833 <|
    PetersenLocalChildren.push (x := s3834) b3834 <|
    PetersenLocalChildren.push (x := s3511) b3511 <|
    PetersenLocalChildren.push (x := s3835) b3835 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3836) b3836 <|
    PetersenLocalChildren.push (x := s3837) b3837 <|
    PetersenLocalChildren.push (x := s3838) b3838 <|
    PetersenLocalChildren.push (x := s3839) b3839 <|
    PetersenLocalChildren.push (x := s3755) b3755 <|
    PetersenLocalChildren.push (x := s3840) b3840 <|
    PetersenLocalChildren.push (x := s3841) b3841 <|
    PetersenLocalChildren.push (x := s3805) b3805 <|
    PetersenLocalChildren.push (x := s3842) b3842 <|
    PetersenLocalChildren.push (x := s3843) b3843 <|
    PetersenLocalChildren.push (x := s3844) b3844 <|
    PetersenLocalChildren.push (x := s3845) b3845 <|
    PetersenLocalChildren.push (x := s3846) b3846 <|
    PetersenLocalChildren.push (x := s3847) b3847 <|
    PetersenLocalChildren.push (x := s3848) b3848 <|
    PetersenLocalChildren.push (x := s3849) b3849 <|
    PetersenLocalChildren.push (x := s2929) b2929 <|
    PetersenLocalChildren.push (x := s3307) b3307 <|
    PetersenLocalChildren.push (x := s3725) b3725 <|
    PetersenLocalChildren.push (x := s3769) b3769 <|
    PetersenLocalChildren.push (x := s3850) b3850 <|
    PetersenLocalChildren.push (x := s3851) b3851 <|
    PetersenLocalChildren.push (x := s3852) b3852 <|
    PetersenLocalChildren.push (x := s3853) b3853 <|
    PetersenLocalChildren.nil
theorem b3856 : Blocked tgt 8 s3856 := by
  apply PetersenFastNode.node (nxt := #[s2930,s3308,s3857,s3858,s3859,s2941,s3860,s3861,s3656,s3862,s3863,s3493,s3864,s3865,s3866,s3867,s3868,s3869,s941,s3870,s3871,s3872,s3873,s3874,s3875,s3738,s3784,s3876,s3877,s3878,s3879,s3822,s3880,s3881,s3882,s3883,s3884,s3885,s3886,s3887,s3888,s3889,s3890,s3891,s3892]) (hints := [6881,6881,7009,818,4567,946,7009,4567,7009,6881,6881,946,4567,4567,5975,6881,6881,0,5975,6881,5975,4567,4567,1,7519,6881,7519,4567,4567,1714,6623,4567,7519,6623,6881,1714,4567,4567,7511,4833,6881,2738,6615,6881,7511,4567,4567,2738,8695,8695,2,4567,4567,4786,4567,4567,3,8695,8695,4786,8695,8695,4,4567,4567,5,4567,4567,6,8695,8695,7,4567,4567,13655,503,8695,8882,12759,8695,13655,4567,4567,8882,8686,8686,5717,946,946,5975,946,946,5717,8686,8686,5975,946,946,1714,8686,8686,7519,1714,8686,1714,946,946,7519,946,946,2738,4961,7009,7511,2738,7009,2738,946,946,7511,946,946,4786,2913,7009,8,4786,7009,4786,946,946,9,8686,8686,10,946,946,11,946,946,12,8686,8686,13,946,946,8882,494,8686,13655,8882,8686,8882,946,946,13655,7007,7007,7519,1714,5975,1714,7519,5975,7519,1714,7007,1714,10478,5975,10478,2738,7007,2738,10478,7007,10478,2738,5975,2738,1879,14,15,5975,5975,16,4786,17,4786,9966,5975,18,9966,17,19,5975,5975,13655,8882,20,8882,13655,21,13655,8882,5975,8882,1714,1714,2738,10478,7519,10478,2738,7519,2738,1714,1714,10478,1714,1714,4786,7519,7519,22,4786,7519,4786,1714,1714,23,11647,11647,24,1714,1714,25,1714,1714,26,11647,11647,27,1714,1714,8882,3455,11647,13655,8882,11647,8882,1714,1714,13655,2738,2738,4786,7511,7511,28,4786,7511,4786,2738,2738,29,10478,10478,30,2738,2738,31,2738,2738,32,10478,10478,33,2738,2738,8882,2286,10478,14687,8882,10478,8882,2738,2738,14687,4786,4786,18,12526,16,34,4786,4786,8882,13655,35,13655,8882,36,8882,4786,4786,13655,37,38,39,8882,40,8882,41,42,43,8882,44,8882]) (by decide +kernel)
  change ∀ b ∈ [s2930,s3308,s3857,s3858,s3859,s2941,s3860,s3861,s3656,s3862,s3863,s3493,s3864,s3865,s3866,s3867,s3868,s3869,s941,s3870,s3871,s3872,s3873,s3874,s3875,s3738,s3784,s3876,s3877,s3878,s3879,s3822,s3880,s3881,s3882,s3883,s3884,s3885,s3886,s3887,s3888,s3889,s3890,s3891,s3892], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2930) b2930 <|
    PetersenLocalChildren.push (x := s3308) b3308 <|
    PetersenLocalChildren.push (x := s3857) b3857 <|
    PetersenLocalChildren.push (x := s3858) b3858 <|
    PetersenLocalChildren.push (x := s3859) b3859 <|
    PetersenLocalChildren.push (x := s2941) b2941 <|
    PetersenLocalChildren.push (x := s3860) b3860 <|
    PetersenLocalChildren.push (x := s3861) b3861 <|
    PetersenLocalChildren.push (x := s3656) b3656 <|
    PetersenLocalChildren.push (x := s3862) b3862 <|
    PetersenLocalChildren.push (x := s3863) b3863 <|
    PetersenLocalChildren.push (x := s3493) b3493 <|
    PetersenLocalChildren.push (x := s3864) b3864 <|
    PetersenLocalChildren.push (x := s3865) b3865 <|
    PetersenLocalChildren.push (x := s3866) b3866 <|
    PetersenLocalChildren.push (x := s3867) b3867 <|
    PetersenLocalChildren.push (x := s3868) b3868 <|
    PetersenLocalChildren.push (x := s3869) b3869 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3870) b3870 <|
    PetersenLocalChildren.push (x := s3871) b3871 <|
    PetersenLocalChildren.push (x := s3872) b3872 <|
    PetersenLocalChildren.push (x := s3873) b3873 <|
    PetersenLocalChildren.push (x := s3874) b3874 <|
    PetersenLocalChildren.push (x := s3875) b3875 <|
    PetersenLocalChildren.push (x := s3738) b3738 <|
    PetersenLocalChildren.push (x := s3784) b3784 <|
    PetersenLocalChildren.push (x := s3876) b3876 <|
    PetersenLocalChildren.push (x := s3877) b3877 <|
    PetersenLocalChildren.push (x := s3878) b3878 <|
    PetersenLocalChildren.push (x := s3879) b3879 <|
    PetersenLocalChildren.push (x := s3822) b3822 <|
    PetersenLocalChildren.push (x := s3880) b3880 <|
    PetersenLocalChildren.push (x := s3881) b3881 <|
    PetersenLocalChildren.push (x := s3882) b3882 <|
    PetersenLocalChildren.push (x := s3883) b3883 <|
    PetersenLocalChildren.push (x := s3884) b3884 <|
    PetersenLocalChildren.push (x := s3885) b3885 <|
    PetersenLocalChildren.push (x := s3886) b3886 <|
    PetersenLocalChildren.push (x := s3887) b3887 <|
    PetersenLocalChildren.push (x := s3888) b3888 <|
    PetersenLocalChildren.push (x := s3889) b3889 <|
    PetersenLocalChildren.push (x := s3890) b3890 <|
    PetersenLocalChildren.push (x := s3891) b3891 <|
    PetersenLocalChildren.push (x := s3892) b3892 <|
    PetersenLocalChildren.nil
theorem b3893 : Blocked tgt 8 s3893 := by
  apply PetersenFastNode.node (nxt := #[s3894,s3895,s3288,s3896,s3897,s3898,s3515,s3899,s941,s3900,s3901,s3902,s3903,s3759,s3904,s3905,s3906,s3844,s3907,s3908,s3868,s3909,s3910,s3911,s3912,s2931,s3309,s3913,s3914,s3915,s3916]) (hints := [4553,0,4553,2739,1,2739,4553,2,4553,2739,3,2739,8672,4,8672,932,5,932,8672,6,8672,932,7,932,9952,8,5961,9952,9,10,7505,11,7505,1700,12,1700,7505,13,7505,1700,14,1700,10464,15,10464,2724,16,2724,10464,17,10464,2724,18,2724,4772,8,12512,4772,19,20,13641,21,13641,8868,22,8868,13641,23,13641,8868,24,8868,2739,2739,2867,804,4553,932,2867,4553,2867,2739,2739,932,4553,4553,5961,2739,2739,25,2739,2739,5961,4553,4553,26,2739,2739,3635,1572,4553,1700,3635,4553,3635,2739,2739,1700,4553,4553,7497,2724,2739,2724,2723,2739,7497,2723,4553,2724,2739,2739,13673,457,4553,12512,12777,4553,13673,2739,2739,12512,2739,2739,10803,8740,8681,8868,10803,8681,10803,2739,2739,8868,8672,8672,5703,932,932,5961,932,932,5703,8672,8672,5961,932,932,1700,8672,8672,7505,1700,8672,1700,932,932,7505,932,932,2724,819,2867,7497,2724,2867,2724,932,932,7497,932,932,12512,6995,6995,13673,12512,6995,12512,932,932,13673,932,932,8868,480,8672,13641,8868,8672,8868,932,932,13641,6993,6993,7505,1700,5961,1700,7505,5961,7505,1700,6993,1700,10464,5961,10464,2724,6993,2724,10464,6993,10464,2724,5961,2724,12512,10,12512,5961,5961,20,14048,27,28,5961,5961,13641,8868,29,8868,13641,30,13641,8868,5961,8868,1700,1700,2724,1587,3635,10464,2724,3635,2724,1700,1700,10464,1700,1700,14705,12512,7505,12512,14705,7505,14705,1700,1700,12512,1700,1700,8868,3441,11633,13641,8868,11633,8868,1700,1700,13641,2724,2724,12512,3401,7497,14705,12512,7497,12512,2724,2724,14705,2724,2724,8868,8755,10464,10803,8868,10464,8868,2724,2724,10803,8868,4256,8868,4320,12512,13641,8868,12512,8868,4256,4256,13641]) (by decide +kernel)
  change ∀ b ∈ [s3894,s3895,s3288,s3896,s3897,s3898,s3515,s3899,s941,s3900,s3901,s3902,s3903,s3759,s3904,s3905,s3906,s3844,s3907,s3908,s3868,s3909,s3910,s3911,s3912,s2931,s3309,s3913,s3914,s3915,s3916], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3894) b3894 <|
    PetersenLocalChildren.push (x := s3895) b3895 <|
    PetersenLocalChildren.push (x := s3288) b3288 <|
    PetersenLocalChildren.push (x := s3896) b3896 <|
    PetersenLocalChildren.push (x := s3897) b3897 <|
    PetersenLocalChildren.push (x := s3898) b3898 <|
    PetersenLocalChildren.push (x := s3515) b3515 <|
    PetersenLocalChildren.push (x := s3899) b3899 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3900) b3900 <|
    PetersenLocalChildren.push (x := s3901) b3901 <|
    PetersenLocalChildren.push (x := s3902) b3902 <|
    PetersenLocalChildren.push (x := s3903) b3903 <|
    PetersenLocalChildren.push (x := s3759) b3759 <|
    PetersenLocalChildren.push (x := s3904) b3904 <|
    PetersenLocalChildren.push (x := s3905) b3905 <|
    PetersenLocalChildren.push (x := s3906) b3906 <|
    PetersenLocalChildren.push (x := s3844) b3844 <|
    PetersenLocalChildren.push (x := s3907) b3907 <|
    PetersenLocalChildren.push (x := s3908) b3908 <|
    PetersenLocalChildren.push (x := s3868) b3868 <|
    PetersenLocalChildren.push (x := s3909) b3909 <|
    PetersenLocalChildren.push (x := s3910) b3910 <|
    PetersenLocalChildren.push (x := s3911) b3911 <|
    PetersenLocalChildren.push (x := s3912) b3912 <|
    PetersenLocalChildren.push (x := s2931) b2931 <|
    PetersenLocalChildren.push (x := s3309) b3309 <|
    PetersenLocalChildren.push (x := s3913) b3913 <|
    PetersenLocalChildren.push (x := s3914) b3914 <|
    PetersenLocalChildren.push (x := s3915) b3915 <|
    PetersenLocalChildren.push (x := s3916) b3916 <|
    PetersenLocalChildren.nil
theorem b3943 : Blocked tgt 8 s3943 := by
  apply PetersenFastNode.node (nxt := #[s3944,s3945,s3294,s3946,s3947,s3948,s3519,s3949,s941,s3950,s3951,s3952,s3953,s3763,s3954,s3955,s3956,s3848,s3957,s3958,s3959,s3911,s3960,s3961,s3929,s3443,s3962,s3872,s3916,s3963,s3964,s3965,s3966]) (hints := [4555,0,4555,6869,1,6869,4555,2,4555,6869,3,6869,8674,4,8674,934,5,934,8674,6,8674,934,7,934,9954,8,9954,1698,9,10,7507,11,7507,1702,12,1702,7507,13,7507,1702,14,1702,10466,15,10466,2726,16,2726,10466,17,10466,2726,18,2726,12514,19,12514,4774,20,4774,12514,21,12514,4774,22,4774,8870,8,13643,8870,23,24,6869,6869,6997,806,4555,934,6997,4555,6997,6869,6869,934,4555,4555,10091,6869,6869,9954,6869,6869,10091,4555,4555,9954,6869,6869,7765,1574,4555,1702,7765,4555,7765,6869,6869,1702,4805,4805,7499,4821,6869,2726,6853,6869,7499,4805,4805,2726,2741,2741,13675,2773,6869,4774,6837,6869,13675,2741,2741,4774,6869,6869,13643,491,8683,25,12747,8683,13643,6869,6869,26,8674,8674,9954,934,934,10091,934,934,9954,8674,8674,10091,934,934,1702,8674,8674,7507,1702,8674,1702,934,934,7507,934,934,2726,4949,6997,7499,2726,6997,2726,934,934,7499,934,934,4774,2901,6997,13675,4774,6997,4774,934,934,13675,934,934,13385,482,8674,13643,8610,8674,13385,934,934,13643,8930,11123,7507,1702,9954,1702,9954,9954,7507,1702,11123,1702,9954,9954,10466,2726,11123,2726,10466,11123,10466,2726,9954,2726,9954,9954,12514,4774,27,4774,12514,28,12514,4774,9954,4774,13643,10,13643,9954,9954,24,9890,29,30,1702,1702,2726,5717,7765,10466,2726,7765,2726,1702,1702,10466,1702,1702,4774,3669,7765,12514,4774,7765,4774,1702,1702,12514,1702,1702,14675,3443,11635,13643,14675,11635,14675,1702,1702,13643,2726,2726,4774,3403,7499,14707,4774,7499,4774,2726,2726,14707,2726,2726,13643,2274,10466,14675,10402,10466,13643,2726,2726,14675,4774,4774,31,4322,12514,13643,12450,12514,32,4774,4774,13643]) (by decide +kernel)
  change ∀ b ∈ [s3944,s3945,s3294,s3946,s3947,s3948,s3519,s3949,s941,s3950,s3951,s3952,s3953,s3763,s3954,s3955,s3956,s3848,s3957,s3958,s3959,s3911,s3960,s3961,s3929,s3443,s3962,s3872,s3916,s3963,s3964,s3965,s3966], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3944) b3944 <|
    PetersenLocalChildren.push (x := s3945) b3945 <|
    PetersenLocalChildren.push (x := s3294) b3294 <|
    PetersenLocalChildren.push (x := s3946) b3946 <|
    PetersenLocalChildren.push (x := s3947) b3947 <|
    PetersenLocalChildren.push (x := s3948) b3948 <|
    PetersenLocalChildren.push (x := s3519) b3519 <|
    PetersenLocalChildren.push (x := s3949) b3949 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3950) b3950 <|
    PetersenLocalChildren.push (x := s3951) b3951 <|
    PetersenLocalChildren.push (x := s3952) b3952 <|
    PetersenLocalChildren.push (x := s3953) b3953 <|
    PetersenLocalChildren.push (x := s3763) b3763 <|
    PetersenLocalChildren.push (x := s3954) b3954 <|
    PetersenLocalChildren.push (x := s3955) b3955 <|
    PetersenLocalChildren.push (x := s3956) b3956 <|
    PetersenLocalChildren.push (x := s3848) b3848 <|
    PetersenLocalChildren.push (x := s3957) b3957 <|
    PetersenLocalChildren.push (x := s3958) b3958 <|
    PetersenLocalChildren.push (x := s3959) b3959 <|
    PetersenLocalChildren.push (x := s3911) b3911 <|
    PetersenLocalChildren.push (x := s3960) b3960 <|
    PetersenLocalChildren.push (x := s3961) b3961 <|
    PetersenLocalChildren.push (x := s3929) b3929 <|
    PetersenLocalChildren.push (x := s3443) b3443 <|
    PetersenLocalChildren.push (x := s3962) b3962 <|
    PetersenLocalChildren.push (x := s3872) b3872 <|
    PetersenLocalChildren.push (x := s3916) b3916 <|
    PetersenLocalChildren.push (x := s3963) b3963 <|
    PetersenLocalChildren.push (x := s3964) b3964 <|
    PetersenLocalChildren.push (x := s3965) b3965 <|
    PetersenLocalChildren.push (x := s3966) b3966 <|
    PetersenLocalChildren.nil
theorem b3969 : Blocked tgt 8 s3969 := by
  apply PetersenFastNode.node (nxt := #[s3329,s3970,s3971,s3338,s3972,s3973,s3974,s3558,s3975,s3976,s3808,s3977,s3978,s3732,s3755,s3979,s3980,s3981,s3982,s3983,s941,s3984,s3985,s3986,s3987,s3988,s3989,s3990,s3991,s3992,s3993]) (hints := [6867,6867,6995,804,4553,932,6995,4553,6995,6867,6867,932,4553,4553,5961,9824,6867,9952,5961,6867,5961,4553,4553,9952,7505,6867,7505,4553,4553,0,6609,4553,7505,6609,6867,1,4553,4553,7497,6867,6867,10464,6601,6867,7497,4553,4553,10464,4803,4803,2,4553,4553,3,4553,4553,4,4803,4803,5,8681,8681,13673,457,4553,4772,12777,4553,13673,8681,8681,4772,4553,4553,13641,489,8681,8868,12745,8681,13641,4553,4553,8868,8672,8672,9952,932,932,5961,9952,932,9952,8672,8672,5961,932,932,7763,8672,8672,7505,8672,8672,7763,932,932,7505,932,932,10464,6995,6995,7497,10464,6995,10464,932,932,7497,932,932,6,8672,8672,7,8672,8672,8,932,932,9,932,932,4772,2899,6995,13673,4772,6995,4772,932,932,13673,932,932,8868,480,8672,13641,8868,8672,8868,932,932,13641,6993,6993,7505,9952,9952,7763,9952,9952,7505,6993,6993,7763,9952,9952,10464,6993,6993,10,10464,6993,10464,9952,9952,11,4929,4929,12,9952,9952,13,9952,9952,14,4929,4929,15,9952,9952,12512,4772,5961,4772,12512,5961,12512,9952,9952,4772,1696,1696,13641,1760,9952,8868,9888,9952,13641,1696,1696,8868,5715,16,17,7505,7505,18,10464,19,10464,1700,7505,20,1700,19,21,4772,11633,4772,12512,7505,12512,4772,7505,4772,12512,11633,12512,8868,7505,8868,3441,11633,13641,8868,11633,8868,7505,7505,13641,2724,10464,20,2724,18,22,4772,10464,4772,3401,7497,14705,4772,7497,4772,10464,10464,14705,8868,2208,8868,2272,10464,14673,8868,10464,8868,2208,2208,14673,4772,23,4772,12512,24,12512,4772,25,4772,12512,26,12512,8868,27,8868,13641,28,13641,8868,29,8868,13641,30,13641,4772,4772,8868,4320,12512,13641,8868,12512,8868,4772,4772,13641]) (by decide +kernel)
  change ∀ b ∈ [s3329,s3970,s3971,s3338,s3972,s3973,s3974,s3558,s3975,s3976,s3808,s3977,s3978,s3732,s3755,s3979,s3980,s3981,s3982,s3983,s941,s3984,s3985,s3986,s3987,s3988,s3989,s3990,s3991,s3992,s3993], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3329) b3329 <|
    PetersenLocalChildren.push (x := s3970) b3970 <|
    PetersenLocalChildren.push (x := s3971) b3971 <|
    PetersenLocalChildren.push (x := s3338) b3338 <|
    PetersenLocalChildren.push (x := s3972) b3972 <|
    PetersenLocalChildren.push (x := s3973) b3973 <|
    PetersenLocalChildren.push (x := s3974) b3974 <|
    PetersenLocalChildren.push (x := s3558) b3558 <|
    PetersenLocalChildren.push (x := s3975) b3975 <|
    PetersenLocalChildren.push (x := s3976) b3976 <|
    PetersenLocalChildren.push (x := s3808) b3808 <|
    PetersenLocalChildren.push (x := s3977) b3977 <|
    PetersenLocalChildren.push (x := s3978) b3978 <|
    PetersenLocalChildren.push (x := s3732) b3732 <|
    PetersenLocalChildren.push (x := s3755) b3755 <|
    PetersenLocalChildren.push (x := s3979) b3979 <|
    PetersenLocalChildren.push (x := s3980) b3980 <|
    PetersenLocalChildren.push (x := s3981) b3981 <|
    PetersenLocalChildren.push (x := s3982) b3982 <|
    PetersenLocalChildren.push (x := s3983) b3983 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3984) b3984 <|
    PetersenLocalChildren.push (x := s3985) b3985 <|
    PetersenLocalChildren.push (x := s3986) b3986 <|
    PetersenLocalChildren.push (x := s3987) b3987 <|
    PetersenLocalChildren.push (x := s3988) b3988 <|
    PetersenLocalChildren.push (x := s3989) b3989 <|
    PetersenLocalChildren.push (x := s3990) b3990 <|
    PetersenLocalChildren.push (x := s3991) b3991 <|
    PetersenLocalChildren.push (x := s3992) b3992 <|
    PetersenLocalChildren.push (x := s3993) b3993 <|
    PetersenLocalChildren.nil
theorem b3994 : Blocked tgt 8 s3994 := by
  apply PetersenFastNode.node (nxt := #[s3995,s3996,s3374,s3997,s3998,s3999,s3581,s4000,s3838,s4001,s3780,s4002,s941,s4003,s4004,s4005,s3982,s4006,s4007,s4008,s4009,s4010,s4011,s4012,s4013,s3330,s4014,s4015,s4016,s3626,s4017,s4018,s3853,s4019,s4020,s4021,s4022,s4023,s4024]) (hints := [6875,0,6875,4561,1,4561,6875,2,6875,4561,3,4561,940,4,940,8680,5,8680,940,6,940,8680,7,8680,7001,8,7001,9960,9,9960,7001,10,7001,9960,11,9960,1708,12,7513,1708,13,14,2732,12,2732,10472,15,16,4780,17,4780,12520,18,12520,4780,19,4780,12520,20,12520,8876,21,8876,13649,22,13649,8876,23,8876,13649,24,13649,4303,4303,7003,4305,4561,8680,4559,4561,7003,4303,4303,8680,4561,4561,5969,9832,6875,9960,5969,6875,5969,4561,4561,9960,7513,6875,7513,4561,4561,25,4561,4561,7513,6617,6875,26,4561,4561,27,4827,6875,2732,6859,6875,28,4561,4561,2732,8689,8689,13681,465,4561,12520,12785,4561,13681,8689,8689,12520,4561,4561,13649,497,8689,8876,12753,8689,13649,4561,4561,8876,8680,8680,9960,5713,940,5969,9960,940,9960,8680,8680,5969,940,940,7771,8680,8680,7513,8680,8680,7771,940,940,7513,8680,8680,2732,4955,7003,29,2732,7003,2732,8680,8680,30,8680,8680,12520,13425,7003,13681,12520,7003,12520,8680,8680,13681,424,424,13391,488,8680,13649,8616,8680,13391,424,424,13649,7001,7001,7513,9960,9960,7771,9960,9960,7513,7001,7001,7771,9960,9960,31,2732,7001,2732,6985,7001,32,9960,9960,2732,9960,9960,12520,1873,5969,4780,12520,5969,12520,9960,9960,4780,1704,1704,13649,1768,9960,8876,9896,9960,13649,1704,1704,8876,2732,14,2732,7513,7513,16,3756,33,34,4780,11641,4780,12520,7513,12520,4780,7513,4780,12520,11641,12520,8876,7513,8876,13649,11641,13649,8876,11641,8876,13649,7513,13649,12520,2732,12520,12665,35,14713,12520,36,12520,2732,2732,14713,13649,2732,13649,12633,37,14681,13649,38,13649,2732,2732,14681,4264,4264,8876,4328,12520,13649,12456,12520,8876,4264,4264,13649]) (by decide +kernel)
  change ∀ b ∈ [s3995,s3996,s3374,s3997,s3998,s3999,s3581,s4000,s3838,s4001,s3780,s4002,s941,s4003,s4004,s4005,s3982,s4006,s4007,s4008,s4009,s4010,s4011,s4012,s4013,s3330,s4014,s4015,s4016,s3626,s4017,s4018,s3853,s4019,s4020,s4021,s4022,s4023,s4024], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3995) b3995 <|
    PetersenLocalChildren.push (x := s3996) b3996 <|
    PetersenLocalChildren.push (x := s3374) b3374 <|
    PetersenLocalChildren.push (x := s3997) b3997 <|
    PetersenLocalChildren.push (x := s3998) b3998 <|
    PetersenLocalChildren.push (x := s3999) b3999 <|
    PetersenLocalChildren.push (x := s3581) b3581 <|
    PetersenLocalChildren.push (x := s4000) b4000 <|
    PetersenLocalChildren.push (x := s3838) b3838 <|
    PetersenLocalChildren.push (x := s4001) b4001 <|
    PetersenLocalChildren.push (x := s3780) b3780 <|
    PetersenLocalChildren.push (x := s4002) b4002 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4003) b4003 <|
    PetersenLocalChildren.push (x := s4004) b4004 <|
    PetersenLocalChildren.push (x := s4005) b4005 <|
    PetersenLocalChildren.push (x := s3982) b3982 <|
    PetersenLocalChildren.push (x := s4006) b4006 <|
    PetersenLocalChildren.push (x := s4007) b4007 <|
    PetersenLocalChildren.push (x := s4008) b4008 <|
    PetersenLocalChildren.push (x := s4009) b4009 <|
    PetersenLocalChildren.push (x := s4010) b4010 <|
    PetersenLocalChildren.push (x := s4011) b4011 <|
    PetersenLocalChildren.push (x := s4012) b4012 <|
    PetersenLocalChildren.push (x := s4013) b4013 <|
    PetersenLocalChildren.push (x := s3330) b3330 <|
    PetersenLocalChildren.push (x := s4014) b4014 <|
    PetersenLocalChildren.push (x := s4015) b4015 <|
    PetersenLocalChildren.push (x := s4016) b4016 <|
    PetersenLocalChildren.push (x := s3626) b3626 <|
    PetersenLocalChildren.push (x := s4017) b4017 <|
    PetersenLocalChildren.push (x := s4018) b4018 <|
    PetersenLocalChildren.push (x := s3853) b3853 <|
    PetersenLocalChildren.push (x := s4019) b4019 <|
    PetersenLocalChildren.push (x := s4020) b4020 <|
    PetersenLocalChildren.push (x := s4021) b4021 <|
    PetersenLocalChildren.push (x := s4022) b4022 <|
    PetersenLocalChildren.push (x := s4023) b4023 <|
    PetersenLocalChildren.push (x := s4024) b4024 <|
    PetersenLocalChildren.nil
theorem b4027 : Blocked tgt 8 s4027 := by
  apply PetersenFastNode.node (nxt := #[s3331,s4028,s4029,s3344,s4030,s4031,s4032,s3562,s4033,s4034,s3873,s4035,s4036,s3738,s3759,s4037,s4038,s4039,s4040,s4041,s941,s4042,s4043,s4044,s4045,s4046,s4047,s3987,s4048,s4049,s4050,s4051,s4052,s4053,s4054]) (hints := [6871,6871,6999,808,4557,936,6999,4557,6999,6871,6871,936,4557,4557,5965,9828,6871,9956,5965,6871,5965,4557,4557,9956,7509,6871,7509,4557,4557,0,6613,4557,7509,6613,6871,1,4557,4557,7501,4823,6871,2728,6605,6871,7501,4557,4557,2728,8685,8685,13677,461,4557,12516,12781,4557,13677,8685,8685,12516,2743,2743,2,4557,4557,3,4557,4557,4,2743,2743,5,4557,4557,13645,493,8685,8872,12749,8685,13645,4557,4557,8872,8676,8676,9956,936,936,5965,9956,936,9956,8676,8676,5965,936,936,7767,8676,8676,7509,8676,8676,7767,936,936,7509,936,936,2728,4951,6999,7501,2728,6999,2728,936,936,7501,936,936,12516,6999,6999,13677,12516,6999,12516,936,936,13677,936,936,6,8676,8676,7,8676,8676,8,936,936,9,936,936,8872,484,8676,13645,8872,8676,8872,936,936,13645,6997,6997,7509,9956,9956,7767,9956,9956,7509,6997,6997,7767,9956,9956,10468,2728,6997,2728,10468,6997,10468,9956,9956,2728,9956,9956,12516,1869,5965,10,12516,5965,12516,9956,9956,11,11125,11125,12,9956,9956,13,9956,9956,14,11125,11125,15,1700,1700,13645,1764,9956,8872,9892,9956,13645,1700,1700,8872,2728,5703,2728,10468,7509,10468,2728,7509,2728,10468,5703,10468,3413,16,17,7509,7509,18,12516,19,12516,1704,7509,20,1704,19,21,8872,7509,8872,12621,22,13645,8872,23,8872,7509,7509,13645,2728,2728,12516,3405,7501,24,12516,7501,12516,2728,2728,25,2728,2728,26,10468,10468,27,10468,10468,28,2728,2728,29,2728,2728,8872,2276,10468,14677,8872,10468,8872,2728,2728,14677,4776,12516,20,4776,18,30,8872,4260,8872,4324,12516,13645,8872,12516,8872,4260,4260,13645,8872,31,8872,13645,32,13645,8872,33,8872,13645,34,13645]) (by decide +kernel)
  change ∀ b ∈ [s3331,s4028,s4029,s3344,s4030,s4031,s4032,s3562,s4033,s4034,s3873,s4035,s4036,s3738,s3759,s4037,s4038,s4039,s4040,s4041,s941,s4042,s4043,s4044,s4045,s4046,s4047,s3987,s4048,s4049,s4050,s4051,s4052,s4053,s4054], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3331) b3331 <|
    PetersenLocalChildren.push (x := s4028) b4028 <|
    PetersenLocalChildren.push (x := s4029) b4029 <|
    PetersenLocalChildren.push (x := s3344) b3344 <|
    PetersenLocalChildren.push (x := s4030) b4030 <|
    PetersenLocalChildren.push (x := s4031) b4031 <|
    PetersenLocalChildren.push (x := s4032) b4032 <|
    PetersenLocalChildren.push (x := s3562) b3562 <|
    PetersenLocalChildren.push (x := s4033) b4033 <|
    PetersenLocalChildren.push (x := s4034) b4034 <|
    PetersenLocalChildren.push (x := s3873) b3873 <|
    PetersenLocalChildren.push (x := s4035) b4035 <|
    PetersenLocalChildren.push (x := s4036) b4036 <|
    PetersenLocalChildren.push (x := s3738) b3738 <|
    PetersenLocalChildren.push (x := s3759) b3759 <|
    PetersenLocalChildren.push (x := s4037) b4037 <|
    PetersenLocalChildren.push (x := s4038) b4038 <|
    PetersenLocalChildren.push (x := s4039) b4039 <|
    PetersenLocalChildren.push (x := s4040) b4040 <|
    PetersenLocalChildren.push (x := s4041) b4041 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4042) b4042 <|
    PetersenLocalChildren.push (x := s4043) b4043 <|
    PetersenLocalChildren.push (x := s4044) b4044 <|
    PetersenLocalChildren.push (x := s4045) b4045 <|
    PetersenLocalChildren.push (x := s4046) b4046 <|
    PetersenLocalChildren.push (x := s4047) b4047 <|
    PetersenLocalChildren.push (x := s3987) b3987 <|
    PetersenLocalChildren.push (x := s4048) b4048 <|
    PetersenLocalChildren.push (x := s4049) b4049 <|
    PetersenLocalChildren.push (x := s4050) b4050 <|
    PetersenLocalChildren.push (x := s4051) b4051 <|
    PetersenLocalChildren.push (x := s4052) b4052 <|
    PetersenLocalChildren.push (x := s4053) b4053 <|
    PetersenLocalChildren.push (x := s4054) b4054 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
