import higher.WireProjection
import M191StartPreferredCuts6
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv781_4260 : PetersenPackedPin.project r781 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv781_4814 : PetersenPackedPin.project r781 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv781_5473 : PetersenPackedPin.project r781 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv781_6170 : PetersenPackedPin.project r781 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv781_6790 : PetersenPackedPin.project r781 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv781_7474 : PetersenPackedPin.project r781 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv781_8012 : PetersenPackedPin.project r781 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv781_5224 : PetersenPackedPin.project r781 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeeeeeee := PetersenWireProjection.derive 3 pv781_4260 pv781_4814 rfl rfl
theorem pv781_7855 : PetersenPackedPin.project r781 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv781_6170 pv781_7474 rfl rfl
end PetersenSmallStarts.M191.Residual
