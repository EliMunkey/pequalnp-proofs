import higher.WireProjection
import M191StartPreferredCuts6
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv784_4260 : PetersenPackedPin.project r784 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv784_4814 : PetersenPackedPin.project r784 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv784_5473 : PetersenPackedPin.project r784 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv784_6170 : PetersenPackedPin.project r784 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv784_6790 : PetersenPackedPin.project r784 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv784_7474 : PetersenPackedPin.project r784 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv784_8012 : PetersenPackedPin.project r784 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv784_630 : PetersenPackedPin.project r784 (0xffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv784_7474 pv784_8012 rfl rfl
theorem pv784_1343 : PetersenPackedPin.project r784 (0xffffffff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_7474 pv784_8012 rfl rfl
theorem pv784_2362 : PetersenPackedPin.project r784 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0xff0000 := PetersenWireProjection.derive 2 pv784_6170 pv784_6790 rfl rfl
theorem pv784_2418 : PetersenPackedPin.project r784 (0xff00ff0000000000ff00ff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_6170 pv784_7474 rfl rfl
theorem pv784_2461 : PetersenPackedPin.project r784 (0xff00ff00ff00ff0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_6170 pv784_8012 rfl rfl
theorem pv784_2963 : PetersenPackedPin.project r784 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_5473 pv784_7474 rfl rfl
theorem pv784_3004 : PetersenPackedPin.project r784 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_5473 pv784_8012 rfl rfl
theorem pv784_3359 : PetersenPackedPin.project r784 (0x33330000333300003333000033330000 : BitVec 128) = 0x33330000 := PetersenWireProjection.derive 2 pv784_4814 pv784_6790 rfl rfl
theorem pv784_3427 : PetersenPackedPin.project r784 (0x33333333000000003333333300000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_4814 pv784_7474 rfl rfl
theorem pv784_3485 : PetersenPackedPin.project r784 (0x33333333333333330000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_4814 pv784_8012 rfl rfl
theorem pv784_3730 : PetersenPackedPin.project r784 (0x55555555000000005555555500000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_4260 pv784_7474 rfl rfl
theorem pv784_3759 : PetersenPackedPin.project r784 (0x55555555555555550000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv784_4260 pv784_8012 rfl rfl
theorem pv784_5367 : PetersenPackedPin.project r784 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_5473 pv784_7474 rfl rfl
theorem pv784_5425 : PetersenPackedPin.project r784 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_5473 pv784_8012 rfl rfl
theorem pv784_5850 : PetersenPackedPin.project r784 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xfafafafa := PetersenWireProjection.derive 3 pv784_4260 pv784_5473 rfl rfl
theorem pv784_6504 : PetersenPackedPin.project r784 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xffaaffaa := PetersenWireProjection.derive 3 pv784_4260 pv784_6170 rfl rfl
theorem pv784_7095 : PetersenPackedPin.project r784 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv784_4260 pv784_6790 rfl rfl
theorem pv784_7152 : PetersenPackedPin.project r784 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffffcccc := PetersenWireProjection.derive 3 pv784_4814 pv784_6790 rfl rfl
theorem pv784_7235 : PetersenPackedPin.project r784 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xfffff0f0 := PetersenWireProjection.derive 3 pv784_5473 pv784_6790 rfl rfl
theorem pv784_7397 : PetersenPackedPin.project r784 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_7474 pv784_8012 rfl rfl
theorem pv784_7688 : PetersenPackedPin.project r784 (0xffffffffaaaaaaaaffffffffaaaaaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv784_4260 pv784_7474 rfl rfl
theorem pv784_7712 : PetersenPackedPin.project r784 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv784_4814 pv784_7474 rfl rfl
theorem pv784_7774 : PetersenPackedPin.project r784 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv784_5473 pv784_7474 rfl rfl
theorem pv784_7944 : PetersenPackedPin.project r784 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv784_6790 pv784_7474 rfl rfl
theorem pv784_8191 : PetersenPackedPin.project r784 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv784_4260 pv784_8012 rfl rfl
theorem pv784_8208 : PetersenPackedPin.project r784 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xcccccccc := PetersenWireProjection.derive 3 pv784_4814 pv784_8012 rfl rfl
theorem pv784_8245 : PetersenPackedPin.project r784 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := PetersenWireProjection.derive 3 pv784_5473 pv784_8012 rfl rfl
theorem pv784_8295 : PetersenPackedPin.project r784 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv784_6170 pv784_8012 rfl rfl
theorem pv784_8331 : PetersenPackedPin.project r784 (0xffffffffffffffffffff0000ffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv784_6790 pv784_8012 rfl rfl
theorem pv784_8377 : PetersenPackedPin.project r784 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv784_7474 pv784_8012 rfl rfl
theorem pv784_603 : PetersenPackedPin.project r784 (0xffffaaaaffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 1 pv784_7095 pv784_8012 rfl rfl
theorem pv784_1316 : PetersenPackedPin.project r784 (0xffffaaaa00000000ffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 1 pv784_7095 pv784_7474 rfl rfl
theorem pv784_2392 : PetersenPackedPin.project r784 (0xff00aa00ff00aa00ff00aa00ff00aa : BitVec 128) = 0xff00aa := PetersenWireProjection.derive 2 pv784_6170 pv784_7095 rfl rfl
theorem pv784_2938 : PetersenPackedPin.project r784 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a : BitVec 128) = 0xf0f0a0a := PetersenWireProjection.derive 2 pv784_5473 pv784_7095 rfl rfl
theorem pv784_3392 : PetersenPackedPin.project r784 (0x33332222333322223333222233332222 : BitVec 128) = 0x33332222 := PetersenWireProjection.derive 2 pv784_4814 pv784_7095 rfl rfl
theorem pv784_5856 : PetersenPackedPin.project r784 (0xfafffafafafffafafafffafafafffafa : BitVec 128) = 0xfafffafa := PetersenWireProjection.derive 3 pv784_2362 pv784_5850 rfl rfl
theorem pv784_5857 : PetersenPackedPin.project r784 (0xfbfbfafafbfbfafafbfbfafafbfbfafa : BitVec 128) = 0xfbfbfafa := PetersenWireProjection.derive 3 pv784_3359 pv784_5850 rfl rfl
theorem pv784_7025 : PetersenPackedPin.project r784 (0xffffaaaa00000000ffffaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_7095 pv784_7474 rfl rfl
theorem pv784_7067 : PetersenPackedPin.project r784 (0xffffaaaaffffaaaa0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_7095 pv784_8012 rfl rfl
theorem pv784_7206 : PetersenPackedPin.project r784 (0xffffeeeeffffeeeeffffeeeeffffeeee : BitVec 128) = 0xffffeeee := PetersenWireProjection.derive 3 pv784_4260 pv784_7152 rfl rfl
theorem pv784_7285 : PetersenPackedPin.project r784 (0xfffffafafffffafafffffafafffffafa : BitVec 128) = 0xfffffafa := PetersenWireProjection.derive 3 pv784_4260 pv784_7235 rfl rfl
theorem pv784_7439 : PetersenPackedPin.project r784 (0xffffffff00000000aaaaaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_7474 pv784_8191 rfl rfl
theorem pv784_7760 : PetersenPackedPin.project r784 (0xfffffffff0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv784_7774 pv784_8012 rfl rfl
theorem pv784_7971 : PetersenPackedPin.project r784 (0xffffffffffffaaaaffffffffffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv784_4260 pv784_7944 rfl rfl
theorem pv784_8352 : PetersenPackedPin.project r784 (0xffffffffffffffffffffaaaaffffaaaa : BitVec 128) = 0xffffaaaa := PetersenWireProjection.derive 3 pv784_4260 pv784_8331 rfl rfl
theorem pv784_2407 : PetersenPackedPin.project r784 (0xff00fa00ff00fa00ff00fa00ff00fa : BitVec 128) = 0xff00fa := PetersenWireProjection.derive 1 pv784_5856 pv784_6170 rfl rfl
theorem pv784_3408 : PetersenPackedPin.project r784 (0x33333232333332323333323233333232 : BitVec 128) = 0x33333232 := PetersenWireProjection.derive 2 pv784_4814 pv784_5857 rfl rfl
end PetersenSmallStarts.M191.Residual
