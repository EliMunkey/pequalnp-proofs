import Petersen191Symmetry
import M191StagedF0X2Z1G92
import M191StagedF0X2Z1G93
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b13000 : Blocked tgt 9 s13000 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s12950) (by decide +kernel)
  exact b12950
theorem b14080 : Blocked tgt 9 s14080 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s13991) (by decide +kernel)
  exact b13991
theorem b14163 : Blocked tgt 9 s14163 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s13842) (by decide +kernel)
  exact b13842
end PetersenSmallStarts.M191.Staged
