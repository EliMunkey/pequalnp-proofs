import M63StartData
import M63StartPins0
import M63StartL5B2
import M63StartL5B1
import M63StartL5B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b75 : Blocked tgt 6 s75 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s75 6 _ le
  decide +kernel
theorem b76 : Blocked tgt 6 s76 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s76 6 _ le
  decide +kernel
theorem b77 : Blocked tgt 6 s77 := by
  apply PetersenFastNode.node (nxt := #[s78,s79,s80,s45,s81,s71]) (hints := [2768,0,2800,720,2379,720,752,2379,2800,720,1,720,2379,2379,3482,459,2,459,1434,3,3482,459,2379,459,2639,2639,2992,847,2379,847,2123,2379,2992,847,2639,847,2379,2379,3768,843,2639,843,2127,2639,3768,843,2379,843,2379,2379,3760,1355,4,1355,1712,5,3760,1355,2379,1355,395,3418,3482,395,720,459,720,720,3482,459,3418,459,720,720,912,847,3418,847,912,3418,912,720,720,847,1240,1240,1688,208,720,843,1688,720,1688,1240,1240,843,720,720,1680,216,1240,1355,1680,1240,1680,720,720,1355,719,719,847,203,459,912,847,459,847,719,719,912,459,459,843,207,719,1688,843,719,843,459,459,1688,459,459,1355,1680,3482,1680,1355,3482,1355,459,459,1680,1432,1432,1688,843,847,843,839,847,1688,839,1432,843,847,847,1615,1099,1432,1355,1615,1432,1615,847,847,1355,843,843,1355,1103,1688,1615,1355,1688,1355,843,843,1615]) (by decide +kernel)
  change ∀ b ∈ [s78,s79,s80,s45,s81,s71], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s78) b78 <|
    PetersenLocalChildren.push (x := s79) b79 <|
    PetersenLocalChildren.push (x := s80) b80 <|
    PetersenLocalChildren.push (x := s45) b45 <|
    PetersenLocalChildren.push (x := s81) b81 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b82 : Blocked tgt 6 s82 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s82 6 _ le
  decide +kernel
theorem b83 : Blocked tgt 6 s83 := by
  apply PetersenFastNode.node (nxt := #[s16,s84]) (hints := [2764,716,748,716,2375,455,0,455,2375,1,2635,843,2119,843,2375,839,2123,839,2375,1351,1708,1351,391,716,455,716,3414,716,843,908,716,1236,204,1684,1236,716,212,1676,716,455,3478,715,199,843,715,455,203,839,455,455,1676,1351,455,778,843,778,843,1814,839,1814,839,1546,1351,1546,1351,1428,839,835,835,843,1095,1611,843,839,1099,1351,839]) (by decide +kernel)
  change ∀ b ∈ [s16,s84], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s16) b16 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.nil
theorem b85 : Blocked tgt 6 s85 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s85 6 _ le
  decide +kernel
theorem b86 : Blocked tgt 6 s86 := by
  apply PetersenFastNode.node (nxt := #[s21,s87,s71]) (hints := [392,2797,456,2797,1367,2797,844,2989,2797,1237,2285,1685,1237,1709,1237,1709,1773,717,749,2765,717,456,1431,716,200,844,716,456,204,840,456,456,1709,1579,456,456,0,2376,456,2859,844,2859,844,1815,840,1815,840,1579,1709,1579,1709,1,2376,2,2376,1429,840,836,836,844,1429,1709,844,844,2120,2636,844,840,1685,1685,840,840,2124,2376,840,1352,1352]) (by decide +kernel)
  change ∀ b ∈ [s21,s87,s71], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s21) b21 <|
    PetersenLocalChildren.push (x := s87) b87 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b88 : Blocked tgt 6 s88 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s88 6 _ le
  decide +kernel
theorem b90 : Blocked tgt 6 s90 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s90 6 _ le
  decide +kernel
theorem b91 : Blocked tgt 6 s91 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s91 6 _ le
  decide +kernel
theorem b92 : Blocked tgt 6 s92 := by
  apply PetersenFastNode.node (nxt := #[s93,s84,s94]) (hints := [392,2797,456,2797,3447,2797,844,2989,2797,3317,2285,3765,3317,2797,2293,3757,2797,717,749,2765,717,456,3511,716,200,844,716,456,204,840,456,456,3757,1352,456,456,0,2376,456,2859,844,2859,844,3895,840,3895,840,3627,1352,3627,1352,1,2376,2,2376,3509,840,836,836,844,1096,1612,844,844,2120,2636,844,840,1100,1352,840,840,2124,2376,840,1352,1709,2376,1352]) (by decide +kernel)
  change ∀ b ∈ [s93,s84,s94], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s93) b93 <|
    PetersenLocalChildren.push (x := s84) b84 <|
    PetersenLocalChildren.push (x := s94) b94 <|
    PetersenLocalChildren.nil
theorem b95 : Blocked tgt 6 s95 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s95 6 _ le
  decide +kernel
theorem b96 : Blocked tgt 6 s96 := by
  apply PetersenFastNode.node (nxt := #[s50,s97,s98]) (hints := [3447,392,3511,3447,2797,780,3447,2797,2797,3447,3447,2797,3317,2285,3765,3317,2797,2293,3757,2797,717,749,2765,717,844,456,844,972,716,456,456,0,456,3637,840,456,456,2487,1352,456,456,1463,2376,456,844,2989,3765,840,836,836,844,1096,1612,844,844,2120,2636,844,3765,840,3765,840,3757,1352,3757,1352,1,2376,2,2376,840,1100,1352,840,840,2124,2376,840,1352,1709,2376,1352]) (by decide +kernel)
  change ∀ b ∈ [s50,s97,s98], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s97) b97 <|
    PetersenLocalChildren.push (x := s98) b98 <|
    PetersenLocalChildren.nil
theorem b99 : Blocked tgt 6 s99 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s99 6 _ le
  decide +kernel
theorem b100 : Blocked tgt 6 s100 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s100 6 _ le
  decide +kernel
theorem b101 : Blocked tgt 6 s101 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s101 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
