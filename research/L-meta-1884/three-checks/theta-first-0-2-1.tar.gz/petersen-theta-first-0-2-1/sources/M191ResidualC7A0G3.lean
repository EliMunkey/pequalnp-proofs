import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredRows2
import M191StartPreferredRows3
import ResidualFast
import ThetaClosing
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b635 : Blocked tgt 7 s635 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s635 7 _ le
  decide +kernel
theorem b636 : Blocked tgt 7 s636 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s636 7 _ le
  decide +kernel
theorem b637 : Blocked tgt 7 s637 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s637 7 _ le
  decide +kernel
theorem b638 : Blocked tgt 7 s638 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s638 7 _ le
  decide +kernel
theorem b639 : Blocked tgt 7 s639 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s639 7 _ le
  decide +kernel
theorem b640 : Blocked tgt 7 s640 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s640 7 _ le
  decide +kernel

theorem b641 : Blocked tgt 7 s641 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s641 7 _ le
  decide +kernel
theorem b642 : Blocked tgt 7 s642 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s642 7 _ le
  decide +kernel
theorem b643 : Blocked tgt 7 s643 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s643 7 _ le
  decide +kernel
theorem b644 : Blocked tgt 7 s644 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(2,true))] s644 7 _ le
  decide +kernel
theorem b645 : Blocked tgt 7 s645 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(2,true))] s645 7 _ le
  decide +kernel
theorem b646 : Blocked tgt 7 s646 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s646 7 _ le
  decide +kernel
theorem b647 : Blocked tgt 7 s647 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s647 7 _ le
  decide +kernel
theorem b648 : Blocked tgt 7 s648 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s648 7 _ le
  decide +kernel
theorem b649 : Blocked tgt 7 s649 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s649 7 _ le
  decide +kernel
theorem b650 : Blocked tgt 7 s650 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s650 7 _ le
  decide +kernel
theorem b657 : Blocked tgt 7 s657 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s657 7 _ le
  decide +kernel
theorem b658 : Blocked tgt 7 s658 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s658 7 _ le
  decide +kernel
theorem b659 : Blocked tgt 7 s659 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s659 7 _ le
  decide +kernel
theorem b660 : Blocked tgt 7 s660 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s660 7 _ le
  decide +kernel
theorem b661 : Blocked tgt 7 s661 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s661 7 _ le
  decide +kernel
theorem b662 : Blocked tgt 7 s662 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s662 7 _ le
  decide +kernel

theorem b663 : Blocked tgt 7 s663 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s663 7 _ le
  decide +kernel
theorem b664 : Blocked tgt 7 s664 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s664 7 _ le
  decide +kernel
theorem b665 : Blocked tgt 7 s665 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s665 7 _ le
  decide +kernel
theorem b666 : Blocked tgt 7 s666 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s666 7 _ le
  decide +kernel
theorem b667 : Blocked tgt 7 s667 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s667 7 _ le
  decide +kernel
theorem b668 : Blocked tgt 7 s668 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s668 7 _ le
  decide +kernel
theorem b669 : Blocked tgt 7 s669 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s669 7 _ le
  decide +kernel
theorem b670 : Blocked tgt 7 s670 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s670 7 _ le
  decide +kernel
theorem b671 : Blocked tgt 7 s671 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s671 7 _ le
  decide +kernel
theorem b672 : Blocked tgt 7 s672 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s672 7 _ le
  decide +kernel
theorem b673 : Blocked tgt 7 s673 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s673 7 _ le
  decide +kernel
theorem b674 : Blocked tgt 7 s674 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s674 7 _ le
  decide +kernel
theorem b675 : Blocked tgt 7 s675 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s675 7 _ le
  decide +kernel
theorem b676 : Blocked tgt 7 s676 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s676 7 _ le
  decide +kernel
theorem b677 : Blocked tgt 7 s677 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s677 7 _ le
  decide +kernel
theorem b678 : Blocked tgt 7 s678 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s678 7 _ le
  decide +kernel

theorem b679 : Blocked tgt 7 s679 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s679 7 _ le
  decide +kernel
theorem b680 : Blocked tgt 7 s680 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s680 7 _ le
  decide +kernel
theorem b681 : Blocked tgt 7 s681 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s681 7 _ le
  decide +kernel
theorem b684 : Blocked tgt 7 s684 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s684 7 _ le
  decide +kernel
theorem b685 : Blocked tgt 7 s685 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s685 7 _ le
  decide +kernel
theorem b686 : Blocked tgt 7 s686 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s686 7 _ le
  decide +kernel
theorem b687 : Blocked tgt 7 s687 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s687 7 _ le
  decide +kernel
theorem b688 : Blocked tgt 7 s688 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s688 7 _ le
  decide +kernel
theorem b689 : Blocked tgt 7 s689 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s689 7 _ le
  decide +kernel
theorem b690 : Blocked tgt 7 s690 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s690 7 _ le
  decide +kernel
theorem b691 : Blocked tgt 7 s691 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s691 7 _ le
  decide +kernel
theorem b692 : Blocked tgt 7 s692 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s692 7 _ le
  decide +kernel
theorem b693 : Blocked tgt 7 s693 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,32,36,34,38,33,37,35,39,64,68,66,70,65,69,67,71,96,100,98,102,97,101,99,103,8,12,10,14,9,13,11,15,40,44,42,46,41,45,43,47,72,76,74,78,73,77,75,79,104,108,106,110,105,109,107,111,16,20,18,22,17,21,19,23,48,52,50,54,49,53,51,55,80,84,82,86,81,85,83,87,112,116,114,118,113,117,115,119,24,28,26,30,25,29,27,31,56,60,58,62,57,61,59,63,88,92,90,94,89,93,91,95,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0fefef0f0fefef0f0fefef0f0fefe,0xaaaaaaaaaaaaaaaafefefefefefefefe),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffff00000000ffffffff00000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffffffffffff0000000000000000),(0xffffffff00000000ffffffff00000000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffffffffffff0000000000000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1364) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1364
theorem b696 : Blocked tgt 7 s696 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s696 7 _ le
  decide +kernel
theorem b697 : Blocked tgt 7 s697 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s697 7 _ le
  decide +kernel
theorem b698 : Blocked tgt 7 s698 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s698 7 _ le
  decide +kernel

theorem b699 : Blocked tgt 7 s699 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,6836,6964,4258,4514,8641,6964,4514,6964,6836,6836,8641,4514,4514,4898,9793,6836,9921,4898,6836,4898,4514,4514,9921,6578,6578,7474,4514,4514,1669,7474,4514,7474,6578,6578,1669,4514,4514,7458,6578,6578,2693,7458,6578,7458,4514,4514,2693,8642,8642,12610,418,4514,4741,12610,4514,12610,8642,8642,4741,4514,4514,12578,450,8642,8837,12578,8642,12578,4514,4514,8837,8641,8641,9921,4898,6964,4898,9153,6964,9921,8641,8641,4898,1669,6964,1669,8641,8641,7474,901,8641,1669,901,6964,7474,2693,8641,2693,6964,6964,7458,2693,6964,2693,2949,8641,7458,4741,8641,4741,2868,6964,12610,4741,6964,4741,8641,8641,12610,8837,385,8837,449,8641,12578,8837,8641,8837,385,385,12578,8897,6962,7474,8897,9921,1669,9921,9921,7474,1669,6962,1669,9921,9921,11457,2181,6962,2693,11457,6962,11457,9921,9921,2693,9921,9921,12481,4741,4898,4741,12481,4898,12481,9921,9921,4741,1665,1665,12578,1729,9921,8837,9857,9921,12578,1665,1665,8837,1669,1669,2693,10433,7474,11457,2693,7474,2693,1669,1669,11457,1669,1669,4741,12481,7474,12481,4741,7474,4741,1669,1669,12481,1669,1669,8837,3410,11602,12578,8837,11602,8837,1669,1669,12578,2693,2693,4741,3362,7458,14674,4741,7458,4741,2693,2693,14674,2693,2693,8837,3265,11457,14642,8837,11457,8837,2693,2693,14642,4741,4741,8837,4289,12481,12578,8837,12481,8837,4741,4741,12578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b700 : Blocked tgt 7 s700 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s700 7 _ le
  decide +kernel
theorem b701 : Blocked tgt 7 s701 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s701 7 _ le
  decide +kernel
theorem b702 : Blocked tgt 7 s702 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s702 7 _ le
  decide +kernel
theorem b703 : Blocked tgt 7 s703 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s703 7 _ le
  decide +kernel
theorem b704 : Blocked tgt 7 s704 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s704 7 _ le
  decide +kernel
theorem b705 : Blocked tgt 7 s705 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s705 7 _ le
  decide +kernel
theorem b706 : Blocked tgt 7 s706 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s706 7 _ le
  decide +kernel
theorem b707 : Blocked tgt 7 s707 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s707 7 _ le
  decide +kernel
theorem b708 : Blocked tgt 7 s708 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s708 7 _ le
  decide +kernel
theorem b709 : Blocked tgt 7 s709 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s709 7 _ le
  decide +kernel
theorem b710 : Blocked tgt 7 s710 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s710 7 _ le
  decide +kernel
theorem b711 : Blocked tgt 7 s711 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s711 7 _ le
  decide +kernel
theorem b712 : Blocked tgt 7 s712 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s712 7 _ le
  decide +kernel
theorem b713 : Blocked tgt 7 s713 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s713 7 _ le
  decide +kernel
theorem b714 : Blocked tgt 7 s714 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s714 7 _ le
  decide +kernel

theorem b715 : Blocked tgt 7 s715 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s715 7 _ le
  decide +kernel
theorem b723 : Blocked tgt 7 s723 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s723 7 _ le
  decide +kernel
theorem b725 : Blocked tgt 7 s725 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s725 7 _ le
  decide +kernel
theorem b749 : Blocked tgt 7 s749 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s749 7 _ le
  decide +kernel
theorem b750 : Blocked tgt 7 s750 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s750 7 _ le
  decide +kernel
theorem b752 : Blocked tgt 7 s752 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s752 7 _ le
  decide +kernel
theorem b755 : Blocked tgt 7 s755 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s755 7 _ le
  decide +kernel
theorem b790 : Blocked tgt 7 s790 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s790 7 _ le
  decide +kernel
theorem b824 : Blocked tgt 7 s824 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s824 7 _ le
  decide +kernel
theorem b826 : Blocked tgt 7 s826 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s826 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
