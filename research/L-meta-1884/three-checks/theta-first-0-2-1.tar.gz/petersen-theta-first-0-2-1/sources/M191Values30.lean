import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv30_4260 : PetersenPackedPin.project r30 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv30_4814 : PetersenPackedPin.project r30 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv30_5473 : PetersenPackedPin.project r30 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv30_6170 : PetersenPackedPin.project r30 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv30_6790 : PetersenPackedPin.project r30 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv30_7474 : PetersenPackedPin.project r30 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv30_8012 : PetersenPackedPin.project r30 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv30_1294 : PetersenPackedPin.project r30 (0xffff000000000000ffff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv30_6790 pv30_7474 rfl rfl
theorem pv30_2708 : PetersenPackedPin.project r30 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 1 pv30_4260 pv30_5473 rfl rfl
theorem pv30_3359 : PetersenPackedPin.project r30 (0x33330000333300003333000033330000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv30_4814 pv30_6790 rfl rfl
theorem pv30_3632 : PetersenPackedPin.project r30 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv30_4260 pv30_5473 rfl rfl
theorem pv30_3980 : PetersenPackedPin.project r30 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv30_4260 pv30_5473 rfl rfl
theorem pv30_5850 : PetersenPackedPin.project r30 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv30_4260 pv30_5473 rfl rfl
theorem pv30_7235 : PetersenPackedPin.project r30 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv30_5473 pv30_6790 rfl rfl
theorem pv30_7314 : PetersenPackedPin.project r30 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv30_6170 pv30_6790 rfl rfl
theorem pv30_3718 : PetersenPackedPin.project r30 (0x55555050555550505555505055555050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv30_4260 pv30_7235 rfl rfl
theorem pv30_3822 : PetersenPackedPin.project r30 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 2 pv30_3980 pv30_5850 rfl rfl
end PetersenSmallStarts.M191.Residual
