import M191StartPreferredCommon
import M31StartLabeled
import M15StartLabeled
import M63StartLabeled
import M111StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r767 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small767 : NoAtMost (0xf000f00 :: i5) (PetersenPackedPin.project r767 tgt) 6 := by
  have a : PetersenPackedPin.project r767 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf000f00 (by decide +kernel)
theorem hot767 : forcedConst r767 tgt = false := by decide +kernel
def r768 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small768 : NoAtMost (0x33003300 :: i5) (PetersenPackedPin.project r768 tgt) 6 := by
  have a : PetersenPackedPin.project r768 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x33003300 (by decide +kernel)
theorem hot768 : forcedConst r768 tgt = false := by decide +kernel
def r769 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small769 : NoAtMost (0xf0f00000 :: i5) (PetersenPackedPin.project r769 tgt) 6 := by
  have a : PetersenPackedPin.project r769 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf0f00000 (by decide +kernel)
theorem hot769 : forcedConst r769 tgt = false := by decide +kernel
def r770 (x : Fin 16) : Fin 128 := (#[0,2,1,3,16,18,17,19,8,10,9,11,24,26,25,27] : Array (Fin 128))[x.val]?.getD 0
theorem small770 : NoAtMost (0x3300 :: i4) (PetersenPackedPin.project r770 tgt) 3 := by
  have a : PetersenPackedPin.project r770 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hot770 : forcedConst r770 tgt = false := by decide +kernel
def r771 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small771 : NoAtMost (0xf0f0 :: i5) (PetersenPackedPin.project r771 tgt) 6 := by
  have a : PetersenPackedPin.project r771 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf0f0 (by decide +kernel)
theorem hot771 : forcedConst r771 tgt = false := by decide +kernel
def r772 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small772 : NoAtMost (0xf0f0000 :: i5) (PetersenPackedPin.project r772 tgt) 6 := by
  have a : PetersenPackedPin.project r772 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf0f0000 (by decide +kernel)
theorem hot772 : forcedConst r772 tgt = false := by decide +kernel
def r773 (x : Fin 64) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119] : Array (Fin 128))[x.val]?.getD 0
theorem small773 : NoAtMost (0xf000f000f000f000 :: i6) (PetersenPackedPin.project r773 tgt) 7 := by
  have a : PetersenPackedPin.project r773 tgt = PetersenSmallStarts.M63.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M63.all_forbidden 0xf000f000f000f000 (by decide +kernel)
theorem hot773 : forcedConst r773 tgt = false := by decide +kernel
def r774 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small774 : NoAtMost (0xffffff00 :: i5) (PetersenPackedPin.project r774 tgt) 6 := by
  have a : PetersenPackedPin.project r774 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xffffff00 (by decide +kernel)
theorem hot774 : forcedConst r774 tgt = false := by decide +kernel
def r775 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small775 : NoAtMost (0xff0000 :: i5) (PetersenPackedPin.project r775 tgt) 6 := by
  have a : PetersenPackedPin.project r775 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xff0000 (by decide +kernel)
theorem hot775 : forcedConst r775 tgt = false := by decide +kernel
def r776 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small776 : NoAtMost (0xff00 :: i5) (PetersenPackedPin.project r776 tgt) 6 := by
  have a : PetersenPackedPin.project r776 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xff00 (by decide +kernel)
theorem hot776 : forcedConst r776 tgt = false := by decide +kernel
def r777 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small777 : NoAtMost (0x3300330033003300 :: i6) (PetersenPackedPin.project r777 tgt) 6 := by
  have a : PetersenPackedPin.project r777 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x3300330033003300 (by decide +kernel)
theorem hot777 : forcedConst r777 tgt = false := by decide +kernel
def r778 (x : Fin 64) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108,16,24,20,28,80,88,84,92,48,56,52,60,112,120,116,124,2,10,6,14,66,74,70,78,34,42,38,46,98,106,102,110,18,26,22,30,82,90,86,94,50,58,54,62,114,122,118,126] : Array (Fin 128))[x.val]?.getD 0
theorem small778 : NoAtMost (0x3300330033003300 :: i6) (PetersenPackedPin.project r778 tgt) 6 := by
  have a : PetersenPackedPin.project r778 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x3300330033003300 (by decide +kernel)
theorem hot778 : forcedConst r778 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
