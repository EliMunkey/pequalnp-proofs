import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv761_4260 : PetersenPackedPin.project r761 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv761_4814 : PetersenPackedPin.project r761 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv761_5473 : PetersenPackedPin.project r761 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv761_6170 : PetersenPackedPin.project r761 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv761_6790 : PetersenPackedPin.project r761 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv761_7474 : PetersenPackedPin.project r761 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv761_8012 : PetersenPackedPin.project r761 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv761_1734 : PetersenPackedPin.project r761 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv761_4260 pv761_6790 rfl rfl
theorem pv761_2192 : PetersenPackedPin.project r761 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv761_4260 pv761_6170 rfl rfl
theorem pv761_3759 : PetersenPackedPin.project r761 (0x55555555555555550000000000000000 : BitVec 128) = 0x55005500 := PetersenWireProjection.derive 2 pv761_4260 pv761_8012 rfl rfl
theorem pv761_6504 : PetersenPackedPin.project r761 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv761_4260 pv761_6170 rfl rfl
theorem pv761_7095 : PetersenPackedPin.project r761 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv761_4260 pv761_6790 rfl rfl
theorem pv761_8295 : PetersenPackedPin.project r761 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv761_6170 pv761_8012 rfl rfl
theorem pv761_3771 : PetersenPackedPin.project r761 (0x55555555555555555500550055005500 : BitVec 128) = 0x55005500 := PetersenWireProjection.derive 2 pv761_4260 pv761_8295 rfl rfl
theorem pv761_6975 : PetersenPackedPin.project r761 (0xffff5555ffff55550000000000000000 : BitVec 128) = 0x55005500 := PetersenWireProjection.derive 2 pv761_1734 pv761_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
