import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values13
import M191Values14
import M191Values19
import M191Values2
import M191Values32
import M191Values734
import M191Values735
import M191Values740
import M191Values744
import M191Values748
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows12
import M191StartPreferredRows13
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b2705 : Blocked tgt 7 s2705 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2705 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6952 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2706 : Blocked tgt 7 s2706 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2706 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xff00ff00ff00ff00,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4366 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2707 : Blocked tgt 7 s2707 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2707 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7650 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2708 : Blocked tgt 7 s2708 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2708 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xffff0000ffff0000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4375 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2709 : Blocked tgt 7 s2709 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s2709 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc] (PetersenWireProjection.cons pv744_2708 (PetersenWireProjection.cons pv744_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r744 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv744_6170 (PetersenWireProjection.cons pv744_6790 (PetersenWireProjection.cons pv744_7474 (PetersenWireProjection.cons pv744_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r744 (0xffffffffffffffff5050505050505050 : BitVec 128) = 0xfcfcfcfcfcfcfcfc) rfl)))))))) (by decide +kernel)
theorem b2710 : Blocked tgt 7 s2710 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s2710 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_283 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2711 : Blocked tgt 7 s2711 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9801,6964,9673,6964,9673,5288,5288,7732,9921,7732,8897,9929,11465,2181,9929,9929,13513,4229,9929,14900,9865,14900,1673,9673,6964,9673,6836,5672,5672,6836,7732,1541,6836,11465,6820,11465,4772,13513,6804,13513,2708,6836,14900,8709,6836,9673,6056,8641,8649,9665,8641,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,6832,7732,7216,7732,5800,11465,7208,11465,9928,13513,13384,13513,5800,14900,13352,14900,10433,10441,10433,11457,12481,12489,12481,13505,7732,3152,14900,7732,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2712 : Blocked tgt 7 s2712 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2712 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xcccccccccccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2717 : Blocked tgt 7 s2717 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2717 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2718 : Blocked tgt 7 s2718 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2718 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2719 : Blocked tgt 7 s2719 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2719 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2720 : Blocked tgt 7 s2720 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2720 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)

theorem b2721 : Blocked tgt 7 s2721 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2721 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2722 : Blocked tgt 7 s2722 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2722 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2723 : Blocked tgt 7 s2723 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2723 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2724 : Blocked tgt 7 s2724 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2724 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b2725 : Blocked tgt 7 s2725 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2725 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b2726 : Blocked tgt 7 s2726 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9673,389,9673,5288,5288,8897,9793,8905,8897,9801,6324,9801,11465,2181,9801,9801,13513,4229,9801,1545,9737,1609,1545,9673,5928,8641,8649,9665,8641,6836,9673,9673,6964,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,4776,4776,5672,1541,10832,5672,5672,6832,5672,11465,7208,11465,9800,13513,13384,13513,5672,1608,13352,5672,6836,7732,10433,10441,10433,11457,12481,12489,12481,13505,1541,13352,8837,1541,4772,11465,6820,11465,2708,13513,6804,13513,6836,8709,14900,6836,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2727 : Blocked tgt 7 s2727 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2727 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6504 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2730 : Blocked tgt 7 s2730 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2730 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3304 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2731 : Blocked tgt 7 s2731 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2731 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2732 : Blocked tgt 7 s2732 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2732 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfa00fa00fa00fa00fa00fa00fa00fa00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2733 : Blocked tgt 7 s2733 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s2733 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444444444444444,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xfa00fa00fa00fa00fa00fa00fa00fa : BitVec 128) = 0x4444444444444444) (PetersenWireProjection.cons pv748_2708 (PetersenWireProjection.cons pv748_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv748_6504 (PetersenWireProjection.cons pv748_6790 (PetersenWireProjection.cons pv748_7474 (PetersenWireProjection.cons pv748_8012 rfl)))))))) (by decide +kernel)
theorem b2734 : Blocked tgt 7 s2734 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2734 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfaaafaaafaaafaaafaaafaaafaaafaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2735 : Blocked tgt 7 s2735 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2735 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2736 : Blocked tgt 7 s2736 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2736 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7314 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2737 : Blocked tgt 7 s2737 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2737 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1887 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)

theorem b2738 : Blocked tgt 7 s2738 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2738 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5850 (PetersenWireProjection.cons pv19_6504 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b2739 : Blocked tgt 7 s2739 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2739 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1252 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2743 : Blocked tgt 7 s2743 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2743 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_531 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2744 : Blocked tgt 7 s2744 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2744 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6457 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2745 : Blocked tgt 7 s2745 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2745 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1912 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2746 : Blocked tgt 7 s2746 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9673,6964,9673,5546,5546,11602,9793,11602,8769,7466,11465,7466,9801,13642,13513,13642,9801,13610,9737,13610,1545,9801,6324,5672,9673,9673,5928,8641,8649,9665,8641,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,6836,9673,9673,6964,6962,5034,11602,6962,5930,11465,7466,11465,10058,13513,13642,13513,5930,1866,13610,5930,6962,5930,5930,6962,10433,10441,10433,11457,12481,12489,12481,13505,3410,3410,11602,13610,7474,7474,11465,3370,13513,11465,3209,3273,11401,3209,4772,11465,11465,6820,5257,5321,13449,5257,2708,13513,13513,6804,13610,14642]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2747 : Blocked tgt 7 s2747 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2747 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_561 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2763 : Blocked tgt 7 s2763 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2763 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b2764 : Blocked tgt 7 s2764 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2764 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b2771 : Blocked tgt 7 s2771 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [9801,9673,6964,9673,5672,10448,7732,9793,7732,8769,9801,11465,2181,9801,9801,13513,4229,9801,1673,9737,1737,1673,9801,1545,9673,5928,8641,8649,9665,8641,9673,4916,11465,9673,9673,2868,13513,9673,1417,1481,9609,1417,6836,9673,9673,6964,7216,7220,7216,7728,5672,11465,7208,11465,9800,13513,13384,13513,5672,1736,9800,5672,5672,9800,5800,5672,10433,10441,10433,11457,12481,12489,12481,13505,7732,11344,8709,7732,6836,1541,6836,7732,11465,3112,13513,11465,3209,3273,11401,3209,4772,11465,11465,6820,5257,5321,13449,5257,2708,13513,13513,6804,6836,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b2797 : Blocked tgt 7 s2797 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2797 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2798 : Blocked tgt 7 s2798 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2798 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2799 : Blocked tgt 7 s2799 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2799 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xcacacacacacacacacacacacacacacaca : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2800 : Blocked tgt 7 s2800 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2800 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2801 : Blocked tgt 7 s2801 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false)),(false,(3,false),(0,false))] s2801 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8) (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2802 : Blocked tgt 7 s2802 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2802 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2803 : Blocked tgt 7 s2803 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2803 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xf0f0f0f0f0f0f0f0,0xcccccccccccccccc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2804 : Blocked tgt 7 s2804 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2804 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2805 : Blocked tgt 7 s2805 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2805 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2806 : Blocked tgt 7 s2806 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2806 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b2807 : Blocked tgt 7 s2807 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2807 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b2808 : Blocked tgt 7 s2808 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2808 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaea : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2809 : Blocked tgt 7 s2809 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2809 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b2810 : Blocked tgt 7 s2810 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2810 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0x8888888888888888,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2811 : Blocked tgt 7 s2811 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2811 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2812 : Blocked tgt 7 s2812 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,false),(1,false))] s2812 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x8888888888888888,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4514 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2813 : Blocked tgt 7 s2813 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2813 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x32323232323232323232323232323232 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2814 : Blocked tgt 7 s2814 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2814 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffc8ffc8ffc8ffc8ffc8ffc8ffc8ffc8 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2815 : Blocked tgt 7 s2815 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2815 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x37003700370037003700370037003700 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2816 : Blocked tgt 7 s2816 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2816 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffffc8c8ffffc8c8ffffc8c8ffffc8c8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2817 : Blocked tgt 7 s2817 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2817 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x37370000373700003737000037370000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2818 : Blocked tgt 7 s2818 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2818 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffffffffc8c8c8c8ffffffffc8c8c8c8 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2819 : Blocked tgt 7 s2819 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2819 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xf0f0,0x0,0x0,0xaaaa,0xcccc,0x0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x37373737000000003737373700000000 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b2820 : Blocked tgt 7 s2820 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2820 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffffffffffffffffc8c8c8c8c8c8c8c8 : BitVec 128) = 0xff00) rfl)))))))) (by decide +kernel)
theorem b2821 : Blocked tgt 7 s2821 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s2821 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xff00,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x37373737373737370000000000000000 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 rfl)))))))) (by decide +kernel)
theorem b2829 : Blocked tgt 7 s2829 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(1,false),(3,false))] s2829 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffccffccffccffccffccffccffccffcc,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xffccffccffccffccffccffccffccffcc) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b2830 : Blocked tgt 7 s2830 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s2830 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2831 : Blocked tgt 7 s2831 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2831 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2059 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2875 : Blocked tgt 7 s2875 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(3,false),(6,false))] s2875 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000,0xffffffffffffffffff00ff00ff00ff00] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xffffffffffffffffff00ff00ff00ff00) rfl)))))))) (by decide +kernel)
theorem b2876 : Blocked tgt 7 s2876 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2876 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2705 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2881 : Blocked tgt 7 s2881 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2881 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_130 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2903 : Blocked tgt 7 s2903 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2903 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2904 : Blocked tgt 7 s2904 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2904 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2905 : Blocked tgt 7 s2905 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2905 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2906 : Blocked tgt 7 s2906 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2906 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2907 : Blocked tgt 7 s2907 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s2907 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2908 : Blocked tgt 7 s2908 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2908 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2909 : Blocked tgt 7 s2909 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2909 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0xaaaa,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5850 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b2910 : Blocked tgt 7 s2910 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2910 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2914 : Blocked tgt 7 s2914 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2914 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2915 : Blocked tgt 7 s2915 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s2915 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5850 (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b2916 : Blocked tgt 7 s2916 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2916 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3209 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2917 : Blocked tgt 7 s2917 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false))] s2917 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4514 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))) (by decide +kernel)
theorem b2920 : Blocked tgt 7 s2920 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s2920 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4514 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b2921 : Blocked tgt 7 s2921 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s2921 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2584 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b2922 : Blocked tgt 7 s2922 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2922 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl))))))) (by decide +kernel)
theorem b2923 : Blocked tgt 7 s2923 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2923 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xcccccccccccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2924 : Blocked tgt 7 s2924 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s2924 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6308 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b2925 : Blocked tgt 7 s2925 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s2925 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b2926 : Blocked tgt 7 s2926 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2926 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5241 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2927 : Blocked tgt 7 s2927 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2927 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2884 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5850 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2928 : Blocked tgt 7 s2928 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2928 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2929 : Blocked tgt 7 s2929 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2929 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5850 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2930 : Blocked tgt 7 s2930 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2930 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5850 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)

theorem b2931 : Blocked tgt 7 s2931 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s2931 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1177 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5850 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b2932 : Blocked tgt 7 s2932 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s2932 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfa0afa0afa0afa0afa0afa0afa0afa0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b2933 : Blocked tgt 7 s2933 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s2933 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6659 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b2934 : Blocked tgt 7 s2934 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s2934 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b2935 : Blocked tgt 7 s2935 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s2935 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2589 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b2936 : Blocked tgt 7 s2936 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s2936 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5794 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b2937 : Blocked tgt 7 s2937 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2937 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7285 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2938 : Blocked tgt 7 s2938 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s2938 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1863 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b2939 : Blocked tgt 7 s2939 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s2939 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2592 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
