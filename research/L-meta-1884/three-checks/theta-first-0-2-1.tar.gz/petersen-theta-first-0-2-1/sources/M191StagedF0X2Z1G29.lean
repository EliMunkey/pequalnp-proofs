import higher.WireProjection
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values19
import M191Values21
import M191Values22
import M191Values32
import M191Values35
import M191Values5
import M191Values739
import M191Values740
import M191Values741
import M191Values748
import M191Values787
import M191Values788
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredCuts6
import M191StartPreferredCuts7
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b10126 : Blocked tgt 7 s10126 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10126 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xe4e4e4e4e4e4e4e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b10134 : Blocked tgt 7 s10134 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s10134 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_561 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8104 rfl)))))))) (by decide +kernel)
theorem b10135 : Blocked tgt 7 s10135 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s10135 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5a0f5a0f5a0f5a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b10239 : Blocked tgt 7 s10239 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s10239 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b10485 : Blocked tgt 7 s10485 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10485 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa080a080a080a08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b10557 : Blocked tgt 7 s10557 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(3,false))] s10557 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6504 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)

theorem b10584 : Blocked tgt 7 s10584 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(0,false),(3,false))] s10584 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0xffaaffaa] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8317 rfl)))))))) (by decide +kernel)
theorem b10633 : Blocked tgt 7 s10633 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s10633 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0x3300,0x0,0xaaaa,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0x55445544554455445544554455445544 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_4260 (PetersenWireProjection.cons pv787_4814 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons pv787_5745 (PetersenWireProjection.cons pv787_6170 (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl)))))))) (by decide +kernel)
theorem b10634 : Blocked tgt 7 s10634 := by
  intro k le c
  apply rejects_sound r785 (0xfcfcfcfc :: i5) 6 tgt small785 hot785 [(true,(2,false),(4,false))] s10634 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xfcfcfcfc,0xff00ff00,0xffccffcc,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xfcfcfcfc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xffccffcc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r785 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b10645 : Blocked tgt 7 s10645 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(3,false))] s10645 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xff00ff00,0xffccffcc,0xffff0000,0x0,0xcccccccc] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6546 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7712 rfl)))))))) (by decide +kernel)
theorem b10647 : Blocked tgt 7 s10647 := by
  intro k le c
  apply rejects_sound r788 (0xfff0fff0 :: i5) 6 tgt small788 hot788 [(true,(2,false),(4,false))] s10647 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xffccffcc,0xfff0fff0,0xffff0000,0x0] (PetersenWireProjection.cons pv788_4260 (PetersenWireProjection.cons pv788_4814 (PetersenWireProjection.cons pv788_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r788 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r788 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xffccffcc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r788 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xfff0fff0) (PetersenWireProjection.cons pv788_6790 (PetersenWireProjection.cons pv788_7474 rfl)))))))) (by decide +kernel)
theorem b10650 : Blocked tgt 7 s10650 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s10650 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x0,0x3300,0x0,0x0,0xaaaa,0xf0f0] (PetersenWireProjection.cons pv787_4260 (PetersenWireProjection.cons pv787_4814 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons pv787_5745 (PetersenWireProjection.cons pv787_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xfffcfffcfffcfffcfffcfffcfffcfffc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl)))))))) (by decide +kernel)
theorem b10652 : Blocked tgt 7 s10652 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s10652 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0x3300,0x0,0xaaaa,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xf0c0f0c0f0c0f0c0f0c0f0c0f0c0f0c : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_4260 (PetersenWireProjection.cons pv787_4814 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons pv787_5745 (PetersenWireProjection.cons pv787_6170 (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl)))))))) (by decide +kernel)
theorem b10683 : Blocked tgt 7 s10683 := by
  intro k le c
  apply rejects_sound r786 (0x30303030 :: i5) 6 tgt small786 hot786 [(true,(2,false),(5,false))] s10683 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x30303030,0xaaaaaaaa,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffffcccc,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0x30303030303030303030303030303030 : BitVec 128) = 0x30303030) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffffcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r786 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)

theorem b10740 : Blocked tgt 7 s10740 := by
  intro k le c
  apply rejects_sound r789 (0x3300 :: i4) 3 tgt small789 hot789 [] s10740 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xaaaa,0x0,0x3300,0x0,0x0,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0x33333030333330303333303033333030 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x3300) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r789 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0) rfl)))))))) (by decide +kernel)
theorem b10838 : Blocked tgt 7 s10838 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10838 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5154 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b10843 : Blocked tgt 7 s10843 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10843 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xff00,0xcccc,0x0,0x0,0xf0f0] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5745 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 rfl)))))))) (by decide +kernel)
theorem b10851 : Blocked tgt 7 s10851 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [773,5290,773,5288,10058,1545,5546,1482,11602,4522,11602,6578,5546,6320,11594,4530,11594,5546,13642,1450,13642,1418,1417,9802,9800,1417,1417,13354,8837,1417,385,393,1409,385,1417,6964,1417,11338,3209,1417,1417,13386,5257,1417,5930,1866,13610,5930,11090,9034,11602,11090,10832,10058,10058,10832,3209,9042,3209,10058,5257,1834,5257,10058,7474,3410,7474,14642,6836,13610,13610,14900,3209,3402,3209,13610,5257,13610,5257,13578,11602,7732,2177,2185,2177,3201,4225,4233,4225,5249,4772,3209,6820,3209,2708,5257,6804,5257,3209,12626,5257,3209]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b10852 : Blocked tgt 7 s10852 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10852 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xff00,0xcccc,0x0,0xf0f0] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5745 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 rfl)))))))) (by decide +kernel)
theorem b10872 : Blocked tgt 7 s10872 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10872 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b10879 : Blocked tgt 7 s10879 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s10879 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xff00,0x0,0x0,0xf0f0] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5745 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 rfl)))))))) (by decide +kernel)
theorem b10881 : Blocked tgt 7 s10881 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s10881 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444444444444444,0x0,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00] (PetersenWireProjection.cons pv748_2298 (PetersenWireProjection.cons pv748_2708 (PetersenWireProjection.cons pv748_4814 (PetersenWireProjection.cons pv748_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv748_6504 (PetersenWireProjection.cons pv748_6790 (PetersenWireProjection.cons pv748_7474 rfl)))))))) (by decide +kernel)
theorem b10886 : Blocked tgt 7 s10886 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s10886 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0,0xffaaffaa] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffffffffffffffffffaaffaaffaaffaa : BitVec 128) = 0xffaaffaa) rfl)))))))) (by decide +kernel)
theorem b10892 : Blocked tgt 7 s10892 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s10892 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0xffff,0xffff] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_5745 (PetersenWireProjection.cons pv19_6504 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 rfl)))))))) (by decide +kernel)

theorem b10895 : Blocked tgt 7 s10895 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s10895 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xff00,0x0,0x0,0xf0f0] (PetersenWireProjection.cons pv13_1912 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5745 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 rfl)))))))) (by decide +kernel)
theorem b10925 : Blocked tgt 7 s10925 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s10925 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x0,0x0,0x3300,0x0,0xaaaa,0xf0f0] (PetersenWireProjection.cons pv787_4260 (PetersenWireProjection.cons pv787_4814 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_5745 (PetersenWireProjection.cons pv787_6170 (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl)))))))) (by decide +kernel)
theorem b10926 : Blocked tgt 7 s10926 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s10926 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b10989 : Blocked tgt 7 s10989 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10989 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5029 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b10990 : Blocked tgt 7 s10990 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10990 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5154 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b10991 : Blocked tgt 7 s10991 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10991 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b10992 : Blocked tgt 7 s10992 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s10992 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b10993 : Blocked tgt 7 s10993 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10993 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)

theorem b10994 : Blocked tgt 7 s10994 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10994 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b10995 : Blocked tgt 7 s10995 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s10995 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xe4e4e4e4e4e4e4e4e4e4e4e4e4e4e4e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b10996 : Blocked tgt 7 s10996 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s10996 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b10997 : Blocked tgt 7 s10997 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s10997 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xffe4ffe4ffe4ffe4ffe4ffe4ffe4ffe4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b10998 : Blocked tgt 7 s10998 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s10998 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xffffffffffffffffe4e4e4e4e4e4e4e4 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b11025 : Blocked tgt 7 s11025 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11025 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_5154 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11026 : Blocked tgt 7 s11026 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [] s11026 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xeeeeeeeeeeeeeeee,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons pv741_5473 (PetersenWireProjection.cons pv741_5850 (PetersenWireProjection.cons pv741_6170 (PetersenWireProjection.cons pv741_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r741 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv741_7474 (PetersenWireProjection.cons pv741_8012 rfl)))))))) (by decide +kernel)
theorem b11027 : Blocked tgt 7 s11027 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11027 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11028 : Blocked tgt 7 s11028 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11028 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5f50000f5f50000f5f50000f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11029 : Blocked tgt 7 s11029 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11029 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xa0a08080a0a08080a0a08080a0a0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11030 : Blocked tgt 7 s11030 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11030 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5720 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11031 : Blocked tgt 7 s11031 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(1,false),(3,false))] s11031 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffccffccffccffcc,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_5149 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffccffccffccffcc) (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11032 : Blocked tgt 7 s11032 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(1,false),(3,false))] s11032 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffccffccffccffcc,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3063 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffccffccffccffcc) (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11033 : Blocked tgt 7 s11033 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s11033 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b11034 : Blocked tgt 7 s11034 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11034 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11035 : Blocked tgt 7 s11035 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11035 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xeeee0000eeee0000eeee0000eeee0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)

theorem b11036 : Blocked tgt 7 s11036 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11036 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1815 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11037 : Blocked tgt 7 s11037 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11037 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_5201 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11038 : Blocked tgt 7 s11038 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11038 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1546 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_5224 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11039 : Blocked tgt 7 s11039 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,9801,7732,4522,7732,6322,5546,4530,7338,5546,773,5290,773,9672,4741,1450,4741,9674,8709,1482,8709,5546,6836,5288,6834,7220,7474,6834,5930,4914,7466,5930,9673,5802,9673,5672,13513,1834,13513,10058,5930,1866,13610,5930,5672,5930,5930,5672,5668,7732,7732,5668,8641,8649,8641,9665,12481,12489,12481,13505,7732,3408,8709,7732,6836,1541,6836,7732,9673,11465,13513,3370,13513,11338,8709,3402,8709,7466,4916,4916,4772,6836,9673,13386,13513,9673,1417,1481,9609,1417,4772,9673,9673,6836,5257,5321,13449,5257,2708,13513,13513,6804,6836,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b11040 : Blocked tgt 7 s11040 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11040 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_438 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11041 : Blocked tgt 7 s11041 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s11041 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5224 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b11042 : Blocked tgt 7 s11042 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11042 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11043 : Blocked tgt 7 s11043 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11043 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5978 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11044 : Blocked tgt 7 s11044 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s11044 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5224 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b11045 : Blocked tgt 7 s11045 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s11045 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1779 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_5224 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b11046 : Blocked tgt 7 s11046 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s11046 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1779 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_5224 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b11047 : Blocked tgt 7 s11047 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s11047 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5224 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7975 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b11048 : Blocked tgt 7 s11048 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11048 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1321 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11063 : Blocked tgt 7 s11063 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5288,9801,1541,4264,1541,6322,6836,6320,2693,11337,2693,5288,9674,1448,13386,9674,773,5288,773,9672,8837,1482,8837,5288,6834,4776,7218,6834,10832,5672,5672,6832,11465,4786,11465,5672,10058,1832,13386,10058,9673,5672,9673,9800,5672,1866,13352,5672,6836,7732,10433,10441,10433,11457,1541,3378,14674,1541,8641,8649,8641,9665,1541,3410,8837,1541,4772,11465,6820,11465,2868,2868,6836,2708,2708,9673,6836,9673,6836,8709,14900,6836,11465,3368,13386,11465,9673,7208,9673,11465,3209,3273,11401,3209,9673,13513,8837,14900,8837,14900,1417,1481,9609,1417]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b11064 : Blocked tgt 7 s11064 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s11064 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xee00ee00ee00ee00ee00ee00ee00ee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b11089 : Blocked tgt 7 s11089 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11089 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xe4e4e4e4e4e4e4e4e4e4e4e4e4e4e4e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xfefefefefefefefefefefefefefefefe : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11090 : Blocked tgt 7 s11090 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s11090 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5224 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf4f4f4f4f4f4f4f4f4f4f4f4f4f4f4f4 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b11091 : Blocked tgt 7 s11091 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11091 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5149 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xfefefefefefefefefefefefefefefefe : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11097 : Blocked tgt 7 s11097 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11097 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5e4f5e4f5e4f5e4f5e4f5e4f5e4f5e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11098 : Blocked tgt 7 s11098 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11098 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5e4f5e4f5e4f5e4f5e4f5e4f5e4f5e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11099 : Blocked tgt 7 s11099 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s11099 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b11100 : Blocked tgt 7 s11100 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s11100 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b11101 : Blocked tgt 7 s11101 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s11101 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b11102 : Blocked tgt 7 s11102 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s11102 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xfafafafafafafafa) (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b11103 : Blocked tgt 7 s11103 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11103 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0e0f0e0f0e0f0e0f0e0f0e0f0e0f0e0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11104 : Blocked tgt 7 s11104 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11104 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x100010001000100010001000100010 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11105 : Blocked tgt 7 s11105 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11105 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)

theorem b11106 : Blocked tgt 7 s11106 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11106 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11107 : Blocked tgt 7 s11107 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11107 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffee0000ffee0000ffee0000ffee0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_6597 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11108 : Blocked tgt 7 s11108 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11108 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffee0000ffee0000ffee0000ffee : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6597 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11109 : Blocked tgt 7 s11109 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11109 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffffffffffffffffffeeffeeffeeffee : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b11110 : Blocked tgt 7 s11110 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11110 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffeeffeeffeeffee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b11112 : Blocked tgt 7 s11112 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11112 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5e4f5e4f5e4f5e4f5e4f5e4f5e4f5e4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11113 : Blocked tgt 7 s11113 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s11113 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffeeffeeffeeffeeffeeffeeffeeffee : BitVec 128) = 0xfafafafafafafafa) (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11114 : Blocked tgt 7 s11114 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s11114 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b11115 : Blocked tgt 7 s11115 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11115 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffee0000ffee0000ffee0000ffee0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11116 : Blocked tgt 7 s11116 := by
  intro k le c
  apply rejects_sound r792 (0xf0 :: i4) 3 tgt small792 hot792 [] s11116 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0,0x0,0x0,0x0,0xcccc,0xf0f0,0x0,0xaaaa] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xffee0000ffee0000ffee0000ffee : BitVec 128) = 0xf0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r792 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xaaaa) rfl)))))))) (by decide +kernel)
theorem b11118 : Blocked tgt 7 s11118 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11118 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xaee0aee0aee0aee0aee0aee0aee0aee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11119 : Blocked tgt 7 s11119 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11119 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_4974 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11120 : Blocked tgt 7 s11120 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11120 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2059 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11121 : Blocked tgt 7 s11121 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11121 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xe000e000e000e000e000e000e000e0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11122 : Blocked tgt 7 s11122 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11122 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf010f010f010f010f010f010f010f010 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11123 : Blocked tgt 7 s11123 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11123 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff00ee00ee00ee00ee : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)

theorem b11124 : Blocked tgt 7 s11124 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11124 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xee00ee00ee00ee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11125 : Blocked tgt 7 s11125 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11125 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xee00ee00ee00ee00ee00ee00ee00ee : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5850 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11126 : Blocked tgt 7 s11126 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11126 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5682 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11127 : Blocked tgt 7 s11127 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11127 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6546 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11128 : Blocked tgt 7 s11128 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11128 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x33003300330033003300330033003300 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11129 : Blocked tgt 7 s11129 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11129 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11130 : Blocked tgt 7 s11130 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11130 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11179 : Blocked tgt 7 s11179 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s11179 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xeee0eee0eee0eee0eee0eee0eee0eee0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b11180 : Blocked tgt 7 s11180 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11180 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x11101110111011101110111011101110 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
