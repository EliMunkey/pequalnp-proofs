import M63StartData
import M63StartPins0
import M63StartL5B10
import M63StartL5B11
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b339 : Blocked tgt 6 s339 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s339 6 _ le
  decide +kernel
theorem b340 : Blocked tgt 6 s340 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s340 6 _ le
  decide +kernel
theorem b341 : Blocked tgt 6 s341 := by
  apply PetersenFastNode.node (nxt := #[s342,s343,s344,s345,s346,s347,s348,s349,s350,s351,s352,s353,s354,s355]) (hints := [3458,3458,3522,403,3328,467,3522,3328,3522,3458,3458,467,3000,3328,3000,3202,3458,0,3000,3458,3000,3064,3328,1,3328,3328,3776,2296,2,851,3776,3,3776,3328,3328,851,3768,2288,3768,2304,3328,1363,3768,3328,3768,2288,2288,1363,1248,1248,4,1280,3328,2387,3296,3328,5,1248,1248,2387,207,207,2870,211,467,3000,463,467,2870,207,207,3000,467,467,851,3648,6,3776,851,7,851,467,467,3776,467,467,1363,2498,3522,3768,1363,3522,1363,467,467,3768,467,467,2387,1474,3522,8,2387,3522,2387,467,467,9,3520,3520,3776,851,3000,851,847,3000,3776,847,3520,851,1103,3000,1103,1107,3520,1363,1103,3520,1103,1359,3000,1363,2127,920,2127,2131,3000,2387,2127,3000,2127,2383,920,2387,851,851,1363,3768,3776,3768,1363,3776,1363,851,851,3768,851,851,2387,1728,3776,10,2387,3776,2387,851,851,11,1363,1363,2387,1720,3768,12,2387,3768,2387,1363,1363,13]) (by decide +kernel)
  change ∀ b ∈ [s342,s343,s344,s345,s346,s347,s348,s349,s350,s351,s352,s353,s354,s355], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s342) b342 <|
    PetersenLocalChildren.push (x := s343) b343 <|
    PetersenLocalChildren.push (x := s344) b344 <|
    PetersenLocalChildren.push (x := s345) b345 <|
    PetersenLocalChildren.push (x := s346) b346 <|
    PetersenLocalChildren.push (x := s347) b347 <|
    PetersenLocalChildren.push (x := s348) b348 <|
    PetersenLocalChildren.push (x := s349) b349 <|
    PetersenLocalChildren.push (x := s350) b350 <|
    PetersenLocalChildren.push (x := s351) b351 <|
    PetersenLocalChildren.push (x := s352) b352 <|
    PetersenLocalChildren.push (x := s353) b353 <|
    PetersenLocalChildren.push (x := s354) b354 <|
    PetersenLocalChildren.push (x := s355) b355 <|
    PetersenLocalChildren.nil
theorem b356 : Blocked tgt 6 s356 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s356 6 _ le
  decide +kernel
theorem b357 : Blocked tgt 6 s357 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s357 6 _ le
  decide +kernel
theorem b358 : Blocked tgt 6 s358 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s358 6 _ le
  decide +kernel
theorem b359 : Blocked tgt 6 s359 := by
  apply PetersenFastNode.node (nxt := #[s360]) (hints := [3445,390,3509,3445,2987,3189,2987,3051,3315,774,3763,3315,2291,2291,3315,2405,2405,3315,2795,2795,1235,1267,3283,1235,714,454,454,714,454,202,838,454,454,3509,1610,454,454,714,714,454,454,1461,2374,454,3507,838,3763,838,1610,3507,1610,1866,842,842,3507,2987,2634,2374,2634,2374,838,1098,1090,838,838,3763,3763,838,838,2122,2374,838,1350,1350,2374,0,2374,1610,2374,2634,2374,2634]) (by decide +kernel)
  change ∀ b ∈ [s360], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s360) b360 <|
    PetersenLocalChildren.nil
theorem b361 : Blocked tgt 6 s361 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s361 6 _ le
  decide +kernel
theorem b362 : Blocked tgt 6 s362 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s362 6 _ le
  decide +kernel
theorem b363 : Blocked tgt 6 s363 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s363 6 _ le
  decide +kernel
theorem b364 : Blocked tgt 6 s364 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s364 6 _ le
  decide +kernel
theorem b365 : Blocked tgt 6 s365 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true))] s365 6 _ le
  decide +kernel
theorem b366 : Blocked tgt 6 s366 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s366 6 _ le
  decide +kernel
theorem b367 : Blocked tgt 6 s367 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s367 6 _ le
  decide +kernel
theorem b368 : Blocked tgt 6 s368 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s368 6 _ le
  decide +kernel
theorem b369 : Blocked tgt 6 s369 := by
  apply PetersenFastNode.node (nxt := #[s344]) (hints := [454,2667,454,2665,2795,778,2283,2283,2795,0,2795,3315,2795,1546,3755,2795,715,747,2763,715,714,2859,2857,714,194,202,706,194,3445,714,714,3509,714,2485,1610,714,714,1461,2634,714,2539,2539,2987,3507,3507,2987,2987,3507,1610,2483,1610,2987,2634,939,2634,907,3763,3763,1090,1098,1090,1602,2114,2122,2114,2626,2405,1610,3429,1610,1365,2634,3413,2634,1610,1707,2634,1610]) (by decide +kernel)
  change ∀ b ∈ [s344], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s344) b344 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
