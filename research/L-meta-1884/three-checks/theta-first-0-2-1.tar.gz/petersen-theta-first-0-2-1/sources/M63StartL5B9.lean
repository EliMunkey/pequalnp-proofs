import M63StartData
import M63StartPins0
import M63StartL4B0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b294 : Blocked tgt 5 s294 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s294 5 _ le
  decide +kernel
theorem b295 : Blocked tgt 5 s295 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s295 5 _ le
  decide +kernel
theorem b296 : Blocked tgt 5 s296 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s296 5 _ le
  decide +kernel
theorem b297 : Blocked tgt 5 s297 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s297 5 _ le
  decide +kernel
theorem b298 : Blocked tgt 5 s298 := by
  apply PetersenFastNode.node (nxt := #[s299]) (hints := [745,778,1001,745,3445,233,1779,3445,3445,390,1525,1525,2405,2421,3429,2405,1365,1397,3413,1365,3507,842,842,3507,0,842,842,3505,842,1094,1610,842,714,2118,714,842,838,838,1350,1610,1350,1610,2374,202,2374,714,1350,1610,1350,1610,2374,714,454,454,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s299], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s299) b299 <|
    PetersenLocalChildren.nil
theorem b300 : Blocked tgt 5 s300 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s300 5 _ le
  decide +kernel
theorem b301 : Blocked tgt 5 s301 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s301 5 _ le
  decide +kernel
theorem b313 : Blocked tgt 5 s313 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s313 5 _ le
  decide +kernel
theorem b323 : Blocked tgt 5 s323 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s323 5 _ le
  decide +kernel
theorem b326 : Blocked tgt 5 s326 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s326 5 _ le
  decide +kernel
theorem b327 : Blocked tgt 5 s327 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s327 5 _ le
  decide +kernel
theorem b328 : Blocked tgt 5 s328 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s328 5 _ le
  decide +kernel
theorem b332 : Blocked tgt 5 s332 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s332 5 _ le
  decide +kernel
theorem b333 : Blocked tgt 5 s333 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s333 5 _ le
  decide +kernel
theorem b334 : Blocked tgt 5 s334 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s334 5 _ le
  decide +kernel
theorem b335 : Blocked tgt 5 s335 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s335 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
