import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows21
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4806 : Blocked tgt 7 s4806 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4806 7 _ le
  decide +kernel
theorem b4807 : Blocked tgt 7 s4807 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4807 7 _ le
  decide +kernel
theorem b4808 : Blocked tgt 7 s4808 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4808 7 _ le
  decide +kernel
theorem b4809 : Blocked tgt 7 s4809 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4809 7 _ le
  decide +kernel
theorem b4810 : Blocked tgt 7 s4810 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4810 7 _ le
  decide +kernel
theorem b4811 : Blocked tgt 7 s4811 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4811 7 _ le
  decide +kernel
theorem b4812 : Blocked tgt 7 s4812 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4812 7 _ le
  decide +kernel
theorem b4813 : Blocked tgt 7 s4813 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4813 7 _ le
  decide +kernel
theorem b4814 : Blocked tgt 7 s4814 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4814 7 _ le
  decide +kernel
theorem b4815 : Blocked tgt 7 s4815 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4815 7 _ le
  decide +kernel
theorem b4816 : Blocked tgt 7 s4816 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4816 7 _ le
  decide +kernel
theorem b4817 : Blocked tgt 7 s4817 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4817 7 _ le
  decide +kernel
theorem b4818 : Blocked tgt 7 s4818 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4818 7 _ le
  decide +kernel

theorem b4819 : Blocked tgt 7 s4819 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s4819 7 _ le
  decide +kernel
theorem b4820 : Blocked tgt 7 s4820 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4820 7 _ le
  decide +kernel
theorem b4821 : Blocked tgt 7 s4821 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4821 7 _ le
  decide +kernel
theorem b4830 : Blocked tgt 7 s4830 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4830 7 _ le
  decide +kernel
theorem b4831 : Blocked tgt 7 s4831 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4831 7 _ le
  decide +kernel
theorem b4832 : Blocked tgt 7 s4832 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4832 7 _ le
  decide +kernel
theorem b4833 : Blocked tgt 7 s4833 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4833 7 _ le
  decide +kernel
theorem b4834 : Blocked tgt 7 s4834 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4834 7 _ le
  decide +kernel
theorem b4835 : Blocked tgt 7 s4835 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4835 7 _ le
  decide +kernel
theorem b4836 : Blocked tgt 7 s4836 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4836 7 _ le
  decide +kernel
theorem b4837 : Blocked tgt 7 s4837 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4837 7 _ le
  decide +kernel
theorem b4838 : Blocked tgt 7 s4838 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4838 7 _ le
  decide +kernel
theorem b4839 : Blocked tgt 7 s4839 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4839 7 _ le
  decide +kernel
theorem b4840 : Blocked tgt 7 s4840 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4840 7 _ le
  decide +kernel
theorem b4841 : Blocked tgt 7 s4841 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4841 7 _ le
  decide +kernel
theorem b4842 : Blocked tgt 7 s4842 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4842 7 _ le
  decide +kernel

theorem b4843 : Blocked tgt 7 s4843 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4843 7 _ le
  decide +kernel
theorem b4844 : Blocked tgt 7 s4844 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4844 7 _ le
  decide +kernel
theorem b4845 : Blocked tgt 7 s4845 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4845 7 _ le
  decide +kernel
theorem b4846 : Blocked tgt 7 s4846 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4846 7 _ le
  decide +kernel
theorem b4847 : Blocked tgt 7 s4847 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4847 7 _ le
  decide +kernel
theorem b4848 : Blocked tgt 7 s4848 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4848 7 _ le
  decide +kernel
theorem b4849 : Blocked tgt 7 s4849 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4849 7 _ le
  decide +kernel
theorem b4850 : Blocked tgt 7 s4850 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4850 7 _ le
  decide +kernel
theorem b4851 : Blocked tgt 7 s4851 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4851 7 _ le
  decide +kernel
theorem b4852 : Blocked tgt 7 s4852 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4852 7 _ le
  decide +kernel
theorem b4853 : Blocked tgt 7 s4853 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4853 7 _ le
  decide +kernel
theorem b4854 : Blocked tgt 7 s4854 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4854 7 _ le
  decide +kernel
theorem b4855 : Blocked tgt 7 s4855 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s4855 7 _ le
  decide +kernel
theorem b4856 : Blocked tgt 7 s4856 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4856 7 _ le
  decide +kernel
theorem b4857 : Blocked tgt 7 s4857 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s4857 7 _ le
  decide +kernel
theorem b4858 : Blocked tgt 7 s4858 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4858 7 _ le
  decide +kernel

theorem b4859 : Blocked tgt 7 s4859 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,385,456,6836,5930,9729,5930,6058,7474,458,7474,2514,6836,458,458,6836,7466,4788,7466,458,458,2740,4554,458,13610,458,4522,4522,385,5674,9857,385,7218,385,7474,901,901,2693,7210,2693,385,4741,13386,4741,385,8837,385,8837,13608,6962,9857,9857,6962,10832,9857,9857,10832,2177,2693,2177,9857,4225,4741,4225,9857,1665,1665,9857,8837,1669,1669,2693,2177,2693,2177,4741,4225,4741,4225,8837,3410,8837,7474,2693,2177,2693,2177,4741,4225,4741,4225,8837,13610,8837,13610,2693,3370,4741,2693,2693,2177,8837,2693,4741,4225,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4860 : Blocked tgt 7 s4860 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4860 7 _ le
  decide +kernel
theorem b4861 : Blocked tgt 7 s4861 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4861 7 _ le
  decide +kernel
theorem b4862 : Blocked tgt 7 s4862 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4862 7 _ le
  decide +kernel
theorem b4863 : Blocked tgt 7 s4863 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4863 7 _ le
  decide +kernel
theorem b4864 : Blocked tgt 7 s4864 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4864 7 _ le
  decide +kernel
theorem b4865 : Blocked tgt 7 s4865 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4865 7 _ le
  decide +kernel
theorem b4866 : Blocked tgt 7 s4866 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4866 7 _ le
  decide +kernel
theorem b4867 : Blocked tgt 7 s4867 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4867 7 _ le
  decide +kernel
theorem b4868 : Blocked tgt 7 s4868 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4868 7 _ le
  decide +kernel
theorem b4869 : Blocked tgt 7 s4869 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4869 7 _ le
  decide +kernel
theorem b4870 : Blocked tgt 7 s4870 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4870 7 _ le
  decide +kernel
theorem b4871 : Blocked tgt 7 s4871 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,385,456,6836,5930,9729,5930,6058,7474,458,7474,2514,7466,4788,7466,458,458,2740,4554,458,13610,458,4522,4522,6836,458,458,6836,385,5930,9857,385,1669,385,1669,7474,2693,7466,2693,385,4741,13386,4741,385,13354,385,13610,901,901,8833,8833,9857,1669,2177,2693,2177,9857,4225,4741,4225,9857,5930,9857,9857,5930,5672,9857,9857,5672,1669,2177,2693,1669,1669,4225,4741,1669,1669,3410,14642,1669,1669,7474,7474,1669,2693,3370,4741,2693,2693,2177,2177,2693,2693,2177,2177,2693,4741,4225,4225,4741,4741,4225,4225,4741,8837,8837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4872 : Blocked tgt 7 s4872 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4872 7 _ le
  decide +kernel
theorem b4873 : Blocked tgt 7 s4873 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s4873 7 _ le
  decide +kernel
theorem b4874 : Blocked tgt 7 s4874 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4874 7 _ le
  decide +kernel

theorem b4875 : Blocked tgt 7 s4875 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s4875 7 _ le
  decide +kernel
theorem b4876 : Blocked tgt 7 s4876 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s4876 7 _ le
  decide +kernel
theorem b4877 : Blocked tgt 7 s4877 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4877 7 _ le
  decide +kernel
theorem b4878 : Blocked tgt 7 s4878 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4878 7 _ le
  decide +kernel
theorem b4879 : Blocked tgt 7 s4879 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4879 7 _ le
  decide +kernel
theorem b4880 : Blocked tgt 7 s4880 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4880 7 _ le
  decide +kernel
theorem b4881 : Blocked tgt 7 s4881 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4881 7 _ le
  decide +kernel
theorem b4882 : Blocked tgt 7 s4882 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4882 7 _ le
  decide +kernel
theorem b4883 : Blocked tgt 7 s4883 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4883 7 _ le
  decide +kernel
theorem b4884 : Blocked tgt 7 s4884 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4884 7 _ le
  decide +kernel
theorem b4885 : Blocked tgt 7 s4885 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4885 7 _ le
  decide +kernel
theorem b4886 : Blocked tgt 7 s4886 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s4886 7 _ le
  decide +kernel
theorem b4887 : Blocked tgt 7 s4887 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s4887 7 _ le
  decide +kernel
theorem b4888 : Blocked tgt 7 s4888 := by
  intro k le c
  apply rejects_sound r749 (0xc0c0c0c0c0c0c0c :: i6) 6 tgt small749 hot749 [] s4888 7 _ le
  decide +kernel
theorem b4889 : Blocked tgt 7 s4889 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s4889 7 _ le
  decide +kernel
theorem b4890 : Blocked tgt 7 s4890 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4890 7 _ le
  decide +kernel

theorem b4891 : Blocked tgt 7 s4891 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4891 7 _ le
  decide +kernel
theorem b4892 : Blocked tgt 7 s4892 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4892 7 _ le
  decide +kernel
theorem b4893 : Blocked tgt 7 s4893 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4893 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
