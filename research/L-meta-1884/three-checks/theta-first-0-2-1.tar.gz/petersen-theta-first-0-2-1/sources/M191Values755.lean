import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv755_4260 : PetersenPackedPin.project r755 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv755_4814 : PetersenPackedPin.project r755 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv755_5473 : PetersenPackedPin.project r755 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv755_6170 : PetersenPackedPin.project r755 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv755_6790 : PetersenPackedPin.project r755 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv755_7474 : PetersenPackedPin.project r755 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv755_8012 : PetersenPackedPin.project r755 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv755_3209 : PetersenPackedPin.project r755 (0x30303030303030303030303030303030 : BitVec 128) = 0x4444 := PetersenWireProjection.derive 2 pv755_4814 pv755_5473 rfl rfl
theorem pv755_3359 : PetersenPackedPin.project r755 (0x33330000333300003333000033330000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv755_4814 pv755_6790 rfl rfl
theorem pv755_5850 : PetersenPackedPin.project r755 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv755_4260 pv755_5473 rfl rfl
theorem pv755_7095 : PetersenPackedPin.project r755 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv755_4260 pv755_6790 rfl rfl
theorem pv755_3276 : PetersenPackedPin.project r755 (0x32323232323232323232323232323232 : BitVec 128) = 0x4444 := PetersenWireProjection.derive 2 pv755_4814 pv755_5850 rfl rfl
theorem pv755_3392 : PetersenPackedPin.project r755 (0x33332222333322223333222233332222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv755_4814 pv755_7095 rfl rfl
theorem pv755_5857 : PetersenPackedPin.project r755 (0xfbfbfafafbfbfafafbfbfafafbfbfafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv755_3359 pv755_5850 rfl rfl
theorem pv755_3408 : PetersenPackedPin.project r755 (0x33333232333332323333323233333232 : BitVec 128) = 0x4444 := PetersenWireProjection.derive 2 pv755_4814 pv755_5857 rfl rfl
end PetersenSmallStarts.M191.Residual
