import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv748_4260 : PetersenPackedPin.project r748 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv748_4814 : PetersenPackedPin.project r748 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv748_5473 : PetersenPackedPin.project r748 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv748_6170 : PetersenPackedPin.project r748 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv748_6790 : PetersenPackedPin.project r748 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv748_7474 : PetersenPackedPin.project r748 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv748_8012 : PetersenPackedPin.project r748 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv748_1734 : PetersenPackedPin.project r748 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv748_4260 pv748_6790 rfl rfl
theorem pv748_2298 : PetersenPackedPin.project r748 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x4444444444444444 := PetersenWireProjection.derive 1 pv748_5473 pv748_6170 rfl rfl
theorem pv748_2708 : PetersenPackedPin.project r748 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv748_4260 pv748_5473 rfl rfl
theorem pv748_6504 : PetersenPackedPin.project r748 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv748_4260 pv748_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
