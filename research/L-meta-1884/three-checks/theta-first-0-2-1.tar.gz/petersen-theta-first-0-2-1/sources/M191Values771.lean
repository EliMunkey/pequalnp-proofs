import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv771_4260 : PetersenPackedPin.project r771 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv771_4814 : PetersenPackedPin.project r771 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv771_5473 : PetersenPackedPin.project r771 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv771_6170 : PetersenPackedPin.project r771 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv771_6790 : PetersenPackedPin.project r771 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv771_7474 : PetersenPackedPin.project r771 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv771_8012 : PetersenPackedPin.project r771 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv771_1177 : PetersenPackedPin.project r771 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 1 pv771_5473 pv771_7474 rfl rfl
theorem pv771_1734 : PetersenPackedPin.project r771 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv771_4260 pv771_6790 rfl rfl
theorem pv771_7095 : PetersenPackedPin.project r771 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv771_4260 pv771_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
