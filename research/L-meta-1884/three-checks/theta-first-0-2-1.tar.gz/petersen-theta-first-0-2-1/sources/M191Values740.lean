import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv740_4260 : PetersenPackedPin.project r740 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv740_4814 : PetersenPackedPin.project r740 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv740_5473 : PetersenPackedPin.project r740 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv740_6170 : PetersenPackedPin.project r740 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv740_6790 : PetersenPackedPin.project r740 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv740_7474 : PetersenPackedPin.project r740 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv740_8012 : PetersenPackedPin.project r740 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv740_391 : PetersenPackedPin.project r740 (0xcccccccccccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv740_4814 pv740_8012 rfl rfl
theorem pv740_1117 : PetersenPackedPin.project r740 (0xcccccccc00000000cccccccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv740_4814 pv740_7474 rfl rfl
theorem pv740_1779 : PetersenPackedPin.project r740 (0xcccc0000cccc0000cccc0000cccc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv740_4814 pv740_6790 rfl rfl
theorem pv740_2240 : PetersenPackedPin.project r740 (0xcc00cc00cc00cc00cc00cc00cc00cc : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv740_4814 pv740_6170 rfl rfl
theorem pv740_2708 : PetersenPackedPin.project r740 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 1 pv740_4260 pv740_5473 rfl rfl
theorem pv740_2800 : PetersenPackedPin.project r740 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv740_4814 pv740_5473 rfl rfl
theorem pv740_3157 : PetersenPackedPin.project r740 (0x22222222222222222222222222222222 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv740_4260 pv740_4814 rfl rfl
theorem pv740_3209 : PetersenPackedPin.project r740 (0x30303030303030303030303030303030 : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 2 pv740_4814 pv740_5473 rfl rfl
theorem pv740_3582 : PetersenPackedPin.project r740 (0x44444444444444444444444444444444 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv740_4260 pv740_4814 rfl rfl
theorem pv740_4429 : PetersenPackedPin.project r740 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv740_4814 pv740_5473 rfl rfl
theorem pv740_4675 : PetersenPackedPin.project r740 (0xcccccccc00000000cccccccc00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv740_4814 pv740_7474 rfl rfl
theorem pv740_4753 : PetersenPackedPin.project r740 (0xcccccccccccccccc0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv740_4814 pv740_8012 rfl rfl
theorem pv740_5224 : PetersenPackedPin.project r740 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv740_4260 pv740_4814 rfl rfl
theorem pv740_5850 : PetersenPackedPin.project r740 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv740_4260 pv740_5473 rfl rfl
theorem pv740_5920 : PetersenPackedPin.project r740 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv740_4814 pv740_5473 rfl rfl
theorem pv740_6504 : PetersenPackedPin.project r740 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xfafafafafafafafa := PetersenWireProjection.derive 3 pv740_4260 pv740_6170 rfl rfl
theorem pv740_6546 : PetersenPackedPin.project r740 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv740_4814 pv740_6170 rfl rfl
theorem pv740_8208 : PetersenPackedPin.project r740 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv740_4814 pv740_8012 rfl rfl
theorem pv740_2517 : PetersenPackedPin.project r740 (0x2020202020202020202020202020202 : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 1 pv740_2708 pv740_4814 rfl rfl
theorem pv740_4503 : PetersenPackedPin.project r740 (0xc4c4c4c4c4c4c4c4c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv740_2708 pv740_4814 rfl rfl
theorem pv740_4514 : PetersenPackedPin.project r740 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv740_4814 pv740_5850 rfl rfl
theorem pv740_5029 : PetersenPackedPin.project r740 (0xcececececececececececececececece : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 3 pv740_2708 pv740_4814 rfl rfl
theorem pv740_5682 : PetersenPackedPin.project r740 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xd0d0d0d0d0d0d0d0 := PetersenWireProjection.derive 2 pv740_2708 pv740_6170 rfl rfl
theorem pv740_6308 : PetersenPackedPin.project r740 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xf2f2f2f2f2f2f2f2 := PetersenWireProjection.derive 3 pv740_2708 pv740_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
