import M191StartPreferredSignals
import M191ResidualC8A0G1
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G57
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G65
import M191StagedF0X2Z1G66
import M191StagedF0X2Z1G67
import M191StagedF0X2Z1G68
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows14
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows19
import M191StartPreferredRows20
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows37
import M191StartPreferredRows4
import M191StartPreferredRows40
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows67
import M191StartPreferredRows7
import M191StartPreferredRows9
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair14387i0 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word7) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s927,s14388,s14389,s14437,s14438]) (hints := [0,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s927,s14388,s14389,s14437,s14438], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14388) (b14388) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14389) (b14389) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14437) (b14437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14438) (b14438) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i1 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s231,s5413,s14439,s14440,s11705,s12145,s14441,s5409]) (hints := [0,1,2,6844,3,6844,4,5,6,6844,7,6844]) (by decide +kernel) ?_
  change ∀ x ∈ [s231,s5413,s14439,s14440,s11705,s12145,s14441,s5409], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s231) (b231) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5413) (b5413) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14439) (b14439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14440) (b14440) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11705) (b11705) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12145) (b12145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14441) (b14441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5409) (b5409) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i2 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14442,s14443,s13795,s14452]) (hints := [9677,0,9677,905,1,905,9677,2,9677,905,3,905]) (by decide +kernel) ?_
  change ∀ x ∈ [s14442,s14443,s13795,s14452], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14442) (b14442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14443) (b14443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13795) (b13795) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14452) (b14452) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i3 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s5441,s14453]) (hints := [5933,0,5933,6965,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s5441,s14453], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5441) (b5441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14453) (b14453) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i4 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s14454,s14345]) (hints := [1672,0,7477,1672,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s14454,s14345], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14454) (b14454) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14345) (b14345) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i5 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14455,s14456,s14457,s14458]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s14455,s14456,s14457,s14458], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14455) (b14455) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14456) (b14456) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14457) (b14457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14458) (b14458) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i6 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14459,s14460,s14461,s14462]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s14459,s14460,s14461,s14462], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14459) (b14459) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14460) (b14460) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14461) (b14461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14462) (b14462) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i7 : PetersenLocalChildren.PairOK tgt 8 s14387 (word41,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14463,s14464,s14471,s14472]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s14463,s14464,s14471,s14472], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14463) (b14463) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14464) (b14464) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14471) (b14471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14472) (b14472) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i8 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14388,s98,s294]) (hints := [6839,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14388,s98,s294], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14388) (b14388) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s98) (b98) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s294) (b294) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i9 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14473,s859,s1663,s14474]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s14473,s859,s1663,s14474], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14473) (b14473) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s859) (b859) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1663) (b1663) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14474) (b14474) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i10 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14388,s2090,s3192]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14388,s2090,s3192], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14388) (b14388) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2090) (b2090) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3192) (b3192) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i11 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14475,s3745,s4433,s5215,s5793,s6012,s14476,s6513]) (hints := [7482,0,7482,1,2,3,7482,4,7482,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14475,s3745,s4433,s5215,s5793,s6012,s14476,s6513], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14475) (b14475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3745) (b3745) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4433) (b4433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5215) (b5215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5793) (b5793) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6012) (b6012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14476) (b14476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6513) (b6513) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i12 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14477,s6732,s7528,s14478]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s14477,s6732,s7528,s14478], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14477) (b14477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6732) (b6732) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7528) (b7528) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14478) (b14478) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i13 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14479,s7748,s8424,s14480]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14479,s7748,s8424,s14480], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14479) (b14479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7748) (b7748) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8424) (b8424) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14480) (b14480) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i14 : PetersenLocalChildren.PairOK tgt 8 s14387 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14481,s8974,s9620,s10060,s10503,s10724,s14482,s10944]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14481,s8974,s9620,s10060,s10503,s10724,s14482,s10944], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14481) (b14481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8974) (b8974) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9620) (b9620) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10060) (b10060) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10503) (b10503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10724) (b10724) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14482) (b14482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10944) (b10944) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i15 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11181,s11482]) (hints := [6838,6838,6966,775,0,903,6966,1,6966,6838,6838,903]) (by decide +kernel) ?_
  change ∀ x ∈ [s11181,s11482], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11181) (b11181) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11482) (b11482) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i16 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s294,s3192,s11763,s12280]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s294,s3192,s11763,s12280], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s294) (b294) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3192) (b3192) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11763) (b11763) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12280) (b12280) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i17 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12438,s12471,s12757,s12909,s14483]) (hints := [6841,6841,7479,0,1,2,7479,3,7479,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s12438,s12471,s12757,s12909,s14483], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12438) (b12438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12471) (b12471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12757) (b12757) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12909) (b12909) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14483) (b14483) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i18 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4772,4772,7466,4788,6836,2693,6820,6836,7466,4772,4772,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i19 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [2708,2708,13642,2740,6836,4741,6804,6836,13642,2708,2708,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i20 : PetersenLocalChildren.PairOK tgt 8 s14387 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13194,s13611]) (hints := [6838,6838,14902,8711,0,8839,14902,1,14902,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13194,s13611], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13194) (b13194) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13611) (b13611) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i21 : PetersenLocalChildren.PairOK tgt 8 s14387 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i22 : PetersenLocalChildren.PairOK tgt 8 s14387 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,7216,8649,9673,7474,9665,9673,7216,901,901,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i23 : PetersenLocalChildren.PairOK tgt 8 s14387 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,2693,4916,6964,7466,2693,6964,2693,901,901,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i24 : PetersenLocalChildren.PairOK tgt 8 s14387 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,4741,2868,6964,13642,4741,6964,4741,901,901,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i25 : PetersenLocalChildren.PairOK tgt 8 s14387 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,8837,1481,9673,13610,8837,9673,8837,901,901,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i26 : PetersenLocalChildren.PairOK tgt 8 s14387 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14453,s14345,s14484,s14485]) (hints := [7478,0,7478,5934,5934,1,7990,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14453,s14345,s14484,s14485], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14453) (b14453) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14345) (b14345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14484) (b14484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14485) (b14485) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i27 : PetersenLocalChildren.PairOK tgt 8 s14387 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14486,s14487]) (hints := [11467,5932,11467,2695,0,2695,11467,1,11467,2695,5932,2695]) (by decide +kernel) ?_
  change ∀ x ∈ [s14486,s14487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14486) (b14486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14487) (b14487) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i28 : PetersenLocalChildren.PairOK tgt 8 s14387 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i29 : PetersenLocalChildren.PairOK tgt 8 s14387 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i30 : PetersenLocalChildren.PairOK tgt 8 s14387 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14488,s14489]) (hints := [2695,0,2695,10443,7476,11467,2695,7476,2695,11459,1,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s14488,s14489], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14488) (b14488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14489) (b14489) <|
    PetersenLocalChildren.nil
private theorem thetaPair14387i31 : PetersenLocalChildren.PairOK tgt 8 s14387 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4741,11602,4741,12489,7474,13513,4741,7474,4741,13505,11602,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i32 : PetersenLocalChildren.PairOK tgt 8 s14387 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8837,7474,8837,3410,11602,13610,8837,11602,8837,7474,7474,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i33 : PetersenLocalChildren.PairOK tgt 8 s14387 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [2693,2693,4741,3370,7466,14674,4741,7466,4741,2693,2693,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i34 : PetersenLocalChildren.PairOK tgt 8 s14387 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [2693,2693,8837,12852,11465,14900,8837,11465,8837,2693,2693,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14387i35 : PetersenLocalChildren.PairOK tgt 8 s14387 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4741,4741,8837,10804,13513,14900,8837,13513,8837,4741,4741,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b14387 : Blocked tgt 9 s14387 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word41,word7),(word41,word3),(word41,word1),(word41,word0),(word41,word6),(word41,word5),(word41,word2),(word41,word4),(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s14387 p
  exact
    PetersenLocalChildren.push thetaPair14387i0 <|
    PetersenLocalChildren.push thetaPair14387i1 <|
    PetersenLocalChildren.push thetaPair14387i2 <|
    PetersenLocalChildren.push thetaPair14387i3 <|
    PetersenLocalChildren.push thetaPair14387i4 <|
    PetersenLocalChildren.push thetaPair14387i5 <|
    PetersenLocalChildren.push thetaPair14387i6 <|
    PetersenLocalChildren.push thetaPair14387i7 <|
    PetersenLocalChildren.push thetaPair14387i8 <|
    PetersenLocalChildren.push thetaPair14387i9 <|
    PetersenLocalChildren.push thetaPair14387i10 <|
    PetersenLocalChildren.push thetaPair14387i11 <|
    PetersenLocalChildren.push thetaPair14387i12 <|
    PetersenLocalChildren.push thetaPair14387i13 <|
    PetersenLocalChildren.push thetaPair14387i14 <|
    PetersenLocalChildren.push thetaPair14387i15 <|
    PetersenLocalChildren.push thetaPair14387i16 <|
    PetersenLocalChildren.push thetaPair14387i17 <|
    PetersenLocalChildren.push thetaPair14387i18 <|
    PetersenLocalChildren.push thetaPair14387i19 <|
    PetersenLocalChildren.push thetaPair14387i20 <|
    PetersenLocalChildren.push thetaPair14387i21 <|
    PetersenLocalChildren.push thetaPair14387i22 <|
    PetersenLocalChildren.push thetaPair14387i23 <|
    PetersenLocalChildren.push thetaPair14387i24 <|
    PetersenLocalChildren.push thetaPair14387i25 <|
    PetersenLocalChildren.push thetaPair14387i26 <|
    PetersenLocalChildren.push thetaPair14387i27 <|
    PetersenLocalChildren.push thetaPair14387i28 <|
    PetersenLocalChildren.push thetaPair14387i29 <|
    PetersenLocalChildren.push thetaPair14387i30 <|
    PetersenLocalChildren.push thetaPair14387i31 <|
    PetersenLocalChildren.push thetaPair14387i32 <|
    PetersenLocalChildren.push thetaPair14387i33 <|
    PetersenLocalChildren.push thetaPair14387i34 <|
    PetersenLocalChildren.push thetaPair14387i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i0 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word7) := by
  refine PetersenLocalChildren.pair_close (bank := #[s5,s927,s14623,s14624,s14653,s14654]) (hints := [0,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s5,s927,s14623,s14624,s14653,s14654], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14623) (b14623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14624) (b14624) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14653) (b14653) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14654) (b14654) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i1 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7112,s14655,s12195,s7110]) (hints := [6840,0,6840,4776,1,4776,6840,2,6840,4776,3,4776]) (by decide +kernel) ?_
  change ∀ x ∈ [s7112,s14655,s12195,s7110], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7112) (b7112) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14655) (b14655) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12195) (b12195) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7110) (b7110) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i2 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14656,s14657,s13799,s14663]) (hints := [9677,0,9677,905,1,905,9677,2,9677,905,3,905]) (by decide +kernel) ?_
  change ∀ x ∈ [s14656,s14657,s13799,s14663], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14656) (b14656) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14657) (b14657) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13799) (b13799) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14663) (b14663) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i3 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s7125,s14664]) (hints := [5933,0,6965,5933,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s7125,s14664], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7125) (b7125) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14664) (b14664) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i4 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14665,s14666,s14457,s14667]) (hints := [7478,0,7478,1673,1,1673,7478,2,7478,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s14665,s14666,s14457,s14667], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14665) (b14665) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14666) (b14666) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14457) (b14457) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14667) (b14667) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i5 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s14668,s14553]) (hints := [11468,0,11468,2696,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s14668,s14553], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14668) (b14668) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14553) (b14553) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i6 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14669,s14670,s14671,s14672]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s14669,s14670,s14671,s14672], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14669) (b14669) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14670) (b14670) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14671) (b14671) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14672) (b14672) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i7 : PetersenLocalChildren.PairOK tgt 8 s14622 (word56,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14673,s14674,s14679,s14680]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s14673,s14674,s14679,s14680], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14673) (b14673) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14674) (b14674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14679) (b14679) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14680) (b14680) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i8 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14623,s102,s298]) (hints := [4775,0,4775,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14623,s102,s298], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14623) (b14623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s102) (b102) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s298) (b298) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i9 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14681,s869,s1667,s14682]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s14681,s869,s1667,s14682], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14681) (b14681) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s869) (b869) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1667) (b1667) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14682) (b14682) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i10 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14623,s2140,s2159,s3196]) (hints := [6966,0,6966,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14623,s2140,s2159,s3196], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14623) (b14623) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2140) (b2140) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2159) (b2159) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3196) (b3196) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i11 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14683,s3829,s4443,s5219,s5797,s6016,s14684,s6517]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14683,s3829,s4443,s5219,s5797,s6016,s14684,s6517], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14683) (b14683) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3829) (b3829) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4443) (b4443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5219) (b5219) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5797) (b5797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6016) (b6016) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14684) (b14684) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6517) (b6517) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i12 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14685,s6767,s7532,s14686]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s14685,s6767,s7532,s14686], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14685) (b14685) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6767) (b6767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7532) (b7532) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14686) (b14686) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i13 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14687,s7761,s8428,s14688]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14687,s7761,s8428,s14688], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14687) (b14687) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7761) (b7761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8428) (b8428) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14688) (b14688) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i14 : PetersenLocalChildren.PairOK tgt 8 s14622 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14689,s9037,s9636,s10064,s10507,s10774,s14690,s10948]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14689,s9037,s9636,s10064,s10507,s10774,s14690,s10948], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14689) (b14689) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9037) (b9037) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9636) (b9636) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10064) (b10064) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10507) (b10507) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10774) (b10774) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14690) (b14690) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10948) (b10948) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i15 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11189,s11486]) (hints := [4774,4774,4902,775,0,903,4902,1,4902,4774,4774,903]) (by decide +kernel) ?_
  change ∀ x ∈ [s11189,s11486], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11189) (b11189) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11486) (b11486) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i16 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s298,s3196,s11767,s12284]) (hints := [6966,0,6966,4776,4776,1,7094,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s298,s3196,s11767,s12284], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s298) (b298) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3196) (b3196) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11767) (b11767) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12284) (b12284) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i17 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12480,s12913]) (hints := [4774,4774,5670,1543,0,1671,5670,1,5670,4774,4774,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12480,s12913], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12480) (b12480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12913) (b12913) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i18 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4772,4772,7466,11465,6836,11465,7466,6836,7466,4772,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i19 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,4741,4772,4741,4740,4772,13642,4740,2708,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i20 : PetersenLocalChildren.PairOK tgt 8 s14622 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13205,s13615]) (hints := [4774,4774,12838,8711,0,8839,12838,1,12838,4774,4774,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13205,s13615], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13205) (b13205) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13615) (b13615) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i21 : PetersenLocalChildren.PairOK tgt 8 s14622 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,10832,901,901,6962,901,901,10832,9673,9673,6962]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i22 : PetersenLocalChildren.PairOK tgt 8 s14622 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,1669,8649,9673,7474,1669,9673,1669,901,901,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i23 : PetersenLocalChildren.PairOK tgt 8 s14622 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,11465,6964,6964,7466,11465,6964,11465,901,901,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i24 : PetersenLocalChildren.PairOK tgt 8 s14622 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,4741,804,4900,13642,4741,4900,4741,901,901,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i25 : PetersenLocalChildren.PairOK tgt 8 s14622 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [901,901,8837,1481,9673,13610,8837,9673,8837,901,901,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i26 : PetersenLocalChildren.PairOK tgt 8 s14622 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14349,s14487]) (hints := [6964,6964,7476,1671,0,1671,7476,1,7476,1671,6964,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s14349,s14487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14349) (b14349) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14487) (b14487) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i27 : PetersenLocalChildren.PairOK tgt 8 s14622 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14664,s14553,s14691,s14692]) (hints := [11469,0,11469,6966,6966,1,7982,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14664,s14553,s14691,s14692], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14664) (b14664) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14553) (b14553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14691) (b14691) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14692) (b14692) <|
    PetersenLocalChildren.nil
private theorem thetaPair14622i28 : PetersenLocalChildren.PairOK tgt 8 s14622 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,11090,13513,4741,6962,4741,13513,6962,13513,4741,11090,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i29 : PetersenLocalChildren.PairOK tgt 8 s14622 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13610,6962,13610,8837,11090,8837,13610,11090,13610,8837,6962,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i30 : PetersenLocalChildren.PairOK tgt 8 s14622 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,10433,10441,7474,11465,10433,7474,10433,1669,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i31 : PetersenLocalChildren.PairOK tgt 8 s14622 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,4741,1572,5668,13513,4741,5668,4741,1669,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i32 : PetersenLocalChildren.PairOK tgt 8 s14622 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1669,1669,8837,3410,11602,13610,8837,11602,8837,1669,1669,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i33 : PetersenLocalChildren.PairOK tgt 8 s14622 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4741,11465,4741,3370,7466,14674,4741,7466,4741,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i34 : PetersenLocalChildren.PairOK tgt 8 s14622 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8837,3209,8837,3273,11465,14642,8837,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14622i35 : PetersenLocalChildren.PairOK tgt 8 s14622 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [4741,4741,8837,8740,13513,12836,8837,13513,8837,4741,4741,12836]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b14622 : Blocked tgt 9 s14622 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word56,word7),(word56,word3),(word56,word1),(word56,word0),(word56,word6),(word56,word5),(word56,word2),(word56,word4),(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s14622 p
  exact
    PetersenLocalChildren.push thetaPair14622i0 <|
    PetersenLocalChildren.push thetaPair14622i1 <|
    PetersenLocalChildren.push thetaPair14622i2 <|
    PetersenLocalChildren.push thetaPair14622i3 <|
    PetersenLocalChildren.push thetaPair14622i4 <|
    PetersenLocalChildren.push thetaPair14622i5 <|
    PetersenLocalChildren.push thetaPair14622i6 <|
    PetersenLocalChildren.push thetaPair14622i7 <|
    PetersenLocalChildren.push thetaPair14622i8 <|
    PetersenLocalChildren.push thetaPair14622i9 <|
    PetersenLocalChildren.push thetaPair14622i10 <|
    PetersenLocalChildren.push thetaPair14622i11 <|
    PetersenLocalChildren.push thetaPair14622i12 <|
    PetersenLocalChildren.push thetaPair14622i13 <|
    PetersenLocalChildren.push thetaPair14622i14 <|
    PetersenLocalChildren.push thetaPair14622i15 <|
    PetersenLocalChildren.push thetaPair14622i16 <|
    PetersenLocalChildren.push thetaPair14622i17 <|
    PetersenLocalChildren.push thetaPair14622i18 <|
    PetersenLocalChildren.push thetaPair14622i19 <|
    PetersenLocalChildren.push thetaPair14622i20 <|
    PetersenLocalChildren.push thetaPair14622i21 <|
    PetersenLocalChildren.push thetaPair14622i22 <|
    PetersenLocalChildren.push thetaPair14622i23 <|
    PetersenLocalChildren.push thetaPair14622i24 <|
    PetersenLocalChildren.push thetaPair14622i25 <|
    PetersenLocalChildren.push thetaPair14622i26 <|
    PetersenLocalChildren.push thetaPair14622i27 <|
    PetersenLocalChildren.push thetaPair14622i28 <|
    PetersenLocalChildren.push thetaPair14622i29 <|
    PetersenLocalChildren.push thetaPair14622i30 <|
    PetersenLocalChildren.push thetaPair14622i31 <|
    PetersenLocalChildren.push thetaPair14622i32 <|
    PetersenLocalChildren.push thetaPair14622i33 <|
    PetersenLocalChildren.push thetaPair14622i34 <|
    PetersenLocalChildren.push thetaPair14622i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i0 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15091,s117,s313]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15091,s117,s313], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15091) (b15091) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s117) (b117) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s313) (b313) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i1 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15092,s893,s1682,s15093]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s15092,s893,s1682,s15093], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15092) (b15092) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s893) (b893) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1682) (b1682) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15093) (b15093) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i2 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15091,s2542,s2870]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15091,s2542,s2870], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15091) (b15091) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2542) (b2542) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2870) (b2870) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i3 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15094,s4490,s4522,s5450,s5812,s15095,s15096,s15097]) (hints := [7482,0,7482,1,2,3,7482,4,7482,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15094,s4490,s4522,s5450,s5812,s15095,s15096,s15097], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15094) (b15094) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4490) (b4490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4522) (b4522) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5450) (b5450) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5812) (b5812) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15095) (b15095) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15096) (b15096) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15097) (b15097) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i4 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15098,s6807,s7547,s15099]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s15098,s6807,s7547,s15099], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15098) (b15098) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6807) (b6807) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7547) (b7547) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15099) (b15099) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i5 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15100,s7810,s8443,s15101]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s15100,s7810,s8443,s15101], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15100) (b15100) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7810) (b7810) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8443) (b8443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15101) (b15101) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i6 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15102,s15103,s15104,s4581,s15105,s5468,s5613,s15106,s15107,s15108,s15139,s15140]) (hints := [0,1,2,3,4,5,6,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s15102,s15103,s15104,s4581,s15105,s5468,s5613,s15106,s15107,s15108,s15139,s15140], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15102) (b15102) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15103) (b15103) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15104) (b15104) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4581) (b4581) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15105) (b15105) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5468) (b5468) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5613) (b5613) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15106) (b15106) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15107) (b15107) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15108) (b15108) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15139) (b15139) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15140) (b15140) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i7 : PetersenLocalChildren.PairOK tgt 8 s15090 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15141,s9193,s9686,s10079,s10522,s10797,s15142,s10971]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s15141,s9193,s9686,s10079,s10522,s10797,s15142,s10971], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15141) (b15141) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9193) (b9193) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9686) (b9686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10079) (b10079) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10522) (b10522) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10797) (b10797) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15142) (b15142) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10971) (b10971) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i8 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11210,s11501]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11210,s11501], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11210) (b11210) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11501) (b11501) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i9 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s313,s2870,s11782,s12042]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s313,s2870,s11782,s12042], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s313) (b313) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2870) (b2870) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11782) (b11782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12042) (b12042) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i10 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12513,s12552,s12762,s12928,s15143]) (hints := [7479,6841,7479,0,1,2,7479,3,7479,6841,6841,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s12513,s12552,s12762,s12928,s15143], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12513) (b12513) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12552) (b12552) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12762) (b12762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12928) (b12928) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15143) (b15143) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i11 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i12 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i13 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15144,s12786,s15145,s15146]) (hints := [2712,2712,0,6840,6840,1,6840,6840,2,2712,2712,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15144,s12786,s15145,s15146], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15144) (b15144) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12786) (b12786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15145) (b15145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15146) (b15146) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i14 : PetersenLocalChildren.PairOK tgt 8 s15090 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13259,s13630]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13259,s13630], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13259) (b13259) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13630) (b13630) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i15 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i16 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,7732,9673,9673,7474,9673,9673,7732,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i17 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i18 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,6964,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i19 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15147,s13959,s15148,s15149]) (hints := [8645,8645,0,9677,9677,1,9677,9677,2,8645,8645,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15147,s13959,s15148,s15149], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15147) (b15147) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13959) (b13959) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15148) (b15148) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15149) (b15149) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i20 : PetersenLocalChildren.PairOK tgt 8 s15090 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i21 : PetersenLocalChildren.PairOK tgt 8 s15090 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [6962,6962,7474,4906,5930,7732,7474,5930,7474,6962,6962,7732]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i22 : PetersenLocalChildren.PairOK tgt 8 s15090 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i23 : PetersenLocalChildren.PairOK tgt 8 s15090 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14761,s15155]) (hints := [13515,10060,13515,1836,5932,0,13515,5932,13515,10060,10060,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s14761,s15155], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14761) (b14761) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15155) (b15155) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i24 : PetersenLocalChildren.PairOK tgt 8 s15090 (word0,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15156,s14363,s14461,s15157]) (hints := [11094,11094,0,5934,5934,1,5934,5934,2,11094,11094,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15156,s14363,s14461,s15157], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15156) (b15156) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14363) (b14363) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14461) (b14461) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15157) (b15157) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i25 : PetersenLocalChildren.PairOK tgt 8 s15090 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i26 : PetersenLocalChildren.PairOK tgt 8 s15090 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,5668,10433,11465,7474,11465,10433,7474,10433,11465,5668,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i27 : PetersenLocalChildren.PairOK tgt 8 s15090 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15163,s15164,s15165,s15166]) (hints := [12493,0,1,7478,7478,2,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s15163,s15164,s15165,s15166], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15163) (b15163) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15164) (b15164) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15165) (b15165) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15166) (b15166) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i28 : PetersenLocalChildren.PairOK tgt 8 s15090 (word6,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15166,s927,s15167]) (hints := [1672,7477,1,1672,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15166,s927,s15167], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15166) (b15166) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15167) (b15167) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i29 : PetersenLocalChildren.PairOK tgt 8 s15090 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15168,s15169]) (hints := [8839,7476,8839,12588,0,13612,8839,1,8839,7476,7476,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s15168,s15169], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15168) (b15168) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15169) (b15169) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i30 : PetersenLocalChildren.PairOK tgt 8 s15090 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15170,s15171]) (hints := [11467,11467,13515,3372,7468,0,13515,7468,13515,11467,11467,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s15170,s15171], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15170) (b15170) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15171) (b15171) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i31 : PetersenLocalChildren.PairOK tgt 8 s15090 (word5,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15172,s15173,s15174,s15175]) (hints := [10437,10437,0,11469,11469,1,11469,11469,2,10437,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15172,s15173,s15174,s15175], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15172) (b15172) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15173) (b15173) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15174) (b15174) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15175) (b15175) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i32 : PetersenLocalChildren.PairOK tgt 8 s15090 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i33 : PetersenLocalChildren.PairOK tgt 8 s15090 (word2,word9) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15165,s927,s15176]) (hints := [13516,13516,1,12484,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s15165,s927,s15176], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15165) (b15165) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15176) (b15176) <|
    PetersenLocalChildren.nil
private theorem thetaPair15090i34 : PetersenLocalChildren.PairOK tgt 8 s15090 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair15090i35 : PetersenLocalChildren.PairOK tgt 8 s15090 (word9,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15177,s15178,s15179,s15180]) (hints := [8841,0,8841,13614,1,13614,8841,2,8841,13614,3,13614]) (by decide +kernel) ?_
  change ∀ x ∈ [s15177,s15178,s15179,s15180], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15177) (b15177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15178) (b15178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15179) (b15179) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s15180) (b15180) <|
    PetersenLocalChildren.nil
theorem b15090 : Blocked tgt 9 s15090 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word9),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word9),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word9),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word9),(word0,word4),(word6,word5),(word6,word2),(word6,word9),(word6,word4),(word5,word2),(word5,word9),(word5,word4),(word2,word9),(word2,word4),(word9,word4)], PetersenLocalChildren.PairOK tgt 8 s15090 p
  exact
    PetersenLocalChildren.push thetaPair15090i0 <|
    PetersenLocalChildren.push thetaPair15090i1 <|
    PetersenLocalChildren.push thetaPair15090i2 <|
    PetersenLocalChildren.push thetaPair15090i3 <|
    PetersenLocalChildren.push thetaPair15090i4 <|
    PetersenLocalChildren.push thetaPair15090i5 <|
    PetersenLocalChildren.push thetaPair15090i6 <|
    PetersenLocalChildren.push thetaPair15090i7 <|
    PetersenLocalChildren.push thetaPair15090i8 <|
    PetersenLocalChildren.push thetaPair15090i9 <|
    PetersenLocalChildren.push thetaPair15090i10 <|
    PetersenLocalChildren.push thetaPair15090i11 <|
    PetersenLocalChildren.push thetaPair15090i12 <|
    PetersenLocalChildren.push thetaPair15090i13 <|
    PetersenLocalChildren.push thetaPair15090i14 <|
    PetersenLocalChildren.push thetaPair15090i15 <|
    PetersenLocalChildren.push thetaPair15090i16 <|
    PetersenLocalChildren.push thetaPair15090i17 <|
    PetersenLocalChildren.push thetaPair15090i18 <|
    PetersenLocalChildren.push thetaPair15090i19 <|
    PetersenLocalChildren.push thetaPair15090i20 <|
    PetersenLocalChildren.push thetaPair15090i21 <|
    PetersenLocalChildren.push thetaPair15090i22 <|
    PetersenLocalChildren.push thetaPair15090i23 <|
    PetersenLocalChildren.push thetaPair15090i24 <|
    PetersenLocalChildren.push thetaPair15090i25 <|
    PetersenLocalChildren.push thetaPair15090i26 <|
    PetersenLocalChildren.push thetaPair15090i27 <|
    PetersenLocalChildren.push thetaPair15090i28 <|
    PetersenLocalChildren.push thetaPair15090i29 <|
    PetersenLocalChildren.push thetaPair15090i30 <|
    PetersenLocalChildren.push thetaPair15090i31 <|
    PetersenLocalChildren.push thetaPair15090i32 <|
    PetersenLocalChildren.push thetaPair15090i33 <|
    PetersenLocalChildren.push thetaPair15090i34 <|
    PetersenLocalChildren.push thetaPair15090i35 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
