import higher.WireProjection
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values19
import M191Values2
import M191Values35
import M191Values5
import M191Values737
import M191Values739
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows30
import M191StartPreferredRows31
import ResidualFast
import ThetaClosing
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b6781 : Blocked tgt 7 s6781 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6781 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0af0f00000ffff0a0af0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6782 : Blocked tgt 7 s6782 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6782 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_936 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6783 : Blocked tgt 7 s6783 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6783 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f0f00000f5f50000f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6784 : Blocked tgt 7 s6784 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6784 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_7760 rfl)))))))) (by decide +kernel)
theorem b6785 : Blocked tgt 7 s6785 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,6578,2450,13610,8837,901,1417,901,13610,8837,8837,5930,8837,1669,3346,1669,8837,14642,3209,8837,8837,14642,14642,8837,8837,4741,5257,4741,6836,773,6964,6836,5930,6324,5930,6058,6578,1541,7474,6578,4530,4530,6578,4772,4772,6578,5546,5546,2708,6578,6578,2708,5672,901,901,5928,901,7218,1669,901,901,6964,6964,901,901,6964,6964,901,901,2868,4741,901,6962,1669,7474,1669,5930,6962,6962,5930,5930,6962,6962,5930,1834,4741,5930,4741,1669,7474,7474,1669,1669,7474,7474,1669,1669,7474,4741,1669,2693,2693,4741,14610,4741,3209,4741,13449,4741,13449]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b6790 : Blocked tgt 7 s6790 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6790 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0affff0a0af0f00000f0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6791 : Blocked tgt 7 s6791 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6791 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_208 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6792 : Blocked tgt 7 s6792 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6792 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f5f50000f0f00000f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6820 : Blocked tgt 7 s6820 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6820 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6821 : Blocked tgt 7 s6821 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6821 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2192 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6822 : Blocked tgt 7 s6822 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6822 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6823 : Blocked tgt 7 s6823 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6823 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6824 : Blocked tgt 7 s6824 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6824 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xff00] (PetersenWireProjection.cons pv14_3730 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6825 : Blocked tgt 7 s6825 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6825 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4206 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)

theorem b6826 : Blocked tgt 7 s6826 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6826 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4206 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6827 : Blocked tgt 7 s6827 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6827 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_735 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6828 : Blocked tgt 7 s6828 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6828 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6829 : Blocked tgt 7 s6829 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4530,6836,4530,6836,901,6964,11465,5672,11977,11465,1669,10441,1669,10433,7466,11465,2693,2693,11465,14416,4741,4741,8837,3273,8837,3209,6836,773,772,6836,5672,4276,5672,5800,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,2256,14900,6836,5672,901,5672,9673,7732,8649,7732,901,7208,9673,7208,901,14416,13642,14416,901,14900,1481,14900,901,7216,7220,7216,7728,5672,10832,7208,5672,10832,5672,5672,10832,5672,14388,13352,5672,5668,5684,7716,5668,3604,3636,7700,3604,7732,3152,14900,7732,3112,3112,7208,14416,12836,12852,12836,14884,10772,10804,10772,14868]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b6830 : Blocked tgt 7 s6830 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6830 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xffff0000,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2938 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_7944 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6831 : Blocked tgt 7 s6831 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6831 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0a0a,0xffff0000,0x0] (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6897 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b6834 : Blocked tgt 7 s6834 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6834 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6007 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6835 : Blocked tgt 7 s6835 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6835 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1841 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6836 : Blocked tgt 7 s6836 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6836 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7855 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6837 : Blocked tgt 7 s6837 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6837 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xff00] (PetersenWireProjection.cons pv14_2418 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6897 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6838 : Blocked tgt 7 s6838 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6838 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0x0,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6886 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7944 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6839 : Blocked tgt 7 s6839 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6839 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0a00000000ffff0a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7944 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6840 : Blocked tgt 7 s6840 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6840 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6897 (PetersenWireProjection.cons pv10_7944 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6841 : Blocked tgt 7 s6841 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6841 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0] (PetersenWireProjection.cons pv5_1844 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7944 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6842 : Blocked tgt 7 s6842 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6842 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0a0affff0000ffff0a0affff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)

theorem b6843 : Blocked tgt 7 s6843 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6843 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0a0affff0000ffff0a0affff0000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7944 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6844 : Blocked tgt 7 s6844 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6844 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffff0a0affff0000ffff0a0affff0000 : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6845 : Blocked tgt 7 s6845 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6845 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_715 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6846 : Blocked tgt 7 s6846 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6846 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xffff,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8339 rfl)))))))) (by decide +kernel)
theorem b6847 : Blocked tgt 7 s6847 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6847 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00,0x0,0xaaaa,0xcccc,0xf0f0,0xffff,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffff0a0affff0a0a : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7944 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b6848 : Blocked tgt 7 s6848 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6848 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6849 : Blocked tgt 7 s6849 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6849 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6897 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6850 : Blocked tgt 7 s6850 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6850 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv19_7397 (PetersenWireProjection.cons pv19_7944 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b6851 : Blocked tgt 7 s6851 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6851 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1343 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv19_7944 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b6863 : Blocked tgt 7 s6863 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6863 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaaaaaa0a0aaaaaaaaaaaaa0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b6864 : Blocked tgt 7 s6864 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6864 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xaaaaaaaaaaaa0a0aaaaaaaaaaaaa0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6865 : Blocked tgt 7 s6865 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6865 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaaaaaa0a0aaaaaaaaaaaaa0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6866 : Blocked tgt 7 s6866 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6866 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_732 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6867 : Blocked tgt 7 s6867 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6867 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6868 : Blocked tgt 7 s6868 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6868 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_3753 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6869 : Blocked tgt 7 s6869 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6869 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccccccc0808cccccccccccc0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)

theorem b6870 : Blocked tgt 7 s6870 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6870 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xc4c4000000000000c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6871 : Blocked tgt 7 s6871 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,6836,5546,6836,901,9673,9929,9929,5930,5672,1669,7732,1669,7732,7466,11465,2693,2693,13642,13513,4741,4741,8837,14900,8837,14900,6836,773,772,6836,5288,6324,5672,5288,6836,4264,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,2256,14900,6836,5672,389,5672,5930,7732,7474,7732,901,11465,7466,11465,901,13513,13642,13513,901,14900,13610,14900,901,7216,7220,7216,7728,11465,10832,11465,11977,13513,5672,13513,14025,5672,14388,13352,5672,10433,10441,10433,11457,12481,12489,12481,13505,7732,3152,14900,7732,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b6872 : Blocked tgt 7 s6872 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(5,false))] s6872 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xffff0000,0xffff0a0a,0xff00ff00] (PetersenWireProjection.cons pv737_2906 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffffffffffff0a0affffffffffff0a0a : BitVec 128) = 0xffff0a0a) (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6873 : Blocked tgt 7 s6873 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(5,false))] s6873 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffff0a0a,0x0] (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffffffffffff0a0affffffffffff0a0a : BitVec 128) = 0xffff0a0a) (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b6874 : Blocked tgt 7 s6874 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s6874 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f00000f0f0f0f0f0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b6875 : Blocked tgt 7 s6875 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s6875 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0000000000000f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b6876 : Blocked tgt 7 s6876 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,5546,9674,5546,901,9673,901,9673,9929,9929,1669,7474,1669,7474,2693,11465,2693,11465,4741,13513,4741,13513,8837,13610,8837,13610,5288,5290,5544,5288,5546,6836,10058,5546,6578,4522,7474,6578,5546,4530,7466,5546,1450,1450,5546,10706,5546,2514,13610,5546,9673,901,901,9673,8641,8649,9665,8641,9673,7210,11465,9673,9673,14418,13513,9673,1417,1481,9609,1417,7474,1669,7474,1669,11465,2693,11465,2693,13513,4741,13513,4741,13610,8837,13610,8837,10433,10441,10433,11457,12481,12489,12481,13505,7474,3410,14642,7474,11465,3370,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b6877 : Blocked tgt 7 s6877 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6877 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00ff00ff000a00ff00ff00ff000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6878 : Blocked tgt 7 s6878 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6878 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500000000000000f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6879 : Blocked tgt 7 s6879 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6879 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xff00ff00ff000a00ff00ff00ff000a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6880 : Blocked tgt 7 s6880 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6880 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv11_1934 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xffffffffffff0a0affffffffffff0a0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b6881 : Blocked tgt 7 s6881 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s6881 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1934 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b6882 : Blocked tgt 7 s6882 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6882 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffffffffffff0a0affffffffffff0a0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6883 : Blocked tgt 7 s6883 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6883 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6884 : Blocked tgt 7 s6884 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6884 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffffffff0a0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6885 : Blocked tgt 7 s6885 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6885 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffffffffffffffffff0a0a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b6886 : Blocked tgt 7 s6886 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6886 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffffff0a0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b6887 : Blocked tgt 7 s6887 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6887 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6890 : Blocked tgt 7 s6890 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6890 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaa0a0a00000000aaaa0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6891 : Blocked tgt 7 s6891 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6891 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4289 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6892 : Blocked tgt 7 s6892 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6892 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaa0000a0a0aaaaaaaa0000a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6893 : Blocked tgt 7 s6893 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6893 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccc080800000000cccc0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6894 : Blocked tgt 7 s6894 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6894 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xccccccccffffcececcccccccffffcece : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6895 : Blocked tgt 7 s6895 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6895 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccc0000c4c4cccccccc0000c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6896 : Blocked tgt 7 s6896 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6896 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1167 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6897 : Blocked tgt 7 s6897 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0f0f0fffffafaf0f0f0f0fffffafa,0xaaaaaaaaaaaaaaaafffafffafffafffa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1367) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1367
theorem b6900 : Blocked tgt 7 s6900 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6900 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f0f0f00000f0f0f0f0f0f00000f0f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6901 : Blocked tgt 7 s6901 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6901 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff000a0000000000ff000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6902 : Blocked tgt 7 s6902 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s6902 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff00ff00ffffff0aff00ff00ffffff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b6903 : Blocked tgt 7 s6903 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6903 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff000a0000000000ff000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6904 : Blocked tgt 7 s6904 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6904 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00ff000000f500ff00ff000000f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6905 : Blocked tgt 7 s6905 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6905 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)

theorem b6906 : Blocked tgt 7 s6906 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6906 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xffff0000ffff0a0affff0000ffff0a0a : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6907 : Blocked tgt 7 s6907 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6907 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_715 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6908 : Blocked tgt 7 s6908 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6908 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6671 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6909 : Blocked tgt 7 s6909 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6909 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7955 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b6910 : Blocked tgt 7 s6910 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6910 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffff0a0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6911 : Blocked tgt 7 s6911 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s6911 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffffffffff00000000ffff0a0a : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b6912 : Blocked tgt 7 s6912 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6912 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffff0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6913 : Blocked tgt 7 s6913 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s6913 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffff0000f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b6914 : Blocked tgt 7 s6914 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6914 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6915 : Blocked tgt 7 s6915 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6915 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7944 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6916 : Blocked tgt 7 s6916 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6916 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xf0f0,0x0,0x0,0xaaaa,0xcccc,0x0,0xff00] (PetersenWireProjection.cons pv10_1300 (PetersenWireProjection.cons pv10_1925 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6943 : Blocked tgt 7 s6943 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s6943 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0000ffff00000a0a00000a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)

theorem b6947 : Blocked tgt 7 s6947 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6947 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_587 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xffffffffffffffffffff0a0affff0a0a : BitVec 128) = 0xff00) rfl)))))))) (by decide +kernel)
theorem b6951 : Blocked tgt 7 s6951 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6951 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaa0a0aaaaa0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6952 : Blocked tgt 7 s6952 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6952 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaaaaaaaaaaaaaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6953 : Blocked tgt 7 s6953 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6953 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaaaaaaaaaa0000a0a00000a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6954 : Blocked tgt 7 s6954 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6954 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccc0808cccc0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6955 : Blocked tgt 7 s6955 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s6955 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xccccccccccccccccffffceceffffcece : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b6956 : Blocked tgt 7 s6956 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s6956 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccccccccccc0000c4c40000c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b6957 : Blocked tgt 7 s6957 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6957 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f00000f0f00000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6958 : Blocked tgt 7 s6958 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s6958 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_5486 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b6959 : Blocked tgt 7 s6959 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6959 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f0f0f0f0f0f0f00000f0f00000f0f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6960 : Blocked tgt 7 s6960 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6960 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff000a00ff000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
