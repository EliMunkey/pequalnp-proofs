import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows7
import M191StartPreferredRows8
import M191StartPreferredRows9
import ResidualFast
import ThetaClosing
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b1724 : Blocked tgt 7 s1724 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(1,false),(3,false))] s1724 7 _ le
  decide +kernel
theorem b1725 : Blocked tgt 7 s1725 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1725 7 _ le
  decide +kernel
theorem b1726 : Blocked tgt 7 s1726 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(1,false),(3,false))] s1726 7 _ le
  decide +kernel
theorem b1727 : Blocked tgt 7 s1727 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,16,20,16,22,17,21,19,23,8,12,8,14,9,12,11,14,24,28,24,30,25,28,27,30,64,68,64,70,65,69,67,71,80,84,80,86,81,85,83,87,72,76,72,78,73,76,75,78,88,92,88,94,89,92,91,94,32,36,32,38,33,37,35,39,48,52,48,54,49,53,51,55,40,44,40,46,41,44,43,46,56,60,56,62,57,60,59,62,96,100,96,102,97,101,99,103,112,116,112,118,113,117,115,119,104,108,104,110,105,108,107,110,120,124,120,126,121,124,123,126] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,0,6,1,5,3,7,16,20,16,22,17,17,19,19,8,12,8,14,9,13,11,15,24,28,24,30,25,25,27,27,64,68,64,70,65,69,67,71,80,84,80,86,81,81,83,83,72,76,72,78,73,77,75,79,88,92,88,94,89,89,91,91,32,36,32,38,33,37,35,39,48,52,48,54,49,49,51,51,40,44,40,46,41,45,43,47,56,60,56,62,57,57,59,59,96,100,96,102,97,101,99,103,112,116,112,118,113,113,115,115,104,108,104,110,105,109,107,111,120,124,120,126,121,121,123,123] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0x32323232323232323232323232323232,0x32323232323232323232323232323232),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xfffff0f0fffff0f0fffff0f0fffff0f0),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1115) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1115
theorem b1729 : Blocked tgt 7 s1729 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1729 7 _ le
  decide +kernel
theorem b1731 : Blocked tgt 7 s1731 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1731 7 _ le
  decide +kernel
theorem b1732 : Blocked tgt 7 s1732 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(true,(1,false),(3,false))] s1732 7 _ le
  decide +kernel

theorem b1735 : Blocked tgt 7 s1735 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s1735 7 _ le
  decide +kernel
theorem b1738 : Blocked tgt 7 s1738 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1738 7 _ le
  decide +kernel
theorem b1740 : Blocked tgt 7 s1740 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1740 7 _ le
  decide +kernel
theorem b1741 : Blocked tgt 7 s1741 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1741 7 _ le
  decide +kernel
theorem b1742 : Blocked tgt 7 s1742 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,12,14,14,16,17,18,19,20,21,22,23,24,25,26,27,28,28,30,30,32,33,34,35,36,33,38,35,40,41,42,43,41,41,43,43,48,49,50,51,52,49,54,51,56,57,58,59,57,57,59,59,64,65,66,67,68,69,70,71,72,73,74,75,76,76,78,78,80,81,82,83,84,85,86,87,88,89,90,91,92,92,94,94,96,97,98,99,100,97,102,99,104,105,106,107,105,105,107,107,112,113,114,115,116,113,118,115,120,121,122,123,121,121,123,123] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,12,14,14,16,17,18,19,20,21,22,23,24,25,26,27,28,28,30,30,32,33,34,35,36,33,38,35,40,41,42,43,41,41,43,43,48,49,50,51,52,49,54,51,56,57,58,59,57,57,59,59,64,65,66,67,68,69,70,71,72,73,74,75,76,76,78,78,80,81,82,83,84,85,86,87,88,89,90,91,92,92,94,94,96,97,98,99,100,97,102,99,104,105,106,107,105,105,107,107,112,113,114,115,116,113,118,115,120,121,122,123,121,121,123,123] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xfafafafafafafafafafafafafafafafa,0xfafafafafafafafafafafafafafafafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffaaffaaffaaffaaffaaffaaffaaffaa),(0xffff0000ffff0000ffff0000ffff0000,0xffff0000ffff0000ffff0000ffff0000),(0xffffffff00000000ffffffff00000000,0xffffffff00000000ffffffff00000000),(0xfffffffff0f0f0f0fffffffff0f0f0f0,0xfffffffff0f0f0f0fffffffff0f0f0f0),(0xffffffffffffffff0000000000000000,0xffffffffffffffff0000000000000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1967) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1967
theorem b1744 : Blocked tgt 7 s1744 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1744 7 _ le
  decide +kernel
theorem b1752 : Blocked tgt 7 s1752 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1752 7 _ le
  decide +kernel
theorem b1753 : Blocked tgt 7 s1753 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1753 7 _ le
  decide +kernel
theorem b1755 : Blocked tgt 7 s1755 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1755 7 _ le
  decide +kernel
theorem b1757 : Blocked tgt 7 s1757 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1757 7 _ le
  decide +kernel
theorem b1758 : Blocked tgt 7 s1758 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1758 7 _ le
  decide +kernel
theorem b1759 : Blocked tgt 7 s1759 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false))] s1759 7 _ le
  decide +kernel
theorem b1760 : Blocked tgt 7 s1760 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1760 7 _ le
  decide +kernel
theorem b1763 : Blocked tgt 7 s1763 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1763 7 _ le
  decide +kernel
theorem b1764 : Blocked tgt 7 s1764 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1764 7 _ le
  decide +kernel
theorem b1765 : Blocked tgt 7 s1765 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s1765 7 _ le
  decide +kernel

theorem b1770 : Blocked tgt 7 s1770 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s1770 7 _ le
  decide +kernel
theorem b1774 : Blocked tgt 7 s1774 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1774 7 _ le
  decide +kernel
theorem b1775 : Blocked tgt 7 s1775 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1775 7 _ le
  decide +kernel
theorem b1776 : Blocked tgt 7 s1776 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1776 7 _ le
  decide +kernel
theorem b1778 : Blocked tgt 7 s1778 := by
  intro k le c
  apply rejects_sound r736 (0xaaaa0000aaaa :: i6) 6 tgt small736 hot736 [] s1778 7 _ le
  decide +kernel
theorem b1780 : Blocked tgt 7 s1780 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(false,(1,false),(3,true))] s1780 7 _ le
  decide +kernel
theorem b1781 : Blocked tgt 7 s1781 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1781 7 _ le
  decide +kernel
theorem b1782 : Blocked tgt 7 s1782 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1782 7 _ le
  decide +kernel
theorem b1783 : Blocked tgt 7 s1783 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1783 7 _ le
  decide +kernel

theorem b1785 : Blocked tgt 7 s1785 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1785 7 _ le
  decide +kernel
theorem b1786 : Blocked tgt 7 s1786 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1786 7 _ le
  decide +kernel
theorem b1787 : Blocked tgt 7 s1787 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s1787 7 _ le
  decide +kernel
theorem b1788 : Blocked tgt 7 s1788 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1788 7 _ le
  decide +kernel
theorem b1789 : Blocked tgt 7 s1789 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(false,(1,false),(3,true))] s1789 7 _ le
  decide +kernel
theorem b1790 : Blocked tgt 7 s1790 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1790 7 _ le
  decide +kernel
theorem b1791 : Blocked tgt 7 s1791 := by
  intro k le c
  apply rejects_sound r741 (0xeeeeeeeeeeeeeeee :: i6) 7 tgt small741 hot741 [(false,(1,false),(3,true))] s1791 7 _ le
  decide +kernel
theorem b1792 : Blocked tgt 7 s1792 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s1792 7 _ le
  decide +kernel
theorem b1793 : Blocked tgt 7 s1793 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1793 7 _ le
  decide +kernel
theorem b1794 : Blocked tgt 7 s1794 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1794 7 _ le
  decide +kernel
theorem b1795 : Blocked tgt 7 s1795 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1795 7 _ le
  decide +kernel
theorem b1796 : Blocked tgt 7 s1796 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1796 7 _ le
  decide +kernel
theorem b1797 : Blocked tgt 7 s1797 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1797 7 _ le
  decide +kernel
theorem b1798 : Blocked tgt 7 s1798 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1798 7 _ le
  decide +kernel
theorem b1801 : Blocked tgt 7 s1801 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1801 7 _ le
  decide +kernel
theorem b1802 : Blocked tgt 7 s1802 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1802 7 _ le
  decide +kernel
theorem b1807 : Blocked tgt 7 s1807 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(0,false),(3,false))] s1807 7 _ le
  decide +kernel
theorem b1808 : Blocked tgt 7 s1808 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s1808 7 _ le
  decide +kernel
theorem b1810 : Blocked tgt 7 s1810 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s1810 7 _ le
  decide +kernel
theorem b1811 : Blocked tgt 7 s1811 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1811 7 _ le
  decide +kernel
theorem b1812 : Blocked tgt 7 s1812 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1812 7 _ le
  decide +kernel
theorem b1814 : Blocked tgt 7 s1814 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s1814 7 _ le
  decide +kernel
theorem b1815 : Blocked tgt 7 s1815 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1815 7 _ le
  decide +kernel
theorem b1816 : Blocked tgt 7 s1816 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s1816 7 _ le
  decide +kernel
theorem b1828 : Blocked tgt 7 s1828 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s1828 7 _ le
  decide +kernel
theorem b1829 : Blocked tgt 7 s1829 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1829 7 _ le
  decide +kernel
theorem b1830 : Blocked tgt 7 s1830 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1830 7 _ le
  decide +kernel
theorem b1867 : Blocked tgt 7 s1867 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1867 7 _ le
  decide +kernel
theorem b1875 : Blocked tgt 7 s1875 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s1875 7 _ le
  decide +kernel
theorem b1884 : Blocked tgt 7 s1884 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s1884 7 _ le
  decide +kernel
theorem b1885 : Blocked tgt 7 s1885 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s1885 7 _ le
  decide +kernel
theorem b1886 : Blocked tgt 7 s1886 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s1886 7 _ le
  decide +kernel
theorem b1896 : Blocked tgt 7 s1896 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s1896 7 _ le
  decide +kernel
theorem b1897 : Blocked tgt 7 s1897 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s1897 7 _ le
  decide +kernel
theorem b1962 : Blocked tgt 7 s1962 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s1962 7 _ le
  decide +kernel
theorem b1965 : Blocked tgt 7 s1965 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s1965 7 _ le
  decide +kernel
theorem b1968 : Blocked tgt 7 s1968 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s1968 7 _ le
  decide +kernel
theorem b1969 : Blocked tgt 7 s1969 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1969 7 _ le
  decide +kernel
theorem b1993 : Blocked tgt 7 s1993 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1993 7 _ le
  decide +kernel
theorem b1994 : Blocked tgt 7 s1994 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1994 7 _ le
  decide +kernel
theorem b1995 : Blocked tgt 7 s1995 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1995 7 _ le
  decide +kernel
theorem b1997 : Blocked tgt 7 s1997 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6964,6836,773,6836,9673,9929,389,9673,901,9673,9673,901,901,2693,4916,901,901,13513,6964,901,901,9673,9673,901,901,8837,1481,901,9801,9801,6836,9929,6836,4520,7732,6836,4772,4788,6820,4772,2708,6836,6836,2708,2708,6836,6836,2708,6836,8709,14900,6836,8897,9929,9929,8897,9929,2181,11465,9929,9929,1832,13513,9929,8897,9929,9929,8897,1673,1737,9865,1673,2693,11465,2693,11465,12489,7732,13513,1669,1669,8837,12328,8837,7732,2693,3112,13513,2693,2693,11465,11465,2693,2693,3273,8837,2693,4741,4741,8837,5321,8837,5257,8837,14900,8837,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b1998 : Blocked tgt 7 s1998 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1998 7 _ le
  decide +kernel
theorem b1999 : Blocked tgt 7 s1999 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(3,false)),(false,(3,true),(0,false))] s1999 7 _ le
  decide +kernel

theorem b2021 : Blocked tgt 7 s2021 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(3,false)),(false,(3,true),(0,false))] s2021 7 _ le
  decide +kernel
theorem b2022 : Blocked tgt 7 s2022 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s2022 7 _ le
  decide +kernel
theorem b2023 : Blocked tgt 7 s2023 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(2,false))] s2023 7 _ le
  decide +kernel
theorem b2027 : Blocked tgt 7 s2027 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(0,true),(1,false))] s2027 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
