import higher.WireProjection
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values22
import M191Values30
import M191Values32
import M191Values34
import M191Values35
import M191Values5
import M191Values733
import M191Values735
import M191Values740
import M191Values744
import M191Values745
import M191Values753
import M191Values754
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12076 : Blocked tgt 7 s12076 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12076 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0x5a5a00005a5a00005a5a00005a5a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12077 : Blocked tgt 7 s12077 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12077 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff5a5affff5a5affff5a5affff5a5a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12078 : Blocked tgt 7 s12078 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12078 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x5a5a00005a5a00005a5a00005a5a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12079 : Blocked tgt 7 s12079 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12079 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa5a50000a5a50000a5a50000a5a50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12080 : Blocked tgt 7 s12080 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s12080 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0x5a5a5a5a000000005a5a5a5a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b12081 : Blocked tgt 7 s12081 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12081 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffff5a5a5a5affffffff5a5a5a5a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b12082 : Blocked tgt 7 s12082 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12082 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0x5a5a5a5a000000005a5a5a5a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b12083 : Blocked tgt 7 s12083 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s12083 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa5a5a5a500000000a5a5a5a500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b12084 : Blocked tgt 7 s12084 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s12084 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0x5a5a5a5a5a5a5a5a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b12085 : Blocked tgt 7 s12085 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12085 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff5a5a5a5a5a5a5a5a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b12086 : Blocked tgt 7 s12086 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12086 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0x5a5a5a5a5a5a5a5a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b12087 : Blocked tgt 7 s12087 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s12087 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa5a5a5a5a5a5a5a50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b12088 : Blocked tgt 7 s12088 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12088 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12089 : Blocked tgt 7 s12089 := by
  intro k le c
  apply rejects_sound r733 (0xffffffffcccccccc :: i6) 6 tgt small733 hot733 [] s12089 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0xffffffffcccccccc,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r733 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv733_4814 (PetersenWireProjection.cons pv733_5224 (PetersenWireProjection.cons pv733_5473 (PetersenWireProjection.cons pv733_6170 (PetersenWireProjection.cons pv733_6790 (PetersenWireProjection.cons pv733_7474 (PetersenWireProjection.cons pv733_8012 rfl)))))))) (by decide +kernel)

theorem b12090 : Blocked tgt 7 s12090 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12090 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12091 : Blocked tgt 7 s12091 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12091 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3582 (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12092 : Blocked tgt 7 s12092 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12092 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12093 : Blocked tgt 7 s12093 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12093 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_3822 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12094 : Blocked tgt 7 s12094 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12094 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12095 : Blocked tgt 7 s12095 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12095 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3677 (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12096 : Blocked tgt 7 s12096 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12096 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12097 : Blocked tgt 7 s12097 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s12097 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r753 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_7095 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl)))))))) (by decide +kernel)
theorem b12098 : Blocked tgt 7 s12098 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12098 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12099 : Blocked tgt 7 s12099 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s12099 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0x55550000555500005555000055550000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b12100 : Blocked tgt 7 s12100 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12100 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12101 : Blocked tgt 7 s12101 := by
  intro k le c
  apply rejects_sound r754 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small754 hot754 [] s12101 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r754 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv754_4814 (PetersenWireProjection.cons pv754_5473 (PetersenWireProjection.cons pv754_6170 (PetersenWireProjection.cons pv754_6790 (PetersenWireProjection.cons pv754_7474 (PetersenWireProjection.cons pv754_7688 (PetersenWireProjection.cons pv754_8012 rfl)))))))) (by decide +kernel)
theorem b12102 : Blocked tgt 7 s12102 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12102 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12103 : Blocked tgt 7 s12103 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s12103 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_3730 (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl)))))))) (by decide +kernel)
theorem b12104 : Blocked tgt 7 s12104 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12104 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12105 : Blocked tgt 7 s12105 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12105 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_3822 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl)))))))) (by decide +kernel)
theorem b12106 : Blocked tgt 7 s12106 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12106 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12107 : Blocked tgt 7 s12107 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s12107 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_3759 (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b12108 : Blocked tgt 7 s12108 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12108 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4429 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12109 : Blocked tgt 7 s12109 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s12109 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b12110 : Blocked tgt 7 s12110 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12110 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2800 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b12111 : Blocked tgt 7 s12111 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12111 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12112 : Blocked tgt 7 s12112 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12112 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5241 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12113 : Blocked tgt 7 s12113 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s12113 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons pv745_6618 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl)))))))) (by decide +kernel)
theorem b12114 : Blocked tgt 7 s12114 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12114 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12115 : Blocked tgt 7 s12115 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12115 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2860 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12116 : Blocked tgt 7 s12116 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12116 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5294 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12117 : Blocked tgt 7 s12117 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12117 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0xaaaa,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12118 : Blocked tgt 7 s12118 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12118 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12119 : Blocked tgt 7 s12119 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12119 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b12120 : Blocked tgt 7 s12120 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12120 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5367 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12121 : Blocked tgt 7 s12121 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12121 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0xaaaa,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)

theorem b12122 : Blocked tgt 7 s12122 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12122 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1177 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12123 : Blocked tgt 7 s12123 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s12123 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2963 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b12124 : Blocked tgt 7 s12124 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12124 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5425 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12125 : Blocked tgt 7 s12125 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s12125 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r744 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv744_4260 (PetersenWireProjection.cons pv744_4814 (PetersenWireProjection.cons pv744_6170 (PetersenWireProjection.cons pv744_6790 (PetersenWireProjection.cons pv744_7474 (PetersenWireProjection.cons pv744_8012 (PetersenWireProjection.cons pv744_8245 rfl)))))))) (by decide +kernel)
theorem b12126 : Blocked tgt 7 s12126 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12126 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_456 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12127 : Blocked tgt 7 s12127 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12127 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3004 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b12186 : Blocked tgt 7 s12186 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12186 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3718 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6952 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12307 : Blocked tgt 7 s12307 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12307 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12308 : Blocked tgt 7 s12308 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12308 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)

theorem b12309 : Blocked tgt 7 s12309 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12309 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12310 : Blocked tgt 7 s12310 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12310 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12311 : Blocked tgt 7 s12311 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12311 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xfdecfdecfdecfdecfdecfdecfdecfdec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12312 : Blocked tgt 7 s12312 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12312 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5696 (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12313 : Blocked tgt 7 s12313 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12313 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3304 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12314 : Blocked tgt 7 s12314 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12314 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5241 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12315 : Blocked tgt 7 s12315 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12315 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5696 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12316 : Blocked tgt 7 s12316 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12316 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12317 : Blocked tgt 7 s12317 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12317 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12318 : Blocked tgt 7 s12318 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12318 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfffffffffffffffff5a0f5a0f5a0f5a0 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b12319 : Blocked tgt 7 s12319 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12319 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7314 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12320 : Blocked tgt 7 s12320 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12320 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1887 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12321 : Blocked tgt 7 s12321 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12321 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5a0f5a0f5a0f5a0f5a0f5a0f5a0f5a0 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b12322 : Blocked tgt 7 s12322 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12322 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1252 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12323 : Blocked tgt 7 s12323 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [901,6322,901,6320,5930,6324,6578,5546,7466,4530,7466,4514,13642,2482,13642,10706,13610,3538,13610,6578,6578,10706,7602,6578,8641,5674,5672,8641,8641,773,6836,8641,8641,4916,10433,8641,8641,2868,12481,8641,1417,1473,8585,1417,385,8641,8641,385,6962,5930,7090,6962,10433,4914,10433,5930,12481,1834,12481,9162,5930,1866,13226,5930,5034,5034,5930,6962,10433,7466,10433,7466,12481,12618,12481,11602,3410,3410,11602,13610,6836,11602,7474,7474,10433,3370,12481,10433,3209,3265,10377,3209,2177,10433,10433,2177,5257,5313,12425,5257,4225,12481,12481,4225,13610,14642]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b12324 : Blocked tgt 7 s12324 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12324 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_531 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12337 : Blocked tgt 7 s12337 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(2,false))] s12337 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5920 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12338 : Blocked tgt 7 s12338 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12338 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5920 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12339 : Blocked tgt 7 s12339 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12339 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5863 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12340 : Blocked tgt 7 s12340 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12340 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xfc00fc00fc00fc00fc00fc00fc00fc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12341 : Blocked tgt 7 s12341 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12341 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xfca8fca8fca8fca8fca8fca8fca8fca8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12342 : Blocked tgt 7 s12342 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12342 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0x540054005400540054005400540054 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12347 : Blocked tgt 7 s12347 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12347 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12348 : Blocked tgt 7 s12348 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12348 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12349 : Blocked tgt 7 s12349 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12349 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5696 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12350 : Blocked tgt 7 s12350 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12350 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xa080a080a080a080a080a080a080a08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12368 : Blocked tgt 7 s12368 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12368 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b12372 : Blocked tgt 7 s12372 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12372 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0xffff,0xffff,0x0,0xaaaa,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_6897 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12373 : Blocked tgt 7 s12373 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12373 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xa0a00000a0a00000a0a00000a0a : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12374 : Blocked tgt 7 s12374 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12374 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_2800 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b12375 : Blocked tgt 7 s12375 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12375 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4579 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6546 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12376 : Blocked tgt 7 s12376 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12376 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6546 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b12377 : Blocked tgt 7 s12377 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12377 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3304 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6546 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12378 : Blocked tgt 7 s12378 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12378 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3304 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12379 : Blocked tgt 7 s12379 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12379 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6546 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12380 : Blocked tgt 7 s12380 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12380 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6546 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12383 : Blocked tgt 7 s12383 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12383 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6546 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b12384 : Blocked tgt 7 s12384 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s12384 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5288 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6504 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12385 : Blocked tgt 7 s12385 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s12385 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2063 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6504 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12386 : Blocked tgt 7 s12386 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12386 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xff88ff88ff88ff88ff88ff88ff88ff88 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12387 : Blocked tgt 7 s12387 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12387 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2059 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12388 : Blocked tgt 7 s12388 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12388 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6457 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12389 : Blocked tgt 7 s12389 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12389 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1912 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12390 : Blocked tgt 7 s12390 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12390 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7380 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b12391 : Blocked tgt 7 s12391 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12391 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1913 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)

end PetersenSmallStarts.M191.Staged
