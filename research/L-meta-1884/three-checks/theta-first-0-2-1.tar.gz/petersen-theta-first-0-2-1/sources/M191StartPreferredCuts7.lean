import M191StartPreferredCommon
import M111StartLabeled
import M15StartLabeled
import M31StartLabeled
import M189StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r791 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small791 : NoAtMost (0x3333000033330000 :: i6) (PetersenPackedPin.project r791 tgt) 6 := by
  have a : PetersenPackedPin.project r791 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x3333000033330000 (by decide +kernel)
theorem hot791 : forcedConst r791 tgt = false := by decide +kernel
def r792 (x : Fin 16) : Fin 128 := (#[0,64,4,68,8,72,12,76,16,80,20,84,24,88,28,92] : Array (Fin 128))[x.val]?.getD 0
theorem small792 : NoAtMost (0xf0 :: i4) (PetersenPackedPin.project r792 tgt) 3 := by
  have a : PetersenPackedPin.project r792 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hot792 : forcedConst r792 tgt = false := by decide +kernel
def r793 (x : Fin 16) : Fin 128 := (#[0,8,4,12,64,72,68,76,32,40,36,44,96,104,100,108] : Array (Fin 128))[x.val]?.getD 0
theorem small793 : NoAtMost (0xf0 :: i4) (PetersenPackedPin.project r793 tgt) 3 := by
  have a : PetersenPackedPin.project r793 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hot793 : forcedConst r793 tgt = false := by decide +kernel
def r794 (x : Fin 16) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71] : Array (Fin 128))[x.val]?.getD 0
theorem small794 : NoAtMost (0xa0a :: i4) (PetersenPackedPin.project r794 tgt) 3 := by
  have a : PetersenPackedPin.project r794 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xa0a (by decide +kernel)
theorem hot794 : forcedConst r794 tgt = false := by decide +kernel
def r795 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small795 : NoAtMost (0xc0c0c0c0c0c0c0c :: i6) (PetersenPackedPin.project r795 tgt) 6 := by
  have a : PetersenPackedPin.project r795 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0xc0c0c0c0c0c0c0c (by decide +kernel)
theorem hot795 : forcedConst r795 tgt = false := by decide +kernel
def r796 (x : Fin 64) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57,64,96,65,97,80,112,81,113,72,104,73,105,88,120,89,121,2,34,3,35,18,50,19,51,10,42,11,43,26,58,27,59,66,98,67,99,82,114,83,115,74,106,75,107,90,122,91,123] : Array (Fin 128))[x.val]?.getD 0
theorem small796 : NoAtMost (0x4444444444444444 :: i6) (PetersenPackedPin.project r796 tgt) 6 := by
  have a : PetersenPackedPin.project r796 tgt = PetersenSmallStarts.M111.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M111.all_forbidden 0x4444444444444444 (by decide +kernel)
theorem hot796 : forcedConst r796 tgt = false := by decide +kernel
def r797 (x : Fin 16) : Fin 128 := (#[0,32,1,33,2,34,3,35,4,36,5,37,6,38,7,39] : Array (Fin 128))[x.val]?.getD 0
theorem small797 : NoAtMost (0x3300 :: i4) (PetersenPackedPin.project r797 tgt) 3 := by
  have a : PetersenPackedPin.project r797 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hot797 : forcedConst r797 tgt = false := by decide +kernel
def r798 (x : Fin 16) : Fin 128 := (#[0,2,1,3,32,34,33,35,64,66,65,67,96,98,97,99] : Array (Fin 128))[x.val]?.getD 0
theorem small798 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r798 tgt) 3 := by
  have a : PetersenPackedPin.project r798 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot798 : forcedConst r798 tgt = false := by decide +kernel
def r799 (x : Fin 16) : Fin 128 := (#[0,2,1,3,16,18,17,19,8,10,9,11,24,26,25,27] : Array (Fin 128))[x.val]?.getD 0
theorem small799 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r799 tgt) 3 := by
  have a : PetersenPackedPin.project r799 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot799 : forcedConst r799 tgt = false := by decide +kernel
def r800 (x : Fin 16) : Fin 128 := (#[0,32,1,33,2,34,3,35,4,36,5,37,6,38,7,39] : Array (Fin 128))[x.val]?.getD 0
theorem small800 : NoAtMost (0xf0 :: i4) (PetersenPackedPin.project r800 tgt) 3 := by
  have a : PetersenPackedPin.project r800 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0xf0 (by decide +kernel)
theorem hot800 : forcedConst r800 tgt = false := by decide +kernel
def r801 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small801 : NoAtMost (0xaaaa :: i5) (PetersenPackedPin.project r801 tgt) 6 := by
  have a : PetersenPackedPin.project r801 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xaaaa (by decide +kernel)
theorem hot801 : forcedConst r801 tgt = false := by decide +kernel
def r802 (x : Fin 64) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57,60,61,64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93,96,97,100,101,104,105,108,109,112,113,116,117,120,121,124,125] : Array (Fin 128))[x.val]?.getD 0
theorem small802 : NoAtMost (0xaa00aa00aa00aa :: i6) (PetersenPackedPin.project r802 tgt) 7 := by
  have a : PetersenPackedPin.project r802 tgt = PetersenSmallStarts.M189.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M189.all_forbidden 0xaa00aa00aa00aa (by decide +kernel)
theorem hot802 : forcedConst r802 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
