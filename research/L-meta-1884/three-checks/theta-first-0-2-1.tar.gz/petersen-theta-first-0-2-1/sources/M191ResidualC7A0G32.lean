import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows22
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4981 : Blocked tgt 7 s4981 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4981 7 _ le
  decide +kernel
theorem b4982 : Blocked tgt 7 s4982 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s4982 7 _ le
  decide +kernel
theorem b4983 : Blocked tgt 7 s4983 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4983 7 _ le
  decide +kernel
theorem b4984 : Blocked tgt 7 s4984 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4984 7 _ le
  decide +kernel
theorem b4985 : Blocked tgt 7 s4985 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4985 7 _ le
  decide +kernel
theorem b4986 : Blocked tgt 7 s4986 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4986 7 _ le
  decide +kernel
theorem b4987 : Blocked tgt 7 s4987 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4987 7 _ le
  decide +kernel
theorem b4988 : Blocked tgt 7 s4988 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4988 7 _ le
  decide +kernel
theorem b4989 : Blocked tgt 7 s4989 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4989 7 _ le
  decide +kernel
theorem b4990 : Blocked tgt 7 s4990 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,4266,4520,6836,10058,1537,10058,10186,4522,458,13610,4522,11602,4522,11602,6578,6836,4522,4522,6836,11594,4788,11594,4522,13642,426,13642,394,385,9802,1665,385,8837,13354,8837,385,11346,385,11602,901,901,2693,11338,2693,385,4741,13386,4741,385,1665,8837,9857,1665,11090,1665,1665,11090,10832,1665,1665,10832,1665,2693,2177,1665,1665,4741,4225,1665,8837,3410,7474,8837,8837,13610,13610,8837,2693,3402,2693,8837,4741,13610,4741,8837,1669,1669,2693,2177,2693,2177,4741,4225,4741,4225,2693,2177,2693,2177,4741,4225,4741,4225,2693,12626,4741,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4991 : Blocked tgt 7 s4991 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4991 7 _ le
  decide +kernel
theorem b4992 : Blocked tgt 7 s4992 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4992 7 _ le
  decide +kernel
theorem b4993 : Blocked tgt 7 s4993 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4993 7 _ le
  decide +kernel

theorem b4994 : Blocked tgt 7 s4994 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4994 7 _ le
  decide +kernel
theorem b4995 : Blocked tgt 7 s4995 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4995 7 _ le
  decide +kernel
theorem b4996 : Blocked tgt 7 s4996 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4996 7 _ le
  decide +kernel
theorem b4997 : Blocked tgt 7 s4997 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4997 7 _ le
  decide +kernel
theorem b4998 : Blocked tgt 7 s4998 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4998 7 _ le
  decide +kernel
theorem b4999 : Blocked tgt 7 s4999 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4999 7 _ le
  decide +kernel
theorem b5000 : Blocked tgt 7 s5000 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5000 7 _ le
  decide +kernel
theorem b5001 : Blocked tgt 7 s5001 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5001 7 _ le
  decide +kernel
theorem b5002 : Blocked tgt 7 s5002 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s5002 7 _ le
  decide +kernel
theorem b5003 : Blocked tgt 7 s5003 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s5003 7 _ le
  decide +kernel
theorem b5004 : Blocked tgt 7 s5004 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5004 7 _ le
  decide +kernel
theorem b5005 : Blocked tgt 7 s5005 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5005 7 _ le
  decide +kernel
theorem b5006 : Blocked tgt 7 s5006 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s5006 7 _ le
  decide +kernel
theorem b5007 : Blocked tgt 7 s5007 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s5007 7 _ le
  decide +kernel
theorem b5008 : Blocked tgt 7 s5008 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5008 7 _ le
  decide +kernel
theorem b5009 : Blocked tgt 7 s5009 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5009 7 _ le
  decide +kernel

theorem b5010 : Blocked tgt 7 s5010 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5010 7 _ le
  decide +kernel
theorem b5011 : Blocked tgt 7 s5011 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5011 7 _ le
  decide +kernel
theorem b5012 : Blocked tgt 7 s5012 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5012 7 _ le
  decide +kernel
theorem b5013 : Blocked tgt 7 s5013 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5013 7 _ le
  decide +kernel
theorem b5014 : Blocked tgt 7 s5014 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5014 7 _ le
  decide +kernel
theorem b5015 : Blocked tgt 7 s5015 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5015 7 _ le
  decide +kernel
theorem b5016 : Blocked tgt 7 s5016 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5016 7 _ le
  decide +kernel
theorem b5017 : Blocked tgt 7 s5017 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5017 7 _ le
  decide +kernel
theorem b5018 : Blocked tgt 7 s5018 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s5018 7 _ le
  decide +kernel
theorem b5019 : Blocked tgt 7 s5019 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5019 7 _ le
  decide +kernel
theorem b5020 : Blocked tgt 7 s5020 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5020 7 _ le
  decide +kernel
theorem b5021 : Blocked tgt 7 s5021 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5021 7 _ le
  decide +kernel
theorem b5022 : Blocked tgt 7 s5022 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5022 7 _ le
  decide +kernel
theorem b5023 : Blocked tgt 7 s5023 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5023 7 _ le
  decide +kernel
theorem b5024 : Blocked tgt 7 s5024 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5024 7 _ le
  decide +kernel
theorem b5025 : Blocked tgt 7 s5025 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5025 7 _ le
  decide +kernel

theorem b5026 : Blocked tgt 7 s5026 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5026 7 _ le
  decide +kernel
theorem b5027 : Blocked tgt 7 s5027 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5027 7 _ le
  decide +kernel
theorem b5028 : Blocked tgt 7 s5028 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5028 7 _ le
  decide +kernel
theorem b5029 : Blocked tgt 7 s5029 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5029 7 _ le
  decide +kernel
theorem b5030 : Blocked tgt 7 s5030 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5030 7 _ le
  decide +kernel
theorem b5031 : Blocked tgt 7 s5031 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5031 7 _ le
  decide +kernel
theorem b5032 : Blocked tgt 7 s5032 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5032 7 _ le
  decide +kernel
theorem b5033 : Blocked tgt 7 s5033 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5033 7 _ le
  decide +kernel
theorem b5034 : Blocked tgt 7 s5034 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5034 7 _ le
  decide +kernel
theorem b5035 : Blocked tgt 7 s5035 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5035 7 _ le
  decide +kernel
theorem b5036 : Blocked tgt 7 s5036 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5036 7 _ le
  decide +kernel
theorem b5037 : Blocked tgt 7 s5037 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5037 7 _ le
  decide +kernel
theorem b5038 : Blocked tgt 7 s5038 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5038 7 _ le
  decide +kernel
theorem b5039 : Blocked tgt 7 s5039 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5039 7 _ le
  decide +kernel
theorem b5040 : Blocked tgt 7 s5040 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5040 7 _ le
  decide +kernel
theorem b5046 : Blocked tgt 7 s5046 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s5046 7 _ le
  decide +kernel

theorem b5047 : Blocked tgt 7 s5047 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s5047 7 _ le
  decide +kernel
theorem b5048 : Blocked tgt 7 s5048 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5048 7 _ le
  decide +kernel
theorem b5049 : Blocked tgt 7 s5049 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5049 7 _ le
  decide +kernel
theorem b5050 : Blocked tgt 7 s5050 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(1,false),(2,false))] s5050 7 _ le
  decide +kernel
theorem b5051 : Blocked tgt 7 s5051 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5051 7 _ le
  decide +kernel
theorem b5052 : Blocked tgt 7 s5052 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5052 7 _ le
  decide +kernel
theorem b5053 : Blocked tgt 7 s5053 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5053 7 _ le
  decide +kernel
theorem b5054 : Blocked tgt 7 s5054 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5054 7 _ le
  decide +kernel
theorem b5055 : Blocked tgt 7 s5055 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5055 7 _ le
  decide +kernel
theorem b5056 : Blocked tgt 7 s5056 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5056 7 _ le
  decide +kernel
theorem b5057 : Blocked tgt 7 s5057 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5057 7 _ le
  decide +kernel
theorem b5058 : Blocked tgt 7 s5058 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5058 7 _ le
  decide +kernel
theorem b5059 : Blocked tgt 7 s5059 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5059 7 _ le
  decide +kernel
theorem b5060 : Blocked tgt 7 s5060 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5060 7 _ le
  decide +kernel
theorem b5061 : Blocked tgt 7 s5061 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5061 7 _ le
  decide +kernel
theorem b5062 : Blocked tgt 7 s5062 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5062 7 _ le
  decide +kernel
theorem b5063 : Blocked tgt 7 s5063 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5063 7 _ le
  decide +kernel
theorem b5064 : Blocked tgt 7 s5064 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5064 7 _ le
  decide +kernel
theorem b5065 : Blocked tgt 7 s5065 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [773,4266,773,8641,4522,9793,6578,6578,4522,10433,6570,4522,8650,426,12746,8650,4522,458,12714,4522,4522,4264,8641,5802,5672,8641,7732,8641,8641,773,8641,7466,10433,8641,8641,13386,12481,8641,385,449,8577,385,8641,6964,6962,4906,7474,6962,10433,4914,10433,5930,12481,1834,12481,10058,5930,1866,13610,5930,5672,5930,5930,5672,5668,10433,7458,10433,11602,12481,14674,12481,7474,3410,14642,7474,6836,7474,7474,7732,10433,3370,12481,10433,2177,2241,10369,2177,4772,10433,10433,6820,4225,4289,12417,4225,2708,12481,12481,6804,13610,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Residual
