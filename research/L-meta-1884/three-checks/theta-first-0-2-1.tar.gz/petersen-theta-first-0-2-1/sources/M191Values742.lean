import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv742_4260 : PetersenPackedPin.project r742 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv742_4814 : PetersenPackedPin.project r742 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv742_5473 : PetersenPackedPin.project r742 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv742_6170 : PetersenPackedPin.project r742 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv742_6790 : PetersenPackedPin.project r742 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv742_7474 : PetersenPackedPin.project r742 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv742_8012 : PetersenPackedPin.project r742 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv742_2362 : PetersenPackedPin.project r742 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv742_6170 pv742_6790 rfl rfl
theorem pv742_5850 : PetersenPackedPin.project r742 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv742_4260 pv742_5473 rfl rfl
theorem pv742_5856 : PetersenPackedPin.project r742 (0xfafffafafafffafafafffafafafffafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv742_2362 pv742_5850 rfl rfl
theorem pv742_2407 : PetersenPackedPin.project r742 (0xff00fa00ff00fa00ff00fa00ff00fa : BitVec 128) = 0x4444 := PetersenWireProjection.derive 1 pv742_5856 pv742_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
