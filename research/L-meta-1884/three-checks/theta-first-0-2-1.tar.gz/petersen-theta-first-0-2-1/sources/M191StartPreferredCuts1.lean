import M191StartPreferredCommon
import M189StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r21 (x : Fin 16) : Fin 128 := (#[0,1,16,17,32,33,48,49,64,65,80,81,96,97,112,113] : Array (Fin 128))[x.val]?.getD 0
theorem small21 : NoAtMost i4 (PetersenPackedPin.project r21 tgt) 3 := by
  have a : PetersenPackedPin.project r21 tgt = table 177 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 177 0 (by decide +kernel) (by decide +kernel)
theorem hot21 : forcedConst r21 tgt = false := by decide +kernel
def r22 (x : Fin 16) : Fin 128 := (#[0,1,8,9,16,17,24,25,32,33,40,41,48,49,56,57] : Array (Fin 128))[x.val]?.getD 0
theorem small22 : NoAtMost i4 (PetersenPackedPin.project r22 tgt) 3 := by
  have a : PetersenPackedPin.project r22 tgt = table 57 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 57 0 (by decide +kernel) (by decide +kernel)
theorem hot22 : forcedConst r22 tgt = false := by decide +kernel
def r24 (x : Fin 16) : Fin 128 := (#[0,1,4,5,32,33,36,37,64,65,68,69,96,97,100,101] : Array (Fin 128))[x.val]?.getD 0
theorem small24 : NoAtMost i4 (PetersenPackedPin.project r24 tgt) 3 := by
  have a : PetersenPackedPin.project r24 tgt = table 165 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 165 0 (by decide +kernel) (by decide +kernel)
theorem hot24 : forcedConst r24 tgt = false := by decide +kernel
def r27 (x : Fin 16) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29] : Array (Fin 128))[x.val]?.getD 0
theorem small27 : NoAtMost i4 (PetersenPackedPin.project r27 tgt) 3 := by
  have a : PetersenPackedPin.project r27 tgt = table 29 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 29 0 (by decide +kernel) (by decide +kernel)
theorem hot27 : forcedConst r27 tgt = false := by decide +kernel
def r30 (x : Fin 16) : Fin 128 := (#[0,1,2,3,32,33,34,35,64,65,66,67,96,97,98,99] : Array (Fin 128))[x.val]?.getD 0
theorem small30 : NoAtMost i4 (PetersenPackedPin.project r30 tgt) 3 := by
  have a : PetersenPackedPin.project r30 tgt = table 163 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 163 0 (by decide +kernel) (by decide +kernel)
theorem hot30 : forcedConst r30 tgt = false := by decide +kernel
def r32 (x : Fin 16) : Fin 128 := (#[8,9,10,11,40,41,42,43,72,73,74,75,104,105,106,107] : Array (Fin 128))[x.val]?.getD 0
theorem small32 : NoAtMost i4 (PetersenPackedPin.project r32 tgt) 3 := by
  have a : PetersenPackedPin.project r32 tgt = table 163 8 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 163 8 (by decide +kernel) (by decide +kernel)
theorem hot32 : forcedConst r32 tgt = false := by decide +kernel
def r34 (x : Fin 16) : Fin 128 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27] : Array (Fin 128))[x.val]?.getD 0
theorem small34 : NoAtMost i4 (PetersenPackedPin.project r34 tgt) 3 := by
  have a : PetersenPackedPin.project r34 tgt = table 27 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 27 0 (by decide +kernel) (by decide +kernel)
theorem hot34 : forcedConst r34 tgt = false := by decide +kernel
def r35 (x : Fin 16) : Fin 128 := (#[64,65,66,67,72,73,74,75,80,81,82,83,88,89,90,91] : Array (Fin 128))[x.val]?.getD 0
theorem small35 : NoAtMost i4 (PetersenPackedPin.project r35 tgt) 3 := by
  have a : PetersenPackedPin.project r35 tgt = table 27 128 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 27 128 (by decide +kernel) (by decide +kernel)
theorem hot35 : forcedConst r35 tgt = false := by decide +kernel
def r38 (x : Fin 16) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71] : Array (Fin 128))[x.val]?.getD 0
theorem small38 : NoAtMost i4 (PetersenPackedPin.project r38 tgt) 3 := by
  have a : PetersenPackedPin.project r38 tgt = table 135 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 135 0 (by decide +kernel) (by decide +kernel)
theorem hot38 : forcedConst r38 tgt = false := by decide +kernel
def r39 (x : Fin 16) : Fin 128 := (#[0,1,2,3,4,5,6,7,32,33,34,35,36,37,38,39] : Array (Fin 128))[x.val]?.getD 0
theorem small39 : NoAtMost i4 (PetersenPackedPin.project r39 tgt) 3 := by
  have a : PetersenPackedPin.project r39 tgt = table 39 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 39 0 (by decide +kernel) (by decide +kernel)
theorem hot39 : forcedConst r39 tgt = false := by decide +kernel
def r41 (x : Fin 16) : Fin 128 := (#[0,1,2,3,4,5,6,7,16,17,18,19,20,21,22,23] : Array (Fin 128))[x.val]?.getD 0
theorem small41 : NoAtMost i4 (PetersenPackedPin.project r41 tgt) 3 := by
  have a : PetersenPackedPin.project r41 tgt = table 23 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 23 0 (by decide +kernel) (by decide +kernel)
theorem hot41 : forcedConst r41 tgt = false := by decide +kernel
def r730 (x : Fin 64) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57,60,61,64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93,96,97,100,101,104,105,108,109,112,113,116,117,120,121,124,125] : Array (Fin 128))[x.val]?.getD 0
theorem small730 : NoAtMost (0x8888888888888888 :: i6) (PetersenPackedPin.project r730 tgt) 7 := by
  have a : PetersenPackedPin.project r730 tgt = PetersenSmallStarts.M189.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M189.all_forbidden 0x8888888888888888 (by decide +kernel)
theorem hot730 : forcedConst r730 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
