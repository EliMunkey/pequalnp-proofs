import M63StartData
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b245 : Blocked tgt 5 s245 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s245 5 _ le
  decide +kernel
theorem b246 : Blocked tgt 5 s246 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(4,false))] s246 5 _ le
  decide +kernel
theorem b251 : Blocked tgt 5 s251 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s251 5 _ le
  decide +kernel
theorem b252 : Blocked tgt 5 s252 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s252 5 _ le
  decide +kernel
theorem b253 : Blocked tgt 5 s253 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s253 5 _ le
  decide +kernel
theorem b254 : Blocked tgt 5 s254 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s254 5 _ le
  decide +kernel
theorem b255 : Blocked tgt 5 s255 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s255 5 _ le
  decide +kernel
theorem b256 : Blocked tgt 5 s256 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s256 5 _ le
  decide +kernel
theorem b257 : Blocked tgt 5 s257 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s257 5 _ le
  decide +kernel
theorem b258 : Blocked tgt 5 s258 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(4,false))] s258 5 _ le
  decide +kernel
theorem b263 : Blocked tgt 5 s263 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s263 5 _ le
  decide +kernel
theorem b264 : Blocked tgt 5 s264 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s264 5 _ le
  decide +kernel
theorem b265 : Blocked tgt 5 s265 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s265 5 _ le
  decide +kernel
theorem b266 : Blocked tgt 5 s266 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s266 5 _ le
  decide +kernel
theorem b267 : Blocked tgt 5 s267 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s267 5 _ le
  decide +kernel
theorem b268 : Blocked tgt 5 s268 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s268 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
