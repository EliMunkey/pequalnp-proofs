import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows17
import M191StartPreferredRows18
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3950 : Blocked tgt 7 s3950 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3950 7 _ le
  decide +kernel
theorem b3951 : Blocked tgt 7 s3951 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3951 7 _ le
  decide +kernel
theorem b3952 : Blocked tgt 7 s3952 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3952 7 _ le
  decide +kernel
theorem b3953 : Blocked tgt 7 s3953 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3953 7 _ le
  decide +kernel
theorem b3954 : Blocked tgt 7 s3954 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3954 7 _ le
  decide +kernel
theorem b3955 : Blocked tgt 7 s3955 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3955 7 _ le
  decide +kernel
theorem b3956 : Blocked tgt 7 s3956 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3956 7 _ le
  decide +kernel
theorem b3957 : Blocked tgt 7 s3957 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3957 7 _ le
  decide +kernel
theorem b3958 : Blocked tgt 7 s3958 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3958 7 _ le
  decide +kernel
theorem b3959 : Blocked tgt 7 s3959 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s3959 7 _ le
  decide +kernel
theorem b3960 : Blocked tgt 7 s3960 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3960 7 _ le
  decide +kernel
theorem b3961 : Blocked tgt 7 s3961 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3961 7 _ le
  decide +kernel
theorem b3962 : Blocked tgt 7 s3962 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3962 7 _ le
  decide +kernel

theorem b3963 : Blocked tgt 7 s3963 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3963 7 _ le
  decide +kernel
theorem b3964 : Blocked tgt 7 s3964 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3964 7 _ le
  decide +kernel
theorem b3965 : Blocked tgt 7 s3965 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3965 7 _ le
  decide +kernel
theorem b3966 : Blocked tgt 7 s3966 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3966 7 _ le
  decide +kernel
theorem b3970 : Blocked tgt 7 s3970 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3970 7 _ le
  decide +kernel
theorem b3971 : Blocked tgt 7 s3971 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3971 7 _ le
  decide +kernel
theorem b3972 : Blocked tgt 7 s3972 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3972 7 _ le
  decide +kernel
theorem b3973 : Blocked tgt 7 s3973 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3973 7 _ le
  decide +kernel
theorem b3974 : Blocked tgt 7 s3974 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3974 7 _ le
  decide +kernel
theorem b3975 : Blocked tgt 7 s3975 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3975 7 _ le
  decide +kernel
theorem b3976 : Blocked tgt 7 s3976 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3976 7 _ le
  decide +kernel
theorem b3977 : Blocked tgt 7 s3977 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3977 7 _ le
  decide +kernel
theorem b3978 : Blocked tgt 7 s3978 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3978 7 _ le
  decide +kernel
theorem b3979 : Blocked tgt 7 s3979 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3979 7 _ le
  decide +kernel
theorem b3980 : Blocked tgt 7 s3980 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3980 7 _ le
  decide +kernel
theorem b3981 : Blocked tgt 7 s3981 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3981 7 _ le
  decide +kernel

theorem b3982 : Blocked tgt 7 s3982 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3982 7 _ le
  decide +kernel
theorem b3983 : Blocked tgt 7 s3983 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3983 7 _ le
  decide +kernel
theorem b3984 : Blocked tgt 7 s3984 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3984 7 _ le
  decide +kernel
theorem b3985 : Blocked tgt 7 s3985 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3985 7 _ le
  decide +kernel
theorem b3986 : Blocked tgt 7 s3986 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3986 7 _ le
  decide +kernel
theorem b3987 : Blocked tgt 7 s3987 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3987 7 _ le
  decide +kernel
theorem b3988 : Blocked tgt 7 s3988 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3988 7 _ le
  decide +kernel
theorem b3989 : Blocked tgt 7 s3989 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3989 7 _ le
  decide +kernel
theorem b3990 : Blocked tgt 7 s3990 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3990 7 _ le
  decide +kernel
theorem b3991 : Blocked tgt 7 s3991 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3991 7 _ le
  decide +kernel
theorem b3992 : Blocked tgt 7 s3992 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3992 7 _ le
  decide +kernel
theorem b3993 : Blocked tgt 7 s3993 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3993 7 _ le
  decide +kernel
theorem b3995 : Blocked tgt 7 s3995 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3995 7 _ le
  decide +kernel
theorem b3996 : Blocked tgt 7 s3996 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3996 7 _ le
  decide +kernel
theorem b3997 : Blocked tgt 7 s3997 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3997 7 _ le
  decide +kernel
theorem b3998 : Blocked tgt 7 s3998 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3998 7 _ le
  decide +kernel

theorem b3999 : Blocked tgt 7 s3999 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3999 7 _ le
  decide +kernel
theorem b4000 : Blocked tgt 7 s4000 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4000 7 _ le
  decide +kernel
theorem b4001 : Blocked tgt 7 s4001 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4001 7 _ le
  decide +kernel
theorem b4002 : Blocked tgt 7 s4002 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s4002 7 _ le
  decide +kernel
theorem b4003 : Blocked tgt 7 s4003 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4003 7 _ le
  decide +kernel
theorem b4004 : Blocked tgt 7 s4004 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4004 7 _ le
  decide +kernel
theorem b4005 : Blocked tgt 7 s4005 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4005 7 _ le
  decide +kernel
theorem b4006 : Blocked tgt 7 s4006 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4006 7 _ le
  decide +kernel
theorem b4007 : Blocked tgt 7 s4007 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4007 7 _ le
  decide +kernel
theorem b4008 : Blocked tgt 7 s4008 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4008 7 _ le
  decide +kernel
theorem b4009 : Blocked tgt 7 s4009 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4009 7 _ le
  decide +kernel
theorem b4010 : Blocked tgt 7 s4010 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4010 7 _ le
  decide +kernel
theorem b4011 : Blocked tgt 7 s4011 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4011 7 _ le
  decide +kernel
theorem b4012 : Blocked tgt 7 s4012 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4012 7 _ le
  decide +kernel
theorem b4013 : Blocked tgt 7 s4013 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4013 7 _ le
  decide +kernel
theorem b4014 : Blocked tgt 7 s4014 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4014 7 _ le
  decide +kernel

theorem b4015 : Blocked tgt 7 s4015 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(2,false),(3,true))] s4015 7 _ le
  decide +kernel
theorem b4016 : Blocked tgt 7 s4016 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(false,(2,false),(3,true))] s4016 7 _ le
  decide +kernel
theorem b4017 : Blocked tgt 7 s4017 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4017 7 _ le
  decide +kernel
theorem b4018 : Blocked tgt 7 s4018 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4018 7 _ le
  decide +kernel
theorem b4019 : Blocked tgt 7 s4019 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4019 7 _ le
  decide +kernel
theorem b4020 : Blocked tgt 7 s4020 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4020 7 _ le
  decide +kernel
theorem b4021 : Blocked tgt 7 s4021 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4021 7 _ le
  decide +kernel
theorem b4022 : Blocked tgt 7 s4022 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4022 7 _ le
  decide +kernel
theorem b4023 : Blocked tgt 7 s4023 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4023 7 _ le
  decide +kernel
theorem b4024 : Blocked tgt 7 s4024 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4024 7 _ le
  decide +kernel
theorem b4028 : Blocked tgt 7 s4028 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4028 7 _ le
  decide +kernel
theorem b4029 : Blocked tgt 7 s4029 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4029 7 _ le
  decide +kernel
theorem b4030 : Blocked tgt 7 s4030 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4030 7 _ le
  decide +kernel
theorem b4031 : Blocked tgt 7 s4031 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4031 7 _ le
  decide +kernel
theorem b4032 : Blocked tgt 7 s4032 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4032 7 _ le
  decide +kernel
theorem b4033 : Blocked tgt 7 s4033 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4033 7 _ le
  decide +kernel

theorem b4034 : Blocked tgt 7 s4034 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,6836,4522,6836,901,8641,5930,9921,5930,9921,7474,7732,1669,1669,2693,10433,2693,10433,13642,12481,4741,4741,8837,14900,8837,14900,6836,773,2836,6836,4264,9793,5672,4264,6836,4264,7732,6836,4772,4788,6820,4772,13377,6836,6836,12481,6836,458,14900,6836,9921,901,9921,5930,7732,7474,7732,901,10433,788,10433,901,12481,13642,12481,901,14900,13610,14900,901,7216,9921,9921,7728,9921,2693,10433,9921,9921,1576,12481,9921,1665,1729,9857,1665,5668,10433,7716,10433,3636,12481,7732,12481,7732,12328,14900,7732,10433,3112,12481,10433,2177,2241,10369,2177,4225,4289,12417,4225]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4035 : Blocked tgt 7 s4035 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4035 7 _ le
  decide +kernel
theorem b4036 : Blocked tgt 7 s4036 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s4036 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
