import M191ResidualC7A0G1
import M191ResidualC7A0G20
import M191ResidualC7A0G21
import M191ResidualC7A0G22
import M191ResidualC7A0G27
import M191ResidualC7A0G4
import M191ResidualC7A0G9
import M191StagedF0X2Z1G10
import M191StagedF0X2Z1G11
import M191StagedF0X2Z1G12
import M191StagedF0X2Z1G13
import M191StagedF0X2Z1G14
import M191StagedF0X2Z1G15
import M191StagedF0X2Z1G16
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G71
import M191StagedF0X2Z1G8
import M191StagedF0X2Z1G9
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows15
import M191StartPreferredRows16
import M191StartPreferredRows17
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows4
import M191StartPreferredRows5
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3533 : Blocked tgt 8 s3533 := by
  apply PetersenFastNode.node (nxt := #[s3534,s3535,s423,s581,s3536,s3244,s3537,s3538,s3478,s3540,s3541,s3542,s3543,s3544,s941,s3545,s3546,s3547,s3548,s3550,s3551,s3552,s3553,s3485,s3507,s3554,s958,s3555,s3556,s3557,s3558,s3559,s3560,s3561,s3562,s3563,s3564,s3565,s3566,s3567,s3568]) (hints := [6877,6877,0,4307,4563,8682,4561,4563,1,6877,6877,8682,4563,4563,5971,9834,6877,9962,5971,6877,5971,4563,4563,9962,7515,6877,7515,4563,4563,2,6619,4563,7515,6619,6877,3,6877,6877,4,4563,4563,5,4563,4563,6,6877,6877,7,4563,4563,7507,4829,6877,2734,6611,6877,7507,4563,4563,2734,8691,8691,13683,467,4563,4782,12787,4563,13683,8691,8691,4782,4563,4563,13651,499,8691,8878,12755,8691,13651,4563,4563,8878,8682,8682,9962,5715,8,5971,9962,9,9962,8682,8682,5971,7259,10,11,8682,8682,12,7515,13,7515,942,8682,14,942,13,15,2734,8682,2734,7251,16,7507,2734,17,2734,8682,8682,7507,4782,8682,4782,13427,18,13683,4782,19,4782,8682,8682,13683,8878,426,8878,490,8682,13651,8878,8682,8878,426,426,13651,7003,7003,7515,9962,9962,20,9962,9962,7515,7003,7003,21,10873,10873,22,9962,9962,23,9962,9962,24,10873,10873,25,9962,9962,10474,2734,7003,2734,10474,7003,10474,9962,9962,2734,9962,9962,12522,4782,5971,4782,12522,5971,12522,9962,9962,4782,1706,1706,13651,1770,9962,8878,9898,9962,13651,1706,1706,8878,1710,7515,14,1710,12,26,2734,27,2734,10474,7515,10474,2734,7515,2734,10474,28,10474,4782,11643,4782,12522,7515,12522,4782,7515,4782,12522,11643,12522,8878,7515,8878,3451,11643,13651,8878,11643,8878,7515,7515,13651,2734,29,2734,10474,30,10474,2734,31,2734,10474,32,10474,4782,33,4782,12522,34,12522,4782,35,4782,12522,36,12522,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651,2734,2734,4782,3411,7507,14715,4782,7507,4782,2734,2734,14715,2734,2734,8878,2282,10474,14683,8878,10474,8878,2734,2734,14683,4782,4782,8878,4330,12522,13651,8878,12522,8878,4782,4782,13651]) (by decide +kernel)
  change ∀ b ∈ [s3534,s3535,s423,s581,s3536,s3244,s3537,s3538,s3478,s3540,s3541,s3542,s3543,s3544,s941,s3545,s3546,s3547,s3548,s3550,s3551,s3552,s3553,s3485,s3507,s3554,s958,s3555,s3556,s3557,s3558,s3559,s3560,s3561,s3562,s3563,s3564,s3565,s3566,s3567,s3568], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3534) b3534 <|
    PetersenLocalChildren.push (x := s3535) b3535 <|
    PetersenLocalChildren.push (x := s423) b423 <|
    PetersenLocalChildren.push (x := s581) b581 <|
    PetersenLocalChildren.push (x := s3536) b3536 <|
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s3537) b3537 <|
    PetersenLocalChildren.push (x := s3538) b3538 <|
    PetersenLocalChildren.push (x := s3478) b3478 <|
    PetersenLocalChildren.push (x := s3540) b3540 <|
    PetersenLocalChildren.push (x := s3541) b3541 <|
    PetersenLocalChildren.push (x := s3542) b3542 <|
    PetersenLocalChildren.push (x := s3543) b3543 <|
    PetersenLocalChildren.push (x := s3544) b3544 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3545) b3545 <|
    PetersenLocalChildren.push (x := s3546) b3546 <|
    PetersenLocalChildren.push (x := s3547) b3547 <|
    PetersenLocalChildren.push (x := s3548) b3548 <|
    PetersenLocalChildren.push (x := s3550) b3550 <|
    PetersenLocalChildren.push (x := s3551) b3551 <|
    PetersenLocalChildren.push (x := s3552) b3552 <|
    PetersenLocalChildren.push (x := s3553) b3553 <|
    PetersenLocalChildren.push (x := s3485) b3485 <|
    PetersenLocalChildren.push (x := s3507) b3507 <|
    PetersenLocalChildren.push (x := s3554) b3554 <|
    PetersenLocalChildren.push (x := s958) b958 <|
    PetersenLocalChildren.push (x := s3555) b3555 <|
    PetersenLocalChildren.push (x := s3556) b3556 <|
    PetersenLocalChildren.push (x := s3557) b3557 <|
    PetersenLocalChildren.push (x := s3558) b3558 <|
    PetersenLocalChildren.push (x := s3559) b3559 <|
    PetersenLocalChildren.push (x := s3560) b3560 <|
    PetersenLocalChildren.push (x := s3561) b3561 <|
    PetersenLocalChildren.push (x := s3562) b3562 <|
    PetersenLocalChildren.push (x := s3563) b3563 <|
    PetersenLocalChildren.push (x := s3564) b3564 <|
    PetersenLocalChildren.push (x := s3565) b3565 <|
    PetersenLocalChildren.push (x := s3566) b3566 <|
    PetersenLocalChildren.push (x := s3567) b3567 <|
    PetersenLocalChildren.push (x := s3568) b3568 <|
    PetersenLocalChildren.nil
theorem b3570 : Blocked tgt 8 s3570 := by
  apply PetersenFastNode.node (nxt := #[s3571,s3572,s3246,s3573,s941,s957,s3544,s3505,s3574,s3487,s3576,s3577,s3578,s3579,s3580,s3581,s3582,s3583,s3584,s3585,s3586,s3587,s3588,s3589,s3590,s3320,s3591,s3592,s3526,s3593,s3594,s3595,s3597,s3598,s3601,s3602,s3603]) (hints := [4559,0,4559,4301,1,4301,4559,2,4559,4301,3,4301,938,4,938,8678,5,6,5967,7,5967,9958,8,9958,5967,9,5967,9958,10,9958,1706,4,7511,1706,11,12,2730,13,2730,10470,14,10470,2730,15,2730,10470,16,10470,4778,17,4778,12518,18,12518,4778,19,4778,12518,20,12518,8874,21,8874,13389,22,13389,8874,23,8874,13389,24,13389,4301,4301,7001,810,4559,938,7001,4559,7001,4301,4301,938,4301,4301,5709,9830,6873,9958,5709,6873,5709,4301,4301,9958,7511,6873,7511,4301,4301,25,4301,4301,7511,6615,6873,26,4301,4301,7245,10470,6873,10470,6349,6873,7245,4301,4301,10470,13414,8687,13421,12518,4301,12518,12525,4301,13421,12518,8687,12518,4301,4301,13389,495,8687,8874,12493,8687,13389,4301,4301,8874,9958,27,9958,938,938,5967,9958,938,9958,5967,28,5967,938,938,12,7511,6,7511,1962,29,30,10470,938,10470,4953,7001,7503,10470,7001,10470,938,938,7503,12518,938,12518,2905,7001,13679,12518,7001,12518,938,938,13679,13389,938,13389,13647,31,13647,13389,32,13389,938,938,13647,6999,6999,7511,9958,9958,33,9958,9958,7511,6999,6999,34,9958,9958,10470,2730,6999,2730,10470,6999,10470,9958,9958,2730,9958,9958,12518,1613,5709,4778,12518,5709,12518,9958,9958,4778,1702,1702,13389,1766,9958,8874,9894,9958,13389,1702,1702,8874,2730,35,2730,10470,7511,10470,2730,7511,2730,10470,36,10470,4778,11639,4778,12518,7511,12518,4778,7511,4778,12518,11639,12518,8874,7511,8874,13389,11639,13389,8874,11639,8874,13389,7511,13389,10470,10470,12518,3149,7245,14711,12518,7245,12518,10470,10470,14711,2214,2214,13389,2278,10470,14679,10406,10470,13389,2214,2214,14679,4262,4262,8874,4326,12518,13389,12454,12518,8874,4262,4262,13389]) (by decide +kernel)
  change ∀ b ∈ [s3571,s3572,s3246,s3573,s941,s957,s3544,s3505,s3574,s3487,s3576,s3577,s3578,s3579,s3580,s3581,s3582,s3583,s3584,s3585,s3586,s3587,s3588,s3589,s3590,s3320,s3591,s3592,s3526,s3593,s3594,s3595,s3597,s3598,s3601,s3602,s3603], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3571) b3571 <|
    PetersenLocalChildren.push (x := s3572) b3572 <|
    PetersenLocalChildren.push (x := s3246) b3246 <|
    PetersenLocalChildren.push (x := s3573) b3573 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s957) b957 <|
    PetersenLocalChildren.push (x := s3544) b3544 <|
    PetersenLocalChildren.push (x := s3505) b3505 <|
    PetersenLocalChildren.push (x := s3574) b3574 <|
    PetersenLocalChildren.push (x := s3487) b3487 <|
    PetersenLocalChildren.push (x := s3576) b3576 <|
    PetersenLocalChildren.push (x := s3577) b3577 <|
    PetersenLocalChildren.push (x := s3578) b3578 <|
    PetersenLocalChildren.push (x := s3579) b3579 <|
    PetersenLocalChildren.push (x := s3580) b3580 <|
    PetersenLocalChildren.push (x := s3581) b3581 <|
    PetersenLocalChildren.push (x := s3582) b3582 <|
    PetersenLocalChildren.push (x := s3583) b3583 <|
    PetersenLocalChildren.push (x := s3584) b3584 <|
    PetersenLocalChildren.push (x := s3585) b3585 <|
    PetersenLocalChildren.push (x := s3586) b3586 <|
    PetersenLocalChildren.push (x := s3587) b3587 <|
    PetersenLocalChildren.push (x := s3588) b3588 <|
    PetersenLocalChildren.push (x := s3589) b3589 <|
    PetersenLocalChildren.push (x := s3590) b3590 <|
    PetersenLocalChildren.push (x := s3320) b3320 <|
    PetersenLocalChildren.push (x := s3591) b3591 <|
    PetersenLocalChildren.push (x := s3592) b3592 <|
    PetersenLocalChildren.push (x := s3526) b3526 <|
    PetersenLocalChildren.push (x := s3593) b3593 <|
    PetersenLocalChildren.push (x := s3594) b3594 <|
    PetersenLocalChildren.push (x := s3595) b3595 <|
    PetersenLocalChildren.push (x := s3597) b3597 <|
    PetersenLocalChildren.push (x := s3598) b3598 <|
    PetersenLocalChildren.push (x := s3601) b3601 <|
    PetersenLocalChildren.push (x := s3602) b3602 <|
    PetersenLocalChildren.push (x := s3603) b3603 <|
    PetersenLocalChildren.nil
theorem b3605 : Blocked tgt 8 s3605 := by
  apply PetersenFastNode.node (nxt := #[s3237,s3606,s3366,s3607,s3608,s3248,s3609,s3610,s3611,s3527,s3546,s3612,s3613,s3614,s3615,s3616,s941,s3617,s3618,s3620,s3621,s3622,s3623,s3489,s3511,s3624,s3625,s3626,s3627,s3558,s3581,s3628,s3629,s3630,s3631,s3632,s3633,s3634,s3635,s3636,s3637]) (hints := [6877,6877,7005,4563,4563,0,7005,4563,7005,6877,6877,1,4563,4563,5971,9834,6877,9962,5971,6877,5971,4563,4563,9962,7515,6877,7515,4563,4563,1710,6619,4563,7515,6619,6877,1710,4563,4563,7507,6877,6877,2,6611,6877,7507,4563,4563,3,4813,4813,4,4563,4563,5,4563,4563,6,4813,4813,7,8691,8691,13683,467,4563,4782,12787,4563,13683,8691,8691,4782,4563,4563,13651,499,8691,8878,12755,8691,13651,4563,4563,8878,9962,8,9962,5971,7005,5971,9962,7005,9962,5971,9,5971,1710,7005,1710,7259,10,7515,1710,11,1710,7005,7005,7515,4957,12,13,7005,7005,14,7507,15,7507,942,7005,16,942,15,17,4782,2877,4782,2909,7005,13683,4782,7005,4782,2877,2877,13683,8878,7005,8878,13651,18,13651,8878,19,8878,7005,7005,13651,8938,7003,7515,8938,9962,1710,9962,9962,7515,1710,7003,1710,9962,9962,7507,4955,7003,20,7507,7003,7507,9962,9962,21,9962,9962,22,5971,5971,23,5971,5971,24,9962,9962,25,9962,9962,12522,4782,5971,4782,12522,5971,12522,9962,9962,4782,1706,1706,13651,1770,9962,8878,9898,9962,13651,1706,1706,8878,1710,1710,26,7507,7515,7507,7499,7515,27,1710,1710,7507,1710,1710,28,7515,7515,29,7515,7515,30,1710,1710,31,1710,1710,4782,12522,7515,12522,4782,7515,4782,1710,1710,12522,1710,1710,8878,3451,11643,13651,8878,11643,8878,1710,1710,13651,2734,7507,16,2734,14,32,4782,11635,4782,3411,7507,14715,4782,7507,4782,11635,11635,14715,8878,7507,8878,3443,11635,14683,8878,11635,8878,7507,7507,14683,4782,33,4782,13683,34,13683,4782,35,4782,13683,36,13683,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651,4782,4782,8878,4330,12522,13651,8878,12522,8878,4782,4782,13651]) (by decide +kernel)
  change ∀ b ∈ [s3237,s3606,s3366,s3607,s3608,s3248,s3609,s3610,s3611,s3527,s3546,s3612,s3613,s3614,s3615,s3616,s941,s3617,s3618,s3620,s3621,s3622,s3623,s3489,s3511,s3624,s3625,s3626,s3627,s3558,s3581,s3628,s3629,s3630,s3631,s3632,s3633,s3634,s3635,s3636,s3637], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3237) b3237 <|
    PetersenLocalChildren.push (x := s3606) b3606 <|
    PetersenLocalChildren.push (x := s3366) b3366 <|
    PetersenLocalChildren.push (x := s3607) b3607 <|
    PetersenLocalChildren.push (x := s3608) b3608 <|
    PetersenLocalChildren.push (x := s3248) b3248 <|
    PetersenLocalChildren.push (x := s3609) b3609 <|
    PetersenLocalChildren.push (x := s3610) b3610 <|
    PetersenLocalChildren.push (x := s3611) b3611 <|
    PetersenLocalChildren.push (x := s3527) b3527 <|
    PetersenLocalChildren.push (x := s3546) b3546 <|
    PetersenLocalChildren.push (x := s3612) b3612 <|
    PetersenLocalChildren.push (x := s3613) b3613 <|
    PetersenLocalChildren.push (x := s3614) b3614 <|
    PetersenLocalChildren.push (x := s3615) b3615 <|
    PetersenLocalChildren.push (x := s3616) b3616 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3617) b3617 <|
    PetersenLocalChildren.push (x := s3618) b3618 <|
    PetersenLocalChildren.push (x := s3620) b3620 <|
    PetersenLocalChildren.push (x := s3621) b3621 <|
    PetersenLocalChildren.push (x := s3622) b3622 <|
    PetersenLocalChildren.push (x := s3623) b3623 <|
    PetersenLocalChildren.push (x := s3489) b3489 <|
    PetersenLocalChildren.push (x := s3511) b3511 <|
    PetersenLocalChildren.push (x := s3624) b3624 <|
    PetersenLocalChildren.push (x := s3625) b3625 <|
    PetersenLocalChildren.push (x := s3626) b3626 <|
    PetersenLocalChildren.push (x := s3627) b3627 <|
    PetersenLocalChildren.push (x := s3558) b3558 <|
    PetersenLocalChildren.push (x := s3581) b3581 <|
    PetersenLocalChildren.push (x := s3628) b3628 <|
    PetersenLocalChildren.push (x := s3629) b3629 <|
    PetersenLocalChildren.push (x := s3630) b3630 <|
    PetersenLocalChildren.push (x := s3631) b3631 <|
    PetersenLocalChildren.push (x := s3632) b3632 <|
    PetersenLocalChildren.push (x := s3633) b3633 <|
    PetersenLocalChildren.push (x := s3634) b3634 <|
    PetersenLocalChildren.push (x := s3635) b3635 <|
    PetersenLocalChildren.push (x := s3636) b3636 <|
    PetersenLocalChildren.push (x := s3637) b3637 <|
    PetersenLocalChildren.nil
theorem b3641 : Blocked tgt 8 s3641 := by
  apply PetersenFastNode.node (nxt := #[s3239,s3642,s3398,s3643,s3644,s3252,s3645,s3646,s3647,s3529,s3548,s3648,s3649,s3650,s3651,s3652,s941,s3653,s3654,s3655,s3656,s3657,s3658,s3493,s3515,s3659,s3660,s3562,s3585,s3661,s3662,s3631,s3663,s3664,s3665,s3666,s3667,s3668,s3669,s3670,s3671]) (hints := [6877,6877,7005,4307,4563,0,7005,4563,7005,6877,6877,1,4563,4563,5971,9834,6877,9962,5971,6877,5971,4563,4563,9962,7515,6877,7515,4563,4563,1710,6619,4563,7515,6619,6877,1710,4563,4563,7507,4829,6877,2734,6611,6877,7507,4563,4563,2734,8691,8691,13683,467,4563,2,12787,4563,13683,8691,8691,3,2749,2749,4,4563,4563,5,4563,4563,6,2749,2749,7,4563,4563,13651,499,8691,8878,12755,8691,13651,4563,4563,8878,9962,8,9962,5715,7005,5971,9962,7005,9962,5969,9,5971,1710,7005,1710,7259,10,7515,1710,11,1710,7005,7005,7515,2734,4941,2734,4957,7005,7507,2734,7005,2734,4941,4941,7507,2909,12,13,7005,7005,14,13683,15,13683,942,7005,16,942,15,17,8878,7005,8878,13395,18,13651,8878,19,8878,7005,7005,13651,8938,7003,7515,8938,9962,1710,9962,9962,7515,1710,7003,1710,9962,9962,10474,2734,7003,2734,10474,7003,10474,9962,9962,2734,9962,9962,13683,1875,5971,20,13683,5971,13683,9962,9962,21,9962,9962,22,5971,5971,23,5971,5971,24,9962,9962,25,1706,1706,13651,1770,9962,8878,9898,9962,13651,1706,1706,8878,1710,1710,2734,10474,7515,10474,2734,7515,2734,1710,1710,10474,1710,1710,14715,3419,7515,13683,14715,7515,14715,1710,1710,13683,1710,1710,26,7515,7515,27,7515,7515,28,1710,1710,29,1710,1710,8878,3451,11643,13651,8878,11643,8878,1710,1710,13651,2734,2734,13683,3411,7507,14715,13683,7507,13683,2734,2734,14715,2734,2734,30,7507,7507,31,7507,7507,32,2734,2734,33,2734,2734,8878,2282,10474,14683,8878,10474,8878,2734,2734,14683,4782,13683,16,4782,14,34,8878,35,8878,13651,13683,13651,8878,13683,8878,13619,36,13651,8878,37,8878,13651,38,13651,8878,39,8878,13651,40,13651]) (by decide +kernel)
  change ∀ b ∈ [s3239,s3642,s3398,s3643,s3644,s3252,s3645,s3646,s3647,s3529,s3548,s3648,s3649,s3650,s3651,s3652,s941,s3653,s3654,s3655,s3656,s3657,s3658,s3493,s3515,s3659,s3660,s3562,s3585,s3661,s3662,s3631,s3663,s3664,s3665,s3666,s3667,s3668,s3669,s3670,s3671], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3239) b3239 <|
    PetersenLocalChildren.push (x := s3642) b3642 <|
    PetersenLocalChildren.push (x := s3398) b3398 <|
    PetersenLocalChildren.push (x := s3643) b3643 <|
    PetersenLocalChildren.push (x := s3644) b3644 <|
    PetersenLocalChildren.push (x := s3252) b3252 <|
    PetersenLocalChildren.push (x := s3645) b3645 <|
    PetersenLocalChildren.push (x := s3646) b3646 <|
    PetersenLocalChildren.push (x := s3647) b3647 <|
    PetersenLocalChildren.push (x := s3529) b3529 <|
    PetersenLocalChildren.push (x := s3548) b3548 <|
    PetersenLocalChildren.push (x := s3648) b3648 <|
    PetersenLocalChildren.push (x := s3649) b3649 <|
    PetersenLocalChildren.push (x := s3650) b3650 <|
    PetersenLocalChildren.push (x := s3651) b3651 <|
    PetersenLocalChildren.push (x := s3652) b3652 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3653) b3653 <|
    PetersenLocalChildren.push (x := s3654) b3654 <|
    PetersenLocalChildren.push (x := s3655) b3655 <|
    PetersenLocalChildren.push (x := s3656) b3656 <|
    PetersenLocalChildren.push (x := s3657) b3657 <|
    PetersenLocalChildren.push (x := s3658) b3658 <|
    PetersenLocalChildren.push (x := s3493) b3493 <|
    PetersenLocalChildren.push (x := s3515) b3515 <|
    PetersenLocalChildren.push (x := s3659) b3659 <|
    PetersenLocalChildren.push (x := s3660) b3660 <|
    PetersenLocalChildren.push (x := s3562) b3562 <|
    PetersenLocalChildren.push (x := s3585) b3585 <|
    PetersenLocalChildren.push (x := s3661) b3661 <|
    PetersenLocalChildren.push (x := s3662) b3662 <|
    PetersenLocalChildren.push (x := s3631) b3631 <|
    PetersenLocalChildren.push (x := s3663) b3663 <|
    PetersenLocalChildren.push (x := s3664) b3664 <|
    PetersenLocalChildren.push (x := s3665) b3665 <|
    PetersenLocalChildren.push (x := s3666) b3666 <|
    PetersenLocalChildren.push (x := s3667) b3667 <|
    PetersenLocalChildren.push (x := s3668) b3668 <|
    PetersenLocalChildren.push (x := s3669) b3669 <|
    PetersenLocalChildren.push (x := s3670) b3670 <|
    PetersenLocalChildren.push (x := s3671) b3671 <|
    PetersenLocalChildren.nil
theorem b3675 : Blocked tgt 8 s3675 := by
  apply PetersenFastNode.node (nxt := #[s3676,s3677,s3434,s3678,s3679,s3256,s3680,s3681,s3480,s3683,s3684,s3595,s3618,s3685,s3654,s3686,s3687,s3688,s3689,s3690,s941,s3691,s3692,s3694,s3695,s3497,s3519,s3696,s3697,s3566,s3589,s3698,s3699,s3635,s3700,s3701,s3702,s3703,s3704,s3669,s3705,s3706,s3707]) (hints := [6879,6879,0,4565,4565,8684,4565,4565,1,6879,6879,8684,4565,4565,5973,9836,6879,9964,5973,6879,5973,4565,4565,9964,7517,6879,7517,4565,4565,1712,6621,4565,7517,6621,6879,1712,4565,4565,7509,4831,6879,2736,6613,6879,7509,4565,4565,2736,8693,8693,13685,469,4565,4784,12789,4565,13685,8693,8693,4784,4565,4565,13653,501,8693,2,12757,8693,13653,4565,4565,3,6879,6879,4,4565,4565,5,4565,4565,6,6879,6879,7,8684,8684,9964,5973,8,5973,9964,9,9964,8684,8684,5973,1712,10,1712,8684,8684,7517,1712,8684,1712,7517,11,7517,2736,8684,2736,7509,12,7509,2736,13,2736,8684,8684,7509,4784,8684,4784,13429,14,13685,4784,15,4784,8684,8684,13685,492,16,17,8684,8684,18,13653,19,13653,944,8684,20,944,19,21,8940,7005,7517,8940,9964,1712,9964,9964,7517,1712,7005,1712,9964,9964,10476,2736,7005,2736,10476,7005,10476,9964,9964,2736,9964,9964,12524,4784,5973,4784,12524,5973,12524,9964,9964,4784,1708,1708,13653,9964,9964,22,9964,9964,13653,1708,1708,23,1708,1708,24,9964,9964,25,9964,9964,26,1708,1708,27,1712,1712,2736,10476,7517,10476,2736,7517,2736,1712,1712,10476,1712,1712,4784,12524,7517,12524,4784,7517,4784,1712,1712,12524,1712,1712,14685,3453,11645,13653,14685,11645,14685,1712,1712,13653,1712,1712,28,7517,7517,29,7517,7517,30,1712,1712,31,2736,2736,4784,3413,7509,14717,4784,7509,4784,2736,2736,14717,2736,2736,13653,10476,10476,14685,10476,10476,13653,2736,2736,14685,2736,2736,32,10476,10476,33,10476,10476,34,2736,2736,35,4784,4784,36,12524,12524,13653,12524,12524,37,4784,4784,13653,4784,4784,38,12524,12524,39,12524,12524,40,4784,4784,41,8880,13653,20,8880,18,42]) (by decide +kernel)
  change ∀ b ∈ [s3676,s3677,s3434,s3678,s3679,s3256,s3680,s3681,s3480,s3683,s3684,s3595,s3618,s3685,s3654,s3686,s3687,s3688,s3689,s3690,s941,s3691,s3692,s3694,s3695,s3497,s3519,s3696,s3697,s3566,s3589,s3698,s3699,s3635,s3700,s3701,s3702,s3703,s3704,s3669,s3705,s3706,s3707], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3676) b3676 <|
    PetersenLocalChildren.push (x := s3677) b3677 <|
    PetersenLocalChildren.push (x := s3434) b3434 <|
    PetersenLocalChildren.push (x := s3678) b3678 <|
    PetersenLocalChildren.push (x := s3679) b3679 <|
    PetersenLocalChildren.push (x := s3256) b3256 <|
    PetersenLocalChildren.push (x := s3680) b3680 <|
    PetersenLocalChildren.push (x := s3681) b3681 <|
    PetersenLocalChildren.push (x := s3480) b3480 <|
    PetersenLocalChildren.push (x := s3683) b3683 <|
    PetersenLocalChildren.push (x := s3684) b3684 <|
    PetersenLocalChildren.push (x := s3595) b3595 <|
    PetersenLocalChildren.push (x := s3618) b3618 <|
    PetersenLocalChildren.push (x := s3685) b3685 <|
    PetersenLocalChildren.push (x := s3654) b3654 <|
    PetersenLocalChildren.push (x := s3686) b3686 <|
    PetersenLocalChildren.push (x := s3687) b3687 <|
    PetersenLocalChildren.push (x := s3688) b3688 <|
    PetersenLocalChildren.push (x := s3689) b3689 <|
    PetersenLocalChildren.push (x := s3690) b3690 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3691) b3691 <|
    PetersenLocalChildren.push (x := s3692) b3692 <|
    PetersenLocalChildren.push (x := s3694) b3694 <|
    PetersenLocalChildren.push (x := s3695) b3695 <|
    PetersenLocalChildren.push (x := s3497) b3497 <|
    PetersenLocalChildren.push (x := s3519) b3519 <|
    PetersenLocalChildren.push (x := s3696) b3696 <|
    PetersenLocalChildren.push (x := s3697) b3697 <|
    PetersenLocalChildren.push (x := s3566) b3566 <|
    PetersenLocalChildren.push (x := s3589) b3589 <|
    PetersenLocalChildren.push (x := s3698) b3698 <|
    PetersenLocalChildren.push (x := s3699) b3699 <|
    PetersenLocalChildren.push (x := s3635) b3635 <|
    PetersenLocalChildren.push (x := s3700) b3700 <|
    PetersenLocalChildren.push (x := s3701) b3701 <|
    PetersenLocalChildren.push (x := s3702) b3702 <|
    PetersenLocalChildren.push (x := s3703) b3703 <|
    PetersenLocalChildren.push (x := s3704) b3704 <|
    PetersenLocalChildren.push (x := s3669) b3669 <|
    PetersenLocalChildren.push (x := s3705) b3705 <|
    PetersenLocalChildren.push (x := s3706) b3706 <|
    PetersenLocalChildren.push (x := s3707) b3707 <|
    PetersenLocalChildren.nil
theorem b3711 : Blocked tgt 8 s3711 := by
  apply PetersenFastNode.node (nxt := #[s941,s3712,s3713,s3714,s3551,s3598,s3715,s3716,s3717,s3485,s3718,s3719,s3720,s3721,s3722,s2253,s2254,s3723,s3327,s3724,s3725,s2934,s3726,s3727,s3729,s3730,s3731,s3732,s3733,s3734,s3735,s3736,s3737,s3738,s3739,s3740,s3741,s3742,s3743,s3744]) (hints := [6876,6876,7004,813,4562,941,7004,4562,7004,6876,6876,941,4562,4562,5970,9833,6876,9961,5970,6876,5970,4562,4562,9961,6876,6876,7772,4562,4562,1709,4562,4562,7772,6876,6876,1709,4562,4562,0,1,2,3,4562,4562,7506,4828,6876,2733,6610,6876,7506,4562,4562,2733,8690,8690,13682,466,4562,4781,12786,4562,13682,8690,8690,4781,4562,4562,13650,498,8690,8877,12754,8690,13650,4562,4562,8877,8681,8681,9961,941,941,5970,9961,941,9961,8681,8681,5970,941,941,1709,8681,8681,4,1709,8681,1709,941,941,5,6,7,8,941,941,9,941,941,10,11,12,13,941,941,2733,4956,7004,7506,2733,7004,2733,941,941,7506,941,941,4781,2908,7004,13682,4781,7004,4781,941,941,13682,941,941,8877,489,8681,13650,8877,8681,8877,941,941,13650,8937,14,15,9961,9961,16,1709,17,1709,9961,9961,0,7002,17,18,9961,9961,10473,2733,19,2733,10473,20,10473,9961,9961,2733,9961,9961,12521,4781,5970,4781,12521,5970,12521,9961,9961,4781,1705,1705,13650,1769,9961,8877,9897,9961,13650,1705,1705,8877,1709,1709,0,7514,16,21,1709,1709,2733,10473,7772,10473,2733,7772,2733,1709,1709,10473,1709,1709,4781,12521,7772,12521,4781,7772,4781,1709,1709,12521,1709,1709,8877,13650,22,13650,8877,23,8877,1709,1709,13650,24,25,26,2733,27,2733,28,29,30,2733,31,2733,14714,32,14714,4781,33,4781,14714,34,14714,4781,35,4781,14682,36,14682,8877,37,8877,14682,38,14682,8877,39,8877,2733,2733,4781,3410,7506,14714,4781,7506,4781,2733,2733,14714,2733,2733,8877,2281,10473,14682,8877,10473,8877,2733,2733,14682,4781,4781,8877,4329,12521,13650,8877,12521,8877,4781,4781,13650]) (by decide +kernel)
  change ∀ b ∈ [s941,s3712,s3713,s3714,s3551,s3598,s3715,s3716,s3717,s3485,s3718,s3719,s3720,s3721,s3722,s2253,s2254,s3723,s3327,s3724,s3725,s2934,s3726,s3727,s3729,s3730,s3731,s3732,s3733,s3734,s3735,s3736,s3737,s3738,s3739,s3740,s3741,s3742,s3743,s3744], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3712) b3712 <|
    PetersenLocalChildren.push (x := s3713) b3713 <|
    PetersenLocalChildren.push (x := s3714) b3714 <|
    PetersenLocalChildren.push (x := s3551) b3551 <|
    PetersenLocalChildren.push (x := s3598) b3598 <|
    PetersenLocalChildren.push (x := s3715) b3715 <|
    PetersenLocalChildren.push (x := s3716) b3716 <|
    PetersenLocalChildren.push (x := s3717) b3717 <|
    PetersenLocalChildren.push (x := s3485) b3485 <|
    PetersenLocalChildren.push (x := s3718) b3718 <|
    PetersenLocalChildren.push (x := s3719) b3719 <|
    PetersenLocalChildren.push (x := s3720) b3720 <|
    PetersenLocalChildren.push (x := s3721) b3721 <|
    PetersenLocalChildren.push (x := s3722) b3722 <|
    PetersenLocalChildren.push (x := s2253) b2253 <|
    PetersenLocalChildren.push (x := s2254) b2254 <|
    PetersenLocalChildren.push (x := s3723) b3723 <|
    PetersenLocalChildren.push (x := s3327) b3327 <|
    PetersenLocalChildren.push (x := s3724) b3724 <|
    PetersenLocalChildren.push (x := s3725) b3725 <|
    PetersenLocalChildren.push (x := s2934) b2934 <|
    PetersenLocalChildren.push (x := s3726) b3726 <|
    PetersenLocalChildren.push (x := s3727) b3727 <|
    PetersenLocalChildren.push (x := s3729) b3729 <|
    PetersenLocalChildren.push (x := s3730) b3730 <|
    PetersenLocalChildren.push (x := s3731) b3731 <|
    PetersenLocalChildren.push (x := s3732) b3732 <|
    PetersenLocalChildren.push (x := s3733) b3733 <|
    PetersenLocalChildren.push (x := s3734) b3734 <|
    PetersenLocalChildren.push (x := s3735) b3735 <|
    PetersenLocalChildren.push (x := s3736) b3736 <|
    PetersenLocalChildren.push (x := s3737) b3737 <|
    PetersenLocalChildren.push (x := s3738) b3738 <|
    PetersenLocalChildren.push (x := s3739) b3739 <|
    PetersenLocalChildren.push (x := s3740) b3740 <|
    PetersenLocalChildren.push (x := s3741) b3741 <|
    PetersenLocalChildren.push (x := s3742) b3742 <|
    PetersenLocalChildren.push (x := s3743) b3743 <|
    PetersenLocalChildren.push (x := s3744) b3744 <|
    PetersenLocalChildren.nil
theorem b3919 : Blocked tgt 8 s3919 := by
  apply PetersenFastNode.node (nxt := #[s3920,s2945,s3921,s3922,s3692,s3923,s3924,s3497,s3925,s3926,s3871,s3915,s3927,s3928,s3929,s3930,s941,s3931,s3932,s3933,s3934,s3742,s3788,s3935,s3936,s3826,s3937,s3938,s3939,s3888,s3940,s3941,s3942]) (hints := [6869,6869,6997,806,4555,934,6997,4555,6997,6869,6869,934,4555,4555,10091,9826,6869,9954,10091,6869,10091,4555,4555,9954,7507,6869,7507,4555,4555,1702,6611,4555,7507,6611,6869,1702,4555,4555,7499,4821,6869,2726,6603,6869,7499,4555,4555,2726,8683,8683,13675,459,4555,4774,12779,4555,13675,8683,8683,4774,4555,4555,14933,8683,8683,8870,8683,8683,14933,4555,4555,8870,4555,4555,0,8683,8683,1,8683,8683,2,4555,4555,3,8674,8674,9954,934,934,10091,9954,934,9954,8674,8674,10091,934,934,1702,8674,8674,7507,1702,8674,1702,934,934,7507,934,934,2726,4949,6997,7499,2726,6997,2726,934,934,7499,934,934,4774,2901,6997,13675,4774,6997,4774,934,934,13675,934,934,8870,8674,8674,4,8870,8674,8870,934,934,5,418,418,6,934,934,7,934,934,8,418,418,9,8930,11123,7507,8930,9954,1702,9954,9954,7507,1702,11123,1702,9954,9954,10466,2726,11123,2726,10466,11123,10466,9954,9954,2726,9954,9954,12514,4774,10,4774,12514,11,12514,9954,9954,4774,1762,12,13,9954,9954,14,8870,15,8870,9954,9954,16,1698,15,17,1702,1702,2726,10466,7507,10466,2726,7507,2726,1702,1702,10466,1702,1702,4774,12514,7507,12514,4774,7507,4774,1702,1702,12514,1702,1702,8870,11635,11635,18,8870,11635,8870,1702,1702,19,7507,7507,20,1702,1702,21,1702,1702,22,7507,7507,23,2726,2726,4774,3403,7499,14707,4774,7499,4774,2726,2726,14707,2726,2726,8870,10466,10466,14933,8870,10466,8870,2726,2726,14933,2210,2210,24,2726,2726,25,2726,2726,26,2210,2210,27,4774,4774,8870,12514,12514,14933,8870,12514,8870,4774,4774,14933,4258,4258,28,4774,4774,29,4774,4774,30,4258,4258,31,8870,8870,16,13643,14,32]) (by decide +kernel)
  change ∀ b ∈ [s3920,s2945,s3921,s3922,s3692,s3923,s3924,s3497,s3925,s3926,s3871,s3915,s3927,s3928,s3929,s3930,s941,s3931,s3932,s3933,s3934,s3742,s3788,s3935,s3936,s3826,s3937,s3938,s3939,s3888,s3940,s3941,s3942], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3920) b3920 <|
    PetersenLocalChildren.push (x := s2945) b2945 <|
    PetersenLocalChildren.push (x := s3921) b3921 <|
    PetersenLocalChildren.push (x := s3922) b3922 <|
    PetersenLocalChildren.push (x := s3692) b3692 <|
    PetersenLocalChildren.push (x := s3923) b3923 <|
    PetersenLocalChildren.push (x := s3924) b3924 <|
    PetersenLocalChildren.push (x := s3497) b3497 <|
    PetersenLocalChildren.push (x := s3925) b3925 <|
    PetersenLocalChildren.push (x := s3926) b3926 <|
    PetersenLocalChildren.push (x := s3871) b3871 <|
    PetersenLocalChildren.push (x := s3915) b3915 <|
    PetersenLocalChildren.push (x := s3927) b3927 <|
    PetersenLocalChildren.push (x := s3928) b3928 <|
    PetersenLocalChildren.push (x := s3929) b3929 <|
    PetersenLocalChildren.push (x := s3930) b3930 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s3931) b3931 <|
    PetersenLocalChildren.push (x := s3932) b3932 <|
    PetersenLocalChildren.push (x := s3933) b3933 <|
    PetersenLocalChildren.push (x := s3934) b3934 <|
    PetersenLocalChildren.push (x := s3742) b3742 <|
    PetersenLocalChildren.push (x := s3788) b3788 <|
    PetersenLocalChildren.push (x := s3935) b3935 <|
    PetersenLocalChildren.push (x := s3936) b3936 <|
    PetersenLocalChildren.push (x := s3826) b3826 <|
    PetersenLocalChildren.push (x := s3937) b3937 <|
    PetersenLocalChildren.push (x := s3938) b3938 <|
    PetersenLocalChildren.push (x := s3939) b3939 <|
    PetersenLocalChildren.push (x := s3888) b3888 <|
    PetersenLocalChildren.push (x := s3940) b3940 <|
    PetersenLocalChildren.push (x := s3941) b3941 <|
    PetersenLocalChildren.push (x := s3942) b3942 <|
    PetersenLocalChildren.nil
theorem b4055 : Blocked tgt 8 s4055 := by
  apply PetersenFastNode.node (nxt := #[s4056,s4057,s3406,s4058,s4059,s4060,s3585,s4061,s3902,s4062,s3784,s4065,s941,s4066,s4067,s4068,s4069,s4008,s4070,s4071,s4040,s4072,s4073,s4076,s4077,s4078,s4079,s4080,s4081,s3332,s4082,s4083,s4084,s4085,s4086]) (hints := [4557,0,4557,8685,1,8685,4557,2,4557,8685,3,8685,936,4,936,8676,5,8676,936,6,936,8676,7,8676,5965,8,5965,9956,9,9956,5965,10,5965,9956,11,9956,1704,12,7509,1704,13,14,2728,15,2728,10468,16,10468,2728,17,2728,10468,18,10468,4776,12,4776,12516,19,20,8872,21,8872,22,23,24,8872,25,8872,26,27,28,6871,6871,6999,8676,8685,8676,8683,8685,6999,8676,6871,8676,8685,8685,10093,9828,6871,9956,10093,6871,10093,8685,8685,9956,7509,6871,7509,8685,8685,29,8685,8685,7509,6613,6871,30,8685,8685,11629,10468,6871,10468,10733,6871,11629,8685,8685,10468,8685,8685,14709,4557,4557,4776,4557,4557,14709,8685,8685,4776,429,429,13645,493,8685,8872,8621,8685,13645,429,429,8872,8676,8676,9956,9837,936,10093,9956,936,9956,8676,8676,10093,936,936,7767,8676,8676,7509,8676,8676,7767,936,936,7509,8676,8676,10468,11373,6999,11629,10468,6999,10468,8676,8676,11629,8676,8676,4776,2903,6999,14709,4776,6999,4776,8676,8676,14709,420,420,8872,484,8676,13645,8612,8676,8872,420,420,13645,6997,6997,7509,9956,9956,7767,9956,9956,7509,6997,6997,7767,9956,9956,10468,2728,6997,2728,10468,6997,10468,9956,9956,2728,9956,9956,14709,4776,5965,4776,5965,5965,14709,9956,9956,4776,1700,1700,13645,1764,9956,8872,9892,9956,13645,1700,1700,8872,2728,5703,2728,10468,7509,10468,2728,7509,2728,10468,5703,10468,4776,14,4776,7509,7509,20,5800,31,32,8872,7509,8872,12621,33,13645,8872,34,8872,7509,7509,13645,10468,10468,4776,7501,7501,14709,4776,7501,4776,10468,10468,14709,2212,2212,8872,2276,10468,14677,10404,10468,8872,2212,2212,14677,4776,4776,8872,13645,14709,13645,8872,14709,8872,4776,4776,13645]) (by decide +kernel)
  change ∀ b ∈ [s4056,s4057,s3406,s4058,s4059,s4060,s3585,s4061,s3902,s4062,s3784,s4065,s941,s4066,s4067,s4068,s4069,s4008,s4070,s4071,s4040,s4072,s4073,s4076,s4077,s4078,s4079,s4080,s4081,s3332,s4082,s4083,s4084,s4085,s4086], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4056) b4056 <|
    PetersenLocalChildren.push (x := s4057) b4057 <|
    PetersenLocalChildren.push (x := s3406) b3406 <|
    PetersenLocalChildren.push (x := s4058) b4058 <|
    PetersenLocalChildren.push (x := s4059) b4059 <|
    PetersenLocalChildren.push (x := s4060) b4060 <|
    PetersenLocalChildren.push (x := s3585) b3585 <|
    PetersenLocalChildren.push (x := s4061) b4061 <|
    PetersenLocalChildren.push (x := s3902) b3902 <|
    PetersenLocalChildren.push (x := s4062) b4062 <|
    PetersenLocalChildren.push (x := s3784) b3784 <|
    PetersenLocalChildren.push (x := s4065) b4065 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4066) b4066 <|
    PetersenLocalChildren.push (x := s4067) b4067 <|
    PetersenLocalChildren.push (x := s4068) b4068 <|
    PetersenLocalChildren.push (x := s4069) b4069 <|
    PetersenLocalChildren.push (x := s4008) b4008 <|
    PetersenLocalChildren.push (x := s4070) b4070 <|
    PetersenLocalChildren.push (x := s4071) b4071 <|
    PetersenLocalChildren.push (x := s4040) b4040 <|
    PetersenLocalChildren.push (x := s4072) b4072 <|
    PetersenLocalChildren.push (x := s4073) b4073 <|
    PetersenLocalChildren.push (x := s4076) b4076 <|
    PetersenLocalChildren.push (x := s4077) b4077 <|
    PetersenLocalChildren.push (x := s4078) b4078 <|
    PetersenLocalChildren.push (x := s4079) b4079 <|
    PetersenLocalChildren.push (x := s4080) b4080 <|
    PetersenLocalChildren.push (x := s4081) b4081 <|
    PetersenLocalChildren.push (x := s3332) b3332 <|
    PetersenLocalChildren.push (x := s4082) b4082 <|
    PetersenLocalChildren.push (x := s4083) b4083 <|
    PetersenLocalChildren.push (x := s4084) b4084 <|
    PetersenLocalChildren.push (x := s4085) b4085 <|
    PetersenLocalChildren.push (x := s4086) b4086 <|
    PetersenLocalChildren.nil
theorem b4089 : Blocked tgt 8 s4089 := by
  apply PetersenFastNode.node (nxt := #[s3333,s4090,s3446,s4091,s4092,s3348,s4093,s4094,s4097,s3566,s4098,s4099,s3726,s3790,s3932,s4100,s4101,s3742,s3763,s4102,s4103,s4104,s4043,s4085,s4105,s4106,s4107,s4108,s941,s4109,s4110,s4111,s4112,s3991,s4113,s4114,s4115,s4116,s4117,s4052,s4118,s4119,s4120]) (hints := [6879,6879,7007,816,4565,944,7007,4565,7007,6879,6879,944,4565,4565,5973,9836,6879,9964,5973,6879,5973,4565,4565,9964,11645,6879,11645,4565,4565,0,10749,4565,11645,10749,6879,1,4565,4565,7509,4831,6879,2736,6613,6879,7509,4565,4565,2736,8693,8693,13685,469,4565,4784,12789,4565,13685,8693,8693,4784,4565,4565,13653,501,8693,2,12757,8693,13653,4565,4565,3,6879,6879,4,4565,4565,5,4565,4565,6,6879,6879,7,8684,8684,9964,944,944,5973,9964,944,9964,8684,8684,5973,944,944,11387,8684,8684,11645,8684,8684,11387,944,944,11645,944,944,2736,4959,7007,7509,2736,7007,2736,944,944,7509,944,944,4784,2911,7007,13685,4784,7007,4784,944,944,13685,944,944,13395,492,8684,13653,8620,8684,13395,944,944,13653,944,944,8,8684,8684,9,8684,8684,10,944,944,11,8940,7005,11645,8940,9964,12,9964,9964,11645,7005,7005,13,9964,9964,10476,2736,7005,2736,10476,7005,10476,9964,9964,2736,9964,9964,12524,4784,5973,4784,12524,5973,12524,9964,9964,4784,1708,1708,13653,1772,9964,14,9900,9964,13653,1708,1708,15,7005,7005,16,9964,9964,17,9964,9964,18,7005,7005,19,2736,20,2736,10476,11645,10476,2736,11645,2736,10476,21,10476,4784,11645,4784,12524,22,12524,4784,23,4784,12524,11645,12524,3453,24,25,11645,11645,26,13653,27,13653,1712,11645,28,1712,27,29,2736,2736,4784,3413,7509,14717,4784,7509,4784,2736,2736,14717,2736,2736,13653,2284,10476,30,10412,10476,13653,2736,2736,31,2736,2736,32,10476,10476,33,10476,10476,34,2736,2736,35,4784,4784,36,4332,12524,13653,12460,12524,37,4784,4784,13653,4784,4784,38,12524,12524,39,12524,12524,40,4784,4784,41,8880,13653,28,8880,26,42]) (by decide +kernel)
  change ∀ b ∈ [s3333,s4090,s3446,s4091,s4092,s3348,s4093,s4094,s4097,s3566,s4098,s4099,s3726,s3790,s3932,s4100,s4101,s3742,s3763,s4102,s4103,s4104,s4043,s4085,s4105,s4106,s4107,s4108,s941,s4109,s4110,s4111,s4112,s3991,s4113,s4114,s4115,s4116,s4117,s4052,s4118,s4119,s4120], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3333) b3333 <|
    PetersenLocalChildren.push (x := s4090) b4090 <|
    PetersenLocalChildren.push (x := s3446) b3446 <|
    PetersenLocalChildren.push (x := s4091) b4091 <|
    PetersenLocalChildren.push (x := s4092) b4092 <|
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s4093) b4093 <|
    PetersenLocalChildren.push (x := s4094) b4094 <|
    PetersenLocalChildren.push (x := s4097) b4097 <|
    PetersenLocalChildren.push (x := s3566) b3566 <|
    PetersenLocalChildren.push (x := s4098) b4098 <|
    PetersenLocalChildren.push (x := s4099) b4099 <|
    PetersenLocalChildren.push (x := s3726) b3726 <|
    PetersenLocalChildren.push (x := s3790) b3790 <|
    PetersenLocalChildren.push (x := s3932) b3932 <|
    PetersenLocalChildren.push (x := s4100) b4100 <|
    PetersenLocalChildren.push (x := s4101) b4101 <|
    PetersenLocalChildren.push (x := s3742) b3742 <|
    PetersenLocalChildren.push (x := s3763) b3763 <|
    PetersenLocalChildren.push (x := s4102) b4102 <|
    PetersenLocalChildren.push (x := s4103) b4103 <|
    PetersenLocalChildren.push (x := s4104) b4104 <|
    PetersenLocalChildren.push (x := s4043) b4043 <|
    PetersenLocalChildren.push (x := s4085) b4085 <|
    PetersenLocalChildren.push (x := s4105) b4105 <|
    PetersenLocalChildren.push (x := s4106) b4106 <|
    PetersenLocalChildren.push (x := s4107) b4107 <|
    PetersenLocalChildren.push (x := s4108) b4108 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4109) b4109 <|
    PetersenLocalChildren.push (x := s4110) b4110 <|
    PetersenLocalChildren.push (x := s4111) b4111 <|
    PetersenLocalChildren.push (x := s4112) b4112 <|
    PetersenLocalChildren.push (x := s3991) b3991 <|
    PetersenLocalChildren.push (x := s4113) b4113 <|
    PetersenLocalChildren.push (x := s4114) b4114 <|
    PetersenLocalChildren.push (x := s4115) b4115 <|
    PetersenLocalChildren.push (x := s4116) b4116 <|
    PetersenLocalChildren.push (x := s4117) b4117 <|
    PetersenLocalChildren.push (x := s4052) b4052 <|
    PetersenLocalChildren.push (x := s4118) b4118 <|
    PetersenLocalChildren.push (x := s4119) b4119 <|
    PetersenLocalChildren.push (x := s4120) b4120 <|
    PetersenLocalChildren.nil
theorem b4121 : Blocked tgt 8 s4121 := by
  apply PetersenFastNode.node (nxt := #[s4122,s4123,s3451,s4124,s4125,s4126,s3589,s4127,s3952,s4128,s3788,s4129,s941,s4130,s4131,s4132,s4133,s4012,s4134,s4135,s4136,s4078,s4137,s4138,s4107,s3334,s4139,s3727,s3791,s4140,s4141,s4044,s4086,s4142,s4143]) (hints := [8685,0,8685,4557,1,4557,8685,2,8685,4557,3,4557,936,4,936,420,5,420,936,6,936,420,7,420,9956,8,9956,1700,9,1700,9956,10,9956,1700,11,1700,1704,12,11637,1704,13,14,2728,15,2728,2212,16,2212,2728,17,2728,2212,18,2212,4776,19,4776,4260,20,4260,4776,21,4776,4260,22,4260,8872,12,8872,13645,23,24,4299,4299,6999,4301,4557,420,4555,4557,6999,4299,4299,420,4557,4557,5965,1572,6871,1700,5965,6871,5965,4557,4557,1700,11637,6871,11637,4557,4557,25,4557,4557,11637,10741,6871,26,4557,4557,7501,2212,6871,2212,6605,6871,7501,4557,4557,2212,429,429,13677,461,4557,4260,4525,4557,13677,429,429,4260,4557,4557,14677,8685,8685,8872,8685,8685,14677,4557,4557,8872,420,420,1700,5709,936,5965,1700,936,1700,420,420,5965,936,936,11379,420,420,11637,420,420,11379,936,936,11637,420,420,2212,7245,6999,7501,2212,6999,2212,420,420,7501,420,420,4260,2903,6999,13677,4260,6999,4260,420,420,13677,420,420,8872,8676,8676,14677,8872,8676,8872,420,420,14677,8932,6997,11637,1700,1700,27,1700,1700,11637,6997,6997,28,1700,1700,2212,2728,6997,2728,2212,6997,2212,1700,1700,2728,1700,1700,4260,1869,5965,4776,4260,5965,4260,1700,1700,4776,1700,1700,14677,9956,9956,8872,9956,9956,14677,1700,1700,8872,2728,29,2728,2212,11637,2212,2728,11637,2728,2212,30,2212,4776,11637,4776,4260,31,4260,4776,32,4776,4260,11637,4260,8872,14,8872,11637,11637,24,9896,33,34,2212,2212,4260,3405,7501,14709,4260,7501,4260,2212,2212,14709,2212,2212,8872,10468,10468,14677,8872,10468,8872,2212,2212,14677,4260,4260,8872,12516,12516,14677,8872,12516,8872,4260,4260,14677]) (by decide +kernel)
  change ∀ b ∈ [s4122,s4123,s3451,s4124,s4125,s4126,s3589,s4127,s3952,s4128,s3788,s4129,s941,s4130,s4131,s4132,s4133,s4012,s4134,s4135,s4136,s4078,s4137,s4138,s4107,s3334,s4139,s3727,s3791,s4140,s4141,s4044,s4086,s4142,s4143], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4122) b4122 <|
    PetersenLocalChildren.push (x := s4123) b4123 <|
    PetersenLocalChildren.push (x := s3451) b3451 <|
    PetersenLocalChildren.push (x := s4124) b4124 <|
    PetersenLocalChildren.push (x := s4125) b4125 <|
    PetersenLocalChildren.push (x := s4126) b4126 <|
    PetersenLocalChildren.push (x := s3589) b3589 <|
    PetersenLocalChildren.push (x := s4127) b4127 <|
    PetersenLocalChildren.push (x := s3952) b3952 <|
    PetersenLocalChildren.push (x := s4128) b4128 <|
    PetersenLocalChildren.push (x := s3788) b3788 <|
    PetersenLocalChildren.push (x := s4129) b4129 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4130) b4130 <|
    PetersenLocalChildren.push (x := s4131) b4131 <|
    PetersenLocalChildren.push (x := s4132) b4132 <|
    PetersenLocalChildren.push (x := s4133) b4133 <|
    PetersenLocalChildren.push (x := s4012) b4012 <|
    PetersenLocalChildren.push (x := s4134) b4134 <|
    PetersenLocalChildren.push (x := s4135) b4135 <|
    PetersenLocalChildren.push (x := s4136) b4136 <|
    PetersenLocalChildren.push (x := s4078) b4078 <|
    PetersenLocalChildren.push (x := s4137) b4137 <|
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s4107) b4107 <|
    PetersenLocalChildren.push (x := s3334) b3334 <|
    PetersenLocalChildren.push (x := s4139) b4139 <|
    PetersenLocalChildren.push (x := s3727) b3727 <|
    PetersenLocalChildren.push (x := s3791) b3791 <|
    PetersenLocalChildren.push (x := s4140) b4140 <|
    PetersenLocalChildren.push (x := s4141) b4141 <|
    PetersenLocalChildren.push (x := s4044) b4044 <|
    PetersenLocalChildren.push (x := s4086) b4086 <|
    PetersenLocalChildren.push (x := s4142) b4142 <|
    PetersenLocalChildren.push (x := s4143) b4143 <|
    PetersenLocalChildren.nil
theorem b4146 : Blocked tgt 8 s4146 := by
  apply PetersenFastNode.node (nxt := #[s3377,s4147,s3408,s4148,s4149,s3380,s4150,s4151,s4152,s3631,s4153,s4154,s3817,s4155,s3877,s4156,s4157,s3822,s3844,s4158,s4161,s4021,s4045,s4162,s4163,s3987,s4008,s4164,s4165,s4166,s4167,s4168,s941,s4169,s4170,s4171,s4172,s4173,s4174,s4175,s4176,s4177,s4178]) (hints := [6879,6879,7007,816,4565,944,7007,4565,7007,6879,6879,944,4565,4565,5973,9836,6879,9964,5973,6879,5973,4565,4565,9964,7517,6879,7517,4565,4565,1712,6621,4565,7517,6621,6879,1712,4565,4565,7509,4831,6879,0,6613,6879,7509,4565,4565,1,8693,8693,14717,4565,4565,2,4565,4565,14717,8693,8693,3,8693,8693,4,4565,4565,5,4565,4565,6,8693,8693,7,4565,4565,13653,501,8693,8880,12757,8693,13653,4565,4565,8880,8684,8684,9964,944,944,5973,9964,944,9964,8684,8684,5973,944,944,1712,8684,8684,7517,1712,8684,1712,944,944,7517,944,944,7251,4959,7007,7509,6991,7007,7251,944,944,7509,944,944,14459,2911,7007,14717,6975,7007,14459,944,944,14717,944,944,8,7007,7007,9,7007,7007,10,944,944,11,944,944,8880,492,8684,13653,8880,8684,8880,944,944,13653,8940,7005,7517,8940,9964,1712,9964,9964,7517,1712,7005,1712,9964,9964,7509,4957,7005,12,7509,7005,7509,9964,9964,13,9964,9964,14717,5973,5973,14,5973,5973,14717,9964,9964,15,9964,9964,16,5973,5973,17,5973,5973,18,9964,9964,19,1708,1708,13653,1772,9964,8880,9900,9964,13653,1708,1708,8880,1712,1712,20,7509,7517,7509,7501,7517,21,1712,1712,7509,1712,1712,14717,3421,7517,22,14717,7517,14717,1712,1712,23,1712,1712,24,7517,7517,25,7517,7517,26,1712,1712,27,1712,1712,8880,3453,11645,13653,8880,11645,8880,1712,1712,13653,3413,28,29,7509,7509,30,14717,31,14717,2736,7509,32,2736,31,33,8880,7509,8880,12637,34,14685,8880,35,8880,7509,7509,14685,4784,14717,32,4784,30,36,8880,37,8880,13653,14717,13653,8880,14717,8880,13653,38,13653,8880,39,8880,13653,40,13653,8880,41,8880,13653,42,13653]) (by decide +kernel)
  change ∀ b ∈ [s3377,s4147,s3408,s4148,s4149,s3380,s4150,s4151,s4152,s3631,s4153,s4154,s3817,s4155,s3877,s4156,s4157,s3822,s3844,s4158,s4161,s4021,s4045,s4162,s4163,s3987,s4008,s4164,s4165,s4166,s4167,s4168,s941,s4169,s4170,s4171,s4172,s4173,s4174,s4175,s4176,s4177,s4178], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3377) b3377 <|
    PetersenLocalChildren.push (x := s4147) b4147 <|
    PetersenLocalChildren.push (x := s3408) b3408 <|
    PetersenLocalChildren.push (x := s4148) b4148 <|
    PetersenLocalChildren.push (x := s4149) b4149 <|
    PetersenLocalChildren.push (x := s3380) b3380 <|
    PetersenLocalChildren.push (x := s4150) b4150 <|
    PetersenLocalChildren.push (x := s4151) b4151 <|
    PetersenLocalChildren.push (x := s4152) b4152 <|
    PetersenLocalChildren.push (x := s3631) b3631 <|
    PetersenLocalChildren.push (x := s4153) b4153 <|
    PetersenLocalChildren.push (x := s4154) b4154 <|
    PetersenLocalChildren.push (x := s3817) b3817 <|
    PetersenLocalChildren.push (x := s4155) b4155 <|
    PetersenLocalChildren.push (x := s3877) b3877 <|
    PetersenLocalChildren.push (x := s4156) b4156 <|
    PetersenLocalChildren.push (x := s4157) b4157 <|
    PetersenLocalChildren.push (x := s3822) b3822 <|
    PetersenLocalChildren.push (x := s3844) b3844 <|
    PetersenLocalChildren.push (x := s4158) b4158 <|
    PetersenLocalChildren.push (x := s4161) b4161 <|
    PetersenLocalChildren.push (x := s4021) b4021 <|
    PetersenLocalChildren.push (x := s4045) b4045 <|
    PetersenLocalChildren.push (x := s4162) b4162 <|
    PetersenLocalChildren.push (x := s4163) b4163 <|
    PetersenLocalChildren.push (x := s3987) b3987 <|
    PetersenLocalChildren.push (x := s4008) b4008 <|
    PetersenLocalChildren.push (x := s4164) b4164 <|
    PetersenLocalChildren.push (x := s4165) b4165 <|
    PetersenLocalChildren.push (x := s4166) b4166 <|
    PetersenLocalChildren.push (x := s4167) b4167 <|
    PetersenLocalChildren.push (x := s4168) b4168 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4169) b4169 <|
    PetersenLocalChildren.push (x := s4170) b4170 <|
    PetersenLocalChildren.push (x := s4171) b4171 <|
    PetersenLocalChildren.push (x := s4172) b4172 <|
    PetersenLocalChildren.push (x := s4173) b4173 <|
    PetersenLocalChildren.push (x := s4174) b4174 <|
    PetersenLocalChildren.push (x := s4175) b4175 <|
    PetersenLocalChildren.push (x := s4176) b4176 <|
    PetersenLocalChildren.push (x := s4177) b4177 <|
    PetersenLocalChildren.push (x := s4178) b4178 <|
    PetersenLocalChildren.nil
theorem b4253 : Blocked tgt 8 s4253 := by
  apply PetersenFastNode.node (nxt := #[s3426,s4254,s4255,s4258,s4259,s3348,s3451,s4260,s4261,s4262,s4263,s4264,s4265,s4266,s4267,s4268]) (hints := [6980,917,6980,917,5946,9817,5946,9690,8666,8666,9690,0,1,9690,9690,10722,7482,2709,7482,9690,9690,4757,13658,9690,1498,9690,8853,5562,5562,9689,917,9945,9689,917,8665,9681,917,917,9689,9689,917,917,4932,2709,917,917,2884,4757,917,917,1497,8853,917,6980,917,917,6980,6978,9945,9937,9937,8913,9945,9945,6978,9945,2709,11481,9945,9945,4757,13529,9945,1689,1753,9881,1689,5946,9945,9945,5946,1685,1685,2709,10457,2709,11473,4757,12505,4757,13521,8853,2,8853,3,4,5,6,7,2709,11481,2709,11481,4757,13529,4757,13529,8853,8,8853,9,10,11,12,13,2709,3386,4757,2709,2709,3289,8853,2709,7482,2709,2709,7482,4757,5337,8853,4757,14,4757,4757,15,8853,13626]) (by decide +kernel)
  change ∀ b ∈ [s3426,s4254,s4255,s4258,s4259,s3348,s3451,s4260,s4261,s4262,s4263,s4264,s4265,s4266,s4267,s4268], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3426) b3426 <|
    PetersenLocalChildren.push (x := s4254) b4254 <|
    PetersenLocalChildren.push (x := s4255) b4255 <|
    PetersenLocalChildren.push (x := s4258) b4258 <|
    PetersenLocalChildren.push (x := s4259) b4259 <|
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s3451) b3451 <|
    PetersenLocalChildren.push (x := s4260) b4260 <|
    PetersenLocalChildren.push (x := s4261) b4261 <|
    PetersenLocalChildren.push (x := s4262) b4262 <|
    PetersenLocalChildren.push (x := s4263) b4263 <|
    PetersenLocalChildren.push (x := s4264) b4264 <|
    PetersenLocalChildren.push (x := s4265) b4265 <|
    PetersenLocalChildren.push (x := s4266) b4266 <|
    PetersenLocalChildren.push (x := s4267) b4267 <|
    PetersenLocalChildren.push (x := s4268) b4268 <|
    PetersenLocalChildren.nil
theorem b4287 : Blocked tgt 8 s4287 := by
  apply PetersenFastNode.node (nxt := #[s4288,s4289,s4290,s4291,s4292,s3244,s4293,s3538,s4273,s4294,s4295,s4296,s4297,s4298,s941,s4299,s4300,s4301,s4302,s4303,s4305,s2244,s4306,s3553,s4277,s3507,s4307,s4308,s4309,s4310,s957,s4311,s958,s4312,s4313,s4314,s4315,s4316,s4317,s4318,s4319,s4320,s4321,s4322,s4323,s4324,s4325]) (hints := [6883,6883,0,4569,4569,8696,4567,4569,1,6883,6883,8696,4569,4569,5977,9848,6883,9976,5977,6883,5977,4569,4569,9976,7521,6883,7521,4569,4569,2,6625,4569,7521,6625,6883,3,6883,6883,4,4569,4569,5,4569,4569,6,6883,6883,7,4569,4569,7513,4835,6883,2740,6617,6883,7513,4569,4569,2740,8697,8697,13689,473,4569,4788,12793,4569,13689,8697,8697,4788,4569,4569,13657,505,8697,8884,12761,8697,13657,4569,4569,8884,8696,8696,9976,5721,8,5977,9976,9,9976,8696,8696,5977,7265,10,11,8696,8696,7521,8696,8696,12,7521,13,7521,948,8696,14,948,15,16,2740,8696,2740,7257,17,7513,2740,18,2740,8696,8696,7513,4788,8696,4788,13433,19,13689,4788,20,4788,8696,8696,13689,8884,440,8884,504,8696,13657,8884,8696,8884,440,440,13657,8944,7009,7521,9976,9976,21,9976,9976,7521,7009,7009,22,10879,10879,23,9976,9976,24,9968,9976,25,9968,10879,26,9976,9976,11512,2740,7009,2740,11512,7009,11512,9976,9976,2740,9976,9976,13560,4788,5977,4788,13560,5977,13560,9976,9976,4788,1720,1720,13657,1784,9976,8884,9912,9976,13657,1720,1720,8884,27,28,29,7521,7521,30,1716,7521,31,1716,12,32,2740,33,2740,11512,7521,11512,2740,7521,2740,11512,34,11512,4788,11649,4788,13560,7521,13560,4788,7521,4788,13560,11649,13560,8884,7521,8884,3457,11649,13657,8884,11649,8884,7521,7521,13657,2740,35,2740,10488,36,11512,2740,37,2740,11504,38,11512,4788,39,4788,12536,40,13560,4788,41,4788,13552,42,13560,8884,43,8884,13657,44,13657,8884,45,8884,13657,46,13657,2740,2740,4788,3417,7513,14721,4788,7513,4788,2740,2740,14721,2740,2740,8884,3320,11512,14689,8884,11512,8884,2740,2740,14689,4788,4788,8884,5368,13560,13657,8884,13560,8884,4788,4788,13657]) (by decide +kernel)
  change ∀ b ∈ [s4288,s4289,s4290,s4291,s4292,s3244,s4293,s3538,s4273,s4294,s4295,s4296,s4297,s4298,s941,s4299,s4300,s4301,s4302,s4303,s4305,s2244,s4306,s3553,s4277,s3507,s4307,s4308,s4309,s4310,s957,s4311,s958,s4312,s4313,s4314,s4315,s4316,s4317,s4318,s4319,s4320,s4321,s4322,s4323,s4324,s4325], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4288) b4288 <|
    PetersenLocalChildren.push (x := s4289) b4289 <|
    PetersenLocalChildren.push (x := s4290) b4290 <|
    PetersenLocalChildren.push (x := s4291) b4291 <|
    PetersenLocalChildren.push (x := s4292) b4292 <|
    PetersenLocalChildren.push (x := s3244) b3244 <|
    PetersenLocalChildren.push (x := s4293) b4293 <|
    PetersenLocalChildren.push (x := s3538) b3538 <|
    PetersenLocalChildren.push (x := s4273) b4273 <|
    PetersenLocalChildren.push (x := s4294) b4294 <|
    PetersenLocalChildren.push (x := s4295) b4295 <|
    PetersenLocalChildren.push (x := s4296) b4296 <|
    PetersenLocalChildren.push (x := s4297) b4297 <|
    PetersenLocalChildren.push (x := s4298) b4298 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4299) b4299 <|
    PetersenLocalChildren.push (x := s4300) b4300 <|
    PetersenLocalChildren.push (x := s4301) b4301 <|
    PetersenLocalChildren.push (x := s4302) b4302 <|
    PetersenLocalChildren.push (x := s4303) b4303 <|
    PetersenLocalChildren.push (x := s4305) b4305 <|
    PetersenLocalChildren.push (x := s2244) b2244 <|
    PetersenLocalChildren.push (x := s4306) b4306 <|
    PetersenLocalChildren.push (x := s3553) b3553 <|
    PetersenLocalChildren.push (x := s4277) b4277 <|
    PetersenLocalChildren.push (x := s3507) b3507 <|
    PetersenLocalChildren.push (x := s4307) b4307 <|
    PetersenLocalChildren.push (x := s4308) b4308 <|
    PetersenLocalChildren.push (x := s4309) b4309 <|
    PetersenLocalChildren.push (x := s4310) b4310 <|
    PetersenLocalChildren.push (x := s957) b957 <|
    PetersenLocalChildren.push (x := s4311) b4311 <|
    PetersenLocalChildren.push (x := s958) b958 <|
    PetersenLocalChildren.push (x := s4312) b4312 <|
    PetersenLocalChildren.push (x := s4313) b4313 <|
    PetersenLocalChildren.push (x := s4314) b4314 <|
    PetersenLocalChildren.push (x := s4315) b4315 <|
    PetersenLocalChildren.push (x := s4316) b4316 <|
    PetersenLocalChildren.push (x := s4317) b4317 <|
    PetersenLocalChildren.push (x := s4318) b4318 <|
    PetersenLocalChildren.push (x := s4319) b4319 <|
    PetersenLocalChildren.push (x := s4320) b4320 <|
    PetersenLocalChildren.push (x := s4321) b4321 <|
    PetersenLocalChildren.push (x := s4322) b4322 <|
    PetersenLocalChildren.push (x := s4323) b4323 <|
    PetersenLocalChildren.push (x := s4324) b4324 <|
    PetersenLocalChildren.push (x := s4325) b4325 <|
    PetersenLocalChildren.nil
theorem b4336 : Blocked tgt 8 s4336 := by
  apply PetersenFastNode.node (nxt := #[s4337,s4338,s4221,s4339,s572,s631,s588,s4340,s4341,s4282,s4343,s4344,s4345,s4346,s1230,s625,s626,s4347,s4348,s4349,s4350,s4351,s4352,s4353,s4354,s4355,s4356,s4357,s4358,s4359,s3320,s3591,s4360,s4361,s4362,s4363,s4364,s4365,s4367,s4368,s4370,s4371,s4372]) (hints := [5589,0,5589,5331,1,5331,5589,2,5589,5331,3,5331,944,4,944,9716,5,6,8940,7,5973,9972,8,9972,5973,9,5973,9972,10,9972,7517,11,7517,12,13,14,1712,15,7517,1712,16,17,2736,18,2736,11508,19,11508,2736,20,2736,11508,21,11508,4784,22,4784,13556,23,13556,4784,24,4784,13556,25,13556,8880,26,8880,13395,27,13395,8880,28,8880,13395,29,13395,5331,5331,7007,816,5589,944,7007,5589,7007,5331,5331,944,5331,5331,5715,9844,6879,9972,5715,6879,5715,5331,5331,9972,4307,6621,7517,4307,5331,30,5331,5331,7517,6621,6621,31,5331,5331,7251,11380,6621,11508,7251,6621,7251,5331,5331,11508,13427,9717,13427,13428,5331,13556,13427,5331,13427,13555,9717,13556,5331,5331,13395,1525,9717,8880,13395,9717,13395,5331,5331,8880,9972,32,9972,432,944,5973,9972,944,9972,5973,33,5973,944,944,17,7517,34,7517,1968,35,36,944,944,7517,11508,944,11508,4959,7007,7509,11508,7007,11508,944,944,7509,13556,944,13556,2911,7007,13685,13556,7007,13556,944,944,13685,13395,944,13395,13653,37,13653,13395,38,13395,944,944,13653,7005,7005,7517,9972,9972,39,9964,9972,7517,9964,7005,40,9972,9972,11508,2736,7005,2736,11508,7005,11508,9972,9972,2736,9972,9972,13556,1619,5715,4784,13556,5715,13556,9972,9972,4784,1716,1716,13395,1780,9972,8880,9908,9972,13395,1716,1716,8880,10476,41,10476,10484,7517,11508,10476,7517,10476,11500,42,11508,12524,11645,12524,12532,7517,13556,12524,7517,12524,13548,11645,13556,8880,7517,8880,13395,11645,13395,8880,11645,8880,13395,7517,13395,11508,11508,13556,3155,7251,14717,13556,7251,13556,11508,11508,14717,3252,3252,13395,3316,11508,14685,11444,11508,13395,3252,3252,14685,5300,5300,8880,5364,13556,13395,13492,13556,8880,5300,5300,13395]) (by decide +kernel)
  change ∀ b ∈ [s4337,s4338,s4221,s4339,s572,s631,s588,s4340,s4341,s4282,s4343,s4344,s4345,s4346,s1230,s625,s626,s4347,s4348,s4349,s4350,s4351,s4352,s4353,s4354,s4355,s4356,s4357,s4358,s4359,s3320,s3591,s4360,s4361,s4362,s4363,s4364,s4365,s4367,s4368,s4370,s4371,s4372], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4337) b4337 <|
    PetersenLocalChildren.push (x := s4338) b4338 <|
    PetersenLocalChildren.push (x := s4221) b4221 <|
    PetersenLocalChildren.push (x := s4339) b4339 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s631) b631 <|
    PetersenLocalChildren.push (x := s588) b588 <|
    PetersenLocalChildren.push (x := s4340) b4340 <|
    PetersenLocalChildren.push (x := s4341) b4341 <|
    PetersenLocalChildren.push (x := s4282) b4282 <|
    PetersenLocalChildren.push (x := s4343) b4343 <|
    PetersenLocalChildren.push (x := s4344) b4344 <|
    PetersenLocalChildren.push (x := s4345) b4345 <|
    PetersenLocalChildren.push (x := s4346) b4346 <|
    PetersenLocalChildren.push (x := s1230) b1230 <|
    PetersenLocalChildren.push (x := s625) b625 <|
    PetersenLocalChildren.push (x := s626) b626 <|
    PetersenLocalChildren.push (x := s4347) b4347 <|
    PetersenLocalChildren.push (x := s4348) b4348 <|
    PetersenLocalChildren.push (x := s4349) b4349 <|
    PetersenLocalChildren.push (x := s4350) b4350 <|
    PetersenLocalChildren.push (x := s4351) b4351 <|
    PetersenLocalChildren.push (x := s4352) b4352 <|
    PetersenLocalChildren.push (x := s4353) b4353 <|
    PetersenLocalChildren.push (x := s4354) b4354 <|
    PetersenLocalChildren.push (x := s4355) b4355 <|
    PetersenLocalChildren.push (x := s4356) b4356 <|
    PetersenLocalChildren.push (x := s4357) b4357 <|
    PetersenLocalChildren.push (x := s4358) b4358 <|
    PetersenLocalChildren.push (x := s4359) b4359 <|
    PetersenLocalChildren.push (x := s3320) b3320 <|
    PetersenLocalChildren.push (x := s3591) b3591 <|
    PetersenLocalChildren.push (x := s4360) b4360 <|
    PetersenLocalChildren.push (x := s4361) b4361 <|
    PetersenLocalChildren.push (x := s4362) b4362 <|
    PetersenLocalChildren.push (x := s4363) b4363 <|
    PetersenLocalChildren.push (x := s4364) b4364 <|
    PetersenLocalChildren.push (x := s4365) b4365 <|
    PetersenLocalChildren.push (x := s4367) b4367 <|
    PetersenLocalChildren.push (x := s4368) b4368 <|
    PetersenLocalChildren.push (x := s4370) b4370 <|
    PetersenLocalChildren.push (x := s4371) b4371 <|
    PetersenLocalChildren.push (x := s4372) b4372 <|
    PetersenLocalChildren.nil
theorem b4390 : Blocked tgt 8 s4390 := by
  apply PetersenFastNode.node (nxt := #[s4391,s4365,s4392,s4323,s4393,s4394,s4395,s611,s4358,s4396]) (hints := [6846,5556,5556,6846,5556,9811,5940,5556,4532,4532,5556,6846,6846,5556,5556,6588,5556,4798,7476,5556,9684,1460,13652,9684,5556,1492,13620,5556,6846,5556,5556,6846,9683,5940,9939,9683,8651,8659,9675,8651,0,9683,9683,1,2703,7476,2703,9683,4751,13396,4751,9683,1491,9683,13620,911,911,6972,9939,9931,9931,8907,9939,9939,6972,9939,2703,11475,9939,9939,4751,13523,9939,1683,9939,9939,1683,1683,9939,9939,1683,1679,1679,2703,10451,2703,11467,4751,12499,4751,13515,14652,13620,14652,13620,2,3,4,5,2703,11475,2703,11475,4751,13523,4751,13523,14652,13620,14652,13620,6,7,8,9,2703,3380,4751,2703,2703,11475,11475,2703,2703,11475,11475,2703,4751,13523,13523,4751,4751,13523,13523,4751,8847,8847]) (by decide +kernel)
  change ∀ b ∈ [s4391,s4365,s4392,s4323,s4393,s4394,s4395,s611,s4358,s4396], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4391) b4391 <|
    PetersenLocalChildren.push (x := s4365) b4365 <|
    PetersenLocalChildren.push (x := s4392) b4392 <|
    PetersenLocalChildren.push (x := s4323) b4323 <|
    PetersenLocalChildren.push (x := s4393) b4393 <|
    PetersenLocalChildren.push (x := s4394) b4394 <|
    PetersenLocalChildren.push (x := s4395) b4395 <|
    PetersenLocalChildren.push (x := s611) b611 <|
    PetersenLocalChildren.push (x := s4358) b4358 <|
    PetersenLocalChildren.push (x := s4396) b4396 <|
    PetersenLocalChildren.nil
theorem b4400 : Blocked tgt 8 s4400 := by
  apply PetersenFastNode.node (nxt := #[s4401,s4402,s2933,s4403,s3712,s4404,s3714,s592,s4368,s4405,s4277,s4406,s4407,s4408,s4409,s4410,s4411,s941,s4412,s4413,s4414,s4415,s471,s4416,s4417,s2934,s4418,s4419,s4420,s4421,s4422,s4423,s4424,s4425,s4426,s4427,s4428,s4429,s4430,s4431]) (hints := [6876,6876,7004,813,5586,941,7004,5586,7004,6876,6876,941,5586,5586,5970,9841,6876,9969,5970,6876,5970,5586,5586,9969,6876,6876,7772,5586,5586,1709,5586,5586,7772,6618,6876,1709,4562,0,1,4562,5586,2,5586,5586,3,4,5,6,5586,5586,7506,4828,6876,2733,7506,6876,7506,5586,5586,2733,9714,9714,13682,1490,5586,4781,13682,5586,13682,9714,9714,4781,5586,5586,13650,1522,9714,8877,13650,9714,13650,5586,5586,8877,9713,9713,9969,941,941,5970,9969,941,9969,9713,9713,5970,941,941,1709,9713,9713,7,1709,9713,1709,941,941,8,8681,8681,9,941,941,10,941,941,11,8681,8681,12,941,941,2733,4956,7004,7506,2733,7004,2733,941,941,7506,941,941,4781,2908,7004,13682,4781,7004,4781,941,941,13682,941,941,8877,1521,9713,13650,8877,9713,8877,941,941,13650,8945,13,14,8945,9969,1709,9969,9969,15,1709,16,1709,9961,9969,17,9961,18,19,9969,9969,11505,2733,20,2733,11505,21,11505,9969,9969,2733,9969,9969,13553,4781,5970,4781,13553,5970,13553,9969,9969,4781,1713,1713,13650,1777,9969,8877,9905,9969,13650,1713,1713,8877,22,23,24,1709,1709,2,1709,1709,3,7514,15,25,1709,1709,2733,11505,7772,11505,2733,7772,2733,1709,1709,11505,1709,1709,4781,13553,7772,13553,4781,7772,4781,1709,1709,13553,1709,1709,8877,13650,26,13650,8877,27,8877,1709,1709,13650,10473,28,10473,2733,29,2733,10473,30,10473,2733,31,2733,12521,32,12521,4781,33,4781,12521,34,12521,4781,35,4781,14682,36,14682,8877,37,8877,14682,38,14682,8877,39,8877,2733,2733,4781,3410,7506,14714,4781,7506,4781,2733,2733,14714,2733,2733,8877,3313,11505,14682,8877,11505,8877,2733,2733,14682,4781,4781,8877,5361,13553,13650,8877,13553,8877,4781,4781,13650]) (by decide +kernel)
  change ∀ b ∈ [s4401,s4402,s2933,s4403,s3712,s4404,s3714,s592,s4368,s4405,s4277,s4406,s4407,s4408,s4409,s4410,s4411,s941,s4412,s4413,s4414,s4415,s471,s4416,s4417,s2934,s4418,s4419,s4420,s4421,s4422,s4423,s4424,s4425,s4426,s4427,s4428,s4429,s4430,s4431], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4401) b4401 <|
    PetersenLocalChildren.push (x := s4402) b4402 <|
    PetersenLocalChildren.push (x := s2933) b2933 <|
    PetersenLocalChildren.push (x := s4403) b4403 <|
    PetersenLocalChildren.push (x := s3712) b3712 <|
    PetersenLocalChildren.push (x := s4404) b4404 <|
    PetersenLocalChildren.push (x := s3714) b3714 <|
    PetersenLocalChildren.push (x := s592) b592 <|
    PetersenLocalChildren.push (x := s4368) b4368 <|
    PetersenLocalChildren.push (x := s4405) b4405 <|
    PetersenLocalChildren.push (x := s4277) b4277 <|
    PetersenLocalChildren.push (x := s4406) b4406 <|
    PetersenLocalChildren.push (x := s4407) b4407 <|
    PetersenLocalChildren.push (x := s4408) b4408 <|
    PetersenLocalChildren.push (x := s4409) b4409 <|
    PetersenLocalChildren.push (x := s4410) b4410 <|
    PetersenLocalChildren.push (x := s4411) b4411 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4412) b4412 <|
    PetersenLocalChildren.push (x := s4413) b4413 <|
    PetersenLocalChildren.push (x := s4414) b4414 <|
    PetersenLocalChildren.push (x := s4415) b4415 <|
    PetersenLocalChildren.push (x := s471) b471 <|
    PetersenLocalChildren.push (x := s4416) b4416 <|
    PetersenLocalChildren.push (x := s4417) b4417 <|
    PetersenLocalChildren.push (x := s2934) b2934 <|
    PetersenLocalChildren.push (x := s4418) b4418 <|
    PetersenLocalChildren.push (x := s4419) b4419 <|
    PetersenLocalChildren.push (x := s4420) b4420 <|
    PetersenLocalChildren.push (x := s4421) b4421 <|
    PetersenLocalChildren.push (x := s4422) b4422 <|
    PetersenLocalChildren.push (x := s4423) b4423 <|
    PetersenLocalChildren.push (x := s4424) b4424 <|
    PetersenLocalChildren.push (x := s4425) b4425 <|
    PetersenLocalChildren.push (x := s4426) b4426 <|
    PetersenLocalChildren.push (x := s4427) b4427 <|
    PetersenLocalChildren.push (x := s4428) b4428 <|
    PetersenLocalChildren.push (x := s4429) b4429 <|
    PetersenLocalChildren.push (x := s4430) b4430 <|
    PetersenLocalChildren.push (x := s4431) b4431 <|
    PetersenLocalChildren.nil
theorem b4529 : Blocked tgt 8 s4529 := by
  apply PetersenFastNode.node (nxt := #[s4530,s4531,s4255,s4532,s4533,s3348,s4534,s4094,s4535,s4323,s4536,s4537,s2259,s4538,s4463,s4539,s4101,s4429,s3763,s4540,s4541,s4542,s4543,s4544,s4545,s4546,s4547,s4548,s4549,s4550,s4551,s4138,s4552,s4109,s4553,s4554,s4555,s4556,s4557,s4558,s4559,s4560,s4561,s4519,s4562,s4563,s941,s4564,s4565]) (hints := [6885,6885,7013,822,5595,950,7013,5595,7013,6885,6885,950,5595,5595,5979,9842,6885,9970,5979,6885,5979,5595,5595,9970,11651,6885,11651,5595,5595,0,6627,5595,11651,6627,6885,1,5595,5595,7515,4837,6885,2742,7515,6885,7515,5595,5595,2742,8699,8699,13691,1499,5595,4790,12795,5595,13691,8699,8699,4790,5595,5595,13659,1531,8699,2,12763,8699,13659,5595,5595,3,4571,6885,4,4571,5595,5,5595,5595,6,6885,6885,7,8690,8690,9970,950,950,5979,9970,950,9970,8690,8690,5979,950,950,11393,8690,8690,11651,8690,8690,11393,950,950,11651,950,950,2742,4965,7013,7515,2742,7013,2742,950,950,7515,950,950,4790,2917,7013,13691,4790,7013,4790,950,950,13691,950,950,13401,1522,8690,13659,8634,8690,13401,950,950,13659,950,950,8,8690,8690,9,8690,8690,10,950,950,11,8946,7011,11651,8946,9970,12,9970,9970,11651,7011,7011,13,9970,9970,10482,2742,7011,2742,10482,7011,10482,9970,9970,2742,9970,9970,12530,4790,5979,4790,12530,5979,12530,9970,9970,4790,1722,1722,13659,1778,9970,14,9914,9970,13659,1722,1722,15,7011,7011,16,9970,9970,17,9970,9970,18,1714,7011,19,2742,20,2742,10482,11651,10482,2742,11651,2742,10482,21,10482,4790,11651,4790,12530,22,12530,4790,23,4790,12530,11651,12530,3459,24,25,3459,11651,13659,11651,11651,26,13659,27,13659,28,29,30,11651,11651,31,1718,11651,32,1718,27,33,2742,2742,4790,3419,7515,14723,4790,7515,4790,2742,2742,14723,2742,2742,13659,3314,10482,34,10426,10482,13659,2742,2742,35,2742,2742,36,10482,10482,37,10482,10482,38,2742,2742,39,4790,4790,40,5362,12530,13659,12474,12530,41,4790,4790,13659,4790,4790,42,12530,12530,43,12530,12530,44,4790,4790,45,8886,13659,46,8886,47,48]) (by decide +kernel)
  change ∀ b ∈ [s4530,s4531,s4255,s4532,s4533,s3348,s4534,s4094,s4535,s4323,s4536,s4537,s2259,s4538,s4463,s4539,s4101,s4429,s3763,s4540,s4541,s4542,s4543,s4544,s4545,s4546,s4547,s4548,s4549,s4550,s4551,s4138,s4552,s4109,s4553,s4554,s4555,s4556,s4557,s4558,s4559,s4560,s4561,s4519,s4562,s4563,s941,s4564,s4565], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4530) b4530 <|
    PetersenLocalChildren.push (x := s4531) b4531 <|
    PetersenLocalChildren.push (x := s4255) b4255 <|
    PetersenLocalChildren.push (x := s4532) b4532 <|
    PetersenLocalChildren.push (x := s4533) b4533 <|
    PetersenLocalChildren.push (x := s3348) b3348 <|
    PetersenLocalChildren.push (x := s4534) b4534 <|
    PetersenLocalChildren.push (x := s4094) b4094 <|
    PetersenLocalChildren.push (x := s4535) b4535 <|
    PetersenLocalChildren.push (x := s4323) b4323 <|
    PetersenLocalChildren.push (x := s4536) b4536 <|
    PetersenLocalChildren.push (x := s4537) b4537 <|
    PetersenLocalChildren.push (x := s2259) b2259 <|
    PetersenLocalChildren.push (x := s4538) b4538 <|
    PetersenLocalChildren.push (x := s4463) b4463 <|
    PetersenLocalChildren.push (x := s4539) b4539 <|
    PetersenLocalChildren.push (x := s4101) b4101 <|
    PetersenLocalChildren.push (x := s4429) b4429 <|
    PetersenLocalChildren.push (x := s3763) b3763 <|
    PetersenLocalChildren.push (x := s4540) b4540 <|
    PetersenLocalChildren.push (x := s4541) b4541 <|
    PetersenLocalChildren.push (x := s4542) b4542 <|
    PetersenLocalChildren.push (x := s4543) b4543 <|
    PetersenLocalChildren.push (x := s4544) b4544 <|
    PetersenLocalChildren.push (x := s4545) b4545 <|
    PetersenLocalChildren.push (x := s4546) b4546 <|
    PetersenLocalChildren.push (x := s4547) b4547 <|
    PetersenLocalChildren.push (x := s4548) b4548 <|
    PetersenLocalChildren.push (x := s4549) b4549 <|
    PetersenLocalChildren.push (x := s4550) b4550 <|
    PetersenLocalChildren.push (x := s4551) b4551 <|
    PetersenLocalChildren.push (x := s4138) b4138 <|
    PetersenLocalChildren.push (x := s4552) b4552 <|
    PetersenLocalChildren.push (x := s4109) b4109 <|
    PetersenLocalChildren.push (x := s4553) b4553 <|
    PetersenLocalChildren.push (x := s4554) b4554 <|
    PetersenLocalChildren.push (x := s4555) b4555 <|
    PetersenLocalChildren.push (x := s4556) b4556 <|
    PetersenLocalChildren.push (x := s4557) b4557 <|
    PetersenLocalChildren.push (x := s4558) b4558 <|
    PetersenLocalChildren.push (x := s4559) b4559 <|
    PetersenLocalChildren.push (x := s4560) b4560 <|
    PetersenLocalChildren.push (x := s4561) b4561 <|
    PetersenLocalChildren.push (x := s4519) b4519 <|
    PetersenLocalChildren.push (x := s4562) b4562 <|
    PetersenLocalChildren.push (x := s4563) b4563 <|
    PetersenLocalChildren.push (x := s941) b941 <|
    PetersenLocalChildren.push (x := s4564) b4564 <|
    PetersenLocalChildren.push (x := s4565) b4565 <|
    PetersenLocalChildren.nil
theorem b4610 : Blocked tgt 8 s4610 := by
  apply PetersenFastNode.node (nxt := #[s4611,s4612,s4248,s4613,s4614,s4615,s4354,s4616,s4617,s4618,s4455,s4621,s4622,s4623,s4624,s4625,s4626,s4627,s4628,s4629,s4630,s4631,s4632,s572,s4633,s4603,s4634,s4635,s4636,s4637,s4638,s4639,s4640,s4641,s3332,s4082,s4642,s4643,s4644,s4544,s4645]) (hints := [5587,0,5587,9715,1,9715,5587,2,5587,9715,3,9715,942,4,942,9714,5,9714,942,6,942,9714,7,9714,8938,8,5971,9970,9,9970,5971,10,5971,9970,11,9970,7515,12,7515,13,14,15,1710,16,7515,1710,17,18,2734,19,2734,11506,20,11506,2734,21,2734,11506,22,11506,4782,23,4782,13554,24,25,8878,26,8878,27,28,29,8878,30,8878,31,32,33,6877,6877,7005,9714,9715,9714,9713,9715,7005,9713,6877,9714,9715,9715,10099,9842,6877,9970,10099,6877,10099,9715,9715,9970,8691,6619,7515,8691,9715,34,9715,9715,7515,6619,6619,35,9715,9715,11635,11378,6619,11506,11635,6619,11635,9715,9715,11506,9715,9715,14715,5587,5587,4782,5587,5587,14715,9715,9715,4782,1459,1459,13651,1523,9715,8878,9651,9715,13651,1459,1459,8878,9714,9714,9970,9843,942,10099,9970,942,9970,9714,9714,10099,8682,8682,7773,8690,9714,7515,9706,9714,7773,8682,8682,7515,9714,9714,11506,11379,7005,11635,11506,7005,11506,9714,9714,11635,9714,9714,4782,2909,7005,14715,4782,7005,4782,9714,9714,14715,1458,1458,8878,1522,9714,13651,9650,9714,8878,1458,1458,13651,7003,7003,7515,9970,9970,7773,9962,9970,7515,9962,7003,7773,9970,9970,11506,2734,7003,2734,11506,7003,11506,9970,9970,2734,9970,9970,14715,4270,5971,4782,5971,5971,14715,9970,9970,4782,1714,1714,13651,1778,9970,8878,9906,9970,13651,1714,1714,8878,10474,5709,10474,10482,7515,11506,10474,7515,10474,11498,5709,11506,4782,18,4782,7515,7515,36,4782,7515,4782,5806,37,38,8878,7515,8878,12627,39,13651,8878,40,8878,7515,7515,13651,11506,11506,4782,7507,7507,14715,4782,7507,4782,11506,11506,14715,3250,3250,8878,3314,11506,14683,11442,11506,8878,3250,3250,14683,4782,4782,8878,13651,14715,13651,8878,14715,8878,4782,4782,13651]) (by decide +kernel)
  change ∀ b ∈ [s4611,s4612,s4248,s4613,s4614,s4615,s4354,s4616,s4617,s4618,s4455,s4621,s4622,s4623,s4624,s4625,s4626,s4627,s4628,s4629,s4630,s4631,s4632,s572,s4633,s4603,s4634,s4635,s4636,s4637,s4638,s4639,s4640,s4641,s3332,s4082,s4642,s4643,s4644,s4544,s4645], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s4611) b4611 <|
    PetersenLocalChildren.push (x := s4612) b4612 <|
    PetersenLocalChildren.push (x := s4248) b4248 <|
    PetersenLocalChildren.push (x := s4613) b4613 <|
    PetersenLocalChildren.push (x := s4614) b4614 <|
    PetersenLocalChildren.push (x := s4615) b4615 <|
    PetersenLocalChildren.push (x := s4354) b4354 <|
    PetersenLocalChildren.push (x := s4616) b4616 <|
    PetersenLocalChildren.push (x := s4617) b4617 <|
    PetersenLocalChildren.push (x := s4618) b4618 <|
    PetersenLocalChildren.push (x := s4455) b4455 <|
    PetersenLocalChildren.push (x := s4621) b4621 <|
    PetersenLocalChildren.push (x := s4622) b4622 <|
    PetersenLocalChildren.push (x := s4623) b4623 <|
    PetersenLocalChildren.push (x := s4624) b4624 <|
    PetersenLocalChildren.push (x := s4625) b4625 <|
    PetersenLocalChildren.push (x := s4626) b4626 <|
    PetersenLocalChildren.push (x := s4627) b4627 <|
    PetersenLocalChildren.push (x := s4628) b4628 <|
    PetersenLocalChildren.push (x := s4629) b4629 <|
    PetersenLocalChildren.push (x := s4630) b4630 <|
    PetersenLocalChildren.push (x := s4631) b4631 <|
    PetersenLocalChildren.push (x := s4632) b4632 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s4633) b4633 <|
    PetersenLocalChildren.push (x := s4603) b4603 <|
    PetersenLocalChildren.push (x := s4634) b4634 <|
    PetersenLocalChildren.push (x := s4635) b4635 <|
    PetersenLocalChildren.push (x := s4636) b4636 <|
    PetersenLocalChildren.push (x := s4637) b4637 <|
    PetersenLocalChildren.push (x := s4638) b4638 <|
    PetersenLocalChildren.push (x := s4639) b4639 <|
    PetersenLocalChildren.push (x := s4640) b4640 <|
    PetersenLocalChildren.push (x := s4641) b4641 <|
    PetersenLocalChildren.push (x := s3332) b3332 <|
    PetersenLocalChildren.push (x := s4082) b4082 <|
    PetersenLocalChildren.push (x := s4642) b4642 <|
    PetersenLocalChildren.push (x := s4643) b4643 <|
    PetersenLocalChildren.push (x := s4644) b4644 <|
    PetersenLocalChildren.push (x := s4544) b4544 <|
    PetersenLocalChildren.push (x := s4645) b4645 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
