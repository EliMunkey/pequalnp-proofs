import M63StartData
import M63StartL5B17
import M63StartL5B14
import M63StartL5B18
import M63StartL5B15
import M63StartL5B19
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b595 : Blocked tgt 6 s595 := by
  apply PetersenFastNode.node (nxt := #[s596,s597,s517,s598,s599]) (hints := [2378,0,1,2378,1369,1369,2378,458,393,458,2638,846,2122,846,1817,842,1817,842,2378,2,1679,2378,2767,3417,2767,3417,458,1433,846,3,846,4,842,1817,842,1817,1354,1354,3417,458,393,458,3157,846,3413,846,1817,842,1817,842,1679,3417,3417,2767,718,202,846,718,458,206,842,458,458,1679,1482,1557,842,838,838,846,407,1679,846,842,1817,1817,842]) (by decide +kernel)
  change ∀ b ∈ [s596,s597,s517,s598,s599], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s596) b596 <|
    PetersenLocalChildren.push (x := s597) b597 <|
    PetersenLocalChildren.push (x := s517) b517 <|
    PetersenLocalChildren.push (x := s598) b598 <|
    PetersenLocalChildren.push (x := s599) b599 <|
    PetersenLocalChildren.nil
theorem b600 : Blocked tgt 6 s600 := by
  apply PetersenFastNode.node (nxt := #[s601,s602,s603,s604,s605,s606,s607,s608]) (hints := [722,722,2381,461,1436,461,2381,0,1,2381,2641,2377,2125,2641,2381,2633,2129,2381,2381,1357,1682,1357,1436,461,1436,461,2770,2,3,2770,2770,3164,1434,2770,1690,2258,1690,3290,1682,1357,1682,1357,461,4,5,461,721,205,457,721,461,209,713,461,461,412,1357,461,849,849,845,845,1357,6,1357,7,402,1690,1434,1617,1101,1617,1353,1357,1105,1357,1609]) (by decide +kernel)
  change ∀ b ∈ [s601,s602,s603,s604,s605,s606,s607,s608], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s601) b601 <|
    PetersenLocalChildren.push (x := s602) b602 <|
    PetersenLocalChildren.push (x := s603) b603 <|
    PetersenLocalChildren.push (x := s604) b604 <|
    PetersenLocalChildren.push (x := s605) b605 <|
    PetersenLocalChildren.push (x := s606) b606 <|
    PetersenLocalChildren.push (x := s607) b607 <|
    PetersenLocalChildren.push (x := s608) b608 <|
    PetersenLocalChildren.nil
theorem b609 : Blocked tgt 6 s609 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,841,2373,841,2373,837,2633,837,2113,2373,2373,2113,2373,1349,1674,1349,1428,453,1428,453,906,841,906,841,3282,837,2762,837,3282,2762,2762,3282,1674,1349,1674,1349,713,453,841,713,453,713,837,453,193,453,453,193,453,404,1349,453,394,841,837,841,1426,841,1349,1609,841,837,1682,837,1609,1349,837,1089,1349,1089,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b610 : Blocked tgt 6 s610 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2633,2373,2373,2633,1364,1364,2373,453,1428,453,2633,2373,2373,841,2373,2625,2121,2373,2373,1349,1674,1349,2762,3412,2762,3412,713,453,713,453,841,1426,837,837,1609,1349,1609,1349,1428,453,1428,453,906,841,3412,841,3412,2250,1682,3412,2372,1349,3396,1349,713,453,453,713,453,201,705,453,453,404,1349,453,1682,841,833,841,1349,1609,1349,1349,1097,1349,1601]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b611 : Blocked tgt 6 s611 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2373,2633,2633,2373,714,714,2633,713,1428,713,2633,2369,2117,2633,2373,2633,2633,837,2633,1609,1674,1609,3282,2762,3282,2762,453,713,453,713,841,841,837,1682,1349,1609,1349,1609,2632,713,2760,713,2762,3156,1426,2762,3282,837,2762,837,1674,1609,1674,1609,713,197,449,713,453,713,713,453,713,1546,1609,713,1426,837,833,1609,1093,1609,1345,837,1609,1349,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b612 : Blocked tgt 6 s612 := by
  apply PetersenFastNode.node (nxt := #[s613,s614]) (hints := [716,716,2375,455,1430,455,2375,0,1,2375,2635,843,2119,843,2375,839,2123,839,2375,1611,1676,2375,1430,455,1430,455,2764,3414,3414,2764,908,843,908,843,1684,839,1684,839,1676,1611,1676,1611,455,1430,1430,455,715,199,843,715,455,203,839,455,455,1430,1611,455,843,1428,839,1814,839,1814,1351,1351,1684,839,835,835,1095,1611,843,839,1099,1091,839]) (by decide +kernel)
  change ∀ b ∈ [s613,s614], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s613) b613 <|
    PetersenLocalChildren.push (x := s614) b614 <|
    PetersenLocalChildren.nil
theorem b615 : Blocked tgt 6 s615 := by
  apply PetersenFastNode.node (nxt := #[s529,s616,s617]) (hints := [717,717,2376,456,1431,456,2636,2376,2376,2636,2376,840,2124,840,2376,1352,0,1352,2636,2376,2376,2636,1431,456,1431,456,2765,3159,1429,2765,1685,840,1685,840,2765,1352,3285,1352,2765,3285,3285,2765,716,456,456,716,456,204,840,456,456,407,1352,456,716,456,456,716,1429,840,1685,840,1096,1429,1352,844,844,840,1685,1352,840,1,840,840,2,1352,1612]) (by decide +kernel)
  change ∀ b ∈ [s529,s616,s617], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s529) b529 <|
    PetersenLocalChildren.push (x := s616) b616 <|
    PetersenLocalChildren.push (x := s617) b617 <|
    PetersenLocalChildren.nil
theorem b618 : Blocked tgt 6 s618 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2633,2373,2373,2633,2372,714,2373,453,388,453,2633,2373,2373,2633,2373,837,772,837,2373,1609,1674,2373,2762,2372,2762,2372,713,453,713,453,841,841,1682,837,1682,837,1349,1349,388,453,388,453,2762,2372,2372,2762,772,837,772,837,2372,1609,1674,1609,713,453,453,713,453,201,837,453,453,1428,1609,453,1426,837,1682,837,1609,1426,1865,837,1097,1089,837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b619 : Blocked tgt 6 s619 := by
  apply PetersenFastNode.node (nxt := #[s620,s621,s531,s622,s623]) (hints := [2378,0,1,2378,1239,1239,2378,458,1433,458,2638,846,2122,846,1687,842,1687,842,2378,1354,2,1354,2767,3287,2767,3287,458,3,458,4,846,1431,842,1687,842,1687,1354,1614,3157,458,3285,458,3287,846,911,846,1687,842,1687,842,2767,1354,3287,1354,718,202,846,718,458,206,842,458,458,409,1354,458,1687,842,838,838,846,1354,1870,842,1687,1354,842]) (by decide +kernel)
  change ∀ b ∈ [s620,s621,s531,s622,s623], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s620) b620 <|
    PetersenLocalChildren.push (x := s621) b621 <|
    PetersenLocalChildren.push (x := s531) b531 <|
    PetersenLocalChildren.push (x := s622) b622 <|
    PetersenLocalChildren.push (x := s623) b623 <|
    PetersenLocalChildren.nil
theorem b624 : Blocked tgt 6 s624 := by
  apply PetersenFastNode.node (nxt := #[s625,s626,s532,s627,s628,s629,s630,s631,s632]) (hints := [723,723,2382,462,1437,462,2642,850,2126,850,2382,0,1,2382,2382,846,2130,846,2382,1358,2,1358,1437,462,1437,462,915,850,915,850,2771,3,4,2771,3291,846,2763,846,2771,1358,3275,1358,722,206,850,722,462,5,6,462,462,210,846,462,462,413,1358,462,850,7,8,850,1435,846,842,842,850,1102,1098,850,846,1691,1358,1618,1106,1358,846]) (by decide +kernel)
  change ∀ b ∈ [s625,s626,s532,s627,s628,s629,s630,s631,s632], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s625) b625 <|
    PetersenLocalChildren.push (x := s626) b626 <|
    PetersenLocalChildren.push (x := s532) b532 <|
    PetersenLocalChildren.push (x := s627) b627 <|
    PetersenLocalChildren.push (x := s628) b628 <|
    PetersenLocalChildren.push (x := s629) b629 <|
    PetersenLocalChildren.push (x := s630) b630 <|
    PetersenLocalChildren.push (x := s631) b631 <|
    PetersenLocalChildren.push (x := s632) b632 <|
    PetersenLocalChildren.nil
theorem b633 : Blocked tgt 6 s633 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [714,714,2373,453,1428,453,2633,841,2117,841,2373,2633,2633,2373,2373,1609,1674,2373,2373,2633,2633,2373,1428,453,1428,453,906,841,906,841,1682,2762,1682,3282,1674,1609,1674,1609,2242,2762,2762,2242,713,197,841,713,453,713,713,453,453,1428,1609,453,453,713,713,453,1426,841,841,1426,841,1426,1609,841,386,841,841,386,1097,1682,1609,837,837,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b634 : Blocked tgt 6 s634 := by
  apply PetersenFastNode.node (nxt := #[s535]) (hints := [2374,2634,2634,2374,715,715,2634,714,1429,714,2634,842,907,842,2374,2634,2634,2374,2634,1350,0,2634,3283,2763,3283,2763,454,714,454,714,1427,842,1427,842,838,838,1350,1610,2633,714,2761,714,907,842,907,842,1683,2763,2763,3283,2763,1350,3267,1350,714,198,842,714,454,714,714,454,714,405,1350,714,1427,842,842,1427,842,1094,1090,842,1350,1683,1862]) (by decide +kernel)
  change ∀ b ∈ [s535], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s535) b535 <|
    PetersenLocalChildren.nil
theorem b635 : Blocked tgt 6 s635 := by
  apply PetersenFastNode.node (nxt := #[s636,s637]) (hints := [2375,0,1,2375,1236,1236,1430,455,1430,455,1428,843,1428,843,2375,839,2123,839,2375,1611,1676,2375,2764,3284,2764,3284,455,1430,455,1430,843,1428,843,1428,839,1684,1351,1351,1430,455,1430,455,1428,843,1428,843,3284,839,2756,839,1676,1611,3284,1611,715,199,843,715,455,203,839,455,455,1430,1611,455,1428,839,835,835,843,1428,1611,843,839,1611,1863]) (by decide +kernel)
  change ∀ b ∈ [s636,s637], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s636) b636 <|
    PetersenLocalChildren.push (x := s637) b637 <|
    PetersenLocalChildren.nil
theorem b643 : Blocked tgt 6 s643 := by
  apply PetersenFastNode.node (nxt := #[s644]) (hints := [3445,198,3317,3317,2795,2795,778,778,3445,842,3763,774,3763,3445,3755,2421,3755,2405,1365,1397,3413,1365,2859,198,198,2987,714,714,198,3763,710,198,198,2485,1222,198,198,1461,2246,198,0,842,2987,842,3507,838,3763,838,2987,1350,3755,1350,907,2374,2955,2374,3633,838,834,834,842,1094,1610,842,842,2118,2634,842,838,1098,1350,838,838,2122,2374,838,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s644], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s644) b644 <|
    PetersenLocalChildren.nil
theorem b645 : Blocked tgt 6 s645 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s645 6 _ le
  decide +kernel
theorem b646 : Blocked tgt 6 s646 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s646 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
