import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv13_4260 : PetersenPackedPin.project r13 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv13_4814 : PetersenPackedPin.project r13 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv13_5473 : PetersenPackedPin.project r13 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv13_6170 : PetersenPackedPin.project r13 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv13_6790 : PetersenPackedPin.project r13 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv13_7474 : PetersenPackedPin.project r13 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv13_8012 : PetersenPackedPin.project r13 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv13_351 : PetersenPackedPin.project r13 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_4260 pv13_8012 rfl rfl
theorem pv13_531 : PetersenPackedPin.project r13 (0xff00ff00ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6170 pv13_8012 rfl rfl
theorem pv13_1252 : PetersenPackedPin.project r13 (0xff00ff0000000000ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6170 pv13_7474 rfl rfl
theorem pv13_1734 : PetersenPackedPin.project r13 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_4260 pv13_6790 rfl rfl
theorem pv13_1829 : PetersenPackedPin.project r13 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv13_5473 pv13_6790 rfl rfl
theorem pv13_1887 : PetersenPackedPin.project r13 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6170 pv13_6790 rfl rfl
theorem pv13_2192 : PetersenPackedPin.project r13 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_4260 pv13_6170 rfl rfl
theorem pv13_2298 : PetersenPackedPin.project r13 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 1 pv13_5473 pv13_6170 rfl rfl
theorem pv13_2708 : PetersenPackedPin.project r13 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_4260 pv13_5473 rfl rfl
theorem pv13_2860 : PetersenPackedPin.project r13 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_5473 pv13_6170 rfl rfl
theorem pv13_3157 : PetersenPackedPin.project r13 (0x22222222222222222222222222222222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_4260 pv13_4814 rfl rfl
theorem pv13_3304 : PetersenPackedPin.project r13 (0x33003300330033003300330033003300 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_4814 pv13_6170 rfl rfl
theorem pv13_3897 : PetersenPackedPin.project r13 (0x88888888888888888888888888888888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4260 pv13_4814 rfl rfl
theorem pv13_3980 : PetersenPackedPin.project r13 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4260 pv13_5473 rfl rfl
theorem pv13_4059 : PetersenPackedPin.project r13 (0xaa00aa00aa00aa00aa00aa00aa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4260 pv13_6170 rfl rfl
theorem pv13_4159 : PetersenPackedPin.project r13 (0xaaaaaaaa00000000aaaaaaaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4260 pv13_7474 rfl rfl
theorem pv13_5241 : PetersenPackedPin.project r13 (0xf000f000f000f000f000f000f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_5473 pv13_6170 rfl rfl
theorem pv13_5850 : PetersenPackedPin.project r13 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv13_4260 pv13_5473 rfl rfl
theorem pv13_5920 : PetersenPackedPin.project r13 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xeeee := PetersenWireProjection.derive 3 pv13_4814 pv13_5473 rfl rfl
theorem pv13_6120 : PetersenPackedPin.project r13 (0xff00ff00ff00ff000000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6170 pv13_8012 rfl rfl
theorem pv13_6504 : PetersenPackedPin.project r13 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_4260 pv13_6170 rfl rfl
theorem pv13_6546 : PetersenPackedPin.project r13 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv13_4814 pv13_6170 rfl rfl
theorem pv13_6618 : PetersenPackedPin.project r13 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv13_5473 pv13_6170 rfl rfl
theorem pv13_7095 : PetersenPackedPin.project r13 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_4260 pv13_6790 rfl rfl
theorem pv13_7235 : PetersenPackedPin.project r13 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv13_5473 pv13_6790 rfl rfl
theorem pv13_7314 : PetersenPackedPin.project r13 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_6170 pv13_6790 rfl rfl
theorem pv13_7855 : PetersenPackedPin.project r13 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv13_6170 pv13_7474 rfl rfl
theorem pv13_7944 : PetersenPackedPin.project r13 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv13_6790 pv13_7474 rfl rfl
theorem pv13_8191 : PetersenPackedPin.project r13 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv13_4260 pv13_8012 rfl rfl
theorem pv13_8295 : PetersenPackedPin.project r13 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv13_6170 pv13_8012 rfl rfl
theorem pv13_561 : PetersenPackedPin.project r13 (0xffaaffaaffaaffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6504 pv13_8012 rfl rfl
theorem pv13_603 : PetersenPackedPin.project r13 (0xffffaaaaffffaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_7095 pv13_8012 rfl rfl
theorem pv13_751 : PetersenPackedPin.project r13 (0xffaa000000000000ffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6504 pv13_7944 rfl rfl
theorem pv13_1277 : PetersenPackedPin.project r13 (0xffaaffaa00000000ffaaffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6504 pv13_7474 rfl rfl
theorem pv13_1316 : PetersenPackedPin.project r13 (0xffffaaaa00000000ffffaaaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_7095 pv13_7474 rfl rfl
theorem pv13_1401 : PetersenPackedPin.project r13 (0xa0000000a0000000a0000000a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_1734 pv13_6618 rfl rfl
theorem pv13_1511 : PetersenPackedPin.project r13 (0xf0a00000f0a00000f0a00000f0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6504 pv13_7235 rfl rfl
theorem pv13_1821 : PetersenPackedPin.project r13 (0xf0f00000f0000000f0f00000f000 : BitVec 128) = 0xc0c0 := PetersenWireProjection.derive 0 pv13_1829 pv13_7855 rfl rfl
theorem pv13_1912 : PetersenPackedPin.project r13 (0xffaa0000ffaa0000ffaa0000ffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6504 pv13_6790 rfl rfl
theorem pv13_2012 : PetersenPackedPin.project r13 (0x20002000200020002000200020002 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_2192 pv13_5920 rfl rfl
theorem pv13_2392 : PetersenPackedPin.project r13 (0xff00aa00ff00aa00ff00aa00ff00aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_6170 pv13_7095 rfl rfl
theorem pv13_2517 : PetersenPackedPin.project r13 (0x2020202020202020202020202020202 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_2708 pv13_4814 rfl rfl
theorem pv13_2884 : PetersenPackedPin.project r13 (0xf0a0f0a0f0a0f0a0f0a0f0a0f0a0f0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_5473 pv13_6504 rfl rfl
theorem pv13_2938 : PetersenPackedPin.project r13 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_5473 pv13_7095 rfl rfl
theorem pv13_3331 : PetersenPackedPin.project r13 (0x33223322332233223322332233223322 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_4814 pv13_6504 rfl rfl
theorem pv13_3392 : PetersenPackedPin.project r13 (0x33332222333322223333222233332222 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_4814 pv13_7095 rfl rfl
theorem pv13_3797 : PetersenPackedPin.project r13 (0x55aa55aa55aa55aa55aa55aa55aa55aa : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_4059 pv13_6504 rfl rfl
theorem pv13_4579 : PetersenPackedPin.project r13 (0xcc88cc88cc88cc88cc88cc88cc88cc88 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4814 pv13_6504 rfl rfl
theorem pv13_4641 : PetersenPackedPin.project r13 (0xcccc8888cccc8888cccc8888cccc8888 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_4814 pv13_7095 rfl rfl
theorem pv13_5029 : PetersenPackedPin.project r13 (0xcececececececececececececececece : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv13_2708 pv13_4814 rfl rfl
theorem pv13_5284 : PetersenPackedPin.project r13 (0xf0a0f0a0f0a0f0a0f0a0f0a0f0a0f0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_5473 pv13_6504 rfl rfl
theorem pv13_5335 : PetersenPackedPin.project r13 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_5473 pv13_7095 rfl rfl
theorem pv13_5568 : PetersenPackedPin.project r13 (0xf0f0fafaf0f0fafaf0f0fafaf0f0fafa : BitVec 128) = 0xcccc := PetersenWireProjection.derive 3 pv13_1734 pv13_5473 rfl rfl
theorem pv13_5696 : PetersenPackedPin.project r13 (0xf5a0f5a0f5a0f5a0f5a0f5a0f5a0f5a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_2708 pv13_6504 rfl rfl
theorem pv13_5745 : PetersenPackedPin.project r13 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv13_2708 pv13_8012 rfl rfl
theorem pv13_6255 : PetersenPackedPin.project r13 (0xff00ffaaff00ffaaff00ffaaff00ffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_1734 pv13_6170 rfl rfl
theorem pv13_6301 : PetersenPackedPin.project r13 (0xff0aff0aff0aff0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_2708 pv13_6120 rfl rfl
theorem pv13_6308 : PetersenPackedPin.project r13 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_2708 pv13_6170 rfl rfl
theorem pv13_6347 : PetersenPackedPin.project r13 (0xff22ff22ff22ff22ff22ff22ff22ff22 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_3157 pv13_6170 rfl rfl
theorem pv13_6456 : PetersenPackedPin.project r13 (0xffa0ffa0ffa0ffa0ffa0ffa0ffa0ffa0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_3980 pv13_6170 rfl rfl
theorem pv13_6457 : PetersenPackedPin.project r13 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6504 pv13_6790 rfl rfl
theorem pv13_6475 : PetersenPackedPin.project r13 (0xffaaffaa00000000ffaaffaa00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6504 pv13_7474 rfl rfl
theorem pv13_6484 : PetersenPackedPin.project r13 (0xffaaffaaff00ff00ffaaffaaff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_4159 pv13_6170 rfl rfl
theorem pv13_6489 : PetersenPackedPin.project r13 (0xffaaffaaffaaffaa0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6504 pv13_8012 rfl rfl
theorem pv13_6897 : PetersenPackedPin.project r13 (0xffff0a0affff0a0affff0a0affff0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_2708 pv13_6790 rfl rfl
theorem pv13_7330 : PetersenPackedPin.project r13 (0xffffff0affffff0affffff0affffff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_2708 pv13_7314 rfl rfl
theorem pv13_7372 : PetersenPackedPin.project r13 (0xffffffaaffffffaaffffffaaffffffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_4260 pv13_7314 rfl rfl
theorem pv13_7903 : PetersenPackedPin.project r13 (0xffffffffffaaffaaffffffffffaaffaa : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 3 pv13_4260 pv13_7855 rfl rfl
theorem pv13_8104 : PetersenPackedPin.project r13 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xff00 := PetersenWireProjection.derive 3 pv13_2708 pv13_8012 rfl rfl
theorem pv13_537 : PetersenPackedPin.project r13 (0xff00ffaaff00ffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6255 pv13_8012 rfl rfl
theorem pv13_541 : PetersenPackedPin.project r13 (0xff0aff0aff0aff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6308 pv13_8012 rfl rfl
theorem pv13_626 : PetersenPackedPin.project r13 (0xffffffaaffffffaa : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_7372 pv13_8012 rfl rfl
theorem pv13_1262 : PetersenPackedPin.project r13 (0xff0aff0a00000000ff0aff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6308 pv13_7474 rfl rfl
theorem pv13_1896 : PetersenPackedPin.project r13 (0xff0a0000ff0a0000ff0a0000ff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv13_6308 pv13_6790 rfl rfl
theorem pv13_2865 : PetersenPackedPin.project r13 (0xf000f0a0f000f0a0f000f0a0f000f0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_5473 pv13_6255 rfl rfl
theorem pv13_2952 : PetersenPackedPin.project r13 (0xf0f0f0a0f0f0f0a0f0f0f0a0f0f0f0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_5473 pv13_7330 rfl rfl
theorem pv13_3315 : PetersenPackedPin.project r13 (0x33023302330233023302330233023302 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv13_4814 pv13_6308 rfl rfl
theorem pv13_6226 : PetersenPackedPin.project r13 (0xff00ff0aff00ff0aff00ff0aff00ff0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_1401 pv13_6170 rfl rfl
theorem pv13_6277 : PetersenPackedPin.project r13 (0xff02ff02ff02ff02ff02ff02ff02ff02 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv13_2012 pv13_6170 rfl rfl
theorem pv13_6300 : PetersenPackedPin.project r13 (0xff0aff0aff0aff0a0000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6301 pv13_8012 rfl rfl
theorem pv13_7223 : PetersenPackedPin.project r13 (0xfffff0f0fffff000fffff0f0fffff000 : BitVec 128) = 0xc0c0 := PetersenWireProjection.derive 3 pv13_1821 pv13_6790 rfl rfl
theorem pv13_6468 : PetersenPackedPin.project r13 (0xffaaf0a0ffaaf000ffaaf0a0ffaaf000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv13_6504 pv13_7223 rfl rfl
end PetersenSmallStarts.M191.Residual
