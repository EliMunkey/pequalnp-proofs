import M63StartData
import M63StartPins0
import M63StartL5B12
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b452 : Blocked tgt 6 s452 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s452 6 _ le
  decide +kernel
theorem b453 : Blocked tgt 6 s453 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s453 6 _ le
  decide +kernel
theorem b454 : Blocked tgt 6 s454 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3508,453,3508,453,2794,777,2986,2794,3314,2794,2794,3314,3314,2794,2794,3314,2794,2290,3754,2794,714,746,2762,714,713,453,841,713,453,713,837,453,193,453,453,193,453,2484,1349,453,453,1460,2373,453,3506,837,841,837,3506,841,841,3506,841,1349,1609,841,841,2373,2633,841,837,3762,837,1609,1349,837,837,2633,2373,837,1089,1349,1089,1349,2113,2373,2113,2373,1349,1706,2373,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b455 : Blocked tgt 6 s455 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s455 6 _ le
  decide +kernel
theorem b456 : Blocked tgt 6 s456 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s456 6 _ le
  decide +kernel
theorem b457 : Blocked tgt 6 s457 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s457 6 _ le
  decide +kernel
theorem b458 : Blocked tgt 6 s458 := by
  apply PetersenFastNode.node (nxt := #[s459]) (hints := [3445,454,3509,3445,2795,778,2987,2795,3315,2283,3763,3315,2795,3315,3315,2795,2795,3315,3315,2795,715,747,2763,715,714,454,454,714,454,202,838,454,454,3509,1350,454,714,454,454,714,454,1461,2374,454,3507,838,3763,838,1094,1094,3507,1350,2987,3507,842,842,2634,2374,2634,2374,838,3763,1350,838,2853,838,838,2853,838,2122,2374,838,1350,1610,1350,0,2374,1350,2634,2374,2634,2374]) (by decide +kernel)
  change ∀ b ∈ [s459], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s459) b459 <|
    PetersenLocalChildren.nil
theorem b460 : Blocked tgt 6 s460 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s460 6 _ le
  decide +kernel
theorem b461 : Blocked tgt 6 s461 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s461 6 _ le
  decide +kernel
theorem b462 : Blocked tgt 6 s462 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s462 6 _ le
  decide +kernel
theorem b463 : Blocked tgt 6 s463 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,false))] s463 6 _ le
  decide +kernel
theorem b464 : Blocked tgt 6 s464 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,false))] s464 6 _ le
  decide +kernel
theorem b465 : Blocked tgt 6 s465 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s465 6 _ le
  decide +kernel
theorem b466 : Blocked tgt 6 s466 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s466 6 _ le
  decide +kernel
theorem b467 : Blocked tgt 6 s467 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s467 6 _ le
  decide +kernel
theorem b468 : Blocked tgt 6 s468 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(2,false))] s468 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
