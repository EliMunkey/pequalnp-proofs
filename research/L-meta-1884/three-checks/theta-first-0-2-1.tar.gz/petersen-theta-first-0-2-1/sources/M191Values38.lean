import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv38_4260 : PetersenPackedPin.project r38 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv38_4814 : PetersenPackedPin.project r38 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv38_5473 : PetersenPackedPin.project r38 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv38_6170 : PetersenPackedPin.project r38 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv38_6790 : PetersenPackedPin.project r38 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv38_7474 : PetersenPackedPin.project r38 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv38_8012 : PetersenPackedPin.project r38 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv38_2963 : PetersenPackedPin.project r38 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_5473 pv38_7474 rfl rfl
theorem pv38_3677 : PetersenPackedPin.project r38 (0x55005500550055005500550055005500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_4260 pv38_6170 rfl rfl
theorem pv38_5224 : PetersenPackedPin.project r38 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeee := PetersenWireProjection.derive 3 pv38_4260 pv38_4814 rfl rfl
theorem pv38_5850 : PetersenPackedPin.project r38 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xfafa := PetersenWireProjection.derive 3 pv38_4260 pv38_5473 rfl rfl
theorem pv38_7095 : PetersenPackedPin.project r38 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaa := PetersenWireProjection.derive 3 pv38_4260 pv38_6790 rfl rfl
theorem pv38_7855 : PetersenPackedPin.project r38 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv38_6170 pv38_7474 rfl rfl
theorem pv38_7944 : PetersenPackedPin.project r38 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv38_6790 pv38_7474 rfl rfl
theorem pv38_1960 : PetersenPackedPin.project r38 (0xffff0000ff000000ffff0000ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_6790 pv38_7855 rfl rfl
theorem pv38_2604 : PetersenPackedPin.project r38 (0x5050505050005000505050505000500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_5850 pv38_7855 rfl rfl
theorem pv38_2988 : PetersenPackedPin.project r38 (0xf0f0f0f0f000f000f0f0f0f0f000f00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_5473 pv38_7855 rfl rfl
theorem pv38_3082 : PetersenPackedPin.project r38 (0x11111111110011001111111111001100 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_5224 pv38_7855 rfl rfl
theorem pv38_3463 : PetersenPackedPin.project r38 (0x33333333330033003333333333003300 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_4814 pv38_7855 rfl rfl
theorem pv38_3744 : PetersenPackedPin.project r38 (0x55555555550055005555555555005500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_4260 pv38_7855 rfl rfl
theorem pv38_4194 : PetersenPackedPin.project r38 (0xaaaaaaaaaa00aa00aaaaaaaaaa00aa00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv38_4260 pv38_7855 rfl rfl
theorem pv38_4732 : PetersenPackedPin.project r38 (0xcccccccccc00cc00cccccccccc00cc00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv38_4814 pv38_7855 rfl rfl
theorem pv38_5408 : PetersenPackedPin.project r38 (0xf0f0f0f0f000f000f0f0f0f0f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv38_5473 pv38_7855 rfl rfl
theorem pv38_7997 : PetersenPackedPin.project r38 (0xffffffffffffff00ffffffffffffff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv38_6170 pv38_7944 rfl rfl
theorem pv38_3483 : PetersenPackedPin.project r38 (0x33333333333333003333333333333300 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv38_4814 pv38_7997 rfl rfl
end PetersenSmallStarts.M191.Residual
