import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv776_4260 : PetersenPackedPin.project r776 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv776_4814 : PetersenPackedPin.project r776 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv776_5473 : PetersenPackedPin.project r776 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv776_6170 : PetersenPackedPin.project r776 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv776_6790 : PetersenPackedPin.project r776 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv776_7474 : PetersenPackedPin.project r776 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv776_8012 : PetersenPackedPin.project r776 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv776_1343 : PetersenPackedPin.project r776 (0xffffffff0000000000000000 : BitVec 128) = 0xff00 := PetersenWireProjection.derive 2 pv776_7474 pv776_8012 rfl rfl
theorem pv776_6504 : PetersenPackedPin.project r776 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv776_4260 pv776_6170 rfl rfl
theorem pv776_7095 : PetersenPackedPin.project r776 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv776_4260 pv776_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
