import higher.WireProjection
import M191Values0
import M191Values1
import M191Values2
import M191Values21
import M191Values22
import M191Values30
import M191Values32
import M191Values34
import M191Values35
import M191Values733
import M191Values734
import M191Values735
import M191Values753
import M191Values754
import M191Values794
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredCuts5
import M191StartPreferredCuts7
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b11562 : Blocked tgt 7 s11562 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11562 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_1779 (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11563 : Blocked tgt 7 s11563 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11563 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_3359 (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11564 : Blocked tgt 7 s11564 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11564 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4675 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11565 : Blocked tgt 7 s11565 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,6964,5544,6836,5546,9801,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,9674,1450,13642,9674,2708,5546,5546,2708,5546,1482,13610,5546,9801,6580,9801,6056,6964,7218,7732,6964,4900,4916,6948,4900,2868,6964,13642,6964,2836,6964,13354,14900,6964,6324,7348,9793,6324,9801,6308,11465,9801,9801,6324,6324,9801,9801,6324,6324,9801,1545,1609,9737,1545,5668,5684,7716,5668,3604,7732,7732,3604,3604,7732,7732,3604,7732,3410,14900,7732,11465,3370,13642,11465,11465,7466,7466,11465,12836,12852,12836,14884,13513,13513,10772,14900,10772,14900,10772,14900,10772,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b11566 : Blocked tgt 7 s11566 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11566 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_1117 (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11567 : Blocked tgt 7 s11567 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s11567 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_3427 (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl)))))))) (by decide +kernel)
theorem b11568 : Blocked tgt 7 s11568 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11568 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4753 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11569 : Blocked tgt 7 s11569 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11569 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 (PetersenWireProjection.cons pv22_8208 rfl)))))))) (by decide +kernel)
theorem b11570 : Blocked tgt 7 s11570 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11570 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_391 (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)

theorem b11571 : Blocked tgt 7 s11571 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11571 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_3485 (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11572 : Blocked tgt 7 s11572 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11572 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5241 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11573 : Blocked tgt 7 s11573 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11573 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6618 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11574 : Blocked tgt 7 s11574 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11574 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11575 : Blocked tgt 7 s11575 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11575 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2860 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11576 : Blocked tgt 7 s11576 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11576 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5294 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11577 : Blocked tgt 7 s11577 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11577 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7235 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11578 : Blocked tgt 7 s11578 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11578 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11579 : Blocked tgt 7 s11579 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11579 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00ff00ff00ff00,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2906 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11580 : Blocked tgt 7 s11580 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11580 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5367 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11581 : Blocked tgt 7 s11581 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11581 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_7774 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11582 : Blocked tgt 7 s11582 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11582 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1177 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11583 : Blocked tgt 7 s11583 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11583 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff0000ffff0000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2963 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11584 : Blocked tgt 7 s11584 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11584 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5425 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11585 : Blocked tgt 7 s11585 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11585 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 (PetersenWireProjection.cons pv9_8245 rfl)))))))) (by decide +kernel)
theorem b11586 : Blocked tgt 7 s11586 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11586 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_456 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)

theorem b11587 : Blocked tgt 7 s11587 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11587 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffffffff00000000,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3004 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11588 : Blocked tgt 7 s11588 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11588 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff000000ff000000ff000000ff000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11589 : Blocked tgt 7 s11589 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11589 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7314 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11590 : Blocked tgt 7 s11590 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11590 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11591 : Blocked tgt 7 s11591 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11591 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11592 : Blocked tgt 7 s11592 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11592 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff00ff0000000000ff00ff0000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11593 : Blocked tgt 7 s11593 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11593 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv32_3822 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_7855 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11594 : Blocked tgt 7 s11594 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11594 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff00ff0000000000ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11595 : Blocked tgt 7 s11595 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11595 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2418 (PetersenWireProjection.cons pv32_3822 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11596 : Blocked tgt 7 s11596 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11596 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff00ff00ff00ff000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11597 : Blocked tgt 7 s11597 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11597 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_3822 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b11598 : Blocked tgt 7 s11598 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11598 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11599 : Blocked tgt 7 s11599 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11599 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_2461 (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11600 : Blocked tgt 7 s11600 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11600 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0xffff000000000000ffff000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11601 : Blocked tgt 7 s11601 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,6964,773,6836,5546,9801,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,9674,5546,5546,9674,9674,5546,5546,9674,5546,1482,13610,5546,9673,6580,9801,9673,6964,8649,7732,6964,4900,4916,6948,4900,2836,2868,6932,2836,772,6964,6964,772,6964,1481,14900,6964,6324,7348,9793,6324,9801,6308,4276,9801,9801,6292,2228,9801,9801,6324,6324,9801,1545,1609,9737,1545,5668,5684,7716,5668,3604,3636,7700,3604,1540,7732,7732,1540,7732,3410,14900,7732,3370,7466,14674,11465,11465,12836,12852,12836,14884,13513,13513,10772,10804,10772,14868,8708,14900,8708,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b11602 : Blocked tgt 7 s11602 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11602 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_1294 (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)

theorem b11603 : Blocked tgt 7 s11603 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s11603 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_1925 (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl)))))))) (by decide +kernel)
theorem b11604 : Blocked tgt 7 s11604 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11604 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xffff0000ffff00000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11605 : Blocked tgt 7 s11605 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11605 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_3822 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8331 rfl)))))))) (by decide +kernel)
theorem b11606 : Blocked tgt 7 s11606 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11606 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0xffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11607 : Blocked tgt 7 s11607 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11607 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_1977 (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11608 : Blocked tgt 7 s11608 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11608 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7397 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11609 : Blocked tgt 7 s11609 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s11609 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 (PetersenWireProjection.cons pv34_8377 rfl)))))))) (by decide +kernel)
theorem b11610 : Blocked tgt 7 s11610 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s11610 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_630 (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl)))))))) (by decide +kernel)
theorem b11611 : Blocked tgt 7 s11611 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11611 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_1343 (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11614 : Blocked tgt 7 s11614 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(1,true),(3,false)),(true,(1,false),(0,false))] s11614 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a) (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b11615 : Blocked tgt 7 s11615 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11615 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11616 : Blocked tgt 7 s11616 := by
  intro k le c
  apply rejects_sound r733 (0xffffffffcccccccc :: i6) 6 tgt small733 hot733 [] s11616 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0xffffffffcccccccc,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r733 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv733_4814 (PetersenWireProjection.cons pv733_5029 (PetersenWireProjection.cons pv733_5473 (PetersenWireProjection.cons pv733_6170 (PetersenWireProjection.cons pv733_6790 (PetersenWireProjection.cons pv733_7474 (PetersenWireProjection.cons pv733_8012 rfl)))))))) (by decide +kernel)
theorem b11617 : Blocked tgt 7 s11617 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11617 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11618 : Blocked tgt 7 s11618 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11618 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xc4c4c4c4c4c4c4c4c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11619 : Blocked tgt 7 s11619 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11619 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2654 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11620 : Blocked tgt 7 s11620 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11620 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_3822 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b11621 : Blocked tgt 7 s11621 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11621 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11622 : Blocked tgt 7 s11622 := by
  intro k le c
  apply rejects_sound r777 (0x3300330033003300 :: i6) 6 tgt small777 hot777 [] s11622 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0x3300330033003300,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x3300330033003300) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r777 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffff0000ffff0000) rfl))))))) (by decide +kernel)
theorem b11623 : Blocked tgt 7 s11623 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s11623 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3822 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5682 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b11624 : Blocked tgt 7 s11624 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11624 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11625 : Blocked tgt 7 s11625 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11625 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2672 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11626 : Blocked tgt 7 s11626 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s11626 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r753 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_6897 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl)))))))) (by decide +kernel)
theorem b11627 : Blocked tgt 7 s11627 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11627 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11628 : Blocked tgt 7 s11628 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s11628 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_3822 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0xf5f50000f5f50000f5f50000f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)
theorem b11629 : Blocked tgt 7 s11629 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11629 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11630 : Blocked tgt 7 s11630 := by
  intro k le c
  apply rejects_sound r754 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small754 hot754 [] s11630 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r754 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv754_4814 (PetersenWireProjection.cons pv754_5473 (PetersenWireProjection.cons pv754_6170 (PetersenWireProjection.cons pv754_6790 (PetersenWireProjection.cons pv754_7474 (PetersenWireProjection.cons pv754_7588 (PetersenWireProjection.cons pv754_8012 rfl)))))))) (by decide +kernel)
theorem b11631 : Blocked tgt 7 s11631 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11631 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11632 : Blocked tgt 7 s11632 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s11632 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_3822 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r34 (0xf5f5f5f500000000f5f5f5f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl)))))))) (by decide +kernel)
theorem b11633 : Blocked tgt 7 s11633 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11633 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11634 : Blocked tgt 7 s11634 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11634 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_3822 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8104 rfl)))))))) (by decide +kernel)
theorem b11635 : Blocked tgt 7 s11635 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11635 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11636 : Blocked tgt 7 s11636 := by
  intro k le c
  apply rejects_sound r791 (0x3333000033330000 :: i6) 6 tgt small791 hot791 [] s11636 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xffffffff00000000,0x0,0x3333000033330000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x3333000033330000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r791 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaaaaaaaaaaaaaa) rfl))))))) (by decide +kernel)
theorem b11637 : Blocked tgt 7 s11637 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s11637 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_3822 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_5745 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b11638 : Blocked tgt 7 s11638 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11638 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b11639 : Blocked tgt 7 s11639 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s11639 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xffffffffcccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0xdededededededededededededededede : BitVec 128) = 0xffffffffcccccccc) (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b11640 : Blocked tgt 7 s11640 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s11640 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0x12121212121212121212121212121212 : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b11641 : Blocked tgt 7 s11641 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11641 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11642 : Blocked tgt 7 s11642 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11642 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11643 : Blocked tgt 7 s11643 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11643 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6429 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11644 : Blocked tgt 7 s11644 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s11644 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x5a005a005a005a005a005a005a005a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b11645 : Blocked tgt 7 s11645 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11645 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff5a5a5a5a5a5a5a5a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b11646 : Blocked tgt 7 s11646 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s11646 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0x5a5a5a5a5a5a5a5a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b11791 : Blocked tgt 7 s11791 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s11791 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x50505050505000005050505050500000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b11792 : Blocked tgt 7 s11792 := by
  intro k le c
  apply rejects_sound r794 (0xa0a :: i4) 3 tgt small794 hot794 [] s11792 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a,0x0,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r794 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r794 (0xafafafafafaf0000afafafafafaf0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv794_4814 (PetersenWireProjection.cons pv794_5473 (PetersenWireProjection.cons pv794_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r794 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv794_7474 (PetersenWireProjection.cons pv794_8012 rfl)))))))) (by decide +kernel)
theorem b11806 : Blocked tgt 7 s11806 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11806 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11807 : Blocked tgt 7 s11807 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11807 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b11808 : Blocked tgt 7 s11808 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11808 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b11809 : Blocked tgt 7 s11809 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s11809 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12048 : Blocked tgt 7 s12048 := by
  intro k le c
  apply rejects_sound r797 (0x3300 :: i4) 3 tgt small797 hot797 [] s12048 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x3300,0xcccc,0xf0f0,0x0,0x0,0x0,0xaaaa,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0x50505050505050505050505050505050 : BitVec 128) = 0x3300) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b12066 : Blocked tgt 7 s12066 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12066 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12067 : Blocked tgt 7 s12067 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12067 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12068 : Blocked tgt 7 s12068 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s12068 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x48484848484848484848484848484848 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b12069 : Blocked tgt 7 s12069 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s12069 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xffffffffcccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0xdededededededededededededededede : BitVec 128) = 0xffffffffcccccccc) (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b12070 : Blocked tgt 7 s12070 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s12070 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0x12121212121212121212121212121212 : BitVec 128) = 0xcccccccc) (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons pv734_4814 (PetersenWireProjection.cons pv734_5473 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
theorem b12071 : Blocked tgt 7 s12071 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s12071 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x84848484848484848484848484848484 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b12072 : Blocked tgt 7 s12072 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12072 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0x5a005a005a005a005a005a005a005a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12073 : Blocked tgt 7 s12073 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12073 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6429 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b12074 : Blocked tgt 7 s12074 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12074 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x5a005a005a005a005a005a005a005a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b12075 : Blocked tgt 7 s12075 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12075 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xa500a500a500a500a500a500a500a500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
