import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values11
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values22
import M191Values32
import M191Values35
import M191Values5
import M191Values740
import M191Values762
import M191Values765
import M191Values766
import M191Values767
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts4
import M191StartPreferredCuts5
import M191StartPreferredRows25
import M191StartPreferredRows26
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b5679 : Blocked tgt 7 s5679 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5679 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3010 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5680 : Blocked tgt 7 s5680 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5680 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5978 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5681 : Blocked tgt 7 s5681 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5681 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7314 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5682 : Blocked tgt 7 s5682 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5682 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_1887 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5683 : Blocked tgt 7 s5683 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5683 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_2362 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5684 : Blocked tgt 7 s5684 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5684 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6055 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5685 : Blocked tgt 7 s5685 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5685 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)

theorem b5686 : Blocked tgt 7 s5686 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5686 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_1252 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5687 : Blocked tgt 7 s5687 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5687 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2418 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5688 : Blocked tgt 7 s5688 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5688 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6120 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5689 : Blocked tgt 7 s5689 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5689 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8074 (PetersenWireProjection.cons pv32_8305 rfl)))))))) (by decide +kernel)
theorem b5690 : Blocked tgt 7 s5690 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5690 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_531 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5691 : Blocked tgt 7 s5691 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5691 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xff00ff00ff00ff000a000a000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5692 : Blocked tgt 7 s5692 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5692 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6671 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5693 : Blocked tgt 7 s5693 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5693 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8074 rfl)))))))) (by decide +kernel)
theorem b5694 : Blocked tgt 7 s5694 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5694 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5695 : Blocked tgt 7 s5695 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5695 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1925 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5696 : Blocked tgt 7 s5696 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5696 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffff0000ffff0000000a0000000a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5697 : Blocked tgt 7 s5697 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5697 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8074 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffffffffff000affff000a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b5698 : Blocked tgt 7 s5698 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5698 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfff50000fff50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5699 : Blocked tgt 7 s5699 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5699 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0000ffff0000000a0000000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8074 rfl)))))))) (by decide +kernel)
theorem b5700 : Blocked tgt 7 s5700 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5700 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xffffffff00000000000a000a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5701 : Blocked tgt 7 s5701 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5701 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffffffffffffffffffff000a000a : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)

theorem b5702 : Blocked tgt 7 s5702 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5702 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xfff5fff500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5703 : Blocked tgt 7 s5703 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5703 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffff00000000000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5705 : Blocked tgt 7 s5705 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5705 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8074 rfl)))))))) (by decide +kernel)
theorem b5706 : Blocked tgt 7 s5706 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5706 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8074 rfl)))))))) (by decide +kernel)
theorem b5707 : Blocked tgt 7 s5707 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5707 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaaaaaaaaaa000a000a000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5708 : Blocked tgt 7 s5708 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5708 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaa0aaa0aaa0aaa0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5709 : Blocked tgt 7 s5709 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5709 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4753 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8074 rfl)))))))) (by decide +kernel)
theorem b5710 : Blocked tgt 7 s5710 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s5710 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv35_8208 rfl)))))))) (by decide +kernel)
theorem b5711 : Blocked tgt 7 s5711 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5711 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8074 rfl)))))))) (by decide +kernel)
theorem b5712 : Blocked tgt 7 s5712 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5712 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5713 : Blocked tgt 7 s5713 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s5713 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccccccccccc0008000800080008 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b5714 : Blocked tgt 7 s5714 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s5714 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xccc4ccc4ccc4ccc4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b5715 : Blocked tgt 7 s5715 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5715 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0x33333333333333330002000200020002 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b5716 : Blocked tgt 7 s5716 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s5716 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv35_8245 rfl)))))))) (by decide +kernel)
theorem b5717 : Blocked tgt 7 s5717 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5717 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3004 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5718 : Blocked tgt 7 s5718 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5718 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3010 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)

theorem b5719 : Blocked tgt 7 s5719 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5719 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8074 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b5720 : Blocked tgt 7 s5720 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5720 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2461 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5721 : Blocked tgt 7 s5721 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5721 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6738 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5722 : Blocked tgt 7 s5722 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5722 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8074 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b5723 : Blocked tgt 7 s5723 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s5723 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_581 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8074 rfl)))))))) (by decide +kernel)
theorem b5724 : Blocked tgt 7 s5724 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5724 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8074 rfl)))))))) (by decide +kernel)
theorem b5725 : Blocked tgt 7 s5725 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5725 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffff0000ffff0000000a0000000a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5726 : Blocked tgt 7 s5726 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5726 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffffffffff000affff000a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b5727 : Blocked tgt 7 s5727 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5727 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfff50000fff50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5728 : Blocked tgt 7 s5728 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5728 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0000ffff0000000a0000000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b5729 : Blocked tgt 7 s5729 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5729 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7397 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5730 : Blocked tgt 7 s5730 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5730 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b5731 : Blocked tgt 7 s5731 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5731 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_630 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8074 rfl)))))))) (by decide +kernel)
theorem b5732 : Blocked tgt 7 s5732 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5732 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8074 rfl)))))))) (by decide +kernel)
theorem b5733 : Blocked tgt 7 s5733 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s5733 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffff00000000000a000a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b5734 : Blocked tgt 7 s5734 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s5734 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfff5fff500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)

theorem b5735 : Blocked tgt 7 s5735 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5735 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffff00000000000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b5736 : Blocked tgt 7 s5736 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,false),(4,true)),(true,(0,false),(8,false))] s5736 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff000a000a000a000a] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffffffffffffffff000a000a000a000a : BitVec 128) = 0xffffffffffffffff000a000a000a000a) rfl)))))))) (by decide +kernel)
theorem b5737 : Blocked tgt 7 s5737 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5737 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_112 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8074 rfl)))))))) (by decide +kernel)
theorem b5786 : Blocked tgt 7 s5786 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s5786 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0,0xcccccccc] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfff5fff5fff5fff50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8208 rfl)))))))) (by decide +kernel)
theorem b5787 : Blocked tgt 7 s5787 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5787 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa000a000a000a0008000800080008 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5788 : Blocked tgt 7 s5788 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s5788 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_4260 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xfff5fff5fff5fff5ccc4ccc4ccc4ccc4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b5855 : Blocked tgt 7 s5855 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5855 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000,0xffffaaaa] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8191 rfl)))))))) (by decide +kernel)
theorem b5856 : Blocked tgt 7 s5856 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5856 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffaaaa] (PetersenWireProjection.cons pv2_2748 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8191 rfl)))))))) (by decide +kernel)
theorem b5857 : Blocked tgt 7 s5857 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5857 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_5682 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_7688 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5858 : Blocked tgt 7 s5858 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5858 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5859 : Blocked tgt 7 s5859 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5859 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_4213 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b5860 : Blocked tgt 7 s5860 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5860 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5861 : Blocked tgt 7 s5861 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5861 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5862 : Blocked tgt 7 s5862 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5862 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_3759 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b5863 : Blocked tgt 7 s5863 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5863 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3759 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b5864 : Blocked tgt 7 s5864 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5864 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000,0xffffaaaa] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8191 rfl)))))))) (by decide +kernel)

theorem b5865 : Blocked tgt 7 s5865 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(0,false),(4,false))] s5865 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffaaaa] (PetersenWireProjection.cons pv2_2652 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8191 rfl)))))))) (by decide +kernel)
theorem b5869 : Blocked tgt 7 s5869 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5869 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_5682 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5870 : Blocked tgt 7 s5870 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5870 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4785 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5682 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b5976 : Blocked tgt 7 s5976 := by
  intro k le c
  apply rejects_sound r762 (0xfcfcfcfc :: i5) 6 tgt small762 hot762 [(true,(2,false),(4,false))] s5976 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xfcfcfcfc,0x0,0xffff0000,0xff00ff00,0xffccffcc] (PetersenWireProjection.cons pv762_4260 (PetersenWireProjection.cons pv762_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r762 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv762_5920 (PetersenWireProjection.cons pv762_6790 (PetersenWireProjection.cons pv762_7474 (PetersenWireProjection.cons pv762_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r762 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffccffcc) rfl)))))))) (by decide +kernel)
theorem b5977 : Blocked tgt 7 s5977 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5977 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 (PetersenWireProjection.cons pv740_8208 rfl)))))))) (by decide +kernel)
theorem b5978 : Blocked tgt 7 s5978 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5978 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b5979 : Blocked tgt 7 s5979 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5979 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_2652 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b5980 : Blocked tgt 7 s5980 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5980 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b5981 : Blocked tgt 7 s5981 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5981 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_1779 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b5982 : Blocked tgt 7 s5982 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5982 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0xf0f0,0xff00,0xffff,0x0,0xaaaa] (PetersenWireProjection.cons pv19_1117 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_5682 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 (PetersenWireProjection.cons pv19_8208 rfl)))))))) (by decide +kernel)
theorem b5983 : Blocked tgt 7 s5983 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5983 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0,0xcccccccc] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4753 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8208 rfl)))))))) (by decide +kernel)
theorem b5984 : Blocked tgt 7 s5984 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5984 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4753 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5682 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8208 rfl)))))))) (by decide +kernel)
theorem b5985 : Blocked tgt 7 s5985 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s5985 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_391 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_5682 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8208 rfl)))))))) (by decide +kernel)
theorem b5986 : Blocked tgt 7 s5986 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5986 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0,0xcccccccc] (PetersenWireProjection.cons pv5_3485 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8208 rfl)))))))) (by decide +kernel)

theorem b5987 : Blocked tgt 7 s5987 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s5987 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3485 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5682 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b5988 : Blocked tgt 7 s5988 := by
  intro k le c
  apply rejects_sound r766 (0xfff0fff0 :: i5) 6 tgt small766 hot766 [(true,(2,false),(4,false))] s5988 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xffccffcc,0xfff0fff0] (PetersenWireProjection.cons pv766_4260 (PetersenWireProjection.cons pv766_4814 (PetersenWireProjection.cons pv766_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r766 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv766_6790 (PetersenWireProjection.cons pv766_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r766 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffccffcc) (PetersenWireProjection.cons pv766_8245 rfl)))))))) (by decide +kernel)
theorem b5989 : Blocked tgt 7 s5989 := by
  intro k le c
  apply rejects_sound r767 (0xf000f00 :: i5) 6 tgt small767 hot767 [(true,(2,false),(4,false))] s5989 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf000f00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xffccffcc] (PetersenWireProjection.cons pv767_3004 (PetersenWireProjection.cons pv767_4260 (PetersenWireProjection.cons pv767_4814 (PetersenWireProjection.cons pv767_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r767 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv767_6790 (PetersenWireProjection.cons pv767_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r767 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xffccffcc) rfl)))))))) (by decide +kernel)
theorem b5990 : Blocked tgt 7 s5990 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5990 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0x5050505050505050,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5682 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5991 : Blocked tgt 7 s5991 := by
  intro k le c
  apply rejects_sound r765 (0x3300 :: i4) 3 tgt small765 hot765 [] s5991 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x0,0x3300,0xf0f0,0xaaaa,0x0,0x0] (PetersenWireProjection.cons pv765_4260 (PetersenWireProjection.cons pv765_4814 (PetersenWireProjection.cons pv765_5473 (PetersenWireProjection.cons pv765_5682 (PetersenWireProjection.cons pv765_6790 (PetersenWireProjection.cons pv765_7474 (PetersenWireProjection.cons pv765_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xfffffffffffffffffcfcfcfcfcfcfcfc : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b5992 : Blocked tgt 7 s5992 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,true),(2,false))] s5992 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x5050505050505050,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x3030303030303030 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5682 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5993 : Blocked tgt 7 s5993 := by
  intro k le c
  apply rejects_sound r765 (0x3300 :: i4) 3 tgt small765 hot765 [] s5993 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0x3300,0xf0f0,0xaaaa,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xf0f0f0f0f0f0f0f0c0c0c0c0c0c0c0c : BitVec 128) = 0x0) (PetersenWireProjection.cons pv765_4260 (PetersenWireProjection.cons pv765_4814 (PetersenWireProjection.cons pv765_5473 (PetersenWireProjection.cons pv765_5682 (PetersenWireProjection.cons pv765_6790 (PetersenWireProjection.cons pv765_7474 (PetersenWireProjection.cons pv765_8012 rfl)))))))) (by decide +kernel)
theorem b5994 : Blocked tgt 7 s5994 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5994 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500f500f500f500c400c400c400c400 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5995 : Blocked tgt 7 s5995 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5995 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffffffffffffffffdccfdccfdccfdcc : BitVec 128) = 0xffffcccc) rfl)))))))) (by decide +kernel)
theorem b5996 : Blocked tgt 7 s5996 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5996 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0x3100310031003100 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5997 : Blocked tgt 7 s5997 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5997 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffffcccc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaff0aff0aff0aff08cc08cc08cc08cc : BitVec 128) = 0xffffcccc) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5998 : Blocked tgt 7 s5998 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5998 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6768 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5999 : Blocked tgt 7 s5999 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5999 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffffffffffffffffffffccccffffcccc : BitVec 128) = 0xffffcccc) rfl)))))))) (by decide +kernel)
theorem b6000 : Blocked tgt 7 s6000 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6000 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_258 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6001 : Blocked tgt 7 s6001 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s6001 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffffcccc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffff0000ffff0000cccc0000cccc : BitVec 128) = 0xffffcccc) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
