import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv9_4260 : PetersenPackedPin.project r9 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv9_4814 : PetersenPackedPin.project r9 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv9_5473 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv9_6170 : PetersenPackedPin.project r9 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv9_6790 : PetersenPackedPin.project r9 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv9_7474 : PetersenPackedPin.project r9 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv9_8012 : PetersenPackedPin.project r9 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv9_456 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_5473 pv9_8012 rfl rfl
theorem pv9_1177 : PetersenPackedPin.project r9 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_5473 pv9_7474 rfl rfl
theorem pv9_1734 : PetersenPackedPin.project r9 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 1 pv9_4260 pv9_6790 rfl rfl
theorem pv9_1829 : PetersenPackedPin.project r9 (0xf0f00000f0f00000f0f00000f0f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_5473 pv9_6790 rfl rfl
theorem pv9_2192 : PetersenPackedPin.project r9 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 1 pv9_4260 pv9_6170 rfl rfl
theorem pv9_2298 : PetersenPackedPin.project r9 (0xf000f000f000f000f000f000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_5473 pv9_6170 rfl rfl
theorem pv9_2708 : PetersenPackedPin.project r9 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv9_4260 pv9_5473 rfl rfl
theorem pv9_2800 : PetersenPackedPin.project r9 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 1 pv9_4814 pv9_5473 rfl rfl
theorem pv9_2860 : PetersenPackedPin.project r9 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 2 pv9_5473 pv9_6170 rfl rfl
theorem pv9_2906 : PetersenPackedPin.project r9 (0xf0f00000f0f00000f0f00000f0f0000 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 2 pv9_5473 pv9_6790 rfl rfl
theorem pv9_2963 : PetersenPackedPin.project r9 (0xf0f0f0f000000000f0f0f0f00000000 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 2 pv9_5473 pv9_7474 rfl rfl
theorem pv9_3004 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 2 pv9_5473 pv9_8012 rfl rfl
theorem pv9_3209 : PetersenPackedPin.project r9 (0x30303030303030303030303030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_4814 pv9_5473 rfl rfl
theorem pv9_3632 : PetersenPackedPin.project r9 (0x50505050505050505050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_4260 pv9_5473 rfl rfl
theorem pv9_3980 : PetersenPackedPin.project r9 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_4260 pv9_5473 rfl rfl
theorem pv9_4429 : PetersenPackedPin.project r9 (0xc0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_4814 pv9_5473 rfl rfl
theorem pv9_5224 : PetersenPackedPin.project r9 (0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv9_4260 pv9_4814 rfl rfl
theorem pv9_5241 : PetersenPackedPin.project r9 (0xf000f000f000f000f000f000f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_6170 rfl rfl
theorem pv9_5294 : PetersenPackedPin.project r9 (0xf0f00000f0f00000f0f00000f0f00000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_6790 rfl rfl
theorem pv9_5367 : PetersenPackedPin.project r9 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_7474 rfl rfl
theorem pv9_5425 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_8012 rfl rfl
theorem pv9_5850 : PetersenPackedPin.project r9 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv9_4260 pv9_5473 rfl rfl
theorem pv9_5920 : PetersenPackedPin.project r9 (0xfcfcfcfcfcfcfcfcfcfcfcfcfcfcfcfc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv9_4814 pv9_5473 rfl rfl
theorem pv9_6504 : PetersenPackedPin.project r9 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xfafafafafafafafa := PetersenWireProjection.derive 3 pv9_4260 pv9_6170 rfl rfl
theorem pv9_6546 : PetersenPackedPin.project r9 (0xffccffccffccffccffccffccffccffcc : BitVec 128) = 0xfcfcfcfcfcfcfcfc := PetersenWireProjection.derive 3 pv9_4814 pv9_6170 rfl rfl
theorem pv9_6618 : PetersenPackedPin.project r9 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv9_5473 pv9_6170 rfl rfl
theorem pv9_7095 : PetersenPackedPin.project r9 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffaaffaaffaaffaa := PetersenWireProjection.derive 3 pv9_4260 pv9_6790 rfl rfl
theorem pv9_7235 : PetersenPackedPin.project r9 (0xfffff0f0fffff0f0fffff0f0fffff0f0 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv9_5473 pv9_6790 rfl rfl
theorem pv9_7712 : PetersenPackedPin.project r9 (0xffffffffccccccccffffffffcccccccc : BitVec 128) = 0xffffccccffffcccc := PetersenWireProjection.derive 3 pv9_4814 pv9_7474 rfl rfl
theorem pv9_7774 : PetersenPackedPin.project r9 (0xfffffffff0f0f0f0fffffffff0f0f0f0 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_5473 pv9_7474 rfl rfl
theorem pv9_7855 : PetersenPackedPin.project r9 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xfffff0f0fffff0f0 := PetersenWireProjection.derive 3 pv9_6170 pv9_7474 rfl rfl
theorem pv9_8245 : PetersenPackedPin.project r9 (0xfffffffffffffffff0f0f0f0f0f0f0f0 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv9_5473 pv9_8012 rfl rfl
theorem pv9_8295 : PetersenPackedPin.project r9 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xfffffffff0f0f0f0 := PetersenWireProjection.derive 3 pv9_6170 pv9_8012 rfl rfl
theorem pv9_283 : PetersenPackedPin.project r9 (0x5050505050505050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_456 pv9_4260 rfl rfl
theorem pv9_443 : PetersenPackedPin.project r9 (0xf050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_456 pv9_2192 rfl rfl
theorem pv9_447 : PetersenPackedPin.project r9 (0xf0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_456 pv9_1734 rfl rfl
theorem pv9_448 : PetersenPackedPin.project r9 (0xf0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_456 pv9_7095 rfl rfl
theorem pv9_667 : PetersenPackedPin.project r9 (0xfffffffff0f0f0f0 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 1 pv9_7774 pv9_8012 rfl rfl
theorem pv9_723 : PetersenPackedPin.project r9 (0x50500000000000005050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1177 pv9_7095 rfl rfl
theorem pv9_836 : PetersenPackedPin.project r9 (0xf000f00000000000f000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1177 pv9_6170 rfl rfl
theorem pv9_969 : PetersenPackedPin.project r9 (0x303030300000000030303030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1177 pv9_4814 rfl rfl
theorem pv9_1164 : PetersenPackedPin.project r9 (0xf050f05000000000f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1177 pv9_2192 rfl rfl
theorem pv9_1168 : PetersenPackedPin.project r9 (0xf0f0505000000000f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1177 pv9_1734 rfl rfl
theorem pv9_1169 : PetersenPackedPin.project r9 (0xf0f0a0a000000000f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_1177 pv9_7095 rfl rfl
theorem pv9_1449 : PetersenPackedPin.project r9 (0xf0000000f0000000f0000000f0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1829 pv9_6170 rfl rfl
theorem pv9_1597 : PetersenPackedPin.project r9 (0x5050000050500000505000005050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1829 pv9_4260 rfl rfl
theorem pv9_1693 : PetersenPackedPin.project r9 (0xa0a00000a0a00000a0a00000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_1734 pv9_5473 rfl rfl
theorem pv9_1817 : PetersenPackedPin.project r9 (0xf0500000f0500000f0500000f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_1829 pv9_2192 rfl rfl
theorem pv9_1821 : PetersenPackedPin.project r9 (0xf0f00000f0000000f0f00000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_1829 pv9_7855 rfl rfl
theorem pv9_2063 : PetersenPackedPin.project r9 (0x300030003000300030003000300030 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_2298 pv9_4814 rfl rfl
theorem pv9_2099 : PetersenPackedPin.project r9 (0x500050005000500050005000500050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_2298 pv9_4260 rfl rfl
theorem pv9_2154 : PetersenPackedPin.project r9 (0xa000a000a000a000a000a000a000a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_2192 pv9_5473 rfl rfl
theorem pv9_2288 : PetersenPackedPin.project r9 (0xf0005000f0005000f0005000f00050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_1734 pv9_2298 rfl rfl
theorem pv9_2402 : PetersenPackedPin.project r9 (0xff00f000ff00f000ff00f000ff00f0 : BitVec 128) = 0xf000f000f000f00 := PetersenWireProjection.derive 2 pv9_6170 pv9_7235 rfl rfl
theorem pv9_2743 : PetersenPackedPin.project r9 (0xa0afafa0a0afafa0a0afafa0a0afafa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 2 pv9_5294 pv9_5850 rfl rfl
theorem pv9_2748 : PetersenPackedPin.project r9 (0xaaa0aaa0aaa0aaa0aaa0aaa0aaa0aaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv9_4260 pv9_5241 rfl rfl
theorem pv9_2754 : PetersenPackedPin.project r9 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 2 pv9_5241 pv9_5850 rfl rfl
theorem pv9_3057 : PetersenPackedPin.project r9 (0xfaf0faf00aa00aa0faf0faf00aa00aa : BitVec 128) = 0xffff0a0affff0a0a := PetersenWireProjection.derive 3 pv9_2192 pv9_2963 rfl rfl
theorem pv9_3063 : PetersenPackedPin.project r9 (0x10101010101010101010101010101010 : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv9_3209 pv9_4260 rfl rfl
theorem pv9_3180 : PetersenPackedPin.project r9 (0x30103010301030103010301030103010 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_2192 pv9_3209 rfl rfl
theorem pv9_3186 : PetersenPackedPin.project r9 (0x30301010303010103030101030301010 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_1734 pv9_3209 rfl rfl
theorem pv9_3187 : PetersenPackedPin.project r9 (0x30302020303020203030202030302020 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_3209 pv9_7095 rfl rfl
theorem pv9_3276 : PetersenPackedPin.project r9 (0x32323232323232323232323232323232 : BitVec 128) = 0x2222222222222222 := PetersenWireProjection.derive 2 pv9_4814 pv9_5850 rfl rfl
theorem pv9_3822 : PetersenPackedPin.project r9 (0x5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a5a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 2 pv9_3980 pv9_5850 rfl rfl
theorem pv9_4366 : PetersenPackedPin.project r9 (0xafaf0000afaf0000afaf0000afaf0000 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 2 pv9_3632 pv9_6790 rfl rfl
theorem pv9_4375 : PetersenPackedPin.project r9 (0xafafafaf00000000afafafaf00000000 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 2 pv9_3632 pv9_7474 rfl rfl
theorem pv9_4481 : PetersenPackedPin.project r9 (0xc0c0eaeac0c0eaeac0c0eaeac0c0eaea : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv9_1734 pv9_4429 rfl rfl
theorem pv9_4490 : PetersenPackedPin.project r9 (0xc0eac0eac0eac0eac0eac0eac0eac0ea : BitVec 128) = 0xa0a0a0a0a0a0a0a := PetersenWireProjection.derive 3 pv9_2192 pv9_4429 rfl rfl
theorem pv9_4514 : PetersenPackedPin.project r9 (0xc8c8c8c8c8c8c8c8c8c8c8c8c8c8c8c8 : BitVec 128) = 0x8888888888888888 := PetersenWireProjection.derive 0 pv9_4814 pv9_5850 rfl rfl
theorem pv9_5149 : PetersenPackedPin.project r9 (0xe0e0e0e0e0e0e0e0e0e0e0e0e0e0e0e0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5224 pv9_5473 rfl rfl
theorem pv9_5281 : PetersenPackedPin.project r9 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_2192 pv9_5473 rfl rfl
theorem pv9_5284 : PetersenPackedPin.project r9 (0xf0a0f0a0f0a0f0a0f0a0f0a0f0a0f0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_6504 rfl rfl
theorem pv9_5288 : PetersenPackedPin.project r9 (0xf0c0f0c0f0c0f0c0f0c0f0c0f0c0f0c0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_6546 rfl rfl
theorem pv9_5328 : PetersenPackedPin.project r9 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv9_1734 pv9_5473 rfl rfl
theorem pv9_5335 : PetersenPackedPin.project r9 (0xf0f0a0a0f0f0a0a0f0f0a0a0f0f0a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_7095 rfl rfl
theorem pv9_5408 : PetersenPackedPin.project r9 (0xf0f0f0f0f000f000f0f0f0f0f000f000 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_7855 rfl rfl
theorem pv9_5555 : PetersenPackedPin.project r9 (0xf0f0fafa0000aaaaf0f0fafa0000aaaa : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv9_1734 pv9_5367 rfl rfl
theorem pv9_5562 : PetersenPackedPin.project r9 (0xf0f0fafaf0f0fafa0000aaaa0000aaaa : BitVec 128) = 0xaa00aa00aa00aa := PetersenWireProjection.derive 3 pv9_1734 pv9_5425 rfl rfl
theorem pv9_5682 : PetersenPackedPin.project r9 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x5050505050505050 := PetersenWireProjection.derive 2 pv9_2708 pv9_6170 rfl rfl
theorem pv9_6308 : PetersenPackedPin.project r9 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xfafafafafafafafa := PetersenWireProjection.derive 3 pv9_2708 pv9_6170 rfl rfl
theorem pv9_6456 : PetersenPackedPin.project r9 (0xffa0ffa0ffa0ffa0ffa0ffa0ffa0ffa0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 3 pv9_3980 pv9_6170 rfl rfl
theorem pv9_6952 : PetersenPackedPin.project r9 (0xffff5050ffff5050ffff5050ffff5050 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv9_3632 pv9_6790 rfl rfl
theorem pv9_7650 : PetersenPackedPin.project r9 (0xffffffff50505050ffffffff50505050 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_3632 pv9_7474 rfl rfl
theorem pv9_8310 : PetersenPackedPin.project r9 (0xffffffffffffffffff50ff50ff50ff50 : BitVec 128) = 0xfffffffff0f0f0f0 := PetersenWireProjection.derive 3 pv9_3632 pv9_8295 rfl rfl
theorem pv9_3055 : PetersenPackedPin.project r9 (0xfaf0faf000000000faf0faf00000000 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 0 pv9_3057 pv9_7474 rfl rfl
theorem pv9_4480 : PetersenPackedPin.project r9 (0xc0c0e0e0c0c0e0e0c0c0e0e0c0c0e0e0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_4481 pv9_5473 rfl rfl
theorem pv9_4489 : PetersenPackedPin.project r9 (0xc0e0c0e0c0e0c0e0c0e0c0e0c0e0c0e0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_4490 pv9_5473 rfl rfl
theorem pv9_5383 : PetersenPackedPin.project r9 (0xf0f0f0f00000a0a0f0f0f0f00000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_5555 rfl rfl
theorem pv9_5433 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f00000a0a00000a0a0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_5562 rfl rfl
theorem pv9_5458 : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0f050f050f050f050 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv9_5473 pv9_8310 rfl rfl
theorem pv9_5876 : PetersenPackedPin.project r9 (0xfcdcfcdcfcdcfcdcfcdcfcdcfcdcfcdc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv9_3180 pv9_4814 rfl rfl
theorem pv9_5892 : PetersenPackedPin.project r9 (0xfcfcdcdcfcfcdcdcfcfcdcdcfcfcdcdc : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv9_3186 pv9_4814 rfl rfl
theorem pv9_5895 : PetersenPackedPin.project r9 (0xfcfcececfcfcececfcfcececfcfcecec : BitVec 128) = 0xcccccccccccccccc := PetersenWireProjection.derive 3 pv9_3187 pv9_4814 rfl rfl
theorem pv9_7213 : PetersenPackedPin.project r9 (0xfffff050fffff050fffff050fffff050 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv9_1817 pv9_6790 rfl rfl
theorem pv9_7223 : PetersenPackedPin.project r9 (0xfffff0f0fffff000fffff0f0fffff000 : BitVec 128) = 0xff00ff00ff00ff00 := PetersenWireProjection.derive 3 pv9_1821 pv9_6790 rfl rfl
theorem pv9_7518 : PetersenPackedPin.project r9 (0xffffffff00005050ffffffff00005050 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_723 pv9_7474 rfl rfl
theorem pv9_7752 : PetersenPackedPin.project r9 (0xfffffffff050f050fffffffff050f050 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_1164 pv9_7474 rfl rfl
theorem pv9_7756 : PetersenPackedPin.project r9 (0xfffffffff0f05050fffffffff0f05050 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_1168 pv9_7474 rfl rfl
theorem pv9_7758 : PetersenPackedPin.project r9 (0xfffffffff0f0a0a0fffffffff0f0a0a0 : BitVec 128) = 0xffff0000ffff0000 := PetersenWireProjection.derive 3 pv9_1169 pv9_7474 rfl rfl
theorem pv9_8241 : PetersenPackedPin.project r9 (0xfffffffffffffffff050f050f050f050 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv9_443 pv9_8012 rfl rfl
theorem pv9_8242 : PetersenPackedPin.project r9 (0xfffffffffffffffff0f05050f0f05050 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv9_447 pv9_8012 rfl rfl
theorem pv9_8243 : PetersenPackedPin.project r9 (0xfffffffffffffffff0f0a0a0f0f0a0a0 : BitVec 128) = 0xffffffff00000000 := PetersenWireProjection.derive 3 pv9_448 pv9_8012 rfl rfl
theorem pv9_6468 : PetersenPackedPin.project r9 (0xffaaf0a0ffaaf000ffaaf0a0ffaaf000 : BitVec 128) = 0xfa00fa00fa00fa00 := PetersenWireProjection.derive 0 pv9_6504 pv9_7223 rfl rfl
end PetersenSmallStarts.M191.Residual
