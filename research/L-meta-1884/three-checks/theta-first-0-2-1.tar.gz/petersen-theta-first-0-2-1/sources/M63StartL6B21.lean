import M63StartData
import M63StartPins0
import M63StartL5B19
import M63StartL5B16
import M63StartL5B20
import M63StartL5B4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b686 : Blocked tgt 6 s686 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s686 6 _ le
  decide +kernel
theorem b687 : Blocked tgt 6 s687 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s687 6 _ le
  decide +kernel
theorem b688 : Blocked tgt 6 s688 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s688 6 _ le
  decide +kernel
theorem b689 : Blocked tgt 6 s689 := by
  apply PetersenFastNode.node (nxt := #[s690,s691]) (hints := [3446,391,3510,3446,2796,779,3508,2796,3316,2284,3764,3316,2796,2292,3756,2796,2406,2796,2796,2406,716,748,2764,716,843,455,843,971,455,3636,839,455,455,3510,3510,455,455,3510,715,455,455,1462,2375,455,3508,839,835,835,843,3508,3756,843,843,2988,3508,843,843,2119,2635,843,839,3756,3748,839,839,3764,3764,839,839,2123,2375,839,1351,1351,2375,1708,2375,1676,2375,0,2375,1]) (by decide +kernel)
  change ∀ b ∈ [s690,s691], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s691) b691 <|
    PetersenLocalChildren.nil
theorem b692 : Blocked tgt 6 s692 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s692 6 _ le
  decide +kernel
theorem b693 : Blocked tgt 6 s693 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s693 6 _ le
  decide +kernel
theorem b694 : Blocked tgt 6 s694 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s694 6 _ le
  decide +kernel
theorem b695 : Blocked tgt 6 s695 := by
  apply PetersenFastNode.node (nxt := #[s696,s572,s697,s698,s699,s701,s179,s180,s690,s702]) (hints := [3454,3454,3518,399,724,463,3518,724,3518,3454,3454,463,724,724,2964,787,3454,851,2964,3454,2964,724,724,851,1244,1244,1692,212,724,847,1692,724,1692,1244,1244,847,724,724,1684,220,1244,1359,1684,1244,1684,724,724,1359,1374,1374,0,724,724,2383,724,724,1,1374,1374,2383,851,2,851,463,463,2964,851,463,851,979,3,2964,463,463,847,1692,4,1692,847,5,847,463,463,1692,463,463,1359,2494,3518,1684,1359,3518,1359,463,463,1684,463,463,2383,1470,3518,6,2383,3518,2383,463,463,7,1692,3484,1692,847,851,847,843,851,1692,843,3484,847,851,851,1619,1103,3484,1359,1619,3484,1619,851,851,1359,851,851,2643,2127,2964,2383,2643,2964,2643,851,851,2383,847,847,1359,1107,1692,1619,1359,1692,1359,847,847,1619,847,847,2383,2131,1692,2643,2383,1692,2383,847,847,2643,1359,1359,2383,1684,1684,8,2383,1684,2383,1359,1359,9]) (by decide +kernel)
  change ∀ b ∈ [s696,s572,s697,s698,s699,s701,s179,s180,s690,s702], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s696) b696 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s697) b697 <|
    PetersenLocalChildren.push (x := s698) b698 <|
    PetersenLocalChildren.push (x := s699) b699 <|
    PetersenLocalChildren.push (x := s701) b701 <|
    PetersenLocalChildren.push (x := s179) b179 <|
    PetersenLocalChildren.push (x := s180) b180 <|
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s702) b702 <|
    PetersenLocalChildren.nil
theorem b703 : Blocked tgt 6 s703 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s703 6 _ le
  decide +kernel
theorem b704 : Blocked tgt 6 s704 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s704 6 _ le
  decide +kernel
theorem b705 : Blocked tgt 6 s705 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s705 6 _ le
  decide +kernel
theorem b706 : Blocked tgt 6 s706 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s706 6 _ le
  decide +kernel
theorem b707 : Blocked tgt 6 s707 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s707 6 _ le
  decide +kernel
theorem b708 : Blocked tgt 6 s708 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s708 6 _ le
  decide +kernel
theorem b709 : Blocked tgt 6 s709 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(1,false),(2,true))] s709 6 _ le
  decide +kernel
theorem b710 : Blocked tgt 6 s710 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s710 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
