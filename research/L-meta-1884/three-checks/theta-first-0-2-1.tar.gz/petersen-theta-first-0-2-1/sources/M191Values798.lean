import higher.WireProjection
import M191StartPreferredCuts7
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv798_4260 : PetersenPackedPin.project r798 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc := by decide +kernel
theorem pv798_5473 : PetersenPackedPin.project r798 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0x0 := by decide +kernel
theorem pv798_6170 : PetersenPackedPin.project r798 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv798_6790 : PetersenPackedPin.project r798 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv798_7474 : PetersenPackedPin.project r798 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv798_8012 : PetersenPackedPin.project r798 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
end PetersenSmallStarts.M191.Residual
