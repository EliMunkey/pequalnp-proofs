import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv759_4260 : PetersenPackedPin.project r759 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv759_4814 : PetersenPackedPin.project r759 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv759_5473 : PetersenPackedPin.project r759 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv759_6170 : PetersenPackedPin.project r759 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv759_6790 : PetersenPackedPin.project r759 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv759_7474 : PetersenPackedPin.project r759 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv759_8012 : PetersenPackedPin.project r759 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv759_1734 : PetersenPackedPin.project r759 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv759_4260 pv759_6790 rfl rfl
theorem pv759_3730 : PetersenPackedPin.project r759 (0x55555555000000005555555500000000 : BitVec 128) = 0x55550000 := PetersenWireProjection.derive 2 pv759_4260 pv759_7474 rfl rfl
theorem pv759_6504 : PetersenPackedPin.project r759 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv759_4260 pv759_6170 rfl rfl
theorem pv759_7095 : PetersenPackedPin.project r759 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv759_4260 pv759_6790 rfl rfl
theorem pv759_7855 : PetersenPackedPin.project r759 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv759_6170 pv759_7474 rfl rfl
theorem pv759_7944 : PetersenPackedPin.project r759 (0xffffffffffff0000ffffffffffff0000 : BitVec 128) = 0xffff0000 := PetersenWireProjection.derive 3 pv759_6790 pv759_7474 rfl rfl
theorem pv759_3744 : PetersenPackedPin.project r759 (0x55555555550055005555555555005500 : BitVec 128) = 0x55550000 := PetersenWireProjection.derive 2 pv759_4260 pv759_7855 rfl rfl
theorem pv759_3753 : PetersenPackedPin.project r759 (0x55555555555500005555555555550000 : BitVec 128) = 0x55550000 := PetersenWireProjection.derive 2 pv759_4260 pv759_7944 rfl rfl
end PetersenSmallStarts.M191.Residual
