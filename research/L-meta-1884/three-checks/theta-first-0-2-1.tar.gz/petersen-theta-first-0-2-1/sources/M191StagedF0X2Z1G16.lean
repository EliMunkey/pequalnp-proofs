import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values19
import M191Values2
import M191Values21
import M191Values22
import M191Values32
import M191Values35
import M191Values5
import M191Values739
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows19
import M191StartPreferredRows20
import ResidualFast
import ThetaClosing
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4371 : Blocked tgt 7 s4371 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4371 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x0,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3315 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5978 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b4372 : Blocked tgt 7 s4372 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4372 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0xaaaa,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2362 (PetersenWireProjection.cons pv10_3315 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b4380 : Blocked tgt 7 s4380 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4380 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2240 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4381 : Blocked tgt 7 s4381 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4381 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2224 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_7712 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4382 : Blocked tgt 7 s4382 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4382 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6099 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4383 : Blocked tgt 7 s4383 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4383 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_981 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4384 : Blocked tgt 7 s4384 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4384 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2441 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4385 : Blocked tgt 7 s4385 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4385 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff0aff0acc08cc08ff0aff0acc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4386 : Blocked tgt 7 s4386 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4386 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xf500f500c400c400f500f500c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4391 : Blocked tgt 7 s4391 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4391 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4565 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 (PetersenWireProjection.cons pv1_8208 rfl)))))))) (by decide +kernel)
theorem b4392 : Blocked tgt 7 s4392 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4392 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6148 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4393 : Blocked tgt 7 s4393 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4393 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_251 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4394 : Blocked tgt 7 s4394 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4394 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xff00ff00ff00ff00cc00cc00cc00cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b4395 : Blocked tgt 7 s4395 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4395 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff0aff0aff0aff0acc08cc08cc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4396 : Blocked tgt 7 s4396 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s4396 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xf500f500f500f500c400c400c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_4260 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b4401 : Blocked tgt 7 s4401 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s4401 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xaaa0aaa0aaa0aaa0aaa0aaa0aaa0aaa0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6308 (PetersenWireProjection.cons pv21_6618 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)

theorem b4402 : Blocked tgt 7 s4402 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4402 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4097 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4403 : Blocked tgt 7 s4403 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4403 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4404 : Blocked tgt 7 s4404 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s4404 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3690 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6308 (PetersenWireProjection.cons pv21_6618 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b4405 : Blocked tgt 7 s4405 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4405 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4582 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4406 : Blocked tgt 7 s4406 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4406 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2029 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4407 : Blocked tgt 7 s4407 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,6836,4522,6836,901,901,5930,9929,9921,9921,7474,1669,7474,1669,10433,2693,10433,2693,12481,4741,12481,4741,13610,8837,13610,8837,6836,4266,4522,6836,5288,9801,5672,5288,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,9929,5930,9929,8641,1669,8641,1669,7472,2693,7466,2693,8641,4741,13642,4741,8641,8837,449,8837,385,8905,8905,9929,1669,9929,2693,11465,9929,9929,4741,13513,9929,1673,1737,9865,1673,1669,11465,2693,1669,1669,13513,4741,1669,1669,13352,8837,1669,2693,3112,4741,2693,2693,3273,8837,2693,4741,5321,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4408 : Blocked tgt 7 s4408 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4408 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xa0a0a0a,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4409 : Blocked tgt 7 s4409 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4409 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4410 : Blocked tgt 7 s4410 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4410 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2298 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4411 : Blocked tgt 7 s4411 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4411 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2884 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6618 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4412 : Blocked tgt 7 s4412 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4412 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xa0a0a0a,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4413 : Blocked tgt 7 s4413 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4413 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4414 : Blocked tgt 7 s4414 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4414 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6618 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4415 : Blocked tgt 7 s4415 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4415 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6618 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4416 : Blocked tgt 7 s4416 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(2,false),(3,false))] s4416 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xfff0fff0fff0fff0fff0fff0fff0fff0,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xfff0fff0fff0fff0fff0fff0fff0fff0) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b4417 : Blocked tgt 7 s4417 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4417 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xff0aff0aff0aff0aff0aff0aff0aff0a,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6308 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b4418 : Blocked tgt 7 s4418 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4418 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6618 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8305 rfl)))))))) (by decide +kernel)
theorem b4419 : Blocked tgt 7 s4419 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s4419 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xff0aff0aff0aff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6618 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 rfl)))))))) (by decide +kernel)
theorem b4420 : Blocked tgt 7 s4420 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4420 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6598 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4421 : Blocked tgt 7 s4421 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4421 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffffff0fffffff0fffffff0fffffff0 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4422 : Blocked tgt 7 s4422 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4422 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1917 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4423 : Blocked tgt 7 s4423 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4423 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2032 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4424 : Blocked tgt 7 s4424 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4424 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6605 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4425 : Blocked tgt 7 s4425 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4425 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7931 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4426 : Blocked tgt 7 s4426 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4426 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1285 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4427 : Blocked tgt 7 s4427 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4427 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2037 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4428 : Blocked tgt 7 s4428 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4428 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6609 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4429 : Blocked tgt 7 s4429 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4429 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xfffffffffffffffffff0fff0fff0fff0 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b4430 : Blocked tgt 7 s4430 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,4522,8650,5546,8641,901,8641,901,9921,1673,9921,1665,11602,1669,7474,1669,10433,2693,10433,2693,12481,4741,12481,4741,8837,8837,6836,773,6964,6836,5546,1545,5930,5546,6836,5546,5546,6836,5546,4788,7466,5546,1418,1450,5514,1418,5546,458,8650,5546,1417,901,1673,1417,901,1417,1669,901,901,4916,2693,901,901,2868,4741,901,901,449,8577,901,4906,1669,1673,1669,1673,2693,3209,1673,1673,4741,5257,1673,1673,9921,9857,1673,1669,3209,2693,1669,1669,5257,4741,1669,1669,11602,14642,1669,2693,3370,4741,2693,2693,2241,10369,2693,4741,4289,12417,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4431 : Blocked tgt 7 s4431 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4431 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2042 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4447 : Blocked tgt 7 s4447 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4447 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6308 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4448 : Blocked tgt 7 s4448 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4448 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2418 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7774 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b4449 : Blocked tgt 7 s4449 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4449 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6107 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4450 : Blocked tgt 7 s4450 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4450 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_918 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4451 : Blocked tgt 7 s4451 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4451 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2448 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b4452 : Blocked tgt 7 s4452 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4452 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_7873 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4453 : Blocked tgt 7 s4453 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4453 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xf0f0f0f0,0x0] (PetersenWireProjection.cons pv5_2322 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7774 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4454 : Blocked tgt 7 s4454 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4454 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff0aff0af000f000ff0aff0af000f000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4455 : Blocked tgt 7 s4455 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4455 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf0a0f0a000000000f0a0f0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4456 : Blocked tgt 7 s4456 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4456 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf500f500f000f000f500f500f000f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b4457 : Blocked tgt 7 s4457 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4457 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_7760 rfl)))))))) (by decide +kernel)
theorem b4458 : Blocked tgt 7 s4458 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [13610,5546,1418,5546,8837,901,1417,901,9865,8837,1673,1673,8837,13610,13610,8837,8837,13610,13610,8837,8837,2693,3209,2693,8837,4741,5257,4741,6836,773,6964,6836,5546,6836,5930,5546,4522,4522,5546,6836,6836,5546,5546,6578,5546,4788,7466,5546,2708,5546,5546,2708,5672,901,901,5928,901,393,1409,901,901,1417,1417,901,901,4916,2693,901,901,2868,4741,901,6962,5930,5930,6962,6962,5930,5930,6962,5930,2693,7466,2693,1834,4741,5930,4741,1669,1669,2693,7466,2693,7466,4741,12425,4741,13441,2693,7466,2693,7466,4741,13449,4741,13449,2693,7466,4741,2693]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4463 : Blocked tgt 7 s4463 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4463 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8245 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b4464 : Blocked tgt 7 s4464 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4464 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2461 (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8245 rfl)))))))) (by decide +kernel)
theorem b4465 : Blocked tgt 7 s4465 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4465 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6156 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4466 : Blocked tgt 7 s4466 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4466 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_198 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4467 : Blocked tgt 7 s4467 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4467 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xff00ff00ff00ff00f000f000f000f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
theorem b4468 : Blocked tgt 7 s4468 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4468 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8245 (PetersenWireProjection.cons pv32_8305 rfl)))))))) (by decide +kernel)

theorem b4469 : Blocked tgt 7 s4469 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4469 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0xf0f0f0f0] (PetersenWireProjection.cons pv5_2327 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8245 rfl)))))))) (by decide +kernel)
theorem b4470 : Blocked tgt 7 s4470 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4470 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff0aff0aff0aff0af000f000f000f000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4471 : Blocked tgt 7 s4471 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4471 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf0a0f0a0f0a0f0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4594 : Blocked tgt 7 s4594 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4594 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xf0f0,0x0,0xcccc,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff00ff000a000a00ff00ff000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xffffffffff0aff0affffffffff0aff0a : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4595 : Blocked tgt 7 s4595 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s4595 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff00ff000a000a00ff00ff000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b4596 : Blocked tgt 7 s4596 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4596 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0x0,0xaaaa,0xcccc,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_531 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7873 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4597 : Blocked tgt 7 s4597 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4597 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffff0aff0affffffffff0aff0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4598 : Blocked tgt 7 s4598 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4598 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1925 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffff0aff0affffffffff0aff0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4599 : Blocked tgt 7 s4599 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4599 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xffff0000ff0a0000ffff0000ff0a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4600 : Blocked tgt 7 s4600 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4600 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffffffffffffff0affffffffffffff0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4601 : Blocked tgt 7 s4601 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4601 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500000000000000f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4602 : Blocked tgt 7 s4602 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4602 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0000ff0a0000ffff0000ff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b4603 : Blocked tgt 7 s4603 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4603 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffffffffff0aff0affffffffff0aff0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4604 : Blocked tgt 7 s4604 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4604 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4605 : Blocked tgt 7 s4605 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4605 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffffff0aff0a0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4606 : Blocked tgt 7 s4606 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4606 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0,0xffff] (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffffffffffffffffffff0aff0a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b4607 : Blocked tgt 7 s4607 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4607 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xffffffffff0aff0a : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b4608 : Blocked tgt 7 s4608 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4608 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf500f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4611 : Blocked tgt 7 s4611 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4611 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaa0aaa0a00000000aa0aaa0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4612 : Blocked tgt 7 s4612 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4612 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaaaaaaaaffaaffaaaaaaaaaaffaaffaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4613 : Blocked tgt 7 s4613 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4613 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaa00a000a0aaaaaaaa00a000a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4614 : Blocked tgt 7 s4614 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4614 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcc08cc0800000000cc08cc08 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4615 : Blocked tgt 7 s4615 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [10450,5546,5546,9672,6836,5546,5546,6836,5546,9801,5930,5546,6578,4522,7474,6578,5546,4530,7466,5546,9674,1450,13642,9674,5546,1482,13610,5546,901,901,9673,5930,9929,9673,8641,8649,9665,8641,9673,7466,11465,9673,9673,13642,13769,9673,1417,1481,9609,1417,8897,9929,5672,9929,7732,7474,1669,1669,2693,11465,2693,11465,4741,13513,4741,13642,8837,13610,8837,13610,6962,9929,9921,9921,9929,2693,11465,9929,9929,4229,13642,9929,1673,1737,9865,1673,10433,10441,10433,11457,4741,3378,4741,5765,8837,3410,8837,7474,11465,3370,4741,11465,3209,3273,11401,3209,4741,13610,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4616 : Blocked tgt 7 s4616 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4616 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccc00c400c4cccccccc00c400c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b4617 : Blocked tgt 7 s4617 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4617 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1161 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4618 : Blocked tgt 7 s4618 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xf0f0f0f0fffafffaf0f0f0f0fffafffa,0xaaaaaaaaaaaaaaaafffffafafffffafa),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000),(0xffff0000ffff0000ffff0000ffff0000,0xff00ff00ff00ff00ff00ff00ff00ff00),(0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000),(0xffffffffffffffff0000000000000000,0xffffffff00000000ffffffff00000000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=ThetaCert.s3_1370) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact ThetaCert.b3_1370
theorem b4621 : Blocked tgt 7 s4621 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4621 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f0f0f000f000f0f0f0f0f000f000f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4622 : Blocked tgt 7 s4622 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4622 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1252 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4623 : Blocked tgt 7 s4623 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4623 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xff00ff00ff0aff0aff00ff00ff0aff0a : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b4624 : Blocked tgt 7 s4624 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4624 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xff00ff00ff0aff0aff00ff00ff0aff0a : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b4625 : Blocked tgt 7 s4625 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4625 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff00ff00ff0aff0aff00ff00ff0aff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b4626 : Blocked tgt 7 s4626 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4626 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_766 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b4627 : Blocked tgt 7 s4627 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4627 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6055 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4628 : Blocked tgt 7 s4628 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4628 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff0aff0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xff0aff0a00000000ff0aff0a : BitVec 128) = 0xff0aff0a) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6055 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b4629 : Blocked tgt 7 s4629 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4629 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff0a000000000000ff0a0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b4630 : Blocked tgt 7 s4630 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4630 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffff0000ffffff0affff0000ffffff0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
