import M191StagedF0X2Z1
import SmallStartRelabel
open PetersenSmallStarts.M191.Preferred PetersenWordCost PetersenPackedPin PetersenLocalChildren
namespace PetersenSmallStarts.M191.OrbitF0X2Z1
set_option maxRecDepth 200000
set_option maxHeartbeats 0
private def a1 (x : Fin 128) : Fin 128 := (#[0,4,2,6,1,5,3,7,16,20,18,22,17,21,19,23,8,12,10,14,9,13,11,15,24,28,26,30,25,29,27,31,64,68,66,70,65,69,67,71,80,84,82,86,81,85,83,87,72,76,74,78,73,77,75,79,88,92,90,94,89,93,91,95,32,36,34,38,33,37,35,39,48,52,50,54,49,53,51,55,40,44,42,46,41,45,43,47,56,60,58,62,57,61,59,63,96,100,98,102,97,101,99,103,112,116,114,118,113,117,115,119,104,108,106,110,105,109,107,111,120,124,122,126,121,125,123,127] : Array (Fin 128))[x.val]?.getD 0
theorem gate_0_2_2 : NoAtMost (0x50505050505050505050505050505050 :: inputs 7) tgt 10 :=
  PetersenSmallStarts.relabel_aux a1 (by decide +kernel) (by decide +kernel) (a:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) (g:=0x50505050505050505050505050505050) (by decide +kernel) PetersenSmallStarts.M191.Preferred.gate_0_2_1
def forbidden : List (BitVec 128) := [0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0x50505050505050505050505050505050]
theorem all_forbidden : ∀ x ∈ forbidden, NoAtMost (x::inputs 7) tgt 10 :=
  PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 10) (x:=0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a) PetersenSmallStarts.M191.Preferred.gate_0_2_1 <|
  PetersenLocalChildren.push (P:=fun x => NoAtMost (x::inputs 7) tgt 10) (x:=0x50505050505050505050505050505050) gate_0_2_2 <|
  PetersenLocalChildren.nil
#print axioms all_forbidden
end PetersenSmallStarts.M191.OrbitF0X2Z1
