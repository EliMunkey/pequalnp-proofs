import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv774_4260 : PetersenPackedPin.project r774 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv774_4814 : PetersenPackedPin.project r774 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv774_5473 : PetersenPackedPin.project r774 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv774_6170 : PetersenPackedPin.project r774 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv774_6790 : PetersenPackedPin.project r774 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv774_7474 : PetersenPackedPin.project r774 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv774_8012 : PetersenPackedPin.project r774 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv774_8377 : PetersenPackedPin.project r774 (0xffffffffffffffffffffffff00000000 : BitVec 128) = 0xffffff00 := PetersenWireProjection.derive 3 pv774_7474 pv774_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
