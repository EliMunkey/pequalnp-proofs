import M191StartPreferredSignals
import M191StagedF0X2Z1G69
import M191StagedF0X2Z1G70
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G84
import M191StagedF0X2Z1G86
import M191StagedF0X2Z1G87
import M191StagedF0X2Z1G88
import M191StagedF0X2Z1G89
import M191StagedF0X2Z1G90
import M191StagedF0X2Z1G91
import M191StagedF0X2Z1G92
import M191StagedF0X2Z1G93
import M191StagedF0X2Z1G94
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows14
import M191StartPreferredRows18
import M191StartPreferredRows21
import M191StartPreferredRows23
import M191StartPreferredRows24
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows29
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows59
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
import M191StartPreferredRows69
import M191StartPreferredRows7
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair1i0 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2,s3,s4,s136,s332]) (hints := [5551,0,6841,1,5551,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s2,s3,s4,s136,s332], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2) (b2) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s3) (b3) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s4) (b4) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s136) (b136) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s332) (b332) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i1 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s333,s334,s335,s921,s1187,s1707,s1708,s1709]) (hints := [909,0,909,1,9681,2,9681,3,909,4,909,5,9681,6,9681,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s333,s334,s335,s921,s1187,s1707,s1708,s1709], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s333) (b333) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s334) (b334) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s335) (b335) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s921) (b921) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s1187) (b1187) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s1707) (b1707) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s1708) (b1708) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s1709) (b1709) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i2 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s2,s3,s1710,s2585,s2896]) (hints := [9934,0,5935,1,9934,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s2,s3,s1710,s2585,s2896], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2) (b2) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s3) (b3) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s1710) (b1710) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2585) (b2585) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2896) (b2896) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i3 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3222,s3223,s3224,s4213,s4734,s5260,s5477,s5831,s5832,s6098,s6099,s6551]) (hints := [1681,0,1681,1,2,3,4,5,1681,6,1681,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s3222,s3223,s3224,s4213,s4734,s5260,s5477,s5831,s5832,s6098,s6099,s6551], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s3222) (b3222) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s3223) (b3223) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s3224) (b3224) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s4213) (b4213) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s4734) (b4734) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s5260) (b5260) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s5477) (b5477) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s5831) (b5831) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s5832) (b5832) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6098) (b6098) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6099) (b6099) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6551) (b6551) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i4 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6552,s6553,s6554,s6983,s7142,s7566,s7567,s7568]) (hints := [2701,0,2701,1,11473,2,11473,3,2701,4,2701,5,11473,6,11473,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6552,s6553,s6554,s6983,s7142,s7566,s7567,s7568], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6552) (b6552) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6553) (b6553) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6554) (b6554) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s6983) (b6983) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7142) (b7142) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7566) (b7566) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7567) (b7567) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7568) (b7568) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i5 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7569,s7570,s7571,s7934,s8040,s8462,s8463,s8464]) (hints := [4749,0,4749,1,13521,2,13521,3,4749,4,4749,5,13521,6,13521,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s7569,s7570,s7571,s7934,s8040,s8462,s8463,s8464], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7569) (b7569) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7570) (b7570) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7571) (b7571) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s7934) (b7934) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8040) (b8040) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8462) (b8462) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8463) (b8463) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8464) (b8464) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i6 : PetersenLocalChildren.PairOK tgt 9 s1 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s8465,s8466,s8467,s9425,s9866,s10104,s10196,s10541,s10542,s10804,s10805,s10978]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s8465,s8466,s8467,s9425,s9866,s10104,s10196,s10541,s10542,s10804,s10805,s10978], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8465) (b8465) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8466) (b8466) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s8467) (b8467) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s9425) (b9425) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s9866) (b9866) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10104) (b10104) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10196) (b10196) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10541) (b10541) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10542) (b10542) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10804) (b10804) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10805) (b10805) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10978) (b10978) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i7 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10979,s10980,s11232,s11311,s11523,s11524]) (hints := [6842,6842,6970,0,9679,1,9679,2,6970,3,6970,4,9679,6842,9679,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s10979,s10980,s11232,s11311,s11523,s11524], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10979) (b10979) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s10980) (b10980) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11232) (b11232) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11311) (b11311) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11523) (b11523) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11524) (b11524) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i8 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s136,s332,s2585,s2896,s11525,s11803,s12063]) (hints := [5937,0,5937,1,6843,6843,2,3,6065,4,5,6]) (by decide +kernel) ?_
  change ∀ x ∈ [s136,s332,s2585,s2896,s11525,s11803,s12063], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s136) (b136) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s332) (b332) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2585) (b2585) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s2896) (b2896) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11525) (b11525) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s11803) (b11803) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12063) (b12063) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i9 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12294,s12295,s12688,s12798,s12947,s12948]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12294,s12295,s12688,s12798,s12947,s12948], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12294) (b12294) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12295) (b12295) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12688) (b12688) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12798) (b12798) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12947) (b12947) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12948) (b12948) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i10 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12949,s12950,s12997,s12998]) (hints := [7470,4776,7470,0,11469,6840,11469,1,7470,6840,7470,2,11469,4776,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12949,s12950,s12997,s12998], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12949) (b12949) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12950) (b12950) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12997) (b12997) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12998) (b12998) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i11 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12999,s13000,s13043,s13044]) (hints := [13646,2712,13646,0,13517,6840,13517,1,13646,6840,13646,2,13517,2712,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12999,s13000,s13043,s13044], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s12999) (b12999) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13000) (b13000) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13043) (b13043) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13044) (b13044) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i12 : PetersenLocalChildren.PairOK tgt 9 s1 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13045,s13046,s13418,s13501,s13649,s13650]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s13045,s13046,s13418,s13501,s13649,s13650], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13045) (b13045) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13046) (b13046) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13418) (b13418) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13501) (b13501) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13649) (b13649) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13650) (b13650) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i13 : PetersenLocalChildren.PairOK tgt 9 s1 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13651,s13652,s13759,s13760]) (hints := [9677,9677,5676,0,905,905,5934,1,905,905,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13651,s13652,s13759,s13760], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13651) (b13651) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13652) (b13652) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13759) (b13759) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13760) (b13760) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i14 : PetersenLocalChildren.PairOK tgt 9 s1 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13841,s13842,s13988,s13989]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13841,s13842,s13988,s13989], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13841) (b13841) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13842) (b13842) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13988) (b13988) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13989) (b13989) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i15 : PetersenLocalChildren.PairOK tgt 9 s1 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13990,s13991,s14077,s14078]) (hints := [9677,9677,11469,0,4920,6968,7470,1,11469,6968,11469,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s13990,s13991,s14077,s14078], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13990) (b13990) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s13991) (b13991) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14077) (b14077) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14078) (b14078) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i16 : PetersenLocalChildren.PairOK tgt 9 s1 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14079,s14080,s14160,s14161]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14079,s14080,s14160,s14161], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14079) (b14079) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14080) (b14080) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14160) (b14160) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14161) (b14161) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i17 : PetersenLocalChildren.PairOK tgt 9 s1 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14162,s14163,s14283,s14284]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14162,s14163,s14283,s14284], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14162) (b14162) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14163) (b14163) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14283) (b14283) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14284) (b14284) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i18 : PetersenLocalChildren.PairOK tgt 9 s1 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14285,s14286,s14387,s14490]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14285,s14286,s14387,s14490], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14285) (b14285) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14286) (b14286) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14387) (b14387) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14490) (b14490) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i19 : PetersenLocalChildren.PairOK tgt 9 s1 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14491,s14492,s14622,s14693]) (hints := [11469,5934,11469,0,2697,6966,2697,1,11469,6966,11469,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14491,s14492,s14622,s14693], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14491) (b14491) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14492) (b14492) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14622) (b14622) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14693) (b14693) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i20 : PetersenLocalChildren.PairOK tgt 9 s1 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14694,s14695,s14826,s14898]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14694,s14695,s14826,s14898], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14694) (b14694) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14695) (b14695) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14826) (b14826) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14898) (b14898) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i21 : PetersenLocalChildren.PairOK tgt 9 s1 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14899,s14900,s14987,s15084]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14899,s14900,s14987,s15084], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14899) (b14899) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14900) (b14900) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s14987) (b14987) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15084) (b15084) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i22 : PetersenLocalChildren.PairOK tgt 9 s1 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15085,s15086,s15087,s15088]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15085,s15086,s15087,s15088], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15085) (b15085) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15086) (b15086) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15087) (b15087) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15088) (b15088) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i23 : PetersenLocalChildren.PairOK tgt 9 s1 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15089,s15090,s15181,s15182]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15089,s15090,s15181,s15182], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15089) (b15089) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15090) (b15090) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15181) (b15181) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15182) (b15182) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i24 : PetersenLocalChildren.PairOK tgt 9 s1 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15183,s15184,s15329,s15330]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15183,s15184,s15329,s15330], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15183) (b15183) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15184) (b15184) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15329) (b15329) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15330) (b15330) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i25 : PetersenLocalChildren.PairOK tgt 9 s1 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15331,s15332,s15454,s15455]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15331,s15332,s15454,s15455], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15331) (b15331) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15332) (b15332) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15454) (b15454) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15455) (b15455) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i26 : PetersenLocalChildren.PairOK tgt 9 s1 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15456,s15457,s15544,s15545]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15456,s15457,s15544,s15545], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15456) (b15456) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15457) (b15457) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15544) (b15544) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15545) (b15545) <|
    PetersenLocalChildren.nil
private theorem thetaPair1i27 : PetersenLocalChildren.PairOK tgt 9 s1 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s15546,s15547,s15548,s15549]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s15546,s15547,s15548,s15549], Blocked tgt 9 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15546) (b15546) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15547) (b15547) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15548) (b15548) <|
    PetersenLocalChildren.push (P := Blocked tgt 9) (x := s15549) (b15549) <|
    PetersenLocalChildren.nil
theorem b1 : Blocked tgt 10 s1 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 9 s1 p
  exact
    PetersenLocalChildren.push thetaPair1i0 <|
    PetersenLocalChildren.push thetaPair1i1 <|
    PetersenLocalChildren.push thetaPair1i2 <|
    PetersenLocalChildren.push thetaPair1i3 <|
    PetersenLocalChildren.push thetaPair1i4 <|
    PetersenLocalChildren.push thetaPair1i5 <|
    PetersenLocalChildren.push thetaPair1i6 <|
    PetersenLocalChildren.push thetaPair1i7 <|
    PetersenLocalChildren.push thetaPair1i8 <|
    PetersenLocalChildren.push thetaPair1i9 <|
    PetersenLocalChildren.push thetaPair1i10 <|
    PetersenLocalChildren.push thetaPair1i11 <|
    PetersenLocalChildren.push thetaPair1i12 <|
    PetersenLocalChildren.push thetaPair1i13 <|
    PetersenLocalChildren.push thetaPair1i14 <|
    PetersenLocalChildren.push thetaPair1i15 <|
    PetersenLocalChildren.push thetaPair1i16 <|
    PetersenLocalChildren.push thetaPair1i17 <|
    PetersenLocalChildren.push thetaPair1i18 <|
    PetersenLocalChildren.push thetaPair1i19 <|
    PetersenLocalChildren.push thetaPair1i20 <|
    PetersenLocalChildren.push thetaPair1i21 <|
    PetersenLocalChildren.push thetaPair1i22 <|
    PetersenLocalChildren.push thetaPair1i23 <|
    PetersenLocalChildren.push thetaPair1i24 <|
    PetersenLocalChildren.push thetaPair1i25 <|
    PetersenLocalChildren.push thetaPair1i26 <|
    PetersenLocalChildren.push thetaPair1i27 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
