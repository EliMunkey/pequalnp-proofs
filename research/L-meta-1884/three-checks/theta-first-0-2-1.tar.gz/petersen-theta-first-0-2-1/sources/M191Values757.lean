import higher.WireProjection
import M191StartPreferredCuts4
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv757_4260 : PetersenPackedPin.project r757 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv757_4814 : PetersenPackedPin.project r757 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv757_5473 : PetersenPackedPin.project r757 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv757_6170 : PetersenPackedPin.project r757 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv757_6790 : PetersenPackedPin.project r757 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv757_7474 : PetersenPackedPin.project r757 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv757_8012 : PetersenPackedPin.project r757 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv757_1177 : PetersenPackedPin.project r757 (0xf0f0f0f000000000f0f0f0f0 : BitVec 128) = 0xf0f0 := PetersenWireProjection.derive 1 pv757_5473 pv757_7474 rfl rfl
theorem pv757_1734 : PetersenPackedPin.project r757 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv757_4260 pv757_6790 rfl rfl
theorem pv757_2192 : PetersenPackedPin.project r757 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv757_4260 pv757_6170 rfl rfl
theorem pv757_3632 : PetersenPackedPin.project r757 (0x50505050505050505050505050505050 : BitVec 128) = 0x50505050 := PetersenWireProjection.derive 2 pv757_4260 pv757_5473 rfl rfl
theorem pv757_3677 : PetersenPackedPin.project r757 (0x55005500550055005500550055005500 : BitVec 128) = 0x0 := PetersenWireProjection.derive 2 pv757_4260 pv757_6170 rfl rfl
theorem pv757_7095 : PetersenPackedPin.project r757 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv757_4260 pv757_6790 rfl rfl
theorem pv757_1168 : PetersenPackedPin.project r757 (0xf0f0505000000000f0f05050 : BitVec 128) = 0x5050 := PetersenWireProjection.derive 1 pv757_1177 pv757_1734 rfl rfl
theorem pv757_5281 : PetersenPackedPin.project r757 (0xf050f050f050f050f050f050f050f050 : BitVec 128) = 0x50505050 := PetersenWireProjection.derive 2 pv757_2192 pv757_5473 rfl rfl
theorem pv757_5328 : PetersenPackedPin.project r757 (0xf0f05050f0f05050f0f05050f0f05050 : BitVec 128) = 0x50505050 := PetersenWireProjection.derive 2 pv757_1734 pv757_5473 rfl rfl
theorem pv757_7756 : PetersenPackedPin.project r757 (0xfffffffff0f05050fffffffff0f05050 : BitVec 128) = 0xffff5050 := PetersenWireProjection.derive 3 pv757_1168 pv757_7474 rfl rfl
end PetersenSmallStarts.M191.Residual
