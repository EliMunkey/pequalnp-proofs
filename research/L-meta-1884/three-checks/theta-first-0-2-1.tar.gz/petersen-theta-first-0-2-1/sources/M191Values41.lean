import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv41_4260 : PetersenPackedPin.project r41 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv41_4814 : PetersenPackedPin.project r41 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccc := by decide +kernel
theorem pv41_5473 : PetersenPackedPin.project r41 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv41_6170 : PetersenPackedPin.project r41 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv41_6790 : PetersenPackedPin.project r41 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv41_7474 : PetersenPackedPin.project r41 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv41_8012 : PetersenPackedPin.project r41 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv41_7855 : PetersenPackedPin.project r41 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv41_6170 pv41_7474 rfl rfl
theorem pv41_8295 : PetersenPackedPin.project r41 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv41_6170 pv41_8012 rfl rfl
end PetersenSmallStarts.M191.Residual
