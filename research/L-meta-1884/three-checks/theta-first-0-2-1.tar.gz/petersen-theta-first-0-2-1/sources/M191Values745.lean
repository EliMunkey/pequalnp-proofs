import higher.WireProjection
import M191StartPreferredCuts3
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv745_4260 : PetersenPackedPin.project r745 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv745_4814 : PetersenPackedPin.project r745 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv745_5473 : PetersenPackedPin.project r745 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv745_6170 : PetersenPackedPin.project r745 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv745_6790 : PetersenPackedPin.project r745 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv745_7474 : PetersenPackedPin.project r745 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv745_8012 : PetersenPackedPin.project r745 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv745_2708 : PetersenPackedPin.project r745 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0x0 := PetersenWireProjection.derive 1 pv745_4260 pv745_5473 rfl rfl
theorem pv745_6618 : PetersenPackedPin.project r745 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv745_5473 pv745_6170 rfl rfl
theorem pv745_3690 : PetersenPackedPin.project r745 (0x55505550555055505550555055505550 : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 2 pv745_4260 pv745_6618 rfl rfl
theorem pv745_5745 : PetersenPackedPin.project r745 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := PetersenWireProjection.derive 2 pv745_2708 pv745_8012 rfl rfl
theorem pv745_6308 : PetersenPackedPin.project r745 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv745_2708 pv745_6170 rfl rfl
theorem pv745_6659 : PetersenPackedPin.project r745 (0xfffafffafffafffafffafffafffafffa : BitVec 128) = 0xeeeeeeeeeeeeeeee := PetersenWireProjection.derive 3 pv745_4260 pv745_6618 rfl rfl
end PetersenSmallStarts.M191.Residual
