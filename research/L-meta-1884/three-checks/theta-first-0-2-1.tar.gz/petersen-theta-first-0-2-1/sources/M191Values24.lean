import higher.WireProjection
import M191StartPreferredCuts1
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv24_4260 : PetersenPackedPin.project r24 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaa := by decide +kernel
theorem pv24_4814 : PetersenPackedPin.project r24 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0x0 := by decide +kernel
theorem pv24_5473 : PetersenPackedPin.project r24 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccc := by decide +kernel
theorem pv24_6170 : PetersenPackedPin.project r24 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv24_6790 : PetersenPackedPin.project r24 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv24_7474 : PetersenPackedPin.project r24 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xf0f0 := by decide +kernel
theorem pv24_8012 : PetersenPackedPin.project r24 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00 := by decide +kernel
theorem pv24_7314 : PetersenPackedPin.project r24 (0xffffff00ffffff00ffffff00ffffff00 : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv24_6170 pv24_6790 rfl rfl
theorem pv24_7380 : PetersenPackedPin.project r24 (0xffffffccffffffccffffffccffffffcc : BitVec 128) = 0x0 := PetersenWireProjection.derive 3 pv24_4814 pv24_7314 rfl rfl
end PetersenSmallStarts.M191.Residual
