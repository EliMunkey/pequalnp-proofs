import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values22
import M191Values30
import M191Values32
import M191Values35
import M191Values5
import M191Values748
import M191Values8
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts3
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows36
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows40
import M191StartPreferredRows41
import M191StartPreferredRows42
import M191StartPreferredRows43
import M191StartPreferredRows44
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b7416 : Blocked tgt 7 s7416 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7416 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2418 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7417 : Blocked tgt 7 s7417 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7417 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00ff00ff00ff0000000a0000000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7418 : Blocked tgt 7 s7418 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7418 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8049 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffffff00ff0aff00ff0a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b7419 : Blocked tgt 7 s7419 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7419 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7420 : Blocked tgt 7 s7420 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7420 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xff00ff00ff00ff0000000a0000000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7421 : Blocked tgt 7 s7421 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7421 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6671 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7422 : Blocked tgt 7 s7422 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7422 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8049 rfl)))))))) (by decide +kernel)

theorem b7423 : Blocked tgt 7 s7423 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7423 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7424 : Blocked tgt 7 s7424 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7424 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1925 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7425 : Blocked tgt 7 s7425 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7425 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6738 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7426 : Blocked tgt 7 s7426 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7426 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8049 (PetersenWireProjection.cons pv14_8339 rfl)))))))) (by decide +kernel)
theorem b7427 : Blocked tgt 7 s7427 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7427 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_581 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7428 : Blocked tgt 7 s7428 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7428 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0000ffff00000a0a00000a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8049 rfl)))))))) (by decide +kernel)
theorem b7429 : Blocked tgt 7 s7429 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7429 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xffffffff0000000000000a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7430 : Blocked tgt 7 s7430 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7430 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffffffffffffffffffff00000a0a : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b7431 : Blocked tgt 7 s7431 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7431 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xfffff5f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7432 : Blocked tgt 7 s7432 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7432 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffff0000000000000a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7434 : Blocked tgt 7 s7434 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7434 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8049 rfl)))))))) (by decide +kernel)
theorem b7435 : Blocked tgt 7 s7435 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7435 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8049 rfl)))))))) (by decide +kernel)
theorem b7436 : Blocked tgt 7 s7436 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7436 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaaaaaaaaaaaaa00000a0a00000a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7437 : Blocked tgt 7 s7437 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7437 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xaaaaa0a0aaaaa0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7438 : Blocked tgt 7 s7438 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7438 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4753 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8049 rfl)))))))) (by decide +kernel)
theorem b7439 : Blocked tgt 7 s7439 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7439 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8049 (PetersenWireProjection.cons pv35_8208 rfl)))))))) (by decide +kernel)

theorem b7440 : Blocked tgt 7 s7440 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7440 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8049 rfl)))))))) (by decide +kernel)
theorem b7441 : Blocked tgt 7 s7441 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7441 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7442 : Blocked tgt 7 s7442 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7442 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xcccccccccccccccc0000080800000808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b7443 : Blocked tgt 7 s7443 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7443 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xccccc4c4ccccc4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b7444 : Blocked tgt 7 s7444 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7444 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0x33333333333333330000020200000202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b7445 : Blocked tgt 7 s7445 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7445 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8049 (PetersenWireProjection.cons pv35_8245 rfl)))))))) (by decide +kernel)
theorem b7446 : Blocked tgt 7 s7446 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7446 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3004 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7447 : Blocked tgt 7 s7447 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7447 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3008 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b7448 : Blocked tgt 7 s7448 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7448 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6120 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7449 : Blocked tgt 7 s7449 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s7449 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8049 (PetersenWireProjection.cons pv35_8295 rfl)))))))) (by decide +kernel)
theorem b7450 : Blocked tgt 7 s7450 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7450 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0a0a] (PetersenWireProjection.cons pv2_531 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8049 rfl)))))))) (by decide +kernel)
theorem b7451 : Blocked tgt 7 s7451 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7451 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2461 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7452 : Blocked tgt 7 s7452 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7452 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00ff00ff00ff0000000a0000000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b7453 : Blocked tgt 7 s7453 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7453 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffffffffffffffffff00ff0aff00ff0a : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b7454 : Blocked tgt 7 s7454 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7454 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b7455 : Blocked tgt 7 s7455 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7455 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xff00ff00ff00ff0000000a0000000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)

theorem b7456 : Blocked tgt 7 s7456 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7456 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8049 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b7457 : Blocked tgt 7 s7457 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7457 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8049 rfl)))))))) (by decide +kernel)
theorem b7458 : Blocked tgt 7 s7458 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7458 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7397 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7459 : Blocked tgt 7 s7459 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7459 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b7460 : Blocked tgt 7 s7460 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7460 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_630 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8049 rfl)))))))) (by decide +kernel)
theorem b7461 : Blocked tgt 7 s7461 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7461 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8049 rfl)))))))) (by decide +kernel)
theorem b7462 : Blocked tgt 7 s7462 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7462 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffff0000000000000a0a00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b7463 : Blocked tgt 7 s7463 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7463 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfffff5f500000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b7464 : Blocked tgt 7 s7464 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7464 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffff0000000000000a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b7465 : Blocked tgt 7 s7465 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,false),(5,true)),(true,(0,false),(8,false))] s7465 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff00000a0a00000a0a] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffffffffffffffff00000a0a00000a0a : BitVec 128) = 0xffffffffffffffff00000a0a00000a0a) rfl)))))))) (by decide +kernel)
theorem b7466 : Blocked tgt 7 s7466 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7466 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_60 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8049 rfl)))))))) (by decide +kernel)
theorem b7518 : Blocked tgt 7 s7518 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7518 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x808000008080000080800000808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 (PetersenWireProjection.cons pv1_8208 rfl)))))))) (by decide +kernel)
theorem b7519 : Blocked tgt 7 s7519 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s7519 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00f500ff00f500ff00f500ff00f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b7520 : Blocked tgt 7 s7520 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7520 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0xcccccccc] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfffff5f5fffff5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8208 rfl)))))))) (by decide +kernel)
theorem b7521 : Blocked tgt 7 s7521 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7521 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a00000a0a0000080800000808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b7522 : Blocked tgt 7 s7522 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7522 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x20200000202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b7523 : Blocked tgt 7 s7523 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s7523 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv22_4260 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xfffff5f5fffff5f5ccccc4c4ccccc4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl)))))))) (by decide +kernel)
theorem b7656 : Blocked tgt 7 s7656 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7656 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r19 (0xf5c4f5c400000000f5c4f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b7665 : Blocked tgt 7 s7665 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7665 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5f5c4c400000000f5f5c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b7753 : Blocked tgt 7 s7753 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7474,6578,4514,6578,1669,901,8641,901,7474,1669,1669,6962,1669,2693,10433,1669,1669,7474,12481,1669,1669,7474,7474,1669,1669,8837,3410,1669,6836,773,6964,6836,6578,6324,6962,6578,4772,6578,6578,4772,2482,2482,6578,2708,2708,6578,6578,10706,6578,8709,14642,6578,10832,901,901,6960,901,4916,2693,901,901,6964,6964,901,901,6964,6964,901,901,14386,8837,901,4914,2693,6962,2693,11090,6962,6962,11090,11090,6962,6962,11090,6962,8837,14642,8837,2693,7458,12481,2693,2693,11457,11457,2693,2693,14642,8837,2693,4741,4741,8837,14642,8837,14642,8837,14642,8837,14642]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil

theorem b7859 : Blocked tgt 7 s7859 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1450,6836,1450,6836,901,6964,13513,5672,14025,13513,1669,12489,1669,12481,13513,7208,2693,2693,13642,13513,4741,4741,8837,5321,8837,5257,6836,773,772,6836,5288,2228,5672,5288,6836,4264,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,5672,901,5672,9673,7732,8649,7732,901,7208,7466,7208,901,14416,9673,14416,901,14900,1481,14900,901,7216,7220,7216,7728,5672,10832,7208,5672,10832,5672,5672,10832,5672,14388,13352,5672,5668,5684,7716,5668,3604,3636,7700,3604,7732,3152,14900,7732,3112,3112,7208,14416,12836,12852,12836,14884,10772,10804,10772,14868]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8083 : Blocked tgt 7 s8083 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s8083 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b8602 : Blocked tgt 7 s8602 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s8602 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffffffaaffaaffaaffaa : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)

theorem b8720 : Blocked tgt 7 s8720 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,5930,9737,5930,6058,7474,458,7474,2514,2256,1482,1482,2256,7466,466,7466,1482,1482,2740,5578,1482,13610,1482,5546,5546,1417,901,9865,1417,901,393,1669,901,901,385,901,4916,2693,901,901,2868,4741,901,901,1417,8837,901,8841,8841,9865,1669,9865,8833,3209,2693,3209,9865,5257,4741,5257,9865,1673,1673,9865,8837,1669,7216,1669,3209,2693,1669,1669,5257,4741,1669,1669,3410,8837,1669,2177,2693,2177,2693,4225,4741,4225,4741,14384,8837,14384,8837,2693,3370,4741,2693,2693,3209,8837,2693,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8721 : Blocked tgt 7 s8721 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,2514,1482,2514,1417,901,1417,901,9865,6962,9865,8833,1669,1669,3209,2693,3209,2693,5257,4741,5257,4741,13610,8837,13610,8837,6836,773,6964,6836,6962,6836,6962,7090,2514,1482,1482,2514,450,466,2498,450,2514,2740,6610,2514,14642,2514,6578,6578,10834,901,901,6962,901,1417,1409,901,901,4916,2693,901,901,2868,4741,901,901,14642,8837,901,6962,9865,9857,6962,4898,2693,6946,2693,11090,4741,14674,4741,6962,8837,14642,8837,2693,2185,2693,3201,4741,4233,4741,5249,8837,13610,8837,13610,2693,12626,4741,2693,2693,12594,8837,2693,4741,14642,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8741 : Blocked tgt 7 s8741 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,1417,1480,6836,5930,9737,5930,6058,2514,1482,1482,2514,2514,1482,1482,2514,7466,466,7466,1482,1482,2740,5578,1482,13610,1482,5546,5546,1417,5674,9865,1417,1669,1417,1669,1925,901,901,1417,385,2693,7210,2693,1417,4741,13386,4741,1417,8837,1417,8837,13608,8841,8841,9865,1669,6962,9865,9865,8833,3209,2693,3209,9865,5257,4741,5257,9865,1673,1673,9865,8837,1669,7474,1669,3209,2693,1669,1669,5257,4741,1669,1669,13610,8837,1669,2177,2693,2177,2693,4225,4741,4225,4741,14642,8837,14642,8837,2693,3370,4741,2693,2693,3209,8837,2693,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8794 : Blocked tgt 7 s8794 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,1482,6836,1482,901,1417,901,1417,9865,9865,1669,7474,1669,7474,2693,3209,2693,3209,4741,5257,4741,5257,8837,13610,8837,13610,6836,1417,1480,1417,1482,6836,6832,1482,7474,458,7474,2514,7466,466,7466,1482,1482,5257,5578,1482,13610,1482,5546,5546,1417,901,8833,1417,393,393,1417,7474,1417,7210,3209,1417,1417,13386,5257,1417,13352,1417,1417,13608,7474,1669,7474,8833,3209,2693,3209,8833,5257,4741,5257,8833,13610,8833,13610,8837,1669,3209,7458,3209,11602,5257,14674,5257,7474,3410,14642,7474,3209,3370,5257,3209,7466,3209,3209,7466,4741,5257,5257,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8952 : Blocked tgt 7 s8952 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,6836,1482,6836,901,901,5930,9865,8833,9865,7474,1669,7474,1669,2177,2693,2177,2693,4225,4741,4225,4741,13610,8837,13610,8837,6836,1482,1482,6836,5672,9737,5672,5800,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,9865,5930,9865,385,1669,7474,1669,385,2693,7466,2693,385,4741,13642,4741,385,8837,385,8837,13610,8841,8841,9865,1669,3209,2693,3209,9865,5257,4741,5257,9865,1673,1673,9865,8837,1669,3209,2693,1669,1669,5257,4741,1669,1669,13352,8837,1669,2693,3112,4741,2693,2693,3209,8837,2693,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b8977 : Blocked tgt 7 s8977 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,773,6964,6836,2256,1482,1482,2256,5930,6836,5930,6058,7474,458,7474,2514,7466,466,7466,1482,1482,2740,5578,1482,13610,1482,5546,5546,901,1417,9865,901,901,5930,901,7474,1925,901,901,4916,2693,901,901,2868,4741,901,901,13610,8837,901,9865,5930,9865,8833,1669,1669,7216,7474,3209,2693,3209,2693,5257,4741,5257,4741,13352,8837,13352,8837,6962,9865,9857,9857,3209,2693,3209,2693,5257,4741,5257,4741,1673,8837,9865,8837,2693,2185,2693,3201,4741,4233,4741,5249,8837,3410,8837,7474,2693,3370,4741,2693,2693,3209,8837,2693,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9010 : Blocked tgt 7 s9010 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,6836,1482,6836,901,901,5930,10832,9865,9865,7474,1669,7474,1669,7466,2693,3209,2693,5257,4741,5257,4741,13610,8837,13610,8837,6836,1417,1480,6836,2256,6836,6832,6832,6836,1541,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,10832,5930,10832,1417,1669,393,1669,385,2693,7466,2693,1417,4741,13386,4741,1417,8837,1417,8837,13608,7216,1669,7216,1669,8784,2693,10832,2693,10832,4741,14416,4741,14384,8837,14384,8837,1669,5684,2693,1669,1669,3636,4741,1669,1669,3152,8837,1669,2693,14416,4741,2693,2693,12852,8837,2693,4741,10804,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9022 : Blocked tgt 7 s9022 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7474,7474,450,2514,1669,2514,450,1669,450,7474,7474,2514,1669,1669,385,901,7474,901,385,7474,385,901,1669,901,9857,7474,9857,1669,1669,6962,8833,1669,9857,8833,7474,6962,1669,1669,3201,2693,7474,2693,2177,7474,3201,1669,1669,2693,1669,1669,4225,4741,7474,4741,4225,7474,4225,1669,1669,4741,1669,1669,12578,8837,11602,8837,3410,11602,12578,1669,1669,8837,6836,6836,6964,773,2514,901,6964,2514,6964,6836,6836,901,6962,2514,6962,6836,6836,9857,6962,6836,6962,7090,2514,9857,4772,4772,7458,2514,2514,2693,2514,2514,7458,4772,4772,2693,2514,2514,14674,2740,6836,4741,6610,6836,14674,2514,2514,4741,14642,6836,14642,2514,2514,8837,6578,2514,14642,6578,6836,8837,10832,385,10832,901,901,6962,901,901,10832,6960,385,6962,901,901,2693,4916,6964,7458,2693,6964,2693,901,901,7458,901,901,4741,2868,6964,14674,4741,6964,4741,901,901,14674,901,901,8837,14386,385,14642,8837,385,8837,901,901,14642,4914,9857,3201,2693,6962,2693,6962,6962,3201,2693,9857,2693,11090,11090,14674,4741,6962,4741,14674,6962,14674,4741,11090,4741,6962,6962,14642,8837,11090,8837,14642,11090,14642,8837,6962,8837,2693,2693,4741,14674,7458,14674,4741,7458,4741,2693,2693,14674,2693,2693,8837,14642,3201,14642,8837,3201,8837,2693,2693,14642,4741,4741,8837,14642,14674,14642,8837,14674,8837,4741,4741,14642]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9040 : Blocked tgt 7 s9040 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4772,773,4900,4772,6836,1482,1482,6836,5930,4772,5930,6058,7474,458,7474,2514,7466,466,7466,1482,1482,4741,5578,1482,13610,1482,5546,5546,901,1417,5674,901,901,5930,901,7474,1669,901,901,7466,2949,901,901,804,4741,901,901,13610,8837,901,10832,5930,9865,9865,7732,1669,7732,1669,2693,2693,3209,7466,5257,4741,5257,4741,14900,8837,14900,8837,6962,1669,7474,1669,3209,4914,3209,11913,5257,4741,5257,4741,5930,8837,13610,8837,1669,2185,2177,1669,1669,4233,4741,1669,1669,3410,8837,1669,4741,3370,4741,3209,8837,3209,8837,7466,4741,5257,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9200 : Blocked tgt 7 s9200 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,6836,1482,6836,901,1417,8833,9865,8833,9865,7474,7732,1669,1669,2693,3209,2693,3209,13642,5257,4741,4741,8837,14900,8837,14900,6836,773,2836,6836,5672,9737,5672,5800,6836,458,7732,6836,4772,4788,6820,4772,13321,6836,6836,5257,6836,1482,14900,6836,9865,901,9865,385,7732,7474,7732,901,3209,788,3209,901,5257,13642,5257,901,14900,385,14900,901,7216,9865,9865,7728,3209,2693,3209,9865,5257,1576,5257,9865,1673,1673,9865,5672,5668,3209,7716,3209,4233,4233,7732,5257,7732,12328,14900,7732,3209,3112,5257,3209,12836,3209,3209,14884,8837,5257,5257,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9203 : Blocked tgt 7 s9203 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [2514,1482,2514,1482,901,1417,901,1417,9865,9865,1669,7474,1669,7474,2693,3209,2693,3209,4741,5257,4741,5257,8837,13610,8837,13610,6836,1417,1480,1417,1482,6836,11090,1482,7474,1482,7474,2514,7466,3209,7466,1482,1482,5257,5578,1482,13610,1482,5546,5546,1417,901,8833,1417,7216,1417,1417,7472,1417,7210,3209,1417,1417,13386,5257,1417,13352,1417,1417,13608,7474,1669,7474,8833,3209,2693,3209,8833,5257,4741,5257,8833,13610,8833,13610,8837,1669,3209,7458,3209,4233,4233,7474,5257,7474,12586,14642,7474,3209,3370,5257,3209,7466,3209,3209,7466,4741,5257,5257,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9294 : Blocked tgt 7 s9294 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,6836,1482,6836,901,6964,9865,5672,9865,5672,1669,7732,1669,7732,7466,7208,2693,2693,13642,14416,4741,4741,8837,14900,8837,14900,6836,773,772,6836,5672,6836,5672,5800,6836,458,7732,6836,4772,4788,6820,4772,2708,2740,6804,2708,6836,2256,14900,6836,5672,901,5672,1417,7732,393,7732,901,7208,7466,7208,901,14416,13642,14416,901,14900,1417,14900,901,7216,7220,7216,7728,5672,10832,7208,5672,10832,5672,5672,10832,5672,14388,13352,5672,5668,5684,7716,5668,3604,3636,7700,3604,7732,3152,14900,7732,3112,3112,7208,14416,12836,12852,12836,14884,10772,10804,10772,14868]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9500 : Blocked tgt 7 s9500 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9500 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffffffccffccffccffcc : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b9501 : Blocked tgt 7 s9501 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9501 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffccffccffccffcc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl)))))))) (by decide +kernel)
theorem b9504 : Blocked tgt 7 s9504 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s9504 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5c4f5c4f5c4f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)

theorem b9519 : Blocked tgt 7 s9519 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s9519 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5f5c4c4f5f5c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b9610 : Blocked tgt 7 s9610 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9610 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6618 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons pv35_8295 rfl)))))))) (by decide +kernel)
theorem b9614 : Blocked tgt 7 s9614 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9614 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfffffffffffffffffff0fff0fff0fff0 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)

theorem b9615 : Blocked tgt 7 s9615 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9615 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfff0fff0fff0fff0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl)))))))) (by decide +kernel)
theorem b9618 : Blocked tgt 7 s9618 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s9618 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xf5f0f5f0f5f0f5f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4260 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b9625 : Blocked tgt 7 s9625 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [7474,10706,8642,7474,1669,901,8641,901,9921,1669,8897,8897,1669,2693,10433,1669,1669,4741,12481,1669,1669,11602,11602,1669,1669,11602,11602,1669,6836,773,6964,6836,6962,6836,6962,7090,4772,10706,10706,4772,10706,2740,14674,10706,2514,2514,10706,6836,6836,10706,6578,6578,10832,901,901,6960,901,4916,2693,901,901,2868,4741,901,901,449,8577,901,901,8641,8641,901,4914,2693,6962,2693,11090,4741,14674,4741,6962,11090,11090,6962,6962,11090,11090,6962,2693,14674,4741,2693,2693,3265,11393,2693,2693,11457,11457,2693,4741,14674,14674,4741,4741,14674,14674,4741,8837,8837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9631 : Blocked tgt 7 s9631 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9631 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xfffff0f0fffff0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl)))))))) (by decide +kernel)
theorem b9634 : Blocked tgt 7 s9634 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s9634 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0xf5f5f0f0f5f5f0f0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_4260 (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl)))))))) (by decide +kernel)

theorem b9699 : Blocked tgt 7 s9699 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1482,2256,1482,10448,901,1417,5930,9865,8833,9865,7474,11344,1669,1669,2693,3209,2693,3209,4741,5257,4741,5257,13610,13352,8837,8837,10448,773,6964,10448,5672,9737,5672,5800,10448,458,3280,3280,7208,3209,7208,3209,13321,5257,5320,5257,13352,10448,5288,5288,9865,901,9865,385,11344,7474,11344,901,3209,4916,3209,901,5257,2868,5257,901,13352,385,13352,901,8841,8841,9865,8897,3209,8784,3209,9865,5257,1576,5257,9865,1673,1673,9865,5672,10377,3209,3265,3209,12425,5257,5313,5257,3152,3152,11344,13352,3209,3112,5257,3209,7208,3209,3209,7208,4741,5257,5257,13320]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9702 : Blocked tgt 7 s9702 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9702 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf0f0f0f0f0f0f0f0f000f000f000f00 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl)))))))) (by decide +kernel)
theorem b9902 : Blocked tgt 7 s9902 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s9902 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5154 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b9908 : Blocked tgt 7 s9908 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s9908 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8104 rfl)))))))) (by decide +kernel)

theorem b9914 : Blocked tgt 7 s9914 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [773,1417,773,1417,5930,9737,7474,458,7474,2514,1482,2256,7466,466,7466,1482,1482,5257,5578,1482,5546,5546,1417,5674,5672,1417,385,393,1409,385,1417,6964,1417,7210,3209,1417,1417,13386,5257,1417,773,1417,1417,773,6962,4906,7474,6962,10832,5930,5930,6832,3209,4914,3209,5930,5257,1834,5257,10058,5930,1866,13610,5930,7474,7732,2177,2185,2177,3201,4225,4233,4225,5249,7474,3410,14642,7474,4772,3209,6820,3209,2708,5257,6804,5257,6836,13610,14900,13610,3209,3370,5257,3209,7466,3209,3209,7466,4741,5257,5257,13578]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9915 : Blocked tgt 7 s9915 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s9915 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2286 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8104 rfl)))))))) (by decide +kernel)
theorem b9923 : Blocked tgt 7 s9923 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,6836,901,6964,1482,6964,773,1482,901,6836,6836,6964,6058,1482,6058,9737,6836,9737,5930,6836,6058,5930,1482,9737,7474,2514,7474,458,1482,7732,7474,1482,7474,2514,2514,7732,7466,1482,7466,466,2514,3209,7466,2514,7466,1482,1482,3209,1482,1482,13642,6804,6836,5257,5578,6836,13642,1482,1482,5257,13610,6836,13610,1482,1482,14900,5546,1482,13610,5546,6836,14900,1417,1417,9737,6964,6964,6058,9737,6964,9737,1417,1417,6058,6964,6964,7732,393,1417,7474,7732,1417,7732,6964,6964,7474,4900,4900,3209,4916,6964,7466,6948,6964,3209,4900,4900,7466,2836,2836,5257,2868,6964,13642,6932,6964,5257,2836,2836,13642,6964,6964,14900,1417,1417,13610,14900,1417,14900,6964,6964,13610,8705,8705,7474,7732,9737,7732,9729,9737,7474,7732,8705,7732,3209,9737,3209,5042,7090,2693,3209,7090,3209,9737,9737,2693,5257,9737,5257,1962,6058,4741,5257,6058,5257,9737,9737,4741,1545,6058,13610,1545,9737,14900,9737,9737,13610,14900,6058,14900,5668,5668,2177,5684,7732,3209,7716,7732,2177,5668,5668,3209,3604,3604,4225,3636,7732,5257,7700,7732,4225,3604,3604,5257,7732,7732,14900,3410,11602,13610,14900,11602,14900,7732,7732,13610,3209,3209,5257,3370,7466,14674,5257,7466,5257,3209,3209,14674,12836,7466,12836,12852,3209,14900,12836,3209,12836,14884,7466,14900,10772,4741,10772,10804,5257,14900,10772,5257,10772,14868,4741,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b9925 : Blocked tgt 7 s9925 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s9925 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b9951 : Blocked tgt 7 s9951 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s9951 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b9960 : Blocked tgt 7 s9960 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s9960 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8104 rfl)))))))) (by decide +kernel)
theorem b9962 : Blocked tgt 7 s9962 := by
  intro k le c
  apply rejects_sound r748 (0x4444444444444444 :: i6) 6 tgt small748 hot748 [] s9962 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444444444444444,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv748_2298 (PetersenWireProjection.cons pv748_2708 (PetersenWireProjection.cons pv748_4814 (PetersenWireProjection.cons pv748_5473 (PetersenWireProjection.cons pv748_6504 (PetersenWireProjection.cons pv748_6790 (PetersenWireProjection.cons pv748_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r748 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xf0f0f0f0f0f0f0f0) rfl)))))))) (by decide +kernel)
theorem b9968 : Blocked tgt 7 s9968 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s9968 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6504 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8104 rfl)))))))) (by decide +kernel)
theorem b9974 : Blocked tgt 7 s9974 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s9974 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1912 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8104 rfl)))))))) (by decide +kernel)
theorem b9975 : Blocked tgt 7 s9975 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s9975 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xffffffffffffffffffaaffaaffaaffaa : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b10032 : Blocked tgt 7 s10032 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s10032 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
