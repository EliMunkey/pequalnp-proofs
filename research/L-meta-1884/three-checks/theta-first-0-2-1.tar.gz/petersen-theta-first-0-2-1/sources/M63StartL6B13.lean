import M63StartData
import M63StartL5B12
import M63StartL5B11
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b427 : Blocked tgt 6 s427 := by
  apply PetersenFastNode.node (nxt := #[s428,s390,s404]) (hints := [2376,0,717,717,1431,456,1431,456,2636,844,2120,844,1815,840,1815,840,2376,1352,1677,1352,2765,3415,456,1431,456,1431,844,909,840,1815,840,1815,1352,1,1352,2,1431,456,1431,456,2765,844,3021,1815,840,1815,840,1677,1352,1677,1352,716,200,844,716,456,204,840,456,456,407,1352,456,1685,840,836,836,844,1096,1612,844,840,1100,1352,840]) (by decide +kernel)
  change ∀ b ∈ [s428,s390,s404], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s428) b428 <|
    PetersenLocalChildren.push (x := s390) b390 <|
    PetersenLocalChildren.push (x := s404) b404 <|
    PetersenLocalChildren.nil
theorem b430 : Blocked tgt 6 s430 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s430 6 _ le
  decide +kernel
theorem b431 : Blocked tgt 6 s431 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s431 6 _ le
  decide +kernel
theorem b432 : Blocked tgt 6 s432 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s432 6 _ le
  decide +kernel
theorem b433 : Blocked tgt 6 s433 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s433 6 _ le
  decide +kernel
theorem b434 : Blocked tgt 6 s434 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s434 6 _ le
  decide +kernel
theorem b435 : Blocked tgt 6 s435 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [841,2986,3050,2794,3314,2794,3508,713,3508,713,3892,3762,841,1609,1089,841,841,2633,2113,841,2794,3188,713,3506,713,3504,833,3892,833,3506,1609,2482,1609,2466,2633,1458,2633,1426,2664,2666,2792,2664,3892,2794,2794,3314,2794,1545,3754,2794,714,746,2762,714,3508,713,713,3508,713,3626,1609,713,713,1460,2633,713,2852,1609,3876,1609,1812,2633,3860,2633,1609,1706,2633,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b436 : Blocked tgt 6 s436 := by
  apply PetersenFastNode.node (nxt := #[s407,s437,s439]) (hints := [2797,3191,716,3509,716,3507,840,3639,840,3509,1096,2485,1096,0,844,2989,2636,1461,2636,1429,3511,2669,3511,2667,3895,2285,3895,3317,2797,2549,3317,2797,2797,3317,3053,2797,717,749,2765,717,3511,204,3895,3511,2471,2487,3495,2471,716,3511,3511,716,1431,1463,3479,1431,2855,2871,3879,2855,1,3895,3895,836,1815,1847,3863,1815,844,1612,2636,2,2636,1096,844,2120,2636,844]) (by decide +kernel)
  change ∀ b ∈ [s407,s437,s439], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s407) b407 <|
    PetersenLocalChildren.push (x := s437) b437 <|
    PetersenLocalChildren.push (x := s439) b439 <|
    PetersenLocalChildren.nil
theorem b441 : Blocked tgt 6 s441 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s441 6 _ le
  decide +kernel
theorem b442 : Blocked tgt 6 s442 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s442 6 _ le
  decide +kernel
theorem b443 : Blocked tgt 6 s443 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s443 6 _ le
  decide +kernel
theorem b444 : Blocked tgt 6 s444 := by
  apply PetersenFastNode.node (nxt := #[s396,s445,s398,s446,s439]) (hints := [2799,1369,458,1433,458,1433,846,2991,842,1817,842,1817,1711,0,1711,1,2378,2,2378,3,1433,458,1433,458,2799,846,3055,1817,2287,1817,1239,1711,1239,1711,1775,719,751,2767,719,718,1433,1433,718,1433,206,1817,1433,2457,1433,1433,1449,393,1433,1433,393,1687,1817,838,1817,846,4,1711,846,846,2122,2638,846,2841,1817,1817,1833,777,1817,1817,777,1354,1354]) (by decide +kernel)
  change ∀ b ∈ [s396,s445,s398,s446,s439], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s396) b396 <|
    PetersenLocalChildren.push (x := s445) b445 <|
    PetersenLocalChildren.push (x := s398) b398 <|
    PetersenLocalChildren.push (x := s446) b446 <|
    PetersenLocalChildren.push (x := s439) b439 <|
    PetersenLocalChildren.nil
theorem b447 : Blocked tgt 6 s447 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,true),(2,false))] s447 6 _ le
  decide +kernel
theorem b449 : Blocked tgt 6 s449 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s449 6 _ le
  decide +kernel
theorem b450 : Blocked tgt 6 s450 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s450 6 _ le
  decide +kernel
theorem b451 : Blocked tgt 6 s451 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s451 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
