import M63StartData
import M63StartL4B0
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b269 : Blocked tgt 5 s269 := by
  apply PetersenFastNode.node (nxt := #[s270]) (hints := [2665,778,2857,2665,3445,2665,2803,3445,3445,390,2549,2549,2405,2421,3429,2405,1365,1397,3413,1365,3507,842,842,3507,0,842,842,3505,714,1094,714,842,842,2118,2634,842,838,838,1350,202,1350,714,2374,2634,2374,2634,1350,714,454,454,2374,2634,2374,2634,1350,1577,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s270], Blocked tgt 4 b
  exact 
    PetersenLocalChildren.push (x := s270) b270 <|
    PetersenLocalChildren.nil
theorem b271 : Blocked tgt 5 s271 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s271 5 _ le
  decide +kernel
theorem b272 : Blocked tgt 5 s272 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s272 5 _ le
  decide +kernel
theorem b273 : Blocked tgt 5 s273 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s273 5 _ le
  decide +kernel
theorem b274 : Blocked tgt 5 s274 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s274 5 _ le
  decide +kernel
theorem b275 : Blocked tgt 5 s275 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s275 5 _ le
  decide +kernel
theorem b277 : Blocked tgt 5 s277 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s277 5 _ le
  decide +kernel
theorem b278 : Blocked tgt 5 s278 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(true,(0,false),(5,false))] s278 5 _ le
  decide +kernel
theorem b279 : Blocked tgt 5 s279 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s279 5 _ le
  decide +kernel
theorem b280 : Blocked tgt 5 s280 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s280 5 _ le
  decide +kernel
theorem b284 : Blocked tgt 5 s284 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s284 5 _ le
  decide +kernel
theorem b285 : Blocked tgt 5 s285 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(5,false))] s285 5 _ le
  decide +kernel
theorem b286 : Blocked tgt 5 s286 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(5,false))] s286 5 _ le
  decide +kernel
theorem b287 : Blocked tgt 5 s287 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s287 5 _ le
  decide +kernel
theorem b288 : Blocked tgt 5 s288 := by
  intro k le c
  apply rejects_sound r3 i4 3 tgt small3 hot3 [] s288 5 _ le
  decide +kernel
theorem b289 : Blocked tgt 5 s289 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(false,(0,false),(1,false)),(false,(0,true),(5,false))] s289 5 _ le
  decide +kernel
end PetersenSmallStarts.M63
