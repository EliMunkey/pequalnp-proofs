import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows3
import M191StartPreferredRows4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b829 : Blocked tgt 7 s829 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s829 7 _ le
  decide +kernel
theorem b856 : Blocked tgt 7 s856 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s856 7 _ le
  decide +kernel
theorem b857 : Blocked tgt 7 s857 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s857 7 _ le
  decide +kernel
theorem b858 : Blocked tgt 7 s858 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s858 7 _ le
  decide +kernel
theorem b863 : Blocked tgt 7 s863 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s863 7 _ le
  decide +kernel
theorem b864 : Blocked tgt 7 s864 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s864 7 _ le
  decide +kernel
theorem b865 : Blocked tgt 7 s865 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s865 7 _ le
  decide +kernel
theorem b866 : Blocked tgt 7 s866 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s866 7 _ le
  decide +kernel
theorem b867 : Blocked tgt 7 s867 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(2,false))] s867 7 _ le
  decide +kernel
theorem b868 : Blocked tgt 7 s868 := by
  intro k le c
  apply rejects_sound r742 (0x4444 :: i4) 3 tgt small742 hot742 [] s868 7 _ le
  decide +kernel
theorem b894 : Blocked tgt 7 s894 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s894 7 _ le
  decide +kernel
theorem b895 : Blocked tgt 7 s895 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s895 7 _ le
  decide +kernel
theorem b900 : Blocked tgt 7 s900 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s900 7 _ le
  decide +kernel
theorem b901 : Blocked tgt 7 s901 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s901 7 _ le
  decide +kernel
theorem b906 : Blocked tgt 7 s906 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s906 7 _ le
  decide +kernel
theorem b907 : Blocked tgt 7 s907 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s907 7 _ le
  decide +kernel
theorem b908 : Blocked tgt 7 s908 := by
  intro k le c
  apply rejects_sound r38 i4 3 tgt small38 hot38 [] s908 7 _ le
  decide +kernel
theorem b933 : Blocked tgt 7 s933 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s933 7 _ le
  decide +kernel
theorem b934 : Blocked tgt 7 s934 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s934 7 _ le
  decide +kernel
theorem b935 : Blocked tgt 7 s935 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s935 7 _ le
  decide +kernel
theorem b936 : Blocked tgt 7 s936 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s936 7 _ le
  decide +kernel
theorem b937 : Blocked tgt 7 s937 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s937 7 _ le
  decide +kernel
theorem b938 : Blocked tgt 7 s938 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s938 7 _ le
  decide +kernel
theorem b939 : Blocked tgt 7 s939 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s939 7 _ le
  decide +kernel
theorem b940 : Blocked tgt 7 s940 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s940 7 _ le
  decide +kernel
theorem b941 : Blocked tgt 7 s941 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s941 7 _ le
  decide +kernel
theorem b942 : Blocked tgt 7 s942 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s942 7 _ le
  decide +kernel
theorem b943 : Blocked tgt 7 s943 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s943 7 _ le
  decide +kernel
theorem b944 : Blocked tgt 7 s944 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s944 7 _ le
  decide +kernel
theorem b945 : Blocked tgt 7 s945 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s945 7 _ le
  decide +kernel
theorem b946 : Blocked tgt 7 s946 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s946 7 _ le
  decide +kernel
theorem b947 : Blocked tgt 7 s947 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s947 7 _ le
  decide +kernel

theorem b948 : Blocked tgt 7 s948 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s948 7 _ le
  decide +kernel
theorem b949 : Blocked tgt 7 s949 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s949 7 _ le
  decide +kernel
theorem b950 : Blocked tgt 7 s950 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s950 7 _ le
  decide +kernel
theorem b951 : Blocked tgt 7 s951 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s951 7 _ le
  decide +kernel
theorem b952 : Blocked tgt 7 s952 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s952 7 _ le
  decide +kernel
theorem b953 : Blocked tgt 7 s953 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s953 7 _ le
  decide +kernel
theorem b954 : Blocked tgt 7 s954 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s954 7 _ le
  decide +kernel
theorem b955 : Blocked tgt 7 s955 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s955 7 _ le
  decide +kernel
theorem b956 : Blocked tgt 7 s956 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s956 7 _ le
  decide +kernel
theorem b957 : Blocked tgt 7 s957 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s957 7 _ le
  decide +kernel
theorem b958 : Blocked tgt 7 s958 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s958 7 _ le
  decide +kernel
theorem b959 : Blocked tgt 7 s959 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s959 7 _ le
  decide +kernel
theorem b960 : Blocked tgt 7 s960 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s960 7 _ le
  decide +kernel
theorem b961 : Blocked tgt 7 s961 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s961 7 _ le
  decide +kernel
theorem b962 : Blocked tgt 7 s962 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s962 7 _ le
  decide +kernel
theorem b963 : Blocked tgt 7 s963 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s963 7 _ le
  decide +kernel

theorem b964 : Blocked tgt 7 s964 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s964 7 _ le
  decide +kernel
theorem b965 : Blocked tgt 7 s965 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s965 7 _ le
  decide +kernel
theorem b966 : Blocked tgt 7 s966 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s966 7 _ le
  decide +kernel
theorem b967 : Blocked tgt 7 s967 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s967 7 _ le
  decide +kernel
theorem b968 : Blocked tgt 7 s968 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s968 7 _ le
  decide +kernel
theorem b969 : Blocked tgt 7 s969 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,4266,4522,6836,4522,9793,5930,4522,7474,4522,6578,6578,4522,4788,6570,4522,8650,426,12746,8650,4522,458,12714,4522,6836,4522,4522,6836,8641,5930,9921,8641,1669,8641,1669,7474,2693,7466,2693,8641,4741,13386,4741,8641,385,449,8577,385,901,901,8897,8897,9921,1669,9921,2693,10433,9921,9921,4741,12481,9921,5930,9921,9857,9857,1665,9921,9921,5672,1669,10433,2693,1669,1669,12481,4741,1669,1669,3410,14642,1669,1669,7474,7474,1669,2693,3370,4741,2693,2693,2241,10369,2693,2693,10433,10433,2693,4741,4289,12417,4741,4741,12481,12481,4741,8837,8837]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b970 : Blocked tgt 7 s970 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s970 7 _ le
  decide +kernel
theorem b971 : Blocked tgt 7 s971 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s971 7 _ le
  decide +kernel
theorem b973 : Blocked tgt 7 s973 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s973 7 _ le
  decide +kernel
theorem b974 : Blocked tgt 7 s974 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s974 7 _ le
  decide +kernel
theorem b975 : Blocked tgt 7 s975 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s975 7 _ le
  decide +kernel
theorem b976 : Blocked tgt 7 s976 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s976 7 _ le
  decide +kernel
theorem b977 : Blocked tgt 7 s977 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s977 7 _ le
  decide +kernel
theorem b981 : Blocked tgt 7 s981 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s981 7 _ le
  decide +kernel
theorem b982 : Blocked tgt 7 s982 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s982 7 _ le
  decide +kernel
theorem b983 : Blocked tgt 7 s983 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s983 7 _ le
  decide +kernel

theorem b984 : Blocked tgt 7 s984 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s984 7 _ le
  decide +kernel
theorem b985 : Blocked tgt 7 s985 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s985 7 _ le
  decide +kernel
theorem b986 : Blocked tgt 7 s986 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s986 7 _ le
  decide +kernel
theorem b987 : Blocked tgt 7 s987 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s987 7 _ le
  decide +kernel
theorem b988 : Blocked tgt 7 s988 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s988 7 _ le
  decide +kernel
theorem b989 : Blocked tgt 7 s989 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(2,false))] s989 7 _ le
  decide +kernel
theorem b990 : Blocked tgt 7 s990 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s990 7 _ le
  decide +kernel
theorem b991 : Blocked tgt 7 s991 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s991 7 _ le
  decide +kernel
theorem b992 : Blocked tgt 7 s992 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s992 7 _ le
  decide +kernel
theorem b993 : Blocked tgt 7 s993 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s993 7 _ le
  decide +kernel
theorem b994 : Blocked tgt 7 s994 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s994 7 _ le
  decide +kernel
theorem b995 : Blocked tgt 7 s995 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s995 7 _ le
  decide +kernel
theorem b996 : Blocked tgt 7 s996 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(2,false))] s996 7 _ le
  decide +kernel
theorem b997 : Blocked tgt 7 s997 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s997 7 _ le
  decide +kernel
theorem b998 : Blocked tgt 7 s998 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s998 7 _ le
  decide +kernel
theorem b999 : Blocked tgt 7 s999 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s999 7 _ le
  decide +kernel

end PetersenSmallStarts.M191.Residual
