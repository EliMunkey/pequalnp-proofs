import higher.WireProjection
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values32
import M191Values35
import M191Values5
import M191Values735
import M191Values737
import M191Values739
import M191Values740
import M191Values744
import M191Values749
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows22
import M191StartPreferredRows23
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4977 : Blocked tgt 7 s4977 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4977 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)

theorem b4978 : Blocked tgt 7 s4978 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4978 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0] (PetersenWireProjection.cons pv5_3730 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl)))))))) (by decide +kernel)
theorem b4979 : Blocked tgt 7 s4979 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s4979 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xff00,0xcccc,0x0,0xf0f0] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4429 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5745 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 rfl)))))))) (by decide +kernel)
theorem b4980 : Blocked tgt 7 s4980 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s4980 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00] (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r735 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 rfl)))))))) (by decide +kernel)
theorem b5066 : Blocked tgt 7 s5066 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s5066 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_438 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b5072 : Blocked tgt 7 s5072 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [6836,6836,901,6964,4522,6964,773,4522,901,6836,6836,6964,4522,4522,6058,9793,6836,9793,5930,6836,6058,4522,4522,9793,7474,6836,7474,4522,4522,7732,6578,4522,7474,6578,6836,7732,4522,4522,7466,6820,6836,10433,6570,6836,7466,4522,4522,10433,8650,8650,13642,426,4522,12481,12746,4522,13642,8650,8650,12481,4522,4522,13610,458,8650,14900,12714,8650,13610,4522,4522,14900,8641,8641,9793,6964,6964,6058,9793,6964,9793,8641,8641,6058,6964,6964,7732,8641,8641,7474,7732,8641,7732,6964,6964,7474,4900,4900,10433,4916,6964,7466,6948,6964,10433,4900,4900,7466,2836,2836,12481,2868,6964,13642,6932,6964,12481,2836,2836,13642,6964,6964,14900,449,8641,13610,14900,8641,14900,6964,6964,13610,6324,7090,7474,6324,9793,7732,9793,9793,7474,7732,7090,7732,9793,9793,10433,5042,7090,2693,10433,7090,10433,9793,9793,2693,9793,9793,12481,1962,6058,4741,12481,6058,12481,9793,9793,4741,1537,1537,13610,1601,9793,14900,9729,9793,13610,1537,1537,14900,5668,5668,2693,5684,7732,10433,7716,7732,2693,5668,5668,10433,3604,3604,14674,3636,7732,12481,7700,7732,14674,3604,3604,12481,7732,7732,14900,3410,11602,13610,14900,11602,14900,7732,7732,13610,10433,10433,12481,3370,7466,14674,12481,7466,12481,10433,10433,14674,12836,2177,12836,12852,10433,14900,12836,10433,12836,14884,2177,14900,10772,4225,10772,10804,12481,14900,10772,12481,10772,14868,4225,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b5073 : Blocked tgt 7 s5073 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5073 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_3822 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5074 : Blocked tgt 7 s5074 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5074 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3822 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5075 : Blocked tgt 7 s5075 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s5075 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_3632 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5682 (PetersenWireProjection.cons pv21_6308 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b5076 : Blocked tgt 7 s5076 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5076 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5077 : Blocked tgt 7 s5077 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5077 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5078 : Blocked tgt 7 s5078 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5078 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b5079 : Blocked tgt 7 s5079 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5079 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b5080 : Blocked tgt 7 s5080 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s5080 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xffffffffcccccccc,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5102 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b5081 : Blocked tgt 7 s5081 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5081 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5082 : Blocked tgt 7 s5082 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5082 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5083 : Blocked tgt 7 s5083 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5083 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6429 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)

theorem b5084 : Blocked tgt 7 s5084 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5084 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2099 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5085 : Blocked tgt 7 s5085 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5085 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6952 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5086 : Blocked tgt 7 s5086 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5086 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xff00ff00ff00ff00,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4366 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5087 : Blocked tgt 7 s5087 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5087 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7650 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5088 : Blocked tgt 7 s5088 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5088 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xffff0000ffff0000,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4375 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5089 : Blocked tgt 7 s5089 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s5089 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc] (PetersenWireProjection.cons pv744_2708 (PetersenWireProjection.cons pv744_4814 (PetersenWireProjection.cons pv744_5473 (PetersenWireProjection.cons pv744_6308 (PetersenWireProjection.cons pv744_6790 (PetersenWireProjection.cons pv744_7474 (PetersenWireProjection.cons pv744_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r744 (0xffffffffffffffff5050505050505050 : BitVec 128) = 0xfcfcfcfcfcfcfcfc) rfl)))))))) (by decide +kernel)
theorem b5090 : Blocked tgt 7 s5090 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5090 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_283 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5095 : Blocked tgt 7 s5095 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5095 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b5096 : Blocked tgt 7 s5096 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5096 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5097 : Blocked tgt 7 s5097 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5097 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5098 : Blocked tgt 7 s5098 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5672,8641,5672,5674,901,5930,5672,901,5672,5928,8641,5930,6836,6964,6836,773,901,4522,6836,901,6836,6964,6964,4522,901,901,1541,6322,8641,6578,1541,8641,1541,901,901,6578,901,901,2693,4916,6964,7466,2693,6964,2693,901,901,7466,901,901,4741,2868,6964,13642,4741,6964,4741,901,901,13642,901,901,8837,13354,8641,13610,8837,8641,8837,901,901,13610,4522,6962,4522,5930,5930,6836,4522,5930,4522,6962,6962,6836,5034,6962,6578,5034,5930,1541,5930,5930,6578,6962,6962,1541,5930,5930,7466,4914,6962,2693,7466,6962,7466,5930,5930,2693,10058,10058,13642,1834,5930,4741,13642,5930,13642,10058,10058,4741,5930,5930,13610,1866,10058,8837,13610,10058,13610,5930,5930,8837,6578,6836,6578,4522,4522,1541,6578,4522,6578,7474,6836,1541,4522,4522,10433,6570,6836,7466,6820,6836,10433,4522,4522,7466,8650,8650,14674,12746,4522,13642,426,4522,14674,8650,8650,13642,4522,4522,14642,12714,8650,13610,458,8650,14642,4522,4522,13610,4514,4514,2693,7466,6578,7466,6562,6578,2693,7466,4514,7466,10706,10706,14674,13642,6578,13642,14674,6578,14674,13642,10706,13642,6578,6578,14642,13610,10706,13610,14642,10706,14642,13610,6578,13610,11594,11594,13642,3370,7466,14674,13642,7466,13642,11594,11594,14674,7466,7466,13610,3402,11594,14642,13610,11594,13610,7466,7466,14642,4741,4741,8837,13610,13642,13610,13578,13642,8837,13578,4741,13610]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b5099 : Blocked tgt 7 s5099 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5099 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5100 : Blocked tgt 7 s5100 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5100 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5101 : Blocked tgt 7 s5101 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5101 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5102 : Blocked tgt 7 s5102 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5102 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b5103 : Blocked tgt 7 s5103 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5103 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)

theorem b5104 : Blocked tgt 7 s5104 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5104 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3315 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5105 : Blocked tgt 7 s5105 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5105 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5106 : Blocked tgt 7 s5106 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5106 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0x0,0xf0f0f0f0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5107 : Blocked tgt 7 s5107 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5107 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6504 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5108 : Blocked tgt 7 s5108 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5108 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5284 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5109 : Blocked tgt 7 s5109 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5109 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5110 : Blocked tgt 7 s5110 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5110 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5111 : Blocked tgt 7 s5111 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5111 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7330 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5112 : Blocked tgt 7 s5112 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5112 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1896 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5113 : Blocked tgt 7 s5113 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s5113 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6504 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7873 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)
theorem b5114 : Blocked tgt 7 s5114 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5114 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5115 : Blocked tgt 7 s5115 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5115 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8305 rfl)))))))) (by decide +kernel)
theorem b5116 : Blocked tgt 7 s5116 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5116 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_541 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5117 : Blocked tgt 7 s5117 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5117 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6457 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5118 : Blocked tgt 7 s5118 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5118 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1912 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5119 : Blocked tgt 7 s5119 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s5119 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8317 rfl)))))))) (by decide +kernel)

theorem b5120 : Blocked tgt 7 s5120 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5120 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_561 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5135 : Blocked tgt 7 s5135 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5135 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5136 : Blocked tgt 7 s5136 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false)),(true,(2,false),(7,false))] s5136 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv740_4503 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffffffffaaaaaaaa) rfl)))))))) (by decide +kernel)
theorem b5137 : Blocked tgt 7 s5137 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(1,false),(4,false))] s5137 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00,0xffaaffaa] (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_5682 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 (PetersenWireProjection.cons pv737_8191 rfl)))))))) (by decide +kernel)
theorem b5138 : Blocked tgt 7 s5138 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5138 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5139 : Blocked tgt 7 s5139 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5139 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5140 : Blocked tgt 7 s5140 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5140 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5141 : Blocked tgt 7 s5141 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5141 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b5142 : Blocked tgt 7 s5142 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5142 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5143 : Blocked tgt 7 s5143 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s5143 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b5144 : Blocked tgt 7 s5144 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5144 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5145 : Blocked tgt 7 s5145 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5145 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf5f5f5f5f5f5f5f5a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5146 : Blocked tgt 7 s5146 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5146 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5f5f5f5f5f5f5f5a0a0a0a0a0a0a0a0 : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5150 : Blocked tgt 7 s5150 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5150 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5151 : Blocked tgt 7 s5151 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5151 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3502 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)

theorem b5152 : Blocked tgt 7 s5152 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5152 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5425 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5153 : Blocked tgt 7 s5153 := by
  intro k le c
  apply rejects_sound r749 (0xc0c0c0c0c0c0c0c :: i6) 6 tgt small749 hot749 [] s5153 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xc0c0c0c0c0c0c0c,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv749_456 (PetersenWireProjection.cons pv749_2708 (PetersenWireProjection.cons pv749_4814 (PetersenWireProjection.cons pv749_5473 (PetersenWireProjection.cons pv749_6308 (PetersenWireProjection.cons pv749_6790 (PetersenWireProjection.cons pv749_7474 (PetersenWireProjection.cons pv749_8191 rfl)))))))) (by decide +kernel)
theorem b5154 : Blocked tgt 7 s5154 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s5154 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b5157 : Blocked tgt 7 s5157 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5157 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf500f500f500f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5158 : Blocked tgt 7 s5158 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5158 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf500f500f500f500a000a000a000a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b5159 : Blocked tgt 7 s5159 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5159 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8191 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b5160 : Blocked tgt 7 s5160 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s5160 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8191 rfl)))))))) (by decide +kernel)
theorem b5161 : Blocked tgt 7 s5161 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5161 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b5162 : Blocked tgt 7 s5162 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5162 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5163 : Blocked tgt 7 s5163 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5163 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7439 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5164 : Blocked tgt 7 s5164 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s5164 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1366 (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b5165 : Blocked tgt 7 s5165 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5165 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b5166 : Blocked tgt 7 s5166 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5166 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5177 : Blocked tgt 7 s5177 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s5177 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6568 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5178 : Blocked tgt 7 s5178 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s5178 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6568 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b5185 : Blocked tgt 7 s5185 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s5185 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6568 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5186 : Blocked tgt 7 s5186 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5186 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2051 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5199 : Blocked tgt 7 s5199 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5199 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8208 rfl)))))))) (by decide +kernel)
theorem b5200 : Blocked tgt 7 s5200 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5200 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8208 rfl)))))))) (by decide +kernel)
theorem b5201 : Blocked tgt 7 s5201 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false))] s5201 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffffcccc] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8208 rfl)))))))) (by decide +kernel)
theorem b5202 : Blocked tgt 7 s5202 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s5202 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff0aff0a,0xffff0000,0x0,0xcccccccc] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r739 (0xffffffffffffffffcccccccccccccccc : BitVec 128) = 0xcccccccc) rfl)))))))) (by decide +kernel)
theorem b5203 : Blocked tgt 7 s5203 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5203 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a0a0a0808080808080808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5204 : Blocked tgt 7 s5204 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5204 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x202020202020202 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5209 : Blocked tgt 7 s5209 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(5,false))] s5209 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8208 rfl)))))))) (by decide +kernel)
theorem b5210 : Blocked tgt 7 s5210 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5210 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_235 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5239 : Blocked tgt 7 s5239 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(0,false),(4,false))] s5239 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00,0xff0aff0a] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_5682 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xffffffffffffffffff0aff0aff0aff0a : BitVec 128) = 0xff0aff0a) rfl)))))))) (by decide +kernel)
theorem b5245 : Blocked tgt 7 s5245 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5245 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_125 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5277 : Blocked tgt 7 s5277 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5277 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff00ff000a000a00ff00ff000a000a00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)

theorem b5278 : Blocked tgt 7 s5278 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s5278 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff00ff000a000a00ff00ff000a000a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b5279 : Blocked tgt 7 s5279 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s5279 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0xa0a0a0a,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6292 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffff0a0a0a0affffffff0a0a0a0a : BitVec 128) = 0xa0a0a0a) (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b5280 : Blocked tgt 7 s5280 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s5280 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1262 (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffffffff0a0a0a0affffffff0a0a0a0a : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b5281 : Blocked tgt 7 s5281 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s5281 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xff0aff0a0a0a0a0aff0aff0a0a0a0a0a : BitVec 128) = 0xa0a0a0a) (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5282 : Blocked tgt 7 s5282 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5282 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1196 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5283 : Blocked tgt 7 s5283 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s5283 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2322 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b5328 : Blocked tgt 7 s5328 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s5328 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_4260 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 (PetersenWireProjection.cons pv35_8305 rfl)))))))) (by decide +kernel)
theorem b5330 : Blocked tgt 7 s5330 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s5330 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0xa0a0a0a] (PetersenWireProjection.cons pv5_2327 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xffffffffffffffff0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a0a0a) rfl)))))))) (by decide +kernel)

end PetersenSmallStarts.M191.Staged
