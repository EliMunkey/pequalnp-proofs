import higher.WireProjection
import M191Values0
import M191Values2
import M191Values737
import M191Values739
import M191Values740
import M191Values758
import M191Values759
import M191Values760
import M191Values761
import M191Values762
import M191Values763
import M191Values764
import M191Values766
import M191Values767
import M191Values768
import M191Values769
import M191Values771
import M191Values772
import M191Values774
import M191Values775
import M191Values776
import M191Values8
import M191ResidualC7A0G38
import M191ResidualC7A0G4
import M191StartPreferredCuts0
import M191StartPreferredCuts2
import M191StartPreferredCuts4
import M191StartPreferredCuts5
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows4
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b5848 : Blocked tgt 8 s5848 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5848 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5849 : Blocked tgt 8 s5849 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5849 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5850 : Blocked tgt 8 s5850 := by
  intro k le c
  apply rejects_sound r758 (0xffffaaaa :: i5) 6 tgt small758 hot758 [] s5850 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xffffaaaa,0xff00ff00] (PetersenWireProjection.cons pv758_4260 (PetersenWireProjection.cons pv758_4814 (PetersenWireProjection.cons pv758_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r758 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv758_6790 (PetersenWireProjection.cons pv758_7474 (PetersenWireProjection.cons pv758_7688 (PetersenWireProjection.cons pv758_8012 rfl)))))))) (by decide +kernel)
theorem b5851 : Blocked tgt 8 s5851 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5851 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5852 : Blocked tgt 8 s5852 := by
  intro k le c
  apply rejects_sound r759 (0x55550000 :: i5) 6 tgt small759 hot759 [] s5852 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x55550000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv759_3730 (PetersenWireProjection.cons pv759_4260 (PetersenWireProjection.cons pv759_4814 (PetersenWireProjection.cons pv759_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r759 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv759_6790 (PetersenWireProjection.cons pv759_7474 (PetersenWireProjection.cons pv759_8012 rfl)))))))) (by decide +kernel)
theorem b5853 : Blocked tgt 8 s5853 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5853 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5904 : Blocked tgt 8 s5904 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s5904 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b5905 : Blocked tgt 8 s5905 := by
  intro k le c
  apply rejects_sound r761 (0x55005500 :: i5) 6 tgt small761 hot761 [] s5905 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x55005500,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv761_3759 (PetersenWireProjection.cons pv761_4260 (PetersenWireProjection.cons pv761_4814 (PetersenWireProjection.cons pv761_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r761 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv761_6790 (PetersenWireProjection.cons pv761_7474 (PetersenWireProjection.cons pv761_8012 rfl)))))))) (by decide +kernel)
theorem b5906 : Blocked tgt 8 s5906 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5906 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4429 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)

theorem b5907 : Blocked tgt 8 s5907 := by
  intro k le c
  apply rejects_sound r762 (0xfcfcfcfc :: i5) 6 tgt small762 hot762 [] s5907 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xfcfcfcfc,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv762_4260 (PetersenWireProjection.cons pv762_4814 (PetersenWireProjection.cons pv762_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r762 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv762_5920 (PetersenWireProjection.cons pv762_6790 (PetersenWireProjection.cons pv762_7474 (PetersenWireProjection.cons pv762_8012 rfl)))))))) (by decide +kernel)
theorem b5908 : Blocked tgt 8 s5908 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5908 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b5909 : Blocked tgt 8 s5909 := by
  intro k le c
  apply rejects_sound r763 (0x30303030 :: i5) 6 tgt small763 hot763 [] s5909 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x30303030,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv763_3209 (PetersenWireProjection.cons pv763_4260 (PetersenWireProjection.cons pv763_4814 (PetersenWireProjection.cons pv763_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r763 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv763_6790 (PetersenWireProjection.cons pv763_7474 (PetersenWireProjection.cons pv763_8012 rfl)))))))) (by decide +kernel)
theorem b5910 : Blocked tgt 8 s5910 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5910 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xc400c400c400c400c400c400c400c400 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5911 : Blocked tgt 8 s5911 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5911 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b5912 : Blocked tgt 8 s5912 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5912 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xcccccccc,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5913 : Blocked tgt 8 s5913 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5913 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2652 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b5914 : Blocked tgt 8 s5914 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5914 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2652 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5915 : Blocked tgt 8 s5915 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5915 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3249 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5916 : Blocked tgt 8 s5916 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5916 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0x0,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4586 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5917 : Blocked tgt 8 s5917 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5917 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5918 : Blocked tgt 8 s5918 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5918 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1779 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5919 : Blocked tgt 8 s5919 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s5919 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b5920 : Blocked tgt 8 s5920 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5920 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4675 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b5921 : Blocked tgt 8 s5921 := by
  apply PetersenFastNode.node (nxt := #[s5922,s5923,s5924,s5925,s5926,s5927,s5928,s5929,s5930,s5931,s5932,s5933,s5934,s5935,s5936,s5937,s5938,s5939,s991,s5940,s5941,s5942,s5943,s5944,s5945,s5946,s5947,s5948,s5949,s5950,s5951,s5952,s5953,s5954,s5955,s5956,s5957,s5958,s5959,s5960,s5961,s5962,s5963]) (hints := [6879,6879,7007,6365,6621,0,7007,6621,7007,6879,6879,1,5973,6621,5973,6367,6879,8940,5973,6879,5973,6101,6621,8940,6621,6621,7517,4565,2,1712,7517,3,7517,6621,6621,1712,7509,4557,7509,4573,6621,2736,7509,6621,7509,4557,4557,2736,13685,10749,13685,2525,6621,4,13685,6621,13685,10749,10749,5,2751,2751,6,6621,6621,7,6621,6621,8,2751,2751,9,13653,6621,13653,2557,10749,8880,13653,10749,13653,6621,6621,8880,8940,10,8940,5717,7007,5973,8940,7007,8940,5971,11,5973,1712,7007,1712,7261,12,7517,1712,13,1712,7007,7007,7517,2736,4943,2736,4959,7007,7509,2736,7007,2736,4943,4943,7509,2911,14,15,7007,7007,16,13685,17,13685,944,7007,18,944,17,19,8880,7007,8880,13397,20,13653,8880,21,8880,7007,7007,13653,8940,8940,7517,1712,5973,1712,9964,5973,7517,8940,8940,1712,8940,8940,10476,2224,7005,2736,10476,7005,10476,8940,8940,2736,8940,8940,13685,1877,5973,22,13685,5973,13685,8940,8940,23,8940,8940,24,5973,5973,25,5973,5973,26,8940,8940,27,5973,5973,13653,8880,8940,8880,8876,8940,13653,8876,5973,8880,1712,1712,2736,7509,7517,7509,2736,7517,2736,1712,1712,7509,1712,1712,14717,3421,7517,13685,14717,7517,14717,1712,1712,13685,1712,1712,28,7517,7517,29,7517,7517,30,1712,1712,31,1712,1712,8880,3453,11645,13653,8880,11645,8880,1712,1712,13653,2736,2736,13685,3413,7509,14717,13685,7509,13685,2736,2736,14717,2736,2736,32,7509,7509,33,7509,7509,34,2736,2736,35,2736,2736,8880,2284,10476,14685,8880,10476,8880,2736,2736,14685,4784,13685,18,4784,16,36,8880,37,8880,13653,13685,13653,8880,13685,8880,13621,38,13653,8880,39,8880,13653,40,13653,8880,41,8880,13653,42,13653]) (by decide +kernel)
  change ∀ b ∈ [s5922,s5923,s5924,s5925,s5926,s5927,s5928,s5929,s5930,s5931,s5932,s5933,s5934,s5935,s5936,s5937,s5938,s5939,s991,s5940,s5941,s5942,s5943,s5944,s5945,s5946,s5947,s5948,s5949,s5950,s5951,s5952,s5953,s5954,s5955,s5956,s5957,s5958,s5959,s5960,s5961,s5962,s5963], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5922) b5922 <|
    PetersenLocalChildren.push (x := s5923) b5923 <|
    PetersenLocalChildren.push (x := s5924) b5924 <|
    PetersenLocalChildren.push (x := s5925) b5925 <|
    PetersenLocalChildren.push (x := s5926) b5926 <|
    PetersenLocalChildren.push (x := s5927) b5927 <|
    PetersenLocalChildren.push (x := s5928) b5928 <|
    PetersenLocalChildren.push (x := s5929) b5929 <|
    PetersenLocalChildren.push (x := s5930) b5930 <|
    PetersenLocalChildren.push (x := s5931) b5931 <|
    PetersenLocalChildren.push (x := s5932) b5932 <|
    PetersenLocalChildren.push (x := s5933) b5933 <|
    PetersenLocalChildren.push (x := s5934) b5934 <|
    PetersenLocalChildren.push (x := s5935) b5935 <|
    PetersenLocalChildren.push (x := s5936) b5936 <|
    PetersenLocalChildren.push (x := s5937) b5937 <|
    PetersenLocalChildren.push (x := s5938) b5938 <|
    PetersenLocalChildren.push (x := s5939) b5939 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s5940) b5940 <|
    PetersenLocalChildren.push (x := s5941) b5941 <|
    PetersenLocalChildren.push (x := s5942) b5942 <|
    PetersenLocalChildren.push (x := s5943) b5943 <|
    PetersenLocalChildren.push (x := s5944) b5944 <|
    PetersenLocalChildren.push (x := s5945) b5945 <|
    PetersenLocalChildren.push (x := s5946) b5946 <|
    PetersenLocalChildren.push (x := s5947) b5947 <|
    PetersenLocalChildren.push (x := s5948) b5948 <|
    PetersenLocalChildren.push (x := s5949) b5949 <|
    PetersenLocalChildren.push (x := s5950) b5950 <|
    PetersenLocalChildren.push (x := s5951) b5951 <|
    PetersenLocalChildren.push (x := s5952) b5952 <|
    PetersenLocalChildren.push (x := s5953) b5953 <|
    PetersenLocalChildren.push (x := s5954) b5954 <|
    PetersenLocalChildren.push (x := s5955) b5955 <|
    PetersenLocalChildren.push (x := s5956) b5956 <|
    PetersenLocalChildren.push (x := s5957) b5957 <|
    PetersenLocalChildren.push (x := s5958) b5958 <|
    PetersenLocalChildren.push (x := s5959) b5959 <|
    PetersenLocalChildren.push (x := s5960) b5960 <|
    PetersenLocalChildren.push (x := s5961) b5961 <|
    PetersenLocalChildren.push (x := s5962) b5962 <|
    PetersenLocalChildren.push (x := s5963) b5963 <|
    PetersenLocalChildren.nil
theorem b5964 : Blocked tgt 8 s5964 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5964 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)

theorem b5965 : Blocked tgt 8 s5965 := by
  intro k le c
  apply rejects_sound r764 (0x33330000 :: i5) 6 tgt small764 hot764 [] s5965 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x33330000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv764_3427 (PetersenWireProjection.cons pv764_4260 (PetersenWireProjection.cons pv764_4814 (PetersenWireProjection.cons pv764_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r764 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv764_6790 (PetersenWireProjection.cons pv764_7474 (PetersenWireProjection.cons pv764_8012 rfl)))))))) (by decide +kernel)
theorem b5966 : Blocked tgt 8 s5966 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s5966 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4753 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b6008 : Blocked tgt 8 s6008 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s6008 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b6009 : Blocked tgt 8 s6009 := by
  intro k le c
  apply rejects_sound r768 (0x33003300 :: i5) 6 tgt small768 hot768 [] s6009 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x33003300,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv768_3485 (PetersenWireProjection.cons pv768_4260 (PetersenWireProjection.cons pv768_4814 (PetersenWireProjection.cons pv768_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r768 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv768_6790 (PetersenWireProjection.cons pv768_7474 (PetersenWireProjection.cons pv768_8012 rfl)))))))) (by decide +kernel)
theorem b6010 : Blocked tgt 8 s6010 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6010 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6011 : Blocked tgt 8 s6011 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6011 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5703 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6012 : Blocked tgt 8 s6012 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6012 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2298 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6013 : Blocked tgt 8 s6013 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6013 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2589 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6014 : Blocked tgt 8 s6014 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6014 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6015 : Blocked tgt 8 s6015 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6015 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xf0f0f0f0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7235 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6016 : Blocked tgt 8 s6016 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6016 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0f0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1829 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6017 : Blocked tgt 8 s6017 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6017 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2906 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6018 : Blocked tgt 8 s6018 := by
  intro k le c
  apply rejects_sound r769 (0xf0f00000 :: i5) 6 tgt small769 hot769 [] s6018 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f00000,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv769_4260 (PetersenWireProjection.cons pv769_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r769 (0xf0f0f0f000000000f0f0f0f000000000 : BitVec 128) = 0xf0f00000) (PetersenWireProjection.cons pv769_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r769 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv769_6790 (PetersenWireProjection.cons pv769_7474 (PetersenWireProjection.cons pv769_8012 rfl)))))))) (by decide +kernel)
theorem b6068 : Blocked tgt 8 s6068 := by
  intro k le c
  apply rejects_sound r771 (0xf0f0 :: i5) 6 tgt small771 hot771 [] s6068 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv771_1177 (PetersenWireProjection.cons pv771_4260 (PetersenWireProjection.cons pv771_4814 (PetersenWireProjection.cons pv771_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r771 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv771_6790 (PetersenWireProjection.cons pv771_7474 (PetersenWireProjection.cons pv771_8012 rfl)))))))) (by decide +kernel)

theorem b6069 : Blocked tgt 8 s6069 := by
  intro k le c
  apply rejects_sound r772 (0xf0f0000 :: i5) 6 tgt small772 hot772 [] s6069 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv772_2963 (PetersenWireProjection.cons pv772_4260 (PetersenWireProjection.cons pv772_4814 (PetersenWireProjection.cons pv772_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r772 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv772_6790 (PetersenWireProjection.cons pv772_7474 (PetersenWireProjection.cons pv772_8012 rfl)))))))) (by decide +kernel)
theorem b6070 : Blocked tgt 8 s6070 := by
  intro k le c
  apply rejects_sound r773 (0xf000f000f000f000 :: i6) 7 tgt small773 hot773 [] s6070 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf000f000f000f000,0xf0f0f0f0f0f0f0f0,0x0,0xffffffff00000000,0xffff0000ffff0000,0xff00ff00ff00ff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xf0f0f0f0f0f0f0f00000000000000000 : BitVec 128) = 0xf000f000f000f000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000ffff0000) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r773 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00ff00ff00) rfl)))))))) (by decide +kernel)
theorem b6071 : Blocked tgt 8 s6071 := by
  intro k le c
  apply rejects_sound r766 (0xfff0fff0 :: i5) 6 tgt small766 hot766 [] s6071 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00,0xfff0fff0] (PetersenWireProjection.cons pv766_4260 (PetersenWireProjection.cons pv766_4814 (PetersenWireProjection.cons pv766_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r766 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv766_6790 (PetersenWireProjection.cons pv766_7474 (PetersenWireProjection.cons pv766_8012 (PetersenWireProjection.cons pv766_8245 rfl)))))))) (by decide +kernel)
theorem b6072 : Blocked tgt 8 s6072 := by
  intro k le c
  apply rejects_sound r760 (0xf000f0 :: i5) 6 tgt small760 hot760 [] s6072 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf000f0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv760_456 (PetersenWireProjection.cons pv760_4260 (PetersenWireProjection.cons pv760_4814 (PetersenWireProjection.cons pv760_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r760 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv760_6790 (PetersenWireProjection.cons pv760_7474 (PetersenWireProjection.cons pv760_8012 rfl)))))))) (by decide +kernel)
theorem b6073 : Blocked tgt 8 s6073 := by
  intro k le c
  apply rejects_sound r767 (0xf000f00 :: i5) 6 tgt small767 hot767 [] s6073 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf000f00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv767_3004 (PetersenWireProjection.cons pv767_4260 (PetersenWireProjection.cons pv767_4814 (PetersenWireProjection.cons pv767_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r767 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv767_6790 (PetersenWireProjection.cons pv767_7474 (PetersenWireProjection.cons pv767_8012 rfl)))))))) (by decide +kernel)
theorem b6074 : Blocked tgt 8 s6074 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6074 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5000000f5000000f5000000f5000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6075 : Blocked tgt 8 s6075 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6075 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffff500fffff500fffff500fffff500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6076 : Blocked tgt 8 s6076 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6076 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1841 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6077 : Blocked tgt 8 s6077 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6077 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaff00000aff00000aff00000aff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6078 : Blocked tgt 8 s6078 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6078 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500f50000000000f500f50000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6079 : Blocked tgt 8 s6079 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6079 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffffffff500f500fffffffff500f500 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6080 : Blocked tgt 8 s6080 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6080 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1196 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6081 : Blocked tgt 8 s6081 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6081 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00ff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaff0aff000000000aff0aff00000000 : BitVec 128) = 0xff00ff00) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6082 : Blocked tgt 8 s6082 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6082 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf500f500f500f5000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6083 : Blocked tgt 8 s6083 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6083 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xfffffffffffffffff500f500f500f500 : BitVec 128) = 0xffff0000) rfl)))))))) (by decide +kernel)
theorem b6084 : Blocked tgt 8 s6084 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6084 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_475 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6085 : Blocked tgt 8 s6085 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6085 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xaff0aff0aff0aff0000000000000000 : BitVec 128) = 0xffff0000) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6086 : Blocked tgt 8 s6086 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6086 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6671 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6087 : Blocked tgt 8 s6087 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6087 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_7944 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6088 : Blocked tgt 8 s6088 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6088 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1294 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6089 : Blocked tgt 8 s6089 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6089 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00ff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1925 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6090 : Blocked tgt 8 s6090 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6090 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6738 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6091 : Blocked tgt 8 s6091 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6091 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 (PetersenWireProjection.cons pv2_8331 rfl)))))))) (by decide +kernel)
theorem b6092 : Blocked tgt 8 s6092 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6092 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_581 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6093 : Blocked tgt 8 s6093 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6093 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1977 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6094 : Blocked tgt 8 s6094 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6094 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5682 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7397 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b6095 : Blocked tgt 8 s6095 := by
  intro k le c
  apply rejects_sound r774 (0xffffff00 :: i5) 6 tgt small774 hot774 [] s6095 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00,0xffffff00] (PetersenWireProjection.cons pv774_4260 (PetersenWireProjection.cons pv774_4814 (PetersenWireProjection.cons pv774_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r774 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv774_6790 (PetersenWireProjection.cons pv774_7474 (PetersenWireProjection.cons pv774_8012 (PetersenWireProjection.cons pv774_8377 rfl)))))))) (by decide +kernel)
theorem b6096 : Blocked tgt 8 s6096 := by
  intro k le c
  apply rejects_sound r775 (0xff0000 :: i5) 6 tgt small775 hot775 [] s6096 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff0000,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv775_630 (PetersenWireProjection.cons pv775_4260 (PetersenWireProjection.cons pv775_4814 (PetersenWireProjection.cons pv775_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r775 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv775_6790 (PetersenWireProjection.cons pv775_7474 (PetersenWireProjection.cons pv775_8012 rfl)))))))) (by decide +kernel)
theorem b6097 : Blocked tgt 8 s6097 := by
  intro k le c
  apply rejects_sound r776 (0xff00 :: i5) 6 tgt small776 hot776 [] s6097 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv776_1343 (PetersenWireProjection.cons pv776_4260 (PetersenWireProjection.cons pv776_4814 (PetersenWireProjection.cons pv776_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r776 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv776_6790 (PetersenWireProjection.cons pv776_7474 (PetersenWireProjection.cons pv776_8012 rfl)))))))) (by decide +kernel)
theorem b6100 : Blocked tgt 8 s6100 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6100 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf500f500f500f500f500f500f500f500,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xf500f500f500f500f500f500f500f500) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl)))))))) (by decide +kernel)
theorem b6101 : Blocked tgt 8 s6101 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s6101 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf500f500f500f500f500f500f500f500,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0xf500f500f500f500f500f500f500f500) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b6102 : Blocked tgt 8 s6102 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6102 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3980 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b6103 : Blocked tgt 8 s6103 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6103 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6104 : Blocked tgt 8 s6104 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6104 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6105 : Blocked tgt 8 s6105 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6105 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6106 : Blocked tgt 8 s6106 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6106 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6107 : Blocked tgt 8 s6107 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(false,(0,true),(3,false))] s6107 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_4260 (PetersenWireProjection.cons pv740_4503 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_5682 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl)))))))) (by decide +kernel)
theorem b6108 : Blocked tgt 8 s6108 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6108 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4503 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6109 : Blocked tgt 8 s6109 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6109 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6110 : Blocked tgt 8 s6110 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6110 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6111 : Blocked tgt 8 s6111 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s6111 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xa0a0a0a,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_5682 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_6897 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b6112 : Blocked tgt 8 s6112 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6112 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_6897 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6113 : Blocked tgt 8 s6113 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6113 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6114 : Blocked tgt 8 s6114 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6114 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6115 : Blocked tgt 8 s6115 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s6115 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b6116 : Blocked tgt 8 s6116 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s6116 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b6117 : Blocked tgt 8 s6117 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6117 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6118 : Blocked tgt 8 s6118 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6118 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b6160 : Blocked tgt 8 s6160 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6160 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7588 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6161 : Blocked tgt 8 s6161 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6161 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6162 : Blocked tgt 8 s6162 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6162 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6163 : Blocked tgt 8 s6163 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6163 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5682 (PetersenWireProjection.cons pv739_5729 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)
theorem b6164 : Blocked tgt 8 s6164 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6164 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xffff0000ffff0000,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5729 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6165 : Blocked tgt 8 s6165 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6165 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6166 : Blocked tgt 8 s6166 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6166 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6301 : Blocked tgt 8 s6301 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6301 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b6302 : Blocked tgt 8 s6302 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6302 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8104 rfl))))))))) (by decide +kernel)
theorem b6303 : Blocked tgt 8 s6303 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6303 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b6304 : Blocked tgt 8 s6304 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6304 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b6400 : Blocked tgt 8 s6400 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(false,(0,true),(4,false))] s6400 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5682 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl)))))))) (by decide +kernel)

theorem b6401 : Blocked tgt 8 s6401 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s6401 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xffffffff00000000,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
