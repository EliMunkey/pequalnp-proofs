import higher.WireProjection
import M191StartPreferredCuts0
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv0_4260 : PetersenPackedPin.project r0 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv0_4814 : PetersenPackedPin.project r0 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccccccccccccccccccccccccccc := by decide +kernel
theorem pv0_5473 : PetersenPackedPin.project r0 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv0_6170 : PetersenPackedPin.project r0 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xff00ff00ff00ff00ff00ff00ff00ff00 := by decide +kernel
theorem pv0_6790 : PetersenPackedPin.project r0 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000ffff0000ffff0000 := by decide +kernel
theorem pv0_7474 : PetersenPackedPin.project r0 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffffffff00000000ffffffff00000000 := by decide +kernel
theorem pv0_8012 : PetersenPackedPin.project r0 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xffffffffffffffff0000000000000000 := by decide +kernel
theorem pv0_351 : PetersenPackedPin.project r0 (0xaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 1 pv0_4260 pv0_8012 rfl rfl
theorem pv0_1734 : PetersenPackedPin.project r0 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaa0000aaaa0000aaaa0000aaaa := PetersenWireProjection.derive 1 pv0_4260 pv0_6790 rfl rfl
theorem pv0_2192 : PetersenPackedPin.project r0 (0xaa00aa00aa00aa00aa00aa00aa00aa : BitVec 128) = 0xaa00aa00aa00aa00aa00aa00aa00aa := PetersenWireProjection.derive 1 pv0_4260 pv0_6170 rfl rfl
theorem pv0_2708 : PetersenPackedPin.project r0 (0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a : BitVec 128) = 0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a := PetersenWireProjection.derive 1 pv0_4260 pv0_5473 rfl rfl
theorem pv0_3632 : PetersenPackedPin.project r0 (0x50505050505050505050505050505050 : BitVec 128) = 0x50505050505050505050505050505050 := PetersenWireProjection.derive 2 pv0_4260 pv0_5473 rfl rfl
theorem pv0_5850 : PetersenPackedPin.project r0 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xfafafafafafafafafafafafafafafafa := PetersenWireProjection.derive 3 pv0_4260 pv0_5473 rfl rfl
theorem pv0_6504 : PetersenPackedPin.project r0 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xffaaffaaffaaffaaffaaffaaffaaffaa := PetersenWireProjection.derive 3 pv0_4260 pv0_6170 rfl rfl
theorem pv0_7095 : PetersenPackedPin.project r0 (0xffffaaaaffffaaaaffffaaaaffffaaaa : BitVec 128) = 0xffffaaaaffffaaaaffffaaaaffffaaaa := PetersenWireProjection.derive 3 pv0_4260 pv0_6790 rfl rfl
theorem pv0_7855 : PetersenPackedPin.project r0 (0xffffffffff00ff00ffffffffff00ff00 : BitVec 128) = 0xffffffffff00ff00ffffffffff00ff00 := PetersenWireProjection.derive 3 pv0_6170 pv0_7474 rfl rfl
theorem pv0_0 : PetersenPackedPin.project r0 (0x0 : BitVec 128) = 0x0 := PetersenWireProjection.derive 0 pv0_351 pv0_8012 rfl rfl
theorem pv0_6308 : PetersenPackedPin.project r0 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xff0aff0aff0aff0aff0aff0aff0aff0a := PetersenWireProjection.derive 3 pv0_2708 pv0_6170 rfl rfl
end PetersenSmallStarts.M191.Residual
