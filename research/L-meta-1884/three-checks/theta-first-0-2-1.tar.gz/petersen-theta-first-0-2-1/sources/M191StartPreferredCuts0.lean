import M191StartPreferredCommon
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r0 (x : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127] : Array (Fin 128))[x.val]?.getD 0
theorem small0 : NoAtMost i7 (PetersenPackedPin.project r0 tgt) 10 := by
  have a : PetersenPackedPin.project r0 tgt = table 191 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 191 0 (by decide +kernel) (by decide +kernel)
theorem hot0 : forcedConst r0 tgt = false := by decide +kernel
def r1 (x : Fin 64) : Fin 128 := (#[0,1,4,5,8,9,12,13,16,17,20,21,24,25,28,29,32,33,36,37,40,41,44,45,48,49,52,53,56,57,60,61,64,65,68,69,72,73,76,77,80,81,84,85,88,89,92,93,96,97,100,101,104,105,108,109,112,113,116,117,120,121,124,125] : Array (Fin 128))[x.val]?.getD 0
theorem small1 : NoAtMost i6 (PetersenPackedPin.project r1 tgt) 7 := by
  have a : PetersenPackedPin.project r1 tgt = table 189 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 189 0 (by decide +kernel) (by decide +kernel)
theorem hot1 : forcedConst r1 tgt = false := by decide +kernel
def r2 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,32,33,34,35,36,37,38,39,64,65,66,67,68,69,70,71,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small2 : NoAtMost i5 (PetersenPackedPin.project r2 tgt) 6 := by
  have a : PetersenPackedPin.project r2 tgt = table 167 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 167 0 (by decide +kernel) (by decide +kernel)
theorem hot2 : forcedConst r2 tgt = false := by decide +kernel
def r5 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31] : Array (Fin 128))[x.val]?.getD 0
theorem small5 : NoAtMost i5 (PetersenPackedPin.project r5 tgt) 6 := by
  have a : PetersenPackedPin.project r5 tgt = table 31 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 31 0 (by decide +kernel) (by decide +kernel)
theorem hot5 : forcedConst r5 tgt = false := by decide +kernel
def r8 (x : Fin 64) : Fin 128 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,120,122,124,126] : Array (Fin 128))[x.val]?.getD 0
theorem small8 : NoAtMost i6 (PetersenPackedPin.project r8 tgt) 6 := by
  have a : PetersenPackedPin.project r8 tgt = table 190 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 190 0 (by decide +kernel) (by decide +kernel)
theorem hot8 : forcedConst r8 tgt = false := by decide +kernel
def r9 (x : Fin 64) : Fin 128 := (#[0,1,2,3,8,9,10,11,16,17,18,19,24,25,26,27,32,33,34,35,40,41,42,43,48,49,50,51,56,57,58,59,64,65,66,67,72,73,74,75,80,81,82,83,88,89,90,91,96,97,98,99,104,105,106,107,112,113,114,115,120,121,122,123] : Array (Fin 128))[x.val]?.getD 0
theorem small9 : NoAtMost i6 (PetersenPackedPin.project r9 tgt) 6 := by
  have a : PetersenPackedPin.project r9 tgt = table 187 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 187 0 (by decide +kernel) (by decide +kernel)
theorem hot9 : forcedConst r9 tgt = false := by decide +kernel
def r10 (x : Fin 16) : Fin 128 := (#[0,4,8,12,32,36,40,44,64,68,72,76,96,100,104,108] : Array (Fin 128))[x.val]?.getD 0
theorem small10 : NoAtMost i4 (PetersenPackedPin.project r10 tgt) 3 := by
  have a : PetersenPackedPin.project r10 tgt = table 172 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 172 0 (by decide +kernel) (by decide +kernel)
theorem hot10 : forcedConst r10 tgt = false := by decide +kernel
def r11 (x : Fin 16) : Fin 128 := (#[0,4,8,12,16,20,24,28,64,68,72,76,80,84,88,92] : Array (Fin 128))[x.val]?.getD 0
theorem small11 : NoAtMost i4 (PetersenPackedPin.project r11 tgt) 3 := by
  have a : PetersenPackedPin.project r11 tgt = table 156 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 156 0 (by decide +kernel) (by decide +kernel)
theorem hot11 : forcedConst r11 tgt = false := by decide +kernel
def r13 (x : Fin 16) : Fin 128 := (#[0,2,4,6,32,34,36,38,64,66,68,70,96,98,100,102] : Array (Fin 128))[x.val]?.getD 0
theorem small13 : NoAtMost i4 (PetersenPackedPin.project r13 tgt) 3 := by
  have a : PetersenPackedPin.project r13 tgt = table 166 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 166 0 (by decide +kernel) (by decide +kernel)
theorem hot13 : forcedConst r13 tgt = false := by decide +kernel
def r14 (x : Fin 16) : Fin 128 := (#[16,18,20,22,48,50,52,54,80,82,84,86,112,114,116,118] : Array (Fin 128))[x.val]?.getD 0
theorem small14 : NoAtMost i4 (PetersenPackedPin.project r14 tgt) 3 := by
  have a : PetersenPackedPin.project r14 tgt = table 166 16 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 166 16 (by decide +kernel) (by decide +kernel)
theorem hot14 : forcedConst r14 tgt = false := by decide +kernel
def r17 (x : Fin 16) : Fin 128 := (#[0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30] : Array (Fin 128))[x.val]?.getD 0
theorem small17 : NoAtMost i4 (PetersenPackedPin.project r17 tgt) 3 := by
  have a : PetersenPackedPin.project r17 tgt = table 30 0 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 30 0 (by decide +kernel) (by decide +kernel)
theorem hot17 : forcedConst r17 tgt = false := by decide +kernel
def r19 (x : Fin 16) : Fin 128 := (#[32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62] : Array (Fin 128))[x.val]?.getD 0
theorem small19 : NoAtMost i4 (PetersenPackedPin.project r19 tgt) 3 := by
  have a : PetersenPackedPin.project r19 tgt = table 30 32 := by rfl
  rw [a]; exact PetersenSmallStarts.minor 30 32 (by decide +kernel) (by decide +kernel)
theorem hot19 : forcedConst r19 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
