import higher.WireProjection
import M191Values0
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values19
import M191Values2
import M191Values21
import M191Values22
import M191Values30
import M191Values32
import M191Values34
import M191Values35
import M191Values731
import M191Values735
import M191Values737
import M191Values739
import M191Values740
import M191Values744
import M191Values745
import M191Values753
import M191Values754
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows54
import M191StartPreferredRows55
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12258 : Blocked tgt 8 s12258 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12258 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4059 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12259 : Blocked tgt 8 s12259 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12259 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_3632 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12260 : Blocked tgt 8 s12260 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12260 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12261 : Blocked tgt 8 s12261 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12261 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_3632 (PetersenWireProjection.cons pv21_3677 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))))) (by decide +kernel)
theorem b12262 : Blocked tgt 8 s12262 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12262 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12263 : Blocked tgt 8 s12263 := by
  intro k le c
  apply rejects_sound r753 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small753 hot753 [] s12263 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv753_2708 (PetersenWireProjection.cons pv753_3632 (PetersenWireProjection.cons pv753_4814 (PetersenWireProjection.cons pv753_5473 (PetersenWireProjection.cons pv753_6170 (PetersenWireProjection.cons pv753_6790 (PetersenWireProjection.cons pv753_7095 (PetersenWireProjection.cons pv753_7474 (PetersenWireProjection.cons pv753_8012 rfl))))))))) (by decide +kernel)
theorem b12264 : Blocked tgt 8 s12264 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12264 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12265 : Blocked tgt 8 s12265 := by
  intro k le c
  apply rejects_sound r30 i4 3 tgt small30 hot30 [] s12265 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv30_2708 (PetersenWireProjection.cons pv30_3632 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r30 (0x55550000555500005555000055550000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv30_4814 (PetersenWireProjection.cons pv30_5473 (PetersenWireProjection.cons pv30_6170 (PetersenWireProjection.cons pv30_6790 (PetersenWireProjection.cons pv30_7474 (PetersenWireProjection.cons pv30_8012 rfl))))))))) (by decide +kernel)
theorem b12266 : Blocked tgt 8 s12266 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12266 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12267 : Blocked tgt 8 s12267 := by
  intro k le c
  apply rejects_sound r754 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small754 hot754 [] s12267 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xffffffff00000000,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000] (PetersenWireProjection.cons pv754_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r754 (0x50505050505050505050505050505050 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv754_4814 (PetersenWireProjection.cons pv754_5473 (PetersenWireProjection.cons pv754_6170 (PetersenWireProjection.cons pv754_6790 (PetersenWireProjection.cons pv754_7474 (PetersenWireProjection.cons pv754_7688 (PetersenWireProjection.cons pv754_8012 rfl))))))))) (by decide +kernel)
theorem b12268 : Blocked tgt 8 s12268 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12268 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12269 : Blocked tgt 8 s12269 := by
  intro k le c
  apply rejects_sound r34 i4 3 tgt small34 hot34 [] s12269 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv34_2708 (PetersenWireProjection.cons pv34_3632 (PetersenWireProjection.cons pv34_3730 (PetersenWireProjection.cons pv34_4814 (PetersenWireProjection.cons pv34_5473 (PetersenWireProjection.cons pv34_6170 (PetersenWireProjection.cons pv34_6790 (PetersenWireProjection.cons pv34_7474 (PetersenWireProjection.cons pv34_8012 rfl))))))))) (by decide +kernel)
theorem b12270 : Blocked tgt 8 s12270 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12270 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12271 : Blocked tgt 8 s12271 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12271 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff,0xffff] (PetersenWireProjection.cons pv35_2708 (PetersenWireProjection.cons pv35_3632 (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8012 (PetersenWireProjection.cons pv35_8191 rfl))))))))) (by decide +kernel)
theorem b12272 : Blocked tgt 8 s12272 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12272 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12273 : Blocked tgt 8 s12273 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s12273 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons pv22_3632 (PetersenWireProjection.cons pv22_3759 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 rfl))))))))) (by decide +kernel)
theorem b12274 : Blocked tgt 8 s12274 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12274 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4429 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12275 : Blocked tgt 8 s12275 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s12275 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xffffffff00000000,0xffffffffcccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_2708 (PetersenWireProjection.cons pv735_3632 (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5920 (PetersenWireProjection.cons pv735_6170 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl))))))))) (by decide +kernel)
theorem b12276 : Blocked tgt 8 s12276 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12276 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2800 (PetersenWireProjection.cons pv10_3632 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12277 : Blocked tgt 8 s12277 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12277 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)

theorem b12278 : Blocked tgt 8 s12278 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12278 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5241 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12279 : Blocked tgt 8 s12279 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s12279 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xffffffff00000000,0xaaaaaaaaaaaaaaaa,0xeeeeeeeeeeeeeeee,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r745 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons pv745_6618 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl))))))))) (by decide +kernel)
theorem b12280 : Blocked tgt 8 s12280 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12280 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12281 : Blocked tgt 8 s12281 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12281 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_2860 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b12282 : Blocked tgt 8 s12282 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12282 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5294 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12283 : Blocked tgt 8 s12283 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12283 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_3632 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12284 : Blocked tgt 8 s12284 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12284 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12285 : Blocked tgt 8 s12285 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12285 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_3632 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b12286 : Blocked tgt 8 s12286 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12286 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5367 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12287 : Blocked tgt 8 s12287 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12287 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0xaaaa,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_3632 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b12288 : Blocked tgt 8 s12288 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12288 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1177 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12289 : Blocked tgt 8 s12289 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s12289 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0x0,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons pv11_2963 (PetersenWireProjection.cons pv11_3632 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl))))))))) (by decide +kernel)
theorem b12290 : Blocked tgt 8 s12290 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12290 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5425 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12291 : Blocked tgt 8 s12291 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s12291 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0x0,0xffffffff00000000,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc] (PetersenWireProjection.cons pv744_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r744 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv744_4260 (PetersenWireProjection.cons pv744_4814 (PetersenWireProjection.cons pv744_6170 (PetersenWireProjection.cons pv744_6790 (PetersenWireProjection.cons pv744_7474 (PetersenWireProjection.cons pv744_8012 (PetersenWireProjection.cons pv744_8245 rfl))))))))) (by decide +kernel)
theorem b12292 : Blocked tgt 8 s12292 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12292 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_456 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3632 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b12293 : Blocked tgt 8 s12293 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s12293 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccc,0x0,0xaaaa,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_2708 (PetersenWireProjection.cons pv17_3004 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0x50505050505050505050505050505050 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_6170 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl))))))))) (by decide +kernel)

theorem b12296 : Blocked tgt 8 s12296 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12296 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12297 : Blocked tgt 8 s12297 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12297 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12298 : Blocked tgt 8 s12298 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12298 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4503 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12299 : Blocked tgt 8 s12299 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(false,(0,false),(2,true)),(true,(1,false),(4,false))] s12299 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffaaffaaffaaffaaffaaffaaffaaffaa,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_2708 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6504 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b12300 : Blocked tgt 8 s12300 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12300 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12301 : Blocked tgt 8 s12301 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12301 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12302 : Blocked tgt 8 s12302 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12302 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2024 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12303 : Blocked tgt 8 s12303 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12303 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b12304 : Blocked tgt 8 s12304 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12304 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12305 : Blocked tgt 8 s12305 := by
  intro k le c
  apply rejects_sound r731 (0xa0a0a0a0 :: i5) 6 tgt small731 hot731 [] s12305 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0xa0a0a0a0,0x0,0xaaaaaaaa,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv731_4814 (PetersenWireProjection.cons pv731_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r731 (0xf5a0f5a0f5a0f5a0f5a0f5a0f5a0f5a0 : BitVec 128) = 0xa0a0a0a0) (PetersenWireProjection.cons pv731_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r731 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons pv731_6790 (PetersenWireProjection.cons pv731_7474 (PetersenWireProjection.cons pv731_8012 rfl)))))))) (by decide +kernel)
theorem b12325 : Blocked tgt 8 s12325 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12325 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_5696 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b12326 : Blocked tgt 8 s12326 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12326 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12327 : Blocked tgt 8 s12327 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12327 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1496 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12328 : Blocked tgt 8 s12328 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12328 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12329 : Blocked tgt 8 s12329 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12329 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2686 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b12330 : Blocked tgt 8 s12330 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12330 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_893 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12331 : Blocked tgt 8 s12331 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12331 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5729 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b12332 : Blocked tgt 8 s12332 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12332 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2698 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12333 : Blocked tgt 8 s12333 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12333 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_178 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b12334 : Blocked tgt 8 s12334 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12334 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_5745 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b12335 : Blocked tgt 8 s12335 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12335 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4429 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12343 : Blocked tgt 8 s12343 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12343 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_2800 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12344 : Blocked tgt 8 s12344 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12344 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_3209 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12345 : Blocked tgt 8 s12345 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12345 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4522 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12396 : Blocked tgt 8 s12396 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12396 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6546 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12397 : Blocked tgt 8 s12397 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12397 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2240 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12398 : Blocked tgt 8 s12398 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s12398 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xaaaaaaaa,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_3304 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6504 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b12399 : Blocked tgt 8 s12399 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12399 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3304 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12400 : Blocked tgt 8 s12400 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12400 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4579 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)

theorem b12401 : Blocked tgt 8 s12401 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12401 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6597 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12402 : Blocked tgt 8 s12402 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12402 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2093 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12418 : Blocked tgt 8 s12418 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12418 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b12419 : Blocked tgt 8 s12419 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12419 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4586 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12420 : Blocked tgt 8 s12420 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12420 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12421 : Blocked tgt 8 s12421 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12421 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12422 : Blocked tgt 8 s12422 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12422 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12423 : Blocked tgt 8 s12423 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12423 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4675 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12428 : Blocked tgt 8 s12428 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12428 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_1117 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12429 : Blocked tgt 8 s12429 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12429 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3427 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b12430 : Blocked tgt 8 s12430 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12430 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4753 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12433 : Blocked tgt 8 s12433 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(1,false),(3,false))] s12433 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv740_391 (PetersenWireProjection.cons pv740_2708 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6170 (PetersenWireProjection.cons pv740_6504 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 rfl))))))))) (by decide +kernel)
theorem b12434 : Blocked tgt 8 s12434 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12434 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3485 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)

theorem b12435 : Blocked tgt 8 s12435 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s12435 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0x0,0xf0f0f0f0,0xaaaaaaaa,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5241 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6504 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl)))))))) (by decide +kernel)
theorem b12436 : Blocked tgt 8 s12436 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12436 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0x0,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12437 : Blocked tgt 8 s12437 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12437 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6618 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12471 : Blocked tgt 8 s12471 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12471 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2298 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12472 : Blocked tgt 8 s12472 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12472 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12473 : Blocked tgt 8 s12473 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s12473 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5284 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b12474 : Blocked tgt 8 s12474 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12474 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5284 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b12475 : Blocked tgt 8 s12475 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12475 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6659 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12476 : Blocked tgt 8 s12476 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12476 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2099 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12477 : Blocked tgt 8 s12477 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12477 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_2884 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))))) (by decide +kernel)
theorem b12478 : Blocked tgt 8 s12478 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12478 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0x0,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5294 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12479 : Blocked tgt 8 s12479 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12479 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12480 : Blocked tgt 8 s12480 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12480 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b12481 : Blocked tgt 8 s12481 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12481 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_2906 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b12482 : Blocked tgt 8 s12482 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12482 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5367 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)

theorem b12491 : Blocked tgt 8 s12491 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12491 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1177 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12492 : Blocked tgt 8 s12492 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12492 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_2963 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b12493 : Blocked tgt 8 s12493 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12493 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5425 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12501 : Blocked tgt 8 s12501 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12501 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_456 (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b12502 : Blocked tgt 8 s12502 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12502 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffaaffaa,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_3004 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6170 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7474 (PetersenWireProjection.cons pv739_8012 rfl))))))))) (by decide +kernel)
theorem b12503 : Blocked tgt 8 s12503 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12503 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b12504 : Blocked tgt 8 s12504 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12504 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
