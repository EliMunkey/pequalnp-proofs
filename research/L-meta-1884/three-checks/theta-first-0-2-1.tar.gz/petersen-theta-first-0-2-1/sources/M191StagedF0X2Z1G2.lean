import higher.WireProjection
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values19
import M191Values2
import M191Values21
import M191Values22
import M191Values32
import M191Values35
import M191Values39
import M191Values41
import M191Values5
import M191Values733
import M191Values734
import M191Values765
import M191Values787
import M191Values798
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts4
import M191StartPreferredCuts6
import M191StartPreferredCuts7
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows65
import M191StartPreferredRows66
import M191StartPreferredRows67
import M191StartPreferredRows68
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b14567 : Blocked tgt 6 s14567 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14567 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xffff,0x0,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x8cc08c808cc08c808cc08c808cc08c8 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_2757 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b14568 : Blocked tgt 6 s14568 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14568 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x5555,0xffff,0x0,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0x2330232023302320233023202330232 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv14_2757 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b14614 : Blocked tgt 6 s14614 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s14614 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x808080808080808ccccc8c8ccccc8c8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b14615 : Blocked tgt 6 s14615 := by
  intro k le c
  apply rejects_sound r798 (0x4444 :: i4) 3 tgt small798 hot798 [] s14615 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r798 (0x2020202020202023333323233333232 : BitVec 128) = 0x4444) (PetersenWireProjection.cons pv798_4260 (PetersenWireProjection.cons pv798_5473 (PetersenWireProjection.cons pv798_6170 (PetersenWireProjection.cons pv798_6790 (PetersenWireProjection.cons pv798_7474 (PetersenWireProjection.cons pv798_8012 rfl))))))) (by decide +kernel)
theorem b14616 : Blocked tgt 6 s14616 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s14616 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xa0a0a0a0a0a0a0afffffafafffffafa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl))))))) (by decide +kernel)
theorem b14965 : Blocked tgt 6 s14965 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5544,6836,1608,5544,6836,773,6964,6836,6836,4520,7218,6836,4772,4788,6820,4772,2708,2740,6804,2708,5544,6836,6836,5544,9673,901,1737,1737,7218,840,7218,2896,11465,2693,11465,2693,13513,4741,13513,4741,5672,5672,901,8649,1669,901,901,4916,2693,901,901,2868,4741,901,1417,901,901,1417,2693,10441,2693,11457,4741,12489,4741,13505,7218,3152,14386,7218,2693,3112,4741,2693,3209,2693,2693,3209,5257,4741,4741,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b15220 : Blocked tgt 6 s15220 := by
  intro k le c
  apply rejects_sound r797 (0x3300 :: i4) 3 tgt small797 hot797 [] s15220 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x3300,0xcccc,0xf0f0,0x0,0x0,0xaaaa,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0x50505050505050505050505050505050 : BitVec 128) = 0x3300) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r797 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0) rfl))))))) (by decide +kernel)
theorem b15221 : Blocked tgt 6 s15221 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15221 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x55005500550055005500550055005500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15222 : Blocked tgt 6 s15222 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15222 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x55555555555555550000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b15225 : Blocked tgt 6 s15225 := by
  intro k le c
  apply rejects_sound r800 (0xf0 :: i4) 3 tgt small800 hot800 [] s15225 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0,0xcccc,0xf0f0,0x0,0x0,0xaaaa,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xd0d0d0d0d0d0d0d0d0c0d0c0d0c0d0c : BitVec 128) = 0xf0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r800 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0x0) rfl))))))) (by decide +kernel)

theorem b15226 : Blocked tgt 6 s15226 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15226 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf000f000f000f000f000f000f000f00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15227 : Blocked tgt 6 s15227 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15227 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf0f0f0f0f0f0f0f0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b15228 : Blocked tgt 6 s15228 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15228 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0x0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xfd00fd00fd00fd00fd00fd00fd00fd00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15229 : Blocked tgt 6 s15229 := by
  intro k le c
  apply rejects_sound r765 (0x3300 :: i4) 3 tgt small765 hot765 [] s15229 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x3300,0xf0f0,0xaaaa,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xfd00fd00fd00fd00cc00cc00cc00cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv765_4260 (PetersenWireProjection.cons pv765_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r765 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0x3300) (PetersenWireProjection.cons pv765_6790 (PetersenWireProjection.cons pv765_7474 (PetersenWireProjection.cons pv765_8012 rfl))))))) (by decide +kernel)
theorem b15230 : Blocked tgt 6 s15230 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15230 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0x0,0xcccc,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xfdfdfdfdfdfdfdfd0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b15231 : Blocked tgt 6 s15231 := by
  intro k le c
  apply rejects_sound r787 (0x3300 :: i4) 3 tgt small787 hot787 [] s15231 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x3300,0x0,0xaaaa,0xf0f0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xfdccfdccfdccfdcc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv787_4260 (PetersenWireProjection.cons pv787_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r787 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0x3300) (PetersenWireProjection.cons pv787_6170 (PetersenWireProjection.cons pv787_6790 (PetersenWireProjection.cons pv787_7474 rfl))))))) (by decide +kernel)
theorem b15232 : Blocked tgt 6 s15232 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15232 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0xcccc,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xff000000ff000000ff000000ff000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15233 : Blocked tgt 6 s15233 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15233 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xff000000ff000000ff000000ff0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15234 : Blocked tgt 6 s15234 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15234 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0xcccc,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b15235 : Blocked tgt 6 s15235 := by
  intro k le c
  apply rejects_sound r41 i4 3 tgt small41 hot41 [] s15235 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xf0f0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffffffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv41_4260 (PetersenWireProjection.cons pv41_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xfdfdfdfdfdfdfdfdfdccfdccfdccfdcc : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv41_6170 (PetersenWireProjection.cons pv41_6790 (PetersenWireProjection.cons pv41_7474 rfl))))))) (by decide +kernel)
theorem b15238 : Blocked tgt 6 s15238 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s15238 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5944 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b15239 : Blocked tgt 6 s15239 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s15239 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xfdfdfdfdfdfdfdfd0000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)
theorem b15275 : Blocked tgt 6 s15275 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15275 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0x0,0xcccc,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf500f500f500f500f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b15276 : Blocked tgt 6 s15276 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s15276 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xf0f0,0x0,0xcccc,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6170 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b15289 : Blocked tgt 6 s15289 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,true),(4,false)),(true,(0,false),(2,false))] s15289 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xddddcccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xddddddddddddddddddccddccddccddcc : BitVec 128) = 0xddddcccc) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b15290 : Blocked tgt 6 s15290 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,true),(3,false)),(true,(0,false),(2,false))] s15290 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xddccddcc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xddddddddddddddddddccddccddccddcc : BitVec 128) = 0xddccddcc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)

theorem b15410 : Blocked tgt 6 s15410 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s15410 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0x2a2a2a2a2a2a0a0a2a2a2a2a2a2a0a0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b15429 : Blocked tgt 6 s15429 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(2,true),(3,false)),(true,(0,false),(2,false))] s15429 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcfcccfcc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xcfcfcfcfcfcfcccccfcfcfcfcfcfcccc : BitVec 128) = 0xcfcccfcc) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b15430 : Blocked tgt 6 s15430 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(2,true),(3,false)),(true,(0,false),(2,false))] s15430 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcfcccfcc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xcfcfcfcfcfcfcccccfcfcfcfcfcfcccc : BitVec 128) = 0xcfcccfcc) (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b15431 : Blocked tgt 6 s15431 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(2,true),(4,false)),(true,(0,false),(2,false))] s15431 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcfcfcccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xcfcfcfcfcfcfcccccfcfcfcfcfcfcccc : BitVec 128) = 0xcfcfcccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b15432 : Blocked tgt 6 s15432 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(2,true),(4,false)),(true,(0,false),(2,false))] s15432 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcfcfcccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xcfcfcfcfcfcfcccccfcfcfcfcfcfcccc : BitVec 128) = 0xcfcfcccc) (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)
theorem b168 : Blocked tgt 7 s168 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s168 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b169 : Blocked tgt 7 s169 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s169 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4503 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b170 : Blocked tgt 7 s170 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s170 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5224 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b171 : Blocked tgt 7 s171 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s171 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5154 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b172 : Blocked tgt 7 s172 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s172 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xecececececececececececececececec : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b173 : Blocked tgt 7 s173 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s173 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b174 : Blocked tgt 7 s174 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s174 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b175 : Blocked tgt 7 s175 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s175 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b176 : Blocked tgt 7 s176 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s176 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b177 : Blocked tgt 7 s177 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s177 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b178 : Blocked tgt 7 s178 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s178 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3121 (PetersenWireProjection.cons pv8_5175 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b179 : Blocked tgt 7 s179 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s179 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_3121 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b180 : Blocked tgt 7 s180 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s180 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4429 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xecececececececececececececececec : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b181 : Blocked tgt 7 s181 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s181 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xecececececececececececececececec : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b182 : Blocked tgt 7 s182 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s182 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xecececececececececececececececec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b183 : Blocked tgt 7 s183 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s183 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2240 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5175 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)

theorem b184 : Blocked tgt 7 s184 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s184 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5175 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b185 : Blocked tgt 7 s185 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s185 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1779 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5175 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b186 : Blocked tgt 7 s186 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s186 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xecececececececececececececececec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6170 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b187 : Blocked tgt 7 s187 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s187 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1117 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5175 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b188 : Blocked tgt 7 s188 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s188 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xecececececececececececececececec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 (PetersenWireProjection.cons pv22_8208 rfl)))))))) (by decide +kernel)
theorem b189 : Blocked tgt 7 s189 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s189 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_5175 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b190 : Blocked tgt 7 s190 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s190 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5149 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b191 : Blocked tgt 7 s191 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s191 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_3063 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b192 : Blocked tgt 7 s192 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s192 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xffecffecffecffecffecffecffecffec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b193 : Blocked tgt 7 s193 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s193 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xec00ec00ec00ec00ec00ec00ec00ec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b194 : Blocked tgt 7 s194 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s194 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv22_2708 (PetersenWireProjection.cons pv22_4814 (PetersenWireProjection.cons pv22_5473 (PetersenWireProjection.cons pv22_6170 (PetersenWireProjection.cons pv22_6790 (PetersenWireProjection.cons pv22_7474 (PetersenWireProjection.cons pv22_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r22 (0xffffffffffffffffecececececececec : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b195 : Blocked tgt 7 s195 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s195 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xecececececececec : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b205 : Blocked tgt 7 s205 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s205 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5850 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6456 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b206 : Blocked tgt 7 s206 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s206 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b207 : Blocked tgt 7 s207 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s207 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b208 : Blocked tgt 7 s208 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s208 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5682 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b209 : Blocked tgt 7 s209 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s209 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b210 : Blocked tgt 7 s210 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s210 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5696 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b211 : Blocked tgt 7 s211 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s211 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8104 rfl)))))))) (by decide +kernel)
theorem b212 : Blocked tgt 7 s212 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s212 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xffffffff00000000,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5745 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 rfl)))))))) (by decide +kernel)
theorem b213 : Blocked tgt 7 s213 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s213 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xffa0ffa0ffa0ffa0ffa0ffa0ffa0ffa0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_6546 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl)))))))) (by decide +kernel)
theorem b214 : Blocked tgt 7 s214 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s214 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_3304 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6456 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b215 : Blocked tgt 7 s215 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s215 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0x33203320332033203320332033203320 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b216 : Blocked tgt 7 s216 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s216 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5241 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6456 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b217 : Blocked tgt 7 s217 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s217 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6456 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b218 : Blocked tgt 7 s218 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s218 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5284 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b219 : Blocked tgt 7 s219 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s219 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2099 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b220 : Blocked tgt 7 s220 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s220 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6456 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b221 : Blocked tgt 7 s221 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s221 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2154 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b222 : Blocked tgt 7 s222 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s222 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6456 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7314 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b223 : Blocked tgt 7 s223 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s223 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1887 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6456 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b224 : Blocked tgt 7 s224 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s224 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6456 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7855 (PetersenWireProjection.cons pv19_8012 rfl)))))))) (by decide +kernel)

theorem b225 : Blocked tgt 7 s225 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s225 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_1252 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6456 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b226 : Blocked tgt 7 s226 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s226 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6456 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons pv32_8295 rfl)))))))) (by decide +kernel)
theorem b227 : Blocked tgt 7 s227 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s227 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_531 (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6456 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b228 : Blocked tgt 7 s228 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s228 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv32_2708 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xffffffffffffffffffa0ffa0ffa0ffa0 : BitVec 128) = 0xffff) rfl)))))))) (by decide +kernel)
theorem b229 : Blocked tgt 7 s229 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s229 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xffa0ffa0ffa0ffa0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_2708 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons pv13_6170 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b349 : Blocked tgt 7 s349 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s349 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b350 : Blocked tgt 7 s350 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s350 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5029 (PetersenWireProjection.cons pv10_5224 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b351 : Blocked tgt 7 s351 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s351 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)

theorem b352 : Blocked tgt 7 s352 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s352 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b353 : Blocked tgt 7 s353 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s353 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b354 : Blocked tgt 7 s354 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s354 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3939 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b355 : Blocked tgt 7 s355 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s355 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3121 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b356 : Blocked tgt 7 s356 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s356 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3121 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b357 : Blocked tgt 7 s357 := by
  intro k le c
  apply rejects_sound r733 (0xffffffffcccccccc :: i6) 6 tgt small733 hot733 [] s357 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffffffff00000000,0xffffffffcccccccc,0xcccccccccccccccc,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv733_3632 (PetersenWireProjection.cons pv733_4814 (PetersenWireProjection.cons pv733_5029 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r733 (0xfafafafafafafafafafafafafafafafa : BitVec 128) = 0xcccccccccccccccc) (PetersenWireProjection.cons pv733_6170 (PetersenWireProjection.cons pv733_6790 (PetersenWireProjection.cons pv733_7474 (PetersenWireProjection.cons pv733_8012 rfl)))))))) (by decide +kernel)
theorem b358 : Blocked tgt 7 s358 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s358 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccccccccccc,0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3632 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b361 : Blocked tgt 7 s361 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s361 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2192 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b364 : Blocked tgt 7 s364 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s364 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b365 : Blocked tgt 7 s365 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s365 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_5029 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b366 : Blocked tgt 7 s366 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s366 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5850 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b367 : Blocked tgt 7 s367 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s367 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4514 (PetersenWireProjection.cons pv10_5029 (PetersenWireProjection.cons pv10_5850 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b368 : Blocked tgt 7 s368 := by
  intro k le c
  apply rejects_sound r734 (0xcccccccc :: i6) 6 tgt small734 hot734 [] s368 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv734_3276 (PetersenWireProjection.cons pv734_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r734 (0xcececececececececececececececece : BitVec 128) = 0xffffffff00000000) (PetersenWireProjection.cons pv734_5850 (PetersenWireProjection.cons pv734_6170 (PetersenWireProjection.cons pv734_6790 (PetersenWireProjection.cons pv734_7474 (PetersenWireProjection.cons pv734_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
