import Petersen191Symmetry
import M191StartPreferredSignals
import M191ResidualC8A0G1
import M191StagedF0X2Z1G40
import M191StagedF0X2Z1G41
import M191StagedF0X2Z1G42
import M191StagedF0X2Z1G43
import M191StagedF0X2Z1G44
import M191StagedF0X2Z1G45
import M191StagedF0X2Z1G46
import M191StagedF0X2Z1G47
import M191StagedF0X2Z1G48
import M191StagedF0X2Z1G49
import M191StagedF0X2Z1G50
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G52
import M191StagedF0X2Z1G53
import M191StagedF0X2Z1G54
import M191StagedF0X2Z1G55
import M191StagedF0X2Z1G56
import M191StagedF0X2Z1G57
import M191StagedF0X2Z1G58
import M191StagedF0X2Z1G59
import M191StagedF0X2Z1G60
import M191StagedF0X2Z1G61
import M191StagedF0X2Z1G62
import M191StagedF0X2Z1G63
import M191StagedF0X2Z1G64
import M191StagedF0X2Z1G66
import M191StagedF0X2Z1G67
import M191StagedF0X2Z1G72
import M191StagedF0X2Z1G73
import M191StagedF0X2Z1G74
import M191StagedF0X2Z1G75
import M191StagedF0X2Z1G76
import M191StagedF0X2Z1G77
import M191StagedF0X2Z1G78
import M191StagedF0X2Z1G79
import M191StagedF0X2Z1G80
import M191StagedF0X2Z1G81
import M191StagedF0X2Z1G82
import M191StagedF0X2Z1G83
import M191StagedF0X2Z1G85
import M191StagedF0X2Z1G86
import M191StagedF0X2Z1G87
import M191StartPreferredRows0
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows13
import M191StartPreferredRows14
import M191StartPreferredRows18
import M191StartPreferredRows19
import M191StartPreferredRows21
import M191StartPreferredRows22
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows33
import M191StartPreferredRows34
import M191StartPreferredRows35
import M191StartPreferredRows37
import M191StartPreferredRows38
import M191StartPreferredRows39
import M191StartPreferredRows4
import M191StartPreferredRows42
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows46
import M191StartPreferredRows47
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows58
import M191StartPreferredRows6
import M191StartPreferredRows60
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows7
import M191StartPreferredRows9
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
private theorem thetaPair6099i0 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6100,s6101,s5837,s150,s6102]) (hints := [6583,0,6841,1,6583,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s6100,s6101,s5837,s150,s6102], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6100) (b6100) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6101) (b6101) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5837) (b5837) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s150) (b150) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6102) (b6102) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i1 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6103,s6104,s980,s1023,s6105,s6106,s6107,s6108]) (hints := [909,0,909,1,8649,2,8649,3,909,4,909,5,8649,6,8649,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6103,s6104,s980,s1023,s6105,s6106,s6107,s6108], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6103) (b6103) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6104) (b6104) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s980) (b980) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1023) (b1023) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6105) (b6105) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6106) (b6106) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6107) (b6107) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6108) (b6108) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i2 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6100,s6101,s2957,s2596,s3011]) (hints := [8902,0,5935,1,8902,2,3,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s6100,s6101,s2957,s2596,s3011], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6100) (b6100) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6101) (b6101) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2957) (b2957) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2596) (b2596) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3011) (b3011) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i3 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6100,s6101,s5555,s4744,s3264,s4746]) (hints := [1675,0,1675,1,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6100,s6101,s5555,s4744,s3264,s4746], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6100) (b6100) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6101) (b6101) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5555) (b5555) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4744) (b4744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3264) (b3264) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4746) (b4746) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i4 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6109,s6110,s6111,s6112,s6113,s6114,s6115,s6116]) (hints := [2701,0,2701,1,10441,2,10441,3,2701,4,2701,5,10441,6,10441,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6109,s6110,s6111,s6112,s6113,s6114,s6115,s6116], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6109) (b6109) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6110) (b6110) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6111) (b6111) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6112) (b6112) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6113) (b6113) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6114) (b6114) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6115) (b6115) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6116) (b6116) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i5 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6117,s6118,s6119,s6160,s6161,s6162,s6163,s6164]) (hints := [4749,0,4749,1,12489,2,12489,3,4749,4,4749,5,12489,6,12489,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s6117,s6118,s6119,s6160,s6161,s6162,s6163,s6164], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6117) (b6117) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6118) (b6118) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6119) (b6119) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6160) (b6160) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6161) (b6161) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6162) (b6162) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6163) (b6163) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6164) (b6164) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i6 : PetersenLocalChildren.PairOK tgt 8 s6099 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6165,s6166,s6167,s6256,s6301,s6302,s6303,s6304,s6305,s6400,s6401,s6402]) (hints := [8849,0,8849,1,2,3,4,5,8849,6,8849,7,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s6165,s6166,s6167,s6256,s6301,s6302,s6303,s6304,s6305,s6400,s6401,s6402], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6165) (b6165) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6166) (b6166) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6167) (b6167) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6256) (b6256) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6301) (b6301) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6302) (b6302) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6303) (b6303) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6304) (b6304) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6305) (b6305) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6400) (b6400) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6401) (b6401) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6402) (b6402) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i7 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6403,s6404,s6425,s6426,s6427,s6428]) (hints := [6842,6842,6970,0,8647,1,8647,2,6970,3,6970,4,8647,6842,8647,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6403,s6404,s6425,s6426,s6427,s6428], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6403) (b6403) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6404) (b6404) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6425) (b6425) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6426) (b6426) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6427) (b6427) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6428) (b6428) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i8 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s150,s6102,s2596,s3011,s6429,s6430,s6431]) (hints := [5937,0,5937,1,6843,6843,2,3,6065,4,5,6]) (by decide +kernel) ?_
  change ∀ x ∈ [s150,s6102,s2596,s3011,s6429,s6430,s6431], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s150) (b150) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6102) (b6102) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2596) (b2596) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3011) (b3011) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6429) (b6429) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6430) (b6430) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6431) (b6431) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i9 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6432,s6433,s6434,s6435,s6436,s6437]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6432,s6433,s6434,s6435,s6436,s6437], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6432) (b6432) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6433) (b6433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6434) (b6434) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6435) (b6435) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6436) (b6436) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6437) (b6437) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i10 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6438,s6439,s6440,s6441]) (hints := [7470,4776,7470,0,10437,6840,10437,1,7470,6840,7470,2,10437,4776,10437,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6438,s6439,s6440,s6441], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6438) (b6438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6439) (b6439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6440) (b6440) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6441) (b6441) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i11 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6442,s6443,s6444,s6445]) (hints := [13646,2712,13646,0,12485,6840,12485,1,13646,6840,13646,2,12485,2712,12485,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6442,s6443,s6444,s6445], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6442) (b6442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6443) (b6443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6444) (b6444) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6445) (b6445) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i12 : PetersenLocalChildren.PairOK tgt 8 s6099 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6446,s6447,s6477,s6478,s6479,s6480]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6446,s6447,s6477,s6478,s6479,s6480], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6446) (b6446) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6447) (b6447) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6477) (b6477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6478) (b6478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6479) (b6479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6480) (b6480) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i13 : PetersenLocalChildren.PairOK tgt 8 s6099 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6481,s6482,s6483,s6484]) (hints := [8645,8645,5676,0,905,905,5934,1,905,905,5676,2,8645,8645,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6481,s6482,s6483,s6484], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6481) (b6481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6482) (b6482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6483) (b6483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6484) (b6484) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i14 : PetersenLocalChildren.PairOK tgt 8 s6099 (word1,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6485,s6486,s6487,s6488,s6489,s6490]) (hints := [8647,8647,1675,0,7224,1,7480,2,1675,3,1675,4,8647,8647,7480,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6485,s6486,s6487,s6488,s6489,s6490], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6485) (b6485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6486) (b6486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6487) (b6487) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6488) (b6488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6489) (b6489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6490) (b6490) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i15 : PetersenLocalChildren.PairOK tgt 8 s6099 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6491,s6492,s6493,s6494]) (hints := [8645,8645,10437,0,4920,6968,7470,1,10437,6968,10437,2,8645,8645,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6491,s6492,s6493,s6494], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6491) (b6491) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6492) (b6492) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6493) (b6493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6494) (b6494) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i16 : PetersenLocalChildren.PairOK tgt 8 s6099 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6495,s6496,s6497,s6498]) (hints := [8645,8645,12485,0,2872,6968,13646,1,12485,6968,12485,2,8645,8645,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6495,s6496,s6497,s6498], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6495) (b6495) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6496) (b6496) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6497) (b6497) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6498) (b6498) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i17 : PetersenLocalChildren.PairOK tgt 8 s6099 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6499,s6500,s6509,s6510]) (hints := [389,389,8841,0,453,8645,13614,1,8581,8645,8841,2,389,389,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6499,s6500,s6509,s6510], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6499) (b6499) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6500) (b6500) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6509) (b6509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6510) (b6510) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i18 : PetersenLocalChildren.PairOK tgt 8 s6099 (word0,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6511,s6512,s6513,s6514]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6511,s6512,s6513,s6514], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6511) (b6511) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6512) (b6512) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6513) (b6513) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6514) (b6514) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i19 : PetersenLocalChildren.PairOK tgt 8 s6099 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6515,s6516,s6517,s6518]) (hints := [10437,5934,10437,0,2697,6966,2697,1,10437,6966,10437,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6515,s6516,s6517,s6518], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6515) (b6515) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6516) (b6516) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6517) (b6517) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6518) (b6518) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i20 : PetersenLocalChildren.PairOK tgt 8 s6099 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6519,s6520,s6521,s6522]) (hints := [12485,10062,12485,0,4745,5934,4745,1,12485,5934,12485,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6519,s6520,s6521,s6522], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6519) (b6519) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6520) (b6520) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6521) (b6521) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6522) (b6522) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i21 : PetersenLocalChildren.PairOK tgt 8 s6099 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6523,s6524,s6525,s6526]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6523,s6524,s6525,s6526], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6523) (b6523) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6524) (b6524) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6525) (b6525) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6526) (b6526) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i22 : PetersenLocalChildren.PairOK tgt 8 s6099 (word25,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6527,s6528,s6529,s6530]) (hints := [10437,1673,10437,0,7470,7478,7470,1,10437,7478,10437,2,1673,1673,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6527,s6528,s6529,s6530], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6527) (b6527) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6528) (b6528) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6529) (b6529) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6530) (b6530) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i23 : PetersenLocalChildren.PairOK tgt 8 s6099 (word25,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6531,s6532,s6533,s6534]) (hints := [12485,1673,12485,0,3382,7478,13646,1,12485,7478,12485,2,1673,1673,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6531,s6532,s6533,s6534], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6531) (b6531) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6532) (b6532) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6533) (b6533) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6534) (b6534) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i24 : PetersenLocalChildren.PairOK tgt 8 s6099 (word25,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6535,s6536,s6537,s6538]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6535,s6536,s6537,s6538], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6535) (b6535) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6536) (b6536) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6537) (b6537) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6538) (b6538) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i25 : PetersenLocalChildren.PairOK tgt 8 s6099 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6539,s6540,s6541,s6542]) (hints := [10437,10437,12485,0,3374,7470,14678,1,12485,7470,12485,2,10437,10437,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6539,s6540,s6541,s6542], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6539) (b6539) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6540) (b6540) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6541) (b6541) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6542) (b6542) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i26 : PetersenLocalChildren.PairOK tgt 8 s6099 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6543,s6544,s6545,s6546]) (hints := [2181,2181,8841,0,2245,10437,14646,1,10373,10437,8841,2,2181,2181,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6543,s6544,s6545,s6546], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6543) (b6543) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6544) (b6544) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6545) (b6545) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6546) (b6546) <|
    PetersenLocalChildren.nil
private theorem thetaPair6099i27 : PetersenLocalChildren.PairOK tgt 8 s6099 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6547,s6548,s6549,s6550]) (hints := [4229,4229,8841,0,4293,12485,13614,1,12421,12485,8841,2,4229,4229,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6547,s6548,s6549,s6550], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6547) (b6547) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6548) (b6548) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6549) (b6549) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6550) (b6550) <|
    PetersenLocalChildren.nil
theorem b6099 : Blocked tgt 9 s6099 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word25),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word25),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word25),(word1,word5),(word1,word2),(word1,word4),(word0,word25),(word0,word5),(word0,word2),(word0,word4),(word25,word5),(word25,word2),(word25,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s6099 p
  exact
    PetersenLocalChildren.push thetaPair6099i0 <|
    PetersenLocalChildren.push thetaPair6099i1 <|
    PetersenLocalChildren.push thetaPair6099i2 <|
    PetersenLocalChildren.push thetaPair6099i3 <|
    PetersenLocalChildren.push thetaPair6099i4 <|
    PetersenLocalChildren.push thetaPair6099i5 <|
    PetersenLocalChildren.push thetaPair6099i6 <|
    PetersenLocalChildren.push thetaPair6099i7 <|
    PetersenLocalChildren.push thetaPair6099i8 <|
    PetersenLocalChildren.push thetaPair6099i9 <|
    PetersenLocalChildren.push thetaPair6099i10 <|
    PetersenLocalChildren.push thetaPair6099i11 <|
    PetersenLocalChildren.push thetaPair6099i12 <|
    PetersenLocalChildren.push thetaPair6099i13 <|
    PetersenLocalChildren.push thetaPair6099i14 <|
    PetersenLocalChildren.push thetaPair6099i15 <|
    PetersenLocalChildren.push thetaPair6099i16 <|
    PetersenLocalChildren.push thetaPair6099i17 <|
    PetersenLocalChildren.push thetaPair6099i18 <|
    PetersenLocalChildren.push thetaPair6099i19 <|
    PetersenLocalChildren.push thetaPair6099i20 <|
    PetersenLocalChildren.push thetaPair6099i21 <|
    PetersenLocalChildren.push thetaPair6099i22 <|
    PetersenLocalChildren.push thetaPair6099i23 <|
    PetersenLocalChildren.push thetaPair6099i24 <|
    PetersenLocalChildren.push thetaPair6099i25 <|
    PetersenLocalChildren.push thetaPair6099i26 <|
    PetersenLocalChildren.push thetaPair6099i27 <|
    PetersenLocalChildren.nil
theorem b7571 : Blocked tgt 9 s7571 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s6554) (by decide +kernel)
  exact b6554
theorem b7934 : Blocked tgt 9 s7934 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s6983) (by decide +kernel)
  exact b6983
theorem b8467 : Blocked tgt 9 s8467 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s3224) (by decide +kernel)
  exact b3224
theorem b9866 : Blocked tgt 9 s9866 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s4734) (by decide +kernel)
  exact b4734
theorem b10542 : Blocked tgt 9 s10542 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym1 Petersen191Symmetry.fix1 (rep:=s5832) (by decide +kernel)
  exact b5832
private theorem thetaPair10980i0 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10981,s10982,s1126,s10983,s10984,s10985]) (hints := [779,0,779,1,5296,5552,9679,2,779,5552,779,3,9679,4,9679,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s10981,s10982,s1126,s10983,s10984,s10985], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10981) (b10981) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10982) (b10982) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1126) (b1126) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10983) (b10983) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10984) (b10984) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10985) (b10985) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i1 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word31) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10986,s10987,s10988,s10999]) (hints := [5550,5550,6840,0,5292,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s10986,s10987,s10988,s10999], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10986) (b10986) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10987) (b10987) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10988) (b10988) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10999) (b10999) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i2 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10986,s1712,s2660,s3145]) (hints := [5550,5550,5934,0,9933,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s10986,s1712,s2660,s3145], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10986) (b10986) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1712) (b1712) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2660) (b2660) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3145) (b3145) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i3 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11000,s5045,s5398,s11001,s6404,s11002]) (hints := [6584,6584,7480,0,4528,5552,1,2,7480,5552,7480,3,6584,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11000,s5045,s5398,s11001,s6404,s11002], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11000) (b11000) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5045) (b5045) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5398) (b5398) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11001) (b11001) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6404) (b6404) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11002) (b11002) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i4 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11003,s7102,s11004,s11005]) (hints := [5550,5550,7470,0,4534,6582,11469,1,7470,6582,7470,2,5550,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11003,s7102,s11004,s11005], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11003) (b11003) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7102) (b7102) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11004) (b11004) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11005) (b11005) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i5 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11006,s8002,s11007,s11008]) (hints := [9678,9678,13646,0,1454,5550,13517,1,13646,5550,13646,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11006,s8002,s11007,s11008], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11006) (b11006) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8002) (b8002) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11007) (b11007) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11008) (b11008) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i6 : PetersenLocalChildren.PairOK tgt 8 s10980 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11009,s9898,s10124,s11010,s10834,s11011]) (hints := [5552,5552,13616,0,1488,9680,1,2,13616,9680,13616,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11009,s9898,s10124,s11010,s10834,s11011], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11009) (b11009) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9898) (b9898) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10124) (b10124) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11010) (b11010) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10834) (b10834) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11011) (b11011) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i7 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word31) := by
  refine PetersenLocalChildren.pair_close (bank := #[s10986,s11012,s11013,s11014]) (hints := [9677,9677,6840,0,6968,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s10986,s11012,s11013,s11014], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10986) (b10986) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11012) (b11012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11013) (b11013) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11014) (b11014) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i8 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11015,s11016,s11017,s11018]) (hints := [9677,9677,5676,0,5806,777,5934,1,777,777,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11015,s11016,s11017,s11018], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11015) (b11015) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11016) (b11016) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11017) (b11017) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11018) (b11018) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i9 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11019,s11020,s11021,s11022]) (hints := [8645,8645,1673,0,8653,9677,7478,1,9669,9677,1673,2,8645,8645,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11019,s11020,s11021,s11022], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11019) (b11019) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11020) (b11020) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11021) (b11021) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11022) (b11022) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i10 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11023,s11024,s11049,s11050,s11051,s11052]) (hints := [9679,9679,11471,0,7472,1,7472,2,11471,3,11471,4,9679,9679,7472,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11023,s11024,s11049,s11050,s11051,s11052], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11023) (b11023) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11024) (b11024) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11049) (b11049) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11050) (b11050) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11051) (b11051) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11052) (b11052) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i11 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11053,s11054,s11078,s11079,s11080,s11081]) (hints := [9679,9679,13519,0,13648,1,13648,2,13519,3,13519,4,9679,9679,13648,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11053,s11054,s11078,s11079,s11080,s11081], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11053) (b11053) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11054) (b11054) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11078) (b11078) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11079) (b11079) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11080) (b11080) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11081) (b11081) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i12 : PetersenLocalChildren.PairOK tgt 8 s10980 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11082,s11083,s11084,s11085]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11082,s11083,s11084,s11085], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11082) (b11082) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11083) (b11083) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11084) (b11084) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11085) (b11085) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i13 : PetersenLocalChildren.PairOK tgt 8 s10980 (word31,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11086,s11087,s11088,s11092,s11093,s11094]) (hints := [5678,0,5678,1,5936,6842,5936,2,5678,6842,5678,3,5936,4,5936,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11086,s11087,s11088,s11092,s11093,s11094], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11086) (b11086) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11087) (b11087) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11088) (b11088) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11092) (b11092) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11093) (b11093) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11094) (b11094) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i14 : PetersenLocalChildren.PairOK tgt 8 s10980 (word31,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11095,s11096,s11111,s11117,s11131,s11132]) (hints := [6842,6842,7738,0,7480,1,7480,2,7738,3,7738,4,7480,6842,7480,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11095,s11096,s11111,s11117,s11131,s11132], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11095) (b11095) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11096) (b11096) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11111) (b11111) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11117) (b11117) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11131) (b11131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11132) (b11132) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i15 : PetersenLocalChildren.PairOK tgt 8 s10980 (word31,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11133,s11134,s11135,s11136]) (hints := [4776,4776,7212,0,11469,6840,11469,1,6824,6840,7212,2,11469,4776,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11133,s11134,s11135,s11136], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11133) (b11133) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11134) (b11134) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11135) (b11135) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11136) (b11136) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i16 : PetersenLocalChildren.PairOK tgt 8 s10980 (word31,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11137,s11138,s11139,s11140]) (hints := [2712,2712,13388,0,13517,6840,13517,1,6808,6840,13388,2,13517,2712,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11137,s11138,s11139,s11140], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11137) (b11137) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11138) (b11138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11139) (b11139) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11140) (b11140) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i17 : PetersenLocalChildren.PairOK tgt 8 s10980 (word31,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11141,s11142,s11156,s11162,s11175,s11176]) (hints := [6842,6842,14906,0,13616,1,13616,2,14906,3,14906,4,13616,6842,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11141,s11142,s11156,s11162,s11175,s11176], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11141) (b11141) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11142) (b11142) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11156) (b11156) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11162) (b11162) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11175) (b11175) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11176) (b11176) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i18 : PetersenLocalChildren.PairOK tgt 8 s10980 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11177,s11178,s11181,s11182]) (hints := [6966,6966,7478,0,4910,5934,1673,1,7478,5934,7478,2,6966,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11177,s11178,s11181,s11182], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11177) (b11177) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11178) (b11178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11181) (b11181) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11182) (b11182) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i19 : PetersenLocalChildren.PairOK tgt 8 s10980 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11183,s11184,s11189,s11190]) (hints := [11469,5934,11469,0,4918,6966,2697,1,11469,6966,11469,2,5934,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11183,s11184,s11189,s11190], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11183) (b11183) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11184) (b11184) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11189) (b11189) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11190) (b11190) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i20 : PetersenLocalChildren.PairOK tgt 8 s10980 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11191,s11192,s11197,s11198]) (hints := [13517,10062,13517,0,1838,5934,4745,1,13517,5934,13517,2,10062,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11191,s11192,s11197,s11198], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11191) (b11191) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11192) (b11192) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11197) (b11197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11198) (b11198) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i21 : PetersenLocalChildren.PairOK tgt 8 s10980 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11199,s11200,s11203,s11204]) (hints := [5934,5934,13614,0,1870,10062,8841,1,13614,10062,13614,2,5934,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11199,s11200,s11203,s11204], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11199) (b11199) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11200) (b11200) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11203) (b11203) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11204) (b11204) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i22 : PetersenLocalChildren.PairOK tgt 8 s10980 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11205,s11206,s11207,s11208]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11205,s11206,s11207,s11208], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11205) (b11205) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11206) (b11206) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11207) (b11207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11208) (b11208) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i23 : PetersenLocalChildren.PairOK tgt 8 s10980 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11209,s11210,s11211,s11212]) (hints := [12485,11606,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,11606,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11209,s11210,s11211,s11212], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11209) (b11209) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11210) (b11210) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11211) (b11211) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11212) (b11212) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i24 : PetersenLocalChildren.PairOK tgt 8 s10980 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11213,s11214,s11215,s11216]) (hints := [7478,7478,14646,0,3414,11606,13614,1,14646,11606,14646,2,7478,7478,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11213,s11214,s11215,s11216], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11213) (b11213) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11214) (b11214) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11215) (b11215) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11216) (b11216) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i25 : PetersenLocalChildren.PairOK tgt 8 s10980 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11217,s11218,s11222,s11223]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11217,s11218,s11222,s11223], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11217) (b11217) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11218) (b11218) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11222) (b11222) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11223) (b11223) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i26 : PetersenLocalChildren.PairOK tgt 8 s10980 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11224,s11225,s11226,s11227]) (hints := [3213,3213,13614,0,3277,11469,14646,1,11405,11469,13614,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11224,s11225,s11226,s11227], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11224) (b11224) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11225) (b11225) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11226) (b11226) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11227) (b11227) <|
    PetersenLocalChildren.nil
private theorem thetaPair10980i27 : PetersenLocalChildren.PairOK tgt 8 s10980 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11228,s11229,s11230,s11231]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11228,s11229,s11230,s11231], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11228) (b11228) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11229) (b11229) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11230) (b11230) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11231) (b11231) <|
    PetersenLocalChildren.nil
theorem b10980 : Blocked tgt 9 s10980 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word1),(word7,word31),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word1,word31),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word31,word0),(word31,word6),(word31,word5),(word31,word2),(word31,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s10980 p
  exact
    PetersenLocalChildren.push thetaPair10980i0 <|
    PetersenLocalChildren.push thetaPair10980i1 <|
    PetersenLocalChildren.push thetaPair10980i2 <|
    PetersenLocalChildren.push thetaPair10980i3 <|
    PetersenLocalChildren.push thetaPair10980i4 <|
    PetersenLocalChildren.push thetaPair10980i5 <|
    PetersenLocalChildren.push thetaPair10980i6 <|
    PetersenLocalChildren.push thetaPair10980i7 <|
    PetersenLocalChildren.push thetaPair10980i8 <|
    PetersenLocalChildren.push thetaPair10980i9 <|
    PetersenLocalChildren.push thetaPair10980i10 <|
    PetersenLocalChildren.push thetaPair10980i11 <|
    PetersenLocalChildren.push thetaPair10980i12 <|
    PetersenLocalChildren.push thetaPair10980i13 <|
    PetersenLocalChildren.push thetaPair10980i14 <|
    PetersenLocalChildren.push thetaPair10980i15 <|
    PetersenLocalChildren.push thetaPair10980i16 <|
    PetersenLocalChildren.push thetaPair10980i17 <|
    PetersenLocalChildren.push thetaPair10980i18 <|
    PetersenLocalChildren.push thetaPair10980i19 <|
    PetersenLocalChildren.push thetaPair10980i20 <|
    PetersenLocalChildren.push thetaPair10980i21 <|
    PetersenLocalChildren.push thetaPair10980i22 <|
    PetersenLocalChildren.push thetaPair10980i23 <|
    PetersenLocalChildren.push thetaPair10980i24 <|
    PetersenLocalChildren.push thetaPair10980i25 <|
    PetersenLocalChildren.push thetaPair10980i26 <|
    PetersenLocalChildren.push thetaPair10980i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i0 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word33) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11312,s11313,s11314,s11315,s11316,s11317,s11318,s197,s11319]) (hints := [5555,5555,6845,0,1,2,3,4,6845,5,6845,6,5555,5555,7,8]) (by decide +kernel) ?_
  change ∀ x ∈ [s11312,s11313,s11314,s11315,s11316,s11317,s11318,s197,s11319], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11312) (b11312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11313) (b11313) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11314) (b11314) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11315) (b11315) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11316) (b11316) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11317) (b11317) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11318) (b11318) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s197) (b197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11319) (b11319) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i1 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11312,s11317,s11318,s1127,s1128,s11320,s11321,s11322]) (hints := [6972,1,6972,2,5554,5554,3,4,6972,5554,6972,0,5552,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s11312,s11317,s11318,s1127,s1128,s11320,s11321,s11322], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11312) (b11312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11317) (b11317) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11318) (b11318) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1127) (b1127) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1128) (b1128) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11320) (b11320) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11321) (b11321) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11322) (b11322) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i2 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11323,s1714,s2685,s3151]) (hints := [9933,5550,5934,0,9933,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11323,s1714,s2685,s3151], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11323) (b11323) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1714) (b1714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2685) (b2685) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3151) (b3151) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i3 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11324,s5068,s5401,s11325,s6426,s11326]) (hints := [1675,6584,1675,0,4528,5552,1,2,1675,5552,1675,3,6584,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11324,s5068,s5401,s11325,s6426,s11326], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11324) (b11324) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5068) (b5068) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5401) (b5401) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11325) (b11325) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6426) (b6426) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11326) (b11326) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i4 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11327,s7103,s11328,s11329]) (hints := [2697,5550,2697,0,11469,6582,11469,1,2697,6582,2697,2,11469,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11327,s7103,s11328,s11329], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11327) (b11327) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7103) (b7103) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11328) (b11328) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11329) (b11329) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i5 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11330,s8003,s11331,s11332]) (hints := [4745,9678,4745,0,13517,5550,13517,1,4745,5550,4745,2,13517,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11330,s8003,s11331,s11332], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11330) (b11330) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8003) (b8003) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11331) (b11331) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11332) (b11332) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i6 : PetersenLocalChildren.PairOK tgt 8 s11311 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11333,s9919,s10127,s11334,s10854,s11335]) (hints := [8843,5552,8843,0,1488,9680,1,2,8843,9680,8843,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11333,s9919,s10127,s11334,s10854,s11335], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11333) (b11333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9919) (b9919) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10127) (b10127) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11334) (b11334) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10854) (b10854) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11335) (b11335) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i7 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11323,s1131,s11012,s11014]) (hints := [9677,6840,6968,0,9677,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11323,s1131,s11012,s11014], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11323) (b11323) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1131) (b1131) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11012) (b11012) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11014) (b11014) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i8 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11312,s197,s11319,s11336,s11337,s11338,s11339,s11340]) (hints := [5938,1,5938,2,6844,6844,3,4,5938,6844,5938,0,5808,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s11312,s197,s11319,s11336,s11337,s11338,s11339,s11340], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11312) (b11312) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s197) (b197) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11319) (b11319) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11336) (b11336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11337) (b11337) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11338) (b11338) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11339) (b11339) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11340) (b11340) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i9 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11341,s11342,s11368,s11369,s11370,s11371]) (hints := [7480,6842,7480,0,1547,1,1675,2,7480,3,7480,4,6842,6842,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11341,s11342,s11368,s11369,s11370,s11371], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11341) (b11341) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11342) (b11342) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11368) (b11368) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11369) (b11369) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11370) (b11370) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11371) (b11371) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i10 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11372,s11373,s11374,s11375]) (hints := [7470,4776,7470,0,11469,6840,11469,1,7470,6840,7470,2,11469,4776,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11372,s11373,s11374,s11375], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11372) (b11372) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11373) (b11373) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11374) (b11374) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11375) (b11375) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i11 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11376,s11377,s11378,s11379]) (hints := [13646,2712,13646,0,13517,6840,13517,1,13646,6840,13646,2,13517,2712,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11376,s11377,s11378,s11379], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11376) (b11376) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11377) (b11377) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11378) (b11378) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11379) (b11379) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i12 : PetersenLocalChildren.PairOK tgt 8 s11311 (word33,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11380,s11381,s11406,s11407,s11408,s11409]) (hints := [13616,6842,13616,0,8715,1,8843,2,13616,3,13616,4,6842,6842,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11380,s11381,s11406,s11407,s11408,s11409], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11380) (b11380) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11381) (b11381) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11406) (b11406) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11407) (b11407) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11408) (b11408) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11409) (b11409) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i13 : PetersenLocalChildren.PairOK tgt 8 s11311 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11410,s11411,s11412,s11413,s11414,s11415]) (hints := [5678,0,5678,1,5680,6970,5936,2,5678,6970,5678,3,5934,4,5936,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11410,s11411,s11412,s11413,s11414,s11415], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11410) (b11410) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11411) (b11411) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11412) (b11412) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11413) (b11413) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11414) (b11414) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11415) (b11415) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i14 : PetersenLocalChildren.PairOK tgt 8 s11311 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11416,s11417,s11441,s11442,s11443,s11444]) (hints := [1675,6970,1675,0,7224,1,7480,2,1675,3,1675,4,6970,6970,7480,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11416,s11417,s11441,s11442,s11443,s11444], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11416) (b11416) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11417) (b11417) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11441) (b11441) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11442) (b11442) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11443) (b11443) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11444) (b11444) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i15 : PetersenLocalChildren.PairOK tgt 8 s11311 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11445,s11446,s11447,s11448]) (hints := [11469,4904,11469,0,4920,6968,7470,1,11469,6968,11469,2,4904,4904,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11445,s11446,s11447,s11448], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11445) (b11445) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11446) (b11446) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11447) (b11447) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11448) (b11448) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i16 : PetersenLocalChildren.PairOK tgt 8 s11311 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11449,s11450,s11451,s11452]) (hints := [13517,2840,13517,0,2872,6968,13646,1,13517,6968,13517,2,2840,2840,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11449,s11450,s11451,s11452], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11449) (b11449) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11450) (b11450) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11451) (b11451) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11452) (b11452) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i17 : PetersenLocalChildren.PairOK tgt 8 s11311 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11453,s11454,s11476,s11477,s11478,s11479]) (hints := [8843,6970,8843,0,13360,1,13616,2,8843,3,8843,4,6970,6970,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s11453,s11454,s11476,s11477,s11478,s11479], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11453) (b11453) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11454) (b11454) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11476) (b11476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11477) (b11477) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11478) (b11478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11479) (b11479) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i18 : PetersenLocalChildren.PairOK tgt 8 s11311 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11480,s11481,s11482,s11483]) (hints := [6966,6966,7478,0,1673,5934,1673,1,7478,5934,7478,2,1673,6966,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11480,s11481,s11482,s11483], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11480) (b11480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11481) (b11481) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11482) (b11482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11483) (b11483) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i19 : PetersenLocalChildren.PairOK tgt 8 s11311 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11484,s11485,s11486,s11487]) (hints := [11469,5934,11469,0,2697,6966,2697,1,11469,6966,11469,2,2697,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11484,s11485,s11486,s11487], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11484) (b11484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11485) (b11485) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11486) (b11486) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11487) (b11487) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i20 : PetersenLocalChildren.PairOK tgt 8 s11311 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11488,s11489,s11490,s11491]) (hints := [13517,10062,13517,0,4745,5934,4745,1,13517,5934,13517,2,4745,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11488,s11489,s11490,s11491], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11488) (b11488) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11489) (b11489) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11490) (b11490) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11491) (b11491) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i21 : PetersenLocalChildren.PairOK tgt 8 s11311 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11492,s11493,s11494,s11495]) (hints := [5934,5934,13614,0,8841,10062,8841,1,13614,10062,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11492,s11493,s11494,s11495], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11492) (b11492) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11493) (b11493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11494) (b11494) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11495) (b11495) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i22 : PetersenLocalChildren.PairOK tgt 8 s11311 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11496,s11497,s11498,s11499]) (hints := [10437,1673,10437,0,10445,7478,11469,1,10437,7478,10437,2,11461,1673,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11496,s11497,s11498,s11499], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11496) (b11496) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11497) (b11497) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11498) (b11498) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11499) (b11499) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i23 : PetersenLocalChildren.PairOK tgt 8 s11311 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11500,s11501,s11502,s11503]) (hints := [12485,1673,12485,0,12493,7478,13517,1,12485,7478,12485,2,13509,1673,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11500,s11501,s11502,s11503], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11500) (b11500) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11501) (b11501) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11502) (b11502) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11503) (b11503) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i24 : PetersenLocalChildren.PairOK tgt 8 s11311 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11504,s11505,s11509,s11510]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11504,s11505,s11509,s11510], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11504) (b11504) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11505) (b11505) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11509) (b11509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11510) (b11510) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i25 : PetersenLocalChildren.PairOK tgt 8 s11311 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11511,s11512,s11513,s11514]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11511,s11512,s11513,s11514], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11511) (b11511) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11512) (b11512) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11513) (b11513) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11514) (b11514) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i26 : PetersenLocalChildren.PairOK tgt 8 s11311 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11515,s11516,s11517,s11518]) (hints := [3213,3213,8841,0,3277,11469,14646,1,11405,11469,8841,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11515,s11516,s11517,s11518], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11515) (b11515) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11516) (b11516) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11517) (b11517) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11518) (b11518) <|
    PetersenLocalChildren.nil
private theorem thetaPair11311i27 : PetersenLocalChildren.PairOK tgt 8 s11311 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11519,s11520,s11521,s11522]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11519,s11520,s11521,s11522], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11519) (b11519) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11520) (b11520) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11521) (b11521) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11522) (b11522) <|
    PetersenLocalChildren.nil
theorem b11311 : Blocked tgt 9 s11311 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word33),(word7,word1),(word7,word0),(word7,word6),(word7,word5),(word7,word2),(word7,word4),(word33,word1),(word33,word0),(word33,word6),(word33,word5),(word33,word2),(word33,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s11311 p
  exact
    PetersenLocalChildren.push thetaPair11311i0 <|
    PetersenLocalChildren.push thetaPair11311i1 <|
    PetersenLocalChildren.push thetaPair11311i2 <|
    PetersenLocalChildren.push thetaPair11311i3 <|
    PetersenLocalChildren.push thetaPair11311i4 <|
    PetersenLocalChildren.push thetaPair11311i5 <|
    PetersenLocalChildren.push thetaPair11311i6 <|
    PetersenLocalChildren.push thetaPair11311i7 <|
    PetersenLocalChildren.push thetaPair11311i8 <|
    PetersenLocalChildren.push thetaPair11311i9 <|
    PetersenLocalChildren.push thetaPair11311i10 <|
    PetersenLocalChildren.push thetaPair11311i11 <|
    PetersenLocalChildren.push thetaPair11311i12 <|
    PetersenLocalChildren.push thetaPair11311i13 <|
    PetersenLocalChildren.push thetaPair11311i14 <|
    PetersenLocalChildren.push thetaPair11311i15 <|
    PetersenLocalChildren.push thetaPair11311i16 <|
    PetersenLocalChildren.push thetaPair11311i17 <|
    PetersenLocalChildren.push thetaPair11311i18 <|
    PetersenLocalChildren.push thetaPair11311i19 <|
    PetersenLocalChildren.push thetaPair11311i20 <|
    PetersenLocalChildren.push thetaPair11311i21 <|
    PetersenLocalChildren.push thetaPair11311i22 <|
    PetersenLocalChildren.push thetaPair11311i23 <|
    PetersenLocalChildren.push thetaPair11311i24 <|
    PetersenLocalChildren.push thetaPair11311i25 <|
    PetersenLocalChildren.push thetaPair11311i26 <|
    PetersenLocalChildren.push thetaPair11311i27 <|
    PetersenLocalChildren.nil
theorem b11803 : Blocked tgt 9 s11803 := by
  apply PetersenSymmetry.via Petersen191Symmetry.sym2 Petersen191Symmetry.fix2 (rep:=s11525) (by decide +kernel)
  exact b11525
private theorem thetaPair12295i0 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12296,s1138,s12297,s12298]) (hints := [905,5292,905,0,5294,5550,9677,1,905,5550,905,2,5292,5292,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12296,s1138,s12297,s12298], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12296) (b12296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1138) (b1138) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12297) (b12297) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12298) (b12298) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i1 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12299,s1723,s2716,s3154]) (hints := [5550,5550,5934,0,9805,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12299,s1723,s2716,s3154], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12299) (b12299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1723) (b1723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2716) (b2716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3154) (b3154) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i2 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12300,s12301,s5094,s5405,s12302,s5840,s12303,s6433,s12304]) (hints := [4531,0,1550,1,4531,5555,2,3,5555,5555,1550,4,5,6,7,8]) (by decide +kernel) ?_
  change ∀ x ∈ [s12300,s12301,s5094,s5405,s12302,s5840,s12303,s6433,s12304], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12300) (b12300) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12301) (b12301) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5094) (b5094) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5405) (b5405) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12302) (b12302) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5840) (b5840) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12303) (b12303) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6433) (b6433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12304) (b12304) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i3 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12299,s12305,s12306,s12325]) (hints := [5550,5550,6840,0,6582,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12299,s12305,s12306,s12325], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12299) (b12299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12305) (b12305) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12306) (b12306) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12325) (b12325) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i4 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12326,s6584,s7106,s7483,s12327,s12328]) (hints := [5552,5552,7472,0,11343,1,11471,2,7472,3,7472,4,5552,5552,11471,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12326,s6584,s7106,s7483,s12327,s12328], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12326) (b12326) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6584) (b6584) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7106) (b7106) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7483) (b7483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12327) (b12327) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12328) (b12328) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i5 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12329,s8006,s12330,s12331]) (hints := [9678,9678,13646,0,1454,5550,13517,1,13646,5550,13646,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12329,s8006,s12330,s12331], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12329) (b12329) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8006) (b8006) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12330) (b12330) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12331) (b12331) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i6 : PetersenLocalChildren.PairOK tgt 8 s12295 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12332,s9944,s10130,s12333,s10867,s12334]) (hints := [5552,5552,13616,0,1488,9680,1,2,13616,9680,13616,3,5552,5552,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12332,s9944,s10130,s12333,s10867,s12334], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12332) (b12332) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9944) (b9944) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10130) (b10130) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12333) (b12333) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10867) (b10867) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12334) (b12334) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i7 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12335,s12336,s12343,s12344]) (hints := [9677,9677,5676,0,5678,905,5934,1,5676,905,5676,2,9677,9677,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12335,s12336,s12343,s12344], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12335) (b12335) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12336) (b12336) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12343) (b12343) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12344) (b12344) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i8 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12345,s12346,s12396,s12397,s12398,s12399]) (hints := [8647,8647,1547,0,8655,9679,1,2,9671,9679,1547,3,8647,8647,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12345,s12346,s12396,s12397,s12398,s12399], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12345) (b12345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12346) (b12346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12396) (b12396) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12397) (b12397) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12398) (b12398) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12399) (b12399) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i9 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12400,s11096,s12401,s12402,s12403,s12418]) (hints := [6842,6970,6842,0,9679,9679,1,2,9679,9679,6842,3,6970,6970,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12400,s11096,s12401,s12402,s12403,s12418], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12400) (b12400) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11096) (b11096) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12401) (b12401) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12402) (b12402) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12403) (b12403) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12418) (b12418) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i10 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12419,s12420,s12421,s12422]) (hints := [9677,9677,11469,0,4920,6968,7470,1,11469,6968,11469,2,9677,9677,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12419,s12420,s12421,s12422], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12419) (b12419) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12420) (b12420) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12421) (b12421) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12422) (b12422) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i11 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12423,s12424,s12428,s12429]) (hints := [9677,9677,13517,0,2872,6968,13646,1,13517,6968,13517,2,9677,9677,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12423,s12424,s12428,s12429], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12423) (b12423) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12424) (b12424) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12428) (b12428) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12429) (b12429) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i12 : PetersenLocalChildren.PairOK tgt 8 s12295 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12430,s12431,s12433,s12434]) (hints := [1421,1421,8841,0,1485,9677,13614,1,9613,9677,8841,2,1421,1421,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12430,s12431,s12433,s12434], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12430) (b12430) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12431) (b12431) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12433) (b12433) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12434) (b12434) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i13 : PetersenLocalChildren.PairOK tgt 8 s12295 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12435,s12436,s12437,s12438,s12471,s12472]) (hints := [5040,6968,0,1,5040,5936,1547,2,5936,5936,3,4,6968,6968,1547,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12435,s12436,s12437,s12438,s12471,s12472], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12435) (b12435) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12436) (b12436) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12437) (b12437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12438) (b12438) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12471) (b12471) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12472) (b12472) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i14 : PetersenLocalChildren.PairOK tgt 8 s12295 (word0,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12473,s12474,s12475,s11705,s12476,s12477]) (hints := [6968,6968,0,1,5936,5936,6842,2,5936,5936,3,4,6968,6968,6842,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12473,s12474,s12475,s11705,s12476,s12477], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12473) (b12473) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12474) (b12474) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12475) (b12475) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11705) (b11705) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12476) (b12476) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12477) (b12477) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i15 : PetersenLocalChildren.PairOK tgt 8 s12295 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12478,s12479,s12480,s12481]) (hints := [11469,5934,11469,0,4918,6966,2697,1,11469,6966,11469,2,5934,5934,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12478,s12479,s12480,s12481], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12478) (b12478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12479) (b12479) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12480) (b12480) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12481) (b12481) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i16 : PetersenLocalChildren.PairOK tgt 8 s12295 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12482,s12483,s12491,s12492]) (hints := [13517,10062,13517,0,1838,5934,4745,1,13517,5934,13517,2,10062,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12482,s12483,s12491,s12492], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12482) (b12482) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12483) (b12483) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12491) (b12491) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12492) (b12492) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i17 : PetersenLocalChildren.PairOK tgt 8 s12295 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12493,s12494,s12501,s12502]) (hints := [5934,5934,13614,0,1870,10062,8841,1,13614,10062,13614,2,5934,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12493,s12494,s12501,s12502], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12493) (b12493) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12494) (b12494) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12501) (b12501) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12502) (b12502) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i18 : PetersenLocalChildren.PairOK tgt 8 s12295 (word6,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12299,s12503,s12504,s12505]) (hints := [7478,1545,6840,0,7478,1,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12299,s12503,s12504,s12505], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12299) (b12299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12503) (b12503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12504) (b12504) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12505) (b12505) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i19 : PetersenLocalChildren.PairOK tgt 8 s12295 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12506,s12507,s12508,s12509,s12510,s12511]) (hints := [10439,1547,10439,0,10447,1,11471,2,10439,3,10439,4,11463,1547,11471,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12506,s12507,s12508,s12509,s12510,s12511], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12506) (b12506) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12507) (b12507) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12508) (b12508) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12509) (b12509) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12510) (b12510) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12511) (b12511) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i20 : PetersenLocalChildren.PairOK tgt 8 s12295 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12512,s12513,s12552,s12553,s12554,s12555]) (hints := [12487,1547,12487,0,12495,1,13519,2,12487,3,12487,4,13511,1547,13519,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12512,s12513,s12552,s12553,s12554,s12555], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12512) (b12512) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12513) (b12513) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12552) (b12552) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12553) (b12553) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12554) (b12554) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12555) (b12555) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i21 : PetersenLocalChildren.PairOK tgt 8 s12295 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12556,s12557,s12603,s12604,s12605,s12606]) (hints := [14648,1547,14648,0,13616,1,13616,2,14648,3,14648,4,13616,1547,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12556,s12557,s12603,s12604,s12605,s12606], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12556) (b12556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12557) (b12557) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12603) (b12603) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12604) (b12604) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12605) (b12605) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12606) (b12606) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i22 : PetersenLocalChildren.PairOK tgt 8 s12295 (word10,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12607,s12608,s12609,s12610,s12635,s12636]) (hints := [4778,4778,0,1,11471,6842,11471,2,6826,6842,3,4,11471,4778,11471,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12607,s12608,s12609,s12610,s12635,s12636], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12607) (b12607) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12608) (b12608) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12609) (b12609) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12610) (b12610) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12635) (b12635) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12636) (b12636) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i23 : PetersenLocalChildren.PairOK tgt 8 s12295 (word10,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12637,s12638,s12639,s12640]) (hints := [14678,2712,14678,0,13517,6840,13517,1,14678,6840,14678,2,13517,2712,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12637,s12638,s12639,s12640], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12637) (b12637) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12638) (b12638) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12639) (b12639) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12640) (b12640) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i24 : PetersenLocalChildren.PairOK tgt 8 s12295 (word10,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12641,s12642,s12661,s12662,s12674,s12675]) (hints := [14648,6842,14648,0,13616,1,13616,2,14648,3,14648,4,13616,6842,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12641,s12642,s12661,s12662,s12674,s12675], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12641) (b12641) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12642) (b12642) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12661) (b12661) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12662) (b12662) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12674) (b12674) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12675) (b12675) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i25 : PetersenLocalChildren.PairOK tgt 8 s12295 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12676,s12677,s12678,s12679]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12676,s12677,s12678,s12679], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12676) (b12676) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12677) (b12677) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12678) (b12678) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12679) (b12679) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i26 : PetersenLocalChildren.PairOK tgt 8 s12295 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12680,s12681,s12682,s12683]) (hints := [3213,3213,13614,0,3277,11469,14646,1,11405,11469,13614,2,3213,3213,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12680,s12681,s12682,s12683], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12680) (b12680) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12681) (b12681) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12682) (b12682) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12683) (b12683) <|
    PetersenLocalChildren.nil
private theorem thetaPair12295i27 : PetersenLocalChildren.PairOK tgt 8 s12295 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12684,s12685,s12686,s12687]) (hints := [5261,5261,8841,0,5325,13517,13614,1,13453,13517,8841,2,5261,5261,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12684,s12685,s12686,s12687], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12684) (b12684) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12685) (b12685) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12686) (b12686) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12687) (b12687) <|
    PetersenLocalChildren.nil
theorem b12295 : Blocked tgt 9 s12295 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word1),(word7,word0),(word7,word6),(word7,word10),(word7,word5),(word7,word2),(word7,word4),(word1,word0),(word1,word6),(word1,word10),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word10),(word0,word5),(word0,word2),(word0,word4),(word6,word10),(word6,word5),(word6,word2),(word6,word4),(word10,word5),(word10,word2),(word10,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s12295 p
  exact
    PetersenLocalChildren.push thetaPair12295i0 <|
    PetersenLocalChildren.push thetaPair12295i1 <|
    PetersenLocalChildren.push thetaPair12295i2 <|
    PetersenLocalChildren.push thetaPair12295i3 <|
    PetersenLocalChildren.push thetaPair12295i4 <|
    PetersenLocalChildren.push thetaPair12295i5 <|
    PetersenLocalChildren.push thetaPair12295i6 <|
    PetersenLocalChildren.push thetaPair12295i7 <|
    PetersenLocalChildren.push thetaPair12295i8 <|
    PetersenLocalChildren.push thetaPair12295i9 <|
    PetersenLocalChildren.push thetaPair12295i10 <|
    PetersenLocalChildren.push thetaPair12295i11 <|
    PetersenLocalChildren.push thetaPair12295i12 <|
    PetersenLocalChildren.push thetaPair12295i13 <|
    PetersenLocalChildren.push thetaPair12295i14 <|
    PetersenLocalChildren.push thetaPair12295i15 <|
    PetersenLocalChildren.push thetaPair12295i16 <|
    PetersenLocalChildren.push thetaPair12295i17 <|
    PetersenLocalChildren.push thetaPair12295i18 <|
    PetersenLocalChildren.push thetaPair12295i19 <|
    PetersenLocalChildren.push thetaPair12295i20 <|
    PetersenLocalChildren.push thetaPair12295i21 <|
    PetersenLocalChildren.push thetaPair12295i22 <|
    PetersenLocalChildren.push thetaPair12295i23 <|
    PetersenLocalChildren.push thetaPair12295i24 <|
    PetersenLocalChildren.push thetaPair12295i25 <|
    PetersenLocalChildren.push thetaPair12295i26 <|
    PetersenLocalChildren.push thetaPair12295i27 <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i0 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12689,s12299,s61,s12690]) (hints := [5550,0,1,5550,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12689,s12299,s61,s12690], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12689) (b12689) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12299) (b12299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s61) (b61) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12690) (b12690) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i1 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12691,s419,s1562,s12692]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12691,s419,s1562,s12692], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12691) (b12691) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s419) (b419) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1562) (b1562) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12692) (b12692) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i2 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12689,s1766,s2748]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s12689,s1766,s2748], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12689) (b12689) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1766) (b1766) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2748) (b2748) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i3 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12693,s3311,s4229,s5121,s5753,s5841,s12694,s6434]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12693,s3311,s4229,s5121,s5753,s5841,s12694,s6434], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12693) (b12693) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3311) (b3311) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4229) (b4229) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5121) (b5121) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5753) (b5753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5841) (b5841) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12694) (b12694) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6434) (b6434) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i4 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12689,s5,s927,s12695,s12696,s12697]) (hints := [1,0,2,3,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12689,s5,s927,s12695,s12696,s12697], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12689) (b12689) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5) (b5) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12695) (b12695) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12696) (b12696) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12697) (b12697) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i5 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12698,s6585,s7484,s12699]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12698,s6585,s7484,s12699], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12698) (b12698) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6585) (b6585) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7484) (b7484) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12699) (b12699) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i6 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12700,s7600,s8379,s12701]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12700,s7600,s8379,s12701], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12700) (b12700) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7600) (b7600) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8379) (b8379) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12701) (b12701) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i7 : PetersenLocalChildren.PairOK tgt 8 s12688 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12702,s8554,s9440,s9977,s10463,s10556,s12703,s10896]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12702,s8554,s9440,s9977,s10463,s10556,s12703,s10896], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12702) (b12702) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8554) (b8554) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9440) (b9440) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9977) (b9977) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10463) (b10463) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10556) (b10556) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12703) (b12703) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10896) (b10896) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i8 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12704,s11255,s12705,s12706]) (hints := [6968,0,6968,9677,1,9677,6968,2,6968,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12704,s11255,s12705,s12706], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12704) (b12704) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11255) (b11255) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12705) (b12705) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12706) (b12706) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i9 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12690,s2748,s2716,s3154,s12259,s12006]) (hints := [5936,0,5936,2,3,1,6064,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s12690,s2748,s2716,s3154,s12259,s12006], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12690) (b12690) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2748) (b2748) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2716) (b2716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3154) (b3154) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12259) (b12259) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12006) (b12006) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i10 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12707,s12708,s12503,s12505,s12709,s12710]) (hints := [1547,0,1,2,3,4,1675,5,1675]) (by decide +kernel) ?_
  change ∀ x ∈ [s12707,s12708,s12503,s12505,s12709,s12710], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12707) (b12707) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12708) (b12708) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12503) (b12503) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12505) (b12505) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12709) (b12709) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12710) (b12710) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i11 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12299,s927,s12710,s5414]) (hints := [6840,0,1,6840,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12299,s927,s12710,s5414], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12299) (b12299) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12710) (b12710) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5414) (b5414) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i12 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12711,s12712,s12713,s12714]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12711,s12712,s12713,s12714], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12711) (b12711) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12712) (b12712) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12713) (b12713) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12714) (b12714) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i13 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12715,s12716,s12720,s12721]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12715,s12716,s12720,s12721], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12715) (b12715) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12716) (b12716) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12720) (b12720) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12721) (b12721) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i14 : PetersenLocalChildren.PairOK tgt 8 s12688 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12722,s12723,s12737,s12738]) (hints := [13614,0,13614,8841,1,8841,13614,2,13614,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s12722,s12723,s12737,s12738], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12722) (b12722) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12723) (b12723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12737) (b12737) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12738) (b12738) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i15 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i16 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12739,s12752]) (hints := [8643,8643,1671,8651,9675,0,9667,9675,1671,8643,8643,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s12739,s12752], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12739) (b12739) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12752) (b12752) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i17 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12753,s11288,s12754,s12755]) (hints := [6968,6968,0,9677,9677,1,9677,9677,2,6968,6968,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12753,s11288,s12754,s12755], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12753) (b12753) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11288) (b11288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12754) (b12754) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12755) (b12755) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i18 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i19 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i20 : PetersenLocalChildren.PairOK tgt 8 s12688 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i21 : PetersenLocalChildren.PairOK tgt 8 s12688 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12756,s12757]) (hints := [6964,6964,0,1671,5932,1671,5932,5932,1,1671,6964,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12756,s12757], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12756) (b12756) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12757) (b12757) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i22 : PetersenLocalChildren.PairOK tgt 8 s12688 (word0,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12758,s3207,s12145,s5443]) (hints := [6966,6966,0,5934,5934,1,5934,5934,2,6966,6966,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12758,s3207,s12145,s5443], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12758) (b12758) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3207) (b3207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12145) (b12145) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5443) (b5443) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i23 : PetersenLocalChildren.PairOK tgt 8 s12688 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,5930,11465,2693,6962,2693,11465,6962,11465,2693,5930,2693]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i24 : PetersenLocalChildren.PairOK tgt 8 s12688 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i25 : PetersenLocalChildren.PairOK tgt 8 s12688 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i26 : PetersenLocalChildren.PairOK tgt 8 s12688 (word6,word10) := by
  refine PetersenLocalChildren.pair_close (bank := #[s927,s12709,s12759]) (hints := [1672,1672,0,7477,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s927,s12709,s12759], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12709) (b12709) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12759) (b12759) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i27 : PetersenLocalChildren.PairOK tgt 8 s12688 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12760,s12761]) (hints := [10435,1671,10435,10443,0,11467,10435,1,10435,11459,1671,11467]) (by decide +kernel) ?_
  change ∀ x ∈ [s12760,s12761], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12760) (b12760) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12761) (b12761) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i28 : PetersenLocalChildren.PairOK tgt 8 s12688 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12762,s12763]) (hints := [12483,1671,12483,12491,0,13515,12483,1,12483,13507,1671,13515]) (by decide +kernel) ?_
  change ∀ x ∈ [s12762,s12763], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12762) (b12762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12763) (b12763) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i29 : PetersenLocalChildren.PairOK tgt 8 s12688 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12764,s12776]) (hints := [1671,1671,8839,13612,0,13612,8839,1,8839,1671,1671,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s12764,s12776], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12764) (b12764) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12776) (b12776) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i30 : PetersenLocalChildren.PairOK tgt 8 s12688 (word10,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12777,s12778,s12779,s12780,s12781,s12782,s12783,s12784]) (hints := [0,1,2,11473,3,11473,4,5,6,11473,7,11473]) (by decide +kernel) ?_
  change ∀ x ∈ [s12777,s12778,s12779,s12780,s12781,s12782,s12783,s12784], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12777) (b12777) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12778) (b12778) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12779) (b12779) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12780) (b12780) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12781) (b12781) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12782) (b12782) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12783) (b12783) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12784) (b12784) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i31 : PetersenLocalChildren.PairOK tgt 8 s12688 (word10,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12785,s12786,s12787,s12788]) (hints := [14678,0,14678,13517,1,13517,14678,2,14678,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12785,s12786,s12787,s12788], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12785) (b12785) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12786) (b12786) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12787) (b12787) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12788) (b12788) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i32 : PetersenLocalChildren.PairOK tgt 8 s12688 (word10,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12789,s12790,s12796,s12797]) (hints := [14646,0,14646,8841,1,8841,14646,2,14646,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s12789,s12790,s12796,s12797], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12789) (b12789) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12790) (b12790) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12796) (b12796) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12797) (b12797) <|
    PetersenLocalChildren.nil
private theorem thetaPair12688i33 : PetersenLocalChildren.PairOK tgt 8 s12688 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i34 : PetersenLocalChildren.PairOK tgt 8 s12688 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12688i35 : PetersenLocalChildren.PairOK tgt 8 s12688 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b12688 : Blocked tgt 9 s12688 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word10),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word10),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word10),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word10),(word0,word5),(word0,word2),(word0,word4),(word6,word10),(word6,word5),(word6,word2),(word6,word4),(word10,word5),(word10,word2),(word10,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s12688 p
  exact
    PetersenLocalChildren.push thetaPair12688i0 <|
    PetersenLocalChildren.push thetaPair12688i1 <|
    PetersenLocalChildren.push thetaPair12688i2 <|
    PetersenLocalChildren.push thetaPair12688i3 <|
    PetersenLocalChildren.push thetaPair12688i4 <|
    PetersenLocalChildren.push thetaPair12688i5 <|
    PetersenLocalChildren.push thetaPair12688i6 <|
    PetersenLocalChildren.push thetaPair12688i7 <|
    PetersenLocalChildren.push thetaPair12688i8 <|
    PetersenLocalChildren.push thetaPair12688i9 <|
    PetersenLocalChildren.push thetaPair12688i10 <|
    PetersenLocalChildren.push thetaPair12688i11 <|
    PetersenLocalChildren.push thetaPair12688i12 <|
    PetersenLocalChildren.push thetaPair12688i13 <|
    PetersenLocalChildren.push thetaPair12688i14 <|
    PetersenLocalChildren.push thetaPair12688i15 <|
    PetersenLocalChildren.push thetaPair12688i16 <|
    PetersenLocalChildren.push thetaPair12688i17 <|
    PetersenLocalChildren.push thetaPair12688i18 <|
    PetersenLocalChildren.push thetaPair12688i19 <|
    PetersenLocalChildren.push thetaPair12688i20 <|
    PetersenLocalChildren.push thetaPair12688i21 <|
    PetersenLocalChildren.push thetaPair12688i22 <|
    PetersenLocalChildren.push thetaPair12688i23 <|
    PetersenLocalChildren.push thetaPair12688i24 <|
    PetersenLocalChildren.push thetaPair12688i25 <|
    PetersenLocalChildren.push thetaPair12688i26 <|
    PetersenLocalChildren.push thetaPair12688i27 <|
    PetersenLocalChildren.push thetaPair12688i28 <|
    PetersenLocalChildren.push thetaPair12688i29 <|
    PetersenLocalChildren.push thetaPair12688i30 <|
    PetersenLocalChildren.push thetaPair12688i31 <|
    PetersenLocalChildren.push thetaPair12688i32 <|
    PetersenLocalChildren.push thetaPair12688i33 <|
    PetersenLocalChildren.push thetaPair12688i34 <|
    PetersenLocalChildren.push thetaPair12688i35 <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i0 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14287,s97,s293]) (hints := [5549,0,6839,5549,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14287,s97,s293], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14287) (b14287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s97) (b97) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s293) (b293) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i1 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14288,s855,s1662,s14289]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s14288,s855,s1662,s14289], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14288) (b14288) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s855) (b855) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s1662) (b1662) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14289) (b14289) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i2 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14287,s2082,s3191]) (hints := [9932,0,5933,9932,1,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14287,s2082,s3191], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14287) (b14287) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2082) (b2082) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3191) (b3191) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i3 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14290,s4400,s4432,s5439,s5792,s14291,s14292,s14293]) (hints := [1677,0,1677,1,2,3,1677,4,1677,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14290,s4400,s4432,s5439,s5792,s14291,s14292,s14293], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14290) (b14290) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4400) (b4400) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4432) (b4432) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5439) (b5439) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5792) (b5792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14291) (b14291) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14292) (b14292) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14293) (b14293) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i4 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word45) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14290,s5792,s14294,s14295,s2241,s14296,s3207,s4478,s5444,s14297,s14298,s14299]) (hints := [2,0,3,4,5,6,7,1,8,9,10,11]) (by decide +kernel) ?_
  change ∀ x ∈ [s14290,s5792,s14294,s14295,s2241,s14296,s3207,s4478,s5444,s14297,s14298,s14299], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14290) (b14290) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5792) (b5792) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14294) (b14294) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14295) (b14295) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s2241) (b2241) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14296) (b14296) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3207) (b3207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s4478) (b4478) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5444) (b5444) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14297) (b14297) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14298) (b14298) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14299) (b14299) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i5 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14300,s6731,s7527,s14301]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s14300,s6731,s7527,s14301], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14300) (b14300) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s6731) (b6731) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7527) (b7527) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14301) (b14301) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i6 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14302,s7744,s8423,s14303]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14302,s7744,s8423,s14303], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14302) (b14302) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s7744) (b7744) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8423) (b8423) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14303) (b14303) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i7 : PetersenLocalChildren.PairOK tgt 8 s14286 (word7,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14304,s8946,s9609,s10059,s10502,s10723,s14305,s10943]) (hints := [8845,0,8845,1,2,3,8845,4,8845,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s14304,s8946,s9609,s10059,s10502,s10723,s14305,s10943], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14304) (b14304) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s8946) (b8946) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s9609) (b9609) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10059) (b10059) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10502) (b10502) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10723) (b10723) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14305) (b14305) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s10943) (b10943) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i8 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11178,s11481]) (hints := [6838,6838,6966,9675,0,9675,6966,1,6966,9675,6838,9675]) (by decide +kernel) ?_
  change ∀ x ∈ [s11178,s11481], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11178) (b11178) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11481) (b11481) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i9 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s293,s3191,s11762,s12279]) (hints := [5934,0,5934,6840,6840,1,6062,2,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s293,s3191,s11762,s12279], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s293) (b293) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3191) (b3191) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s11762) (b11762) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12279) (b12279) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i10 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12437,s12908]) (hints := [6838,6838,7734,1543,0,1671,7734,1,7734,6838,6838,1671]) (by decide +kernel) ?_
  change ∀ x ∈ [s12437,s12908], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12437) (b12437) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s12908) (b12908) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i11 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word45) := by
  refine PetersenLocalChildren.pair_close (bank := #[s3207,s5444,s14306,s14307,s14308,s14309,s14327,s14328]) (hints := [2,3,4,6844,6844,0,6844,6844,1,5,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s3207,s5444,s14306,s14307,s14308,s14309,s14327,s14328], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s3207) (b3207) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5444) (b5444) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14306) (b14306) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14307) (b14307) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14308) (b14308) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14309) (b14309) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14327) (b14327) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14328) (b14328) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i12 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7466,4772,7466,11465,6836,11465,7466,6836,7466,11465,4772,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i13 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13642,2708,13642,13513,6836,13513,13642,6836,13642,13513,2708,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i14 : PetersenLocalChildren.PairOK tgt 8 s14286 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13187,s13610]) (hints := [13612,6838,13612,8711,0,8839,13612,1,13612,6838,6838,8839]) (by decide +kernel) ?_
  change ∀ x ∈ [s13187,s13610], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13187) (b13187) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13610) (b13610) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i15 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,5672,901,901,5930,901,901,5672,9673,9673,5930]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i16 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s13940,s14329]) (hints := [8643,8643,1671,9675,9675,0,9675,9675,1671,8643,8643,1]) (by decide +kernel) ?_
  change ∀ x ∈ [s13940,s14329], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13940) (b13940) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14329) (b14329) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i17 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word45) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14330,s13714,s14331,s14332]) (hints := [8645,8645,0,9677,9677,1,9677,9677,2,8645,8645,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s14330,s13714,s14331,s14332], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14330) (b14330) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s13714) (b13714) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14331) (b14331) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14332) (b14332) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i18 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i19 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i20 : PetersenLocalChildren.PairOK tgt 8 s14286 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,8837,1481,9673,13610,9609,9673,8837,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i21 : PetersenLocalChildren.PairOK tgt 8 s14286 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14343,s14344,s14345,s14346]) (hints := [4910,0,1,5934,5934,2,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s14343,s14344,s14345,s14346], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14343) (b14343) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14344) (b14344) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14345) (b14345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14346) (b14346) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i22 : PetersenLocalChildren.PairOK tgt 8 s14286 (word0,word45) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14346,s927,s14347]) (hints := [5933,5933,1,6965,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14346,s927,s14347], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14346) (b14346) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14347) (b14347) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i23 : PetersenLocalChildren.PairOK tgt 8 s14286 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14348,s14349]) (hints := [11467,5932,11467,2695,0,2695,11467,1,11467,2695,5932,2695]) (by decide +kernel) ?_
  change ∀ x ∈ [s14348,s14349], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14348) (b14348) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14349) (b14349) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i24 : PetersenLocalChildren.PairOK tgt 8 s14286 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [13513,10058,13513,4741,5930,4741,13513,5930,13513,4741,10058,4741]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i25 : PetersenLocalChildren.PairOK tgt 8 s14286 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5930,5930,13610,8837,10058,8837,13610,10058,13610,8837,5930,8837]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i26 : PetersenLocalChildren.PairOK tgt 8 s14286 (word6,word45) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14345,s927,s5442]) (hints := [1672,1672,1,7477,0,2]) (by decide +kernel) ?_
  change ∀ x ∈ [s14345,s927,s5442], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14345) (b14345) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s927) (b927) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s5442) (b5442) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i27 : PetersenLocalChildren.PairOK tgt 8 s14286 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,1669,10433,11465,7732,11465,10433,7732,10433,11465,1669,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i28 : PetersenLocalChildren.PairOK tgt 8 s14286 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,1669,12481,13513,7732,13513,12481,7732,12481,13513,1669,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i29 : PetersenLocalChildren.PairOK tgt 8 s14286 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14350,s14357]) (hints := [1671,1671,8839,13612,0,13612,8839,1,8839,1671,1671,13612]) (by decide +kernel) ?_
  change ∀ x ∈ [s14350,s14357], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14350) (b14350) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14357) (b14357) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i30 : PetersenLocalChildren.PairOK tgt 8 s14286 (word45,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14358,s14359,s14360,s14361]) (hints := [10437,0,10437,11469,1,11469,10437,2,10437,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s14358,s14359,s14360,s14361], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14358) (b14358) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14359) (b14359) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14360) (b14360) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14361) (b14361) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i31 : PetersenLocalChildren.PairOK tgt 8 s14286 (word45,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14362,s14363,s14364,s14365]) (hints := [12485,0,12485,13517,1,13517,12485,2,12485,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s14362,s14363,s14364,s14365], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14362) (b14362) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14363) (b14363) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14364) (b14364) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14365) (b14365) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i32 : PetersenLocalChildren.PairOK tgt 8 s14286 (word45,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s14366,s14367,s14376,s14386]) (hints := [14646,0,14646,8841,1,8841,14646,2,14646,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s14366,s14367,s14376,s14386], Blocked tgt 8 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14366) (b14366) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14367) (b14367) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14376) (b14376) <|
    PetersenLocalChildren.push (P := Blocked tgt 8) (x := s14386) (b14386) <|
    PetersenLocalChildren.nil
private theorem thetaPair14286i33 : PetersenLocalChildren.PairOK tgt 8 s14286 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i34 : PetersenLocalChildren.PairOK tgt 8 s14286 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,8837,3273,11465,14642,11401,11465,8837,3209,3209,14642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair14286i35 : PetersenLocalChildren.PairOK tgt 8 s14286 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,8837,5321,13513,13610,13449,13513,8837,5257,5257,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b14286 : Blocked tgt 9 s14286 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word7,word3),(word7,word1),(word7,word0),(word7,word6),(word7,word45),(word7,word5),(word7,word2),(word7,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word45),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word45),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word45),(word0,word5),(word0,word2),(word0,word4),(word6,word45),(word6,word5),(word6,word2),(word6,word4),(word45,word5),(word45,word2),(word45,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 8 s14286 p
  exact
    PetersenLocalChildren.push thetaPair14286i0 <|
    PetersenLocalChildren.push thetaPair14286i1 <|
    PetersenLocalChildren.push thetaPair14286i2 <|
    PetersenLocalChildren.push thetaPair14286i3 <|
    PetersenLocalChildren.push thetaPair14286i4 <|
    PetersenLocalChildren.push thetaPair14286i5 <|
    PetersenLocalChildren.push thetaPair14286i6 <|
    PetersenLocalChildren.push thetaPair14286i7 <|
    PetersenLocalChildren.push thetaPair14286i8 <|
    PetersenLocalChildren.push thetaPair14286i9 <|
    PetersenLocalChildren.push thetaPair14286i10 <|
    PetersenLocalChildren.push thetaPair14286i11 <|
    PetersenLocalChildren.push thetaPair14286i12 <|
    PetersenLocalChildren.push thetaPair14286i13 <|
    PetersenLocalChildren.push thetaPair14286i14 <|
    PetersenLocalChildren.push thetaPair14286i15 <|
    PetersenLocalChildren.push thetaPair14286i16 <|
    PetersenLocalChildren.push thetaPair14286i17 <|
    PetersenLocalChildren.push thetaPair14286i18 <|
    PetersenLocalChildren.push thetaPair14286i19 <|
    PetersenLocalChildren.push thetaPair14286i20 <|
    PetersenLocalChildren.push thetaPair14286i21 <|
    PetersenLocalChildren.push thetaPair14286i22 <|
    PetersenLocalChildren.push thetaPair14286i23 <|
    PetersenLocalChildren.push thetaPair14286i24 <|
    PetersenLocalChildren.push thetaPair14286i25 <|
    PetersenLocalChildren.push thetaPair14286i26 <|
    PetersenLocalChildren.push thetaPair14286i27 <|
    PetersenLocalChildren.push thetaPair14286i28 <|
    PetersenLocalChildren.push thetaPair14286i29 <|
    PetersenLocalChildren.push thetaPair14286i30 <|
    PetersenLocalChildren.push thetaPair14286i31 <|
    PetersenLocalChildren.push thetaPair14286i32 <|
    PetersenLocalChildren.push thetaPair14286i33 <|
    PetersenLocalChildren.push thetaPair14286i34 <|
    PetersenLocalChildren.push thetaPair14286i35 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
