import M191StartPreferredCommon
import M15StartLabeled
import M31StartLabeled
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M191.Preferred
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
def r755 (x : Fin 16) : Fin 128 := (#[0,2,4,6,64,66,68,70,32,34,36,38,96,98,100,102] : Array (Fin 128))[x.val]?.getD 0
theorem small755 : NoAtMost (0x4444 :: i4) (PetersenPackedPin.project r755 tgt) 3 := by
  have a : PetersenPackedPin.project r755 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x4444 (by decide +kernel)
theorem hot755 : forcedConst r755 tgt = false := by decide +kernel
def r756 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small756 : NoAtMost (0xeeeeeeee :: i5) (PetersenPackedPin.project r756 tgt) 6 := by
  have a : PetersenPackedPin.project r756 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xeeeeeeee (by decide +kernel)
theorem hot756 : forcedConst r756 tgt = false := by decide +kernel
def r757 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small757 : NoAtMost (0x50505050 :: i5) (PetersenPackedPin.project r757 tgt) 6 := by
  have a : PetersenPackedPin.project r757 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x50505050 (by decide +kernel)
theorem hot757 : forcedConst r757 tgt = false := by decide +kernel
def r758 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small758 : NoAtMost (0xffffaaaa :: i5) (PetersenPackedPin.project r758 tgt) 6 := by
  have a : PetersenPackedPin.project r758 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xffffaaaa (by decide +kernel)
theorem hot758 : forcedConst r758 tgt = false := by decide +kernel
def r759 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small759 : NoAtMost (0x55550000 :: i5) (PetersenPackedPin.project r759 tgt) 6 := by
  have a : PetersenPackedPin.project r759 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x55550000 (by decide +kernel)
theorem hot759 : forcedConst r759 tgt = false := by decide +kernel
def r760 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small760 : NoAtMost (0xf000f0 :: i5) (PetersenPackedPin.project r760 tgt) 6 := by
  have a : PetersenPackedPin.project r760 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xf000f0 (by decide +kernel)
theorem hot760 : forcedConst r760 tgt = false := by decide +kernel
def r761 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small761 : NoAtMost (0x55005500 :: i5) (PetersenPackedPin.project r761 tgt) 6 := by
  have a : PetersenPackedPin.project r761 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x55005500 (by decide +kernel)
theorem hot761 : forcedConst r761 tgt = false := by decide +kernel
def r762 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small762 : NoAtMost (0xfcfcfcfc :: i5) (PetersenPackedPin.project r762 tgt) 6 := by
  have a : PetersenPackedPin.project r762 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xfcfcfcfc (by decide +kernel)
theorem hot762 : forcedConst r762 tgt = false := by decide +kernel
def r763 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small763 : NoAtMost (0x30303030 :: i5) (PetersenPackedPin.project r763 tgt) 6 := by
  have a : PetersenPackedPin.project r763 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x30303030 (by decide +kernel)
theorem hot763 : forcedConst r763 tgt = false := by decide +kernel
def r764 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small764 : NoAtMost (0x33330000 :: i5) (PetersenPackedPin.project r764 tgt) 6 := by
  have a : PetersenPackedPin.project r764 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0x33330000 (by decide +kernel)
theorem hot764 : forcedConst r764 tgt = false := by decide +kernel
def r765 (x : Fin 16) : Fin 128 := (#[0,32,1,33,16,48,17,49,8,40,9,41,24,56,25,57] : Array (Fin 128))[x.val]?.getD 0
theorem small765 : NoAtMost (0x3300 :: i4) (PetersenPackedPin.project r765 tgt) 3 := by
  have a : PetersenPackedPin.project r765 tgt = PetersenSmallStarts.M15.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M15.all_forbidden 0x3300 (by decide +kernel)
theorem hot765 : forcedConst r765 tgt = false := by decide +kernel
def r766 (x : Fin 32) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103] : Array (Fin 128))[x.val]?.getD 0
theorem small766 : NoAtMost (0xfff0fff0 :: i5) (PetersenPackedPin.project r766 tgt) 6 := by
  have a : PetersenPackedPin.project r766 tgt = PetersenSmallStarts.M31.tgt := by decide +kernel
  rw [a]; exact PetersenSmallStarts.M31.all_forbidden 0xfff0fff0 (by decide +kernel)
theorem hot766 : forcedConst r766 tgt = false := by decide +kernel
end PetersenSmallStarts.M191.Preferred
