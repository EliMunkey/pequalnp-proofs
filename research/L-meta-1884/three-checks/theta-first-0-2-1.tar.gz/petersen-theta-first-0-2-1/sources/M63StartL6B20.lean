import M63StartData
import M63StartL5B19
import M63StartPins0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b665 : Blocked tgt 6 s665 := by
  apply PetersenFastNode.node (nxt := #[s666,s667]) (hints := [3446,391,3510,3446,2796,3190,2988,2796,3316,2284,3764,3316,2796,2292,3756,2796,2666,2796,2796,2666,716,748,2764,716,199,199,455,2988,455,3636,839,455,455,2486,1351,455,455,715,455,1462,2375,455,3508,839,3764,839,1095,1095,3756,1351,843,843,2635,2375,2635,2375,839,3756,1351,839,0,839,839,1,839,2123,2375,839,1351,1611,1351,1708,2375,1351,2635,2375,2635,2375]) (by decide +kernel)
  change ∀ b ∈ [s666,s667], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s666) b666 <|
    PetersenLocalChildren.push (x := s667) b667 <|
    PetersenLocalChildren.nil
theorem b668 : Blocked tgt 6 s668 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s668 6 _ le
  decide +kernel
theorem b669 : Blocked tgt 6 s669 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s669 6 _ le
  decide +kernel
theorem b670 : Blocked tgt 6 s670 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s670 6 _ le
  decide +kernel
theorem b671 : Blocked tgt 6 s671 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(1,false),(2,false))] s671 6 _ le
  decide +kernel
theorem b672 : Blocked tgt 6 s672 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(1,false),(2,false))] s672 6 _ le
  decide +kernel
theorem b673 : Blocked tgt 6 s673 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s673 6 _ le
  decide +kernel
theorem b674 : Blocked tgt 6 s674 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [1364,389,1428,1364,2794,1364,2986,2794,2664,2794,2794,2664,1234,2282,1682,1234,1706,1234,1706,1770,714,746,2762,714,197,453,2986,453,713,453,1682,837,453,453,1428,1428,453,453,1428,2373,453,841,841,1426,837,1682,837,1706,1426,1706,1962,2633,2373,2633,2373,1552,837,1552,837,1576,1706,1576,1706,2633,2373,2633,2373,837,1682,1682,837,837,2121,2373,837,1349,1349]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b675 : Blocked tgt 6 s675 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(1,false),(2,false))] s675 6 _ le
  decide +kernel
theorem b677 : Blocked tgt 6 s677 := by
  apply PetersenFastNode.node (nxt := #[s678,s679]) (hints := [2796,3446,2668,455,2796,455,2796,843,3052,2796,3316,2284,3764,3316,2796,2292,3756,2796,716,748,2764,716,3510,455,3510,455,2988,843,2858,843,3894,839,3894,839,3626,1351,3626,1351,0,2375,1,2375,715,199,843,715,455,203,839,455,455,3756,1351,455,455,1462,2375,455,3764,839,835,835,843,1095,1611,843,843,2119,2635,843,839,1099,1351,839,839,2123,2375,839,1351,1708,2375,1351]) (by decide +kernel)
  change ∀ b ∈ [s678,s679], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s678) b678 <|
    PetersenLocalChildren.push (x := s679) b679 <|
    PetersenLocalChildren.nil
theorem b680 : Blocked tgt 6 s680 := by
  intro k le c
  apply rejects_sound r2 i4 3 tgt small2 hot2 [] s680 6 _ le
  decide +kernel
theorem b681 : Blocked tgt 6 s681 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s681 6 _ le
  decide +kernel
theorem b682 : Blocked tgt 6 s682 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s682 6 _ le
  decide +kernel
theorem b683 : Blocked tgt 6 s683 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s683 6 _ le
  decide +kernel
theorem b684 : Blocked tgt 6 s684 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s684 6 _ le
  decide +kernel
theorem b685 : Blocked tgt 6 s685 := by
  apply PetersenFastNode.node (nxt := #[s661]) (hints := [3445,390,3509,3445,2795,778,2987,2795,3315,2283,3763,3315,3445,2795,2795,3445,2795,2291,3755,2795,715,747,2763,715,714,454,842,714,454,202,714,454,454,714,714,454,454,2485,1350,454,454,1461,2374,454,3763,842,842,4019,3507,842,842,0,842,1094,1610,842,842,2118,2634,842,838,838,1350,1610,1350,1610,2374,2634,2374,2634,1350,1610,1350,1610,2374,2634,2374,2634,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s661], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s661) b661 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M63
