import higher.WireProjection
import M191Values1
import M191Values10
import M191Values13
import M191Values14
import M191Values19
import M191Values2
import M191Values21
import M191Values24
import M191Values32
import M191Values35
import M191Values39
import M191Values41
import M191Values5
import M191Values737
import M191Values739
import M191Values750
import M191Values798
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredCuts7
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows59
import M191StartPreferredRows61
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
import M191StartPreferredRows65
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b12355 : Blocked tgt 6 s12355 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12355 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2627 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12356 : Blocked tgt 6 s12356 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12356 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4579 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b12357 : Blocked tgt 6 s12357 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12357 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_3331 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b12358 : Blocked tgt 6 s12358 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12358 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xaaaa,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12359 : Blocked tgt 6 s12359 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12359 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xaaaa,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1779 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12360 : Blocked tgt 6 s12360 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4264,4776,4264,8897,6962,4904,7090,6962,5032,4914,7080,5032,9162,936,13258,9162,9800,5032,5032,9160,5032,970,13224,5032,6836,1541,6836,6964,1541,4916,2693,1541,1541,2868,6964,1541,1541,6964,901,901,1541,12456,8837,1541,4772,4788,6820,4772,2708,6836,6836,2708,2708,6836,6836,2708,6836,8709,14900,6836,2693,3368,13386,2693,2693,7208,7208,2693,2693,12852,8837,2693,4741,4741,8837,14900,8837,14900,8837,14900,8837,14900]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b12361 : Blocked tgt 6 s12361 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s12361 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_1117 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_5700 (PetersenWireProjection.cons pv21_6504 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
theorem b12362 : Blocked tgt 6 s12362 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12362 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf580f580f580f580f580f580f580f580 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12363 : Blocked tgt 6 s12363 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12363 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2744 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12364 : Blocked tgt 6 s12364 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12364 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffff5c4fffff5c4fffff5c4fffff5c4 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12365 : Blocked tgt 6 s12365 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12365 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5c40000f5c40000f5c40000f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)

theorem b12366 : Blocked tgt 6 s12366 := by
  intro k le c
  apply rejects_sound r24 i4 3 tgt small24 hot24 [] s12366 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0x0,0x0,0xaaaa,0xf0f0,0xff00] (PetersenWireProjection.cons pv24_4814 (PetersenWireProjection.cons pv24_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r24 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r24 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r24 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv24_7474 (PetersenWireProjection.cons pv24_8012 rfl))))))) (by decide +kernel)
theorem b12367 : Blocked tgt 6 s12367 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12367 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xcccc,0x0,0x5555,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1912 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12370 : Blocked tgt 6 s12370 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12370 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2517 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12371 : Blocked tgt 6 s12371 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s12371 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xf0f0f0f0,0xcccccccc,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b12382 : Blocked tgt 6 s12382 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12382 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a080808080a0a0a0a08080808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6546 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12440 : Blocked tgt 6 s12440 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [901,4520,8641,389,8897,8641,6836,773,6836,6964,901,4916,2693,901,901,2868,4741,901,901,449,8837,901,4264,8897,4776,4264,7732,6836,1541,6836,1541,2693,6312,1541,1541,4741,12488,1541,1541,8837,12456,1541,6324,6324,8897,6836,8897,2181,10433,8897,8897,4229,12481,8897,5672,8837,8833,8833,4772,4788,6820,4772,2708,2740,6804,2708,6836,8709,14900,6836,2693,3112,4741,2693,2693,12852,8837,2693,4741,10804,8837,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b12441 : Blocked tgt 6 s12441 := by
  intro k le c
  apply rejects_sound r750 (0xcccccccc :: i6) 6 tgt small750 hot750 [(true,(2,false),(4,false))] s12441 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xcccccccccccccccc,0x0,0xffccffccffccffcc,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv750_2529 (PetersenWireProjection.cons pv750_2754 (PetersenWireProjection.cons pv750_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r750 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xffccffccffccffcc) (PetersenWireProjection.cons pv750_6790 (PetersenWireProjection.cons pv750_7474 (PetersenWireProjection.cons pv750_8012 rfl))))))) (by decide +kernel)
theorem b12442 : Blocked tgt 6 s12442 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12442 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2748 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b12443 : Blocked tgt 6 s12443 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12443 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xf0f0f0f0,0x0,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b12444 : Blocked tgt 6 s12444 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12444 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xffff0afaffff0afaffff0afaffff0afa : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12445 : Blocked tgt 6 s12445 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12445 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xafa00000afa00000afa00000afa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12446 : Blocked tgt 6 s12446 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s12446 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2754 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5284 (PetersenWireProjection.cons pv9_6504 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))) (by decide +kernel)
theorem b12447 : Blocked tgt 6 s12447 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12447 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0xaaaa,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv13_2884 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b12448 : Blocked tgt 6 s12448 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12448 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xaaaa,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2754 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12449 : Blocked tgt 6 s12449 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s12449 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_1829 (PetersenWireProjection.cons pv9_2754 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_6504 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))) (by decide +kernel)
theorem b12450 : Blocked tgt 6 s12450 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12450 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6457 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)

theorem b12451 : Blocked tgt 6 s12451 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12451 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1912 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12519 : Blocked tgt 6 s12519 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s12519 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xffff,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_5738 (PetersenWireProjection.cons pv19_6504 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7774 (PetersenWireProjection.cons pv19_8012 rfl))))))) (by decide +kernel)
theorem b12520 : Blocked tgt 6 s12520 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12520 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0xcccc,0x0,0x5555,0xffff,0x0,0xff00] (PetersenWireProjection.cons pv32_2963 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12521 : Blocked tgt 6 s12521 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12521 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5a0f5a0f500f500f5a0f5a0f500f500 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12522 : Blocked tgt 6 s12522 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12522 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0aaa0aaa0a0a0a0a0aaa0aaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12523 : Blocked tgt 6 s12523 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12523 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffff5f5fffff500fffff5f5fffff500 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12524 : Blocked tgt 6 s12524 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12524 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f5000000f5f50000f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12525 : Blocked tgt 6 s12525 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12525 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6457 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12526 : Blocked tgt 6 s12526 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12526 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xcccc,0x0,0x5555,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1912 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12527 : Blocked tgt 6 s12527 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12527 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv13_6475 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b12528 : Blocked tgt 6 s12528 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12528 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv13_1277 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_8012 rfl))))))) (by decide +kernel)
theorem b12529 : Blocked tgt 6 s12529 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12529 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0xffff,0xffff,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12530 : Blocked tgt 6 s12530 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12530 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xffff,0xff00] (PetersenWireProjection.cons pv14_1925 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f500f500f5f5f5f5f500f500 : BitVec 128) = 0xf0f0) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12564 : Blocked tgt 6 s12564 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12564 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0,0x0,0xcccc,0xaaaa,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_5961 (PetersenWireProjection.cons pv39_6504 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b12565 : Blocked tgt 6 s12565 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12565 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xf0f0,0x0,0xaaaa,0x0,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x80808080808080808cc08cc08cc08cc : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6504 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b12566 : Blocked tgt 6 s12566 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12566 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8245 rfl))))))) (by decide +kernel)
theorem b12567 : Blocked tgt 6 s12567 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12567 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xff00,0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0] (PetersenWireProjection.cons pv32_3004 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 rfl))))))) (by decide +kernel)
theorem b12568 : Blocked tgt 6 s12568 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12568 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xf5a0f5a0f5a0f5a0f500f500f500f500 : BitVec 128) = 0xf0f0f0f0f0f0f0f0) (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12569 : Blocked tgt 6 s12569 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s12569 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2711 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12570 : Blocked tgt 6 s12570 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12570 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffff5f5fffff5f5fffff500fffff500 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12571 : Blocked tgt 6 s12571 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12571 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f50000f5f50000f5000000f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b12572 : Blocked tgt 6 s12572 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12572 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xf0f0,0x0,0x0,0xaaaa,0x0,0xff00] (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xf5f5f5f5f5f5f5f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6504 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b12573 : Blocked tgt 6 s12573 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(false,(0,true),(5,false))] s12573 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xf5f50000,0xaaaaaaaa,0x0,0xff00ff00] (PetersenWireProjection.cons pv2_475 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xf5f50000) (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 rfl))))))) (by decide +kernel)
theorem b12574 : Blocked tgt 6 s12574 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12574 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6457 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12575 : Blocked tgt 6 s12575 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12575 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xcccc,0x0,0x5555,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_1912 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5761 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12576 : Blocked tgt 6 s12576 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12576 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xff00,0x0,0x0,0x0,0xf0f0] (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv13_6489 (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 rfl))))))) (by decide +kernel)
theorem b12577 : Blocked tgt 6 s12577 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s12577 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xff00,0x0,0x0,0xf0f0] (PetersenWireProjection.cons pv13_561 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv13_6504 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 rfl))))))) (by decide +kernel)
theorem b12578 : Blocked tgt 6 s12578 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12578 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xff00,0x0,0xffff,0xf0f0,0xffff] (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8331 rfl))))))) (by decide +kernel)
theorem b12579 : Blocked tgt 6 s12579 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s12579 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xff00,0x0,0xffff,0xf0f0] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0xff00) (PetersenWireProjection.cons pv14_6504 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 rfl))))))) (by decide +kernel)
theorem b12580 : Blocked tgt 6 s12580 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12580 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0xf0f0,0x0,0xaaaa,0x0,0x0,0xff00] (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6504 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffffffff000000000000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b12581 : Blocked tgt 6 s12581 := by
  intro k le c
  apply rejects_sound r41 i4 3 tgt small41 hot41 [] s12581 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xf0f0,0x0,0xaaaa,0xff00,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffffffff00000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv41_4814 (PetersenWireProjection.cons pv41_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x0) (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r41 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv41_6790 (PetersenWireProjection.cons pv41_7474 rfl))))))) (by decide +kernel)
theorem b12645 : Blocked tgt 6 s12645 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s12645 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5f5f5f5f5f5f5f5f5a0f5a0f5a0f5a0 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b12646 : Blocked tgt 6 s12646 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s12646 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf5f5f5f5f5f5f5f5f5a0f5a0f5a0f5a0 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl))))))) (by decide +kernel)
theorem b12728 : Blocked tgt 6 s12728 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(1,false),(4,false))] s12728 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0x0,0xffff0000,0xffaaffaa,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6457 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8191 (PetersenWireProjection.cons pv737_8295 rfl))))))) (by decide +kernel)
theorem b12729 : Blocked tgt 6 s12729 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(1,false),(4,false))] s12729 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xcccccccc,0xf0f0f0f0,0xffaaffaa,0xffff0000,0x0,0xff00ff00] (PetersenWireProjection.cons pv739_2708 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6504 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7439 (PetersenWireProjection.cons pv739_8295 rfl))))))) (by decide +kernel)
theorem b12743 : Blocked tgt 6 s12743 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12743 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12744 : Blocked tgt 6 s12744 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [(true,(0,false),(2,false))] s12744 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3157 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_5700 (PetersenWireProjection.cons pv8_6504 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b12745 : Blocked tgt 6 s12745 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s12745 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xf0f0f0f0,0xcccccccc,0xaaaaaaaa,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5946 (PetersenWireProjection.cons pv2_6504 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b12746 : Blocked tgt 6 s12746 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(false,(0,true),(3,false))] s12746 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xd0d0d0d0d0d0d0d0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0xf580f580f580f580f580f580f580f580 : BitVec 128) = 0xd0d0d0d0d0d0d0d0) (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b12747 : Blocked tgt 6 s12747 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s12747 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5c4f5c4f5c4f5c4f5c4f5c4f5c4f5c4 : BitVec 128) = 0xcccc) (PetersenWireProjection.cons pv10_6457 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))) (by decide +kernel)
theorem b12768 : Blocked tgt 6 s12768 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12768 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccc,0xf0f0,0x0,0xaaaa,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0x55555555555555550000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons pv39_6504 (PetersenWireProjection.cons pv39_6790 (PetersenWireProjection.cons pv39_7474 rfl))))))) (by decide +kernel)
theorem b12771 : Blocked tgt 6 s12771 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s12771 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5a0f5a0f5a0f5a0f500f500f500f500 : BitVec 128) = 0xf500f500) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b12772 : Blocked tgt 6 s12772 := by
  intro k le c
  apply rejects_sound r39 i4 3 tgt small39 hot39 [] s12772 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00,0x0] (PetersenWireProjection.cons pv39_4260 (PetersenWireProjection.cons pv39_4814 (PetersenWireProjection.cons pv39_5473 (PetersenWireProjection.cons pv39_5761 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r39 (0xffaa0000ffaa0000ffaa0000ffaa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv39_7474 (PetersenWireProjection.cons pv39_8012 rfl))))))) (by decide +kernel)
theorem b13272 : Blocked tgt 6 s13272 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13272 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf5f5f5f5f5f5f5f5f500f500f500f500 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_6618 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl))))))) (by decide +kernel)

theorem b13723 : Blocked tgt 6 s13723 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13723 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2748 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b13724 : Blocked tgt 6 s13724 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13724 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x8cc08cc08cc08cc08cc08cc08cc08cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b13725 : Blocked tgt 6 s13725 := by
  intro k le c
  apply rejects_sound r750 (0xcccccccc :: i6) 6 tgt small750 hot750 [] s13725 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xcccccccccccccccc,0x0,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv750_2529 (PetersenWireProjection.cons pv750_4260 (PetersenWireProjection.cons pv750_5473 (PetersenWireProjection.cons pv750_6170 (PetersenWireProjection.cons pv750_6790 (PetersenWireProjection.cons pv750_7474 (PetersenWireProjection.cons pv750_8012 rfl))))))) (by decide +kernel)
theorem b13726 : Blocked tgt 6 s13726 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s13726 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xafe0afe0afe0afe0afe0afe0afe0afe : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b13750 : Blocked tgt 6 s13750 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s13750 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xa0a0a0a0a0a0a0aaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa) (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b13751 : Blocked tgt 6 s13751 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13751 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x808080808080808cccccccccccccccc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b13969 : Blocked tgt 6 s13969 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s13969 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a0a0a0a0a0a0a0a2a0a2a0a2a0a2a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))) (by decide +kernel)
theorem b13970 : Blocked tgt 6 s13970 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s13970 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf5f5f5f5f5f5f5f5f5c4f5c4f5c4f5c4 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_6504 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b13971 : Blocked tgt 6 s13971 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13971 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccc,0x0,0x5555,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xf5f5f5f5f5f5f5f5f5c4f5c4f5c4f5c4 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl))))))) (by decide +kernel)

theorem b13972 : Blocked tgt 6 s13972 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s13972 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0f0c0f0c0f0c0f0c0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))) (by decide +kernel)
theorem b13975 : Blocked tgt 6 s13975 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s13975 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xaaaa,0xcccc,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0xf0f0f0f0f0f0f0f0f0e0f0e0f0e0f0e : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b13976 : Blocked tgt 6 s13976 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(true,(1,false),(4,false)),(false,(3,true),(0,false))] s13976 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0f0c0c,0xaaaaaaaa,0xcccccccc,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r2 (0xf0f0f0f0f0f0f0f0f0c0f0c0f0c0f0c : BitVec 128) = 0xf0f0c0c) (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))) (by decide +kernel)
theorem b13977 : Blocked tgt 6 s13977 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(3,false)),(false,(3,true),(0,false))] s13977 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf0c0f0c,0xaaaaaaaa,0xcccccccc,0x0,0xff00ff00,0xffff0000,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf0f0f0f0f0f0f0f0f0c0f0c0f0c0f0c : BitVec 128) = 0xf0c0f0c) (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 rfl))))))) (by decide +kernel)
theorem b13982 : Blocked tgt 6 s13982 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s13982 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xaaaaaaaaaaaaaaaaffeeffeeffeeffee : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl))))))) (by decide +kernel)
theorem b14335 : Blocked tgt 6 s14335 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s14335 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_3173 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b14354 : Blocked tgt 6 s14354 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4904,6836,4904,5032,6836,773,6964,6836,6578,6836,6836,6578,4772,4788,6820,4772,2708,2740,6804,2708,6836,1480,13352,6836,9673,901,8905,8905,6962,6962,11465,2693,11465,2693,13513,4741,13513,4741,4904,840,12840,4904,8641,901,901,8641,901,4916,2693,901,901,2868,4741,901,901,1481,8837,901,10433,2693,10433,2693,12481,4741,12481,4741,7218,3152,14386,7218,2693,3112,4741,2693,2693,3273,11401,2693,4741,5321,13449,4741]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact

    PetersenLocalChildren.nil
theorem b14355 : Blocked tgt 6 s14355 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(false,(0,true),(4,false))] s14355 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf500f500,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r5 (0xf5f0f5f0f5f0f5f0f500f500f500f500 : BitVec 128) = 0xf500f500) (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))) (by decide +kernel)
theorem b14374 : Blocked tgt 6 s14374 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s14374 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x5555,0xcccc,0x0,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r32 (0x55555555555555555550555055505550 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))) (by decide +kernel)
theorem b14375 : Blocked tgt 6 s14375 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s14375 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x5555,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0x55555555555555555550555055505550 : BitVec 128) = 0x5555) (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8104 rfl))))))) (by decide +kernel)
theorem b14379 : Blocked tgt 6 s14379 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s14379 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r1 (0x808080808080808ccc8ccc8ccc8ccc8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))) (by decide +kernel)
theorem b14380 : Blocked tgt 6 s14380 := by
  intro k le c
  apply rejects_sound r798 (0x4444 :: i4) 3 tgt small798 hot798 [] s14380 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x4444,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r798 (0x2020202020202023332333233323332 : BitVec 128) = 0x4444) (PetersenWireProjection.cons pv798_4260 (PetersenWireProjection.cons pv798_5473 (PetersenWireProjection.cons pv798_6170 (PetersenWireProjection.cons pv798_6790 (PetersenWireProjection.cons pv798_7474 (PetersenWireProjection.cons pv798_8012 rfl))))))) (by decide +kernel)
theorem b14381 : Blocked tgt 6 s14381 := by
  intro k le c
  apply rejects_sound r35 i4 3 tgt small35 hot35 [] s14381 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xf0f0,0xff00,0x0,0xffff] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r35 (0xa0a0a0a0a0a0a0afffafffafffafffa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv35_4814 (PetersenWireProjection.cons pv35_5473 (PetersenWireProjection.cons pv35_6170 (PetersenWireProjection.cons pv35_6790 (PetersenWireProjection.cons pv35_7474 (PetersenWireProjection.cons pv35_8191 rfl))))))) (by decide +kernel)
theorem b14398 : Blocked tgt 6 s14398 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(false,(0,false),(1,false))] s14398 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x8888888888888888,0xaaaaaaaaaaaaaaaa,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0x8c808c808c808c808c808c808c808c8 : BitVec 128) = 0x8888888888888888) (PetersenWireProjection.cons pv9_2748 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))) (by decide +kernel)
theorem b14399 : Blocked tgt 6 s14399 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14399 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0x8c808c808c808c808c808c808c808c8 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5682 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))) (by decide +kernel)
theorem b14406 : Blocked tgt 6 s14406 := by
  intro k le c
  apply rejects_sound r750 (0xcccccccc :: i6) 6 tgt small750 hot750 [(true,(2,false),(4,false))] s14406 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xcccccccc,0xcccccccccccccccc,0x0,0xffccffccffccffcc,0xf0f0f0f0f0f0f0f0,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000] (PetersenWireProjection.cons pv750_2529 (PetersenWireProjection.cons pv750_4260 (PetersenWireProjection.cons pv750_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r750 (0xfffafffafffafffafffafffafffafffa : BitVec 128) = 0xffccffccffccffcc) (PetersenWireProjection.cons pv750_6790 (PetersenWireProjection.cons pv750_7474 (PetersenWireProjection.cons pv750_8012 rfl))))))) (by decide +kernel)
theorem b14407 : Blocked tgt 6 s14407 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s14407 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xafa0afa0afa0afa0afa0afa0afa0afa : BitVec 128) = 0xaaaa) (PetersenWireProjection.cons pv21_3690 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))) (by decide +kernel)
theorem b14408 : Blocked tgt 6 s14408 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(3,false),(0,false))] s14408 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xfafafafa,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2754 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xfffa0000fffa0000fffa0000fffa0000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))) (by decide +kernel)
theorem b14565 : Blocked tgt 6 s14565 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14565 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xffff,0xaaaa,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xaaa0aaa0aaa0aaa0aaa0aaa0aaa0aaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_2757 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
theorem b14566 : Blocked tgt 6 s14566 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14566 6 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffff,0xffff,0xaaaa,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2108 (PetersenWireProjection.cons pv14_2757 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
