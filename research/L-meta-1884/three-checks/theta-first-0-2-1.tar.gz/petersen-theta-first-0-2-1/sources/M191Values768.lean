import higher.WireProjection
import M191StartPreferredCuts5
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv768_4260 : PetersenPackedPin.project r768 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0xaaaaaaaa := by decide +kernel
theorem pv768_4814 : PetersenPackedPin.project r768 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xcccccccc := by decide +kernel
theorem pv768_5473 : PetersenPackedPin.project r768 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xf0f0f0f0 := by decide +kernel
theorem pv768_6170 : PetersenPackedPin.project r768 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0x0 := by decide +kernel
theorem pv768_6790 : PetersenPackedPin.project r768 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0x0 := by decide +kernel
theorem pv768_7474 : PetersenPackedPin.project r768 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xffff0000 := by decide +kernel
theorem pv768_8012 : PetersenPackedPin.project r768 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xff00ff00 := by decide +kernel
theorem pv768_1734 : PetersenPackedPin.project r768 (0xaaaa0000aaaa0000aaaa0000aaaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 1 pv768_4260 pv768_6790 rfl rfl
theorem pv768_3485 : PetersenPackedPin.project r768 (0x33333333333333330000000000000000 : BitVec 128) = 0x33003300 := PetersenWireProjection.derive 2 pv768_4814 pv768_8012 rfl rfl
theorem pv768_6504 : PetersenPackedPin.project r768 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaa := PetersenWireProjection.derive 3 pv768_4260 pv768_6170 rfl rfl
theorem pv768_8295 : PetersenPackedPin.project r768 (0xffffffffffffffffff00ff00ff00ff00 : BitVec 128) = 0xff00ff00 := PetersenWireProjection.derive 3 pv768_6170 pv768_8012 rfl rfl
theorem pv768_3511 : PetersenPackedPin.project r768 (0x33333333333333333300330033003300 : BitVec 128) = 0x33003300 := PetersenWireProjection.derive 2 pv768_4814 pv768_8295 rfl rfl
end PetersenSmallStarts.M191.Residual
