import M191StartPreferredSignals
import M191ResidualC7A0G1
import M191ResidualC7A0G3
import M191ResidualC7A0G4
import M191ResidualC7A0G40
import M191ResidualC7A0G46
import M191ResidualC7A0G47
import M191StagedF0X2Z1G16
import M191StagedF0X2Z1G17
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G22
import M191StagedF0X2Z1G23
import M191StagedF0X2Z1G24
import M191StagedF0X2Z1G25
import M191StagedF0X2Z1G26
import M191StagedF0X2Z1G27
import M191StagedF0X2Z1G28
import M191StagedF0X2Z1G3
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G5
import M191StagedF0X2Z1G51
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G8
import M191StartPreferredRows1
import M191StartPreferredRows10
import M191StartPreferredRows11
import M191StartPreferredRows13
import M191StartPreferredRows2
import M191StartPreferredRows20
import M191StartPreferredRows21
import M191StartPreferredRows24
import M191StartPreferredRows25
import M191StartPreferredRows26
import M191StartPreferredRows27
import M191StartPreferredRows28
import M191StartPreferredRows29
import M191StartPreferredRows3
import M191StartPreferredRows30
import M191StartPreferredRows31
import M191StartPreferredRows32
import M191StartPreferredRows33
import M191StartPreferredRows4
import M191StartPreferredRows47
import M191StartPreferredRows6
import M191StartPreferredRows7
import ResidualFast
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b5704 : Blocked tgt 8 s5704 := by
  apply PetersenFastNode.node (nxt := #[s5705,s5641,s5706,s5643,s5707,s1510,s5708,s1512,s5709,s5710,s5711,s5712,s5713,s5512,s5714,s5715,s5676,s5716,s5678,s5717,s1517,s5550,s1519,s5718,s5688,s5719,s5690,s5720,s4702,s4711,s4697,s4672,s5721,s5722,s5723,s5724,s5725,s5726,s5727,s5728,s5729,s5730,s5731,s5732,s5733,s5609,s5734,s5735,s5736,s572,s5737,s4701]) (hints := [6888,6888,7016,825,5598,953,7016,5598,7016,6888,6888,953,5598,5598,5982,9853,6888,9981,5982,6888,5982,5598,5598,9981,7526,10758,7526,5598,5598,1721,7526,5598,7526,7654,10758,1721,5598,5598,7518,8710,10758,2745,7518,10758,7518,5598,5598,2745,9726,9726,13694,1502,5598,4793,13694,5598,13694,9726,9726,4793,5598,5598,0,9726,9726,1,9726,9726,2,5598,5598,3,5598,5598,4,9726,9726,5,9726,9726,6,5598,5598,7,9725,9725,9981,953,953,5982,9981,953,9981,9725,9725,5982,953,953,1721,8701,9725,7526,1721,9725,1721,953,953,7526,953,953,2745,4968,7016,7518,2745,7016,2745,953,953,7518,953,953,4793,2920,7016,13694,4793,7016,4793,953,953,13694,953,953,8,9725,9725,9,9725,9725,10,953,953,11,953,953,12,9725,9725,13,9725,9725,14,953,953,15,8949,8949,7526,8957,9981,1721,9973,9981,7526,8949,8949,1721,9981,9981,11517,2745,7014,2745,11517,7014,11517,9981,9981,2745,9981,9981,13565,4793,5982,4793,13565,5982,13565,9981,9981,4793,1725,1725,16,9981,9981,17,9981,9981,18,1725,1725,19,1725,1725,20,9981,9981,21,9981,9981,22,1725,1725,23,1721,1721,2745,10493,7526,11517,2745,7526,2745,1721,1721,11517,1721,1721,4793,12541,7526,13565,4793,7526,4793,1721,1721,13565,1721,1721,24,11654,11654,25,11654,11654,26,1721,1721,27,1721,1721,28,11654,11654,29,11654,11654,30,1721,1721,31,2745,2745,4793,3422,7518,14726,4793,7518,4793,2745,2745,14726,2745,2745,32,11517,11517,33,11517,11517,34,2745,2745,35,2745,2745,36,11517,11517,37,11517,11517,38,2745,2745,39,4793,4793,40,13565,13565,41,13565,13565,42,4793,4793,43,4793,4793,44,13565,13565,45,13565,13565,46,4793,4793,47,8889,48,49,8889,50,51]) (by decide +kernel)
  change ∀ b ∈ [s5705,s5641,s5706,s5643,s5707,s1510,s5708,s1512,s5709,s5710,s5711,s5712,s5713,s5512,s5714,s5715,s5676,s5716,s5678,s5717,s1517,s5550,s1519,s5718,s5688,s5719,s5690,s5720,s4702,s4711,s4697,s4672,s5721,s5722,s5723,s5724,s5725,s5726,s5727,s5728,s5729,s5730,s5731,s5732,s5733,s5609,s5734,s5735,s5736,s572,s5737,s4701], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5705) b5705 <|
    PetersenLocalChildren.push (x := s5641) b5641 <|
    PetersenLocalChildren.push (x := s5706) b5706 <|
    PetersenLocalChildren.push (x := s5643) b5643 <|
    PetersenLocalChildren.push (x := s5707) b5707 <|
    PetersenLocalChildren.push (x := s1510) b1510 <|
    PetersenLocalChildren.push (x := s5708) b5708 <|
    PetersenLocalChildren.push (x := s1512) b1512 <|
    PetersenLocalChildren.push (x := s5709) b5709 <|
    PetersenLocalChildren.push (x := s5710) b5710 <|
    PetersenLocalChildren.push (x := s5711) b5711 <|
    PetersenLocalChildren.push (x := s5712) b5712 <|
    PetersenLocalChildren.push (x := s5713) b5713 <|
    PetersenLocalChildren.push (x := s5512) b5512 <|
    PetersenLocalChildren.push (x := s5714) b5714 <|
    PetersenLocalChildren.push (x := s5715) b5715 <|
    PetersenLocalChildren.push (x := s5676) b5676 <|
    PetersenLocalChildren.push (x := s5716) b5716 <|
    PetersenLocalChildren.push (x := s5678) b5678 <|
    PetersenLocalChildren.push (x := s5717) b5717 <|
    PetersenLocalChildren.push (x := s1517) b1517 <|
    PetersenLocalChildren.push (x := s5550) b5550 <|
    PetersenLocalChildren.push (x := s1519) b1519 <|
    PetersenLocalChildren.push (x := s5718) b5718 <|
    PetersenLocalChildren.push (x := s5688) b5688 <|
    PetersenLocalChildren.push (x := s5719) b5719 <|
    PetersenLocalChildren.push (x := s5690) b5690 <|
    PetersenLocalChildren.push (x := s5720) b5720 <|
    PetersenLocalChildren.push (x := s4702) b4702 <|
    PetersenLocalChildren.push (x := s4711) b4711 <|
    PetersenLocalChildren.push (x := s4697) b4697 <|
    PetersenLocalChildren.push (x := s4672) b4672 <|
    PetersenLocalChildren.push (x := s5721) b5721 <|
    PetersenLocalChildren.push (x := s5722) b5722 <|
    PetersenLocalChildren.push (x := s5723) b5723 <|
    PetersenLocalChildren.push (x := s5724) b5724 <|
    PetersenLocalChildren.push (x := s5725) b5725 <|
    PetersenLocalChildren.push (x := s5726) b5726 <|
    PetersenLocalChildren.push (x := s5727) b5727 <|
    PetersenLocalChildren.push (x := s5728) b5728 <|
    PetersenLocalChildren.push (x := s5729) b5729 <|
    PetersenLocalChildren.push (x := s5730) b5730 <|
    PetersenLocalChildren.push (x := s5731) b5731 <|
    PetersenLocalChildren.push (x := s5732) b5732 <|
    PetersenLocalChildren.push (x := s5733) b5733 <|
    PetersenLocalChildren.push (x := s5609) b5609 <|
    PetersenLocalChildren.push (x := s5734) b5734 <|
    PetersenLocalChildren.push (x := s5735) b5735 <|
    PetersenLocalChildren.push (x := s5736) b5736 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s5737) b5737 <|
    PetersenLocalChildren.push (x := s4701) b4701 <|
    PetersenLocalChildren.nil
theorem b5785 : Blocked tgt 8 s5785 := by
  apply PetersenFastNode.node (nxt := #[s5566,s5710,s5786,s5787,s5512,s1690,s5788]) (hints := [5553,6585,9680,8648,9680,8648,9936,8904,1676,0,2700,10440,2700,10440,4748,12488,4748,12488,13617,1,13617,2,3,4,5,6,6843,8648,5553,8648,5553,9808,5937,5553,7481,5553,7481,7609,5553,10440,7473,10440,9681,12488,13649,12488,5553,1489,13617,5553,6843,5553,5553,6843,8648,5937,9936,8648,8648,9680,1676,8648,8648,7473,10440,8648,8648,13393,12488,8648,456,8648,13617,8648,392,8912,8912,9936,1676,10440,2700,10440,9936,12488,4748,12488,9936,1680,9936,9936,1680,1680,9936,9936,1680,10440,11472,10440,1676,12488,13520,12488,1676,1676,3417,14649,1676,1676,7481,7481,1676,10440,3377,12488,10440,2184,10440,10440,2184,2184,10440,10440,2184,4232,12488,12488,4232,4232,12488,12488,4232,8844,8844]) (by decide +kernel)
  change ∀ b ∈ [s5566,s5710,s5786,s5787,s5512,s1690,s5788], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5566) b5566 <|
    PetersenLocalChildren.push (x := s5710) b5710 <|
    PetersenLocalChildren.push (x := s5786) b5786 <|
    PetersenLocalChildren.push (x := s5787) b5787 <|
    PetersenLocalChildren.push (x := s5512) b5512 <|
    PetersenLocalChildren.push (x := s1690) b1690 <|
    PetersenLocalChildren.push (x := s5788) b5788 <|
    PetersenLocalChildren.nil
theorem b6119 : Blocked tgt 8 s6119 := by
  apply PetersenFastNode.node (nxt := #[s6120,s6121,s6122,s6123,s6124,s6125,s6126,s6127,s6128,s6129,s6130,s6131,s6132,s6133,s6134,s6135,s6136,s1015,s6137,s6138,s6139,s6140,s6141,s3003,s6053,s6142,s6143,s6144,s6145,s6146,s6147,s6148,s6149,s6150,s6151,s6152,s6153,s6154,s991,s6155,s6026,s6156,s6157,s6158,s6159]) (hints := [6881,6881,7009,818,6623,946,7009,6623,7009,6881,6881,946,5975,6623,5975,6369,6881,0,5975,6881,5975,6103,6623,1,6623,6623,7519,4567,2,1714,7519,3,7519,6623,6623,1714,7511,4559,7511,4575,6623,2738,7511,6623,7511,4559,4559,2738,2527,2753,4,2527,6623,12526,6623,6623,5,2753,2753,12526,2753,2753,6,6623,6623,7,6623,6623,8,10751,2753,9,13655,6623,13655,8754,10,8882,13655,11,13655,6623,6623,8882,8686,8686,5717,946,946,5975,946,946,5717,8686,8686,5975,946,946,1714,7263,12,7519,1714,13,1714,946,946,7519,946,946,2738,4961,7009,7511,2738,7009,2738,946,946,7511,946,946,12526,7009,7009,14,12526,7009,12526,946,946,15,946,946,16,8686,8686,17,8686,8686,18,946,946,19,946,946,8882,494,8686,13655,8882,8686,8882,946,946,13655,7007,7007,7519,1714,5975,1714,7519,5975,7519,1714,7007,1714,10478,5975,10478,2738,7007,2738,10478,7007,10478,2738,5975,2738,12526,10103,12526,5975,5975,20,12526,5975,12526,13038,10103,21,8942,10103,22,8942,5975,23,5975,5975,24,10103,10103,25,5975,5975,13655,8882,10103,8882,13655,10103,13655,8882,5975,8882,1714,1714,2738,7511,7519,7511,2738,7519,2738,1714,1714,7511,1714,1714,12526,7519,7519,26,12526,7519,12526,1714,1714,27,1714,1714,28,7519,7519,29,7519,7519,30,1714,1714,31,1714,1714,8882,3455,11647,13655,8882,11647,8882,1714,1714,13655,2738,2738,12526,7511,7511,32,12526,7511,12526,2738,2738,33,2738,2738,34,10478,10478,35,10478,10478,36,2738,2738,37,2738,2738,8882,2286,10478,14687,8882,10478,8882,2738,2738,14687,4786,12526,38,4786,39,40,8882,4270,8882,4334,12526,13655,8882,12526,8882,4270,4270,13655,8882,41,8882,13655,42,13655,8882,43,8882,13655,44,13655]) (by decide +kernel)
  change ∀ b ∈ [s6120,s6121,s6122,s6123,s6124,s6125,s6126,s6127,s6128,s6129,s6130,s6131,s6132,s6133,s6134,s6135,s6136,s1015,s6137,s6138,s6139,s6140,s6141,s3003,s6053,s6142,s6143,s6144,s6145,s6146,s6147,s6148,s6149,s6150,s6151,s6152,s6153,s6154,s991,s6155,s6026,s6156,s6157,s6158,s6159], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6120) b6120 <|
    PetersenLocalChildren.push (x := s6121) b6121 <|
    PetersenLocalChildren.push (x := s6122) b6122 <|
    PetersenLocalChildren.push (x := s6123) b6123 <|
    PetersenLocalChildren.push (x := s6124) b6124 <|
    PetersenLocalChildren.push (x := s6125) b6125 <|
    PetersenLocalChildren.push (x := s6126) b6126 <|
    PetersenLocalChildren.push (x := s6127) b6127 <|
    PetersenLocalChildren.push (x := s6128) b6128 <|
    PetersenLocalChildren.push (x := s6129) b6129 <|
    PetersenLocalChildren.push (x := s6130) b6130 <|
    PetersenLocalChildren.push (x := s6131) b6131 <|
    PetersenLocalChildren.push (x := s6132) b6132 <|
    PetersenLocalChildren.push (x := s6133) b6133 <|
    PetersenLocalChildren.push (x := s6134) b6134 <|
    PetersenLocalChildren.push (x := s6135) b6135 <|
    PetersenLocalChildren.push (x := s6136) b6136 <|
    PetersenLocalChildren.push (x := s1015) b1015 <|
    PetersenLocalChildren.push (x := s6137) b6137 <|
    PetersenLocalChildren.push (x := s6138) b6138 <|
    PetersenLocalChildren.push (x := s6139) b6139 <|
    PetersenLocalChildren.push (x := s6140) b6140 <|
    PetersenLocalChildren.push (x := s6141) b6141 <|
    PetersenLocalChildren.push (x := s3003) b3003 <|
    PetersenLocalChildren.push (x := s6053) b6053 <|
    PetersenLocalChildren.push (x := s6142) b6142 <|
    PetersenLocalChildren.push (x := s6143) b6143 <|
    PetersenLocalChildren.push (x := s6144) b6144 <|
    PetersenLocalChildren.push (x := s6145) b6145 <|
    PetersenLocalChildren.push (x := s6146) b6146 <|
    PetersenLocalChildren.push (x := s6147) b6147 <|
    PetersenLocalChildren.push (x := s6148) b6148 <|
    PetersenLocalChildren.push (x := s6149) b6149 <|
    PetersenLocalChildren.push (x := s6150) b6150 <|
    PetersenLocalChildren.push (x := s6151) b6151 <|
    PetersenLocalChildren.push (x := s6152) b6152 <|
    PetersenLocalChildren.push (x := s6153) b6153 <|
    PetersenLocalChildren.push (x := s6154) b6154 <|
    PetersenLocalChildren.push (x := s991) b991 <|
    PetersenLocalChildren.push (x := s6155) b6155 <|
    PetersenLocalChildren.push (x := s6026) b6026 <|
    PetersenLocalChildren.push (x := s6156) b6156 <|
    PetersenLocalChildren.push (x := s6157) b6157 <|
    PetersenLocalChildren.push (x := s6158) b6158 <|
    PetersenLocalChildren.push (x := s6159) b6159 <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i0 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6306,s6307,s6308,s6309]) (hints := [6840,6840,6968,0,777,6582,905,1,6968,6582,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6306,s6307,s6308,s6309], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6306) (b6306) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6307) (b6307) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6308) (b6308) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6309) (b6309) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i1 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6310,s6311,s6312,s6313,s6314,s6315]) (hints := [10064,6584,10064,0,6330,6842,1,2,10064,6842,10064,3,10192,6584,4,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6310,s6311,s6312,s6313,s6314,s6315], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6310) (b6310) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6311) (b6311) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6312) (b6312) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6313) (b6313) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6314) (b6314) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6315) (b6315) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i2 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6316,s6317,s6318,s6319,s6320,s6321]) (hints := [11608,6584,11608,0,4528,1,1675,2,11608,3,11608,4,6584,6584,1675,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6316,s6317,s6318,s6319,s6320,s6321], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6316) (b6316) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6317) (b6317) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6318) (b6318) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6319) (b6319) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6320) (b6320) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6321) (b6321) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i3 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6322,s6323,s6324,s6325,s6326,s6327]) (hints := [13616,6584,13616,0,2520,1,8843,2,13616,3,13616,4,6584,6584,8843,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6322,s6323,s6324,s6325,s6326,s6327], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6322) (b6322) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6323) (b6323) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6324) (b6324) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6325) (b6325) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6326) (b6326) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6327) (b6327) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i4 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6328,s6329,s6330,s6331]) (hints := [11598,4518,11598,0,4534,6582,2697,1,11598,6582,11598,2,4518,4518,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6328,s6329,s6330,s6331], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6328) (b6328) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6329) (b6329) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6330) (b6330) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6331) (b6331) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i5 : PetersenLocalChildren.PairOK tgt 7 s6305 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6332,s6333,s6334,s6335]) (hints := [13646,2454,13646,0,2486,6582,4745,1,13646,6582,13646,2,2454,2454,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6332,s6333,s6334,s6335], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6332) (b6332) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6333) (b6333) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6334) (b6334) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6335) (b6335) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i6 : PetersenLocalChildren.PairOK tgt 7 s6305 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6336,s6337,s6338,s6339]) (hints := [389,389,9804,0,393,905,10062,1,901,905,9804,2,389,389,10062,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6336,s6337,s6338,s6339], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6336) (b6336) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6337) (b6337) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6338) (b6338) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6339) (b6339) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i7 : PetersenLocalChildren.PairOK tgt 7 s6305 (word1,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6340,s6341,s6342,s6343,s6344,s6345]) (hints := [907,907,1675,0,11352,1,11608,2,1675,3,1675,4,907,907,11608,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6340,s6341,s6342,s6343,s6344,s6345], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6340) (b6340) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6341) (b6341) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6342) (b6342) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6343) (b6343) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6344) (b6344) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6345) (b6345) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i8 : PetersenLocalChildren.PairOK tgt 7 s6305 (word1,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6346,s6347,s6348,s6349,s6350,s6351]) (hints := [907,907,8843,0,13360,1,13616,2,8843,3,8843,4,907,907,13616,5]) (by decide +kernel) ?_
  change ∀ x ∈ [s6346,s6347,s6348,s6349,s6350,s6351], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6346) (b6346) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6347) (b6347) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6348) (b6348) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6349) (b6349) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6350) (b6350) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6351) (b6351) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i9 : PetersenLocalChildren.PairOK tgt 7 s6305 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6352,s6353,s6354,s6355]) (hints := [905,905,2697,0,4920,6968,11598,1,2697,6968,2697,2,905,905,11598,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6352,s6353,s6354,s6355], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6352) (b6352) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6353) (b6353) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6354) (b6354) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6355) (b6355) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i10 : PetersenLocalChildren.PairOK tgt 7 s6305 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6356,s6357,s6358,s6359]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6356,s6357,s6358,s6359], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6356) (b6356) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6357) (b6357) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6358) (b6358) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6359) (b6359) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i11 : PetersenLocalChildren.PairOK tgt 7 s6305 (word0,word25) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6360,s6361,s6362,s6363]) (hints := [11094,11094,11606,0,1673,10062,1673,1,1669,10062,11606,2,1669,11094,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6360,s6361,s6362,s6363], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6360) (b6360) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6361) (b6361) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6362) (b6362) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6363) (b6363) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i12 : PetersenLocalChildren.PairOK tgt 7 s6305 (word0,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6364,s6365,s6366,s6367]) (hints := [5934,5934,13614,0,8841,10062,8841,1,8837,10062,13614,2,8837,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6364,s6365,s6366,s6367], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6364) (b6364) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6365) (b6365) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6366) (b6366) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6367) (b6367) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i13 : PetersenLocalChildren.PairOK tgt 7 s6305 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6368,s6369,s6370,s6371]) (hints := [2181,10062,2181,0,2185,11094,2697,1,2181,11094,2181,2,2693,10062,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6368,s6369,s6370,s6371], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6368) (b6368) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6369) (b6369) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6370) (b6370) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6371) (b6371) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i14 : PetersenLocalChildren.PairOK tgt 7 s6305 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6372,s6373,s6374,s6375]) (hints := [4229,10062,4229,0,4233,5934,4745,1,4229,5934,4229,2,4741,10062,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6372,s6373,s6374,s6375], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6372) (b6372) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6373) (b6373) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6374) (b6374) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6375) (b6375) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i15 : PetersenLocalChildren.PairOK tgt 7 s6305 (word25,word26) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6376,s6377,s6378,s6379]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6376,s6377,s6378,s6379], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6376) (b6376) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6377) (b6377) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6378) (b6378) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6379) (b6379) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i16 : PetersenLocalChildren.PairOK tgt 7 s6305 (word25,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6380,s6381,s6382,s6383]) (hints := [1673,1673,2697,0,11598,11606,11598,1,2697,11606,2697,2,1673,1673,11598,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6380,s6381,s6382,s6383], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6380) (b6380) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6381) (b6381) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6382) (b6382) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6383) (b6383) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i17 : PetersenLocalChildren.PairOK tgt 7 s6305 (word25,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6384,s6385,s6386,s6387]) (hints := [1673,1673,4745,0,12622,7478,13646,1,4745,7478,4745,2,1673,1673,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6384,s6385,s6386,s6387], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6384) (b6384) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6385) (b6385) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6386) (b6386) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6387) (b6387) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i18 : PetersenLocalChildren.PairOK tgt 7 s6305 (word26,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6388,s6389,s6390,s6391]) (hints := [2697,8841,2697,0,3406,14646,11598,1,2697,14646,2697,2,8841,8841,11598,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6388,s6389,s6390,s6391], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6388) (b6388) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6389) (b6389) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6390) (b6390) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6391) (b6391) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i19 : PetersenLocalChildren.PairOK tgt 7 s6305 (word26,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6392,s6393,s6394,s6395]) (hints := [4745,8841,4745,0,13614,13614,13646,1,4745,13614,4745,2,8841,8841,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6392,s6393,s6394,s6395], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6392) (b6392) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6393) (b6393) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6394) (b6394) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6395) (b6395) <|
    PetersenLocalChildren.nil
private theorem thetaPair6305i20 : PetersenLocalChildren.PairOK tgt 7 s6305 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s6396,s6397,s6398,s6399]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s6396,s6397,s6398,s6399], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6396) (b6396) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6397) (b6397) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6398) (b6398) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s6399) (b6399) <|
    PetersenLocalChildren.nil
theorem b6305 : Blocked tgt 8 s6305 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word25),(word3,word26),(word3,word5),(word3,word2),(word1,word0),(word1,word25),(word1,word26),(word1,word5),(word1,word2),(word0,word25),(word0,word26),(word0,word5),(word0,word2),(word25,word26),(word25,word5),(word25,word2),(word26,word5),(word26,word2),(word5,word2)], PetersenLocalChildren.PairOK tgt 7 s6305 p
  exact
    PetersenLocalChildren.push thetaPair6305i0 <|
    PetersenLocalChildren.push thetaPair6305i1 <|
    PetersenLocalChildren.push thetaPair6305i2 <|
    PetersenLocalChildren.push thetaPair6305i3 <|
    PetersenLocalChildren.push thetaPair6305i4 <|
    PetersenLocalChildren.push thetaPair6305i5 <|
    PetersenLocalChildren.push thetaPair6305i6 <|
    PetersenLocalChildren.push thetaPair6305i7 <|
    PetersenLocalChildren.push thetaPair6305i8 <|
    PetersenLocalChildren.push thetaPair6305i9 <|
    PetersenLocalChildren.push thetaPair6305i10 <|
    PetersenLocalChildren.push thetaPair6305i11 <|
    PetersenLocalChildren.push thetaPair6305i12 <|
    PetersenLocalChildren.push thetaPair6305i13 <|
    PetersenLocalChildren.push thetaPair6305i14 <|
    PetersenLocalChildren.push thetaPair6305i15 <|
    PetersenLocalChildren.push thetaPair6305i16 <|
    PetersenLocalChildren.push thetaPair6305i17 <|
    PetersenLocalChildren.push thetaPair6305i18 <|
    PetersenLocalChildren.push thetaPair6305i19 <|
    PetersenLocalChildren.push thetaPair6305i20 <|
    PetersenLocalChildren.nil
theorem b6561 : Blocked tgt 8 s6561 := by
  apply PetersenFastNode.node (nxt := #[s6562,s2602,s6563,s6564,s6565,s6566,s6567,s6568,s6569,s6570,s6571,s6572,s6573,s6574,s413,s6575,s6576,s6577,s6578,s6579,s6580,s6581]) (hints := [5952,5952,6080,6346,0,1,9695,5694,9695,5696,5952,6986,9695,5952,9695,5694,5694,6986,1691,6984,1691,4928,5952,7754,1691,5952,1691,6984,6984,7754,11487,5952,11487,6984,6984,2,11487,6984,11487,5952,5952,3,9951,5952,9951,6984,6984,4,9951,6984,9951,5952,5952,5,13535,10080,13535,1856,5952,6,13535,5952,13535,10080,10080,7,8859,5952,8859,1888,10080,14922,8859,10080,8859,5952,5952,14922,6986,5822,6986,9695,6080,9695,6986,6080,6986,9695,5822,9695,7754,6600,7754,5056,6080,1691,7754,6080,7754,6600,6600,1691,6080,6080,8,4552,6600,11487,6600,6600,9,6080,6080,11487,6080,6080,10,6600,6600,9951,5568,6600,11,5568,6080,9951,10208,10208,13664,1984,6080,13535,13664,6080,13664,10208,10208,13535,14922,6080,14922,2016,10208,8859,14922,10208,14922,6080,6080,8859,6986,6986,7754,8671,9695,7496,7754,9695,7754,6986,6986,7496,4922,4922,11487,6986,6986,12,6986,6986,11487,4922,4922,13,4922,4922,9951,6986,6986,14,6986,6986,9951,4922,4922,15,2858,2858,13535,2890,6986,13664,6954,6986,13535,2858,2858,13664,6986,6986,14922,1503,9695,13632,14922,9695,14922,6986,6986,13632,5690,5690,10455,7754,7754,11487,7754,7754,10455,5690,5690,11487,5690,5690,8919,7754,7754,9951,7754,7754,8919,5690,5690,9951,3626,3626,12503,3658,7754,13535,7722,7754,12503,3626,3626,13535,7754,7754,14922,3432,11624,13632,14922,11624,14922,7754,7754,13632,9951,11487,9951,2203,16,17,11487,11487,13535,14696,18,14696,13535,19,13535,11487,11487,14696,12858,3231,12858,14922,11487,14922,12858,11487,12858,14922,3231,14922,9951,9951,4763,13535,20,13535,4251,21,4763,9951,9951,13535,12858,1695,12858,14922,9951,14922,12858,9951,12858,14922,1695,14922,10794,5279,10794,10826,13535,14922,10794,13535,10794,14890,5279,14922]) (by decide +kernel)
  change ∀ b ∈ [s6562,s2602,s6563,s6564,s6565,s6566,s6567,s6568,s6569,s6570,s6571,s6572,s6573,s6574,s413,s6575,s6576,s6577,s6578,s6579,s6580,s6581], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6562) b6562 <|
    PetersenLocalChildren.push (x := s2602) b2602 <|
    PetersenLocalChildren.push (x := s6563) b6563 <|
    PetersenLocalChildren.push (x := s6564) b6564 <|
    PetersenLocalChildren.push (x := s6565) b6565 <|
    PetersenLocalChildren.push (x := s6566) b6566 <|
    PetersenLocalChildren.push (x := s6567) b6567 <|
    PetersenLocalChildren.push (x := s6568) b6568 <|
    PetersenLocalChildren.push (x := s6569) b6569 <|
    PetersenLocalChildren.push (x := s6570) b6570 <|
    PetersenLocalChildren.push (x := s6571) b6571 <|
    PetersenLocalChildren.push (x := s6572) b6572 <|
    PetersenLocalChildren.push (x := s6573) b6573 <|
    PetersenLocalChildren.push (x := s6574) b6574 <|
    PetersenLocalChildren.push (x := s413) b413 <|
    PetersenLocalChildren.push (x := s6575) b6575 <|
    PetersenLocalChildren.push (x := s6576) b6576 <|
    PetersenLocalChildren.push (x := s6577) b6577 <|
    PetersenLocalChildren.push (x := s6578) b6578 <|
    PetersenLocalChildren.push (x := s6579) b6579 <|
    PetersenLocalChildren.push (x := s6580) b6580 <|
    PetersenLocalChildren.push (x := s6581) b6581 <|
    PetersenLocalChildren.nil
theorem b6601 : Blocked tgt 8 s6601 := by
  apply PetersenFastNode.node (nxt := #[s6602,s6603,s6604,s6605,s6606,s6607,s6608]) (hints := [6843,908,6971,6843,5937,6331,5937,6065,6585,1676,7481,6585,4537,4537,6585,4779,4779,6585,5553,5553,2489,6585,4748,6585,10713,13617,8844,13617,6585,9680,908,908,9680,908,8656,1676,908,908,6971,11472,908,908,9680,9680,908,908,6971,4748,908,2843,908,908,2843,908,1488,8844,908,6969,1676,7481,1676,11472,6969,11472,11984,9936,9936,6969,5937,13520,4748,13520,4748,10065,5937,5937,10065,5937,8844,13617,8844,1676,10448,10440,1676,1676,7481,7481,1676,1676,12496,4748,1676,11609,1676,1676,11609,1676,3417,8844,1676,2700,2700,4748,0,4748,11472,1,11472,11472,2,8844,3280,8844,3216,4748,13520,4748,13520,3,4,5,6,8844,14649,8844,14649,4748,13649,4748,5328,8844,4748,10779,8844,10779,8844]) (by decide +kernel)
  change ∀ b ∈ [s6602,s6603,s6604,s6605,s6606,s6607,s6608], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6602) b6602 <|
    PetersenLocalChildren.push (x := s6603) b6603 <|
    PetersenLocalChildren.push (x := s6604) b6604 <|
    PetersenLocalChildren.push (x := s6605) b6605 <|
    PetersenLocalChildren.push (x := s6606) b6606 <|
    PetersenLocalChildren.push (x := s6607) b6607 <|
    PetersenLocalChildren.push (x := s6608) b6608 <|
    PetersenLocalChildren.nil
theorem b6612 : Blocked tgt 8 s6612 := by
  apply PetersenFastNode.node (nxt := #[s2608,s6613,s6614,s6615,s6616,s6617,s6618,s6619,s6620,s6621,s6622,s6623]) (hints := [6976,913,6976,913,5942,0,5942,10198,7486,1681,7486,10718,8670,8670,10718,11477,1,10718,9686,9686,13654,4753,13654,10718,2526,10718,8849,6590,6590,9685,913,913,9685,913,8661,1681,913,913,6976,11477,913,913,9685,9685,913,913,2880,4753,913,913,1493,8849,913,6976,913,913,6976,6974,1681,7486,1681,11477,6974,11477,11989,9941,9941,6974,5942,13525,4753,13525,4753,5942,8849,10070,8849,5942,10070,10070,5942,1681,10453,10445,1681,1681,7486,7486,1681,1681,12501,4753,1681,1681,11614,8849,1681,7486,1681,1681,7486,2705,2705,4753,14686,4753,11477,8849,3285,8849,3221,2,11477,11477,3,4753,13525,4753,13525,8849,4,8849,5,6,7,8,9,4753,5333,8849,4753,10,4753,4753,11,8849,13622]) (by decide +kernel)
  change ∀ b ∈ [s2608,s6613,s6614,s6615,s6616,s6617,s6618,s6619,s6620,s6621,s6622,s6623], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2608) b2608 <|
    PetersenLocalChildren.push (x := s6613) b6613 <|
    PetersenLocalChildren.push (x := s6614) b6614 <|
    PetersenLocalChildren.push (x := s6615) b6615 <|
    PetersenLocalChildren.push (x := s6616) b6616 <|
    PetersenLocalChildren.push (x := s6617) b6617 <|
    PetersenLocalChildren.push (x := s6618) b6618 <|
    PetersenLocalChildren.push (x := s6619) b6619 <|
    PetersenLocalChildren.push (x := s6620) b6620 <|
    PetersenLocalChildren.push (x := s6621) b6621 <|
    PetersenLocalChildren.push (x := s6622) b6622 <|
    PetersenLocalChildren.push (x := s6623) b6623 <|
    PetersenLocalChildren.nil
theorem b6627 : Blocked tgt 8 s6627 := by
  apply PetersenFastNode.node (nxt := #[s6628,s6629,s6630,s666,s6631,s6632]) (hints := [6842,779,6970,6842,5936,6842,5936,6064,6326,6584,6584,6326,6584,1547,7480,6584,4536,4536,6584,4778,4778,6584,5552,5552,13648,2488,13648,10712,13616,2520,13616,6584,5680,907,5936,907,9679,907,7480,1675,907,907,6970,11471,907,907,6970,6970,907,907,2874,4747,907,907,13616,8843,907,5936,5678,6968,1675,7480,1675,11471,6968,11471,5936,5936,6968,6968,5936,13519,4747,13519,4747,5936,8843,13616,8843,7222,1675,7222,1675,11471,0,11471,1,2,3,4,5,13519,4747,13519,4747,13358,8843,13358,8843,1675,10447,10439,1675,1675,7480,7480,1675,1675,12495,4747,1675,1675,3416,8843,1675,2699,2699,4747,14680,4747,11471,8843,3279,8843,3215,4747,13519,4747,13519,8843,14648,8843,14648,4747,5327,8843,4747]) (by decide +kernel)
  change ∀ b ∈ [s6628,s6629,s6630,s666,s6631,s6632], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6628) b6628 <|
    PetersenLocalChildren.push (x := s6629) b6629 <|
    PetersenLocalChildren.push (x := s6630) b6630 <|
    PetersenLocalChildren.push (x := s666) b666 <|
    PetersenLocalChildren.push (x := s6631) b6631 <|
    PetersenLocalChildren.push (x := s6632) b6632 <|
    PetersenLocalChildren.nil

theorem b6717 : Blocked tgt 8 s6717 := by
  apply PetersenFastNode.node (nxt := #[s6670,s6718,s6719,s675,s6698,s6720]) (hints := [6842,6328,6970,6842,5936,6330,5936,6064,6584,1547,7480,6584,4536,4536,6584,4778,4778,6584,5552,5552,13648,2488,13648,10712,2714,6584,6584,2714,13616,2520,13616,6584,5678,5680,5678,5934,1675,7224,1675,6970,11471,6970,11471,4906,4906,6970,6970,4906,2874,6970,13648,907,907,8843,13360,8843,6970,6968,1675,7480,1675,11471,6968,11471,11983,9935,9935,6968,5936,10064,1840,13648,10064,9806,5936,5936,9806,5936,8843,13616,8843,1675,10447,10439,1675,1675,7480,7480,1675,1675,3384,14680,1675,1675,7480,7480,1675,1675,3416,8843,1675,2699,2699,11471,14680,13648,11471,11471,0,1,11471,8843,3279,8843,3215,13648,14680,13648,14680,2,3,4,5,8843,14648,8843,14648,4747,4747,8843,13616,8843,13584,8843,13616,8843,13616]) (by decide +kernel)
  change ∀ b ∈ [s6670,s6718,s6719,s675,s6698,s6720], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6670) b6670 <|
    PetersenLocalChildren.push (x := s6718) b6718 <|
    PetersenLocalChildren.push (x := s6719) b6719 <|
    PetersenLocalChildren.push (x := s675) b675 <|
    PetersenLocalChildren.push (x := s6698) b6698 <|
    PetersenLocalChildren.push (x := s6720) b6720 <|
    PetersenLocalChildren.nil
theorem b6735 : Blocked tgt 8 s6735 := by
  apply PetersenFastNode.node (nxt := #[s3016,s6736,s6737,s6738,s6739,s6740,s6741,s6742,s6743,s6744,s663,s6713,s6628,s6745,s6746,s6747,s6748,s6749,s6750,s6751,s6752,s6753,s6754,s6755,s6756,s6757,s471,s6758,s6759,s6760,s6761,s6762,s6763,s6764,s6765]) (hints := [6871,6871,6999,808,6613,936,6999,6613,6999,6871,6871,936,6613,6613,6997,6359,6871,0,6997,6871,6997,6613,6613,1,6613,6613,7509,1576,2,1704,7509,3,7509,6613,6613,1704,4807,4807,4,6613,6613,2728,5581,6613,5,5581,4807,2728,4565,6,7,4565,6613,11500,6613,6613,8,11500,9,11500,13677,10741,13677,2517,6613,4776,13677,6613,13677,10741,10741,4776,13645,6613,13645,2549,10741,8872,13645,10741,13645,6613,6613,8872,9708,9708,10867,936,936,6997,936,936,10867,9708,9708,6997,936,936,1704,8684,9708,7509,1704,9708,1704,936,936,7509,936,936,2728,9708,9708,10,2728,9708,2728,936,936,11,9708,9708,11500,936,936,12,936,936,11500,9708,9708,13,936,936,4776,2903,6999,13677,4776,6999,4776,936,936,13677,936,936,8872,1516,9708,13645,8872,9708,8872,936,936,13645,6997,6997,7509,1704,14,1704,7509,15,7509,1704,6997,1704,2216,16,17,2216,6997,2728,6997,6997,18,2728,19,2728,11500,6997,11500,12012,20,21,13548,11125,13548,4776,6997,4776,13548,6997,13548,4776,11125,4776,13645,6997,13645,8872,11125,8872,13645,11125,13645,8872,6997,8872,1704,1704,2728,7509,7509,22,2728,7509,2728,1704,1704,23,10468,24,10468,1704,1704,11500,1704,1704,10468,11492,25,11500,1704,1704,4776,12524,7509,13548,4776,7509,4776,1704,1704,13548,1704,1704,8872,3445,11637,13645,8872,11637,8872,1704,1704,13645,26,27,28,2728,2728,11500,2728,2728,8,11500,18,11500,2728,2728,4776,13548,29,13548,4776,30,4776,2728,2728,13548,2728,2728,8872,14677,31,14677,8872,32,8872,2728,2728,14677,11500,11500,13548,4776,33,4776,13548,34,13548,4776,11500,4776,3244,3244,13645,8872,11500,8872,11436,11500,13645,8872,3244,8872,4776,4776,8872,5356,13548,13645,8872,13548,8872,4776,4776,13645]) (by decide +kernel)
  change ∀ b ∈ [s3016,s6736,s6737,s6738,s6739,s6740,s6741,s6742,s6743,s6744,s663,s6713,s6628,s6745,s6746,s6747,s6748,s6749,s6750,s6751,s6752,s6753,s6754,s6755,s6756,s6757,s471,s6758,s6759,s6760,s6761,s6762,s6763,s6764,s6765], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3016) b3016 <|
    PetersenLocalChildren.push (x := s6736) b6736 <|
    PetersenLocalChildren.push (x := s6737) b6737 <|
    PetersenLocalChildren.push (x := s6738) b6738 <|
    PetersenLocalChildren.push (x := s6739) b6739 <|
    PetersenLocalChildren.push (x := s6740) b6740 <|
    PetersenLocalChildren.push (x := s6741) b6741 <|
    PetersenLocalChildren.push (x := s6742) b6742 <|
    PetersenLocalChildren.push (x := s6743) b6743 <|
    PetersenLocalChildren.push (x := s6744) b6744 <|
    PetersenLocalChildren.push (x := s663) b663 <|
    PetersenLocalChildren.push (x := s6713) b6713 <|
    PetersenLocalChildren.push (x := s6628) b6628 <|
    PetersenLocalChildren.push (x := s6745) b6745 <|
    PetersenLocalChildren.push (x := s6746) b6746 <|
    PetersenLocalChildren.push (x := s6747) b6747 <|
    PetersenLocalChildren.push (x := s6748) b6748 <|
    PetersenLocalChildren.push (x := s6749) b6749 <|
    PetersenLocalChildren.push (x := s6750) b6750 <|
    PetersenLocalChildren.push (x := s6751) b6751 <|
    PetersenLocalChildren.push (x := s6752) b6752 <|
    PetersenLocalChildren.push (x := s6753) b6753 <|
    PetersenLocalChildren.push (x := s6754) b6754 <|
    PetersenLocalChildren.push (x := s6755) b6755 <|
    PetersenLocalChildren.push (x := s6756) b6756 <|
    PetersenLocalChildren.push (x := s6757) b6757 <|
    PetersenLocalChildren.push (x := s471) b471 <|
    PetersenLocalChildren.push (x := s6758) b6758 <|
    PetersenLocalChildren.push (x := s6759) b6759 <|
    PetersenLocalChildren.push (x := s6760) b6760 <|
    PetersenLocalChildren.push (x := s6761) b6761 <|
    PetersenLocalChildren.push (x := s6762) b6762 <|
    PetersenLocalChildren.push (x := s6763) b6763 <|
    PetersenLocalChildren.push (x := s6764) b6764 <|
    PetersenLocalChildren.push (x := s6765) b6765 <|
    PetersenLocalChildren.nil
theorem b6776 : Blocked tgt 8 s6776 := by
  apply PetersenFastNode.node (nxt := #[s6777,s6764,s6778,s6779,s6780,s6781,s2348,s6782,s6783,s6784,s6785]) (hints := [6847,784,6975,6847,5941,6335,5941,6069,6589,1552,7485,6589,4541,4541,6589,4783,4783,6589,5557,5557,10717,6589,6589,10717,10717,6589,6589,10717,13621,2525,13621,6589,9684,912,912,9684,912,8660,1680,912,912,6975,11476,912,912,9684,9684,912,912,2879,4752,912,9684,912,912,9684,912,1492,8848,912,6973,1680,7485,1680,11476,6973,11476,5941,5941,6973,6973,5941,1845,5941,4752,5941,10069,5941,8848,13621,8848,1680,10452,10444,1680,1680,7485,7485,1680,1680,7485,4752,1680,11613,1680,1680,11613,1680,3421,8848,1680,2704,2704,4752,0,4752,11476,11476,1,2,11476,8848,3284,8848,3220,4752,3,4752,4,5,6,7,8,8848,14653,8848,14653,4752,13524,4752,13621,8848,4752,9,8848,10,8848]) (by decide +kernel)
  change ∀ b ∈ [s6777,s6764,s6778,s6779,s6780,s6781,s2348,s6782,s6783,s6784,s6785], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6777) b6777 <|
    PetersenLocalChildren.push (x := s6764) b6764 <|
    PetersenLocalChildren.push (x := s6778) b6778 <|
    PetersenLocalChildren.push (x := s6779) b6779 <|
    PetersenLocalChildren.push (x := s6780) b6780 <|
    PetersenLocalChildren.push (x := s6781) b6781 <|
    PetersenLocalChildren.push (x := s2348) b2348 <|
    PetersenLocalChildren.push (x := s6782) b6782 <|
    PetersenLocalChildren.push (x := s6783) b6783 <|
    PetersenLocalChildren.push (x := s6784) b6784 <|
    PetersenLocalChildren.push (x := s6785) b6785 <|
    PetersenLocalChildren.nil
theorem b6789 : Blocked tgt 8 s6789 := by
  apply PetersenFastNode.node (nxt := #[s6790,s2352,s6791,s6792]) (hints := [6840,777,6968,6840,10062,6840,10062,10190,6582,1545,7478,6582,4534,4534,6582,4776,4776,6582,5550,5550,13646,2486,13646,10710,6582,10710,10710,6582,6582,10710,10710,6582,9677,905,905,9677,905,8653,1673,905,905,6968,11469,905,905,9677,9677,905,905,2872,4745,905,905,9677,8841,905,1421,905,905,1421,7478,1673,7478,1673,11469,11094,11469,11981,9933,9933,11094,10062,13517,4745,13517,4745,1870,10062,8841,5934,5934,1673,10445,10437,1673,1673,7478,7478,1673,1673,12493,4745,1673,1673,11606,8841,1673,7478,1673,1673,7478,2697,2697,4745,14678,4745,11469,8841,11469,8841,3213,3213,11469,11469,3213,4745,13517,4745,13517,8841,14904,8841,14904,0,1,2,3,4745,13517,8841,4745,5261,4745,4745,5261,8841,13614]) (by decide +kernel)
  change ∀ b ∈ [s6790,s2352,s6791,s6792], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6790) b6790 <|
    PetersenLocalChildren.push (x := s2352) b2352 <|
    PetersenLocalChildren.push (x := s6791) b6791 <|
    PetersenLocalChildren.push (x := s6792) b6792 <|
    PetersenLocalChildren.nil

theorem b6862 : Blocked tgt 8 s6862 := by
  apply PetersenFastNode.node (nxt := #[s2620,s6580,s6863,s6864,s6865,s6606,s6866,s6867,s6868,s6869,s675,s6870,s6871,s6760,s6872,s6779,s6873,s6874,s2348,s6875,s6876,s6877,s4600,s6878,s6879,s572,s6880,s6881,s6882,s6883,s6884,s6885,s6886,s6887]) (hints := [6870,6870,6998,807,5580,935,6998,5580,6998,6870,6870,935,5580,5580,5964,6358,6870,0,5964,6870,5964,5580,5580,1,6612,6612,7508,4556,5580,1703,7508,5580,7508,6612,6612,1703,5580,5580,7500,4564,6612,11499,7500,6612,7500,5580,5580,11499,1484,10740,14708,1484,5580,13547,5580,5580,14708,10740,10740,13547,2,3,4,5580,5580,5,5580,5580,6,9708,7,8,5580,5580,13644,2548,10740,8871,13644,10740,13644,5580,5580,8871,9707,9707,5706,935,935,5964,935,935,5706,9707,9707,5964,935,935,1703,8683,9707,7508,1703,9707,1703,935,935,7508,935,935,11499,4950,6998,7500,11499,6998,11499,935,935,7500,935,935,13547,2902,6998,14708,13547,6998,13547,935,935,14708,935,935,9,9707,9707,10,9707,9707,11,935,935,12,935,935,8871,1515,9707,13644,8871,9707,8871,935,935,13644,6996,6996,7508,1703,5964,1703,7508,5964,7508,1703,6996,1703,11499,5964,11499,4948,6996,13,11499,6996,11499,12011,5964,14,13547,10092,13547,5964,5964,15,13547,5964,13547,14059,10092,16,9963,10092,17,9963,5964,18,5964,5964,19,10092,10092,20,5964,5964,13644,8871,10092,8871,13644,10092,13644,8871,5964,8871,1703,1703,10467,10475,7508,11499,10467,7508,10467,1703,1703,11499,1703,1703,12515,12523,7508,13547,12515,7508,12515,1703,1703,13547,1703,1703,21,7508,7508,22,7508,7508,23,1703,1703,24,1703,1703,8871,3444,11636,13644,8871,11636,8871,1703,1703,13644,11499,11499,13547,3404,7500,14708,13547,7500,13547,11499,11499,14708,2727,11499,25,2727,26,27,8871,3243,8871,3307,11499,14676,8871,11499,8871,3243,3243,14676,4775,13547,25,4775,28,29,8871,5291,8871,5355,13547,13644,8871,13547,8871,5291,5291,13644,8871,30,8871,13644,31,13644,8871,32,8871,13644,33,13644]) (by decide +kernel)
  change ∀ b ∈ [s2620,s6580,s6863,s6864,s6865,s6606,s6866,s6867,s6868,s6869,s675,s6870,s6871,s6760,s6872,s6779,s6873,s6874,s2348,s6875,s6876,s6877,s4600,s6878,s6879,s572,s6880,s6881,s6882,s6883,s6884,s6885,s6886,s6887], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2620) b2620 <|
    PetersenLocalChildren.push (x := s6580) b6580 <|
    PetersenLocalChildren.push (x := s6863) b6863 <|
    PetersenLocalChildren.push (x := s6864) b6864 <|
    PetersenLocalChildren.push (x := s6865) b6865 <|
    PetersenLocalChildren.push (x := s6606) b6606 <|
    PetersenLocalChildren.push (x := s6866) b6866 <|
    PetersenLocalChildren.push (x := s6867) b6867 <|
    PetersenLocalChildren.push (x := s6868) b6868 <|
    PetersenLocalChildren.push (x := s6869) b6869 <|
    PetersenLocalChildren.push (x := s675) b675 <|
    PetersenLocalChildren.push (x := s6870) b6870 <|
    PetersenLocalChildren.push (x := s6871) b6871 <|
    PetersenLocalChildren.push (x := s6760) b6760 <|
    PetersenLocalChildren.push (x := s6872) b6872 <|
    PetersenLocalChildren.push (x := s6779) b6779 <|
    PetersenLocalChildren.push (x := s6873) b6873 <|
    PetersenLocalChildren.push (x := s6874) b6874 <|
    PetersenLocalChildren.push (x := s2348) b2348 <|
    PetersenLocalChildren.push (x := s6875) b6875 <|
    PetersenLocalChildren.push (x := s6876) b6876 <|
    PetersenLocalChildren.push (x := s6877) b6877 <|
    PetersenLocalChildren.push (x := s4600) b4600 <|
    PetersenLocalChildren.push (x := s6878) b6878 <|
    PetersenLocalChildren.push (x := s6879) b6879 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s6880) b6880 <|
    PetersenLocalChildren.push (x := s6881) b6881 <|
    PetersenLocalChildren.push (x := s6882) b6882 <|
    PetersenLocalChildren.push (x := s6883) b6883 <|
    PetersenLocalChildren.push (x := s6884) b6884 <|
    PetersenLocalChildren.push (x := s6885) b6885 <|
    PetersenLocalChildren.push (x := s6886) b6886 <|
    PetersenLocalChildren.push (x := s6887) b6887 <|
    PetersenLocalChildren.nil
theorem b6889 : Blocked tgt 8 s6889 := by
  apply PetersenFastNode.node (nxt := #[s6890,s6891,s6607,s6892,s6893,s6894,s6698,s6895,s6896,s6897,s6782,s6900,s6901,s6902,s6903,s6904,s6905,s6906,s6907,s6908,s572,s6909,s6882,s6910,s6911,s6912,s6913,s2621,s6581,s6761,s6914,s6915,s6916]) (hints := [5579,0,5579,10739,1,10739,5579,2,5579,9707,3,10739,934,4,934,9706,5,9706,934,6,934,9706,7,9706,9962,8,5963,9962,9,11123,5963,10,5963,11123,11,11123,1702,12,1702,11635,13,11635,1702,14,1702,11635,15,11635,7499,16,7499,11498,17,11498,2726,18,7499,2726,19,11498,4774,20,4774,13546,21,22,8870,23,8870,10805,24,10805,8870,25,8870,10805,26,10805,2741,2741,2869,9706,10739,9706,2869,10739,2869,2741,2741,9706,10739,10739,11123,2229,2741,27,11123,2741,11123,10739,10739,28,10739,10739,11635,4555,5579,1702,11635,5579,11635,10739,10739,1702,8691,5579,7499,8691,10739,11498,10739,10739,7499,11498,5579,11498,10739,10739,13675,5579,5579,4774,13675,5579,13675,10739,10739,4774,2483,2483,10805,2547,10739,8870,10675,10739,10805,2483,2483,8870,9706,9706,10865,10867,2869,11123,10865,2869,10865,9706,9706,11123,8674,8674,3637,8682,9706,11635,9698,9706,3637,8674,8674,11635,9706,9706,11498,2869,2869,7499,11498,2869,11498,9706,9706,7499,9706,9706,4774,6997,6997,13675,4774,6997,4774,9706,9706,13675,1450,1450,10805,1514,9706,13643,9642,9706,10805,1450,1450,13643,11123,11123,11635,3125,5963,3637,11635,5963,11635,11123,11123,3637,11498,5963,11498,11123,11123,29,11498,11123,11498,12010,5963,30,11123,11123,13675,4262,5963,4774,13675,5963,13675,11123,11123,4774,2867,2867,13643,2931,11123,10805,11059,11123,13643,2867,2867,10805,10466,1702,10466,10474,11635,11498,10466,11635,10466,11490,1702,11498,11635,11635,4774,7507,7507,13675,4774,7507,4774,11635,11635,13675,3379,3379,10805,3443,11635,13643,11571,11635,10805,3379,3379,13643,11498,11498,4774,7499,7499,31,4774,7499,4774,11498,11498,32,3242,3242,8870,3306,11498,10805,11434,11498,8870,3242,3242,10805,10805,4774,10805,13643,13675,13643,10805,13675,10805,4774,4774,13643]) (by decide +kernel)
  change ∀ b ∈ [s6890,s6891,s6607,s6892,s6893,s6894,s6698,s6895,s6896,s6897,s6782,s6900,s6901,s6902,s6903,s6904,s6905,s6906,s6907,s6908,s572,s6909,s6882,s6910,s6911,s6912,s6913,s2621,s6581,s6761,s6914,s6915,s6916], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6890) b6890 <|
    PetersenLocalChildren.push (x := s6891) b6891 <|
    PetersenLocalChildren.push (x := s6607) b6607 <|
    PetersenLocalChildren.push (x := s6892) b6892 <|
    PetersenLocalChildren.push (x := s6893) b6893 <|
    PetersenLocalChildren.push (x := s6894) b6894 <|
    PetersenLocalChildren.push (x := s6698) b6698 <|
    PetersenLocalChildren.push (x := s6895) b6895 <|
    PetersenLocalChildren.push (x := s6896) b6896 <|
    PetersenLocalChildren.push (x := s6897) b6897 <|
    PetersenLocalChildren.push (x := s6782) b6782 <|
    PetersenLocalChildren.push (x := s6900) b6900 <|
    PetersenLocalChildren.push (x := s6901) b6901 <|
    PetersenLocalChildren.push (x := s6902) b6902 <|
    PetersenLocalChildren.push (x := s6903) b6903 <|
    PetersenLocalChildren.push (x := s6904) b6904 <|
    PetersenLocalChildren.push (x := s6905) b6905 <|
    PetersenLocalChildren.push (x := s6906) b6906 <|
    PetersenLocalChildren.push (x := s6907) b6907 <|
    PetersenLocalChildren.push (x := s6908) b6908 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s6909) b6909 <|
    PetersenLocalChildren.push (x := s6882) b6882 <|
    PetersenLocalChildren.push (x := s6910) b6910 <|
    PetersenLocalChildren.push (x := s6911) b6911 <|
    PetersenLocalChildren.push (x := s6912) b6912 <|
    PetersenLocalChildren.push (x := s6913) b6913 <|
    PetersenLocalChildren.push (x := s2621) b2621 <|
    PetersenLocalChildren.push (x := s6581) b6581 <|
    PetersenLocalChildren.push (x := s6761) b6761 <|
    PetersenLocalChildren.push (x := s6914) b6914 <|
    PetersenLocalChildren.push (x := s6915) b6915 <|
    PetersenLocalChildren.push (x := s6916) b6916 <|
    PetersenLocalChildren.nil
theorem b6950 : Blocked tgt 8 s6950 := by
  apply PetersenFastNode.node (nxt := #[s6951,s6952,s6620,s6953,s6954,s6955,s6702,s6956,s6957,s6958,s6791,s6959,s6960,s6961,s6962,s6963,s6964,s6965,s6966,s6967,s6968,s6969,s6912,s6970,s572,s6971,s6947,s6763,s6972,s6847,s6973,s6974,s6975]) (hints := [9707,0,9707,6611,1,6611,5579,2,9707,5579,3,6611,934,4,934,1450,5,1450,934,6,934,1450,7,1450,9962,8,9962,1706,9,6995,9962,10,9962,6995,11,6995,1702,12,1702,7507,13,7507,1702,14,1702,7507,15,7507,11498,16,11498,3242,17,3242,2726,18,11498,2726,19,3242,4774,20,4774,5290,21,5290,4774,22,4774,5290,23,5290,8870,24,8870,14675,25,26,6869,6869,6997,1450,6611,1450,6997,6611,6997,6869,6869,1450,6611,6611,6995,6357,6869,9962,6995,6869,6995,6611,6611,9962,6611,6611,7507,8683,9707,1702,7507,9707,7507,6611,6611,1702,4563,9707,11627,4563,6611,3242,6611,6611,11627,3242,9707,3242,2483,2483,13675,2515,6611,5290,6579,6611,13675,2483,2483,5290,6611,6611,13643,9707,9707,8870,13643,9707,13643,6611,6611,8870,1450,1450,9962,6995,6997,6995,6993,6997,9962,1450,1450,6995,418,418,7765,426,1450,7507,1442,1450,7765,418,418,7507,1450,1450,3242,6997,6997,11627,3242,6997,3242,1450,1450,11627,1450,1450,5290,2901,6997,13675,5290,6997,5290,1450,1450,13675,1450,1450,8870,9706,9706,13643,8870,9706,8870,1450,1450,13643,6995,6995,7507,7253,9962,7765,7507,9962,7507,6995,6995,7765,3242,9962,3242,6995,6995,27,3242,6995,3242,3754,9962,28,5290,2867,5290,2899,6995,4774,5290,6995,5290,2867,2867,4774,6995,6995,13643,1770,9962,8870,9962,9962,13643,6995,6995,8870,2210,1702,2210,2218,7507,3242,2210,7507,2210,3234,1702,3242,4258,3379,4258,4266,7507,5290,4258,7507,4258,5282,3379,5290,7507,7507,8870,11635,11635,13643,8870,11635,8870,7507,7507,13643,3242,3242,5290,12659,29,14707,5290,30,5290,3242,3242,14707,3242,3242,8870,11498,11498,31,8870,11498,8870,3242,3242,32,5290,5290,8870,13546,13546,13643,8870,13546,8870,5290,5290,13643]) (by decide +kernel)
  change ∀ b ∈ [s6951,s6952,s6620,s6953,s6954,s6955,s6702,s6956,s6957,s6958,s6791,s6959,s6960,s6961,s6962,s6963,s6964,s6965,s6966,s6967,s6968,s6969,s6912,s6970,s572,s6971,s6947,s6763,s6972,s6847,s6973,s6974,s6975], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6951) b6951 <|
    PetersenLocalChildren.push (x := s6952) b6952 <|
    PetersenLocalChildren.push (x := s6620) b6620 <|
    PetersenLocalChildren.push (x := s6953) b6953 <|
    PetersenLocalChildren.push (x := s6954) b6954 <|
    PetersenLocalChildren.push (x := s6955) b6955 <|
    PetersenLocalChildren.push (x := s6702) b6702 <|
    PetersenLocalChildren.push (x := s6956) b6956 <|
    PetersenLocalChildren.push (x := s6957) b6957 <|
    PetersenLocalChildren.push (x := s6958) b6958 <|
    PetersenLocalChildren.push (x := s6791) b6791 <|
    PetersenLocalChildren.push (x := s6959) b6959 <|
    PetersenLocalChildren.push (x := s6960) b6960 <|
    PetersenLocalChildren.push (x := s6961) b6961 <|
    PetersenLocalChildren.push (x := s6962) b6962 <|
    PetersenLocalChildren.push (x := s6963) b6963 <|
    PetersenLocalChildren.push (x := s6964) b6964 <|
    PetersenLocalChildren.push (x := s6965) b6965 <|
    PetersenLocalChildren.push (x := s6966) b6966 <|
    PetersenLocalChildren.push (x := s6967) b6967 <|
    PetersenLocalChildren.push (x := s6968) b6968 <|
    PetersenLocalChildren.push (x := s6969) b6969 <|
    PetersenLocalChildren.push (x := s6912) b6912 <|
    PetersenLocalChildren.push (x := s6970) b6970 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s6971) b6971 <|
    PetersenLocalChildren.push (x := s6947) b6947 <|
    PetersenLocalChildren.push (x := s6763) b6763 <|
    PetersenLocalChildren.push (x := s6972) b6972 <|
    PetersenLocalChildren.push (x := s6847) b6847 <|
    PetersenLocalChildren.push (x := s6973) b6973 <|
    PetersenLocalChildren.push (x := s6974) b6974 <|
    PetersenLocalChildren.push (x := s6975) b6975 <|
    PetersenLocalChildren.nil

theorem b6998 : Blocked tgt 8 s6998 := by
  apply PetersenFastNode.node (nxt := #[s6999,s7000,s7001,s7002,s7003,s7004,s6909,s7005,s7006]) (hints := [6845,782,6973,6845,5939,6333,5939,6067,6587,1550,7483,6587,4539,4539,6587,4781,4781,6587,5555,5555,2491,2491,6587,2717,2717,6587,6587,10715,13619,8718,13619,6587,9682,910,910,9682,910,8658,1678,910,910,6973,11474,910,910,9682,9682,910,910,6973,13522,910,910,9682,9682,910,910,1490,8846,910,6971,1678,7483,1678,11474,6971,11474,5939,5939,6971,6971,5939,13522,5939,13522,10067,10067,5939,5939,10067,5939,8846,13619,8846,1678,10450,10442,1678,1678,7483,7483,1678,1678,12498,12490,1678,1678,7483,7483,1678,1678,3419,8846,1678,2702,2702,11474,0,13522,11474,1,11474,11474,2,8846,3282,8846,3218,3,13522,4,13522,5,6,7,8,8846,14651,8846,14651,4750,4750,8846,5330,8846,5266,8846,13619,8846,13619]) (by decide +kernel)
  change ∀ b ∈ [s6999,s7000,s7001,s7002,s7003,s7004,s6909,s7005,s7006], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s6999) b6999 <|
    PetersenLocalChildren.push (x := s7000) b7000 <|
    PetersenLocalChildren.push (x := s7001) b7001 <|
    PetersenLocalChildren.push (x := s7002) b7002 <|
    PetersenLocalChildren.push (x := s7003) b7003 <|
    PetersenLocalChildren.push (x := s7004) b7004 <|
    PetersenLocalChildren.push (x := s6909) b6909 <|
    PetersenLocalChildren.push (x := s7005) b7005 <|
    PetersenLocalChildren.push (x := s7006) b7006 <|
    PetersenLocalChildren.nil
theorem b7149 : Blocked tgt 8 s7149 := by
  apply PetersenFastNode.node (nxt := #[s7150,s7151,s7152,s5488,s7153,s5490,s7154,s7155,s572,s7156,s690,s7157,s7158,s7159,s7160,s7161,s7162,s5500,s7163,s7164,s391,s7165,s7166,s7167,s7168,s691,s705,s673,s6694,s7169,s7170,s7171,s7172,s7173,s7174,s7175,s7176]) (hints := [5327,6873,0,5327,5583,9710,5583,5583,1,9710,6873,9710,6873,6873,2,5583,5583,3,5583,5583,4,6873,6873,5,5583,5583,5967,6361,6873,6,5967,6873,5967,5583,5583,7,6615,6615,7511,4559,5583,1706,7511,5583,7511,6615,6615,1706,5583,5583,7503,4567,6615,2730,7503,6615,7503,5583,5583,2730,9711,9711,13679,1487,5583,13550,13679,5583,13679,9711,9711,13550,5583,5583,13647,1519,9711,8874,13647,9711,13647,5583,5583,8874,938,9710,8,938,9,10,9710,9710,5709,5967,11,5967,10222,12,5709,9710,9710,5967,8678,8678,1706,8686,9710,7511,9702,9710,1706,8678,8678,7511,9710,9710,2730,7503,13,7503,11758,14,2730,9710,9710,7503,9710,9710,13550,13679,15,13679,13550,16,13550,9710,9710,13679,1454,1454,8874,1518,9710,13647,9646,9710,8874,1454,1454,13647,9966,17,5709,9966,18,5967,5709,19,5709,5967,20,5967,1706,21,1706,7511,22,7511,1706,23,1706,7511,24,7511,2730,25,2730,11502,26,7503,2730,27,2730,7503,28,7503,4778,29,4778,13550,30,13550,4778,31,4778,13550,32,13550,8874,33,8874,13647,34,13647,8874,35,8874,13647,36,13647,6999,6999,7511,1706,5967,1706,7511,5967,7511,1706,6999,1706,2218,5967,7503,2218,6999,2730,7503,6999,7503,2730,5967,2730,13550,10095,13550,4778,5967,4778,13550,5967,13550,4778,10095,4778,5967,5967,13647,8874,10095,8874,13647,10095,13647,8874,5967,8874,1706,1706,2730,7503,7511,7503,2730,7511,2730,1706,1706,7503,12518,1706,12518,12526,7511,13550,12518,7511,12518,13542,1706,13550,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,13550,2730,13550,3407,7503,14711,13550,7503,13550,2730,2730,14711,2730,2730,8874,3439,11631,14679,8874,11631,8874,2730,2730,14679,5294,5294,8874,5358,13550,13647,13486,13550,8874,5294,5294,13647]) (by decide +kernel)
  change ∀ b ∈ [s7150,s7151,s7152,s5488,s7153,s5490,s7154,s7155,s572,s7156,s690,s7157,s7158,s7159,s7160,s7161,s7162,s5500,s7163,s7164,s391,s7165,s7166,s7167,s7168,s691,s705,s673,s6694,s7169,s7170,s7171,s7172,s7173,s7174,s7175,s7176], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s7150) b7150 <|
    PetersenLocalChildren.push (x := s7151) b7151 <|
    PetersenLocalChildren.push (x := s7152) b7152 <|
    PetersenLocalChildren.push (x := s5488) b5488 <|
    PetersenLocalChildren.push (x := s7153) b7153 <|
    PetersenLocalChildren.push (x := s5490) b5490 <|
    PetersenLocalChildren.push (x := s7154) b7154 <|
    PetersenLocalChildren.push (x := s7155) b7155 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s7156) b7156 <|
    PetersenLocalChildren.push (x := s690) b690 <|
    PetersenLocalChildren.push (x := s7157) b7157 <|
    PetersenLocalChildren.push (x := s7158) b7158 <|
    PetersenLocalChildren.push (x := s7159) b7159 <|
    PetersenLocalChildren.push (x := s7160) b7160 <|
    PetersenLocalChildren.push (x := s7161) b7161 <|
    PetersenLocalChildren.push (x := s7162) b7162 <|
    PetersenLocalChildren.push (x := s5500) b5500 <|
    PetersenLocalChildren.push (x := s7163) b7163 <|
    PetersenLocalChildren.push (x := s7164) b7164 <|
    PetersenLocalChildren.push (x := s391) b391 <|
    PetersenLocalChildren.push (x := s7165) b7165 <|
    PetersenLocalChildren.push (x := s7166) b7166 <|
    PetersenLocalChildren.push (x := s7167) b7167 <|
    PetersenLocalChildren.push (x := s7168) b7168 <|
    PetersenLocalChildren.push (x := s691) b691 <|
    PetersenLocalChildren.push (x := s705) b705 <|
    PetersenLocalChildren.push (x := s673) b673 <|
    PetersenLocalChildren.push (x := s6694) b6694 <|
    PetersenLocalChildren.push (x := s7169) b7169 <|
    PetersenLocalChildren.push (x := s7170) b7170 <|
    PetersenLocalChildren.push (x := s7171) b7171 <|
    PetersenLocalChildren.push (x := s7172) b7172 <|
    PetersenLocalChildren.push (x := s7173) b7173 <|
    PetersenLocalChildren.push (x := s7174) b7174 <|
    PetersenLocalChildren.push (x := s7175) b7175 <|
    PetersenLocalChildren.push (x := s7176) b7176 <|
    PetersenLocalChildren.nil
theorem b7315 : Blocked tgt 8 s7315 := by
  apply PetersenFastNode.node (nxt := #[s7316,s7317,s7318,s7319,s7320,s1384,s7321,s1386,s7322,s7323,s7324,s7170,s7325,s7326,s7327,s7328,s1397,s7208,s1399,s7329,s7330,s7331,s7332,s7333,s7334,s7335,s6908,s6909,s6905,s6881,s572,s7336,s6907,s7337,s7338,s7339,s7340]) (hints := [6873,6873,7001,810,5583,938,7001,5583,7001,6873,6873,938,5583,5583,5967,6361,6873,0,5967,6873,5967,5583,5583,1,6615,6615,7511,4559,5583,1706,7511,5583,7511,6615,6615,1706,5583,5583,7503,4567,6615,2730,7503,6615,7503,5583,5583,2730,1487,10743,2,1487,5583,13550,5583,5583,3,10743,10743,13550,10743,10743,4,5583,5583,5,5583,5583,6,9711,10743,7,5583,5583,13647,2551,10743,8874,13647,10743,13647,5583,5583,8874,9710,9710,5709,938,938,5967,938,938,5709,9710,9710,5967,938,938,1706,8686,9710,7511,1706,9710,1706,938,938,7511,938,938,2730,4953,7001,7503,2730,7001,2730,938,938,7503,938,938,13550,7001,7001,8,13550,7001,13550,938,938,9,938,938,10,9710,9710,11,9710,9710,12,938,938,13,938,938,8874,1518,9710,13647,8874,9710,8874,938,938,13647,6999,6999,7511,1706,5967,1706,7511,5967,7511,1706,6999,1706,2218,5967,7503,2218,6999,2730,7503,6999,7503,2730,5967,2730,13550,10095,13550,5967,5967,14,13550,5967,13550,14062,10095,15,9966,10095,16,9966,5967,17,5967,5967,18,10095,10095,19,5967,5967,13647,8874,10095,8874,13647,10095,13647,8874,5967,8874,1706,1706,2730,7503,7511,7503,2730,7511,2730,1706,1706,7503,1706,1706,12518,12526,7511,13550,12518,7511,12518,1706,1706,13550,1706,1706,20,7511,7511,21,7511,7511,22,1706,1706,23,1706,1706,8874,3447,11639,13647,8874,11639,8874,1706,1706,13647,2730,2730,13550,7503,7503,24,13550,7503,13550,2730,2730,25,2730,2730,26,11502,7503,27,7503,7503,28,2730,2730,29,2730,2730,8874,3439,11631,14679,8874,11631,8874,2730,2730,14679,4778,13550,30,4778,31,32,8874,5294,8874,5358,13550,13647,8874,13550,8874,5294,5294,13647,8874,33,8874,13647,34,13647,8874,35,8874,13647,36,13647]) (by decide +kernel)
  change ∀ b ∈ [s7316,s7317,s7318,s7319,s7320,s1384,s7321,s1386,s7322,s7323,s7324,s7170,s7325,s7326,s7327,s7328,s1397,s7208,s1399,s7329,s7330,s7331,s7332,s7333,s7334,s7335,s6908,s6909,s6905,s6881,s572,s7336,s6907,s7337,s7338,s7339,s7340], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s7316) b7316 <|
    PetersenLocalChildren.push (x := s7317) b7317 <|
    PetersenLocalChildren.push (x := s7318) b7318 <|
    PetersenLocalChildren.push (x := s7319) b7319 <|
    PetersenLocalChildren.push (x := s7320) b7320 <|
    PetersenLocalChildren.push (x := s1384) b1384 <|
    PetersenLocalChildren.push (x := s7321) b7321 <|
    PetersenLocalChildren.push (x := s1386) b1386 <|
    PetersenLocalChildren.push (x := s7322) b7322 <|
    PetersenLocalChildren.push (x := s7323) b7323 <|
    PetersenLocalChildren.push (x := s7324) b7324 <|
    PetersenLocalChildren.push (x := s7170) b7170 <|
    PetersenLocalChildren.push (x := s7325) b7325 <|
    PetersenLocalChildren.push (x := s7326) b7326 <|
    PetersenLocalChildren.push (x := s7327) b7327 <|
    PetersenLocalChildren.push (x := s7328) b7328 <|
    PetersenLocalChildren.push (x := s1397) b1397 <|
    PetersenLocalChildren.push (x := s7208) b7208 <|
    PetersenLocalChildren.push (x := s1399) b1399 <|
    PetersenLocalChildren.push (x := s7329) b7329 <|
    PetersenLocalChildren.push (x := s7330) b7330 <|
    PetersenLocalChildren.push (x := s7331) b7331 <|
    PetersenLocalChildren.push (x := s7332) b7332 <|
    PetersenLocalChildren.push (x := s7333) b7333 <|
    PetersenLocalChildren.push (x := s7334) b7334 <|
    PetersenLocalChildren.push (x := s7335) b7335 <|
    PetersenLocalChildren.push (x := s6908) b6908 <|
    PetersenLocalChildren.push (x := s6909) b6909 <|
    PetersenLocalChildren.push (x := s6905) b6905 <|
    PetersenLocalChildren.push (x := s6881) b6881 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s7336) b7336 <|
    PetersenLocalChildren.push (x := s6907) b6907 <|
    PetersenLocalChildren.push (x := s7337) b7337 <|
    PetersenLocalChildren.push (x := s7338) b7338 <|
    PetersenLocalChildren.push (x := s7339) b7339 <|
    PetersenLocalChildren.push (x := s7340) b7340 <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i0 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7349,s7350,s7351,s7352]) (hints := [6840,6840,6968,0,777,1486,905,1,6968,1486,6968,2,6840,6840,905,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7349,s7350,s7351,s7352], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7349) (b7349) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7350) (b7350) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7351) (b7351) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7352) (b7352) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i1 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7353,s7354,s7355,s7356]) (hints := [5934,1486,5934,0,9741,6840,9869,1,5934,6840,5934,2,6062,1486,9869,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7353,s7354,s7355,s7356], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7353) (b7353) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7354) (b7354) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7355) (b7355) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7356) (b7356) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i2 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7357,s7358,s7359,s7360]) (hints := [6582,6582,7478,0,462,1486,1673,1,7478,1486,7478,2,6582,6582,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7357,s7358,s7359,s7360], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7357) (b7357) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7358) (b7358) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7359) (b7359) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7360) (b7360) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i3 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7361,s7362,s7363,s7364]) (hints := [7470,1486,7470,0,6582,6582,2697,1,7470,6582,7470,2,7598,1486,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7361,s7362,s7363,s7364], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7361) (b7361) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7362) (b7362) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7363) (b7363) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7364) (b7364) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i4 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7365,s7366,s7367,s7368]) (hints := [1486,1486,13646,0,2486,6582,4745,1,5582,6582,13646,2,1486,1486,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7365,s7366,s7367,s7368], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7365) (b7365) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7366) (b7366) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7367) (b7367) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7368) (b7368) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i5 : PetersenLocalChildren.PairOK tgt 7 s7348 (word3,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7369,s7370,s7371,s7372]) (hints := [13614,6582,13614,0,1486,1486,8841,1,5550,1486,13614,2,5550,6582,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7369,s7370,s7371,s7372], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7369) (b7369) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7370) (b7370) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7371) (b7371) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7372) (b7372) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i6 : PetersenLocalChildren.PairOK tgt 7 s7348 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7373,s7374,s7375,s7376]) (hints := [1421,1421,9869,0,905,905,5934,1,9869,905,9869,2,1421,1421,5934,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7373,s7374,s7375,s7376], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7373) (b7373) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7374) (b7374) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7375) (b7375) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7376) (b7376) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i7 : PetersenLocalChildren.PairOK tgt 7 s7348 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7377,s7378,s7379,s7380]) (hints := [905,905,1673,0,397,1421,7478,1,1673,1421,1673,2,905,905,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7377,s7378,s7379,s7380], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7377) (b7377) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7378) (b7378) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7379) (b7379) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7380) (b7380) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i8 : PetersenLocalChildren.PairOK tgt 7 s7348 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7381,s7382,s7383,s7384]) (hints := [905,905,2697,0,4920,6968,7470,1,2697,6968,2697,2,905,905,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7381,s7382,s7383,s7384], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7381) (b7381) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7382) (b7382) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7383) (b7383) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7384) (b7384) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i9 : PetersenLocalChildren.PairOK tgt 7 s7348 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7385,s7386,s7387,s7388]) (hints := [905,905,4745,0,2872,6968,13646,1,4745,6968,4745,2,905,905,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7385,s7386,s7387,s7388], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7385) (b7385) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7386) (b7386) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7387) (b7387) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7388) (b7388) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i10 : PetersenLocalChildren.PairOK tgt 7 s7348 (word1,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7389,s7390,s7391,s7392]) (hints := [905,905,8841,0,1421,1421,13614,1,8841,1421,8841,2,905,905,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7389,s7390,s7391,s7392], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7389) (b7389) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7390) (b7390) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7391) (b7391) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7392) (b7392) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i11 : PetersenLocalChildren.PairOK tgt 7 s7348 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7393,s7394,s7395,s7396]) (hints := [8837,8837,7478,0,8845,9869,1673,1,9861,9869,7478,2,8837,8837,1673,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7393,s7394,s7395,s7396], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7393) (b7393) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7394) (b7394) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7395) (b7395) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7396) (b7396) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i12 : PetersenLocalChildren.PairOK tgt 7 s7348 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7397,s7398,s7399,s7400]) (hints := [9869,9869,11405,0,2185,6966,2697,1,11405,6966,11405,2,9869,9869,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7397,s7398,s7399,s7400], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7397) (b7397) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7398) (b7398) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7399) (b7399) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7400) (b7400) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i13 : PetersenLocalChildren.PairOK tgt 7 s7348 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7401,s7402,s7403,s7404]) (hints := [5261,9869,5261,0,4745,5934,4745,1,5261,5934,5261,2,9869,9869,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7401,s7402,s7403,s7404], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7401) (b7401) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7402) (b7402) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7403) (b7403) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7404) (b7404) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i14 : PetersenLocalChildren.PairOK tgt 7 s7348 (word0,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7405,s7406,s7407,s7408]) (hints := [1677,5934,13614,0,1677,9869,8841,1,9869,9869,13614,2,8841,5934,8841,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7405,s7406,s7407,s7408], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7405) (b7405) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7406) (b7406) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7407) (b7407) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7408) (b7408) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i15 : PetersenLocalChildren.PairOK tgt 7 s7348 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7409,s7410,s7411,s7412]) (hints := [1673,1673,2697,0,10381,7478,11405,1,2697,7478,2697,2,1673,1673,11405,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7409,s7410,s7411,s7412], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7409) (b7409) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7410) (b7410) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7411) (b7411) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7412) (b7412) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i16 : PetersenLocalChildren.PairOK tgt 7 s7348 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7413,s7414,s7415,s7416]) (hints := [1673,1673,4745,0,4237,7478,5261,1,4745,7478,4745,2,1673,1673,5261,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7413,s7414,s7415,s7416], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7413) (b7413) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7414) (b7414) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7415) (b7415) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7416) (b7416) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i17 : PetersenLocalChildren.PairOK tgt 7 s7348 (word6,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7417,s7418,s7419,s7420]) (hints := [1673,1673,8841,0,3414,11606,13614,1,8841,11606,8841,2,1673,1673,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7417,s7418,s7419,s7420], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7417) (b7417) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7418) (b7418) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7419) (b7419) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7420) (b7420) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i18 : PetersenLocalChildren.PairOK tgt 7 s7348 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7421,s7422,s7423,s7424]) (hints := [2697,2697,4745,0,3374,7470,14678,1,4745,7470,4745,2,2697,2697,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7421,s7422,s7423,s7424], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7421) (b7421) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7422) (b7422) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7423) (b7423) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7424) (b7424) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i19 : PetersenLocalChildren.PairOK tgt 7 s7348 (word5,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7425,s7426,s7427,s7428]) (hints := [2697,2697,8841,0,3213,11405,14646,1,8841,11405,8841,2,2697,2697,14646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7425,s7426,s7427,s7428], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7425) (b7425) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7426) (b7426) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7427) (b7427) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7428) (b7428) <|
    PetersenLocalChildren.nil
private theorem thetaPair7348i20 : PetersenLocalChildren.PairOK tgt 7 s7348 (word2,word207) := by
  refine PetersenLocalChildren.pair_close (bank := #[s7429,s7430,s7431,s7432]) (hints := [4745,4745,8841,0,5261,5261,13614,1,8841,5261,8841,2,4745,4745,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s7429,s7430,s7431,s7432], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7429) (b7429) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7430) (b7430) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7431) (b7431) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s7432) (b7432) <|
    PetersenLocalChildren.nil
theorem b7348 : Blocked tgt 8 s7348 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word207),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word207),(word0,word6),(word0,word5),(word0,word2),(word0,word207),(word6,word5),(word6,word2),(word6,word207),(word5,word2),(word5,word207),(word2,word207)], PetersenLocalChildren.PairOK tgt 7 s7348 p
  exact
    PetersenLocalChildren.push thetaPair7348i0 <|
    PetersenLocalChildren.push thetaPair7348i1 <|
    PetersenLocalChildren.push thetaPair7348i2 <|
    PetersenLocalChildren.push thetaPair7348i3 <|
    PetersenLocalChildren.push thetaPair7348i4 <|
    PetersenLocalChildren.push thetaPair7348i5 <|
    PetersenLocalChildren.push thetaPair7348i6 <|
    PetersenLocalChildren.push thetaPair7348i7 <|
    PetersenLocalChildren.push thetaPair7348i8 <|
    PetersenLocalChildren.push thetaPair7348i9 <|
    PetersenLocalChildren.push thetaPair7348i10 <|
    PetersenLocalChildren.push thetaPair7348i11 <|
    PetersenLocalChildren.push thetaPair7348i12 <|
    PetersenLocalChildren.push thetaPair7348i13 <|
    PetersenLocalChildren.push thetaPair7348i14 <|
    PetersenLocalChildren.push thetaPair7348i15 <|
    PetersenLocalChildren.push thetaPair7348i16 <|
    PetersenLocalChildren.push thetaPair7348i17 <|
    PetersenLocalChildren.push thetaPair7348i18 <|
    PetersenLocalChildren.push thetaPair7348i19 <|
    PetersenLocalChildren.push thetaPair7348i20 <|
    PetersenLocalChildren.nil
theorem b7433 : Blocked tgt 8 s7433 := by
  apply PetersenFastNode.node (nxt := #[s7434,s7370,s7435,s7372,s7436,s1510,s7437,s1512,s7438,s7439,s7440,s7441,s7442,s7174,s7443,s7444,s7405,s7445,s7407,s7446,s1517,s7212,s1519,s7447,s7448,s7449,s7450,s7451,s7452,s7453,s7454,s7455,s7425,s7456,s7427,s7457,s6967,s6971,s6964,s6943,s7458,s7459,s7460,s7461,s7462,s7338,s7463,s7464,s7465,s572,s7466,s6966]) (hints := [6888,6888,7016,825,9726,953,7016,9726,7016,6888,6888,953,5982,9726,5982,9853,6888,9981,5982,6888,5982,6110,9726,9981,6630,6630,7526,8702,9726,1721,7526,9726,7526,6630,6630,1721,7518,9726,7518,6630,6630,2745,7518,6630,7518,7646,9726,2745,9726,9726,13694,2534,6630,4793,13694,6630,13694,9726,9726,4793,1534,6630,0,1534,9726,1,9726,9726,2,6630,6630,3,6630,6630,4,9726,9726,5,5598,9726,6,5598,6630,7,9725,9725,9981,953,953,5982,9981,953,9981,9725,9725,5982,953,953,1721,8701,9725,7526,1721,9725,1721,953,953,7526,953,953,2745,4968,7016,7518,2745,7016,2745,953,953,7518,953,953,4793,2920,7016,13694,4793,7016,4793,953,953,13694,953,953,8,1533,9725,9,9661,9725,10,953,953,11,953,953,12,9725,9725,13,9725,9725,14,953,953,15,8949,8949,7526,8957,9981,1721,9973,9981,7526,8949,8949,1721,9981,9981,11517,2233,7014,2745,11517,7014,11517,9981,9981,2745,9981,9981,13565,4793,5982,4793,13565,5982,13565,9981,9981,4793,5982,5982,16,9981,9981,17,9917,9981,18,9917,5982,19,1725,5982,20,9981,9981,21,9981,9981,22,5982,5982,23,1721,1721,2745,10493,7526,11517,2745,7526,2745,1721,1721,11517,1721,1721,4793,12541,7526,13565,4793,7526,4793,1721,1721,13565,1721,1721,24,11654,11654,25,11654,11654,26,1721,1721,27,1721,1721,28,11654,11654,29,11654,11654,30,1721,1721,31,2745,2745,4793,3422,7518,14726,4793,7518,4793,2745,2745,14726,2745,2745,32,11517,11517,33,11453,11517,34,2745,2745,35,2745,2745,36,11517,11517,37,11517,11517,38,2745,2745,39,4793,4793,40,5373,13565,41,13501,13565,42,4793,4793,43,4793,4793,44,13565,13565,45,13565,13565,46,4793,4793,47,8889,48,49,8889,50,51]) (by decide +kernel)
  change ∀ b ∈ [s7434,s7370,s7435,s7372,s7436,s1510,s7437,s1512,s7438,s7439,s7440,s7441,s7442,s7174,s7443,s7444,s7405,s7445,s7407,s7446,s1517,s7212,s1519,s7447,s7448,s7449,s7450,s7451,s7452,s7453,s7454,s7455,s7425,s7456,s7427,s7457,s6967,s6971,s6964,s6943,s7458,s7459,s7460,s7461,s7462,s7338,s7463,s7464,s7465,s572,s7466,s6966], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s7434) b7434 <|
    PetersenLocalChildren.push (x := s7370) b7370 <|
    PetersenLocalChildren.push (x := s7435) b7435 <|
    PetersenLocalChildren.push (x := s7372) b7372 <|
    PetersenLocalChildren.push (x := s7436) b7436 <|
    PetersenLocalChildren.push (x := s1510) b1510 <|
    PetersenLocalChildren.push (x := s7437) b7437 <|
    PetersenLocalChildren.push (x := s1512) b1512 <|
    PetersenLocalChildren.push (x := s7438) b7438 <|
    PetersenLocalChildren.push (x := s7439) b7439 <|
    PetersenLocalChildren.push (x := s7440) b7440 <|
    PetersenLocalChildren.push (x := s7441) b7441 <|
    PetersenLocalChildren.push (x := s7442) b7442 <|
    PetersenLocalChildren.push (x := s7174) b7174 <|
    PetersenLocalChildren.push (x := s7443) b7443 <|
    PetersenLocalChildren.push (x := s7444) b7444 <|
    PetersenLocalChildren.push (x := s7405) b7405 <|
    PetersenLocalChildren.push (x := s7445) b7445 <|
    PetersenLocalChildren.push (x := s7407) b7407 <|
    PetersenLocalChildren.push (x := s7446) b7446 <|
    PetersenLocalChildren.push (x := s1517) b1517 <|
    PetersenLocalChildren.push (x := s7212) b7212 <|
    PetersenLocalChildren.push (x := s1519) b1519 <|
    PetersenLocalChildren.push (x := s7447) b7447 <|
    PetersenLocalChildren.push (x := s7448) b7448 <|
    PetersenLocalChildren.push (x := s7449) b7449 <|
    PetersenLocalChildren.push (x := s7450) b7450 <|
    PetersenLocalChildren.push (x := s7451) b7451 <|
    PetersenLocalChildren.push (x := s7452) b7452 <|
    PetersenLocalChildren.push (x := s7453) b7453 <|
    PetersenLocalChildren.push (x := s7454) b7454 <|
    PetersenLocalChildren.push (x := s7455) b7455 <|
    PetersenLocalChildren.push (x := s7425) b7425 <|
    PetersenLocalChildren.push (x := s7456) b7456 <|
    PetersenLocalChildren.push (x := s7427) b7427 <|
    PetersenLocalChildren.push (x := s7457) b7457 <|
    PetersenLocalChildren.push (x := s6967) b6967 <|
    PetersenLocalChildren.push (x := s6971) b6971 <|
    PetersenLocalChildren.push (x := s6964) b6964 <|
    PetersenLocalChildren.push (x := s6943) b6943 <|
    PetersenLocalChildren.push (x := s7458) b7458 <|
    PetersenLocalChildren.push (x := s7459) b7459 <|
    PetersenLocalChildren.push (x := s7460) b7460 <|
    PetersenLocalChildren.push (x := s7461) b7461 <|
    PetersenLocalChildren.push (x := s7462) b7462 <|
    PetersenLocalChildren.push (x := s7338) b7338 <|
    PetersenLocalChildren.push (x := s7463) b7463 <|
    PetersenLocalChildren.push (x := s7464) b7464 <|
    PetersenLocalChildren.push (x := s7465) b7465 <|
    PetersenLocalChildren.push (x := s572) b572 <|
    PetersenLocalChildren.push (x := s7466) b7466 <|
    PetersenLocalChildren.push (x := s6966) b6966 <|
    PetersenLocalChildren.nil
theorem b7517 : Blocked tgt 8 s7517 := by
  apply PetersenFastNode.node (nxt := #[s7518,s1635,s7261,s7519,s7439,s7520,s7521,s7174,s7522,s7523]) (hints := [5556,5556,0,9683,1,9683,9939,9939,1679,2,1679,3,2703,11475,4751,13523,4751,13523,13620,4,13620,5,6,7,8,9,6846,9683,6588,9683,5940,6334,5940,6068,6588,1551,7484,6588,7476,6588,7476,7604,13652,13523,13652,13523,13620,2524,13620,6588,6846,6588,6588,6846,9683,5940,5682,9683,8651,8659,9675,8651,9683,7476,2703,9683,9683,13396,13523,9683,1491,9683,13620,9683,1427,6972,1679,7484,1679,2191,2191,7476,2703,13523,4751,13523,4751,5940,1876,13620,5940,5682,5940,5940,5682,1679,7476,2703,1679,12491,12499,12491,13515,1679,3420,14652,1679,1679,7484,7484,1679,13523,3380,13523,2703,2703,3412,13620,2703,2703,7476,7476,2703,5267,13523,13523,5267,5267,13523,13523,5267,8847,8847]) (by decide +kernel)
  change ∀ b ∈ [s7518,s1635,s7261,s7519,s7439,s7520,s7521,s7174,s7522,s7523], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s7518) b7518 <|
    PetersenLocalChildren.push (x := s1635) b1635 <|
    PetersenLocalChildren.push (x := s7261) b7261 <|
    PetersenLocalChildren.push (x := s7519) b7519 <|
    PetersenLocalChildren.push (x := s7439) b7439 <|
    PetersenLocalChildren.push (x := s7520) b7520 <|
    PetersenLocalChildren.push (x := s7521) b7521 <|
    PetersenLocalChildren.push (x := s7174) b7174 <|
    PetersenLocalChildren.push (x := s7522) b7522 <|
    PetersenLocalChildren.push (x := s7523) b7523 <|
    PetersenLocalChildren.nil
theorem b10671 : Blocked tgt 8 s10671 := by
  let fw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,1,66,3,68,69,70,71,32,33,34,35,36,37,38,39,96,33,98,35,100,101,102,103,16,17,18,19,20,21,22,23,80,17,82,19,84,85,86,87,48,49,50,51,52,53,54,55,112,49,114,51,116,117,118,119,8,9,10,11,12,13,14,15,72,9,74,11,76,77,78,79,40,41,42,43,44,45,46,47,104,41,106,43,108,109,110,111,24,25,26,27,28,29,30,31,88,25,90,27,92,93,94,95,56,57,58,59,60,61,62,63,120,57,122,59,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  let bw (i : Fin 128) : Fin 128 := (#[0,1,2,3,4,5,6,7,64,65,66,67,68,69,70,71,32,33,34,35,36,37,38,39,96,97,98,99,100,101,102,103,16,17,18,19,20,21,22,23,80,81,82,83,84,85,86,87,48,49,50,51,52,53,54,55,112,113,114,115,116,117,118,119,8,1,10,3,12,13,14,15,72,65,74,67,76,77,78,79,40,33,42,35,44,45,46,47,104,97,106,99,108,109,110,111,24,17,26,19,28,29,30,31,88,81,90,83,92,93,94,95,56,49,58,51,60,61,62,63,120,113,122,115,124,125,126,127] : Array (Fin 128))[i.val]?.getD 0
  apply PetersenResidualFast.verified fw bw [(0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa),(0xcccccccccccccccccccccccccccccccc,0xcccccccccccccccccccccccccccccccc),(0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0),(0xf5f5f5f5f5f5f5f50000000000000000,0xf500f500f500f500f500f500f500f500),(0xff00ff00ff00ff00ff00ff00ff00ff00,0xffffffffffffffff0000000000000000),(0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000),(0xffffccccffffccccffffccccffffcccc,0xffffffffccccccccffffffffcccccccc),(0xffffffff00000000ffffffff00000000,0xffff0000ffff0000ffff0000ffff0000)] (hw:=by decide) (hu:=by decide) (by decide) (by decide +kernel)
    (V:=s5921) (by decide +kernel) (by decide +kernel) (v:=tgt) (by decide +kernel)
  exact b5921
end PetersenSmallStarts.M191.Staged
