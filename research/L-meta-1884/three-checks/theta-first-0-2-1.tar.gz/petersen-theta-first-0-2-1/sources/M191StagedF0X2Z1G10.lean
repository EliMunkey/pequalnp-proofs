import higher.WireProjection
import M191Values1
import M191Values10
import M191Values11
import M191Values13
import M191Values14
import M191Values17
import M191Values2
import M191Values32
import M191Values5
import M191Values735
import M191Values737
import M191Values738
import M191Values739
import M191Values740
import M191Values749
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows14
import M191StartPreferredRows15
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b3358 : Blocked tgt 7 s3358 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3358 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4109 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3359 : Blocked tgt 7 s3359 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3359 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4109 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3360 : Blocked tgt 7 s3360 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3360 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3361 : Blocked tgt 7 s3361 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3361 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xaaaaaaaa,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7095 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3362 : Blocked tgt 7 s3362 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3362 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_3705 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3365 : Blocked tgt 7 s3365 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3365 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7095 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3366 : Blocked tgt 7 s3366 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3366 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3367 : Blocked tgt 7 s3367 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3367 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3359 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3368 : Blocked tgt 7 s3368 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3368 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4641 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3369 : Blocked tgt 7 s3369 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3369 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1579 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3370 : Blocked tgt 7 s3370 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3370 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_3392 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3371 : Blocked tgt 7 s3371 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3371 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5335 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b3372 : Blocked tgt 7 s3372 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3372 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2938 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)

theorem b3373 : Blocked tgt 7 s3373 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3373 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff0aaa0aff0aaa0aff0aaa0aff0aaa0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3374 : Blocked tgt 7 s3374 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3374 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1617 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3375 : Blocked tgt 7 s3375 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3375 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf500a000f500a000f500a000f500a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3376 : Blocked tgt 7 s3376 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3376 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3377 : Blocked tgt 7 s3377 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3377 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_7095 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b3378 : Blocked tgt 7 s3378 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3378 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1294 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_7095 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3379 : Blocked tgt 7 s3379 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3379 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7025 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3380 : Blocked tgt 7 s3380 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3380 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7971 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b3381 : Blocked tgt 7 s3381 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3381 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1316 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3382 : Blocked tgt 7 s3382 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3382 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1631 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3383 : Blocked tgt 7 s3383 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3383 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7067 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3384 : Blocked tgt 7 s3384 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3384 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8352 rfl)))))))) (by decide +kernel)
theorem b3385 : Blocked tgt 7 s3385 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s3385 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_603 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6308 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl)))))))) (by decide +kernel)
theorem b3386 : Blocked tgt 7 s3386 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3386 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1646 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3391 : Blocked tgt 7 s3391 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3391 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0xaaaaaaaa,0x0] (PetersenWireProjection.cons pv5_4159 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7688 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3392 : Blocked tgt 7 s3392 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3392 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4159 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7688 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)

theorem b3393 : Blocked tgt 7 s3393 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3393 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7688 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3394 : Blocked tgt 7 s3394 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3394 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0xaaaaaaaa,0x0] (PetersenWireProjection.cons pv5_3730 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7688 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3395 : Blocked tgt 7 s3395 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3395 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3730 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3396 : Blocked tgt 7 s3396 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3396 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_7688 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b3397 : Blocked tgt 7 s3397 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3397 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_7688 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3398 : Blocked tgt 7 s3398 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3398 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7688 (PetersenWireProjection.cons pv11_7712 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3399 : Blocked tgt 7 s3399 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3399 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_3427 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7688 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3400 : Blocked tgt 7 s3400 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3400 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4718 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3401 : Blocked tgt 7 s3401 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3401 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1007 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3402 : Blocked tgt 7 s3402 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3402 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0x33333333222222223333333322222222 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3403 : Blocked tgt 7 s3403 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3403 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0a0a0a0a0f0f0f0f0a0a0a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b3404 : Blocked tgt 7 s3404 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3404 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_2979 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3405 : Blocked tgt 7 s3405 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3405 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xff0aff0aaa0aaa0aff0aff0aaa0aaa0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3406 : Blocked tgt 7 s3406 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3406 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1017 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3407 : Blocked tgt 7 s3407 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3407 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xf500f500a000a000f500f500a000a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3408 : Blocked tgt 7 s3408 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3408 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7688 (PetersenWireProjection.cons pv14_7944 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)

theorem b3409 : Blocked tgt 7 s3409 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3409 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1925 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7688 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3410 : Blocked tgt 7 s3410 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3410 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6702 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3411 : Blocked tgt 7 s3411 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3411 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1021 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3412 : Blocked tgt 7 s3412 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3412 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons pv11_1944 (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3413 : Blocked tgt 7 s3413 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3413 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3414 : Blocked tgt 7 s3414 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3414 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_7686 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3415 : Blocked tgt 7 s3415 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3415 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xffffffffffffffffffffffffaaaaaaaa : BitVec 128) = 0x0) rfl)))))))) (by decide +kernel)
theorem b3416 : Blocked tgt 7 s3416 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s3416 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0x0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r11 (0xffffffffaaaaaaaa : BitVec 128) = 0x0) (PetersenWireProjection.cons pv11_4260 (PetersenWireProjection.cons pv11_4814 (PetersenWireProjection.cons pv11_5473 (PetersenWireProjection.cons pv11_6308 (PetersenWireProjection.cons pv11_6790 (PetersenWireProjection.cons pv11_7474 (PetersenWireProjection.cons pv11_8012 rfl)))))))) (by decide +kernel)
theorem b3417 : Blocked tgt 7 s3417 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3417 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1024 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3422 : Blocked tgt 7 s3422 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3422 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_3897 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3423 : Blocked tgt 7 s3423 := by
  intro k le c
  apply rejects_sound r740 (0x2222222222222222 :: i6) 7 tgt small740 hot740 [(true,(0,false),(3,false)),(true,(2,false),(7,false))] s3423 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffffaaaaaaaa] (PetersenWireProjection.cons pv740_3582 (PetersenWireProjection.cons pv740_4814 (PetersenWireProjection.cons pv740_5473 (PetersenWireProjection.cons pv740_6308 (PetersenWireProjection.cons pv740_6790 (PetersenWireProjection.cons pv740_7474 (PetersenWireProjection.cons pv740_8012 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r740 (0xffffffffffffffffaaaaaaaaaaaaaaaa : BitVec 128) = 0xffffffffaaaaaaaa) rfl)))))))) (by decide +kernel)
theorem b3424 : Blocked tgt 7 s3424 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3424 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3425 : Blocked tgt 7 s3425 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3425 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4089 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3426 : Blocked tgt 7 s3426 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [(true,(1,false),(4,false))] s3426 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xffff0000,0xff00ff00,0xffaaffaa] (PetersenWireProjection.cons pv737_3677 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6308 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 (PetersenWireProjection.cons pv737_8191 rfl)))))))) (by decide +kernel)
theorem b3427 : Blocked tgt 7 s3427 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3427 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1734 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3428 : Blocked tgt 7 s3428 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3428 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1073 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)

theorem b3429 : Blocked tgt 7 s3429 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3429 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_4213 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b3430 : Blocked tgt 7 s3430 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3430 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4213 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3431 : Blocked tgt 7 s3431 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3431 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8191 rfl)))))))) (by decide +kernel)
theorem b3432 : Blocked tgt 7 s3432 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3432 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0xaaaaaaaa] (PetersenWireProjection.cons pv5_3759 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 (PetersenWireProjection.cons pv5_8191 rfl)))))))) (by decide +kernel)
theorem b3433 : Blocked tgt 7 s3433 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3433 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_3759 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3438 : Blocked tgt 7 s3438 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3438 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3485 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b3439 : Blocked tgt 7 s3439 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3439 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4785 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3440 : Blocked tgt 7 s3440 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3440 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_278 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3441 : Blocked tgt 7 s3441 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3441 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3502 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b3442 : Blocked tgt 7 s3442 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3442 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0x0,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5425 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b3443 : Blocked tgt 7 s3443 := by
  intro k le c
  apply rejects_sound r749 (0xc0c0c0c0c0c0c0c :: i6) 6 tgt small749 hot749 [] s3443 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xc0c0c0c0c0c0c0c,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv749_456 (PetersenWireProjection.cons pv749_4260 (PetersenWireProjection.cons pv749_4814 (PetersenWireProjection.cons pv749_5473 (PetersenWireProjection.cons pv749_6308 (PetersenWireProjection.cons pv749_6790 (PetersenWireProjection.cons pv749_7474 (PetersenWireProjection.cons pv749_8191 rfl)))))))) (by decide +kernel)
theorem b3444 : Blocked tgt 7 s3444 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3444 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0f0f0f0f0f0f0a0a0a0a0a0a0a0a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b3445 : Blocked tgt 7 s3445 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3445 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_3016 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b3449 : Blocked tgt 7 s3449 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3449 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf500f500f500f50000000000000000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)

theorem b3450 : Blocked tgt 7 s3450 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s3450 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv13_4260 (PetersenWireProjection.cons pv13_4814 (PetersenWireProjection.cons pv13_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r13 (0xff0aff0aff0aff0aaa0aaa0aaa0aaa0a : BitVec 128) = 0x0) (PetersenWireProjection.cons pv13_6308 (PetersenWireProjection.cons pv13_6790 (PetersenWireProjection.cons pv13_7474 (PetersenWireProjection.cons pv13_8012 rfl)))))))) (by decide +kernel)
theorem b3451 : Blocked tgt 7 s3451 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3451 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_289 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3452 : Blocked tgt 7 s3452 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3452 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r17 (0xf500f500f500f500a000a000a000a0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b3453 : Blocked tgt 7 s3453 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3453 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8191 (PetersenWireProjection.cons pv14_8331 rfl)))))))) (by decide +kernel)
theorem b3454 : Blocked tgt 7 s3454 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3454 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1977 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8191 rfl)))))))) (by decide +kernel)
theorem b3455 : Blocked tgt 7 s3455 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3455 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6767 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3456 : Blocked tgt 7 s3456 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s3456 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xa0a0a0a,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_291 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6308 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b3457 : Blocked tgt 7 s3457 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s3457 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1991 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6308 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl)))))))) (by decide +kernel)
theorem b3458 : Blocked tgt 7 s3458 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3458 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 (PetersenWireProjection.cons pv17_8377 rfl)))))))) (by decide +kernel)
theorem b3459 : Blocked tgt 7 s3459 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3459 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1343 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b3460 : Blocked tgt 7 s3460 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s3460 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv739_4260 (PetersenWireProjection.cons pv739_4814 (PetersenWireProjection.cons pv739_5473 (PetersenWireProjection.cons pv739_6308 (PetersenWireProjection.cons pv739_6790 (PetersenWireProjection.cons pv739_7439 (PetersenWireProjection.cons pv739_8012 rfl))))))) (by decide +kernel)
theorem b3461 : Blocked tgt 7 s3461 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3461 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0,0x0] (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7439 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)
theorem b3462 : Blocked tgt 7 s3462 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3462 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7439 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3463 : Blocked tgt 7 s3463 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s3463 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff0aff0a,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_298 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6308 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl)))))))) (by decide +kernel)
theorem b3464 : Blocked tgt 7 s3464 := by
  intro k le c
  apply rejects_sound r738 (0xf000f000f000f0 :: i6) 6 tgt small738 hot738 [] s3464 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xf000f000f000f0,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv738_1366 (PetersenWireProjection.cons pv738_4260 (PetersenWireProjection.cons pv738_4814 (PetersenWireProjection.cons pv738_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r738 (0xff0aff0aff0aff0aff0aff0aff0aff0a : BitVec 128) = 0xaaaaaaaaaaaaaaaa) (PetersenWireProjection.cons pv738_6790 (PetersenWireProjection.cons pv738_8012 rfl))))))) (by decide +kernel)
theorem b3465 : Blocked tgt 7 s3465 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3465 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1366 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_8012 (PetersenWireProjection.cons pv17_8191 rfl)))))))) (by decide +kernel)

theorem b3466 : Blocked tgt 7 s3466 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s3466 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0x0,0x0] (PetersenWireProjection.cons pv17_1366 (PetersenWireProjection.cons pv17_4260 (PetersenWireProjection.cons pv17_4814 (PetersenWireProjection.cons pv17_5473 (PetersenWireProjection.cons pv17_6308 (PetersenWireProjection.cons pv17_6790 (PetersenWireProjection.cons pv17_7474 (PetersenWireProjection.cons pv17_8012 rfl)))))))) (by decide +kernel)
theorem b3467 : Blocked tgt 7 s3467 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3467 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_351 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3472 : Blocked tgt 7 s3472 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s3472 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_4035 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6308 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b3473 : Blocked tgt 7 s3473 := by
  intro k le c
  apply rejects_sound r735 (0xffffffffcccccccc :: i6) 6 tgt small735 hot735 [] s3473 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xffffffffcccccccc,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv735_3666 (PetersenWireProjection.cons pv735_4260 (PetersenWireProjection.cons pv735_4814 (PetersenWireProjection.cons pv735_5473 (PetersenWireProjection.cons pv735_6308 (PetersenWireProjection.cons pv735_6790 (PetersenWireProjection.cons pv735_7474 (PetersenWireProjection.cons pv735_8012 rfl)))))))) (by decide +kernel)
theorem b3474 : Blocked tgt 7 s3474 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3474 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4429 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5920 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b3475 : Blocked tgt 7 s3475 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3475 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4429 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3476 : Blocked tgt 7 s3476 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s3476 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf2f2f2f2f2f2f2f2,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2800 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5920 (PetersenWireProjection.cons pv1_6308 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b3477 : Blocked tgt 7 s3477 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [(true,(0,false),(2,false))] s3477 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xfafafafafafafafa,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_3209 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_5920 (PetersenWireProjection.cons pv9_6308 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl)))))))) (by decide +kernel)
theorem b3478 : Blocked tgt 7 s3478 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s3478 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0xcccc,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_5920 (PetersenWireProjection.cons pv32_6308 (PetersenWireProjection.cons pv32_6568 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl)))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
