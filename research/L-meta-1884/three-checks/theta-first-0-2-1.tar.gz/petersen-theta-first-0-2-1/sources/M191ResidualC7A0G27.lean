import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredRows19
import M191StartPreferredRows20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b4472 : Blocked tgt 7 s4472 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s4472 7 _ le
  decide +kernel
theorem b4491 : Blocked tgt 7 s4491 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4491 7 _ le
  decide +kernel
theorem b4492 : Blocked tgt 7 s4492 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4492 7 _ le
  decide +kernel
theorem b4493 : Blocked tgt 7 s4493 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4493 7 _ le
  decide +kernel
theorem b4494 : Blocked tgt 7 s4494 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4494 7 _ le
  decide +kernel
theorem b4495 : Blocked tgt 7 s4495 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4495 7 _ le
  decide +kernel
theorem b4496 : Blocked tgt 7 s4496 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4496 7 _ le
  decide +kernel
theorem b4497 : Blocked tgt 7 s4497 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,6836,4522,6836,901,8649,5930,9929,9921,9921,7474,7732,1669,1669,2693,10441,2693,11457,13642,12489,4741,4741,8837,14900,8837,14900,6836,773,2836,6836,4264,9801,5672,4264,6836,4264,7732,6836,4772,4788,6820,4772,13384,6836,6836,12488,6836,458,14900,6836,9929,901,9929,8641,7732,8641,7732,901,11465,788,11465,901,12489,13642,12489,901,14900,449,14900,901,7216,9929,9929,7728,9929,2693,11465,9929,9929,1576,12489,9929,1673,1737,9865,1673,5668,11465,7716,11465,3636,12489,7732,12489,7732,12328,14900,7732,11465,3112,12489,11465,3209,3273,11401,3209,4233,4297,12425,4233]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4498 : Blocked tgt 7 s4498 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4498 7 _ le
  decide +kernel
theorem b4499 : Blocked tgt 7 s4499 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4499 7 _ le
  decide +kernel
theorem b4500 : Blocked tgt 7 s4500 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4500 7 _ le
  decide +kernel
theorem b4501 : Blocked tgt 7 s4501 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4501 7 _ le
  decide +kernel
theorem b4502 : Blocked tgt 7 s4502 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4502 7 _ le
  decide +kernel

theorem b4503 : Blocked tgt 7 s4503 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4503 7 _ le
  decide +kernel
theorem b4504 : Blocked tgt 7 s4504 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4504 7 _ le
  decide +kernel
theorem b4505 : Blocked tgt 7 s4505 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4505 7 _ le
  decide +kernel
theorem b4506 : Blocked tgt 7 s4506 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4506 7 _ le
  decide +kernel
theorem b4507 : Blocked tgt 7 s4507 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4507 7 _ le
  decide +kernel
theorem b4508 : Blocked tgt 7 s4508 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4508 7 _ le
  decide +kernel
theorem b4509 : Blocked tgt 7 s4509 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4509 7 _ le
  decide +kernel
theorem b4510 : Blocked tgt 7 s4510 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4510 7 _ le
  decide +kernel
theorem b4511 : Blocked tgt 7 s4511 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4511 7 _ le
  decide +kernel
theorem b4512 : Blocked tgt 7 s4512 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4512 7 _ le
  decide +kernel
theorem b4513 : Blocked tgt 7 s4513 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4513 7 _ le
  decide +kernel
theorem b4514 : Blocked tgt 7 s4514 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4514 7 _ le
  decide +kernel
theorem b4515 : Blocked tgt 7 s4515 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4515 7 _ le
  decide +kernel
theorem b4516 : Blocked tgt 7 s4516 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4516 7 _ le
  decide +kernel
theorem b4517 : Blocked tgt 7 s4517 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4517 7 _ le
  decide +kernel
theorem b4518 : Blocked tgt 7 s4518 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4518 7 _ le
  decide +kernel

theorem b4519 : Blocked tgt 7 s4519 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4519 7 _ le
  decide +kernel
theorem b4520 : Blocked tgt 7 s4520 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4520 7 _ le
  decide +kernel
theorem b4521 : Blocked tgt 7 s4521 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4521 7 _ le
  decide +kernel
theorem b4530 : Blocked tgt 7 s4530 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4530 7 _ le
  decide +kernel
theorem b4531 : Blocked tgt 7 s4531 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4531 7 _ le
  decide +kernel
theorem b4532 : Blocked tgt 7 s4532 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4532 7 _ le
  decide +kernel
theorem b4533 : Blocked tgt 7 s4533 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4533 7 _ le
  decide +kernel
theorem b4534 : Blocked tgt 7 s4534 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4534 7 _ le
  decide +kernel
theorem b4535 : Blocked tgt 7 s4535 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4535 7 _ le
  decide +kernel
theorem b4536 : Blocked tgt 7 s4536 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true)),(true,(0,false),(3,false))] s4536 7 _ le
  decide +kernel
theorem b4537 : Blocked tgt 7 s4537 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [4522,4264,4522,5288,901,8641,5930,9921,1665,9921,7474,11344,1669,1669,2693,10433,2693,10433,4741,12481,4741,12481,13610,13352,8837,8837,5288,773,6964,5288,5288,9793,5672,5288,11344,5288,10448,10448,5288,10433,7208,5288,13377,12481,12488,12481,5288,458,12456,5288,9921,901,9921,385,11344,385,11344,901,10433,4916,10433,901,12481,2868,12481,901,13352,13610,13352,901,8897,8897,9921,10832,9921,8784,10433,9921,9921,1576,12481,9921,1673,1729,9865,1673,2693,10433,11328,10433,11344,12481,14416,12481,3152,3152,11344,13352,10433,3112,12481,10433,3209,3265,10377,3209,5257,5313,12425,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4538 : Blocked tgt 7 s4538 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4538 7 _ le
  decide +kernel
theorem b4539 : Blocked tgt 7 s4539 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4539 7 _ le
  decide +kernel
theorem b4540 : Blocked tgt 7 s4540 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4540 7 _ le
  decide +kernel
theorem b4541 : Blocked tgt 7 s4541 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4541 7 _ le
  decide +kernel
theorem b4542 : Blocked tgt 7 s4542 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s4542 7 _ le
  decide +kernel

theorem b4543 : Blocked tgt 7 s4543 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4543 7 _ le
  decide +kernel
theorem b4544 : Blocked tgt 7 s4544 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4544 7 _ le
  decide +kernel
theorem b4545 : Blocked tgt 7 s4545 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4545 7 _ le
  decide +kernel
theorem b4546 : Blocked tgt 7 s4546 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4546 7 _ le
  decide +kernel
theorem b4547 : Blocked tgt 7 s4547 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s4547 7 _ le
  decide +kernel
theorem b4548 : Blocked tgt 7 s4548 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4548 7 _ le
  decide +kernel
theorem b4549 : Blocked tgt 7 s4549 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4549 7 _ le
  decide +kernel
theorem b4550 : Blocked tgt 7 s4550 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s4550 7 _ le
  decide +kernel
theorem b4551 : Blocked tgt 7 s4551 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4551 7 _ le
  decide +kernel
theorem b4552 : Blocked tgt 7 s4552 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4552 7 _ le
  decide +kernel
theorem b4553 : Blocked tgt 7 s4553 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4553 7 _ le
  decide +kernel
theorem b4554 : Blocked tgt 7 s4554 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4554 7 _ le
  decide +kernel
theorem b4555 : Blocked tgt 7 s4555 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4555 7 _ le
  decide +kernel
theorem b4556 : Blocked tgt 7 s4556 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4556 7 _ le
  decide +kernel
theorem b4557 : Blocked tgt 7 s4557 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4557 7 _ le
  decide +kernel
theorem b4558 : Blocked tgt 7 s4558 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s4558 7 _ le
  decide +kernel

theorem b4559 : Blocked tgt 7 s4559 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4559 7 _ le
  decide +kernel
theorem b4560 : Blocked tgt 7 s4560 := by
  intro k le c
  apply rejects_sound r739 (0xa0a0a0a :: i5) 6 tgt small739 hot739 [(true,(0,false),(4,false))] s4560 7 _ le
  decide +kernel
theorem b4561 : Blocked tgt 7 s4561 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4561 7 _ le
  decide +kernel
theorem b4562 : Blocked tgt 7 s4562 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4562 7 _ le
  decide +kernel
theorem b4563 : Blocked tgt 7 s4563 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4563 7 _ le
  decide +kernel
theorem b4564 : Blocked tgt 7 s4564 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4564 7 _ le
  decide +kernel
theorem b4565 : Blocked tgt 7 s4565 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s4565 7 _ le
  decide +kernel
theorem b4582 : Blocked tgt 7 s4582 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4582 7 _ le
  decide +kernel
theorem b4583 : Blocked tgt 7 s4583 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s4583 7 _ le
  decide +kernel
theorem b4584 : Blocked tgt 7 s4584 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s4584 7 _ le
  decide +kernel
theorem b4585 : Blocked tgt 7 s4585 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4585 7 _ le
  decide +kernel
theorem b4586 : Blocked tgt 7 s4586 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s4586 7 _ le
  decide +kernel
theorem b4587 : Blocked tgt 7 s4587 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [5546,6836,5546,6836,901,9673,8897,9929,5930,9929,7474,7732,1669,1669,2693,11465,2693,11465,13642,13513,4741,4741,8837,14900,8837,14900,6836,773,2836,6836,5288,9801,5672,5288,6836,4264,7732,6836,4772,4788,6820,4772,13384,6836,6836,13512,6836,1482,14900,6836,9929,389,9929,5930,7732,7474,7732,901,11465,788,11465,901,13513,13642,13513,901,14900,13610,14900,901,7216,9929,9921,9921,9929,2693,11465,9929,9929,1576,13513,9929,1673,1737,9865,1673,10433,10441,10433,11457,12481,12489,12481,13505,7732,12328,14900,7732,11465,3112,13513,11465,3209,3273,11401,3209,5257,5321,13449,5257]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 6 b
  exact

    PetersenLocalChildren.nil
theorem b4588 : Blocked tgt 7 s4588 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4588 7 _ le
  decide +kernel
theorem b4589 : Blocked tgt 7 s4589 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s4589 7 _ le
  decide +kernel
theorem b4590 : Blocked tgt 7 s4590 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s4590 7 _ le
  decide +kernel

theorem b4591 : Blocked tgt 7 s4591 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s4591 7 _ le
  decide +kernel
theorem b4592 : Blocked tgt 7 s4592 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4592 7 _ le
  decide +kernel
theorem b4593 : Blocked tgt 7 s4593 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true)),(true,(0,false),(4,false))] s4593 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
