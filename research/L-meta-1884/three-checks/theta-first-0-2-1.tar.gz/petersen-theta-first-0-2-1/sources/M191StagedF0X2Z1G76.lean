import M191StartPreferredSignals
import M191ResidualC7A0G32
import M191ResidualC7A0G38
import M191ResidualC7A0G8
import M191ResidualC7A0G9
import M191StagedF0X2Z1G19
import M191StagedF0X2Z1G2
import M191StagedF0X2Z1G20
import M191StagedF0X2Z1G21
import M191StagedF0X2Z1G24
import M191StagedF0X2Z1G28
import M191StagedF0X2Z1G29
import M191StagedF0X2Z1G30
import M191StagedF0X2Z1G31
import M191StagedF0X2Z1G32
import M191StagedF0X2Z1G33
import M191StagedF0X2Z1G34
import M191StagedF0X2Z1G35
import M191StagedF0X2Z1G4
import M191StagedF0X2Z1G6
import M191StagedF0X2Z1G7
import M191StagedF0X2Z1G8
import M191StartPreferredRows0
import M191StartPreferredRows11
import M191StartPreferredRows12
import M191StartPreferredRows14
import M191StartPreferredRows22
import M191StartPreferredRows24
import M191StartPreferredRows26
import M191StartPreferredRows28
import M191StartPreferredRows44
import M191StartPreferredRows45
import M191StartPreferredRows48
import M191StartPreferredRows49
import M191StartPreferredRows5
import M191StartPreferredRows50
import M191StartPreferredRows51
import M191StartPreferredRows52
import M191StartPreferredRows53
import M191StartPreferredRows54
import M191StartPreferredRows55
import M191StartPreferredRows56
import M191StartPreferredRows57
import M191StartPreferredRows7
import M191StartPreferredRows9
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b10988 : Blocked tgt 8 s10988 := by
  apply PetersenFastNode.node (nxt := #[s10989,s10990,s10991,s170,s3146,s2663,s5049,s6408,s9902,s10838,s10992,s179,s10993,s10994,s10995,s10996,s190,s191,s10997,s5400,s10998,s10126]) (hints := [795,5310,795,9695,0,9695,795,1,795,5310,5310,9695,5568,5310,6858,5568,2,3,5952,5310,5952,9823,4,5,7496,6342,7496,4286,5310,6,7496,5310,7496,6342,6342,7,7488,5310,7488,11359,6342,11487,7488,6342,7488,5310,5310,11487,13664,10470,13664,13407,5310,13535,13664,5310,13664,13534,10470,13535,13632,5310,13632,2278,10470,8,13632,10470,13632,5310,5310,9,9695,9695,6858,795,795,10,6858,795,6858,9695,9695,11,9695,9695,5694,5824,795,5952,795,795,5694,9695,9695,5952,8663,8663,1691,8671,9695,7496,9687,9695,1691,8663,8663,7496,9695,9695,11487,7488,12,7488,11487,13,11487,9695,9695,7488,9695,9695,13535,13664,14,13664,13535,15,13535,9695,9695,13664,1439,1439,8859,1503,9695,13632,9631,9695,8859,1439,1439,13632,5694,16,5694,5952,6858,5952,5694,6858,5694,5952,17,5952,6858,6858,7754,7496,18,7496,7754,19,7754,7496,6858,7496,11487,4794,11487,7488,6858,7488,11487,6858,11487,7488,4794,7488,13535,2730,13535,13664,6858,13664,13535,6858,13535,13664,2730,13664,6858,6858,14922,13632,20,13632,14922,21,14922,13632,6858,13632,6984,6984,7496,4928,5952,1691,7496,5952,7496,6984,6984,1691,11487,5952,11487,4936,6984,2715,11487,6984,11487,5952,5952,2715,13535,10080,13535,1856,5952,4763,13535,5952,13535,10080,10080,4763,5952,5952,13632,1888,10080,8859,13632,10080,13632,5952,5952,8859,10455,1691,10455,10463,7496,11487,10455,7496,10455,11479,1691,11487,12503,11624,12503,12511,7496,13535,12503,7496,12503,13527,11624,13535,7496,7496,14664,3432,11624,13632,14664,11624,14664,7496,7496,13632,11487,11487,13535,3392,7488,14696,13535,7488,13535,11487,11487,14696,3231,3231,13632,3295,11487,14664,11423,11487,13632,3231,3231,14664,5279,5279,8859,5343,13535,13632,13471,13535,8859,5279,5279,13632]) (by decide +kernel)
  change ∀ b ∈ [s10989,s10990,s10991,s170,s3146,s2663,s5049,s6408,s9902,s10838,s10992,s179,s10993,s10994,s10995,s10996,s190,s191,s10997,s5400,s10998,s10126], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s10989) b10989 <|
    PetersenLocalChildren.push (x := s10990) b10990 <|
    PetersenLocalChildren.push (x := s10991) b10991 <|
    PetersenLocalChildren.push (x := s170) b170 <|
    PetersenLocalChildren.push (x := s3146) b3146 <|
    PetersenLocalChildren.push (x := s2663) b2663 <|
    PetersenLocalChildren.push (x := s5049) b5049 <|
    PetersenLocalChildren.push (x := s6408) b6408 <|
    PetersenLocalChildren.push (x := s9902) b9902 <|
    PetersenLocalChildren.push (x := s10838) b10838 <|
    PetersenLocalChildren.push (x := s10992) b10992 <|
    PetersenLocalChildren.push (x := s179) b179 <|
    PetersenLocalChildren.push (x := s10993) b10993 <|
    PetersenLocalChildren.push (x := s10994) b10994 <|
    PetersenLocalChildren.push (x := s10995) b10995 <|
    PetersenLocalChildren.push (x := s10996) b10996 <|
    PetersenLocalChildren.push (x := s190) b190 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.push (x := s10997) b10997 <|
    PetersenLocalChildren.push (x := s5400) b5400 <|
    PetersenLocalChildren.push (x := s10998) b10998 <|
    PetersenLocalChildren.push (x := s10126) b10126 <|
    PetersenLocalChildren.nil
theorem b11024 : Blocked tgt 8 s11024 := by
  apply PetersenFastNode.node (nxt := #[s11025,s10993,s11026,s2674,s5057,s6415,s11027,s11028,s11029,s11030,s9908,s10843,s11031,s11032,s11033,s11034,s11035,s11036,s11037,s11038,s11039,s11040,s11041,s11042,s11043,s11044,s11045,s11046,s11047,s11048]) (hints := [6866,5576,6866,5318,0,1,5576,5576,5960,9959,2,3,1699,6352,1699,4552,5576,4,1699,5576,1699,6352,6352,5,5576,5576,7496,4560,6352,6,7368,6352,7496,5576,5576,7,803,8,803,5320,5576,9703,803,5576,803,9703,9,9703,4771,9704,4771,1480,5576,13543,4771,5576,4771,9704,9704,13543,8867,5576,8867,1512,9704,10,8867,9704,8867,5576,5576,11,5702,12,5702,5960,6866,5960,5702,6866,5702,5960,13,5960,6866,6866,7762,1571,14,1699,7762,15,7762,6866,6866,1699,4946,4802,16,4946,6866,7496,6866,6866,17,4802,4802,7496,4802,4802,18,9703,6866,9703,6866,6866,19,9703,4802,9703,2738,2738,13414,13543,6866,13543,6834,6866,13414,13543,2738,13543,6866,6866,14930,8739,20,8867,14930,21,14930,6866,6866,8867,6864,6864,7504,4936,5960,1699,7504,5960,7504,6864,6864,1699,5960,5960,7496,4944,6864,22,7496,6864,7496,5960,5960,23,9703,5702,9703,5832,5960,803,9703,5960,9703,803,5702,803,13543,10088,13543,1864,5960,4771,13543,5960,13543,10088,10088,4771,5960,5960,13640,1896,10088,8867,13640,10088,13640,5960,5960,8867,1699,1699,24,7496,7504,7496,7488,7504,25,1699,1699,7496,8671,1699,8671,8679,7504,9703,8671,7504,8671,9695,1699,9703,12511,1699,12511,12519,7504,13543,12511,7504,12511,13535,1699,13543,1699,1699,8867,3440,11632,13640,8867,11632,8867,1699,1699,13640,9703,7496,9703,11495,26,27,13543,11624,13543,3400,7496,14704,13543,7496,13543,11624,11624,14704,8867,7496,8867,3432,11624,14672,8867,11624,8867,7496,7496,14672,9703,9703,13543,13672,28,13672,13543,29,13543,9703,9703,13672,1447,1447,8867,1511,9703,13640,9639,9703,8867,1447,1447,13640,5287,5287,8867,5351,13543,13640,13479,13543,8867,5287,5287,13640]) (by decide +kernel)
  change ∀ b ∈ [s11025,s10993,s11026,s2674,s5057,s6415,s11027,s11028,s11029,s11030,s9908,s10843,s11031,s11032,s11033,s11034,s11035,s11036,s11037,s11038,s11039,s11040,s11041,s11042,s11043,s11044,s11045,s11046,s11047,s11048], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11025) b11025 <|
    PetersenLocalChildren.push (x := s10993) b10993 <|
    PetersenLocalChildren.push (x := s11026) b11026 <|
    PetersenLocalChildren.push (x := s2674) b2674 <|
    PetersenLocalChildren.push (x := s5057) b5057 <|
    PetersenLocalChildren.push (x := s6415) b6415 <|
    PetersenLocalChildren.push (x := s11027) b11027 <|
    PetersenLocalChildren.push (x := s11028) b11028 <|
    PetersenLocalChildren.push (x := s11029) b11029 <|
    PetersenLocalChildren.push (x := s11030) b11030 <|
    PetersenLocalChildren.push (x := s9908) b9908 <|
    PetersenLocalChildren.push (x := s10843) b10843 <|
    PetersenLocalChildren.push (x := s11031) b11031 <|
    PetersenLocalChildren.push (x := s11032) b11032 <|
    PetersenLocalChildren.push (x := s11033) b11033 <|
    PetersenLocalChildren.push (x := s11034) b11034 <|
    PetersenLocalChildren.push (x := s11035) b11035 <|
    PetersenLocalChildren.push (x := s11036) b11036 <|
    PetersenLocalChildren.push (x := s11037) b11037 <|
    PetersenLocalChildren.push (x := s11038) b11038 <|
    PetersenLocalChildren.push (x := s11039) b11039 <|
    PetersenLocalChildren.push (x := s11040) b11040 <|
    PetersenLocalChildren.push (x := s11041) b11041 <|
    PetersenLocalChildren.push (x := s11042) b11042 <|
    PetersenLocalChildren.push (x := s11043) b11043 <|
    PetersenLocalChildren.push (x := s11044) b11044 <|
    PetersenLocalChildren.push (x := s11045) b11045 <|
    PetersenLocalChildren.push (x := s11046) b11046 <|
    PetersenLocalChildren.push (x := s11047) b11047 <|
    PetersenLocalChildren.push (x := s11048) b11048 <|
    PetersenLocalChildren.nil
theorem b11088 : Blocked tgt 8 s11088 := by
  apply PetersenFastNode.node (nxt := #[s11089,s11090,s3148,s11091,s191]) (hints := [778,5295,778,9678,5551,0,5551,9934,5551,1,6583,4527,7479,6583,5551,4535,7471,5551,9679,1455,13647,9679,5551,1487,13615,5551,9678,6969,9678,5807,778,9678,9678,2,8646,8654,9670,8646,9678,7471,11470,9678,9678,13647,13518,9678,1422,1486,9614,1422,3,6841,5935,6841,4,6841,7479,7737,7479,4777,11470,6825,11470,2713,13518,6809,13518,6841,13615,14905,13615,5935,5677,6967,4911,7479,6967,11470,4919,11470,5935,13518,1839,13518,10063,5935,1871,13615,5935,7221,7479,7221,7479,7213,11470,7213,11470,13389,13518,13389,13518,13357,13615,13357,13615,10438,10446,10438,11462,12486,12494,12486,13510,7479,3415,14647,7479,11470,3375,13518,11470,3214,3278,11406,3214,5262,5326,13454,5262]) (by decide +kernel)
  change ∀ b ∈ [s11089,s11090,s3148,s11091,s191], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11089) b11089 <|
    PetersenLocalChildren.push (x := s11090) b11090 <|
    PetersenLocalChildren.push (x := s3148) b3148 <|
    PetersenLocalChildren.push (x := s11091) b11091 <|
    PetersenLocalChildren.push (x := s191) b191 <|
    PetersenLocalChildren.nil
theorem b11096 : Blocked tgt 8 s11096 := by
  apply PetersenFastNode.node (nxt := #[s1731,s2680,s5063,s6421,s11097,s11098,s9914,s10851,s11099,s11100,s11033,s11101,s11063,s11102,s11103,s11104,s11105,s11106,s11107,s11108,s11109,s11110]) (hints := [795,5310,795,5312,5568,9695,795,5568,795,5310,5310,9695,5568,5568,5952,9823,0,1,6600,6600,7496,4544,5568,2,7496,5568,7496,6600,6600,3,5568,5568,6858,6342,4,5,5568,5568,7488,4552,6600,11487,7488,6600,7488,5568,5568,11487,9696,9696,13664,1472,5568,13535,13664,5568,13664,9696,9696,13535,5568,5568,13632,1504,9696,6,13632,9696,13632,5568,5568,7,9695,9695,5694,5696,795,5952,5694,795,5694,9695,9695,5952,8663,8663,1563,8671,9695,7496,9687,9695,1563,8663,8663,7496,9695,9695,6858,6986,8,9,9695,9695,11487,7232,10,7488,11487,11,11487,9695,9695,7488,9695,9695,13535,13408,12,13664,13535,13,13535,9695,9695,13664,1439,1439,8859,1503,9695,13632,9631,9695,8859,1439,1439,13632,6984,6984,7496,4928,5952,1563,7496,5952,7496,6984,6984,1563,10854,10854,14,5952,5952,6858,5952,5952,15,6854,10854,6858,11487,5952,11487,4936,6984,2715,11487,6984,11487,5952,5952,2715,13535,10080,13535,1856,5952,4763,13535,5952,13535,10080,10080,4763,5952,5952,13632,1888,10080,8859,13632,10080,13632,5952,5952,8859,7496,7496,6858,7754,16,17,10455,1563,10455,10463,7496,11487,10455,7496,10455,11479,1563,11487,12503,11624,12503,12511,7496,13535,12503,7496,12503,13527,11624,13535,7496,7496,14664,3432,11624,13632,14664,11624,14664,7496,7496,13632,4794,4794,18,11487,6858,11487,6842,6858,19,11487,4794,11487,2730,2730,14438,13535,6858,13535,6826,6858,14438,13535,2730,13535,6858,6858,14922,13632,20,13632,14922,21,14922,13632,6858,13632,11487,11487,13535,3392,7488,14696,13535,7488,13535,11487,11487,14696,3231,3231,13632,3295,11487,14664,11423,11487,13632,3231,3231,14664,5279,5279,8859,5343,13535,13632,13471,13535,8859,5279,5279,13632]) (by decide +kernel)
  change ∀ b ∈ [s1731,s2680,s5063,s6421,s11097,s11098,s9914,s10851,s11099,s11100,s11033,s11101,s11063,s11102,s11103,s11104,s11105,s11106,s11107,s11108,s11109,s11110], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1731) b1731 <|
    PetersenLocalChildren.push (x := s2680) b2680 <|
    PetersenLocalChildren.push (x := s5063) b5063 <|
    PetersenLocalChildren.push (x := s6421) b6421 <|
    PetersenLocalChildren.push (x := s11097) b11097 <|
    PetersenLocalChildren.push (x := s11098) b11098 <|
    PetersenLocalChildren.push (x := s9914) b9914 <|
    PetersenLocalChildren.push (x := s10851) b10851 <|
    PetersenLocalChildren.push (x := s11099) b11099 <|
    PetersenLocalChildren.push (x := s11100) b11100 <|
    PetersenLocalChildren.push (x := s11033) b11033 <|
    PetersenLocalChildren.push (x := s11101) b11101 <|
    PetersenLocalChildren.push (x := s11063) b11063 <|
    PetersenLocalChildren.push (x := s11102) b11102 <|
    PetersenLocalChildren.push (x := s11103) b11103 <|
    PetersenLocalChildren.push (x := s11104) b11104 <|
    PetersenLocalChildren.push (x := s11105) b11105 <|
    PetersenLocalChildren.push (x := s11106) b11106 <|
    PetersenLocalChildren.push (x := s11107) b11107 <|
    PetersenLocalChildren.push (x := s11108) b11108 <|
    PetersenLocalChildren.push (x := s11109) b11109 <|
    PetersenLocalChildren.push (x := s11110) b11110 <|
    PetersenLocalChildren.nil
theorem b11111 : Blocked tgt 8 s11111 := by
  apply PetersenFastNode.node (nxt := #[s11112,s11113,s11114,s11105,s11115,s11116]) (hints := [779,5296,779,9679,5552,5294,5552,9935,6584,4528,7480,6584,5552,0,5552,4536,7472,5552,9680,1456,13648,9680,5552,1488,13616,5552,9679,1,9679,5808,779,9679,8647,8655,9671,8647,9679,2,9679,7472,11471,9679,9679,13648,13519,9679,1423,1487,9615,1423,5678,5936,5678,5936,1547,3,7480,6842,6842,7214,11471,7214,11471,13390,13519,13390,13519,14906,13616,14906,13616,6968,4912,7480,6968,10838,5936,5936,10838,11471,4920,11471,5936,13519,1840,13519,10064,5936,1872,13616,5936,7480,7738,10439,10447,10439,11463,12487,12495,12487,13511,7480,3416,14648,7480,4,11471,5,11471,14422,13519,14422,13519,14906,13616,14906,13616,11471,3376,13519,11471,3215,3279,11407,3215,5263,5327,13455,5263]) (by decide +kernel)
  change ∀ b ∈ [s11112,s11113,s11114,s11105,s11115,s11116], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11112) b11112 <|
    PetersenLocalChildren.push (x := s11113) b11113 <|
    PetersenLocalChildren.push (x := s11114) b11114 <|
    PetersenLocalChildren.push (x := s11105) b11105 <|
    PetersenLocalChildren.push (x := s11115) b11115 <|
    PetersenLocalChildren.push (x := s11116) b11116 <|
    PetersenLocalChildren.nil
theorem b11117 : Blocked tgt 8 s11117 := by
  apply PetersenFastNode.node (nxt := #[s11118,s5400,s11119,s11120,s11121,s11122,s1142,s11105,s11123,s11124,s11125,s2681,s5399,s11126,s9915,s10852,s11127,s11128,s11034,s11129,s11064,s11130]) (hints := [5568,6858,5568,6600,0,6600,5568,1,5568,6600,6858,6600,9695,6858,9695,8663,2,8663,9695,3,9695,8663,6858,8663,5952,4,5952,6984,6858,6984,5952,6858,5952,6984,5,6984,7496,6858,7754,7496,6,7,11487,4794,11487,10455,6858,10455,11487,6858,11487,10455,4794,10455,13535,2730,13535,12503,6858,12503,13535,6858,13535,12503,2730,12503,13632,6858,13632,14664,8,14664,13632,9,13632,14664,6858,14664,795,5310,795,6344,6600,8663,795,6600,795,8663,5310,8663,6600,6600,6984,8919,10,11,6600,6600,7754,5568,5568,12,5568,5568,7754,6600,6600,13,4536,4536,2715,4552,6600,10455,6584,6600,2715,4536,4536,10455,10728,10728,14696,2504,6600,12503,14696,6600,14696,10728,10728,12503,6600,6600,14664,2536,10728,14,14664,10728,14664,6600,6600,15,8663,8663,5694,6856,795,6984,795,795,5694,8663,8663,6984,8663,8663,7754,9695,9695,16,9695,9695,7754,8663,8663,17,8663,8663,10455,7232,18,7488,10455,19,10455,8663,8663,7488,8663,8663,12503,14696,20,14696,12503,21,12503,8663,8663,14696,407,407,8859,471,8663,14664,8599,8663,8859,407,407,14664,6984,6984,7238,5952,5952,7754,5952,5952,7238,6984,6984,7754,10455,4920,10455,4936,6984,2715,10455,6984,10455,4920,4920,2715,12503,11112,12503,2888,6984,4763,12503,6984,12503,11112,11112,4763,6984,6984,14664,2920,11112,8859,14664,11112,14664,6984,6984,8859,10455,5690,10455,11487,7754,11487,10455,7754,10455,11487,5690,11487,12503,3626,12503,13535,7754,13535,12503,7754,12503,13535,3626,13535,14664,7754,14664,13632,11366,13632,14664,11366,14664,13632,7754,13632,10455,10455,12503,12648,7488,14696,12503,7488,12503,10455,10455,14696,2199,2199,12600,2263,10455,14664,10391,10455,12600,2199,2199,14664,4247,4247,8859,4311,12503,14664,12439,12503,8859,4247,4247,14664]) (by decide +kernel)
  change ∀ b ∈ [s11118,s5400,s11119,s11120,s11121,s11122,s1142,s11105,s11123,s11124,s11125,s2681,s5399,s11126,s9915,s10852,s11127,s11128,s11034,s11129,s11064,s11130], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11118) b11118 <|
    PetersenLocalChildren.push (x := s5400) b5400 <|
    PetersenLocalChildren.push (x := s11119) b11119 <|
    PetersenLocalChildren.push (x := s11120) b11120 <|
    PetersenLocalChildren.push (x := s11121) b11121 <|
    PetersenLocalChildren.push (x := s11122) b11122 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s11105) b11105 <|
    PetersenLocalChildren.push (x := s11123) b11123 <|
    PetersenLocalChildren.push (x := s11124) b11124 <|
    PetersenLocalChildren.push (x := s11125) b11125 <|
    PetersenLocalChildren.push (x := s2681) b2681 <|
    PetersenLocalChildren.push (x := s5399) b5399 <|
    PetersenLocalChildren.push (x := s11126) b11126 <|
    PetersenLocalChildren.push (x := s9915) b9915 <|
    PetersenLocalChildren.push (x := s10852) b10852 <|
    PetersenLocalChildren.push (x := s11127) b11127 <|
    PetersenLocalChildren.push (x := s11128) b11128 <|
    PetersenLocalChildren.push (x := s11034) b11034 <|
    PetersenLocalChildren.push (x := s11129) b11129 <|
    PetersenLocalChildren.push (x := s11064) b11064 <|
    PetersenLocalChildren.push (x := s11130) b11130 <|
    PetersenLocalChildren.nil
theorem b11178 : Blocked tgt 8 s11178 := by
  apply PetersenFastNode.node (nxt := #[s11179,s11180]) (hints := [775,5292,775,9675,5548,5290,5548,9931,6580,5548,5548,6580,6580,5548,5548,6580,5548,4532,7468,5548,9676,1452,13644,9676,5548,1484,13612,5548,9675,6966,9675,5804,775,9675,8643,9675,9675,8643,8643,9675,9675,8643,9675,7468,11467,9675,9675,13644,13515,9675,1419,1483,9611,1419,5674,5932,5674,5932,6838,1543,7734,6838,0,6838,6838,1,4774,11467,6822,11467,2710,13515,6806,13515,6838,13612,14902,13612,4908,5932,1671,5932,6964,11467,2695,11467,5932,13515,1836,13515,10060,5932,1868,13612,5932,7476,7476,10435,11467,10435,11467,12483,13515,12483,13515,14644,13612,14644,13612,10435,11467,10435,11467,12483,13515,12483,13515,14644,13612,14644,13612,11467,3372,13515,11467,3211,3275,11403,3211,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s11179,s11180], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11179) b11179 <|
    PetersenLocalChildren.push (x := s11180) b11180 <|
    PetersenLocalChildren.nil
theorem b11184 : Blocked tgt 8 s11184 := by
  apply PetersenFastNode.node (nxt := #[s2094,s11041,s11185,s11186,s11187,s11188]) (hints := [779,5296,779,9679,5552,5294,5552,0,6584,4528,7480,6584,5552,6584,6584,5552,5552,6584,6584,5552,9680,1456,13648,9680,5552,1488,13616,5552,9679,6970,9679,6840,779,9679,8647,8655,9671,8647,9679,1,2699,9679,9679,779,779,9679,9679,13648,13519,9679,1423,1487,9615,1423,10838,6968,6838,6968,6842,7480,7738,7480,4778,4794,6826,4778,2,6842,6842,3,2714,13519,6810,13519,6842,13616,14906,13616,6968,1675,7480,6968,4920,6968,2699,5936,5936,13519,2872,13519,11096,13616,2904,13616,6968,1675,7480,7480,1675,4,7480,7480,5,12487,12495,12487,13511,7480,3416,14648,7480,11471,11471,13519,14680,13519,14680,13616,14648,13616,14648,13519,14680,13519,14680,13616,14648,13616,14648,5263,5327,13455,5263]) (by decide +kernel)
  change ∀ b ∈ [s2094,s11041,s11185,s11186,s11187,s11188], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s2094) b2094 <|
    PetersenLocalChildren.push (x := s11041) b11041 <|
    PetersenLocalChildren.push (x := s11185) b11185 <|
    PetersenLocalChildren.push (x := s11186) b11186 <|
    PetersenLocalChildren.push (x := s11187) b11187 <|
    PetersenLocalChildren.push (x := s11188) b11188 <|
    PetersenLocalChildren.nil
theorem b11214 : Blocked tgt 8 s11214 := by
  apply PetersenFastNode.node (nxt := #[s11109,s11124]) (hints := [775,5292,775,9675,5548,5290,5548,9931,6580,5548,11604,6580,5548,4532,7468,5548,9676,1452,13644,9676,5548,1484,13612,5548,6580,5548,5548,6580,9675,6966,9675,5804,775,9675,8643,8651,9667,8643,9675,7468,11467,9675,9675,13644,13515,9675,1419,1483,9611,1419,387,9675,9675,387,5674,5932,5674,5932,6838,11604,11346,11604,4774,11467,6822,11467,2710,13515,6806,13515,6838,13612,13354,13612,6838,0,1,6838,6964,5932,11604,6964,11467,4916,11467,5932,13515,1836,13515,10060,5932,1868,13612,5932,6964,5932,5932,6964,10435,10443,10435,11459,12483,12491,12483,13507,3412,11604,13612,7476,7476,11467,3372,13515,11467,3211,3275,11403,3211,2179,11467,11467,2179,5259,5323,13451,5259,4227,13515,13515,4227,13612,14644]) (by decide +kernel)
  change ∀ b ∈ [s11109,s11124], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11109) b11109 <|
    PetersenLocalChildren.push (x := s11124) b11124 <|
    PetersenLocalChildren.nil
theorem b11218 : Blocked tgt 8 s11218 := by
  apply PetersenFastNode.node (nxt := #[s11047,s11219,s11220,s11221]) (hints := [777,5294,777,9677,5550,5292,5550,9933,6582,4526,7478,6582,5550,4534,7470,5550,9678,5550,5550,9678,9678,5550,5550,9678,5550,1486,13614,5550,9677,6968,9677,5806,777,9677,8645,8653,9669,8645,9677,7470,7212,9677,9677,14678,14420,9677,9677,0,1,9677,1421,1485,9613,1421,5676,5934,5676,5934,6840,7478,7736,7478,4776,7470,6824,7470,2712,14678,6808,14678,2,6840,6840,3,6840,13614,14904,13614,6966,4910,7478,6966,5934,4918,7470,5934,10062,5934,5934,10062,10062,5934,5934,10062,5934,1870,13614,5934,1673,7470,7462,7462,11606,3382,14678,11606,1673,7478,7478,1673,7478,3414,14646,7478,3374,7470,14678,11469,11469,7470,12598,13614,7470,13517,13517,8841,13614,14614,13614,8841,13614,8841,13614]) (by decide +kernel)
  change ∀ b ∈ [s11047,s11219,s11220,s11221], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11047) b11047 <|
    PetersenLocalChildren.push (x := s11219) b11219 <|
    PetersenLocalChildren.push (x := s11220) b11220 <|
    PetersenLocalChildren.push (x := s11221) b11221 <|
    PetersenLocalChildren.nil
theorem b11255 : Blocked tgt 8 s11255 := by
  apply PetersenFastNode.node (nxt := #[s11256,s11114,s11257,s11258,s1142,s11259,s11260]) (hints := [908,5297,908,9680,5553,5295,5553,9936,4529,4529,5553,0,5553,6585,5553,11472,7473,5553,9681,1457,13649,9681,5553,1489,13617,5553,9680,6971,9680,5809,908,9680,8648,8656,9672,8648,780,9680,9680,1,9680,7473,11472,9680,9680,13649,13520,9680,1424,1488,9616,1424,5679,5937,5679,5937,1548,1548,2,1676,3,4,6843,6843,7215,11472,7215,11472,13391,13520,13391,13520,14907,13617,14907,13617,5041,5041,5937,6969,6969,5937,5937,6969,11472,4921,11472,5937,13520,1841,13520,10065,5937,1873,13617,5937,7481,7481,10440,10448,10440,11464,12488,12496,12488,13512,14649,13617,14649,13617,5,11472,6,11472,14681,13520,14681,13520,14649,13617,14649,13617,11472,3377,13520,11472,3216,3280,11408,3216,5264,5328,13456,5264]) (by decide +kernel)
  change ∀ b ∈ [s11256,s11114,s11257,s11258,s1142,s11259,s11260], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11256) b11256 <|
    PetersenLocalChildren.push (x := s11114) b11114 <|
    PetersenLocalChildren.push (x := s11257) b11257 <|
    PetersenLocalChildren.push (x := s11258) b11258 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s11259) b11259 <|
    PetersenLocalChildren.push (x := s11260) b11260 <|
    PetersenLocalChildren.nil
theorem b11342 : Blocked tgt 8 s11342 := by
  apply PetersenFastNode.node (nxt := #[s11343,s11344,s11345,s11346,s11347,s11348,s11349,s11350,s11351,s11352,s1142,s11100,s11353,s11354,s11355,s11356,s11357,s11120,s11358,s11359,s11360,s11361,s11362,s11363,s11364,s11365,s11366,s11367]) (hints := [6992,5316,6992,5318,5574,9701,6992,5574,6992,5316,5316,9701,5574,5574,5958,9829,0,1,6606,6606,1569,5574,5574,2,5574,5574,1569,6606,6606,3,6606,6606,6864,5574,5574,4,5574,5574,6864,6606,6606,5,5574,5574,7494,4558,6606,11493,7494,6606,7494,5574,5574,11493,9702,9702,13670,1478,5574,13541,13670,5574,13670,9702,9702,13541,5574,5574,13638,1510,9702,6,13638,9702,13638,5574,5574,7,9701,9701,5700,5702,6992,5958,5700,6992,5700,9701,9701,5958,1569,6992,1569,9701,9701,8,9693,9701,1569,9693,6992,9,8669,6992,6864,9701,9701,10,9701,9701,6864,6992,6992,11,9701,9701,11493,4944,6992,7494,11493,6992,11493,9701,9701,7494,9701,9701,13541,2896,6992,13670,13541,6992,13541,9701,9701,13670,1445,1445,8865,1509,9701,13638,9637,9701,8865,1445,1445,13638,6990,6990,12,5958,5958,1569,5958,5958,13,6990,6990,1569,6990,6990,14,5958,5958,6864,5958,5958,15,6990,6990,6864,11493,5958,11493,4942,6990,2721,11493,6990,11493,5958,5958,2721,13541,10086,13541,1862,5958,4769,13541,5958,13541,10086,10086,4769,5958,5958,13638,1894,10086,8865,13638,10086,13638,5958,5958,8865,7502,1569,6864,7502,16,17,10461,1569,10461,10469,18,11493,10461,19,10461,11485,1569,11493,12509,1569,12509,12517,20,13541,12509,21,12509,13533,1569,13541,14670,1569,14670,13638,22,13638,14670,23,14670,13638,1569,13638,4800,4800,24,11493,6864,11493,6848,6864,25,11493,4800,11493,14702,2736,14702,13541,6864,13541,14702,6864,14702,13541,2736,13541,14670,6864,14670,13638,26,13638,14670,27,14670,13638,6864,13638,11493,11493,13541,3398,7494,14702,13541,7494,13541,11493,11493,14702,3237,3237,13638,3301,11493,14670,11429,11493,13638,3237,3237,14670,5285,5285,8865,5349,13541,13638,13477,13541,8865,5285,5285,13638]) (by decide +kernel)
  change ∀ b ∈ [s11343,s11344,s11345,s11346,s11347,s11348,s11349,s11350,s11351,s11352,s1142,s11100,s11353,s11354,s11355,s11356,s11357,s11120,s11358,s11359,s11360,s11361,s11362,s11363,s11364,s11365,s11366,s11367], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11343) b11343 <|
    PetersenLocalChildren.push (x := s11344) b11344 <|
    PetersenLocalChildren.push (x := s11345) b11345 <|
    PetersenLocalChildren.push (x := s11346) b11346 <|
    PetersenLocalChildren.push (x := s11347) b11347 <|
    PetersenLocalChildren.push (x := s11348) b11348 <|
    PetersenLocalChildren.push (x := s11349) b11349 <|
    PetersenLocalChildren.push (x := s11350) b11350 <|
    PetersenLocalChildren.push (x := s11351) b11351 <|
    PetersenLocalChildren.push (x := s11352) b11352 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s11100) b11100 <|
    PetersenLocalChildren.push (x := s11353) b11353 <|
    PetersenLocalChildren.push (x := s11354) b11354 <|
    PetersenLocalChildren.push (x := s11355) b11355 <|
    PetersenLocalChildren.push (x := s11356) b11356 <|
    PetersenLocalChildren.push (x := s11357) b11357 <|
    PetersenLocalChildren.push (x := s11120) b11120 <|
    PetersenLocalChildren.push (x := s11358) b11358 <|
    PetersenLocalChildren.push (x := s11359) b11359 <|
    PetersenLocalChildren.push (x := s11360) b11360 <|
    PetersenLocalChildren.push (x := s11361) b11361 <|
    PetersenLocalChildren.push (x := s11362) b11362 <|
    PetersenLocalChildren.push (x := s11363) b11363 <|
    PetersenLocalChildren.push (x := s11364) b11364 <|
    PetersenLocalChildren.push (x := s11365) b11365 <|
    PetersenLocalChildren.push (x := s11366) b11366 <|
    PetersenLocalChildren.push (x := s11367) b11367 <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i0 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11528,s11529,s11530,s11531]) (hints := [6840,6840,905,0,6968,5550,6968,1,777,5550,905,2,6840,6840,6968,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11528,s11529,s11530,s11531], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11528) (b11528) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11529) (b11529) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11530) (b11530) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11531) (b11531) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i1 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11532,s11533,s11534,s11535]) (hints := [5550,5550,6062,0,9805,6840,9805,1,5934,6840,6062,2,5550,5550,9805,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11532,s11533,s11534,s11535], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11532) (b11532) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11533) (b11533) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11534) (b11534) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11535) (b11535) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i2 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11536,s11537,s11538,s11539]) (hints := [6582,6582,7478,0,4526,5550,7736,1,7478,5550,7478,2,6582,6582,7736,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11536,s11537,s11538,s11539], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11536) (b11536) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11537) (b11537) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11538) (b11538) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11539) (b11539) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i3 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11540,s11541,s11542,s11543]) (hints := [5550,5550,7470,0,4534,6582,11469,1,7470,6582,7470,2,5550,5550,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11540,s11541,s11542,s11543], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11540) (b11540) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11541) (b11541) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11542) (b11542) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11543) (b11543) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i4 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11544,s11545,s11546,s11547]) (hints := [9678,9678,13646,0,1454,5550,13517,1,13646,5550,13646,2,9678,9678,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11544,s11545,s11546,s11547], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11544) (b11544) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11545) (b11545) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11546) (b11546) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11547) (b11547) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i5 : PetersenLocalChildren.PairOK tgt 7 s11527 (word58,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11548,s11549,s11550,s11551]) (hints := [5550,5550,13614,0,1486,9678,14904,1,13614,9678,13614,2,5550,5550,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11548,s11549,s11550,s11551], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11548) (b11548) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11549) (b11549) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11550) (b11550) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11551) (b11551) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i6 : PetersenLocalChildren.PairOK tgt 7 s11527 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11552,s11553,s11554,s11555]) (hints := [9677,9677,9805,0,6584,6968,6062,1,9805,6968,9805,2,9677,9677,6062,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11552,s11553,s11554,s11555], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11552) (b11552) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11553) (b11553) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11554) (b11554) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11555) (b11555) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i7 : PetersenLocalChildren.PairOK tgt 7 s11527 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11556,s11557,s11558,s11559]) (hints := [6968,6968,7736,0,8653,9677,7478,1,7736,9677,7736,2,6968,6968,7478,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11556,s11557,s11558,s11559], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11556) (b11556) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11557) (b11557) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11558) (b11558) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11559) (b11559) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i8 : PetersenLocalChildren.PairOK tgt 7 s11527 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11560,s11561,s11562,s11563]) (hints := [4904,4904,11469,0,4920,6968,7470,1,6952,6968,11469,2,4904,4904,7470,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11560,s11561,s11562,s11563], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11560) (b11560) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11561) (b11561) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11562) (b11562) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11563) (b11563) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i9 : PetersenLocalChildren.PairOK tgt 7 s11527 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11564,s11565,s11566,s11567]) (hints := [2840,2840,13517,0,2872,6968,13646,1,6936,6968,13517,2,2840,2840,13646,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11564,s11565,s11566,s11567], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11564) (b11564) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11565) (b11565) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11566) (b11566) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11567) (b11567) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i10 : PetersenLocalChildren.PairOK tgt 7 s11527 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11568,s11569,s11570,s11571]) (hints := [6968,6968,14904,0,1485,9677,13614,1,14904,9677,14904,2,6968,6968,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11568,s11569,s11570,s11571], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11568) (b11568) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11569) (b11569) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11570) (b11570) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11571) (b11571) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i11 : PetersenLocalChildren.PairOK tgt 7 s11527 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11572,s11573,s11574,s11575]) (hints := [6328,6328,7478,0,7352,9805,7736,1,9797,9805,7478,2,6328,6328,7736,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11572,s11573,s11574,s11575], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11572) (b11572) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11573) (b11573) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11574) (b11574) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11575) (b11575) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i12 : PetersenLocalChildren.PairOK tgt 7 s11527 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11576,s11577,s11578,s11579]) (hints := [9805,9805,11469,0,6312,6328,2697,1,11469,6328,11469,2,9805,9805,2697,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11576,s11577,s11578,s11579], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11576) (b11576) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11577) (b11577) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11578) (b11578) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11579) (b11579) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i13 : PetersenLocalChildren.PairOK tgt 7 s11527 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11580,s11581,s11582,s11583]) (hints := [9805,9805,13517,0,6296,6328,4745,1,13517,6328,13517,2,9805,9805,4745,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11580,s11581,s11582,s11583], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11580) (b11580) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11581) (b11581) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11582) (b11582) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11583) (b11583) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i14 : PetersenLocalChildren.PairOK tgt 7 s11527 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11584,s11585,s11586,s11587]) (hints := [1549,1549,13614,0,1613,9805,14904,1,9741,9805,13614,2,1549,1549,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11584,s11585,s11586,s11587], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11584) (b11584) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11585) (b11585) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11586) (b11586) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11587) (b11587) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i15 : PetersenLocalChildren.PairOK tgt 7 s11527 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11588,s11589,s11590,s11591]) (hints := [5672,5672,10437,0,5688,7736,11469,1,7720,7736,10437,2,5672,5672,11469,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11588,s11589,s11590,s11591], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11588) (b11588) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11589) (b11589) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11590) (b11590) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11591) (b11591) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i16 : PetersenLocalChildren.PairOK tgt 7 s11527 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11592,s11593,s11594,s11595]) (hints := [3608,3608,12485,0,3640,7736,13517,1,7704,7736,12485,2,3608,3608,13517,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11592,s11593,s11594,s11595], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11592) (b11592) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11593) (b11593) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11594) (b11594) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11595) (b11595) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i17 : PetersenLocalChildren.PairOK tgt 7 s11527 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11596,s11597,s11598,s11599]) (hints := [7736,7736,14904,0,3414,11606,13614,1,14904,11606,14904,2,7736,7736,13614,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11596,s11597,s11598,s11599], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11596) (b11596) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11597) (b11597) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11598) (b11598) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11599) (b11599) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i18 : PetersenLocalChildren.PairOK tgt 7 s11527 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11600,s11601,s11602,s11603]) (hints := [11469,11469,13517,0,3374,7470,14678,1,13517,7470,13517,2,11469,11469,14678,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11600,s11601,s11602,s11603], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11600) (b11600) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11601) (b11601) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11602) (b11602) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11603) (b11603) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i19 : PetersenLocalChildren.PairOK tgt 7 s11527 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11604,s11605,s11606,s11607]) (hints := [12840,3213,12840,0,12856,11469,14904,1,12840,11469,12840,2,14888,3213,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11604,s11605,s11606,s11607], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11604) (b11604) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11605) (b11605) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11606) (b11606) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11607) (b11607) <|
    PetersenLocalChildren.nil
private theorem thetaPair11527i20 : PetersenLocalChildren.PairOK tgt 7 s11527 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11608,s11609,s11610,s11611]) (hints := [10776,5261,10776,0,10808,13517,14904,1,10776,13517,10776,2,14872,5261,14904,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s11608,s11609,s11610,s11611], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11608) (b11608) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11609) (b11609) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11610) (b11610) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11611) (b11611) <|
    PetersenLocalChildren.nil
theorem b11527 : Blocked tgt 8 s11527 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word58,word1),(word58,word0),(word58,word6),(word58,word5),(word58,word2),(word58,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 7 s11527 p
  exact
    PetersenLocalChildren.push thetaPair11527i0 <|
    PetersenLocalChildren.push thetaPair11527i1 <|
    PetersenLocalChildren.push thetaPair11527i2 <|
    PetersenLocalChildren.push thetaPair11527i3 <|
    PetersenLocalChildren.push thetaPair11527i4 <|
    PetersenLocalChildren.push thetaPair11527i5 <|
    PetersenLocalChildren.push thetaPair11527i6 <|
    PetersenLocalChildren.push thetaPair11527i7 <|
    PetersenLocalChildren.push thetaPair11527i8 <|
    PetersenLocalChildren.push thetaPair11527i9 <|
    PetersenLocalChildren.push thetaPair11527i10 <|
    PetersenLocalChildren.push thetaPair11527i11 <|
    PetersenLocalChildren.push thetaPair11527i12 <|
    PetersenLocalChildren.push thetaPair11527i13 <|
    PetersenLocalChildren.push thetaPair11527i14 <|
    PetersenLocalChildren.push thetaPair11527i15 <|
    PetersenLocalChildren.push thetaPair11527i16 <|
    PetersenLocalChildren.push thetaPair11527i17 <|
    PetersenLocalChildren.push thetaPair11527i18 <|
    PetersenLocalChildren.push thetaPair11527i19 <|
    PetersenLocalChildren.push thetaPair11527i20 <|
    PetersenLocalChildren.nil
theorem b11613 : Blocked tgt 8 s11613 := by
  apply PetersenFastNode.node (nxt := #[s11614,s11532,s2693,s11615,s11616,s11617,s11618,s11533,s2690,s11619,s5072,s11620,s5074,s11621,s11622,s11623,s11624,s11625,s11626,s11627,s11628,s11629,s11630,s11631,s11632,s11633,s9923,s11634,s9925,s11635,s11636,s11637,s11638,s11639,s11640,s11641,s11642,s11643,s11644,s11645,s11646]) (hints := [5587,0,6877,5587,1,2,7005,3,7005,9714,4,9714,7005,5,7005,9714,6,9714,9842,0,6099,9842,7,8,7773,9,7773,10,11,12,7773,13,7773,14,15,16,7507,17,7507,11506,18,11506,7507,19,7507,11506,20,11506,13683,21,13683,13554,22,13554,13683,23,13683,13554,24,13554,14941,25,14941,26,27,28,14941,29,14941,30,31,32,6877,6877,942,9714,33,9714,814,34,942,9714,6877,9714,6099,2,6099,6877,6877,8,5971,35,36,7515,6877,7515,7773,37,7773,7515,38,7515,6877,6877,7773,7507,4813,7507,11506,6877,11506,7507,6877,7507,11506,4813,11506,13683,2749,13683,13554,6877,13554,13683,6877,13683,13554,2749,13554,13651,6877,13651,14941,39,14941,13651,40,13651,6877,6877,14941,9714,9714,5841,7005,7005,6099,7005,7005,5841,9714,9714,6099,8682,8682,7773,8690,9714,7515,9706,9714,7773,8682,8682,7515,9714,9714,11506,4957,7005,7507,11506,7005,11506,9714,9714,7507,9714,9714,13554,2909,7005,13683,13554,7005,13554,9714,9714,13683,1458,1458,14941,1522,9714,13651,9650,9714,14941,1458,1458,13651,7131,7131,7515,7773,6099,7773,7515,6099,7515,7773,7131,7773,11506,6099,11506,5083,7131,2734,11506,7131,11506,6099,6099,2734,13554,10227,13554,2003,6099,4782,13554,6099,13554,10227,10227,4782,6099,6099,13651,14941,10227,14941,13651,10227,13651,14941,6099,14941,10474,5709,10474,10482,7773,11506,10474,7773,10474,11498,5709,11506,12522,3645,12522,12530,7773,13554,12522,7773,12522,13546,3645,13554,7773,7773,14941,3451,11643,13651,14941,11643,14941,7773,7773,13651,11506,11506,13554,3411,7507,14715,13554,7507,13554,11506,11506,14715,3250,3250,12877,3314,11506,14941,11442,11506,12877,3250,3250,14941,5298,5298,10813,5362,13554,14941,13490,13554,10813,5298,5298,14941]) (by decide +kernel)
  change ∀ b ∈ [s11614,s11532,s2693,s11615,s11616,s11617,s11618,s11533,s2690,s11619,s5072,s11620,s5074,s11621,s11622,s11623,s11624,s11625,s11626,s11627,s11628,s11629,s11630,s11631,s11632,s11633,s9923,s11634,s9925,s11635,s11636,s11637,s11638,s11639,s11640,s11641,s11642,s11643,s11644,s11645,s11646], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11614) b11614 <|
    PetersenLocalChildren.push (x := s11532) b11532 <|
    PetersenLocalChildren.push (x := s2693) b2693 <|
    PetersenLocalChildren.push (x := s11615) b11615 <|
    PetersenLocalChildren.push (x := s11616) b11616 <|
    PetersenLocalChildren.push (x := s11617) b11617 <|
    PetersenLocalChildren.push (x := s11618) b11618 <|
    PetersenLocalChildren.push (x := s11533) b11533 <|
    PetersenLocalChildren.push (x := s2690) b2690 <|
    PetersenLocalChildren.push (x := s11619) b11619 <|
    PetersenLocalChildren.push (x := s5072) b5072 <|
    PetersenLocalChildren.push (x := s11620) b11620 <|
    PetersenLocalChildren.push (x := s5074) b5074 <|
    PetersenLocalChildren.push (x := s11621) b11621 <|
    PetersenLocalChildren.push (x := s11622) b11622 <|
    PetersenLocalChildren.push (x := s11623) b11623 <|
    PetersenLocalChildren.push (x := s11624) b11624 <|
    PetersenLocalChildren.push (x := s11625) b11625 <|
    PetersenLocalChildren.push (x := s11626) b11626 <|
    PetersenLocalChildren.push (x := s11627) b11627 <|
    PetersenLocalChildren.push (x := s11628) b11628 <|
    PetersenLocalChildren.push (x := s11629) b11629 <|
    PetersenLocalChildren.push (x := s11630) b11630 <|
    PetersenLocalChildren.push (x := s11631) b11631 <|
    PetersenLocalChildren.push (x := s11632) b11632 <|
    PetersenLocalChildren.push (x := s11633) b11633 <|
    PetersenLocalChildren.push (x := s9923) b9923 <|
    PetersenLocalChildren.push (x := s11634) b11634 <|
    PetersenLocalChildren.push (x := s9925) b9925 <|
    PetersenLocalChildren.push (x := s11635) b11635 <|
    PetersenLocalChildren.push (x := s11636) b11636 <|
    PetersenLocalChildren.push (x := s11637) b11637 <|
    PetersenLocalChildren.push (x := s11638) b11638 <|
    PetersenLocalChildren.push (x := s11639) b11639 <|
    PetersenLocalChildren.push (x := s11640) b11640 <|
    PetersenLocalChildren.push (x := s11641) b11641 <|
    PetersenLocalChildren.push (x := s11642) b11642 <|
    PetersenLocalChildren.push (x := s11643) b11643 <|
    PetersenLocalChildren.push (x := s11644) b11644 <|
    PetersenLocalChildren.push (x := s11645) b11645 <|
    PetersenLocalChildren.push (x := s11646) b11646 <|
    PetersenLocalChildren.nil
theorem b11750 : Blocked tgt 8 s11750 := by
  apply PetersenFastNode.node (nxt := #[s11561,s11032]) (hints := [5548,0,6966,5548,6966,5290,5548,9931,7734,4524,7734,6580,5548,4532,7468,5548,5290,5548,5548,5290,9676,1452,13644,9676,14902,1484,14902,5548,6838,6966,1,6838,5932,5932,7476,7734,7476,6838,7468,6838,7468,4774,4774,6838,6838,4774,13515,6806,13515,2710,13612,14902,13612,6838,5802,6966,6966,6060,6966,7220,7734,6966,4918,6966,7468,9675,9675,13515,2870,13515,2838,6966,13612,14902,6966,7092,7734,7476,7734,6060,5044,7468,6060,5802,6060,6060,5802,13515,1964,13515,10188,6060,14902,13612,14902,5670,7734,7734,5670,5670,7734,7734,5670,12483,12491,12483,13507,7734,3412,14902,7734,11467,11467,13515,3372,13515,11596,12838,14902,12838,14902,13515,13644,13515,13644,12838,14902,12838,14902,5259,5323,13451,5259]) (by decide +kernel)
  change ∀ b ∈ [s11561,s11032], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11561) b11561 <|
    PetersenLocalChildren.push (x := s11032) b11032 <|
    PetersenLocalChildren.nil
theorem b11790 : Blocked tgt 8 s11790 := by
  apply PetersenFastNode.node (nxt := #[s11601,s11791,s11792]) (hints := [5549,0,6967,5293,6967,5291,5549,9932,7735,4525,7735,6581,5549,4533,7469,5549,9677,5549,5549,9677,9677,5549,5549,9677,14903,1485,14903,5549,9676,6967,9676,6839,5933,5933,7477,7735,7477,6839,7469,6823,7469,4775,14677,6807,14677,2711,1,6839,6839,2,13613,14903,13613,6839,9676,6967,6967,9676,8644,8652,9668,8644,9676,4919,6951,9676,9676,2871,6935,9676,9676,6967,6967,9676,1420,1484,9612,1420,7093,7735,7477,7735,6061,5045,7469,6061,10189,6061,6061,10189,10189,6061,6061,10189,6061,14903,13613,14903,5671,5687,7719,5671,3607,3639,7703,3607,1543,7735,7735,1543,7735,3413,14903,7735,3373,7469,14677,11468,11468,12839,12855,12839,14887,13516,13516,10775,10807,10775,14871,8711,14903,8711,14903]) (by decide +kernel)
  change ∀ b ∈ [s11601,s11791,s11792], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s11601) b11601 <|
    PetersenLocalChildren.push (x := s11791) b11791 <|
    PetersenLocalChildren.push (x := s11792) b11792 <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i0 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word3) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12066,s11534,s5523,s11533,s5525,s11532,s12067,s11535]) (hints := [6844,0,1,6844,2,3,5554,4,5,5554,6,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12066,s11534,s5523,s11533,s5525,s11532,s12067,s11535], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12066) (b12066) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11534) (b11534) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5523) (b5523) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11533) (b11533) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5525) (b5525) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11532) (b11532) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12067) (b12067) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11535) (b11535) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i1 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12068,s12069,s12070,s12071]) (hints := [905,0,905,9677,1,9677,905,2,905,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12068,s12069,s12070,s12071], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12068) (b12068) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12069) (b12069) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12070) (b12070) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12071) (b12071) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i2 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12066,s5523,s5525,s12067,s11808,s11807,s11806,s11809]) (hints := [9937,2,4,9937,1,5,5938,0,6,5938,3,7]) (by decide +kernel) ?_
  change ∀ x ∈ [s12066,s5523,s5525,s12067,s11808,s11807,s11806,s11809], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12066) (b12066) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5523) (b5523) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s5525) (b5525) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12067) (b12067) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11808) (b11808) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11807) (b11807) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11806) (b11806) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11809) (b11809) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i3 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12072,s12073,s12074,s12075]) (hints := [1673,0,1673,7736,1,7736,1673,2,1673,7736,3,7736]) (by decide +kernel) ?_
  change ∀ x ∈ [s12072,s12073,s12074,s12075], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12072) (b12072) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12073) (b12073) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12074) (b12074) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12075) (b12075) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i4 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12076,s12077,s12078,s12079]) (hints := [2697,0,2697,11469,1,11469,2697,2,2697,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12076,s12077,s12078,s12079], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12076) (b12076) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12077) (b12077) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12078) (b12078) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12079) (b12079) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i5 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12080,s12081,s12082,s12083]) (hints := [4745,0,4745,13517,1,13517,4745,2,4745,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12080,s12081,s12082,s12083], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12080) (b12080) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12081) (b12081) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12082) (b12082) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12083) (b12083) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i6 : PetersenLocalChildren.PairOK tgt 7 s12065 (word58,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12084,s12085,s12086,s12087]) (hints := [8841,0,8841,14904,1,14904,8841,2,8841,14904,3,14904]) (by decide +kernel) ?_
  change ∀ x ∈ [s12084,s12085,s12086,s12087], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12084) (b12084) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12085) (b12085) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12086) (b12086) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12087) (b12087) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i7 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word1) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12088,s12089,s12090,s12091]) (hints := [6968,0,6968,9677,1,9677,6968,2,6968,9677,3,9677]) (by decide +kernel) ?_
  change ∀ x ∈ [s12088,s12089,s12090,s12091], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12088) (b12088) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12089) (b12089) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12090) (b12090) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12091) (b12091) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i8 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s11534,s11533,s11532,s11535,s11808,s11807,s11806,s11809]) (hints := [9809,3,7,9809,1,5,6066,0,6,6066,2,4]) (by decide +kernel) ?_
  change ∀ x ∈ [s11534,s11533,s11532,s11535,s11808,s11807,s11806,s11809], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11534) (b11534) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11533) (b11533) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11532) (b11532) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11535) (b11535) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11808) (b11808) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11807) (b11807) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11806) (b11806) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s11809) (b11809) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i9 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12092,s12093,s12094,s12095]) (hints := [7736,0,7736,1673,1,1673,7736,2,7736,1673,3,1673]) (by decide +kernel) ?_
  change ∀ x ∈ [s12092,s12093,s12094,s12095], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12092) (b12092) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12093) (b12093) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12094) (b12094) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12095) (b12095) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i10 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12096,s12097,s12098,s12099]) (hints := [7470,0,7470,11469,1,11469,7470,2,7470,11469,3,11469]) (by decide +kernel) ?_
  change ∀ x ∈ [s12096,s12097,s12098,s12099], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12096) (b12096) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12097) (b12097) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12098) (b12098) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12099) (b12099) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i11 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12100,s12101,s12102,s12103]) (hints := [13646,0,13646,13517,1,13517,13646,2,13646,13517,3,13517]) (by decide +kernel) ?_
  change ∀ x ∈ [s12100,s12101,s12102,s12103], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12100) (b12100) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12101) (b12101) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12102) (b12102) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12103) (b12103) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i12 : PetersenLocalChildren.PairOK tgt 7 s12065 (word3,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12104,s12105,s12106,s12107]) (hints := [14904,0,14904,8841,1,8841,14904,2,14904,8841,3,8841]) (by decide +kernel) ?_
  change ∀ x ∈ [s12104,s12105,s12106,s12107], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12104) (b12104) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12105) (b12105) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12106) (b12106) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12107) (b12107) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i13 : PetersenLocalChildren.PairOK tgt 7 s12065 (word1,word0) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12108,s12109,s12110,s12111]) (hints := [9677,9677,0,6968,6968,1,6968,6968,2,9677,9677,3]) (by decide +kernel) ?_
  change ∀ x ∈ [s12108,s12109,s12110,s12111], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12108) (b12108) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12109) (b12109) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12110) (b12110) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12111) (b12111) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i14 : PetersenLocalChildren.PairOK tgt 7 s12065 (word1,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [8641,8641,7732,8649,9673,7474,9665,9673,7732,8641,8641,7474]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i15 : PetersenLocalChildren.PairOK tgt 7 s12065 (word1,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,11465,4916,6964,7466,11465,6964,11465,9673,9673,7466]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i16 : PetersenLocalChildren.PairOK tgt 7 s12065 (word1,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [9673,9673,13513,2868,6964,13642,13513,6964,13513,9673,9673,13642]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i17 : PetersenLocalChildren.PairOK tgt 7 s12065 (word1,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [1417,1417,14900,1481,9673,13610,9609,9673,14900,1417,1417,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i18 : PetersenLocalChildren.PairOK tgt 7 s12065 (word0,word6) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12112,s12113,s12114,s12115]) (hints := [7478,0,7478,7736,1,7736,7478,2,7478,7736,3,7736]) (by decide +kernel) ?_
  change ∀ x ∈ [s12112,s12113,s12114,s12115], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12112) (b12112) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12113) (b12113) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12114) (b12114) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12115) (b12115) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i19 : PetersenLocalChildren.PairOK tgt 7 s12065 (word0,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12116,s12117,s12118,s12119]) (hints := [11469,0,11469,2697,1,2697,11469,2,11469,2697,3,2697]) (by decide +kernel) ?_
  change ∀ x ∈ [s12116,s12117,s12118,s12119], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12116) (b12116) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12117) (b12117) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12118) (b12118) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12119) (b12119) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i20 : PetersenLocalChildren.PairOK tgt 7 s12065 (word0,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12120,s12121,s12122,s12123]) (hints := [13517,0,13517,4745,1,4745,13517,2,13517,4745,3,4745]) (by decide +kernel) ?_
  change ∀ x ∈ [s12120,s12121,s12122,s12123], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12120) (b12120) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12121) (b12121) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12122) (b12122) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12123) (b12123) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i21 : PetersenLocalChildren.PairOK tgt 7 s12065 (word0,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[s12124,s12125,s12126,s12127]) (hints := [13614,0,13614,14904,1,14904,13614,2,13614,14904,3,14904]) (by decide +kernel) ?_
  change ∀ x ∈ [s12124,s12125,s12126,s12127], Blocked tgt 7 x
  exact
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12124) (b12124) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12125) (b12125) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12126) (b12126) <|
    PetersenLocalChildren.push (P := Blocked tgt 7) (x := s12127) (b12127) <|
    PetersenLocalChildren.nil
private theorem thetaPair12065i22 : PetersenLocalChildren.PairOK tgt 7 s12065 (word6,word5) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [10433,5668,10433,10441,7732,11465,10433,7732,10433,11457,5668,11465]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i23 : PetersenLocalChildren.PairOK tgt 7 s12065 (word6,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [12481,3604,12481,12489,7732,13513,12481,7732,12481,13505,3604,13513]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i24 : PetersenLocalChildren.PairOK tgt 7 s12065 (word6,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [7732,7732,14900,3410,11602,13610,14900,11602,14900,7732,7732,13610]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i25 : PetersenLocalChildren.PairOK tgt 7 s12065 (word5,word2) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [11465,11465,13513,3370,7466,14674,13513,7466,13513,11465,11465,14674]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i26 : PetersenLocalChildren.PairOK tgt 7 s12065 (word5,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [3209,3209,12836,3273,11465,14900,11401,11465,12836,3209,3209,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
private theorem thetaPair12065i27 : PetersenLocalChildren.PairOK tgt 7 s12065 (word2,word4) := by
  refine PetersenLocalChildren.pair_close (bank := #[]) (hints := [5257,5257,10772,5321,13513,14900,13449,13513,10772,5257,5257,14900]) (by decide +kernel) ?_
  exact PetersenLocalChildren.nil
theorem b12065 : Blocked tgt 8 s12065 := by
  refine PetersenLocalChildren.finish (by decide +kernel) ?_
  change ∀ p ∈ [(word58,word3),(word58,word1),(word58,word0),(word58,word6),(word58,word5),(word58,word2),(word58,word4),(word3,word1),(word3,word0),(word3,word6),(word3,word5),(word3,word2),(word3,word4),(word1,word0),(word1,word6),(word1,word5),(word1,word2),(word1,word4),(word0,word6),(word0,word5),(word0,word2),(word0,word4),(word6,word5),(word6,word2),(word6,word4),(word5,word2),(word5,word4),(word2,word4)], PetersenLocalChildren.PairOK tgt 7 s12065 p
  exact
    PetersenLocalChildren.push thetaPair12065i0 <|
    PetersenLocalChildren.push thetaPair12065i1 <|
    PetersenLocalChildren.push thetaPair12065i2 <|
    PetersenLocalChildren.push thetaPair12065i3 <|
    PetersenLocalChildren.push thetaPair12065i4 <|
    PetersenLocalChildren.push thetaPair12065i5 <|
    PetersenLocalChildren.push thetaPair12065i6 <|
    PetersenLocalChildren.push thetaPair12065i7 <|
    PetersenLocalChildren.push thetaPair12065i8 <|
    PetersenLocalChildren.push thetaPair12065i9 <|
    PetersenLocalChildren.push thetaPair12065i10 <|
    PetersenLocalChildren.push thetaPair12065i11 <|
    PetersenLocalChildren.push thetaPair12065i12 <|
    PetersenLocalChildren.push thetaPair12065i13 <|
    PetersenLocalChildren.push thetaPair12065i14 <|
    PetersenLocalChildren.push thetaPair12065i15 <|
    PetersenLocalChildren.push thetaPair12065i16 <|
    PetersenLocalChildren.push thetaPair12065i17 <|
    PetersenLocalChildren.push thetaPair12065i18 <|
    PetersenLocalChildren.push thetaPair12065i19 <|
    PetersenLocalChildren.push thetaPair12065i20 <|
    PetersenLocalChildren.push thetaPair12065i21 <|
    PetersenLocalChildren.push thetaPair12065i22 <|
    PetersenLocalChildren.push thetaPair12065i23 <|
    PetersenLocalChildren.push thetaPair12065i24 <|
    PetersenLocalChildren.push thetaPair12065i25 <|
    PetersenLocalChildren.push thetaPair12065i26 <|
    PetersenLocalChildren.push thetaPair12065i27 <|
    PetersenLocalChildren.nil
theorem b12306 : Blocked tgt 8 s12306 := by
  apply PetersenFastNode.node (nxt := #[s3155,s2721,s12307,s209,s5098,s12308,s5100,s12309,s12310,s9951,s10872,s12311,s1143,s12312,s12313,s218,s219,s12314,s12315,s12316,s221,s12317,s12318,s10135,s12319,s12320,s12321,s12322,s12323,s12324]) (hints := [931,6350,931,9703,6608,9703,931,6608,931,9703,6350,9703,5960,6608,5960,6354,0,1,5576,6608,6866,5576,2,3,6608,6608,1571,4,5,6,7632,7,1571,6608,6608,8,7496,4544,7496,4560,6608,11495,7496,6608,7496,4544,4544,11495,13672,10736,13672,2512,6608,13543,13672,6608,13672,10736,10736,13543,13640,6608,13640,2544,10736,9,13640,10736,13640,6608,6608,10,9703,9703,5702,5704,931,5960,5702,931,5702,9703,9703,5960,9703,9703,6866,803,931,11,6866,931,6866,9703,9703,12,8671,8671,1571,8679,9703,13,9695,9703,1571,8671,8671,14,9703,9703,11495,4946,6994,7496,11495,6994,11495,9703,9703,7496,9703,9703,13543,2898,6994,13672,13543,6994,13543,9703,9703,13672,1447,1447,8867,1511,9703,13640,9639,9703,8867,1447,1447,13640,6992,6992,15,5960,5960,6866,5960,5960,16,6992,6992,6866,5064,6992,17,5064,5960,1571,5960,5960,18,6992,6992,1571,11495,5960,11495,4944,6992,2723,11495,6992,11495,5960,5960,2723,13543,10088,13543,1864,5960,4771,13543,5960,13543,10088,10088,4771,5960,5960,13640,1896,10088,8867,13640,10088,13640,5960,5960,8867,6866,6866,8,1571,19,1571,7504,20,21,7504,6866,1571,11495,4802,11495,7496,6866,7496,11495,6866,11495,7496,4802,7496,13543,2738,13543,13672,6866,13672,13543,6866,13543,13672,2738,13672,14672,6866,14672,13640,22,13640,14672,23,14672,13640,6866,13640,10463,1571,10463,10471,24,11495,10463,25,10463,11487,1571,11495,12511,1571,12511,12519,26,13543,12511,27,12511,13535,1571,13543,14672,1571,14672,13640,28,13640,14672,29,14672,13640,1571,13640,11495,11495,13543,3400,7496,14704,13543,7496,13543,11495,11495,14704,3239,3239,13640,3303,11495,14672,11431,11495,13640,3239,3239,14672,5287,5287,8867,5351,13543,13640,13479,13543,8867,5287,5287,13640]) (by decide +kernel)
  change ∀ b ∈ [s3155,s2721,s12307,s209,s5098,s12308,s5100,s12309,s12310,s9951,s10872,s12311,s1143,s12312,s12313,s218,s219,s12314,s12315,s12316,s221,s12317,s12318,s10135,s12319,s12320,s12321,s12322,s12323,s12324], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s3155) b3155 <|
    PetersenLocalChildren.push (x := s2721) b2721 <|
    PetersenLocalChildren.push (x := s12307) b12307 <|
    PetersenLocalChildren.push (x := s209) b209 <|
    PetersenLocalChildren.push (x := s5098) b5098 <|
    PetersenLocalChildren.push (x := s12308) b12308 <|
    PetersenLocalChildren.push (x := s5100) b5100 <|
    PetersenLocalChildren.push (x := s12309) b12309 <|
    PetersenLocalChildren.push (x := s12310) b12310 <|
    PetersenLocalChildren.push (x := s9951) b9951 <|
    PetersenLocalChildren.push (x := s10872) b10872 <|
    PetersenLocalChildren.push (x := s12311) b12311 <|
    PetersenLocalChildren.push (x := s1143) b1143 <|
    PetersenLocalChildren.push (x := s12312) b12312 <|
    PetersenLocalChildren.push (x := s12313) b12313 <|
    PetersenLocalChildren.push (x := s218) b218 <|
    PetersenLocalChildren.push (x := s219) b219 <|
    PetersenLocalChildren.push (x := s12314) b12314 <|
    PetersenLocalChildren.push (x := s12315) b12315 <|
    PetersenLocalChildren.push (x := s12316) b12316 <|
    PetersenLocalChildren.push (x := s221) b221 <|
    PetersenLocalChildren.push (x := s12317) b12317 <|
    PetersenLocalChildren.push (x := s12318) b12318 <|
    PetersenLocalChildren.push (x := s10135) b10135 <|
    PetersenLocalChildren.push (x := s12319) b12319 <|
    PetersenLocalChildren.push (x := s12320) b12320 <|
    PetersenLocalChildren.push (x := s12321) b12321 <|
    PetersenLocalChildren.push (x := s12322) b12322 <|
    PetersenLocalChildren.push (x := s12323) b12323 <|
    PetersenLocalChildren.push (x := s12324) b12324 <|
    PetersenLocalChildren.nil
theorem b12336 : Blocked tgt 8 s12336 := by
  apply PetersenFastNode.node (nxt := #[s1724,s12337,s12338,s12339,s12340,s12341,s12342]) (hints := [908,5553,908,5295,5553,0,5295,5553,5553,5295,4529,4529,5553,1,5553,6585,5553,11344,7473,5553,9681,1457,13649,9681,5553,1489,13617,5553,5681,908,5937,9680,9680,908,2,1548,908,6843,780,6843,6971,11472,4923,11472,908,13520,2875,13520,908,908,13617,8844,908,5937,5679,5041,5041,5937,6969,6969,5937,5937,6969,11472,4921,11472,5937,13520,1841,13520,10065,5937,1873,13617,5937,3,1548,4,1548,5,6843,6,6843,11472,7473,11472,7473,13520,13649,13520,13649,13359,13617,13359,13617,7481,7481,10440,10448,10440,11464,12488,12496,12488,13512,14649,13617,14649,13617,4779,11472,6827,11472,14681,13520,14681,13520,14649,13617,14649,13617,11472,3377,13520,11472,3216,3280,11408,3216,5264,5328,13456,5264]) (by decide +kernel)
  change ∀ b ∈ [s1724,s12337,s12338,s12339,s12340,s12341,s12342], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1724) b1724 <|
    PetersenLocalChildren.push (x := s12337) b12337 <|
    PetersenLocalChildren.push (x := s12338) b12338 <|
    PetersenLocalChildren.push (x := s12339) b12339 <|
    PetersenLocalChildren.push (x := s12340) b12340 <|
    PetersenLocalChildren.push (x := s12341) b12341 <|
    PetersenLocalChildren.push (x := s12342) b12342 <|
    PetersenLocalChildren.nil
theorem b12403 : Blocked tgt 8 s12403 := by
  apply PetersenFastNode.node (nxt := #[s12404,s1143,s1139,s12405,s1732,s2731,s5105,s12406,s9960,s10879,s1142,s11099,s12407,s12408,s12409,s11120,s12410,s12411,s12412,s12413,s12414,s12415,s12416,s12417]) (hints := [5570,5570,6860,5312,5312,0,6860,5312,6860,5570,5570,1,5312,5312,6988,5570,5570,2,6988,5570,6988,5312,5312,3,5312,5312,5696,9825,4,5,1565,6602,1565,4288,5312,6,1565,5312,1565,6602,6602,7,2717,5312,2717,11361,6602,11489,2717,6602,2717,5312,5312,11489,4765,9698,4765,13409,5312,13537,4765,5312,4765,13536,9698,13537,8861,5312,8861,1506,9698,8,8861,9698,8861,5312,5312,9,9697,6860,6988,9697,10,11,5954,12,5954,5696,6860,5696,5954,6860,5954,5696,13,5696,7498,6860,7498,1565,14,1565,7498,15,7498,6860,6860,1565,7490,4796,7490,11489,6860,11489,7490,6860,7490,11489,4796,11489,13666,2732,13666,13537,6860,13537,13666,6860,13666,13537,2732,13537,13634,6860,13634,8733,16,8861,13634,17,13634,6860,6860,8861,5696,18,5696,5954,6988,5954,5696,6988,5696,5954,19,5954,1565,6988,1565,7498,20,7498,1565,21,1565,6988,6988,7498,11489,4924,11489,4940,6988,7490,11489,6988,11489,4924,4924,7490,13537,2860,13537,2892,6988,13666,13537,6988,13537,2860,2860,13666,8861,6988,8861,13634,22,13634,8861,23,8861,6988,6988,13634,4800,6986,7498,4800,5696,1565,5696,5696,7498,1565,6986,1565,11489,5696,11489,2717,6986,2717,11489,6986,11489,5696,5696,2717,13537,9824,13537,1600,5696,4765,13537,5696,13537,9824,9824,4765,5696,5696,13376,1632,9824,8861,13376,9824,13376,5696,5696,8861,10457,1565,10457,10465,7498,11489,10457,7498,10457,11481,1565,11489,12505,1565,12505,12513,7498,13537,12505,7498,12505,13529,1565,13537,1565,1565,8861,13376,11626,13376,8861,11626,8861,1565,1565,13376,11489,11489,13537,3136,7232,14698,13537,7232,13537,11489,11489,14698,3233,3233,8861,3297,11489,14666,11425,11489,8861,3233,3233,14666,5281,5281,8861,5345,13537,13376,13473,13537,8861,5281,5281,13376]) (by decide +kernel)
  change ∀ b ∈ [s12404,s1143,s1139,s12405,s1732,s2731,s5105,s12406,s9960,s10879,s1142,s11099,s12407,s12408,s12409,s11120,s12410,s12411,s12412,s12413,s12414,s12415,s12416,s12417], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12404) b12404 <|
    PetersenLocalChildren.push (x := s1143) b1143 <|
    PetersenLocalChildren.push (x := s1139) b1139 <|
    PetersenLocalChildren.push (x := s12405) b12405 <|
    PetersenLocalChildren.push (x := s1732) b1732 <|
    PetersenLocalChildren.push (x := s2731) b2731 <|
    PetersenLocalChildren.push (x := s5105) b5105 <|
    PetersenLocalChildren.push (x := s12406) b12406 <|
    PetersenLocalChildren.push (x := s9960) b9960 <|
    PetersenLocalChildren.push (x := s10879) b10879 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s11099) b11099 <|
    PetersenLocalChildren.push (x := s12407) b12407 <|
    PetersenLocalChildren.push (x := s12408) b12408 <|
    PetersenLocalChildren.push (x := s12409) b12409 <|
    PetersenLocalChildren.push (x := s11120) b11120 <|
    PetersenLocalChildren.push (x := s12410) b12410 <|
    PetersenLocalChildren.push (x := s12411) b12411 <|
    PetersenLocalChildren.push (x := s12412) b12412 <|
    PetersenLocalChildren.push (x := s12413) b12413 <|
    PetersenLocalChildren.push (x := s12414) b12414 <|
    PetersenLocalChildren.push (x := s12415) b12415 <|
    PetersenLocalChildren.push (x := s12416) b12416 <|
    PetersenLocalChildren.push (x := s12417) b12417 <|
    PetersenLocalChildren.nil
theorem b12431 : Blocked tgt 8 s12431 := by
  apply PetersenFastNode.node (nxt := #[s5970,s12416,s12394,s12432,s11109,s12411]) (hints := [5294,5552,5552,5294,5552,9807,4528,4528,5552,0,5552,6584,5552,11343,7472,5552,9680,1456,13648,9680,5552,1488,13616,5552,5294,5552,5552,5294,9679,5936,5678,9679,8647,8655,9671,8647,6842,9679,9679,1,9679,7472,11471,9679,9679,13392,13519,9679,1487,9679,13616,9679,1423,5040,5040,5936,6968,6968,5936,5936,6968,11471,4920,11471,5936,13519,1840,13519,10064,5936,1872,13616,5936,5678,5936,5936,5678,7480,7480,10439,10447,10439,11463,12487,12495,12487,13511,14648,13616,14648,13616,1547,2,3,1547,4778,11471,6826,11471,14680,13519,14680,13519,14648,13616,14648,13616,6842,4,5,6842,11471,3376,13519,11471,3215,11471,11471,3215,3215,11471,11471,3215,5263,13519,13519,5263,5263,13519,13519,5263,13616,8843]) (by decide +kernel)
  change ∀ b ∈ [s5970,s12416,s12394,s12432,s11109,s12411], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s5970) b5970 <|
    PetersenLocalChildren.push (x := s12416) b12416 <|
    PetersenLocalChildren.push (x := s12394) b12394 <|
    PetersenLocalChildren.push (x := s12432) b12432 <|
    PetersenLocalChildren.push (x := s11109) b11109 <|
    PetersenLocalChildren.push (x := s12411) b12411 <|
    PetersenLocalChildren.nil
theorem b12494 : Blocked tgt 8 s12494 := by
  apply PetersenFastNode.node (nxt := #[s12495,s12496,s12497,s12498,s12499,s12500]) (hints := [907,5296,907,5294,5552,9807,4528,4528,5552,0,5552,6584,5552,11343,7472,5552,9680,1456,13648,9680,5552,9680,9680,5552,5552,9680,9680,5552,9679,9808,9806,9679,8647,8655,9671,8647,6842,9679,9679,6970,9679,4922,11471,9679,9679,2874,13519,9679,1423,9679,9679,1423,1423,9679,9679,1423,9168,9168,10064,11096,11096,10064,10064,11096,11471,9048,11471,10064,13519,4747,13519,10064,1872,10064,8843,5936,5936,7480,7480,10439,10447,10439,11463,12487,12495,12487,13511,1547,1,8843,1547,2,1547,1547,3,4778,11471,6826,11471,14680,13519,14680,13519,6842,8715,14906,6842,4,6842,6842,5,11471,3376,13519,11471,3215,11471,11471,3215,3215,11471,11471,3215,5263,13519,13519,5263,5263,13519,13519,5263,13616,13616]) (by decide +kernel)
  change ∀ b ∈ [s12495,s12496,s12497,s12498,s12499,s12500], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12495) b12495 <|
    PetersenLocalChildren.push (x := s12496) b12496 <|
    PetersenLocalChildren.push (x := s12497) b12497 <|
    PetersenLocalChildren.push (x := s12498) b12498 <|
    PetersenLocalChildren.push (x := s12499) b12499 <|
    PetersenLocalChildren.push (x := s12500) b12500 <|
    PetersenLocalChildren.nil
theorem b12610 : Blocked tgt 8 s12610 := by
  apply PetersenFastNode.node (nxt := #[s12611,s12612,s12613,s12614,s12615,s12616,s1763,s2745,s12617,s5118,s12618,s12619,s12620,s12621,s12622,s9974,s10895,s12389,s12623,s12624,s12625,s12626,s12470,s12627,s12628,s12629,s12630,s12537,s12631,s12589,s12632,s12633,s12634]) (hints := [7499,7499,0,5579,11498,5579,11370,11498,1,5579,7499,5579,11498,11498,4933,9706,7499,9706,4933,7499,4933,9706,11498,9706,11498,11498,4931,5963,2726,5963,4931,2726,4931,11498,11498,5963,10466,10466,2,11490,11498,1574,10474,11498,3,10466,10466,1574,11498,11498,6853,4805,4,5,11498,11498,12643,13546,7499,13546,3403,7499,12643,11498,11498,13546,3242,3242,12611,11434,11498,13643,3306,11498,12611,3242,3242,13643,934,5321,934,5323,5579,9706,934,5579,934,5321,5321,9706,5579,5579,5963,9834,6,7,4555,8,1574,4555,5579,9,5579,5579,1574,10,11,12,5579,5579,6853,6595,13,14,9707,9707,13675,1483,5579,13546,13675,5579,13675,9707,9707,13546,5579,5579,13643,1515,9707,15,13643,9707,13643,5579,5579,16,9706,9706,5705,5707,934,5963,5705,934,5705,9706,9706,5963,8674,8674,1574,8682,9706,17,9698,9706,1574,8674,8674,18,4933,4933,6853,9706,9706,19,9706,9706,6853,4933,4933,20,9706,9706,13546,13419,4933,13675,13546,4933,13546,9706,9706,13675,1450,1450,8870,1514,9706,13643,9642,9706,8870,1450,1450,13643,5067,4931,21,5067,5963,1574,5963,5963,22,1574,4931,1574,4931,4931,23,5963,5963,6853,5963,5963,24,4931,4931,6853,13546,10091,13546,1867,5963,4774,13546,5963,13546,10091,10091,4774,5963,5963,13643,1899,10091,8870,13643,10091,13643,5963,5963,8870,1574,1574,6853,7491,25,26,12514,1574,12514,12522,27,13546,12514,28,12514,13538,1574,13546,1574,1574,8870,13643,29,13643,8870,30,8870,13643,1574,13643,12643,2725,12643,13546,6853,13546,12643,6853,12643,13546,2725,13546,12611,6853,12611,13643,31,13643,12611,32,12611,13643,6853,13643,5290,5290,8870,5354,13546,13643,13482,13546,8870,5290,5290,13643]) (by decide +kernel)
  change ∀ b ∈ [s12611,s12612,s12613,s12614,s12615,s12616,s1763,s2745,s12617,s5118,s12618,s12619,s12620,s12621,s12622,s9974,s10895,s12389,s12623,s12624,s12625,s12626,s12470,s12627,s12628,s12629,s12630,s12537,s12631,s12589,s12632,s12633,s12634], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12611) b12611 <|
    PetersenLocalChildren.push (x := s12612) b12612 <|
    PetersenLocalChildren.push (x := s12613) b12613 <|
    PetersenLocalChildren.push (x := s12614) b12614 <|
    PetersenLocalChildren.push (x := s12615) b12615 <|
    PetersenLocalChildren.push (x := s12616) b12616 <|
    PetersenLocalChildren.push (x := s1763) b1763 <|
    PetersenLocalChildren.push (x := s2745) b2745 <|
    PetersenLocalChildren.push (x := s12617) b12617 <|
    PetersenLocalChildren.push (x := s5118) b5118 <|
    PetersenLocalChildren.push (x := s12618) b12618 <|
    PetersenLocalChildren.push (x := s12619) b12619 <|
    PetersenLocalChildren.push (x := s12620) b12620 <|
    PetersenLocalChildren.push (x := s12621) b12621 <|
    PetersenLocalChildren.push (x := s12622) b12622 <|
    PetersenLocalChildren.push (x := s9974) b9974 <|
    PetersenLocalChildren.push (x := s10895) b10895 <|
    PetersenLocalChildren.push (x := s12389) b12389 <|
    PetersenLocalChildren.push (x := s12623) b12623 <|
    PetersenLocalChildren.push (x := s12624) b12624 <|
    PetersenLocalChildren.push (x := s12625) b12625 <|
    PetersenLocalChildren.push (x := s12626) b12626 <|
    PetersenLocalChildren.push (x := s12470) b12470 <|
    PetersenLocalChildren.push (x := s12627) b12627 <|
    PetersenLocalChildren.push (x := s12628) b12628 <|
    PetersenLocalChildren.push (x := s12629) b12629 <|
    PetersenLocalChildren.push (x := s12630) b12630 <|
    PetersenLocalChildren.push (x := s12537) b12537 <|
    PetersenLocalChildren.push (x := s12631) b12631 <|
    PetersenLocalChildren.push (x := s12589) b12589 <|
    PetersenLocalChildren.push (x := s12632) b12632 <|
    PetersenLocalChildren.push (x := s12633) b12633 <|
    PetersenLocalChildren.push (x := s12634) b12634 <|
    PetersenLocalChildren.nil
theorem b12662 : Blocked tgt 8 s12662 := by
  apply PetersenFastNode.node (nxt := #[s12663,s10135,s12664,s12411,s12665,s12666,s12667,s12668,s5421,s12659,s1765,s2747,s5120,s12669,s10134,s12670,s12543,s12671,s12672,s12673]) (hints := [9694,6856,9694,5566,0,5566,9694,1,9694,5566,6856,5566,9693,6856,9693,1437,2,1437,9693,3,9693,1437,6856,1437,10078,4,10078,5950,6856,5950,10078,6856,10078,5950,5,5950,11622,6856,11622,1561,6,1561,7494,7,11622,7494,6856,1561,11485,4792,11485,3229,6856,3229,11485,6856,11485,3229,4792,3229,13533,2728,13533,5277,6856,5277,13533,6856,13533,5277,2728,5277,13630,6856,14662,13630,8,9,921,5308,921,5310,5566,1437,921,5566,921,5308,5308,1437,5566,5566,5950,1565,10,11,4542,10726,1561,4542,5566,12,5566,5566,1561,10726,10726,13,5566,5566,7486,3101,10726,3229,7486,10726,7486,5566,5566,3229,1438,1438,4761,1470,5566,5277,5534,5566,4761,1438,1438,5277,5566,5566,14662,9694,9694,14,9694,9694,14662,5566,5566,15,1437,1437,5692,5694,921,5950,5692,921,5692,1437,1437,5950,405,405,1561,413,1437,11622,1429,1437,1561,405,405,11622,1437,1437,3229,7230,6984,7486,3229,6984,3229,1437,1437,7486,1437,1437,5277,2888,6984,13662,5277,6984,5277,1437,1437,13662,1437,1437,14920,9693,9693,14662,9693,9693,14920,1437,1437,14662,5054,6982,11622,5054,5950,1561,5950,5950,11622,1561,6982,1561,3229,5950,3229,2713,6982,2713,3229,6982,3229,5950,5950,2713,5277,1822,5277,1854,5950,4761,5277,5950,5277,1822,1822,4761,5950,5950,14662,10078,10078,14920,10078,10078,14662,5950,5950,14920,2197,1561,2197,2205,11622,3229,2197,11622,2197,3221,1561,3229,4245,1561,4245,4253,16,5277,4245,17,4245,5269,1561,5277,1561,1561,14662,11622,11622,18,14662,11622,14662,1561,1561,19,3229,3229,5277,3390,7486,14694,5277,7486,5277,3229,3229,14694,3229,3229,12598,11485,11485,14662,11485,11485,12598,3229,3229,14662,5277,5277,10792,13533,13533,14662,13533,13533,10792,5277,5277,14662]) (by decide +kernel)
  change ∀ b ∈ [s12663,s10135,s12664,s12411,s12665,s12666,s12667,s12668,s5421,s12659,s1765,s2747,s5120,s12669,s10134,s12670,s12543,s12671,s12672,s12673], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12663) b12663 <|
    PetersenLocalChildren.push (x := s10135) b10135 <|
    PetersenLocalChildren.push (x := s12664) b12664 <|
    PetersenLocalChildren.push (x := s12411) b12411 <|
    PetersenLocalChildren.push (x := s12665) b12665 <|
    PetersenLocalChildren.push (x := s12666) b12666 <|
    PetersenLocalChildren.push (x := s12667) b12667 <|
    PetersenLocalChildren.push (x := s12668) b12668 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s12659) b12659 <|
    PetersenLocalChildren.push (x := s1765) b1765 <|
    PetersenLocalChildren.push (x := s2747) b2747 <|
    PetersenLocalChildren.push (x := s5120) b5120 <|
    PetersenLocalChildren.push (x := s12669) b12669 <|
    PetersenLocalChildren.push (x := s10134) b10134 <|
    PetersenLocalChildren.push (x := s12670) b12670 <|
    PetersenLocalChildren.push (x := s12543) b12543 <|
    PetersenLocalChildren.push (x := s12671) b12671 <|
    PetersenLocalChildren.push (x := s12672) b12672 <|
    PetersenLocalChildren.push (x := s12673) b12673 <|
    PetersenLocalChildren.nil
theorem b12808 : Blocked tgt 8 s12808 := by
  apply PetersenFastNode.node (nxt := #[s12809,s12810,s1780,s12811,s12812,s12813,s12814,s12815,s12816,s11120,s12817,s12818,s12819,s12820,s12821,s12822,s12823,s12824,s1142,s11106,s12825,s12826]) (hints := [795,5310,795,5568,5568,8663,795,5568,795,8663,5310,8663,6858,5310,6858,5568,5568,0,5568,5568,6858,5310,5310,1,5568,5568,5952,8919,2,3,6600,6600,7496,4544,5568,4,7496,5568,7496,6600,6600,5,5568,5568,7488,4552,6600,10455,7488,6600,7488,5568,5568,10455,9696,9696,13664,1472,5568,12503,13664,5568,13664,9696,9696,12503,5568,5568,13632,1504,9696,6,13632,9696,13632,5568,5568,7,9695,8663,6858,9695,8,9,8663,8663,5694,5952,795,5952,795,795,5694,8663,8663,5952,8663,8663,7754,7496,10,7496,9687,11,7754,8663,8663,7496,8663,8663,10455,7488,12,7488,10455,13,10455,8663,8663,7488,8663,8663,12503,13664,14,13664,12503,15,12503,8663,8663,13664,407,407,8859,471,8663,13632,8599,8663,8859,407,407,13632,5694,16,5694,5952,6858,5952,5694,6858,5694,5952,17,5952,6858,6858,7754,7496,18,7496,7754,19,7754,7496,6858,7496,11487,4794,11487,10455,6858,10455,11487,6858,11487,10455,4794,10455,13535,2730,13535,12503,6858,12503,13535,6858,13535,12503,2730,12503,6858,6858,14922,13632,20,13632,14922,21,14922,13632,6858,13632,6984,6984,7496,4928,5952,7754,7496,5952,7496,6984,6984,7754,10455,5952,10455,4936,6984,2715,10455,6984,10455,5952,5952,2715,12503,10080,12503,1856,5952,4763,12503,5952,12503,10080,10080,4763,5952,5952,13632,1888,10080,8859,13632,10080,13632,5952,5952,8859,10455,5690,10455,11487,7496,11487,10455,7496,10455,11487,5690,11487,12503,11624,12503,13535,7496,13535,12503,7496,12503,13535,11624,13535,7496,7496,14664,3432,11624,13632,14664,11624,14664,7496,7496,13632,10455,10455,12503,3392,7488,14696,12503,7488,12503,10455,10455,14696,2199,2199,13632,2263,10455,14664,10391,10455,13632,2199,2199,14664,4247,4247,8859,4311,12503,13632,12439,12503,8859,4247,4247,13632]) (by decide +kernel)
  change ∀ b ∈ [s12809,s12810,s1780,s12811,s12812,s12813,s12814,s12815,s12816,s11120,s12817,s12818,s12819,s12820,s12821,s12822,s12823,s12824,s1142,s11106,s12825,s12826], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s12809) b12809 <|
    PetersenLocalChildren.push (x := s12810) b12810 <|
    PetersenLocalChildren.push (x := s1780) b1780 <|
    PetersenLocalChildren.push (x := s12811) b12811 <|
    PetersenLocalChildren.push (x := s12812) b12812 <|
    PetersenLocalChildren.push (x := s12813) b12813 <|
    PetersenLocalChildren.push (x := s12814) b12814 <|
    PetersenLocalChildren.push (x := s12815) b12815 <|
    PetersenLocalChildren.push (x := s12816) b12816 <|
    PetersenLocalChildren.push (x := s11120) b11120 <|
    PetersenLocalChildren.push (x := s12817) b12817 <|
    PetersenLocalChildren.push (x := s12818) b12818 <|
    PetersenLocalChildren.push (x := s12819) b12819 <|
    PetersenLocalChildren.push (x := s12820) b12820 <|
    PetersenLocalChildren.push (x := s12821) b12821 <|
    PetersenLocalChildren.push (x := s12822) b12822 <|
    PetersenLocalChildren.push (x := s12823) b12823 <|
    PetersenLocalChildren.push (x := s12824) b12824 <|
    PetersenLocalChildren.push (x := s1142) b1142 <|
    PetersenLocalChildren.push (x := s11106) b11106 <|
    PetersenLocalChildren.push (x := s12825) b12825 <|
    PetersenLocalChildren.push (x := s12826) b12826 <|
    PetersenLocalChildren.nil
theorem b12845 : Blocked tgt 8 s12845 := by
  apply PetersenFastNode.node (nxt := #[s1787,s12846,s12847,s12848,s12849,s12850,s12851,s12852,s12853,s12854,s12825,s12855,s12856,s12857,s12858,s12859,s12860,s12861,s5421,s12652,s12862,s12863,s12864,s12865,s12866,s12668]) (hints := [6990,5314,6990,5316,5572,9699,6990,5572,6990,5314,5314,9699,5572,5572,5956,9827,0,1,7500,10732,7500,5572,5572,2,7500,5572,7500,7628,10732,3,5572,5572,7492,8684,10732,11491,7492,10732,7492,5572,5572,11491,9700,9700,13668,1476,5572,13539,13668,5572,13668,9700,9700,13539,5572,5572,8735,9700,9700,4,9700,9700,8735,5572,5572,5,5572,5572,6862,9700,9700,6,9700,9700,6862,5572,5572,7,9699,9699,5698,5700,6990,5956,5698,6990,5698,9699,9699,5956,8667,8667,7758,8675,9699,7500,9691,9699,7758,8667,8667,7500,9699,9699,11491,4942,6990,7492,11491,6990,11491,9699,9699,7492,9699,9699,13539,2894,6990,13668,13539,6990,13539,9699,9699,13668,1443,1443,8735,9699,9699,8,9699,9699,8735,1443,1443,9,1443,1443,6862,9699,9699,10,9699,9699,6862,1443,1443,11,6988,6988,7500,4932,5956,7758,7500,5956,7500,6988,6988,7758,11491,5956,11491,4940,6988,2719,11491,6988,11491,5956,5956,2719,13539,10084,13539,1860,5956,4767,13539,5956,13539,10084,10084,4767,5956,5956,12,10084,10084,8735,10084,10084,13,5956,5956,8735,5956,5956,14,10084,10084,6862,10084,10084,15,5956,5956,6862,10459,5694,10459,10467,7500,11491,10459,7500,10459,11483,5694,11491,12507,11628,12507,12515,7500,13539,12507,7500,12507,13531,11628,13539,7500,7500,8735,11628,11628,16,11628,11628,8735,7500,7500,17,7500,7500,6862,11628,11628,18,11628,11628,6862,7500,7500,19,11491,11491,13539,3396,7492,14700,13539,7492,13539,11491,11491,14700,3235,3235,8735,11491,11491,20,11491,11491,8735,3235,3235,21,3235,3235,4798,11491,11491,6862,11491,11491,4798,3235,3235,6862,5283,5283,8735,13539,13539,22,13539,13539,8735,5283,5283,23,5283,5283,2734,13539,13539,6862,13539,13539,2734,5283,5283,6862,13636,8735,6862,13636,24,25]) (by decide +kernel)
  change ∀ b ∈ [s1787,s12846,s12847,s12848,s12849,s12850,s12851,s12852,s12853,s12854,s12825,s12855,s12856,s12857,s12858,s12859,s12860,s12861,s5421,s12652,s12862,s12863,s12864,s12865,s12866,s12668], Blocked tgt 7 b
  exact
    PetersenLocalChildren.push (x := s1787) b1787 <|
    PetersenLocalChildren.push (x := s12846) b12846 <|
    PetersenLocalChildren.push (x := s12847) b12847 <|
    PetersenLocalChildren.push (x := s12848) b12848 <|
    PetersenLocalChildren.push (x := s12849) b12849 <|
    PetersenLocalChildren.push (x := s12850) b12850 <|
    PetersenLocalChildren.push (x := s12851) b12851 <|
    PetersenLocalChildren.push (x := s12852) b12852 <|
    PetersenLocalChildren.push (x := s12853) b12853 <|
    PetersenLocalChildren.push (x := s12854) b12854 <|
    PetersenLocalChildren.push (x := s12825) b12825 <|
    PetersenLocalChildren.push (x := s12855) b12855 <|
    PetersenLocalChildren.push (x := s12856) b12856 <|
    PetersenLocalChildren.push (x := s12857) b12857 <|
    PetersenLocalChildren.push (x := s12858) b12858 <|
    PetersenLocalChildren.push (x := s12859) b12859 <|
    PetersenLocalChildren.push (x := s12860) b12860 <|
    PetersenLocalChildren.push (x := s12861) b12861 <|
    PetersenLocalChildren.push (x := s5421) b5421 <|
    PetersenLocalChildren.push (x := s12652) b12652 <|
    PetersenLocalChildren.push (x := s12862) b12862 <|
    PetersenLocalChildren.push (x := s12863) b12863 <|
    PetersenLocalChildren.push (x := s12864) b12864 <|
    PetersenLocalChildren.push (x := s12865) b12865 <|
    PetersenLocalChildren.push (x := s12866) b12866 <|
    PetersenLocalChildren.push (x := s12668) b12668 <|
    PetersenLocalChildren.nil
end PetersenSmallStarts.M191.Staged
