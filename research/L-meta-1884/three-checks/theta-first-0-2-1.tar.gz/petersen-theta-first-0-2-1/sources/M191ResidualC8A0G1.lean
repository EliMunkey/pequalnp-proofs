import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredRows1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b235 : Blocked tgt 8 s235 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s235 8 _ le
  decide +kernel
theorem b236 : Blocked tgt 8 s236 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s236 8 _ le
  decide +kernel
theorem b237 : Blocked tgt 8 s237 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s237 8 _ le
  decide +kernel
theorem b238 : Blocked tgt 8 s238 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s238 8 _ le
  decide +kernel
theorem b239 : Blocked tgt 8 s239 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s239 8 _ le
  decide +kernel
theorem b240 : Blocked tgt 8 s240 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s240 8 _ le
  decide +kernel
theorem b241 : Blocked tgt 8 s241 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s241 8 _ le
  decide +kernel
theorem b242 : Blocked tgt 8 s242 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s242 8 _ le
  decide +kernel
theorem b268 : Blocked tgt 8 s268 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s268 8 _ le
  decide +kernel
theorem b269 : Blocked tgt 8 s269 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s269 8 _ le
  decide +kernel
theorem b270 : Blocked tgt 8 s270 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s270 8 _ le
  decide +kernel
theorem b271 : Blocked tgt 8 s271 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s271 8 _ le
  decide +kernel
theorem b272 : Blocked tgt 8 s272 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s272 8 _ le
  decide +kernel
theorem b273 : Blocked tgt 8 s273 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s273 8 _ le
  decide +kernel
theorem b274 : Blocked tgt 8 s274 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s274 8 _ le
  decide +kernel

theorem b275 : Blocked tgt 8 s275 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s275 8 _ le
  decide +kernel
theorem b276 : Blocked tgt 8 s276 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s276 8 _ le
  decide +kernel
theorem b277 : Blocked tgt 8 s277 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s277 8 _ le
  decide +kernel
theorem b278 : Blocked tgt 8 s278 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s278 8 _ le
  decide +kernel
theorem b279 : Blocked tgt 8 s279 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s279 8 _ le
  decide +kernel
theorem b280 : Blocked tgt 8 s280 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s280 8 _ le
  decide +kernel
theorem b281 : Blocked tgt 8 s281 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s281 8 _ le
  decide +kernel
theorem b282 : Blocked tgt 8 s282 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s282 8 _ le
  decide +kernel
theorem b283 : Blocked tgt 8 s283 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s283 8 _ le
  decide +kernel
theorem b284 : Blocked tgt 8 s284 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s284 8 _ le
  decide +kernel
theorem b285 : Blocked tgt 8 s285 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s285 8 _ le
  decide +kernel
theorem b286 : Blocked tgt 8 s286 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s286 8 _ le
  decide +kernel
theorem b287 : Blocked tgt 8 s287 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s287 8 _ le
  decide +kernel
theorem b288 : Blocked tgt 8 s288 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s288 8 _ le
  decide +kernel
theorem b289 : Blocked tgt 8 s289 := by
  intro k le c
  apply rejects_sound r22 i4 3 tgt small22 hot22 [] s289 8 _ le
  decide +kernel
theorem b290 : Blocked tgt 8 s290 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s290 8 _ le
  decide +kernel

theorem b291 : Blocked tgt 8 s291 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s291 8 _ le
  decide +kernel
theorem b292 : Blocked tgt 8 s292 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s292 8 _ le
  decide +kernel
theorem b293 : Blocked tgt 8 s293 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s293 8 _ le
  decide +kernel
theorem b294 : Blocked tgt 8 s294 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s294 8 _ le
  decide +kernel
theorem b295 : Blocked tgt 8 s295 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s295 8 _ le
  decide +kernel
theorem b296 : Blocked tgt 8 s296 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s296 8 _ le
  decide +kernel
theorem b297 : Blocked tgt 8 s297 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s297 8 _ le
  decide +kernel
theorem b298 : Blocked tgt 8 s298 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s298 8 _ le
  decide +kernel
theorem b299 : Blocked tgt 8 s299 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s299 8 _ le
  decide +kernel
theorem b300 : Blocked tgt 8 s300 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s300 8 _ le
  decide +kernel
theorem b301 : Blocked tgt 8 s301 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s301 8 _ le
  decide +kernel
theorem b302 : Blocked tgt 8 s302 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s302 8 _ le
  decide +kernel
theorem b303 : Blocked tgt 8 s303 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s303 8 _ le
  decide +kernel
theorem b304 : Blocked tgt 8 s304 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s304 8 _ le
  decide +kernel
theorem b305 : Blocked tgt 8 s305 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s305 8 _ le
  decide +kernel
theorem b306 : Blocked tgt 8 s306 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s306 8 _ le
  decide +kernel

theorem b307 : Blocked tgt 8 s307 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s307 8 _ le
  decide +kernel
theorem b308 : Blocked tgt 8 s308 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s308 8 _ le
  decide +kernel
theorem b309 : Blocked tgt 8 s309 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s309 8 _ le
  decide +kernel
theorem b310 : Blocked tgt 8 s310 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s310 8 _ le
  decide +kernel
theorem b311 : Blocked tgt 8 s311 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s311 8 _ le
  decide +kernel
theorem b312 : Blocked tgt 8 s312 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s312 8 _ le
  decide +kernel
theorem b313 : Blocked tgt 8 s313 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s313 8 _ le
  decide +kernel
theorem b314 : Blocked tgt 8 s314 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s314 8 _ le
  decide +kernel
theorem b315 : Blocked tgt 8 s315 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s315 8 _ le
  decide +kernel
theorem b316 : Blocked tgt 8 s316 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s316 8 _ le
  decide +kernel
theorem b317 : Blocked tgt 8 s317 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s317 8 _ le
  decide +kernel
theorem b318 : Blocked tgt 8 s318 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s318 8 _ le
  decide +kernel
theorem b319 : Blocked tgt 8 s319 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s319 8 _ le
  decide +kernel
theorem b320 : Blocked tgt 8 s320 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s320 8 _ le
  decide +kernel
theorem b321 : Blocked tgt 8 s321 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s321 8 _ le
  decide +kernel
theorem b322 : Blocked tgt 8 s322 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s322 8 _ le
  decide +kernel

theorem b323 : Blocked tgt 8 s323 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s323 8 _ le
  decide +kernel
theorem b324 : Blocked tgt 8 s324 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s324 8 _ le
  decide +kernel
theorem b325 : Blocked tgt 8 s325 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s325 8 _ le
  decide +kernel
theorem b326 : Blocked tgt 8 s326 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s326 8 _ le
  decide +kernel
theorem b327 : Blocked tgt 8 s327 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s327 8 _ le
  decide +kernel
theorem b328 : Blocked tgt 8 s328 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s328 8 _ le
  decide +kernel
theorem b329 : Blocked tgt 8 s329 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s329 8 _ le
  decide +kernel
theorem b330 : Blocked tgt 8 s330 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s330 8 _ le
  decide +kernel
theorem b331 : Blocked tgt 8 s331 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s331 8 _ le
  decide +kernel
theorem b336 : Blocked tgt 8 s336 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s336 8 _ le
  decide +kernel
theorem b337 : Blocked tgt 8 s337 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s337 8 _ le
  decide +kernel
theorem b338 : Blocked tgt 8 s338 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s338 8 _ le
  decide +kernel
theorem b339 : Blocked tgt 8 s339 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s339 8 _ le
  decide +kernel
theorem b340 : Blocked tgt 8 s340 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s340 8 _ le
  decide +kernel
theorem b341 : Blocked tgt 8 s341 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s341 8 _ le
  decide +kernel
theorem b342 : Blocked tgt 8 s342 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s342 8 _ le
  decide +kernel
theorem b343 : Blocked tgt 8 s343 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s343 8 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
