import M63StartData
import M63StartPins0
import M63StartL5B1
import M63StartL5B0
import M63StartL5B2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
namespace PetersenSmallStarts.M63
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b46 : Blocked tgt 6 s46 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s46 6 _ le
  decide +kernel
theorem b47 : Blocked tgt 6 s47 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [(true,(0,false),(1,false))] s47 6 _ le
  decide +kernel
theorem b48 : Blocked tgt 6 s48 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s48 6 _ le
  decide +kernel
theorem b49 : Blocked tgt 6 s49 := by
  apply PetersenFastNode.node (nxt := #[s50,s51,s52]) (hints := [3447,392,3511,3447,2797,780,2989,2797,2797,2667,3317,2285,3765,3317,2797,2293,3757,2797,717,749,2765,717,716,200,844,716,456,0,456,204,840,456,456,2487,1352,456,456,1463,2376,456,844,2859,3509,840,836,836,844,1096,1612,844,844,2120,2636,844,3635,840,3635,840,3627,1352,3627,1352,1,2376,2,2376,840,1100,1352,840,840,2124,2376,840,1352,1709,2376,1352]) (by decide +kernel)
  change ∀ b ∈ [s50,s51,s52], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s50) b50 <|
    PetersenLocalChildren.push (x := s51) b51 <|
    PetersenLocalChildren.push (x := s52) b52 <|
    PetersenLocalChildren.nil
theorem b53 : Blocked tgt 6 s53 := by
  apply PetersenFastNode.node (nxt := #[]) (hints := [3444,2794,3444,2794,453,713,453,713,841,841,837,3762,837,3762,1349,1609,1349,1609,2373,2633,2373,2633,2666,2666,2794,713,2794,3444,2856,2794,3314,2282,3762,3314,2794,2290,3754,2794,714,746,2762,714,713,453,453,713,193,201,705,193,713,3754,1609,713,713,1460,2633,713,3762,837,3762,837,1609,1349,1609,1349,2633,2373,2633,2373,1089,1097,1089,1601,2113,2121,2113,2625,1609,1706,2633,1609]) (by decide +kernel)
  change ∀ b ∈ [], Blocked tgt 5 b
  exact 
    
    PetersenLocalChildren.nil
theorem b54 : Blocked tgt 6 s54 := by
  intro k le c
  apply rejects_sound r4 i4 3 tgt small4 hot4 [] s54 6 _ le
  decide +kernel
theorem b55 : Blocked tgt 6 s55 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s55 6 _ le
  decide +kernel
theorem b56 : Blocked tgt 6 s56 := by
  apply PetersenFastNode.node (nxt := #[s32,s57,s58,s59,s60,s61,s62]) (hints := [396,396,2799,460,2801,784,2993,2801,3321,2289,3769,3321,2801,3451,2801,2297,3761,2801,721,753,2769,721,720,204,848,720,460,208,844,460,460,3515,460,3633,1356,460,460,0,2380,460,3513,844,840,840,1,848,848,2,848,1100,1616,848,848,2124,2640,848,844,3899,844,1104,1356,844,844,2128,2380,844,3,1356,4,1356,5,2380,6,2380,1356,1713,2380,1356]) (by decide +kernel)
  change ∀ b ∈ [s32,s57,s58,s59,s60,s61,s62], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s32) b32 <|
    PetersenLocalChildren.push (x := s57) b57 <|
    PetersenLocalChildren.push (x := s58) b58 <|
    PetersenLocalChildren.push (x := s59) b59 <|
    PetersenLocalChildren.push (x := s60) b60 <|
    PetersenLocalChildren.push (x := s61) b61 <|
    PetersenLocalChildren.push (x := s62) b62 <|
    PetersenLocalChildren.nil
theorem b63 : Blocked tgt 6 s63 := by
  apply PetersenFastNode.node (nxt := #[s35]) (hints := [2795,3315,2795,3315,714,454,714,454,842,3507,842,3507,838,838,1610,1350,1610,1350,2634,2374,2634,2374,390,390,3315,454,3315,778,3507,3315,3315,2795,2795,3315,2275,2291,3299,2275,1235,1267,3283,1235,194,198,450,194,454,714,714,454,454,3627,1350,454,454,0,2374,454,3507,842,842,3507,1090,1094,1090,1346,2114,2118,2114,2370,1350,1610,1350,1610,2374,2634,2374,2634,1350,1707,2374,1350]) (by decide +kernel)
  change ∀ b ∈ [s35], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s35) b35 <|
    PetersenLocalChildren.nil
theorem b64 : Blocked tgt 6 s64 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s64 6 _ le
  decide +kernel
theorem b65 : Blocked tgt 6 s65 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s65 6 _ le
  decide +kernel
theorem b66 : Blocked tgt 6 s66 := by
  apply PetersenFastNode.node (nxt := #[s67,s68]) (hints := [3446,391,3510,3446,2796,843,2988,2796,3316,2284,3764,3316,2796,2292,3756,2796,2796,2406,716,748,2764,716,715,199,843,715,455,203,839,455,455,2486,1351,455,455,2470,455,1462,2375,455,3508,839,835,835,843,1095,1611,843,2858,843,843,2858,843,2119,2635,843,839,1099,1351,839,2854,839,839,2854,839,2123,2375,839,1351,3626,1351,1708,2375,1351,0,2375,1,2375]) (by decide +kernel)
  change ∀ b ∈ [s67,s68], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s67) b67 <|
    PetersenLocalChildren.push (x := s68) b68 <|
    PetersenLocalChildren.nil
theorem b69 : Blocked tgt 6 s69 := by
  apply PetersenFastNode.node (nxt := #[s70,s71]) (hints := [3316,2796,3316,2796,3510,455,3510,455,3508,843,3508,843,3764,839,3764,839,1351,1351,0,2375,1,2375,391,391,2796,455,2796,843,2988,2796,2276,2284,2788,2276,2796,3316,3316,2796,716,748,2764,716,715,199,843,715,455,203,839,455,455,3510,3494,455,455,1462,2375,455,2468,839,835,835,843,3508,3508,843,843,2119,2635,843,839,3764,3764,839,839,2123,2375,839,2375,1578,2375,1546]) (by decide +kernel)
  change ∀ b ∈ [s70,s71], Blocked tgt 5 b
  exact 
    PetersenLocalChildren.push (x := s70) b70 <|
    PetersenLocalChildren.push (x := s71) b71 <|
    PetersenLocalChildren.nil
theorem b72 : Blocked tgt 6 s72 := by
  intro k le c
  apply rejects_sound r9 i4 3 tgt small9 hot9 [] s72 6 _ le
  decide +kernel
theorem b73 : Blocked tgt 6 s73 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s73 6 _ le
  decide +kernel
theorem b74 : Blocked tgt 6 s74 := by
  intro k le c
  apply rejects_sound r0 i5 6 tgt small0 hot0 [] s74 6 _ le
  decide +kernel
end PetersenSmallStarts.M63
