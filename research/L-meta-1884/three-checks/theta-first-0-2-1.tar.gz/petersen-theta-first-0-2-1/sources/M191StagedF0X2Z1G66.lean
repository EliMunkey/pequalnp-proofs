import higher.WireProjection
import M191Values0
import M191Values1
import M191Values10
import M191Values14
import M191Values19
import M191Values2
import M191Values21
import M191Values32
import M191Values5
import M191Values737
import M191Values745
import M191Values8
import M191Values9
import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts2
import M191StartPreferredCuts3
import M191StartPreferredRows62
import M191StartPreferredRows63
import M191StartPreferredRows64
namespace PetersenSmallStarts.M191.Residual
end PetersenSmallStarts.M191.Residual
open PetersenSmallStarts.M191.Residual
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Staged
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b13959 : Blocked tgt 8 s13959 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s13959 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7913 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
theorem b13960 : Blocked tgt 8 s13960 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s13960 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0x0] (PetersenWireProjection.cons pv19_1279 (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)

theorem b13961 : Blocked tgt 8 s13961 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s13961 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2077 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13962 : Blocked tgt 8 s13962 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s13962 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6539 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13987 : Blocked tgt 8 s13987 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s13987 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2084 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b13992 : Blocked tgt 8 s13992 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(1,false),(4,false))] s13992 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffccccffffccccffffccccffffcccc,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xffffccccffffccccffffccccffffcccc : BitVec 128) = 0xffffccccffffccccffffccccffffcccc) (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b13993 : Blocked tgt 8 s13993 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13993 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13994 : Blocked tgt 8 s13994 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13994 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl)))))))) (by decide +kernel)
theorem b13995 : Blocked tgt 8 s13995 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s13995 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b13996 : Blocked tgt 8 s13996 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s13996 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xc4c4c4c4c4c4c4c4c4c4c4c4c4c4c4c4 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b13997 : Blocked tgt 8 s13997 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13997 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13998 : Blocked tgt 8 s13998 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13998 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b13999 : Blocked tgt 8 s13999 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s13999 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14000 : Blocked tgt 8 s14000 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14000 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b14001 : Blocked tgt 8 s14001 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14001 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14002 : Blocked tgt 8 s14002 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14002 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xf5f50000f5f50000f5f50000f5f50000 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)

theorem b14003 : Blocked tgt 8 s14003 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14003 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a08080a0a08080a0a08080a0a0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b14004 : Blocked tgt 8 s14004 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14004 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xa0a08080a0a08080a0a08080a0a0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14005 : Blocked tgt 8 s14005 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14005 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r8 (0xa0a08080a0a08080a0a08080a0a0808 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b14006 : Blocked tgt 8 s14006 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14006 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7168 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14007 : Blocked tgt 8 s14007 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14007 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1480 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14008 : Blocked tgt 8 s14008 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14008 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1480 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b14034 : Blocked tgt 8 s14034 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14034 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5720 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14035 : Blocked tgt 8 s14035 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14035 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5720 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14036 : Blocked tgt 8 s14036 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(4,false))] s14036 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffffcccc,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7152 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14037 : Blocked tgt 8 s14037 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(4,false))] s14037 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffffcccc,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7152 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14038 : Blocked tgt 8 s14038 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(4,false))] s14038 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0xffffcccc,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7152 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14039 : Blocked tgt 8 s14039 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(1,false),(4,false))] s14039 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000,0xffffcccc,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7152 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14040 : Blocked tgt 8 s14040 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14040 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3582 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14041 : Blocked tgt 8 s14041 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14041 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3705 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14042 : Blocked tgt 8 s14042 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14042 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4142 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)

theorem b14043 : Blocked tgt 8 s14043 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14043 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_1546 (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b14044 : Blocked tgt 8 s14044 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14044 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_3716 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14045 : Blocked tgt 8 s14045 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14045 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4429 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14046 : Blocked tgt 8 s14046 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14046 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2240 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14047 : Blocked tgt 8 s14047 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14047 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0x0,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4586 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14048 : Blocked tgt 8 s14048 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s14048 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4586 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14049 : Blocked tgt 8 s14049 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s14049 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1779 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_7152 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14050 : Blocked tgt 8 s14050 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14050 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xf0f0f0f0,0x0,0x0,0xcccccccc,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7152 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14051 : Blocked tgt 8 s14051 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14051 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_3359 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14058 : Blocked tgt 8 s14058 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14058 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_391 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14059 : Blocked tgt 8 s14059 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14059 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14060 : Blocked tgt 8 s14060 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14060 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2906 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14061 : Blocked tgt 8 s14061 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s14061 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r9 (0xf0f0c0c0f0f0c0c0f0f0c0c0f0f0c0c0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6170 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b14062 : Blocked tgt 8 s14062 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14062 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_2940 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14063 : Blocked tgt 8 s14063 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14063 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_5978 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_7152 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14064 : Blocked tgt 8 s14064 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14064 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xff000000ff000000ff000000ff00 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_7152 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14065 : Blocked tgt 8 s14065 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14065 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6044 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14066 : Blocked tgt 8 s14066 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14066 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_1556 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14067 : Blocked tgt 8 s14067 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14067 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r10 (0xff00cc00ff00cc00ff00cc00ff00cc : BitVec 128) = 0x0) (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14068 : Blocked tgt 8 s14068 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s14068 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_1779 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14069 : Blocked tgt 8 s14069 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s14069 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7136 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14070 : Blocked tgt 8 s14070 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14070 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xffff,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_7975 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14071 : Blocked tgt 8 s14071 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14071 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_1321 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14072 : Blocked tgt 8 s14072 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s14072 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1560 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14073 : Blocked tgt 8 s14073 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s14073 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7142 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14074 : Blocked tgt 8 s14074 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14074 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00,0xffff] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 (PetersenWireProjection.cons pv14_8356 rfl))))))))) (by decide +kernel)
theorem b14075 : Blocked tgt 8 s14075 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s14075 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv10_608 (PetersenWireProjection.cons pv10_2708 (PetersenWireProjection.cons pv10_4260 (PetersenWireProjection.cons pv10_4814 (PetersenWireProjection.cons pv10_5473 (PetersenWireProjection.cons pv10_6170 (PetersenWireProjection.cons pv10_6790 (PetersenWireProjection.cons pv10_7474 (PetersenWireProjection.cons pv10_8012 rfl))))))))) (by decide +kernel)
theorem b14076 : Blocked tgt 8 s14076 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s14076 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_1568 (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14287 : Blocked tgt 8 s14287 := by
  intro k le c
  apply rejects_sound r0 i7 10 tgt small0 hot0 [(true,(2,false),(3,false))] s14287 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xfff0fff0fff0fff0fff0fff0fff0fff0,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] (PetersenWireProjection.cons pv0_0 (PetersenWireProjection.cons pv0_4260 (PetersenWireProjection.cons pv0_4814 (PetersenWireProjection.cons pv0_5473 (PetersenWireProjection.cons pv0_6170 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r0 (0xfff0fff0fff0fff0fff0fff0fff0fff0 : BitVec 128) = 0xfff0fff0fff0fff0fff0fff0fff0fff0) (PetersenWireProjection.cons pv0_6790 (PetersenWireProjection.cons pv0_7474 (PetersenWireProjection.cons pv0_8012 rfl))))))))) (by decide +kernel)
theorem b14288 : Blocked tgt 8 s14288 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(1,false),(2,false))] s14288 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2627 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6618 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14289 : Blocked tgt 8 s14289 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(true,(1,false),(2,false))] s14289 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xfcfcfcfcfcfcfcfc,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4503 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6618 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14290 : Blocked tgt 8 s14290 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14290 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14291 : Blocked tgt 8 s14291 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14291 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b14292 : Blocked tgt 8 s14292 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14292 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5682 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14293 : Blocked tgt 8 s14293 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14293 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_5682 (PetersenWireProjection.cons pv737_6618 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14294 : Blocked tgt 8 s14294 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14294 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b14295 : Blocked tgt 8 s14295 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14295 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2654 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14296 : Blocked tgt 8 s14296 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s14296 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0xcccc,0x0,0xffff,0xffff,0xffff,0x0,0xf0f0,0xff00] (PetersenWireProjection.cons pv32_4260 (PetersenWireProjection.cons pv32_4814 (PetersenWireProjection.cons pv32_5473 (PetersenWireProjection.cons pv32_6170 (PetersenWireProjection.cons pv32_6618 (PetersenWireProjection.cons pv32_6659 (PetersenWireProjection.cons pv32_6790 (PetersenWireProjection.cons pv32_7474 (PetersenWireProjection.cons pv32_8012 rfl))))))))) (by decide +kernel)
theorem b14297 : Blocked tgt 8 s14297 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14297 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5703 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl)))))))) (by decide +kernel)
theorem b14298 : Blocked tgt 8 s14298 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14298 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5703 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14299 : Blocked tgt 8 s14299 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14299 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r737 (0xf5f0f5f0f5f0f5f0f5f0f5f0f5f0f5f0 : BitVec 128) = 0xf0f0f0f0) (PetersenWireProjection.cons pv737_6170 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14300 : Blocked tgt 8 s14300 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14300 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2672 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14301 : Blocked tgt 8 s14301 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s14301 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_5713 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14302 : Blocked tgt 8 s14302 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(2,false),(3,false))] s14302 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xfff0fff0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2686 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6618 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14303 : Blocked tgt 8 s14303 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(2,false),(3,false))] s14303 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xfff0fff0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5729 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6618 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14304 : Blocked tgt 8 s14304 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(2,false),(3,false))] s14304 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xfff0fff0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2698 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6618 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14305 : Blocked tgt 8 s14305 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(true,(2,false),(3,false))] s14305 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0xff00ff00,0xfff0fff0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_5745 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6618 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)

theorem b14306 : Blocked tgt 8 s14306 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14306 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4097 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl)))))))) (by decide +kernel)
theorem b14307 : Blocked tgt 8 s14307 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s14307 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r21 (0xaaa0aaa0aaa0aaa0aaa0aaa0aaa0aaa0 : BitVec 128) = 0x0) (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6618 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))))) (by decide +kernel)
theorem b14308 : Blocked tgt 8 s14308 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s14308 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv8_2708 (PetersenWireProjection.cons pv8_4097 (PetersenWireProjection.cons pv8_4260 (PetersenWireProjection.cons pv8_4814 (PetersenWireProjection.cons pv8_5473 (PetersenWireProjection.cons pv8_6170 (PetersenWireProjection.cons pv8_6790 (PetersenWireProjection.cons pv8_7474 (PetersenWireProjection.cons pv8_8012 rfl))))))))) (by decide +kernel)
theorem b14327 : Blocked tgt 8 s14327 := by
  intro k le c
  apply rejects_sound r21 i4 3 tgt small21 hot21 [] s14327 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaa,0x0,0x0,0x0,0x0,0x0,0xcccc,0xf0f0,0xff00] (PetersenWireProjection.cons pv21_2708 (PetersenWireProjection.cons pv21_3690 (PetersenWireProjection.cons pv21_4814 (PetersenWireProjection.cons pv21_5473 (PetersenWireProjection.cons pv21_6170 (PetersenWireProjection.cons pv21_6618 (PetersenWireProjection.cons pv21_6790 (PetersenWireProjection.cons pv21_7474 (PetersenWireProjection.cons pv21_8012 rfl))))))))) (by decide +kernel)
theorem b14328 : Blocked tgt 8 s14328 := by
  intro k le c
  apply rejects_sound r745 (0xeeeeeeeeeeeeeeee :: i6) 6 tgt small745 hot745 [] s14328 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xeeeeeeeeeeeeeeee,0x0,0xffffffff00000000,0xcccccccccccccccc,0xaaaaaaaaaaaaaaaa,0xffff0000ffff0000,0xff00ff00ff00ff00,0xf0f0f0f0f0f0f0f0] (PetersenWireProjection.cons pv745_2708 (PetersenWireProjection.cons pv745_3690 (PetersenWireProjection.cons pv745_4260 (PetersenWireProjection.cons pv745_4814 (PetersenWireProjection.cons pv745_5473 (PetersenWireProjection.cons pv745_6170 (PetersenWireProjection.cons pv745_6790 (PetersenWireProjection.cons pv745_7474 (PetersenWireProjection.cons pv745_8012 rfl))))))))) (by decide +kernel)
theorem b14329 : Blocked tgt 8 s14329 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14329 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_3304 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6618 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14330 : Blocked tgt 8 s14330 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s14330 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4582 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14331 : Blocked tgt 8 s14331 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [(false,(0,false),(1,true))] s14331 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x2222222222222222,0xaaaaaaaaaaaaaaaa,0x0,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv1_2029 (PetersenWireProjection.cons pv1_2708 (PetersenWireProjection.cons pv1_4260 (PetersenWireProjection.cons pv1_4814 (PetersenWireProjection.cons pv1_5473 (PetersenWireProjection.cons pv1_6170 (PetersenWireProjection.cons pv1_6790 (PetersenWireProjection.cons pv1_7474 (PetersenWireProjection.cons pv1_8012 rfl))))))))) (by decide +kernel)
theorem b14343 : Blocked tgt 8 s14343 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14343 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0x0,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5241 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14344 : Blocked tgt 8 s14344 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s14344 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5241 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6618 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b14345 : Blocked tgt 8 s14345 := by
  intro k le c
  apply rejects_sound r9 i6 6 tgt small9 hot9 [] s14345 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xaaaaaaaaaaaaaaaa,0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0x0,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] (PetersenWireProjection.cons pv9_2298 (PetersenWireProjection.cons pv9_2708 (PetersenWireProjection.cons pv9_4260 (PetersenWireProjection.cons pv9_4814 (PetersenWireProjection.cons pv9_5473 (PetersenWireProjection.cons pv9_6618 (PetersenWireProjection.cons pv9_6790 (PetersenWireProjection.cons pv9_7474 (PetersenWireProjection.cons pv9_8012 rfl))))))))) (by decide +kernel)
theorem b14346 : Blocked tgt 8 s14346 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14346 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0x0,0xf0f0f0f0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6618 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14347 : Blocked tgt 8 s14347 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14347 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0x0,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_2860 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14348 : Blocked tgt 8 s14348 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14348 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0x0,0xcccc,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6618 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7235 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)

theorem b14349 : Blocked tgt 8 s14349 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14349 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0x0,0xcccc,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1829 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6618 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14357 : Blocked tgt 8 s14357 := by
  intro k le c
  apply rejects_sound r737 (0xa0a0a0a :: i5) 6 tgt small737 hot737 [] s14357 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xf0f0f0f0,0x0,0xffff0000,0xff00ff00] (PetersenWireProjection.cons pv737_531 (PetersenWireProjection.cons pv737_2708 (PetersenWireProjection.cons pv737_4260 (PetersenWireProjection.cons pv737_4814 (PetersenWireProjection.cons pv737_5473 (PetersenWireProjection.cons pv737_6618 (PetersenWireProjection.cons pv737_6790 (PetersenWireProjection.cons pv737_7474 (PetersenWireProjection.cons pv737_8012 rfl))))))))) (by decide +kernel)
theorem b14358 : Blocked tgt 8 s14358 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14358 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6598 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14359 : Blocked tgt 8 s14359 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14359 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons (by decide +kernel : PetersenPackedPin.project r14 (0xfffffff0fffffff0fffffff0fffffff0 : BitVec 128) = 0xffff) (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14360 : Blocked tgt 8 s14360 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s14360 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0x0,0xaaaa,0xcccc,0x0,0xffff,0xf0f0,0xff00] (PetersenWireProjection.cons pv14_1917 (PetersenWireProjection.cons pv14_2708 (PetersenWireProjection.cons pv14_4260 (PetersenWireProjection.cons pv14_4814 (PetersenWireProjection.cons pv14_5473 (PetersenWireProjection.cons pv14_6170 (PetersenWireProjection.cons pv14_6790 (PetersenWireProjection.cons pv14_7474 (PetersenWireProjection.cons pv14_8012 rfl))))))))) (by decide +kernel)
theorem b14361 : Blocked tgt 8 s14361 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s14361 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0x0,0x0,0xff00ff00,0xffff0000] (PetersenWireProjection.cons pv2_2032 (PetersenWireProjection.cons pv2_2708 (PetersenWireProjection.cons pv2_4260 (PetersenWireProjection.cons pv2_4814 (PetersenWireProjection.cons pv2_5473 (PetersenWireProjection.cons pv2_6170 (PetersenWireProjection.cons pv2_6790 (PetersenWireProjection.cons pv2_7474 (PetersenWireProjection.cons pv2_8012 rfl))))))))) (by decide +kernel)
theorem b14362 : Blocked tgt 8 s14362 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [(false,(0,false),(2,true))] s14362 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0xa0a0a0a,0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0x0,0xffff0000,0x0,0x0] (PetersenWireProjection.cons pv5_2708 (PetersenWireProjection.cons pv5_4260 (PetersenWireProjection.cons pv5_4814 (PetersenWireProjection.cons pv5_5473 (PetersenWireProjection.cons pv5_6170 (PetersenWireProjection.cons pv5_6605 (PetersenWireProjection.cons pv5_6790 (PetersenWireProjection.cons pv5_7474 (PetersenWireProjection.cons pv5_8012 rfl))))))))) (by decide +kernel)
theorem b14363 : Blocked tgt 8 s14363 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s14363 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [0x0,0x0,0xaaaa,0xcccc,0xf0f0,0xff00,0xffff,0xffff,0x0] (PetersenWireProjection.cons pv19_2708 (PetersenWireProjection.cons pv19_4260 (PetersenWireProjection.cons pv19_4814 (PetersenWireProjection.cons pv19_5473 (PetersenWireProjection.cons pv19_6170 (PetersenWireProjection.cons pv19_6790 (PetersenWireProjection.cons pv19_7474 (PetersenWireProjection.cons pv19_7931 (PetersenWireProjection.cons pv19_8012 rfl))))))))) (by decide +kernel)
end PetersenSmallStarts.M191.Staged
