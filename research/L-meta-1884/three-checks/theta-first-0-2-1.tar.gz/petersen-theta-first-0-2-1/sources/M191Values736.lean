import higher.WireProjection
import M191StartPreferredCuts2
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
theorem pv736_4260 : PetersenPackedPin.project r736 (0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa : BitVec 128) = 0x0 := by decide +kernel
theorem pv736_4814 : PetersenPackedPin.project r736 (0xcccccccccccccccccccccccccccccccc : BitVec 128) = 0xffffffff00000000 := by decide +kernel
theorem pv736_5473 : PetersenPackedPin.project r736 (0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0 : BitVec 128) = 0xcccccccccccccccc := by decide +kernel
theorem pv736_6170 : PetersenPackedPin.project r736 (0xff00ff00ff00ff00ff00ff00ff00ff00 : BitVec 128) = 0xaaaaaaaaaaaaaaaa := by decide +kernel
theorem pv736_6790 : PetersenPackedPin.project r736 (0xffff0000ffff0000ffff0000ffff0000 : BitVec 128) = 0xffff0000ffff0000 := by decide +kernel
theorem pv736_7474 : PetersenPackedPin.project r736 (0xffffffff00000000ffffffff00000000 : BitVec 128) = 0xff00ff00ff00ff00 := by decide +kernel
theorem pv736_8012 : PetersenPackedPin.project r736 (0xffffffffffffffff0000000000000000 : BitVec 128) = 0xf0f0f0f0f0f0f0f0 := by decide +kernel
theorem pv736_6504 : PetersenPackedPin.project r736 (0xffaaffaaffaaffaaffaaffaaffaaffaa : BitVec 128) = 0xaaaaaaaaaaaaaaaa := PetersenWireProjection.derive 3 pv736_4260 pv736_6170 rfl rfl
theorem pv736_1912 : PetersenPackedPin.project r736 (0xffaa0000ffaa0000ffaa0000ffaa : BitVec 128) = 0xaaaa0000aaaa := PetersenWireProjection.derive 1 pv736_6504 pv736_6790 rfl rfl
end PetersenSmallStarts.M191.Residual
