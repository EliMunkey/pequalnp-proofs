import M191StartPreferredCuts0
import M191StartPreferredCuts1
import M191StartPreferredCuts3
import M191StartPreferredRows32
open PetersenWordCost PetersenPackedPin PetersenLayerCheck PetersenMaskCofactor PetersenInducedCostTable PetersenLocalChildren
open PetersenSmallStarts.M191.Preferred
namespace PetersenSmallStarts.M191.Residual
set_option maxHeartbeats 0
set_option maxRecDepth 200000
set_option exponentiation.threshold 8192
theorem b7262 : Blocked tgt 7 s7262 := by
  intro k le c
  apply rejects_sound r10 i4 3 tgt small10 hot10 [] s7262 7 _ le
  decide +kernel
theorem b7263 : Blocked tgt 7 s7263 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7263 7 _ le
  decide +kernel
theorem b7264 : Blocked tgt 7 s7264 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7264 7 _ le
  decide +kernel
theorem b7265 : Blocked tgt 7 s7265 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7265 7 _ le
  decide +kernel
theorem b7266 : Blocked tgt 7 s7266 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7266 7 _ le
  decide +kernel
theorem b7267 : Blocked tgt 7 s7267 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7267 7 _ le
  decide +kernel
theorem b7268 : Blocked tgt 7 s7268 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7268 7 _ le
  decide +kernel
theorem b7269 : Blocked tgt 7 s7269 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7269 7 _ le
  decide +kernel
theorem b7270 : Blocked tgt 7 s7270 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7270 7 _ le
  decide +kernel
theorem b7271 : Blocked tgt 7 s7271 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7271 7 _ le
  decide +kernel
theorem b7272 : Blocked tgt 7 s7272 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7272 7 _ le
  decide +kernel
theorem b7273 : Blocked tgt 7 s7273 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7273 7 _ le
  decide +kernel
theorem b7274 : Blocked tgt 7 s7274 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7274 7 _ le
  decide +kernel

theorem b7275 : Blocked tgt 7 s7275 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7275 7 _ le
  decide +kernel
theorem b7276 : Blocked tgt 7 s7276 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7276 7 _ le
  decide +kernel
theorem b7277 : Blocked tgt 7 s7277 := by
  intro k le c
  apply rejects_sound r744 (0xfcfcfcfcfcfcfcfc :: i6) 6 tgt small744 hot744 [] s7277 7 _ le
  decide +kernel
theorem b7278 : Blocked tgt 7 s7278 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7278 7 _ le
  decide +kernel
theorem b7279 : Blocked tgt 7 s7279 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7279 7 _ le
  decide +kernel
theorem b7280 : Blocked tgt 7 s7280 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7280 7 _ le
  decide +kernel
theorem b7281 : Blocked tgt 7 s7281 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7281 7 _ le
  decide +kernel
theorem b7282 : Blocked tgt 7 s7282 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7282 7 _ le
  decide +kernel
theorem b7283 : Blocked tgt 7 s7283 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7283 7 _ le
  decide +kernel
theorem b7284 : Blocked tgt 7 s7284 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7284 7 _ le
  decide +kernel
theorem b7285 : Blocked tgt 7 s7285 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7285 7 _ le
  decide +kernel
theorem b7286 : Blocked tgt 7 s7286 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7286 7 _ le
  decide +kernel
theorem b7287 : Blocked tgt 7 s7287 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7287 7 _ le
  decide +kernel
theorem b7288 : Blocked tgt 7 s7288 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7288 7 _ le
  decide +kernel
theorem b7289 : Blocked tgt 7 s7289 := by
  intro k le c
  apply rejects_sound r32 i4 3 tgt small32 hot32 [] s7289 7 _ le
  decide +kernel
theorem b7290 : Blocked tgt 7 s7290 := by
  intro k le c
  apply rejects_sound r13 i4 3 tgt small13 hot13 [] s7290 7 _ le
  decide +kernel

theorem b7291 : Blocked tgt 7 s7291 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7291 7 _ le
  decide +kernel
theorem b7292 : Blocked tgt 7 s7292 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7292 7 _ le
  decide +kernel
theorem b7293 : Blocked tgt 7 s7293 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7293 7 _ le
  decide +kernel
theorem b7294 : Blocked tgt 7 s7294 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7294 7 _ le
  decide +kernel
theorem b7295 : Blocked tgt 7 s7295 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7295 7 _ le
  decide +kernel
theorem b7296 : Blocked tgt 7 s7296 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7296 7 _ le
  decide +kernel
theorem b7297 : Blocked tgt 7 s7297 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7297 7 _ le
  decide +kernel
theorem b7298 : Blocked tgt 7 s7298 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true))] s7298 7 _ le
  decide +kernel
theorem b7299 : Blocked tgt 7 s7299 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7299 7 _ le
  decide +kernel
theorem b7300 : Blocked tgt 7 s7300 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7300 7 _ le
  decide +kernel
theorem b7301 : Blocked tgt 7 s7301 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7301 7 _ le
  decide +kernel
theorem b7302 : Blocked tgt 7 s7302 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7302 7 _ le
  decide +kernel
theorem b7303 : Blocked tgt 7 s7303 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7303 7 _ le
  decide +kernel
theorem b7316 : Blocked tgt 7 s7316 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7316 7 _ le
  decide +kernel
theorem b7317 : Blocked tgt 7 s7317 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7317 7 _ le
  decide +kernel
theorem b7318 : Blocked tgt 7 s7318 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7318 7 _ le
  decide +kernel

theorem b7319 : Blocked tgt 7 s7319 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7319 7 _ le
  decide +kernel
theorem b7320 : Blocked tgt 7 s7320 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7320 7 _ le
  decide +kernel
theorem b7321 : Blocked tgt 7 s7321 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7321 7 _ le
  decide +kernel
theorem b7322 : Blocked tgt 7 s7322 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7322 7 _ le
  decide +kernel
theorem b7323 : Blocked tgt 7 s7323 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7323 7 _ le
  decide +kernel
theorem b7324 : Blocked tgt 7 s7324 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7324 7 _ le
  decide +kernel
theorem b7325 : Blocked tgt 7 s7325 := by
  intro k le c
  apply rejects_sound r1 i6 7 tgt small1 hot1 [] s7325 7 _ le
  decide +kernel
theorem b7326 : Blocked tgt 7 s7326 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7326 7 _ le
  decide +kernel
theorem b7327 : Blocked tgt 7 s7327 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7327 7 _ le
  decide +kernel
theorem b7328 : Blocked tgt 7 s7328 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7328 7 _ le
  decide +kernel
theorem b7329 : Blocked tgt 7 s7329 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7329 7 _ le
  decide +kernel
theorem b7330 : Blocked tgt 7 s7330 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7330 7 _ le
  decide +kernel
theorem b7331 : Blocked tgt 7 s7331 := by
  intro k le c
  apply rejects_sound r19 i4 3 tgt small19 hot19 [] s7331 7 _ le
  decide +kernel
theorem b7332 : Blocked tgt 7 s7332 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [] s7332 7 _ le
  decide +kernel
theorem b7333 : Blocked tgt 7 s7333 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7333 7 _ le
  decide +kernel
theorem b7334 : Blocked tgt 7 s7334 := by
  intro k le c
  apply rejects_sound r14 i4 3 tgt small14 hot14 [] s7334 7 _ le
  decide +kernel

theorem b7335 : Blocked tgt 7 s7335 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7335 7 _ le
  decide +kernel
theorem b7336 : Blocked tgt 7 s7336 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7336 7 _ le
  decide +kernel
theorem b7337 : Blocked tgt 7 s7337 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7337 7 _ le
  decide +kernel
theorem b7338 : Blocked tgt 7 s7338 := by
  intro k le c
  apply rejects_sound r17 i4 3 tgt small17 hot17 [] s7338 7 _ le
  decide +kernel
theorem b7339 : Blocked tgt 7 s7339 := by
  intro k le c
  apply rejects_sound r11 i4 3 tgt small11 hot11 [] s7339 7 _ le
  decide +kernel
theorem b7340 : Blocked tgt 7 s7340 := by
  intro k le c
  apply rejects_sound r5 i5 6 tgt small5 hot5 [] s7340 7 _ le
  decide +kernel
theorem b7349 : Blocked tgt 7 s7349 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7349 7 _ le
  decide +kernel
theorem b7350 : Blocked tgt 7 s7350 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7350 7 _ le
  decide +kernel
theorem b7351 : Blocked tgt 7 s7351 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7351 7 _ le
  decide +kernel
theorem b7352 : Blocked tgt 7 s7352 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7352 7 _ le
  decide +kernel
theorem b7353 : Blocked tgt 7 s7353 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7353 7 _ le
  decide +kernel
theorem b7354 : Blocked tgt 7 s7354 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7354 7 _ le
  decide +kernel
theorem b7355 : Blocked tgt 7 s7355 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7355 7 _ le
  decide +kernel
theorem b7356 : Blocked tgt 7 s7356 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7356 7 _ le
  decide +kernel
theorem b7357 : Blocked tgt 7 s7357 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7357 7 _ le
  decide +kernel
theorem b7358 : Blocked tgt 7 s7358 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7358 7 _ le
  decide +kernel

theorem b7359 : Blocked tgt 7 s7359 := by
  intro k le c
  apply rejects_sound r8 i6 6 tgt small8 hot8 [] s7359 7 _ le
  decide +kernel
theorem b7360 : Blocked tgt 7 s7360 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7360 7 _ le
  decide +kernel
theorem b7361 : Blocked tgt 7 s7361 := by
  intro k le c
  apply rejects_sound r2 i5 6 tgt small2 hot2 [(false,(0,false),(2,true)),(true,(0,false),(5,false))] s7361 7 _ le
  decide +kernel
end PetersenSmallStarts.M191.Residual
