import PetersenCubicScalar
open PetersenBoostShift PetersenWordCost PetersenPhysicalWords PetersenPhysicalProjection
namespace PetersenIndexedReader
set_option maxRecDepth 30000
set_option maxHeartbeats 0
variable {n w : Nat}
local notation "B" => BitVec w

def gated (C : Net n) (i : Fin n) := C.kind i≠.source
instance (C : Net n) (i : Fin n) : Decidable (gated C i) := inferInstanceAs (Decidable (C.kind i≠.source))
def op (C : Net n) (i : Fin n) := decide (C.kind i=.disj)

def TapeWords (C : Net n) (v : Fin n→B) := ∀i,gated C i→v i=gate (op C i) (v (C.arg i false)) (v (C.arg i true))

/-- Reinterpret the network with every outgoing read of h replaced by zero. -/
def value (C : Net n) (v : Fin n→B) (h : Fin n) (i : Fin n) : B :=
  if _yes : gated C i then
    gate (op C i) (if C.arg i false=h then 0 else value C v h (C.arg i false))
      (if C.arg i true=h then 0 else value C v h (C.arg i true))
  else v i
termination_by i.val
decreasing_by all_goals apply C.causal i _yes

def operand (C : Net n) (v : Fin n→B) (h i : Fin n) (b : Bool) :=
  if C.arg i b=h then 0 else value C v h (C.arg i b)

private theorem gate_value (C : Net n) (v : Fin n→B) (h i : Fin n) (g : gated C i) :
    value C v h i=gate (op C i) (operand C v h i false) (operand C v h i true) := by
  rw [value];simp only [g,↓reduceDIte,operand]
private theorem input (C : Net n) (v : Fin n→B) (h i : Fin n) (g : ¬gated C i) :
    value C v h i=v i := by rw [value];simp [g]

private theorem before (C : Net n) {v : Fin n→B} (ev : TapeWords C v) (h i : Fin n) (lt : i.val≤h.val) : value C v h i=v i := by
  suffices all : ∀k:Nat,∀j:Fin n,j.val=k → j.val≤h.val → value C v h j=v j by exact all _ i rfl lt
  intro k;induction k using Nat.strong_induction_on with
  | ind k ih=>
    intro j eq le;by_cases g:gated C j
    · have same (s) : operand C v h j s=v (C.arg j s) := by
        have bj:=C.causal j g s
        have ne : C.arg j s≠h := by intro equal;rw [equal] at bj;omega
        simp only [operand,ne,ite_false];exact ih _ (eq ▸ bj) _ rfl (by omega)
      rw [gate_value C v h j g,same,same,←ev j g]
    · exact input C v h j g

private theorem bit (C : Net n) {v : Fin n→B} (ev : TapeWords C v) (h : Fin n) (r : Fin w) (zero : read (v h) r=false) :
    ∀i,read (value C v h i) r=read (v i) r := by
  have eval (p : Bool) (a b : B) : read (gate p a b) r=(if p then read a r || read b r else read a r && read b r) := by
    cases p <;> simp [gate,PetersenWordCost.read]
  suffices all : ∀k:Nat,∀j:Fin n,j.val=k → read (value C v h j) r=read (v j) r by exact fun i=>all _ i rfl
  intro k;induction k using Nat.strong_induction_on with
  | ind k ih=>
    intro j eq;by_cases g:gated C j
    · have same (s) : read (operand C v h j s) r=read (v (C.arg j s)) r := by
        by_cases sj:C.arg j s=h
        · rw [operand,if_pos sj,sj,zero];simp [PetersenWordCost.read]
        · simp only [operand,sj,ite_false];exact ih _ (eq ▸ C.causal j g s) _ rfl
      rw [gate_value C v h j g,ev j g,eval,eval,same,same]
    · rw [input C v h j g]

theorem restored (C : Net n) {v : Fin n→B} (ev : TapeWords C v) (h t : Fin n) :
    gate true (v h) (value C v h t)=v t|||v h := by
  apply read_inj;funext r
  change (v h|||value C v h t).getLsbD r.val=(v t|||v h).getLsbD r.val
  rw [BitVec.getLsbD_or,BitVec.getLsbD_or];change (read (v h) r || read (value C v h t) r)=(read (v t) r || read (v h) r)
  cases z:read (v h) r with
  | false=>rw [bit C ev h r z];simp
  | true=>simp

def paid (C : Net n) (v : Fin n→B) (h i : Fin n) := gated C i ∧ operand C v h i false≠0 ∧ operand C v h i true≠0
instance (C : Net n) (v : Fin n→B) (h i : Fin n) : Decidable (paid C v h i) := inferInstanceAs (Decidable (_ ∧ _ ∧ _))

def gates (C : Net n) := Finset.univ.filter (gated C)
def pays (C : Net n) (v : Fin n→B) (h : Fin n) := Finset.univ.filter (paid C v h)

private theorem raw_kept {I S : List B} {k} (p : Positive I k S) : I⊆S := by
  induction p with
  | start=>exact fun _ h=>h
  | add _ _ _ _ ih=>exact fun _ h=>List.mem_cons_of_mem _ (ih h)

/-- Build the modified network from the input basis. Only gates with two
nonzero modified operands are charged. All the earlier prefix values survive. -/
theorem build_subset {C : Net n} (v : Fin n→B) (h : Fin n) (I : List B) (has0 : 0∈I)
    (raw : ∀i,¬gated C i→v i∈I) (D : Finset (Fin n)) (closed : ∀i∈D,gated C i→∀s,C.arg i s∈D) :
    ∃Z,Positive I (D.filter (paid C v h)).card Z ∧ ∀i∈D,value C v h i∈Z := by
  induction D using Finset.strongInductionOn with
  | _ D ih=>
    by_cases ne:D.Nonempty
    · let tip:=D.max' ne
      have tm : tip∈D:=Finset.max'_mem D ne
      let E:=D.erase tip
      have beforeTip (j) (hj:j∈D) (g:gated C j) (s) : C.arg j s∈E := by
        have pred:=C.causal j g s
        have upper : j≤tip := Finset.le_max' D j hj
        exact Finset.mem_erase.mpr ⟨fun eq=>by rw [eq] at pred;omega,closed j hj g s⟩
      obtain ⟨Z,r,cov⟩:=ih E (Finset.erase_ssubset tm) (fun j mem=>beforeTip j (Finset.mem_of_mem_erase mem))
      have restore : insert tip E=D := Finset.insert_erase tm
      have notin : tip∉E := by simp [E]
      have noFilter : tip∉E.filter (paid C v h) := fun hm=>notin (Finset.mem_filter.mp hm).1
      have finish {Y : List B} (sub : Z⊆Y) (got : value C v h tip∈Y) : ∀j∈D,value C v h j∈Y := by
        intro j hj;by_cases eq:j=tip
        · exact eq ▸ got
        · exact sub (cov j (Finset.mem_erase.mpr ⟨eq,hj⟩))
      by_cases g:gated C tip
      · have operands (s) : operand C v h tip s ∈ Z := by
          unfold operand;split
          · exact raw_kept r has0
          · exact cov _ (beforeTip _ tm g s)
        have eq:=gate_value C v h tip g
        by_cases cost:paid C v h tip
        · have step:=Positive.add (op C tip) r (operands false) (operands true)
          refine ⟨gate (op C tip) (operand C v h tip false) (operand C v h tip true)::Z,?_,finish (fun _ q=>List.mem_cons_of_mem _ q) (by rw [eq];exact List.mem_cons_self)⟩
          rw [←restore,Finset.filter_insert];simp [cost,noFilter];exact step
        · have some0 : operand C v h tip false=0 ∨ operand C v h tip true=0 := by by_contra! no;exact cost ⟨g,no.1,no.2⟩
          have got : value C v h tip∈Z := by
            rw [eq];rcases some0 with z|z <;> rw [z] <;> cases op C tip <;> simp [gate] <;> first | exact raw_kept r has0 | exact operands _
          refine ⟨Z,?_,finish (fun _ q=>q) got⟩;rw [←restore,Finset.filter_insert];simpa [cost] using r
      · have noc : ¬paid C v h tip := fun q=>g q.1
        refine ⟨Z,?_,finish (fun _ q=>q) ((input C v h tip g) ▸ raw_kept r (raw tip g))⟩
        rw [←restore,Finset.filter_insert];simpa [noc] using r
    · have de:=Finset.not_nonempty_iff_eq_empty.mp ne;subst D;simp;exact ⟨I,Positive.start⟩

theorem build {C : Net n} (v : Fin n→B) (h : Fin n) (I : List B) (has0 : 0∈I)
    (raw : ∀i,¬gated C i→v i∈I) : ∃Z,Positive I (pays C v h).card Z ∧ ∀i,value C v h i∈Z := by
  obtain ⟨Z,p,all⟩:=build_subset v h I has0 raw Finset.univ (by simp)
  exact ⟨Z,p,fun i=>all i (Finset.mem_univ _)⟩

private theorem incl (C : Net n) (v : Fin n→B) (h : Fin n) : pays C v h ⊆ gates C := by
  intro i hi;exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp hi).2.1⟩

private theorem skip_one {C : Net n} {v : Fin n→B} {h i : Fin n} (gi : gated C i) (free : i∉pays C v h) :
    (pays C v h).card+1≤(gates C).card := by
  have sub : insert i (pays C v h) ⊆ gates C := Finset.insert_subset (Finset.mem_filter.mpr ⟨Finset.mem_univ _,gi⟩) (incl C v h)
  simpa [Finset.card_insert_of_notMem free] using Finset.card_le_card sub

private theorem skip_two {C : Net n} {v : Fin n→B} {h i j : Fin n} (gi : gated C i) (gj : gated C j) (ne : i≠j)
    (fi : i∉pays C v h) (fj : j∉pays C v h) : (pays C v h).card+2≤(gates C).card := by
  have sub : insert i (insert j (pays C v h)) ⊆ gates C := Finset.insert_subset (Finset.mem_filter.mpr ⟨Finset.mem_univ _,gi⟩)
    (Finset.insert_subset (Finset.mem_filter.mpr ⟨Finset.mem_univ _,gj⟩) (incl C v h))
  have fresh : i∉insert j (pays C v h) := by simp [ne,fi]
  have card:=Finset.card_le_card sub
  rw [Finset.card_insert_of_notMem fresh,Finset.card_insert_of_notMem fj] at card
  omega

private theorem free_arg {C : Net n} {v : Fin n→B} {h i : Fin n} {s:Bool}
    (z : operand C v h i s=0) : i∉pays C v h := by
  intro mem;obtain ⟨_,m,n⟩:=(Finset.mem_filter.mp mem).2
  cases s <;> contradiction

private theorem cut_arg {C : Net n} {v : Fin n→B} {h i : Fin n} {s:Bool}
    (edge : C.arg i s=h) : operand C v h i s=0 := by simp [operand,edge]

/-- If joining the output to h needs 16 gates, every direct reader of h is
the same OR gate in any connected 16-gate realization. -/
theorem unique_or_used {C : Net n} {v : Fin n→B} {I : List B} {h t : Fin n}
    (ev : TapeWords C v) (has0 : 0∈I) (raw : ∀i,¬gated C i→v i∈I)
    (budget : (gates C).card≤16)
    (live : ∀i,gated C i→i≠t→∃j s,gated C j ∧ C.arg j s=i)
    (used : ∃r s,gated C r ∧ C.arg r s=h) (lower : NoPhysical I (v t|||v h) 15) :
    ∃r,C.kind r=.disj ∧ ∀j s,gated C j→C.arg j s=h→j=r := by
  obtain ⟨Z,run,cov⟩:=build v h I has0 raw
  have haveH : v h∈Z := (before C ev h h (le_refl _)) ▸ cov h
  have combined:=Positive.add true run haveH (cov t)
  have hit : v t|||v h∈gate true (v h) (value C v h t)::Z := by rw [←restored C ev h t];exact List.mem_cons_self
  have unique (i j : Fin n) (gi:gated C i) (gj:gated C j) (fi : i∉pays C v h) (fj : j∉pays C v h) : i=j := by
    by_contra ne;have cost:=skip_two gi gj ne fi fj;exact lower _ (by omega) _ combined hit
  obtain ⟨r,s,gr,er⟩:=used
  have zero : operand C v h r s=0:=cut_arg er
  have fr:=free_arg zero
  have reader (j) (b:Bool) (gj:gated C j) (e:C.arg j b=h) : j=r :=
    unique _ _ gj gr (free_arg (cut_arg e)) fr
  refine ⟨r,?_,reader⟩
  by_contra noOR
  have dead : value C v h r=0 := by
    rw [gate_value C v h r gr];have cfg : op C r=false := decide_eq_false noOR
    rw [cfg];cases s <;> simp [gate,zero]
  by_cases out:r=t
  · have vt : v t|||v h=v h := by
      have restore:=restored C ev h t;rw [←out,dead] at restore
      simpa [out,gate] using restore.symm
    have cost:=skip_one gr fr
    exact lower _ (by omega) _ run (by rw [vt];exact haveH)
  · obtain ⟨j,b,gj,ej⟩:=live r gr out
    have zj : operand C v h j b=0 := by simp [operand,ej,dead]
    have eq:=unique j r gj gr (free_arg zj) fr
    have lt:=C.causal j gj b;rw [ej,eq] at lt;omega

theorem unique_or {C : Net n} {v : Fin n→B} {I : List B} {h t : Fin n}
    (ev : TapeWords C v) (has0 : 0∈I) (raw : ∀i,¬gated C i→v i∈I)
    (budget : (gates C).card≤16) (live : ∀i,i≠t→∃j s,gated C j ∧ C.arg j s=i)
    (distinct : h≠t) (lower : NoPhysical I (v t|||v h) 15) :
    ∃r,C.kind r=.disj ∧ ∀j s,gated C j→C.arg j s=h→j=r :=
  unique_or_used ev has0 raw budget (fun i _=>live i) (live h distinct) lower

/-- An ordinary size-16 lower bound forces every gate, aside from the output,
to have a reader even in an untrimmed net with dummy sources. -/
theorem gate_live_tight {K : Nat} {C : Net n} {v : Fin n→B} {I : List B} {t : Fin n}
    (ev : TapeWords C v) (has0 : 0∈I) (raw : ∀i,¬gated C i→v i∈I)
    (budget : (gates C).card≤K+1) (lower : NoPhysical I (v t) K) :
    ∀h,gated C h→h≠t→∃j s,gated C j ∧ C.arg j s=h := by
  intro h gh distinct
  by_contra! unused
  let D:=(Finset.univ : Finset (Fin n)).erase h
  have closed (i) (_:i∈D) (g:gated C i) (b) : C.arg i b∈D :=
    Finset.mem_erase.mpr ⟨unused i b g,Finset.mem_univ _⟩
  obtain ⟨Z,run,seen⟩:=build_subset v h I has0 raw D closed
  have eq (i : Fin n) : value C v h i=v i := by
    suffices all : ∀k:Nat,∀j:Fin n,j.val=k→value C v h j=v j by exact all _ i rfl
    intro k;induction k using Nat.strong_induction_on with
    | ind k ih=>
      intro j jv;by_cases g:gated C j
      · have same (b) : operand C v h j b=v (C.arg j b) := by
          simp only [operand,unused j b g,ite_false];exact ih _ (jv ▸ C.causal j g b) _ rfl
        rw [gate_value C v h j g,same,same,←ev j g]
      · exact input C v h j g
  have sub : D.filter (paid C v h) ⊆ (gates C).erase h := by
    intro i m;obtain ⟨hi,pr⟩:=Finset.mem_filter.mp m
    exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hi).1,Finset.mem_filter.mpr ⟨Finset.mem_univ _,pr.1⟩⟩
  have cost:=Finset.card_le_card sub
  have member : h∈gates C:=Finset.mem_filter.mpr ⟨Finset.mem_univ _,gh⟩
  rw [Finset.card_erase_of_mem member] at cost
  exact lower _ (by omega) _ run (eq t ▸ seen t (Finset.mem_erase.mpr ⟨Ne.symm distinct,Finset.mem_univ _⟩))

theorem gate_live {C : Net n} {v : Fin n→B} {I : List B} {t : Fin n}
    (ev : TapeWords C v) (has0 : 0∈I) (raw : ∀i,¬gated C i→v i∈I)
    (budget : (gates C).card≤16) (lower : NoPhysical I (v t) 15) :
    ∀h,gated C h→h≠t→∃j s,gated C j ∧ C.arg j s=h := gate_live_tight ev has0 raw budget lower

#print axioms gate_live
#print axioms build
#print axioms unique_or
end PetersenIndexedReader
