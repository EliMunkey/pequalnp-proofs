import PetersenIndexedRailShape
import PetersenMissingPositive
open PetersenBoostShift PetersenIndexedReader PetersenCubicLift PetersenOneAndLayer PetersenCubicScalar
  PetersenNineData PetersenPhysicalProjection PetersenScalarModels PetersenBypassRails PetersenIndexedLift
  PetersenIndexedRailShape PetersenIndexedPinPrice PetersenWordCost
namespace PetersenTwoRails
set_option maxRecDepth 50000
set_option maxHeartbeats 0
variable {n w : Nat} {C : Net n}

/-- Signed-ten hardness can be supplied through its elementary positive-table
corollary. On an 18-gate realizing DAG, this forces full-table gate liveness and
rules out a single gate reading both raw complementary literals. -/
theorem normalized {full : Fin n→BitVec w} {I : List (BitVec w)} {t pos neg : Fin n}
    (ev : TapeWords C full) (c0 : 0∈I) (c1 : ~~~0∈I) (raw : ∀i,¬gated C i→full i∈I)
    (hard : NoPhysical I (full t) 17) (length : (gates C).card≤18)
    (diff:pos≠neg) (comp : full pos= ~~~(full neg)) :
    (∀j,Reader C pos j→Reader C neg j→False) ∧ (∀i,gated C i→i≠t→∃j,Reader C i j) := by
  have size : (free C full).card≤0:=budget_gap (extra:=0) full ev I c0 c1 raw hard length
  constructor
  · rintro j ⟨g,s,sp⟩ ⟨_,b,bn⟩
    have neq:s≠b:=by intro e;subst b;exact diff (sp.symm.trans bn)
    have trivial : Trivial (full j) := by
      rw [ev j g];cases s <;> cases b <;> simp at neq <;> cases op C j <;> simp [gate,sp,bn,comp,Trivial]
    have unpaid : j∈free C full := by
      apply Finset.mem_sdiff.mpr;refine ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,g⟩,?_⟩
      intro p;exact (Finset.mem_filter.mp p).2.2.1 trivial
    have plus:=Finset.card_pos.mpr ⟨_,unpaid⟩;omega
  · intro i g ne;obtain ⟨j,s,gj,e⟩:=gate_live_tight ev c0 raw length hard i g ne
    exact ⟨j,gj,s,e⟩

/-- Both positive and negative raw mark have an actual read. The four lower
bounds are the full-ten ordinary corollary at 17 and three ordinary nine-input
targets at 15. The argument uses no signed-nine lower bound or root census. -/
theorem excludes {t pos neg : Fin n} {full : Fin n→BitVec w} {basisFull : List (BitVec w)}
    {data0 data1 old flag : Fin 512→Fin n→Bool}
    (evFull : TapeWords C full) (zeroMem : 0∈basisFull) (oneMem : ~~~0∈basisFull)
    (rawFull : ∀i,¬gated C i→full i∈basisFull) (full17 : NoPhysical basisFull (full t) 17)
    (comp : full pos= ~~~(full neg)) (pSource : C.kind pos=.source) (nSource : C.kind neg=.source)
    (ev0 : ∀x,Eval C (data0 x) emptyMask emptyMask (old x))
    (ev1 : ∀x,Eval C (data1 x) emptyMask emptyMask (flag x))
    (rails0 : ∀x,old x pos=false ∧ old x neg=true)
    (rails1 : ∀x,flag x pos=true ∧ flag x neg=false)
    (others : ∀x i,C.kind i=.source→i≠pos→i≠neg→flag x i=old x i)
    (mono : ∀x y,included x y→∀i,C.kind i=.source→ old x i=true→ old y i=true)
    (raw : ∀i,C.kind i=.source→wordOf (fun x=>old x i)∈PetersenNineProjected.basis)
    (out0 : ∀x,old x t=target (cube x)) (out1 : ∀x,flag x t=markedOn (cube x))
    (sinkGate : gated C t) (last : ∀j : Fin n,j.val≤t.val) (limit : (gates C).card≤18)
    (usesNegative : ∃j,Reader C neg j) (base : NoPhysical PetersenNineProjected.basis label 15)
    (one : Hard true false) (two : Hard true true) : False := by
  let v:=sampleNet old
  have hit : v t=label := by
    apply read_inj;funext j;change read (wordOf _) j=read label j;rw [wordOf,read_pack,labelRow];exact out0 _
  have pri (i) (h:¬gated C i) : v i∈PetersenNineProjected.basis:=raw i (Classical.byContradiction fun no=>h no)
  have hard : NoPhysical PetersenNineProjected.basis (v t) 15:=hit ▸ base
  have c0:(0:BitVec 24)∈PetersenNineProjected.basis:=by decide +kernel
  have c1 : ~~~(0:BitVec 24)∈PetersenNineProjected.basis:=by decide +kernel
  have cost: (free C v).card≤2:=budget _ (sampled_eval ev0) _ c0 c1 pri hard limit
  have sourceP : t≠pos:=by intro e;exact sinkGate (e ▸ pSource)
  have required :=PetersenMissingPositive.positive_required ev0 ev1 (pos:=pos) (fun x i src ne hi=>by
    by_cases nn:i=neg
    · subst i;exact (rails0 x).2
    · rwa [others x i src ne nn] at hi) out0 out1 sourceP
  obtain ⟨j,s,g,ps⟩:=required
  have distinct : pos≠neg:=by intro e;have a:=(rails0 0).1;rw [e,(rails0 0).2] at a;contradiction
  obtain ⟨separate,live⟩:=normalized evFull zeroMem oneMem rawFull full17 limit distinct comp
  have offp : v pos=0:=by apply read_inj;funext j;change read (wordOf _) j=read 0 j;rw [wordOf,read_pack];simpa [PetersenWordCost.read] using (rails0 (sample j)).1
  have offn : v neg= ~~~(0:BitVec 24):=by apply read_inj;funext j;change read (wordOf _) j=read (~~~0) j;rw [wordOf,read_pack];change old (sample j) neg=PetersenWordCost.read (~~~(0:BitVec 24)) j;rw [(rails0 (sample j)).2];revert j;decide +kernel
  have non : ¬Trivial (v t):=by rw [hit];decide +kernel
  obtain ⟨p,r,rp,rn⟩:=shape (sampled_eval ev0) offp offn pSource nSource ⟨j,g,s,ps⟩ usesNegative separate cost non live
  apply PetersenPhysicalRailLift.excludes r t ev0 ev1 _ _ _ mono raw out0 out1 sinkGate last limit base one two
  · simpa only [rp,rn] using rails0
  · simpa only [rp,rn] using rails1
  · simpa only [rp,rn] using others

#print axioms excludes
end PetersenTwoRails
