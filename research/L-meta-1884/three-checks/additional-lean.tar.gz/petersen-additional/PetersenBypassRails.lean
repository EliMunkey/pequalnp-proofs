import PetersenIndexedLift
open PetersenBoostShift PetersenIndexedReader PetersenCubicLift PetersenOneAndLayer PetersenCubicScalar
  PetersenNineData PetersenPhysicalProjection PetersenScalarModels
namespace PetersenBypassRails
set_option maxRecDepth 50000
set_option maxHeartbeats 0
variable {n : Nat}

structure Pair (C : Net n) where
  high : Fin n
  low : Fin n
  distinct : high≠low
  hs : Bool
  ls : Bool
  hg : gated C high
  lg : gated C low

variable {C : Net n}

def keep (p : Pair C) (i : Fin n) := i≠p.high ∧ i≠p.low
instance (p : Pair C) (i : Fin n) : Decidable (keep p i) := inferInstanceAs (Decidable (_ ∧ _))

/-- Chase the two ordinary pin identities. The two removed gates may themselves be adjacent. -/
def resolve (p : Pair C) (i : Fin n) : Fin n :=
  if u:i=p.high then resolve p (C.arg i p.hs)
  else if d:i=p.low then resolve p (C.arg i p.ls) else i
termination_by i.val
decreasing_by
  · exact C.causal i (u ▸ p.hg) _
  · exact C.causal i (d ▸ p.lg) _

private theorem chase_hi (p : Pair C) : resolve p p.high=resolve p (C.arg p.high p.hs) := by rw [resolve];simp
private theorem chase_lo (p : Pair C) : resolve p p.low=resolve p (C.arg p.low p.ls) := by rw [resolve];simp [Ne.symm p.distinct]
private theorem fixed (p : Pair C) (i : Fin n) (kept : keep p i) : resolve p i=i := by rw [resolve];simp [kept.1,kept.2]

theorem chased (p : Pair C) (i : Fin n) : keep p (resolve p i) ∧ ((resolve p i).val ≤ i.val) := by
  suffices h : ∀k:Nat,∀j:Fin n,j.val=k→keep p (resolve p j) ∧ ((resolve p j).val ≤ j.val) by exact h _ i rfl
  intro k;induction k using Nat.strong_induction_on with
  | ind k ih=>
    intro j jv
    by_cases u:j=p.high
    · subst j;rw [chase_hi]
      have lt:=C.causal _ p.hg p.hs;obtain ⟨z,v⟩:=ih _ (jv ▸ lt) _ rfl;exact ⟨z,by omega⟩
    by_cases d:j=p.low
    · subst j;rw [chase_lo]
      have lt:=C.causal _ p.lg p.ls;obtain ⟨z,v⟩:=ih _ (jv ▸ lt) _ rfl;exact ⟨z,by omega⟩
    · rw [fixed _ _ ⟨u,d⟩];exact ⟨⟨u,d⟩,le_refl _⟩

def net (p : Pair C) : Net n where
  kind i:=if keep p i then C.kind i else .source
  arg i s:=resolve p (C.arg i s)
  causal i g s:=by
    by_cases yes:keep p i
    · simp only [yes,ite_true] at g;exact lt_of_le_of_lt (chased _ _).2 (C.causal i g s)
    · simp [yes] at g

theorem gate_count (p : Pair C) : (gates (net p)).card+2=(gates C).card := by
  have eq : gates (net p)=((gates C).erase p.high).erase p.low := by
    ext i
    have mem (D : Net n) (z : Fin n) : z∈gates D ↔ gated D z :=
      ⟨fun h=>(Finset.mem_filter.mp h).2,fun h=>Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩⟩
    rw [mem,Finset.mem_erase,Finset.mem_erase,mem]
    change (if keep p i then C.kind i else .source)≠.source ↔ i≠p.low ∧ i≠p.high ∧ C.kind i≠.source
    by_cases a:i=p.high <;> by_cases b:i=p.low <;> simp [keep,a,b]
  have hi : p.high∈gates C:=Finset.mem_filter.mpr ⟨Finset.mem_univ _,p.hg⟩
  have lo : p.low∈(gates C).erase p.high:=Finset.mem_erase.mpr ⟨Ne.symm p.distinct,Finset.mem_filter.mpr ⟨Finset.mem_univ _,p.lg⟩⟩
  rw [eq,Finset.card_erase_of_mem lo,Finset.card_erase_of_mem hi]
  have a:=Finset.card_pos.mpr ⟨_,hi⟩;have b:=Finset.card_pos.mpr ⟨_,lo⟩
  rw [Finset.card_erase_of_mem hi] at b;omega

def keepValue (p : Pair C) (v : Fin n→Bool) (i : Fin n) := keep p i && v i
def sourceValue (p : Pair C) (v : Fin n→Bool) (i : Fin n) := keep p i && decide (C.kind i=.source) && v i

def baseline (p : Pair C) (v : Fin n→Bool) := v p.high=v (C.arg p.high p.hs) ∧ v p.low=v (C.arg p.low p.ls)

private theorem chase_value (p : Pair C) {v : Fin n→Bool} (base : baseline p v) (i : Fin n) : v (resolve p i)=v i := by
  suffices h : ∀k:Nat,∀j:Fin n,j.val=k→v (resolve p j)=v j by exact h _ i rfl
  intro k;induction k using Nat.strong_induction_on with
  | ind k ih=>
    intro j jv;by_cases u:j=p.high
    · subst j;rw [chase_hi,ih _ (jv ▸ C.causal _ p.hg p.hs) _ rfl,←base.1]
    by_cases d:j=p.low
    · subst j;rw [chase_lo,ih _ (jv ▸ C.causal _ p.lg p.ls) _ rfl,←base.2]
    · rw [fixed _ _ ⟨u,d⟩]

private theorem original_arg (p : Pair C) {v : Fin n→Bool} (base : baseline p v) (i) (s) :
    takeBit (net p) emptyMask emptyMask (keepValue p v) i s=v (C.arg i s) := by
  simp [takeBit,emptyMask,keepValue,net,(chased p (C.arg i s)).1,chase_value p base]

theorem ordinary {p : Pair C} {raw v : Fin n→Bool} (ev : Eval C raw emptyMask emptyMask v) (base : baseline p v) :
    Eval (net p) (sourceValue p v) emptyMask emptyMask (keepValue p v) := by
  intro i;by_cases yes:keep p i
  · have orig:=ev i
    change keepValue p v i=match (if keep p i then C.kind i else .source) with
      | .source=>sourceValue p v i
      | .disj=>takeBit (net p) emptyMask emptyMask (keepValue p v) i false || takeBit (net p) emptyMask emptyMask (keepValue p v) i true
      | .conj=>takeBit (net p) emptyMask emptyMask (keepValue p v) i false && takeBit (net p) emptyMask emptyMask (keepValue p v) i true
    simp only [yes,ite_true];cases k:C.kind i
    · simp [keepValue,sourceValue,k,yes]
    · rw [original_arg p base,original_arg p base];simpa [k,keepValue,yes,takeBit,emptyMask] using orig
    · rw [original_arg p base,original_arg p base];simpa [k,keepValue,yes,takeBit,emptyMask] using orig
  · simp [net,keepValue,sourceValue,yes]

def highMask (p : Pair C) : Mask n := fun i s=>decide (gated (net p) i ∧ C.arg i s=p.high)
def lowMask (p : Pair C) : Mask n := fun i s=>decide (C.arg i s=p.low)
def onValue (p : Pair C) (before after : Fin n→Bool) (i : Fin n) :=
  if gated (net p) i then after i else sourceValue p before i

def quiet (p : Pair C) (before after : Fin n→Bool) :=
  ∀i,gated (net p) i→∀s, C.kind (C.arg i s)=.source→after (C.arg i s)=before (C.arg i s)

private theorem mark_arg {p : Pair C} {before after : Fin n→Bool} (up : after p.high=true)
    (dn : after p.low=false) (fixedRaw : quiet p before after) {i} (g:gated (net p) i) (s) :
    takeBit (net p) (lowMask p) (highMask p) (onValue p before after) i s=after (C.arg i s) := by
  by_cases d:C.arg i s=p.low
  · simp [takeBit,lowMask,d,dn]
  by_cases u:C.arg i s=p.high
  · simp [takeBit,lowMask,highMask,d,u,g,up,Ne.symm p.distinct,p.distinct]
  have keepArg : keep p (C.arg i s):=⟨u,d⟩
  change (if lowMask p i s then false else if highMask p i s then true else onValue p before after (resolve p (C.arg i s)))=_
  simp only [highMask,lowMask,d,u,decide_false,Bool.false_eq_true,ite_false,and_false,fixed p _ keepArg]
  by_cases z:C.kind (C.arg i s)=.source
  · simpa [onValue,net,gated,keepArg,z,sourceValue] using (fixedRaw i g s z).symm
  · simp [onValue,net,gated,keepArg,z]

theorem marked {p : Pair C} {before after raw : Fin n→Bool} (ev : Eval C raw emptyMask emptyMask after)
    (hi : after p.high=true) (lo : after p.low=false) (q : quiet p before after) :
    Eval (net p) (sourceValue p before) (lowMask p) (highMask p) (onValue p before after) := by
  intro i
  by_cases g:gated (net p) i
  · have kept : keep p i:=by by_contra no;simp [gated,net,no] at g
    have orig:=ev i
    change onValue p before after i=match (if keep p i then C.kind i else .source) with
      | .source=>sourceValue p before i
      | .disj=>takeBit (net p) (lowMask p) (highMask p) (onValue p before after) i false || takeBit (net p) (lowMask p) (highMask p) (onValue p before after) i true
      | .conj=>takeBit (net p) (lowMask p) (highMask p) (onValue p before after) i false && takeBit (net p) (lowMask p) (highMask p) (onValue p before after) i true
    simp only [kept,ite_true,onValue,g];cases k:C.kind i
    · simp [gated,net,k,kept] at g
    · rw [mark_arg hi lo q g,mark_arg hi lo q g];simpa [k,takeBit,emptyMask] using orig
    · rw [mark_arg hi lo q g,mark_arg hi lo q g];simpa [k,takeBit,emptyMask] using orig
  · have eq : (net p).kind i=.source:=Classical.byContradiction fun no=>g no
    simp [eq,onValue,g]

#print axioms gate_count
#print axioms ordinary
#print axioms marked
end PetersenBypassRails
