import PetersenTwoRails
import PetersenDirectIndex
open PetersenSignedBridge PetersenBoostShift PetersenIndexedReader PetersenCubicLift PetersenOneAndLayer
  PetersenCubicScalar PetersenScalarModels PetersenIndexedRailShape PetersenWordCost PetersenPhysicalWords
  PetersenPhysicalProjection PetersenIndexedPinPrice PetersenDirectIndex
namespace PetersenScalarSource
set_option maxHeartbeats 0
set_option maxRecDepth 60000
abbrev rid := Fin rails.length
def neg : rid:=⟨2,by decide⟩
def pos : rid:=⟨3,by decide⟩
def dual := rails.map table
def pure := (0:BitVec 38)::(~~~(0:BitVec 38))::input
def originalToNine (i : Fin 10) : Fin 10:= ![9,4,0,1,6,7,3,5,2,8] i
def slice (x : Fin 512) (b : Bool) : PInput := fun i=>
  if h:(originalToNine i).val<9 then cube x ⟨(originalToNine i).val,h⟩ else b
private theorem targets (x : Fin 512) : PetersenTarget (slice x false)=PetersenNineData.target (cube x) ∧
    PetersenTarget (slice x true)=markedOn (cube x) := by revert x;decide +kernel
private theorem painted (j : rid) : wordOf (fun x=>rails.get j (slice x false))∈PetersenNineProjected.basis := by
  revert j;decide +kernel
private theorem constants (x : Fin 512) (b : Bool) : rails.get pos (slice x b)=b ∧ rails.get neg (slice x b)= !b := by revert x b;decide +kernel
private theorem quiet (i : rid) (pn:i≠pos) (nn:i≠neg) (x : Fin 512) : rails.get i (slice x true)=rails.get i (slice x false) := by
  revert i x;decide +kernel
private theorem plain (j : rid) (nn : j≠neg) : table (rails.get j)∈pure := by revert j;decide +kernel
private theorem sourceType (i : rid) : (∀x,rails.get i (slice x false)=false) ∨ (∀x,rails.get i (slice x false)=true) ∨
    ∃z:Fin 9,∀x,rails.get i (slice x false)=cube x z := by revert i;decide +kernel
private theorem upward (i : rid) (x y : Fin 512) (le:included x y) :
    rails.get i (slice x false)=true→ rails.get i (slice y false)=true := by
  rcases sourceType i with a|b|⟨j,h⟩
  · simp [a]
  · simp [b]
  · rw [h,h];exact le j

private theorem coded {m Z} (M : Model rails m Z) : TapeWords M.net (fun i=>table (M.val i)) := by
  intro i g;apply read_inj;funext j
  have ev:=M.eval (row j) i
  have bit (f : Func PInput) : PetersenWordCost.read (table f) j=f (row j) := by rw [table,read_pack];rfl
  have eval (s : Bool) (a b : BitVec 38) : PetersenWordCost.read (gate s a b) j=
      (if s then PetersenWordCost.read a j || PetersenWordCost.read b j else PetersenWordCost.read a j && PetersenWordCost.read b j) := by
    cases s <;> simp [PetersenWordCost.read,gate]
  rw [eval,bit,bit,bit];cases k:M.net.kind i
  · exact (g k).elim
  · simpa [op,k,takeBit,emptyMask] using ev
  · simpa [op,k,takeBit,emptyMask] using ev

private theorem absence {n} {C : Net n} {v : Fin n→BitVec 38} {t z : Fin n}
    (ev : TapeWords C v) (absent : ¬∃j,Reader C z j) (sink:gated C t) (rawZ : C.kind z=.source)
    (raw : ∀i,¬gated C i→i≠z→v i∈pure) (cost : (gates C).card≤18)
    (lower : NoPhysical pure (v t) 18) : False := by
  let u:=Function.update v z 0
  have old (i : Fin n) (ne : i≠z) : u i=v i:=Function.update_of_ne ne ..
  have before (i) (g:gated C i) (s) : C.arg i s≠z:=fun eq=>absent ⟨i,g,s,eq⟩
  have good:TapeWords C u:=by
    intro i g;rw [old i (fun e=>g (e ▸ rawZ)),old _ (before i g false),old _ (before i g true)];exact ev i g
  have inps (i) (source:¬ gated C i) : u i∈pure:=by
    by_cases eq:i=z
    · subst i;simp [u,pure]
    · rw [old _ eq];exact raw _ source eq
  obtain ⟨W,run,see⟩:=PetersenIndexedPinPrice.build u good pure (by simp [pure]) (by simp [pure]) inps
  have sub : charged C u ⊆ gates C := fun j h=>Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp h).2.1⟩
  have le:=Finset.card_le_card sub
  have dest:=see t;rw [old t (fun h=>sink (h ▸ rawZ))] at dest
  exact lower _ (by omega) _ run dest

/-- An original all-paid physical candidate reduces to four small scalar/pure
obligations, in addition to the full signed-ten bound through seventeen gates. -/
theorem excludes (full17 : NoPhysical dual target 17) (pure18 : NoPhysical pure target 18)
    (ordinary : NoPhysical PetersenNineProjected.basis PetersenNineData.label 15)
    (one : Hard true false) (two : Hard true true) :
    ∀k≤18,∀W,Direct rails k W→PetersenTarget∉W := by
  intro k bound W run out
  have notRaw:PetersenTarget∉rails:=by
    intro mem;have hit:target∈dual:=List.mem_map.mpr ⟨_,mem,rfl⟩
    have no : target∉dual:=by decide +kernel
    exact no hit
  obtain ⟨m,le,Z,M,t,output,sink,last⟩:=PetersenDirectIndex.output (⟨0,by decide⟩:rid) run notRaw out
  have cost:(gates M.net).card≤18:=by rw [M.cost];omega
  obtain ⟨ps,psrc,pi⟩:=M.source_all pos
  obtain ⟨ns,nsrc,ni⟩:=M.source_all neg
  have distinguish (i j) (si:M.net.kind i=.source) (sj:M.net.kind j=.source) (ne:i≠j) : M.input i≠M.input j :=
    fun e=>ne (M.source_unique _ _ si sj e)
  let whole:=fun i=>table (M.val i)
  have target0:whole t=target:=congrArg table output
  have no17:NoPhysical dual (whole t) 17:=target0 ▸ full17
  have noPure:NoPhysical pure (whole t) 18:=target0 ▸ pure18
  have picked0:=M.raw ps psrc;rw [pi] at picked0
  have picked1:=M.raw ns nsrc;rw [ni] at picked1
  by_cases used:∃j,Reader M.net ns j
  · have rFull (i) (s:¬gated M.net i) : whole i∈dual:=by
      have so:M.net.kind i=.source:=Classical.byContradiction fun e=>s e
      exact List.mem_map.mpr ⟨_,List.get_mem rails _,congrArg table (M.raw i so).symm⟩
    have comp:whole ps= ~~~(whole ns):=by
      change table (M.val ps)= ~~~(table (M.val ns));rw [picked0,picked1];decide +kernel
    apply PetersenTwoRails.excludes (C:=M.net) (t:=t) (pos:=ps) (neg:=ns) (old:=fun x i=>M.val i (slice x false)) (flag:=fun x i=>M.val i (slice x true))
      (coded M) (by decide +kernel) (by decide +kernel) rFull no17 comp psrc nsrc (fun x=>M.eval (slice x false)) (fun x=>M.eval (slice x true)) _ _ _ _ _ _ _ sink last cost used ordinary one two
    · intro x;rw [picked0,picked1];exact constants x false
    · intro x;rw [picked0,picked1];exact constants x true
    · intro x i so np nn;rw [M.raw i so]
      exact quiet (M.input i) (pi ▸ distinguish i ps so psrc np) (ni ▸ distinguish i ns so nsrc nn) x
    · intro x y le i so;rw [M.raw i so];exact upward _ _ _ le
    · intro i so;rw [M.raw i so];exact painted _
    · intro x;rw [output];exact (targets x).1
    · intro x;rw [output];exact (targets x).2
  · apply absence (coded M) used sink nsrc _ cost noPure
    intro i nsour ne
    have so:M.net.kind i=.source:=Classical.byContradiction fun e=>nsour e
    rw [M.raw i so];exact plain _ (ni ▸ distinguish i ns so nsrc ne)

#print axioms excludes
end PetersenScalarSource
