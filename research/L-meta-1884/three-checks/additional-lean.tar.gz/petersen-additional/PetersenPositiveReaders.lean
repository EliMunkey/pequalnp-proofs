import PetersenReaderPrefix
import PetersenPositiveDominance
open PetersenAntichain PetersenDirectReaders PetersenWordCost PetersenPhysicalWords PetersenDominantPin PetersenMonotoneFrontier
open PetersenPackedPin
namespace PetersenPositiveReaders
variable {w u : Nat}
local notation "B" => BitVec w

theorem cost {S T : Finset B} {es} (p : Tape S es T) (r : Fin u→Fin w) (q : BitVec u)
    {I V : List (BitVec u)} {k} (pre : Positive I k V) (cs : 0∈V ∧ ~~~0∈V)
    (supply : ∀ v∈S,PetersenPositiveDominance.Good r q V v) :
    ∃ Z,Positive I (k+tally (fun g=> !lost r q g) es) Z ∧ ∀v∈T,PetersenPositiveDominance.Good r q Z v := by
  induction p generalizing k V with
  | nil => exact ⟨V,by simpa [tally] using pre,supply⟩
  | @step K es T g ne fresh _ ih =>
    obtain ⟨Y,run,new,sub⟩:=PetersenPositiveDominance.advance r q
      (show Plain g.a g.b g.out from ⟨g.op,rfl⟩) pre cs
      (supply _ (Finset.mem_insert_self ..)) (supply _ (Finset.mem_insert_of_mem (Finset.mem_insert_self ..)))
    have next (v) (mem : v∈insert g.out K) : PetersenPositiveDominance.Good r q Y v := by
      rcases Finset.mem_insert.mp mem with rfl|old
      · exact new
      · obtain ⟨y,hy,best⟩:=supply v (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem old))
        exact ⟨y,sub hy,best⟩
    obtain ⟨Z,h,all⟩:=ih run ⟨sub cs.1,sub cs.2⟩ next
    have charge : PetersenTracePin.debit (fun v=>forced r q v=true) g.a g.b = (!lost r q g).toNat := by
      cases ha:forced r q g.a <;> cases hb:forced r q g.b <;> simp [PetersenTracePin.debit,lost,ha,hb]
    exact ⟨Z,by simpa only [charge,tally,Nat.add_assoc] using h,all⟩

theorem remaining {S : Finset B} {t : B} {es} (p : Tape S es {t}) (r : Fin u→Fin w)
    (I : List (BitVec u)) (K : Nat) (small : PetersenPhysicalProjection.NoPhysical I (project r t) K)
    (cs : 0∈I ∧ ~~~0∈I) (supply : ∀v∈S,PetersenPositiveDominance.Good r (project r t) I v) :
    K+1≤tally (fun g=> !lost r (project r t) g) es := by
  obtain ⟨Z,run,all⟩:=cost p r (project r t) (Positive.start (I:=I)) cs supply
  obtain ⟨y,hy,better⟩:=all t (Finset.mem_singleton_self _)
  rw [sink better] at hy
  by_contra! weak
  exact small (tally (fun g=> !lost r (project r t) g) es) (by omega) Z (by simpa using run) hy

/-- The forced complementary-rail count uses an ordinary positive lower bound.
The small simulation makes direct positive gates only. -/
theorem marked {S : Finset B} {t x : B} {es} (p : Tape S es {t}) (r : Fin u→Fin w)
    (I : List (BitVec u)) (K : Nat) (small : PetersenPhysicalProjection.NoPhysical I (project r t) K)
    (cs : 0∈I ∧ ~~~0∈I) (supply : ∀v∈S,PetersenPositiveDominance.Good r (project r t) I v)
    (distinct : x ≠ ~~~x) (cz : forced r (project r t) x=true) (co : forced r (project r t) (~~~x)=true)
    (proper : ∀g∈es,g.out≠0 ∧ g.out≠~~~0) :
    K+1+tally (reads x) es+tally (reads (~~~x)) es ≤ es.length :=
  PetersenReaderPrefix.marked_charge r (remaining p r I K small cs supply) distinct cz co proper

#print axioms marked
end PetersenPositiveReaders
