import PetersenBoostShift
open PetersenBoostShift PetersenOneAndLayer PetersenNineData
namespace PetersenCubicLift
set_option maxRecDepth 40000
set_option maxHeartbeats 0
abbrev R:=Fin 512
variable {n : Nat}
def emptyMask : Mask n:=fun _ _=>false

/-- One run is pointwise below an ordinary run if all overridden-high sockets
already read true in the ordinary run. The rows of the two runs may differ. -/
theorem compare {C : Net n} {raw bigRaw a b : Fin n→Bool} {L H : Mask n}
    (small : Eval C raw L H a) (large : Eval C bigRaw emptyMask emptyMask b)
    (sources : ∀i,raw i=true → bigRaw i=true)
    (highOK : ∀i s, C.kind i≠.source → L i s=false → H i s=true → b (C.arg i s)=true) : ∀i,a i=true → b i=true := by
  suffices go : ∀j:Nat,∀i:Fin n,i.val=j → a i=true → b i=true by exact fun i=>go i.val i rfl
  intro j;induction j using Nat.strong_induction_on with
  | ind j ih=>
    intro i eq h
    have lo:=small i;have hi:=large i
    have arg (s : Bool) (non : C.kind i≠.source) : takeBit C L H a i s=true → b (C.arg i s)=true := by
      intro on;cases l:L i s <;> cases upper:H i s <;> simp [takeBit,l,upper] at on
      · exact ih (C.arg i s).val (eq ▸ C.causal i non s) _ rfl on
      · exact highOK i s non l upper
    rw [lo] at h;rw [hi]
    cases op:C.kind i with
    | source=>simp [op] at h ⊢;exact sources i h
    | disj=>
      simp only [op] at h ⊢;simp only [takeBit,emptyMask,ite_false,Bool.false_eq_true]
      exact Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp h).imp (arg false (by simp [op])) (arg true (by simp [op])))
    | conj=>
      simp only [op] at h ⊢;simp only [takeBit,emptyMask,ite_false,Bool.false_eq_true]
      exact Bool.and_eq_true_iff.mpr ((Bool.and_eq_true_iff.mp h).imp (arg false (by simp [op])) (arg true (by simp [op])))

def normalizeMask (C : Net n) (H : Mask n) : Mask n := fun i s=>decide (C.kind i≠.source) && H i s
private theorem clean {C : Net n} {data v} {L H : Mask n} (ev : Eval C data L H v) : Eval C data L (normalizeMask C H) v := by
  intro i;have h:=ev i;cases e:C.kind i <;> simp [e,takeBit,normalizeMask] at h ⊢ <;> exact h

/-- A fixed low override may touch arbitrary sockets. A boost has a single
ordinary input wire, and may initially select any subset of its outgoing sockets. -/
def Works (C : Net n) (data : R→Fin n→Bool) (L : Mask n) (sink anchor : Fin n) :=
  ∃H : Mask n, (∀j s,H j s=true → C.kind j≠.source ∧ C.arg j s=anchor) ∧
    ∀x,∃v,Eval C (data x) L H v ∧ v sink=markedOn (cube x)

def included (a b : R) := ∀i:V,cube a i=true → cube b i=true
private def probes : Fin 3→R := ![16,64,128]
private def add (a b : R) : R := Fin.ofNat 512 (a.val ||| b.val)
private theorem unionFacts (a : R) (j : Fin 3) : included a (add a (probes j)) ∧
    included (probes j) (add a (probes j)) ∧ markedOn (cube (probes j))=true := by
  revert a j;unfold included;decide +kernel
private theorem badRow (a : R) (off : target (cube a)=false) (ab : a≠42) (ba : a≠261) :
    ∃j : Fin 3,target (cube (add a (probes j)))=false := by revert a;decide +kernel

theorem allowed {C : Net n} {data old : R→Fin n→Bool} {L : Mask n} {root anchor : Fin n}
    (mono : ∀a b,included a b → ∀i,data a i=true → data b i=true)
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x))
    (off : ∀x,old x root=target (cube x)) (w : Works C data L root anchor) {x}
    (on : old x anchor=true) : target (cube x)=true ∨ x=42 ∨ x=261 := by
  obtain ⟨H,owned,yes⟩:=w
  by_contra! h
  have zero : target (cube x)=false := by simpa using h.1
  obtain ⟨j,wrong⟩:=badRow x zero h.2.1 h.2.2
  obtain ⟨xz,pz,pOn⟩:=unionFacts x j
  let z:=add x (probes j)
  have up : old z anchor=true:=compare (ev x) (ev z) (mono _ _ xz) (fun _ _ _ _ h=>Bool.noConfusion h) anchor on
  obtain ⟨v,rv,out⟩:=yes (probes j)
  have contradiction:=compare rv (ev z) (mono _ _ pz) (fun i s _ _ h=>(owned i s h).2 ▸ up) root (out ▸ pOn)
  rw [off,wrong] at contradiction;exact Bool.noConfusion contradiction

theorem push {C : Net n} {data old : R→Fin n→Bool} {L : Mask n} {root i : Fin n}
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) (off : ∀x,old x root=target (cube x))
    (finalIndex : ∀j : Fin n,j.val≤root.val) (w : Works C data L root i)
    (law : i≠root → ∃r,C.kind r=.disj ∧ ∀j s,C.kind j≠.source → C.arg j s=i → j=r) :
    ∃j,i.val < j.val ∧ Works C data L root j := by
  obtain ⟨H,owned,ok⟩:=w
  have active : ∃j s,L j s=false ∧ H j s=true := by
    by_contra! no
    obtain ⟨v,sv,vs⟩:=ok 128
    have onProbe : markedOn (cube 128)=true := by decide
    have hit:=compare sv (ev 128) (fun _ h=>h) (fun j s _ l h=>(no j s l h).elim) root (vs ▸ onProbe)
    have noProbe : target (cube 128)=false := by decide
    rw [off,noProbe] at hit;exact Bool.noConfusion hit
  obtain ⟨j,s,ls,hs⟩:=active
  obtain ⟨nj,src⟩:=owned j s hs
  have ij := src ▸ C.causal j nj s
  have beyond := finalIndex j
  have ne : i≠root := by intro eq;subst i;omega
  obtain ⟨r,disj,sole⟩:=law ne
  obtain rfl:=sole j s nj src
  have only (p) (k) (h : H p k=true) : p=j := sole p k (owned p k h).1 (owned p k h).2
  have notRoot : j≠root := by
    intro eq;obtain ⟨v,rv,f⟩:=ok 0
    have y:=rv j;rw [disj] at y
    cases s <;> simp [takeBit,ls,hs] at y <;> rw [eq,f] at y <;> exact Bool.noConfusion y
  refine ⟨j,ij,normalizeMask C (allUses C j),?_,?_⟩
  · intro p k h;obtain ⟨op,arg⟩:=Bool.and_eq_true_iff.mp h
    exact ⟨of_decide_eq_true op,of_decide_eq_true arg⟩
  · intro x;obtain ⟨v,rv,ch⟩:=ok x
    obtain ⟨u,eu,same⟩:=shift rv disj only ⟨s,ls,hs⟩
    exact ⟨u,clean eu,(same root (Ne.symm notRoot)).trans ch⟩

/-- `readerLaw` is the index-level shape proved for fresh minimum tapes by
`PetersenForcingWire.one_or`: every strict forcing signal has one OR reader.
With this shape the negative marked slice forces an independent cubic minterm
at an equivalent latest positive intervention on this very same ordinary DAG. -/
theorem cubic {C : Net n} {data old : R→Fin n→Bool} {L : Mask n} {root : Fin n}
    (mono : ∀a b,included a b → ∀i,data a i=true → data b i=true)
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x))
    (off : ∀x,old x root=target (cube x)) (finalIndex : ∀j : Fin n,j.val≤root.val)
    (readerLaw : ∀i, i≠root → (∀x,old x i=true→target (cube x)=true) →
      ∃r,C.kind r=.disj ∧ ∀j s,C.kind j≠.source→C.arg j s=i→j=r)
    (has : ∃i,Works C data L root i) :
    ∃i, Works C data L root i ∧ (old 42 i=true ∨ old 261 i=true) ∧
      (∀x,old x i=true → target (cube x)=true ∨ x=42 ∨ x=261) := by
  let avoid:Fin n→Prop:=fun i=>∀x,old x i=true → target (cube x)=true
  have move (i) (w : Works C data L root i) (good : avoid i) : ∃j,i.val < j.val ∧ Works C data L root j :=
    push ev off finalIndex w (fun ne=>readerLaw i ne good)
  obtain ⟨last,work,bad⟩:=latest has move
  change ¬∀x,old x last=true→target (cube x)=true at bad
  push Not at bad
  obtain ⟨x,on,nok⟩:=bad
  have all (k : R) : old k last=true → target (cube k)=true ∨ k=42 ∨ k=261 := allowed mono ev off work
  rcases all x on with ok|rfl|rfl
  · exact (nok ok).elim
  · exact ⟨last,work,Or.inl on,all⟩
  · exact ⟨last,work,Or.inr on,all⟩

#print axioms cubic
end PetersenCubicLift
