import PetersenPhysicalRailLift
open PetersenWordCost PetersenBoostShift PetersenIndexedReader PetersenPhysicalWords PetersenPhysicalProjection
namespace PetersenIndexedPinPrice
set_option maxHeartbeats 0
set_option maxRecDepth 40000
variable {n w : Nat}
local notation "B" => BitVec w

def Trivial (z : B) := z=0 ∨ z= ~~~(0:B)
instance (z : B) : Decidable (Trivial z) := inferInstanceAs (Decidable (_ ∨ _))
def due (C : Net n) (v : Fin n→B) (i : Fin n) :=
  gated C i ∧ ¬Trivial (v i) ∧ ¬Trivial (v (C.arg i false)) ∧ ¬Trivial (v (C.arg i true))
instance (C : Net n) (v : Fin n→B) (i : Fin n) : Decidable (due C v i) := inferInstanceAs (Decidable (_ ∧ _ ∧ _ ∧ _))
def charged (C : Net n) (v : Fin n→B) := Finset.univ.filter (due C v)

private theorem kept {I S : List B} {k} (p : Positive I k S) : I⊆S := by
  induction p with
  | start=>exact fun _ h=>h
  | add _ _ _ _ ih=>exact fun _ h=>List.mem_cons_of_mem _ (ih h)

private theorem cheap (s : Bool) {a b : B} (q : Trivial a ∨ Trivial b) :
    gate s a b=a ∨ gate s a b=b ∨ Trivial (gate s a b) := by
  rcases q with (z|z)|(z|z) <;> subst_vars <;> cases s <;> simp [gate,Trivial]

/-- A constant output or a constant operand has zero cost on the pinned table. -/
theorem build {C : Net n} (v : Fin n→B) (ev : TapeWords C v) (I : List B) (c0 : (0:B)∈I) (c1 : ~~~(0:B)∈I)
    (raw : ∀i,¬gated C i→v i∈I) : ∃Z,Positive I (charged C v).card Z ∧ ∀i,v i∈Z := by
  have sub (D : Finset (Fin n)) (closed : ∀i∈D,gated C i→∀s,C.arg i s∈D) :
      ∃Z,Positive I (D.filter (due C v)).card Z ∧ ∀i∈D,v i∈Z := by
    induction D using Finset.strongInductionOn with
    | _ D ih=>
      by_cases ne:D.Nonempty
      · let tip:=D.max' ne
        have mem:tip∈D:=Finset.max'_mem D ne
        let E:=D.erase tip
        have prev (j) (hj:j∈D) (g:gated C j) (s) : C.arg j s∈E := by
          have pred:=C.causal j g s;have upper : j≤tip:=Finset.le_max' D j hj
          exact Finset.mem_erase.mpr ⟨fun e=>by rw [e] at pred;omega,closed j hj g s⟩
        obtain ⟨Z,r,cover⟩:=ih E (Finset.erase_ssubset mem) (fun j h=>prev j (Finset.mem_of_mem_erase h))
        have join : insert tip E=D:=Finset.insert_erase mem
        have fresh : tip∉E.filter (due C v) := by simp [E]
        have extend {Y : List B} (old : Z⊆Y) (got : v tip∈Y) : ∀j∈D,v j∈Y := by
          intro j hj;by_cases e:j=tip
          · exact e ▸ got
          · exact old (cover _ (Finset.mem_erase.mpr ⟨e,hj⟩))
        have constants (z : B) (t:Trivial z) : z∈Z := by rcases t with rfl|rfl;exact kept r c0;exact kept r c1
        by_cases pay:due C v tip
        · have step:=Positive.add (op C tip) r (cover _ (prev _ mem pay.1 false)) (cover _ (prev _ mem pay.1 true))
          refine ⟨gate (op C tip) (v (C.arg tip false)) (v (C.arg tip true))::Z,?_,extend (fun _ h=>List.mem_cons_of_mem _ h) (by rw [ev tip pay.1];exact List.mem_cons_self)⟩
          rw [←join,Finset.filter_insert];simp [pay,fresh];exact step
        · have hit:v tip∈Z := by
            by_cases g:gated C tip
            · by_cases const:Trivial (v tip)
              · exact constants _ const
              · have operand:Trivial (v (C.arg tip false)) ∨ Trivial (v (C.arg tip true)) := by
                  by_contra! no;exact pay ⟨g,const,no.1,no.2⟩
                have c:=cheap (op C tip) operand;rw [←ev tip g] at c
                rcases c with e|e|c
                · rw [e];exact cover _ (prev _ mem g false)
                · rw [e];exact cover _ (prev _ mem g true)
                · exact constants _ c
            · exact kept r (raw tip g)
          refine ⟨Z,?_,extend (fun _ h=>h) hit⟩;rw [←join,Finset.filter_insert];simpa [pay] using r
      · have emp:=Finset.not_nonempty_iff_eq_empty.mp ne;subst D;simp;exact ⟨I,Positive.start⟩
  obtain ⟨Z,r,all⟩:=sub Finset.univ (by simp)
  exact ⟨Z,r,fun i=>all _ (Finset.mem_univ i)⟩

theorem budget_gap {K extra : Nat} {C : Net n} (v : Fin n→B) (ev : TapeWords C v) (I : List B) (c0 : (0:B)∈I) (c1 : ~~~(0:B)∈I)
    (raw : ∀i,¬gated C i→v i∈I) {t} (lower : NoPhysical I (v t) K) (limit : (gates C).card≤K+1+extra) :
    ((gates C) \ (charged C v)).card≤extra := by
  obtain ⟨Z,run,seen⟩:=build v ev I c0 c1 raw
  have price : K+1≤(charged C v).card:=by by_contra! bad;exact lower _ (by omega) _ run (seen t)
  have sub:charged C v⊆gates C:=fun i h=>Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp h).2.1⟩
  rw [Finset.card_sdiff,Finset.inter_eq_left.mpr sub];omega

theorem budget {C : Net n} (v : Fin n→B) (ev : TapeWords C v) (I : List B) (c0 : (0:B)∈I) (c1 : ~~~(0:B)∈I)
    (raw : ∀i,¬gated C i→v i∈I) {t} (lower : NoPhysical I (v t) 15) (limit : (gates C).card≤18) :
    ((gates C) \ (charged C v)).card≤2 := budget_gap v ev I c0 c1 raw lower limit

#print axioms budget
end PetersenIndexedPinPrice
