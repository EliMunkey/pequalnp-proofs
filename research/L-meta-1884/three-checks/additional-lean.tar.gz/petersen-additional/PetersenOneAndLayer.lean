import PetersenNineData
open PetersenNineData
namespace PetersenOneAndLayer
abbrev X := V→Bool

def single (i : V) : X := fun j=>decide (i=j)
def join (x y : X) : X := fun i=>x i || y i
def markedOn (x : X) := target x || x 4 || x 6 || x 7

/-- Each surviving vertex misses at least one neighbor of deleted vertex 9. -/
theorem geometry (v : V) : ∃y : V, markedOn (single y)=true ∧ target (join (single y) (single v))=false := by
  revert v;decide

/-- Expanding a circuit's fan-out into a tree preserves selective interventions:
a designated ordinary wire may have only some of its outgoing uses replaced by
1, while arbitrary other uses may be replaced by 0. The ordinary interpretation
ignores these annotations. -/
inductive Tree where
  | var : V→Tree
  | lit : Bool→Tree
  | disj : Tree→Tree→Tree
  | conj : Tree→Tree→Tree
  | high : Tree→Tree
  | low : Tree→Tree

def ordinary : Tree→X→Bool
  | .var i,x=>x i
  | .lit b,_=>b
  | .disj a b,x=>ordinary a x || ordinary b x
  | .conj a b,x=>ordinary a x && ordinary b x
  | .high a,x=>ordinary a x
  | .low a,x=>ordinary a x

def lifted : Tree→X→Bool
  | .var i,x=>x i
  | .lit b,_=>b
  | .disj a b,x=>lifted a x || lifted b x
  | .conj a b,x=>lifted a x && lifted b x
  | .high _,_=>true
  | .low _,_=>false

def andDepth : Tree→Nat
  | .var _|.lit _=>0
  | .disj a b => max (andDepth a) (andDepth b)
  | .conj a b => max (andDepth a) (andDepth b)+1
  | .high a | .low a=>andDepth a

def sameBoost (h : X→Bool) : Tree→Prop
  | .var _|.lit _=>True
  | .disj a b|.conj a b=>sameBoost h a ∧ sameBoost h b
  | .high a=>ordinary a=h ∧ sameBoost h a
  | .low a=>sameBoost h a

theorem upper (a : Tree) {h : X→Bool} (common : sameBoost h a) {x y : X}
    (xy : ∀i,x i=true → y i=true) (high : h y=true) : lifted a x=true → ordinary a y=true := by
  induction a with
  | var i => exact xy i
  | lit i => exact id
  | high a ih => intro _;exact congrFun common.1 y ▸ high
  | low a ih => simp [lifted]
  | disj a b ia ib =>
    exact fun u=>Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp u).imp (ia common.1) (ib common.2))
  | conj a b ia ib =>
    exact fun u=>Bool.and_eq_true_iff.mpr ((Bool.and_eq_true_iff.mp u).imp (ia common.1) (ib common.2))

theorem mono (a : Tree) {x y : X} (xy : ∀i,x i=true → y i=true) :
    ordinary a x=true → ordinary a y=true := by
  induction a with
  | var i => exact xy i
  | lit _ => exact id
  | high _ ih | low _ ih => exact ih
  | disj _ _ ia ib => exact fun u=>Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp u).imp ia ib)
  | conj _ _ ia ib => exact fun u=>Bool.and_eq_true_iff.mpr ((Bool.and_eq_true_iff.mp u).imp ia ib)

theorem boost_mono (a : Tree) {h : X→Bool} (common : sameBoost h a)
    (has : ∃b : Tree,ordinary b=h) {x y : X} (xy : ∀i,x i=true → y i=true) :
    h x=true → h y=true := by
  obtain ⟨b,rfl⟩:=has;exact mono b xy

/-- Every marked singleton extends any assignment accepted by the boosted signal
into the ordinary nine predicate. This follows from intervention monotonicity. -/
theorem extensions (a : Tree) {h : X→Bool} (common : sameBoost h a)
    (real : ∃b : Tree,ordinary b=h) (old : ordinary a=target) (new : lifted a=markedOn)
    (x : X) (on : h x=true) (v : V) (needed : markedOn (single v)=true) :
    target (join (single v) x)=true := by
  have raised:=boost_mono a common real (x:=x) (y:=join (single v) x)
    (fun i yes=>Bool.or_eq_true_iff.mpr (Or.inr yes)) on
  rw [←old]
  exact upper a common (x:=single v) (y:=join (single v) x)
    (fun i yes=>Bool.or_eq_true_iff.mpr (Or.inl yes)) raised (new ▸ needed)

def cube (v : Fin 512) : X := fun i=>v.val.testBit i.val

private theorem geometry_cube (v : Fin 512) (neg : target (cube v)=false)
    (h42 : v≠42) (h261 : v≠261) : ∃j : V, markedOn (single j)=true ∧
      target (join (single j) (cube v))=false := by
  revert v; decide +kernel

/-- The only independent inputs the boosted signal may accept are the two
alternating triples of the six-cycle remaining after removing the three neighbors. -/
theorem possible_on (a : Tree) {h : X→Bool} (common : sameBoost h a)
    (real : ∃b : Tree,ordinary b=h) (old : ordinary a=target) (new : lifted a=markedOn)
    (v : Fin 512) (on : h (cube v)=true) : target (cube v)=true ∨ v=42 ∨ v=261 := by
  by_contra! no
  have neg : target (cube v)=false := by simpa using no.1
  obtain ⟨j,needed,miss⟩:=geometry_cube v neg no.2.1 no.2.2
  have yes:=extensions a common real old new (cube v) on j needed
  rw [miss] at yes;exact Bool.noConfusion yes

/-- The boosted ordinary signal cannot accept a single vertex. Even setting
arbitrarily many other edges to 0 cannot avert the singleton obstruction. -/
theorem no_singleton (a : Tree) {h : X→Bool} (common : sameBoost h a)
    (real : ∃b : Tree,ordinary b=h) (old : ordinary a=target) (new : lifted a=markedOn) (v : V) :
    h (single v)=false := by
  cases e:h (single v) with
  | false=>rfl
  | true=>
    obtain ⟨y,hit,miss⟩:=geometry v
    have raised:=boost_mono a common real (x:=single v) (y:=join (single y) (single v))
      (fun i yes=>Bool.or_eq_true_iff.mpr (Or.inr yes)) e
    have wrong:=upper a common (x:=single y) (y:=join (single y) (single v))
      (fun i yes=>Bool.or_eq_true_iff.mpr (Or.inl yes)) raised (new ▸ hit)
    rw [old,miss] at wrong;exact Bool.noConfusion wrong

theorem zero_has_lit (a : Tree) (depth : andDepth a=0) {x : X} (nonzero : ordinary a x=true) :
    ∃v,ordinary a (single v)=true := by
  induction a with
  | var i => exact ⟨i,by simp [ordinary,single]⟩
  | lit b => exact ⟨0,nonzero⟩
  | high _ ih | low _ ih => exact ih depth nonzero
  | conj _ _ _ _ => simp [andDepth] at depth
  | disj a b ia ib =>
    have da : andDepth a=0 := by change max _ _=0 at depth;omega
    have db : andDepth b=0 := by change max _ _=0 at depth;omega
    rcases Bool.or_eq_true_iff.mp nonzero with l|r
    · obtain ⟨v,y⟩:=ia da l;exact ⟨v,Bool.or_eq_true_iff.mpr (Or.inl y)⟩
    · obtain ⟨v,y⟩:=ib db r;exact ⟨v,Bool.or_eq_true_iff.mpr (Or.inr y)⟩

private theorem low_only (a : Tree) {h : X→Bool} (common : sameBoost h a) (d : andDepth a=0)
    (active : ∃x, h x=true) (notOne : ∀i,h (single i)=false) :
    ∀x,lifted a x=true → ordinary a x=true := by
  induction a with
  | var _ | lit _ => exact fun _=>id
  | low _ _ => simp [lifted]
  | high a _ =>
    obtain ⟨v,on⟩:=active
    obtain ⟨j,lit⟩:=zero_has_lit a d (x:=v) (common.1 ▸ on)
    rw [common.1,notOne] at lit;exact Bool.noConfusion lit
  | conj _ _ _ _ => simp [andDepth] at d
  | disj a b ia ib =>
    have a0 : andDepth a=0 := by change max _ _=0 at d;omega
    have b0 : andDepth b=0 := by change max _ _=0 at d;omega
    exact fun x u=>Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp u).imp (ia common.1 a0 x) (ib common.2 b0 x))

theorem one_layer (a : Tree) {h : X→Bool} (common : sameBoost h a) (d : andDepth a≤1)
    (active : ∃x,h x=true) (notOne : ∀i,h (single i)=false) :
    (∀x,lifted a x=true) ∨ (∀x,lifted a x=true → ordinary a x=true) := by
  induction a with
  | var _ | lit _ => exact Or.inr (fun _=>id)
  | low _ _ => right;simp [lifted]
  | high _ _ => exact Or.inl (fun _=>rfl)
  | conj a b _ _ =>
    have a0 : andDepth a=0 := by change max _ _+1≤1 at d;omega
    have b0 : andDepth b=0 := by change max _ _+1≤1 at d;omega
    right;exact fun x u=>Bool.and_eq_true_iff.mpr ((Bool.and_eq_true_iff.mp u).imp
      (low_only a common.1 a0 active notOne x) (low_only b common.2 b0 active notOne x))
  | disj a b ia ib =>
    have a0 : andDepth a≤1 := by change max _ _≤1 at d;omega
    have b0 : andDepth b≤1 := by change max _ _≤1 at d;omega
    rcases ia common.1 a0 with always|aa
    · exact Or.inl (fun x=>Bool.or_eq_true_iff.mpr (Or.inl (always x)))
    rcases ib common.2 b0 with always|bb
    · exact Or.inl (fun x=>Bool.or_eq_true_iff.mpr (Or.inr (always x)))
    exact Or.inr (fun x u=>Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp u).imp (aa x) (bb x)))

/-- This includes all ORs of star or biclique products with arbitrary OR
fanout. There is no such lift of any ordinary nine-input circuit of AND-depth
one whose positive override has a nonzero ordinary partner. -/
theorem impossible (a : Tree) {h : X→Bool} (common : sameBoost h a)
    (real : ∃b : Tree,ordinary b=h) (active : ∃x,h x=true)
    (old : ordinary a=target) (new : lifted a=markedOn) : 2≤andDepth a := by
  by_contra! shallow
  rcases one_layer a common (by omega) active (no_singleton a common real old new) with constant|smaller
  · have one:=constant (fun _=>false);rw [new] at one; exact Bool.noConfusion one
  · have zero : target (single 4)=false := by decide
    have one : markedOn (single 4)=true := by decide
    have bad:=smaller (single 4) (new ▸ one);rw [old,zero] at bad;exact Bool.noConfusion bad

#print axioms possible_on
#print axioms impossible
end PetersenOneAndLayer
