import PetersenIndexedReader
import PetersenScalarModels
open PetersenBoostShift PetersenCubicLift PetersenCubicScalar PetersenWordCost PetersenPhysicalWords
  PetersenOneAndLayer PetersenPhysicalProjection PetersenNineData PetersenIndexedReader PetersenScalarModels
namespace PetersenIndexedLift
set_option maxRecDepth 30000
set_option maxHeartbeats 0
variable {n : Nat}

def sampleNet (old : Fin 512→Fin n→Bool) (i : Fin n) := wordOf (fun x=>old x i)
private theorem sampleRead (old : Fin 512→Fin n→Bool) (i : Fin n) (r : Fin 24) :
    read (sampleNet old i) r=old (sample r) i := by unfold sampleNet wordOf;rw [read_pack];rfl
theorem sampled_eval {C : Net n} {data old : Fin 512→Fin n→Bool}
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) : TapeWords C (sampleNet old) := by
  intro i g;apply read_inj;funext r
  have e:=ev (sample r) i
  rw [sampleRead]
  cases k:C.kind i with
  | source=>exact (g k).elim
  | disj=>
    have p : op C i=true := by simp [op,k]
    rw [p];change _=(sampleNet old (C.arg i false) ||| sampleNet old (C.arg i true)).getLsbD r.val;rw [BitVec.getLsbD_or]
    change _=(read (sampleNet old (C.arg i false)) r || read (sampleNet old (C.arg i true)) r)
    rw [sampleRead,sampleRead];simpa [k,takeBit,emptyMask] using e
  | conj=>
    have p : op C i=false := by simp [op,k]
    rw [p];change _=(sampleNet old (C.arg i false) &&& sampleNet old (C.arg i true)).getLsbD r.val;rw [BitVec.getLsbD_and]
    change _=(read (sampleNet old (C.arg i false)) r && read (sampleNet old (C.arg i true)) r)
    rw [sampleRead,sampleRead];simpa [k,takeBit,emptyMask] using e

/-- Any ordinary connected nine-input DAG with at most sixteen paid gates is
incompatible with the marked cofactor when one ordinary wire can supply high
and arbitrary low sockets are permitted. Only three ordinary positive scalar
lower bounds are required, including the ordinary nine-input problem. -/
theorem excludes {C : Net n} {data old : Fin 512→Fin n→Bool} {L : Mask n} {root : Fin n}
    (mon : ∀x y,included x y → ∀i,data x i=true→data y i=true)
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) (off : ∀x,old x root=target (cube x))
    (fin : ∀j : Fin n,j.val≤root.val)
    (raw : ∀i,¬gated C i→wordOf (fun x=>old x i)∈PetersenNineProjected.basis)
    (live : ∀i,i≠root→∃j s,gated C j ∧ C.arg j s=i)
    (budget : (gates C).card≤16)
    (ordinary : NoPhysical PetersenNineProjected.basis label 15)
    (one : Hard true false) (two : Hard true true) : ¬∃i,Works C data L root i := by
  have sink : sampleNet old root=label := by
    apply read_inj;funext r;rw [sampleRead,off,labelRow]
  apply PetersenCubicScalar.excludes mon ev off fin _ (complete ordinary one two)
  intro i ne hard
  apply unique_or (sampled_eval ev) (by decide +kernel) raw budget live ne
  rw [sink];exact hard

/-- A working boost necessarily acts on at least one gate socket. -/
private theorem working_used {C : Net n} {data old : Fin 512→Fin n→Bool} {L : Mask n} {root h : Fin n}
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) (off : ∀x,old x root=target (cube x))
    (w : Works C data L root h) : ∃j s,gated C j ∧ C.arg j s=h := by
  obtain ⟨H,owned,ok⟩:=w
  by_contra! no
  obtain ⟨v,rv,yes⟩:=ok 128
  have p : markedOn (cube 128)=true := by decide
  have q : target (cube 128)=false := by decide
  have le:=compare rv (ev 128) (fun _ h=>h)
    (fun i s _ _ a=>(no i s (owned i s a).1 (owned i s a).2).elim) root (yes ▸ p)
  rw [off,q] at le;exact Bool.noConfusion le

/-- The optimal ordinary cost also supplies gate liveness. Unused dummy source
slots introduced by bypassing a marked pair may remain in the topological order. -/
theorem excludes_untrimmed {C : Net n} {data old : Fin 512→Fin n→Bool} {L : Mask n} {root : Fin n}
    (mon : ∀x y,included x y → ∀i,data x i=true→data y i=true)
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) (off : ∀x,old x root=target (cube x))
    (fin : ∀j : Fin n,j.val≤root.val)
    (raw : ∀i,¬gated C i→wordOf (fun x=>old x i)∈PetersenNineProjected.basis)
    (budget : (gates C).card≤16)
    (ordinary : NoPhysical PetersenNineProjected.basis label 15)
    (one : Hard true false) (two : Hard true true) : ¬∃i,Works C data L root i := by
  have sink : sampleNet old root=label := by
    apply read_inj;funext r;rw [sampleRead,off,labelRow]
  have cs : (0:BitVec 24) ∈ PetersenNineProjected.basis := by decide +kernel
  have live:=gate_live (sampled_eval ev) cs raw budget (sink ▸ ordinary)
  intro work
  have move (i) (yes : Works C data L root i) (_ : True) : ∃j,i.val<j.val ∧ Works C data L root j := by
    have eq:=combine (fun x=>old x i) (fun _ h=>allowed mon ev off yes h)
    apply PetersenCubicLift.push ev off fin yes
    intro _
    apply unique_or_used (sampled_eval ev) cs raw budget live (working_used ev off yes)
    rw [sink];change NoPhysical _ (label|||wordOf (fun x=>old x i)) 15
    rw [eq];exact complete ordinary one two _ _
  obtain ⟨_,_,bad⟩:=latest work move;exact bad trivial

#print axioms excludes_untrimmed
#print axioms excludes
end PetersenIndexedLift
