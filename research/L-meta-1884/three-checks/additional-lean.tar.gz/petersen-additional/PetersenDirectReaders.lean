import PetersenAntichain
import PetersenDominantPin
open PetersenSignedBridge PetersenMonotoneFrontier PetersenAntichain PetersenDominantPin PetersenWordCost PetersenPackedPin
namespace PetersenDirectReaders
variable {w u : Nat}
local notation "B" => BitVec w

structure Instr (w : Nat) where
  a : BitVec w
  b : BitVec w
  op : Bool

def Instr.out (g : Instr w) := gate g.op g.a g.b

def reads (x : B) (g : Instr w) := (g.a==x) || (g.b==x)
def readsAnd (x : B) (g : Instr w) := reads x g && !g.op

/-- An explicit last-use schedule with only genuine, fresh binary operations. -/
inductive Tape : Finset B → List (Instr w) → Finset B → Prop where
  | nil (S : Finset B) : Tape S [] S
  | step {K : Finset B} {es T} (g : Instr w) : g.a≠g.b → g.out∉insert g.a (insert g.b K) →
      Tape (insert g.out K) es T → Tape (insert g.a (insert g.b K)) (g::es) T

theorem record {t : B} {I S m c T} (tail : ATail t I S m c T) :
    ∃ es,List.length es=m ∧ Tape S es T := by
  induction tail with
  | nil => exact ⟨[],rfl,Tape.nil _⟩
  | @step K a b o m c T _ ne fresh _ g _ ih =>
    obtain ⟨es,eq,rest⟩:=ih
    obtain ⟨op,rfl⟩:=g.1
    exact ⟨⟨a,b,op⟩::es,by simp [eq],Tape.step ⟨a,b,op⟩ ne fresh rest⟩

def tally {α : Type*} (p : α→Bool) : List α → Nat
  | [] => 0
  | a::l => (p a).toNat+tally p l

theorem partition {α : Type*} (p : α→Bool) (l : List α) :
    tally p l + tally (fun a=> !(p a)) l = l.length := by
  induction l with
  | nil => rfl
  | cons a l ih => cases e:p a <;> simp [tally,e] <;> omega

private theorem mono {α : Type*} {p q : α→Bool} {es : List α}
    (sub : ∀g∈es,p g=true → q g=true) : tally p es ≤ tally q es := by
  induction es with
  | nil => rfl
  | cons g es ih =>
    have tail:=ih (fun a h=>sub a (List.mem_cons_of_mem _ h))
    have z:=sub g (List.mem_cons_self ..)
    cases h:p g <;> cases j:q g <;> simp_all [tally] <;> omega

theorem strict {α : Type*} {p q : α→Bool} {es : List α}
    (sub : ∀g∈es,p g=true → q g=true) (extra : ∃v∈es,p v=false ∧ q v=true) :
    tally p es + 1 ≤ tally q es := by
  induction es with
  | nil => simp at extra
  | cons g es ih =>
    have cont := fun a (h:a∈es)=>sub a (List.mem_cons_of_mem _ h)
    have z:=sub g (List.mem_cons_self ..)
    obtain ⟨v,hv,pv,qv⟩:=extra
    rcases List.mem_cons.mp hv with rfl|h
    · have cut:=mono cont; simp [tally,pv,qv]; omega
    · have cut:=ih cont ⟨v,h,pv,qv⟩
      cases a:p g <;> cases b:q g <;> simp_all [tally] <;> omega

def below (a x : B) := ∀i:Fin w, read a i=true → read x i=true

theorem andBelow {x : B} {g : Instr w} (r : readsAnd x g=true) : below g.out x := by
  obtain ⟨both,op⟩:=Bool.and_eq_true_iff.mp r
  have andOp : g.op=false := by cases h:g.op <;> simp_all
  rcases Bool.or_eq_true_iff.mp both with aa|bb
  · rw [←beq_iff_eq.mp aa];intro i; simp [Instr.out,gate,andOp,PetersenWordCost.read] <;> tauto
  · rw [←beq_iff_eq.mp bb];intro i; simp [Instr.out,gate,andOp,PetersenWordCost.read] <;> tauto

private theorem absorbed {a x : B} (sub : below a x) (op : Bool) :
    gate op a x = (if op then x else a) ∧ gate op x a = (if op then x else a) := by
  have t (u v : Bool) (d : u=true → v=true) :
      (u&&v)=u ∧ (v&&u)=u ∧ (u||v)=v ∧ (v||u)=v := by cases u <;> cases v <;> simp_all
  cases op <;> constructor <;> apply read_inj <;> funext i <;>
    have f:=t (read a i) (read x i) (sub i) <;>
    simp [PetersenWordCost.read,gate] at f ⊢ <;> tauto

private theorem solitary {x y : B} {g : Instr w} {K : Finset B} (_neq : g.a≠g.b)
    (fresh : g.out∉insert g.a (insert g.b K)) (sub : below y x) (different : y≠x)
    (reader : reads y g=true) : reads x g=false := by
  cases h:reads x g with
  | false => rfl
  | true =>
    have notNew (U V : B) (args : g.a=U ∧ g.b=V) (val : g.out=U ∨ g.out=V) : False := by
      apply fresh; rw [args.1,args.2];rcases val with q|q <;> simp [q]
    have pair := absorbed sub g.op
    rcases Bool.or_eq_true_iff.mp reader with ay|byy <;> rcases Bool.or_eq_true_iff.mp h with ax|bx
    · exact (different ((beq_iff_eq.mp ay).symm.trans (beq_iff_eq.mp ax))).elim
    · apply False.elim;apply notNew y x ⟨beq_iff_eq.mp ay,beq_iff_eq.mp bx⟩
      have p : g.out=(if g.op then x else y) := by simpa [Instr.out,beq_iff_eq.mp ay,beq_iff_eq.mp bx] using pair.1
      cases q:g.op <;> simp_all
    · apply False.elim;apply notNew x y ⟨beq_iff_eq.mp ax,beq_iff_eq.mp byy⟩
      have p : g.out=(if g.op then x else y) := by simpa [Instr.out,beq_iff_eq.mp ax,beq_iff_eq.mp byy] using pair.2
      cases q:g.op <;> simp_all
    · exact (different ((beq_iff_eq.mp byy).symm.trans (beq_iff_eq.mp bx))).elim

/-- A live value that is absent at the sink must have a reader. If it implies x,
the first reader cannot also read x because that operation would be absorbed. -/
theorem independent_reader {S T : Finset B} {es} (p : Tape S es T) {x y : B}
    (mem : y∈S) (out : y∉T) (sub : below y x) (different : y≠x) :
    ∃ g∈es, reads y g=true ∧ reads x g=false := by
  induction p with
  | nil => exact (out mem).elim
  | @step K es T g ne fresh _ ih =>
    by_cases used : reads y g=true
    · exact ⟨g,List.mem_cons_self ..,used,solitary ne fresh sub different used⟩
    · have inK : y∈K := by
        rcases Finset.mem_insert.mp mem with q|m
        · exact (used (Bool.or_eq_true_iff.mpr (Or.inl (beq_iff_eq.mpr q.symm)))).elim
        rcases Finset.mem_insert.mp m with q|h
        · exact (used (Bool.or_eq_true_iff.mpr (Or.inr (beq_iff_eq.mpr q.symm)))).elim
        exact h
      obtain ⟨r,hr,bt,af⟩:=ih (Finset.mem_insert_of_mem inK) out
      exact ⟨r,List.mem_cons_of_mem _ hr,bt,af⟩

def lost (r : Fin u→Fin w) (q : BitVec u) (g : Instr w) := forced r q g.a || forced r q g.b

theorem cost {S T : Finset B} {es} (p : Tape S es T) (r : Fin u→Fin w) (q : BitVec u)
    {I V : List (Func (Fin u))} {k} (pre : Run I k V) (supply : ∀x∈S,Good r q V x) :
    ∃ Z,Run I (k+tally (fun g=> !lost r q g) es) Z ∧ ∀v∈T, Good r q Z v := by
  induction p generalizing k V with
  | nil => exact ⟨V,by simpa [tally] using pre,supply⟩
  | @step K es T g ne fresh _ ih =>
    have a:=supply g.a (Finset.mem_insert_self ..)
    have b:=supply g.b (Finset.mem_insert_of_mem (Finset.mem_insert_self ..))
    obtain ⟨Y,run,gout,all⟩:=propagate r q (show Plain g.a g.b g.out from ⟨g.op,rfl⟩) pre a b
    have next (v) (h:v∈insert g.out K) : Good r q Y v := by
      rcases Finset.mem_insert.mp h with rfl|hv
      · exact gout
      · obtain ⟨y,improve,av⟩:=supply v (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem hv))
        exact ⟨y,improve,all _ av⟩
    obtain ⟨Z,hz,final⟩:=ih run next
    refine ⟨Z,?_,final⟩
    have charge : PetersenTracePin.debit (fun v=>forced r q v=true) g.a g.b = (!lost r q g).toNat := by
      cases ha:forced r q g.a <;> cases hb:forced r q g.b <;> simp [PetersenTracePin.debit,lost,ha,hb]
    simpa only [charge,tally,Nat.add_assoc] using hz

def vanishes (r : Fin u→Fin w) (q : BitVec u) (x : BitVec w) :=
    ∀i, read q i=true → read x (r i)=false

theorem forced_below (r : Fin u→Fin w) (q : BitVec u) {x y : B} (zero : vanishes r q x) (sub : below y x) :
    forced r q y=true := by
  apply (forced_iff ..).mpr
  refine ⟨false,?_⟩
  intro i
  rw [project,read_pack]
  change read y (r i)=read q i → read (0:BitVec u) i=read q i
  intro matchBit
  cases val : read q i with
  | false => simp [PetersenWordCost.read]
  | true =>
    have both:read x (r i)=true := sub (r i) (matchBit.trans val)
    exact False.elim (Bool.false_ne_true ((zero i val).symm.trans both))

private theorem read_loses {r : Fin u→Fin w} {q : BitVec u} {y : B} {g : Instr w}
    (f : forced r q y=true) (h : reads y g=true) : lost r q g=true := by
  rcases Bool.or_eq_true_iff.mp h with a|b
  · exact Bool.or_eq_true_iff.mpr (Or.inl (beq_iff_eq.mp a ▸ f))
  · exact Bool.or_eq_true_iff.mpr (Or.inr (beq_iff_eq.mp b ▸ f))

theorem bonus {S T : Finset B} {es} (p : Tape S es T) (r : Fin u→Fin w) (q : BitVec u)
    {x : B} (zero : vanishes r q x) (hot : ∀v∈T, forced r q v=false)
    (someAnd : ∃ g∈es,readsAnd x g=true) :
    ∃ g∈es,reads x g=false ∧ lost r q g=true := by
  induction p with
  | nil => simp at someAnd
  | @step K es T g ne fresh rest ih =>
    obtain ⟨v,hv,op⟩:=someAnd
    rcases List.mem_cons.mp hv with rfl|mem
    · have sub:=andBelow op
      have cold:=forced_below r q zero sub
      have out : v.out∉T := by
        intro h; have n:=hot _ h;rw [cold] at n;exact Bool.noConfusion n
      have direct:reads x v=true := (Bool.and_eq_true_iff.mp op).1
      have different : v.out≠x := by
        intro same; apply fresh
        rcases Bool.or_eq_true_iff.mp direct with aa|bb
        · simp [same,beq_iff_eq.mp aa]
        · simp [same,beq_iff_eq.mp bb]
      obtain ⟨a,h,got,sep⟩:=independent_reader rest (Finset.mem_insert_self ..) out sub different
      exact ⟨a,List.mem_cons_of_mem _ h,sep,read_loses cold got⟩
    · obtain ⟨z,h,u,v⟩:=ih hot ⟨v,mem,op⟩
      exact ⟨z,List.mem_cons_of_mem _ h,u,v⟩

/-- Pinning x removes all its direct readers. A direct AND contributes one
additional removed reader, since its output implies x and cannot be consumed
together with x in a fresh gate. -/
theorem read_budget {S : Finset B} {t : B} {es} (p : Tape S es {t}) (r : Fin u→Fin w)
    (I : List (BitVec u)) (K : Nat) (small : NoAtMost I (project r t) K)
    (supply : ∀v∈S, Good r (project r t) (I.map read) v)
    (hot : forced r (project r t) t=false) {x : B} (zero : vanishes r (project r t) x) :
    K+1+tally (reads x) es+(es.any (readsAnd x)).toNat ≤ es.length := by
  let q:=project r t
  obtain ⟨Z,hz,all⟩:=cost p r q (Run.start (init:=I.map read)) supply
  obtain ⟨y,improve,av⟩:=all t (Finset.mem_singleton_self t)
  rw [sink improve] at av
  have enough : K+1≤tally (fun g=> !lost r q g) es := by
    by_contra! weak
    exact small (tally (fun g=> !lost r q g) es) (by omega) Z (by simpa using hz) av
  have killed := forced_below r q zero (fun i=>id (α:=read x i=true))
  have sub : ∀g∈es, reads x g=true → lost r q g=true := fun _ _ h=>read_loses killed h
  have sum:=partition (lost r q) es
  cases any : es.any (readsAnd x) with
  | false => have c:=mono sub; simp;omega
  | true =>
    have extra:=bonus p r q zero (fun v hv=>(Finset.mem_singleton.mp hv) ▸ hot) (List.any_eq_true.mp any)
    have c:=strict sub extra; simp;omega

#print axioms read_budget
end PetersenDirectReaders
