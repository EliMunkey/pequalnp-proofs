import PetersenScalarSource
open PetersenPackedFrontier PetersenSignedBridge PetersenWordCost PetersenPhysicalWords PetersenPhysicalProjection
  PetersenScalarModels
namespace PetersenScalarClosure
set_option maxHeartbeats 0
set_option maxRecDepth 60000

private theorem expand {k W} (r : Positive PetersenScalarSource.dual k W) :
    ∃Z,Direct rails k Z ∧ Z.map table=W := by
  induction r with
  | start=>exact ⟨rails,Direct.start,rfl⟩
  | @add k W a b op _ ha hb ih=>
    obtain ⟨Z,run,rfl⟩:=ih
    obtain ⟨f,hf,ea⟩:=List.mem_map.mp ha
    obtain ⟨g,hg,eb⟩:=List.mem_map.mp hb
    subst a;subst b
    cases op
    · refine ⟨_,Direct.and run hf hg,?_⟩;simp only [List.map_cons];apply congrArg (fun f=>f::Z.map table)
      exact pack_bin false _ _
    · refine ⟨_,Direct.or run hf hg,?_⟩;simp only [List.map_cons];apply congrArg (fun f=>f::Z.map table)
      exact pack_bin true _ _

private theorem grow {W : List (Func PInput)} {f h} (v : Av W f) : Av (h::W) f := by
  induction v with
  | wire h=>exact Av.wire (List.mem_cons_of_mem _ h)
  | zero=>exact Av.zero
  | one=>exact Av.one
  | neg _ ih=>exact Av.neg ih

private theorem startSigned : ∀f∈rails, Av base f := by
  intro f mem;rcases List.mem_cons.mp mem with rfl|mem
  · exact Av.zero
  rcases List.mem_cons.mp mem with rfl|mem
  · exact Av.one
  rcases List.mem_cons.mp mem with rfl|mem
  · apply Av.neg;exact Av.wire (List.mem_ofFn.mpr ⟨0,rfl⟩)
  · exact Av.wire mem

private theorem signed {k W} (r : Direct rails k W) : ∃Z,Run base k Z ∧ ∀f∈W,Av Z f := by
  induction r with
  | start=>exact ⟨_,Run.start,startSigned⟩
  | and _ ha hb ih=>
    obtain ⟨Z,prog,seen⟩:=ih
    refine ⟨_,Run.and prog (seen _ ha) (seen _ hb),?_⟩
    intro v h;rcases List.mem_cons.mp h with rfl|h
    · exact Av.wire List.mem_cons_self
    · exact grow (seen _ h)
  | or _ ha hb ih=>
    obtain ⟨Z,prog,seen⟩:=ih
    refine ⟨_,Run.or prog (seen _ ha) (seen _ hb),?_⟩
    intro v h;rcases List.mem_cons.mp h with rfl|h
    · exact Av.wire List.mem_cons_self
    · exact grow (seen _ h)

theorem full_to_physical (full : ∀k≤17,∀W,Run base k W→¬Av W PetersenTarget) :
    NoPhysical PetersenScalarSource.dual target 17 := by
  intro k le W r hit
  obtain ⟨Z,run,rfl⟩:=expand r
  obtain ⟨f,hf,e⟩:=List.mem_map.mp hit
  have eq : f=PetersenTarget := by
    have agree : ∀y∈PhysicalBoundary.selected,f (PhysicalBoundary.word y)=PhysicalBoundary.edge y := by
      intro y hy;obtain ⟨j,rfl⟩:=List.mem_iff_get.mp hy
      have observed:=congrFun (congrArg PetersenWordCost.read e) j
      change PetersenWordCost.read (pack (f ∘ row)) j=PetersenWordCost.read (pack (PetersenTarget ∘ row)) j at observed
      rw [read_pack,read_pack] at observed;exact observed
    have all:=(PhysicalBoundary.physical_compressed_iff run hf).mpr agree
    funext x
    let code:=(pack x).toNat
    have small:code<1024:=(pack x).isLt
    have identity:PhysicalBoundary.word code=x:=by
      funext j;change PetersenWordCost.read (pack x) j=x j;rw [read_pack]
    have v:=all code small;simpa [PhysicalBoundary.edge,identity] using v
  obtain ⟨S,rs,seen⟩:=signed run
  exact full _ le _ rs (eq ▸ seen f hf)

/-- Original L-meta-1884 statement, with the signed-ten bound and the four
remaining *pure positive* table lower bounds as its only assumptions. -/
theorem original (full : ∀k≤17,∀W,Run base k W→¬Av W PetersenTarget)
    (pure : NoPhysical PetersenScalarSource.pure target 18)
    (ordinary : NoPhysical PetersenNineProjected.basis PetersenNineData.label 15)
    (one : Hard true false) (two : Hard true true)
    (C : PEqualNP.CircuitLowerBounds.Circuit) (σ : Fin 10→Fin 10) (u : Bool→Bool)
    (fan : PEqualNP.MetaComplexity.FanInTwo C) (small : C.size≤18) :
    ∃x : PInput,C.eval (List.ofFn (x ∘ σ) ++ [u (x 0)])≠PetersenTarget x :=
  L_meta_1884_of_exclusions full
    (PetersenScalarSource.excludes (full_to_physical full) pure ordinary one two 18 (le_refl _)) C σ u fan small

#print axioms full_to_physical
#print axioms original
end PetersenScalarClosure
