import PetersenOneAndLayer
namespace PetersenBoostShift
set_option maxHeartbeats 0

inductive Kind where | source | disj | conj deriving DecidableEq
structure Net (n : Nat) where
  kind : Fin n→Kind
  arg : Fin n→Bool→Fin n
  causal : ∀i, kind i≠.source → ∀s, (arg i s).val < i.val
abbrev Mask (n : Nat) := Fin n→Bool→Bool

def takeBit {n} (C : Net n) (L H : Mask n) (v : Fin n→Bool) (i : Fin n) (s : Bool) : Bool :=
  if L i s then false else if H i s then true else v (C.arg i s)

def Eval {n} (C : Net n) (raw : Fin n→Bool) (L H : Mask n) (v : Fin n→Bool) : Prop :=
  ∀i,v i=match C.kind i with
  | .source=>raw i
  | .disj=>takeBit C L H v i false || takeBit C L H v i true
  | .conj=>takeBit C L H v i false && takeBit C L H v i true

/-- Boost every outgoing socket of a wire. A low override continues to take
precedence, so outgoing sockets already selected for low are unaffected. -/
def allUses {n} (C : Net n) (r : Fin n) : Mask n := fun i s=>decide (C.arg i s=r)

/-- Move a boost through its sole OR reader. This changes that gate's stored
value but preserves every other wire, including every downstream reader.
Negative overrides can occur anywhere and can have arbitrary fanout. -/
theorem shift {n} {C : Net n} {raw v} {L H : Mask n} {r : Fin n}
    (ev : Eval C raw L H v) (isOr : C.kind r=.disj)
    (only : ∀i s,H i s=true → i=r) (active : ∃s,L r s=false ∧ H r s=true) :
    ∃v', Eval C raw L (allUses C r) v' ∧ ∀i, i≠r → v' i=v i := by
  have on : v r=true := by
    have atR:=ev r;rw [isOr] at atR
    rcases active with ⟨b,l,h⟩
    cases b <;> simp [takeBit,l,h] at atR <;> exact atR
  let G : Mask n:=fun _ _=>false
  let rr:=takeBit C L G v r false || takeBit C L G v r true
  let nv:=Function.update v r rr
  have same (i : Fin n) (m : i≠r) : nv i=v i := Function.update_of_ne m ..
  have before (b : Bool) : C.arg r b≠r := by
    have z:=C.causal r (by simp [isOr]) b
    intro eq;rw [eq] at z;omega
  have atR (s : Bool) : takeBit C L (allUses C r) nv r s=takeBit C L G v r s := by
    simp [takeBit,allUses,before,same _ (before s),G]
  have away (i : Fin n) (m : i≠r) (s : Bool) : takeBit C L (allUses C r) nv i s=takeBit C L H v i s := by
    have h : H i s=false := by cases z:H i s with
      | false=>rfl
      | true=>exact (m (only _ _ z)).elim
    by_cases pin : C.arg i s=r
    · simp [takeBit,allUses,pin,h,on]
    · simp [takeBit,allUses,pin,h,same _ pin]
  refine ⟨nv,?_,same⟩
  intro i
  by_cases isR : i=r
  · subst i;rw [isOr,atR,atR];exact Function.update_self ..
  · rw [same i isR,ev i]
    cases op:C.kind i <;> simp only [away i isR]

/-- Choosing a latest working boost leaves only anchors at which pushing
through one OR reader is impossible. -/
theorem latest {n : Nat} {works : Fin n→Prop} (some : ∃i,works i)
    {avoidable : Fin n→Prop} (move : ∀i, works i → avoidable i → ∃j, i.val < j.val ∧ works j) :
    ∃i,works i ∧ ¬avoidable i := by
  classical
  let live : Finset (Fin n) := Finset.univ.filter works
  obtain ⟨i,hi⟩:=some
  have nonempty : live.Nonempty := ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,hi⟩⟩
  let last:=live.max' nonempty
  have haveLast : works last := (Finset.mem_filter.mp (Finset.max'_mem ..)).2
  refine ⟨last,haveLast,fun bad=>?_⟩
  obtain ⟨j,ij,hj⟩:=move last haveLast bad
  have lim : j≤last := Finset.le_max' live j (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hj⟩)
  omega

#print axioms shift
#print axioms latest
end PetersenBoostShift
