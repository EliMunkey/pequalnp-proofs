import PetersenIndexedPinPrice
open PetersenWordCost PetersenBoostShift PetersenBypassRails PetersenIndexedReader PetersenIndexedPinPrice
  PetersenPhysicalRailLift PetersenPhysicalWords
namespace PetersenIndexedRailShape
set_option maxRecDepth 50000
set_option maxHeartbeats 0
variable {n w : Nat} {C : Net n}
local notation "B" => BitVec w

def Reader (C : Net n) (wire gate : Fin n) := gated C gate ∧ ∃s,C.arg gate s=wire
def free (C : Net n) (v : Fin n→B) := (gates C) \ (charged C v)

private theorem freeOf {v : Fin n→B} {r} (g : gated C r) {b} (h : Trivial (v (C.arg r b))) : r∈free C v := by
  apply Finset.mem_sdiff.mpr;refine ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,g⟩,?_⟩
  intro mem;obtain ⟨_,_,ha,hb⟩:=(Finset.mem_filter.mp mem).2;cases b <;> contradiction

private theorem two {S : Finset (Fin n)} {x y : Fin n} (hx:x∈S) (hy:y∈S) (different:x≠y) (le:S.card≤2) :
    ∀j∈S,j=x ∨ j=y := by
  intro j hj;by_contra! no
  have sub : ({j,x,y} : Finset (Fin n)) ⊆ S := Finset.insert_subset hj (Finset.insert_subset hx (Finset.singleton_subset_iff.mpr hy))
  have k:=Finset.card_le_card sub
  simp [no.1,no.2,different] at k;omega

private theorem bothTrivial (s : Bool) {a b : B} (ha : Trivial a) (hb : Trivial b) : Trivial (gate s a b) := by
  rcases ha with rfl|rfl <;> rcases hb with rfl|rfl <;> cases s <;> simp [gate,Trivial]

/-- On an optimal pinned nine-table, every read of either marked rail lies in
the two uncharged gates. Their outgoing wires cannot be constant, since such a
constant must propagate through another marked reader all the way to the sink. -/
theorem shape {v : Fin n→B} {t pos neg : Fin n}
    (ev : TapeWords C v) (zp : v pos=0) (zn : v neg= ~~~(0:B))
    (primaryP : C.kind pos=.source) (primaryN : C.kind neg=.source)
    (useP : ∃j,Reader C pos j) (useN : ∃j,Reader C neg j)
    (separate : ∀j,Reader C pos j→Reader C neg j→False)
    (limit : (free C v).card≤2) (sink : ¬Trivial (v t))
    (live : ∀i,gated C i→i≠t→∃j,Reader C i j) :
    ∃p : Pair C,∃r : RailShape p,r.pos=pos ∧ r.neg=neg := by
  obtain ⟨u,ug,us,ue⟩:=useP;obtain ⟨d,dg,ds,de⟩:=useN
  have ne:u≠d:=by intro e;subst d;exact separate u ⟨ug,us,ue⟩ ⟨dg,ds,de⟩
  have uFree : u∈free C v:=freeOf ug (b:=us) (Or.inl (ue ▸ zp))
  have dFree : d∈free C v:=freeOf dg (b:=ds) (Or.inr (de ▸ zn))
  have classify:=two uFree dFree ne limit
  have notConst : ∀i,gated C i→¬Trivial (v i) := by
    suffices all : ∀k:Nat,∀i:Fin n,n-i.val=k→gated C i→¬Trivial (v i) by exact fun i=>all _ i rfl
    intro k;induction k using Nat.strong_induction_on with
    | ind k ih=>
      intro i step gi const
      by_cases last:i=t
      · exact sink (last ▸ const)
      obtain ⟨j,gj,b,e⟩:=live i gi last
      have bad:=freeOf gj (b:=b) (e ▸ const)
      have mark : ∃s,Trivial (v (C.arg j s)) ∧ b≠s := by
        rcases classify j bad with eq|eq
        · subst j;refine ⟨us,Or.inl (ue ▸ zp),?_⟩
          intro bs;subst b;have eip:=e.symm.trans ue;exact gi (eip ▸ primaryP)
        · subst j;refine ⟨ds,Or.inr (de ▸ zn),?_⟩
          intro bs;subst b;have ein:=e.symm.trans de;exact gi (ein ▸ primaryN)
      obtain ⟨s,raw,diff⟩:=mark
      have src : Trivial (v (C.arg j b)):=e ▸ const
      have out : Trivial (v j) := by
        rw [ev j gj];cases b <;> cases s <;> simp at diff <;> exact bothTrivial _ (by assumption) (by assumption)
      have stride:=C.causal j gj b;rw [e] at stride
      exact ih _ (by have bounded:=j.isLt;omega) j rfl gj out
  have isOR : C.kind u=.disj := by
    cases k:C.kind u with
    | source=>exact (ug k).elim
    | disj=>rfl
    | conj=>
      exfalso;apply notConst u ug;left;rw [ev u ug]
      cases us <;> simp [op,k,gate,ue,zp]
  have isAND : C.kind d=.conj := by
    cases k:C.kind d with
    | source=>exact (dg k).elim
    | conj=>rfl
    | disj=>
      exfalso;apply notConst d dg;right;rw [ev d dg]
      cases ds <;> simp [op,k,gate,de,zn]
  let p : Pair C:=⟨u,d,ne,!us,!ds,ug,dg⟩
  refine ⟨p,⟨pos,neg,isOR,isAND,by simpa [p] using ue,by simpa [p] using de,?_,?_⟩,rfl,rfl⟩
  · intro j s g e;rcases classify j (freeOf g (b:=s) (Or.inl (e ▸ zp))) with a|a
    · exact a
    · subst j;exact (separate d ⟨g,s,e⟩ ⟨dg,ds,de⟩).elim
  · intro j s g e;rcases classify j (freeOf g (b:=s) (Or.inr (e ▸ zn))) with a|a
    · subst j;exact (separate u ⟨ug,us,ue⟩ ⟨g,s,e⟩).elim
    · exact a

#print axioms shape
end PetersenIndexedRailShape
