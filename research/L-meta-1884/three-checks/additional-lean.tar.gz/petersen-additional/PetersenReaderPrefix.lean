import PetersenDirectReaders
open PetersenDirectReaders PetersenAntichain PetersenMonotoneFrontier PetersenPackedPin PetersenDominantPin PetersenWordCost PetersenSignedBridge
namespace PetersenReaderPrefix
variable {w u : Nat}
local notation "B" => BitVec w

theorem append {S L T : Finset B} {a b} (pre : Tape S a L) (post : Tape L b T) : Tape S (a++b) T := by
  induction pre with
  | nil => exact post
  | step g ne fr _ ih => exact .step g ne fr (ih post)

theorem tally_add {α : Type*} (p : α→Bool) (a b : List α) : tally p (a++b)=tally p a+tally p b := by
  induction a with
  | nil => simp [tally]
  | cons h a ih => simp [tally,ih,Nat.add_assoc]

theorem positive {α : Type*} {p : α→Bool} {es : List α} {v} (h:v∈es) (yes:p v=true) : 1≤tally p es := by
  induction es with
  | nil => simp at h
  | cons a es ih =>
    rcases List.mem_cons.mp h with rfl|h
    · simp [tally,yes]
    · have found:=ih h; simp only [tally]; omega

theorem live_read {S T : Finset B} {x : B} {es} (tail : Tape S es T) (live : x∈S) (absent : x∉T) :
    ∃ g∈es,reads x g=true := by
  induction tail with
  | nil => exact (absent live).elim
  | @step K es T g _ _ rest ih =>
    by_cases used:reads x g=true
    · exact ⟨g,List.mem_cons_self ..,used⟩
    · have keep : x∈K := by
        rcases Finset.mem_insert.mp live with h|m
        · exact (used (Bool.or_eq_true_iff.mpr (Or.inl (beq_iff_eq.mpr h.symm)))).elim
        rcases Finset.mem_insert.mp m with h|k
        · exact (used (Bool.or_eq_true_iff.mpr (Or.inr (beq_iff_eq.mpr h.symm)))).elim
        exact k
      obtain ⟨v,hv,yes⟩:=ih (Finset.mem_insert_of_mem keep) absent
      exact ⟨v,List.mem_cons_of_mem _ hv,yes⟩

/-- A prefix accounts for every raw read already made and one future read if
the raw word is still live. The additional AND charge applies immediately. -/
theorem prefix_budget {S L : Finset B} {t x : B} {a b} (pre : Tape S a L) (post : Tape L b {t})
    (r : Fin u→Fin w) (I : List (BitVec u)) (K : Nat) (small : NoAtMost I (project r t) K)
    (supply : ∀v∈S, Good r (project r t) (I.map read) v) (hot : forced r (project r t) t=false)
    (zero : vanishes r (project r t) x) :
    K+1+tally (reads x) a+(decide (x∈L)).toNat+(a.any (readsAnd x)).toNat ≤ a.length+b.length := by
  have bound:=read_budget (append pre post) r I K small supply hot zero
  rw [tally_add,List.length_append,List.any_append] at bound
  have needed : (decide (x∈L)).toNat ≤ tally (reads x) b := by
    by_cases live:x∈L
    · simp [live]
      have cold:=forced_below r _ zero (fun i=>id (α:=read x i=true))
      have diff : x≠t := by intro e; rw [e,hot] at cold;exact Bool.noConfusion cold
      obtain ⟨g,hm,yes⟩:=live_read post live (by simpa using diff)
      exact positive hm yes
    · simp [live]
  cases e:a.any (readsAnd x) <;> cases y:b.any (readsAnd x) <;> simp [e,y] at bound ⊢ <;> omega

theorem record_clean {t : B} {I S m c T} (tail : ATail t I S m c T) :
    ∃ es,List.length es=m ∧ Tape S es T ∧ ∀g∈es,g.out≠0 ∧ g.out≠~~~0 := by
  induction tail with
  | nil => exact ⟨[],rfl,Tape.nil _,by simp⟩
  | @step K a b o m c T _ ne fresh _ g _ ih =>
    obtain ⟨es,eq,rest,proper⟩:=ih
    have nz : o≠0 := fun e=>g.2 o (Or.inl e) (PetersenMonotoneFrontier.refl t _)
    have no : o≠~~~0 := fun e=>g.2 o (Or.inr (Or.inl e)) (PetersenMonotoneFrontier.refl t _)
    obtain ⟨op,rfl⟩:=g.1
    refine ⟨⟨a,b,op⟩::es,by simp [eq],Tape.step ⟨a,b,op⟩ ne fresh rest,?_⟩
    intro v hv;rcases List.mem_cons.mp hv with rfl|h
    · exact ⟨nz,no⟩
    · exact proper v h

theorem sum_sub {α : Type*} {p q s : α→Bool} {es : List α}
    (yes : ∀g∈es, p g=true ∨ q g=true → s g=true)
    (separate : ∀g∈es, p g=true → q g=false) : tally p es+tally q es≤tally s es := by
  induction es with
  | nil => rfl
  | cons g es ih =>
    have next:=ih (fun a h=>yes a (List.mem_cons_of_mem _ h)) (fun a h=>separate a (List.mem_cons_of_mem _ h))
    have a:=yes g (List.mem_cons_self ..);have b:=separate g (List.mem_cons_self ..)
    cases e:p g <;> cases f:q g <;> cases z:s g <;> simp_all [tally] <;> omega

private theorem forced_read {r : Fin u→Fin w} {q : BitVec u} {y : B} {g : PetersenDirectReaders.Instr w}
    (f : forced r q y=true) (h : reads y g=true) : lost r q g=true := by
  rcases Bool.or_eq_true_iff.mp h with a|b
  · exact Bool.or_eq_true_iff.mpr (Or.inl (beq_iff_eq.mp a ▸ f))
  · exact Bool.or_eq_true_iff.mpr (Or.inr (beq_iff_eq.mp b ▸ f))

theorem rails {x : B} {g : PetersenDirectReaders.Instr w} (distinct : x ≠ ~~~x) (proper : g.out≠0 ∧ g.out≠~~~0)
    (readX : reads x g=true) : reads (~~~x) g=false := by
  cases e:reads (~~~x) g with
  | false => rfl
  | true =>
    have clean (a b : B) (ha:g.a=a) (hb:g.b=b) (eq : b= ~~~a) : False := by
      cases h:g.op
      · apply proper.1; simp [PetersenDirectReaders.Instr.out,gate,h,ha,hb,eq]
      · apply proper.2; simp [PetersenDirectReaders.Instr.out,gate,h,ha,hb,eq]
    rcases Bool.or_eq_true_iff.mp readX with ax|bx <;> rcases Bool.or_eq_true_iff.mp e with an|bn
    · exact (distinct ((beq_iff_eq.mp ax).symm.trans (beq_iff_eq.mp an))).elim
    · exact (clean _ _ (beq_iff_eq.mp ax) (beq_iff_eq.mp bn) rfl).elim
    · exact (clean _ _ (beq_iff_eq.mp an) (beq_iff_eq.mp bx) (by simp)).elim
    · exact (distinct ((beq_iff_eq.mp bx).symm.trans (beq_iff_eq.mp bn))).elim

theorem marked_charge {t x : B} {es : List (PetersenDirectReaders.Instr w)}
    (r : Fin u→Fin w) {K : Nat} (lower : K+1≤tally (fun g=> !lost r (project r t) g) es)
    (distinct : x ≠ ~~~x) (cz : forced r (project r t) x=true) (co : forced r (project r t) (~~~x)=true)
    (proper : ∀g∈es,g.out≠0 ∧ g.out≠~~~0) :
    K+1+tally (reads x) es+tally (reads (~~~x)) es ≤ es.length := by
  have part := partition (lost r (project r t)) es
  have add:=sum_sub (p:=reads x) (q:=reads (~~~x)) (s:=lost r (project r t)) (es:=es)
    (fun a _ b=>b.elim (forced_read cz) (forced_read co)) (fun g mem=>rails distinct (proper g mem))
  omega

theorem once {S : Finset B} {t x : B} {es} (p : Tape S es {t}) (pos:x∈S) (neg: ~~~x∈S)
    (pt : x≠t) (nt : ~~~x≠t) (two : tally (reads x) es+tally (reads (~~~x)) es≤2) :
    tally (reads x) es=1 ∧ tally (reads (~~~x)) es=1 := by
  obtain ⟨a,aa,ra⟩:=live_read p pos (by simpa using pt)
  obtain ⟨b,bb,rb⟩:=live_read p neg (by simpa using nt)
  have one:=positive aa ra;have other:=positive bb rb
  omega

/-- Both complementary rails consume the same gate budget when they become
constants on the projected problem. A nonconstant output gate cannot read both
rails, so each of their direct reads counts separately. -/
theorem marked {S : Finset B} {t x : B} {es} (p : Tape S es {t}) (r : Fin u→Fin w)
    (I : List (BitVec u)) (K : Nat) (small : NoAtMost I (project r t) K)
    (supply : ∀v∈S, Good r (project r t) (I.map read) v)
    (distinct : x ≠ ~~~x) (cz : forced r (project r t) x=true) (co : forced r (project r t) (~~~x)=true)
    (proper : ∀g∈es,g.out≠0 ∧ g.out≠~~~0) :
    K+1+tally (reads x) es+tally (reads (~~~x)) es ≤ es.length := by
  let q:=project r t
  obtain ⟨Z,hz,all⟩:=cost p r q (Run.start (init:=I.map read)) supply
  obtain ⟨y,improve,av⟩:=all t (Finset.mem_singleton_self t)
  rw [sink improve] at av
  have left : K+1≤tally (fun g=> !lost r q g) es := by
    by_contra! weak; exact small (tally (fun g=> !lost r q g) es) (by omega) Z (by simpa using hz) av
  exact marked_charge r left distinct cz co proper

#print axioms prefix_budget
#print axioms marked
end PetersenReaderPrefix
