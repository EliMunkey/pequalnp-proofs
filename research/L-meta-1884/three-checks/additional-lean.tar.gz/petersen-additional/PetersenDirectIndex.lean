import PetersenPhysicalRailLift
open PetersenBoostShift PetersenIndexedReader PetersenCubicLift PetersenSignedBridge
namespace PetersenDirectIndex
set_option maxHeartbeats 0
set_option maxRecDepth 50000
variable {X : Type}

def extend {n} (C : Net n) (a b : Fin n) (s : Bool) : Net (n+1) where
  kind i := Fin.lastCases (if s then .disj else .conj) C.kind i
  arg i u := Fin.lastCases ((if u then b else a).castSucc) (fun j=>(C.arg j u).castSucc) i
  causal i := by
    refine Fin.lastCases ?_ (fun j=>?_) i
    · intro _ u;simp
    · intro g u;simp at g ⊢;exact C.causal j g u

theorem extend_cost {n} (C : Net n) (a b : Fin n) (s : Bool) : (gates (extend C a b s)).card=(gates C).card+1 := by
  let emb:Fin n↪Fin (n+1):=⟨Fin.castSucc,Fin.castSucc_injective _⟩
  have shape : gates (extend C a b s)=insert (Fin.last n) ((gates C).map emb) := by
    ext i
    have mem (m) (D : Net m) q : q∈gates D ↔ gated D q := by simp [gates]
    apply Fin.lastCases (motive:=fun j=>j∈gates (extend C a b s) ↔ j∈insert (Fin.last n) ((gates C).map emb)) ?_ (fun j=>?_) i
    · cases s <;> simp [mem,gated,extend]
    · rw [mem,Finset.mem_insert,Finset.mem_map]
      have no : j.castSucc≠Fin.last n:=Fin.castSucc_ne_last j
      simp only [no,false_or];constructor
      · intro g;exact ⟨j,(mem ..).mpr (by simpa [gated,extend] using g),rfl⟩
      · rintro ⟨k,h,e⟩
        have eq:k=j:=Fin.castSucc_injective _ e;subst k;simpa [gated,extend] using (mem ..).mp h
  have fresh:Fin.last n∉(gates C).map emb:=by
    intro h;obtain ⟨j,_,eq⟩:=Finset.mem_map.mp h;exact Fin.castSucc_ne_last j eq
  rw [shape,Finset.card_insert_of_notMem fresh,Finset.card_map]

structure Model (I : List (Func X)) (k : Nat) (W : List (Func X)) where
  n : Nat
  net : Net n
  val : Fin n→Func X
  input : Fin n→Fin I.length
  raw : ∀i,net.kind i=.source→val i=I.get (input i)
  source_all : ∀j:Fin I.length,∃i,net.kind i=.source ∧ input i=j
  source_unique : ∀i j,net.kind i=.source→net.kind j=.source→input i=input j→i=j
  cover : ∀v∈W,∃i,val i=v
  eval : ∀x,Eval net (fun i=>val i x) emptyMask emptyMask (fun i=>val i x)
  cost : (gates net).card=k

def start (I : List (Func X)) : Model I 0 I where
  n:=I.length
  net:=⟨fun _=>.source,fun i _=>i,by simp⟩
  val:=I.get
  input:=id
  raw:=by simp
  source_all:=fun j=>⟨j,rfl,rfl⟩
  source_unique:=by simp
  cover:=fun f h=>List.mem_iff_get.mp h
  eval:=by simp [Eval]
  cost:=by simp [gates,gated]

def opValue (s : Bool) (a b : Func X) : Func X:=fun x=>if s then a x || b x else a x && b x

noncomputable def add {I W : List (Func X)} {k f g} (M : Model I k W) (u : Fin I.length)
    (hf : f∈W) (hg : g∈W) (s : Bool) : Model I (k+1) (opValue s f g ::W) := by
  classical
  let a:Fin M.n:=Classical.choose (M.cover f hf)
  let b:Fin M.n:=Classical.choose (M.cover g hg)
  have af : M.val a=f:=Classical.choose_spec (M.cover f hf)
  have bg : M.val b=g:=Classical.choose_spec (M.cover g hg)
  let C:=extend M.net a b s
  let v : Fin (M.n+1)→Func X := fun i=>Fin.lastCases (opValue s f g) M.val i
  let inp : Fin (M.n+1)→Fin I.length :=fun i=>Fin.lastCases u M.input i
  refine ⟨M.n+1,C,v,inp,?_,?_,?_,?_,?_,by rw [extend_cost,M.cost]⟩
  · intro i;apply Fin.lastCases (motive:=fun j=>C.kind j=.source→v j=I.get (inp j)) ?_ (fun j=>?_) i
    · cases s <;> simp [C,extend]
    · simpa [C,extend,v,inp] using M.raw j
  · intro j;obtain ⟨i,so,h⟩:=M.source_all j;exact ⟨i.castSucc,by simpa [C,extend] using so,by simpa [inp] using h⟩
  · intro i j;induction i using Fin.lastCases <;> induction j using Fin.lastCases
    all_goals first | (cases s <;> simp [C,extend,inp]) | skip
    all_goals exact M.source_unique _ _
  · intro z h;rcases List.mem_cons.mp h with rfl|orig
    · exact ⟨Fin.last _,by simp [v]⟩
    · obtain ⟨j,eq⟩:=M.cover _ orig;exact ⟨j.castSucc,by simpa [v] using eq⟩
  · intro x i;apply Fin.lastCases (motive:=fun i=>v i x=match C.kind i with
      | .source=>v i x | .disj=>takeBit C emptyMask emptyMask (fun j=>v j x) i false || takeBit C emptyMask emptyMask (fun j=>v j x) i true
      | .conj=>takeBit C emptyMask emptyMask (fun j=>v j x) i false && takeBit C emptyMask emptyMask (fun j=>v j x) i true) ?_ (fun j=>?_) i
    · cases s <;> simp [takeBit,emptyMask,extend,C,v,opValue,af,bg]
    · have ev:=M.eval x j;cases k:M.net.kind j <;> simp [C,extend,v,k,takeBit,emptyMask] at ev ⊢ <;> assumption

theorem model {I W : List (Func X)} (u : Fin I.length) {k} (r : Direct I k W) : Nonempty (Model I k W) := by
  induction r with
  | start=>exact ⟨start I⟩
  | and _ ha hb ih=>obtain ⟨M⟩:=ih;exact ⟨add M u ha hb false⟩
  | or _ ha hb ih=>obtain ⟨M⟩:=ih;exact ⟨add M u ha hb true⟩

private theorem add_last {I W : List (Func X)} {k f g} (M : Model I k W) (u : Fin I.length)
    (hf : f∈W) (hg : g∈W) (s : Bool) :
    ∃t, (add M u hf hg s).val t=opValue s f g ∧ gated (add M u hf hg s).net t ∧ ∀j:Fin (add M u hf hg s).n,j.val≤t.val := by
  refine ⟨Fin.last M.n,?_,?_,?_⟩
  · simp [add]
  · cases s <;> simp [add,extend,gated]
  · intro j;exact Nat.le_of_lt_succ j.isLt

/-- Cut the source execution where the target was first created. The resulting
indexed candidate has its target at the last index and has at most the original
gate count, whether or not the original program contained trailing dead gates. -/
theorem output {I W : List (Func X)} (u : Fin I.length) {k} (r : Direct I k W) {f} (absent : f∉I)
    (present : f∈W) : ∃m≤k,∃Z,∃M:Model I m Z,∃t, M.val t=f ∧ gated M.net t ∧ ∀j:Fin M.n,j.val≤t.val := by
  induction r with
  | start=>exact (absent present).elim
  | @and k W a b src ha hb ih=>
    rcases List.mem_cons.mp present with eq|old
    · obtain ⟨M⟩:=model u src;obtain ⟨t,v,g,last⟩:=add_last M u ha hb false
      exact ⟨_,le_refl _,_,add M u ha hb false,t,v.trans eq.symm,g,last⟩
    · obtain ⟨m,le,h⟩:=ih old;exact ⟨m,by omega,h⟩
  | @or k W a b src ha hb ih=>
    rcases List.mem_cons.mp present with eq|old
    · obtain ⟨M⟩:=model u src;obtain ⟨t,v,g,last⟩:=add_last M u ha hb true
      exact ⟨_,le_refl _,_,add M u ha hb true,t,v.trans eq.symm,g,last⟩
    · obtain ⟨m,le,h⟩:=ih old;exact ⟨m,by omega,h⟩

#print axioms output
#print axioms model
end PetersenDirectIndex
