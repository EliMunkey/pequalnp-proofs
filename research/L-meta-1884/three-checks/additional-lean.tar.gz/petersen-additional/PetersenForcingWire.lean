import PetersenPositiveReaders
open PetersenWordCost PetersenPhysicalWords PetersenDirectReaders PetersenPositiveDominance PetersenReaderPrefix
open PetersenMonotoneFrontier PetersenPackedPin PetersenDominantPin
namespace PetersenForcingWire
variable {w : Nat}
local notation "B" => BitVec w
set_option maxHeartbeats 0

private theorem identityProject (x : B) : project id x=x := by apply read_inj;rw [project,read_pack];rfl

/-- The suffix simulation retains all wires of the original prefix, including
the forcing signal which will be ORed back once at the end. -/
private theorem costKeep {S T : Finset B} {es} (p : Tape S es T) (q : B)
    {I V : List B} {k} (pre : Positive I k V) (cs : 0∈V ∧ ~~~0∈V)
    (cv : ∀v∈S,PetersenPositiveDominance.Good id q V v) :
    ∃ Z,Positive I (k+tally (fun g=> !lost id q g) es) Z ∧ V⊆Z ∧ ∀v∈T,PetersenPositiveDominance.Good id q Z v := by
  induction p generalizing k V with
  | nil=>exact ⟨V,by simpa [tally] using pre,fun _ h=>h,cv⟩
  | @step K es T g ne fresh _ ih=>
    obtain ⟨Y,run,new,sub⟩:=PetersenPositiveDominance.advance id q (show Plain g.a g.b g.out from ⟨g.op,rfl⟩)
      pre cs (cv _ (Finset.mem_insert_self ..)) (cv _ (Finset.mem_insert_of_mem (Finset.mem_insert_self ..)))
    have rem (v) (hv:v∈insert g.out K) : PetersenPositiveDominance.Good id q Y v := by
      rcases Finset.mem_insert.mp hv with rfl|h
      · exact new
      · obtain ⟨x,xv,improve⟩:=cv v (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem h))
        exact ⟨x,sub xv,improve⟩
    obtain ⟨Z,rz,sz,final⟩:=ih run ⟨sub cs.1,sub cs.2⟩ rem
    have same : PetersenTracePin.debit (fun v=>forced id q v=true) g.a g.b=(!lost id q g).toNat := by
      cases x:forced id q g.a <;> cases y:forced id q g.b <;> simp [PetersenTracePin.debit,lost,x,y]
    exact ⟨Z,by simpa only [same,tally,Nat.add_assoc] using rz,fun _ h=>sz (sub h),final⟩

def masked (t x : B) := t &&& ~~~x

private theorem maskBit (t x : B) (i : Fin w) : read (masked t x) i=(read t i && !read x i) := by
  simp [masked,PetersenWordCost.read,i.isLt]

private theorem finalOr {t x z : B} (hit : below x t) (better : Better (masked t x) t z) : gate true x z=t := by
  apply read_inj;funext i
  have p:=better i;rw [maskBit] at p
  have h:=hit i
  change (x|||z).getLsbD i.val=t.getLsbD i.val
  rw [BitVec.getLsbD_or];change (read x i || read z i)=read t i
  revert p h;cases read x i <;> cases read t i <;> cases read z i <;> decide

private theorem finalOrAny {t x z : B} (better : Better (masked t x) t z) : gate true x z=t|||x := by
  apply read_inj;funext i
  have p:=better i;rw [maskBit] at p
  change (x|||z).getLsbD i.val=(t|||x).getLsbD i.val
  rw [BitVec.getLsbD_or,BitVec.getLsbD_or];change (read x i || read z i)=(read t i || read x i)
  revert p;cases read x i <;> cases read t i <;> cases read z i <;> decide

private theorem force_mask {t x : B} : vanishes id (masked t x) x := by
  intro i h;rw [maskBit] at h;change read x i=false;cases e:read x i <;> simp_all

private theorem hot {t x : B} (outside : ∃i,read t i=false) (strict : ∃i,read t i=true ∧ read x i=false) :
    forced id (masked t x) t=false := by
  cases f:forced id (masked t x) t with
  | false=>rfl
  | true=>
    obtain ⟨v,b⟩:=(forced_iff ..).mp f;rw [identityProject] at b
    cases v with
    | false=>
      obtain ⟨i,ts,xs⟩:=strict
      have q:=b i;rw [maskBit,ts,xs] at q
      have no : read (constWord (u:=w) false) i=false := by simp [constWord,PetersenWordCost.read]
      rw [no] at q;exact Bool.noConfusion (q rfl)
    | true=>
      obtain ⟨i,ts⟩:=outside
      have q:=b i;rw [maskBit,ts] at q
      have yes : read (constWord (u:=w) true) i=true := by simp [PetersenWordCost.read,constWord,i.isLt]
      rw [yes] at q;exact Bool.noConfusion (q rfl)

/-- In a minimum ordinary circuit, every interior live wire which implies the
target has exactly one remaining direct reader, necessarily an OR. The prefix
may contain arbitrary shared gates. -/
theorem one_or_join {I V : List B} {x t : B} {S es n K} (r : Tape S es {t}) (pre : Positive I n V)
    (small : PetersenPhysicalProjection.NoPhysical I (t|||x) K) (saturated : n+es.length≤K+1)
    (live : x∈S) (scope : ∀v∈S,v∈V) (cs : 0∈V ∧ ~~~0∈V) (budget : n≤K)
    (outside : ∃i,read t i=false) :
    tally (reads x) es=1 ∧ es.any (readsAnd x)=false := by
  have strictSub : ∃i,read t i=true ∧ read x i=false := by
    by_contra! all
    have eq : t|||x=x := by
      apply read_inj;funext i;change (t|||x).getLsbD i.val=x.getLsbD i.val
      rw [BitVec.getLsbD_or];change (read t i || read x i)=read x i
      cases e:read t i with
      | false=>rfl
      | true=>have v:=all i e;cases z:read x i <;> simp_all
    exact small n budget V pre (by rw [eq];exact scope x live)
  let q:=masked t x
  have zero : vanishes id q x:=force_mask
  have forcedX:=forced_below id q zero (fun _ h=>h)
  have hotT := hot (x:=x) outside strictSub
  have cv (v) (hv:v∈S) : PetersenPositiveDominance.Good id q V v :=
    ⟨v,scope v hv,by rw [identityProject];exact fun _ h=>h⟩
  obtain ⟨Z,rz,keep,out⟩:=costKeep r q pre cs cv
  obtain ⟨y,hy,b⟩:=out _ (Finset.mem_singleton_self t)
  rw [identityProject] at b
  have fix:=finalOrAny b
  have recover:=Positive.add true rz (keep (scope _ live)) hy
  have enough : K+1≤n+tally (fun g=> !lost id q g) es+1 := by
    by_contra! cheap
    exact small _ (by omega) _ recover (fix ▸ List.mem_cons_self ..)
  have sum:=partition (lost id q) es
  have limit : tally (lost id q) es≤1 := by omega
  have chosen {g : Instr w} (uses : reads x g=true) : lost id q g=true := by
    rcases Bool.or_eq_true_iff.mp uses with l|r
    · exact Bool.or_eq_true_iff.mpr (Or.inl (beq_iff_eq.mp l ▸ forcedX))
    · exact Bool.or_eq_true_iff.mpr (Or.inr (beq_iff_eq.mp r ▸ forcedX))
  have neq : x≠t := by
    obtain ⟨i,ht,hx⟩:=strictSub;rintro rfl;rw [ht] at hx;contradiction
  obtain ⟨g,hg,rg⟩:=live_read r live (fun h=>neq (Finset.mem_singleton.mp h))
  have has:=positive hg rg
  have le := sum_sub (p:=reads x) (q:=fun _=>false) (s:=lost id q) (es:=es)
    (fun _ _ h=>h.elim chosen (fun no=>Bool.noConfusion no)) (fun _ _ _=>rfl)
  cases a:es.any (readsAnd x) with
  | false=>exact ⟨by omega,rfl⟩
  | true=>
    obtain ⟨e,em,rd,ls⟩:=bonus r id q zero (fun _ h=>Finset.mem_singleton.mp h ▸ hotT) (List.any_eq_true.mp a)
    have more:=PetersenDirectReaders.strict (p:=reads x) (q:=lost id q) (es:=es) (fun _ _=>chosen) ⟨e,em,rd,ls⟩
    omega

theorem one_or {I V : List B} {x t : B} {S es n K} (r : Tape S es {t}) (pre : Positive I n V)
    (small : PetersenPhysicalProjection.NoPhysical I t K) (saturated : n+es.length≤K+1)
    (live : x∈S) (scope : ∀v∈S,v∈V) (cs : 0∈V ∧ ~~~0∈V) (hit : below x t)
    (outside : ∃i,read t i=false) (strictSub : ∃i,read t i=true ∧ read x i=false) :
    tally (reads x) es=1 ∧ es.any (readsAnd x)=false := by
  have eq : t|||x=t := by
    apply read_inj;funext i;change (t|||x).getLsbD i.val=t.getLsbD i.val
    rw [BitVec.getLsbD_or];change (read t i || read x i)=read t i
    have le:=hit i;revert le;cases read t i <;> cases read x i <;> decide
  obtain ⟨i,t1,x0⟩:=strictSub
  have neq : x≠t := by intro e;rw [e,t1] at x0;contradiction
  obtain ⟨g,mem,_⟩:=live_read r live (fun h=>neq (Finset.mem_singleton.mp h))
  have nonempty : 0 < es.length := List.length_pos_of_mem mem
  exact one_or_join r pre (by rw [eq];exact small) saturated live scope cs (by omega) outside

#print axioms one_or_join
#print axioms one_or
end PetersenForcingWire
