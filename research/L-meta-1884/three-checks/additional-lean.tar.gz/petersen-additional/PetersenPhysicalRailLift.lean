import PetersenBypassRails
open PetersenBoostShift PetersenIndexedReader PetersenCubicLift PetersenOneAndLayer PetersenCubicScalar
  PetersenNineData PetersenPhysicalProjection PetersenScalarModels PetersenBypassRails
namespace PetersenPhysicalRailLift
set_option maxRecDepth 50000
set_option maxHeartbeats 0
variable {n : Nat} {C : Net n}

/-- Pairs of actual positive/negative source readers, with positions of their
other operands named by the zero-cofactor bypass. -/
structure RailShape (p : Pair C) where
  pos : Fin n
  neg : Fin n
  highOr : C.kind p.high=.disj
  lowAnd : C.kind p.low=.conj
  highInput : C.arg p.high (!p.hs)=pos
  lowInput : C.arg p.low (!p.ls)=neg
  onlyPos : ∀i s,gated C i→C.arg i s=pos→i=p.high
  onlyNeg : ∀i s,gated C i→C.arg i s=neg→i=p.low

private theorem pbase {p : Pair C} (r : RailShape p) {raw v} (ev : Eval C raw emptyMask emptyMask v)
    (x : v r.pos=false) (nx : v r.neg=true) : baseline p v := by
  have h:=ev p.high;have l:=ev p.low
  have hi:=r.highInput;have lo:=r.lowInput
  rw [r.highOr] at h;rw [r.lowAnd] at l
  constructor
  · cases j:p.hs <;> simp [j] at hi ⊢ <;> simpa [takeBit,emptyMask,hi,x] using h
  · cases j:p.ls <;> simp [j] at lo ⊢ <;> simpa [takeBit,emptyMask,lo,nx] using l

private theorem pon {p : Pair C} (r : RailShape p) {raw v} (ev : Eval C raw emptyMask emptyMask v)
    (x : v r.pos=true) (nx : v r.neg=false) : v p.high=true ∧ v p.low=false := by
  have h:=ev p.high;have l:=ev p.low
  have hi:=r.highInput;have lo:=r.lowInput
  rw [r.highOr] at h;rw [r.lowAnd] at l
  constructor
  · cases j:p.hs <;> simp [j] at hi <;> simpa [takeBit,emptyMask,hi,x] using h
  · cases j:p.ls <;> simp [j] at lo <;> simpa [takeBit,emptyMask,lo,nx] using l

private theorem quiet_of_raw {p : Pair C} (r : RailShape p) {u v}
    (same : ∀i,C.kind i=.source→i≠r.pos→i≠r.neg→v i=u i) : quiet p u v := by
  intro j g s source
  have k:keep p j:=by by_contra bad;simp [gated,net,bad] at g
  have orig : gated C j:=by simpa [net,gated,k] using g
  exact same _ source (fun e=>k.1 (r.onlyPos j s orig e)) (fun e=>k.2 (r.onlyNeg j s orig e))

theorem excludes {p : Pair C} (r : RailShape p) (root : Fin n)
    {data0 data1 old flag : Fin 512→Fin n→Bool}
    (ev0 : ∀x,Eval C (data0 x) emptyMask emptyMask (old x))
    (ev1 : ∀x,Eval C (data1 x) emptyMask emptyMask (flag x))
    (rails0 : ∀x,old x r.pos=false ∧ old x r.neg=true)
    (rails1 : ∀x,flag x r.pos=true ∧ flag x r.neg=false)
    (others : ∀x i,C.kind i=.source→i≠r.pos→i≠r.neg→flag x i=old x i)
    (mono : ∀x y,included x y→∀i,C.kind i=.source→ old x i=true→ old y i=true)
    (raw : ∀i,C.kind i=.source→wordOf (fun x=>old x i)∈PetersenNineProjected.basis)
    (output0 : ∀x,old x root=target (cube x))
    (output1 : ∀x,flag x root=markedOn (cube x))
    (sg : gated C root) (last : ∀j : Fin n,j.val≤root.val) (budget : (gates C).card≤18)
    (ordinaryBound : NoPhysical PetersenNineProjected.basis label 15)
    (one : Hard true false) (two : Hard true true) : False := by
  have on (x) := pon r (ev1 x) (rails1 x).1 (rails1 x).2
  have kept : keep p root := by
    constructor
    · intro e;have z:=output1 0;rw [e,(on 0).1] at z;exact Bool.noConfusion z
    · intro e;have z:=output1 128;rw [e,(on 128).2] at z;exact Bool.noConfusion z
  have sinkGate : gated (net p) root:=by simpa [gated,net,kept] using sg
  let off:=fun x=>keepValue p (old x)
  let data:=fun x=>sourceValue p (old x)
  have mm (x y) (sub:included x y) (i) : data x i=true→data y i=true := by
    by_cases k:keep p i <;> by_cases s:C.kind i=.source <;> simp [data,sourceValue,k,s]
    exact mono _ _ sub _ s
  have sim (x) : Eval (net p) (data x) emptyMask emptyMask (off x) :=
    ordinary (ev0 x) (pbase r (ev0 x) (rails0 x).1 (rails0 x).2)
  have hit (x) : off x root=target (cube x) := by simpa [off,keepValue,kept] using output0 x
  have inputs (i) (src : ¬gated (net p) i) : wordOf (fun x=>off x i)∈PetersenNineProjected.basis := by
    by_cases k:keep p i
    · have yes:C.kind i=.source:=by simpa [gated,net,k] using src
      simpa [off,keepValue,k] using raw i yes
    · have z : wordOf (fun _=>false)=(0:BitVec 24) := by decide +kernel
      simp only [off,keepValue,k,decide_false,Bool.false_and];rw [z];decide +kernel
  have cost: (gates (net p)).card≤16:=by have c:=gate_count p;omega
  apply PetersenIndexedLift.excludes_untrimmed (L:=lowMask p) mm sim hit last inputs cost ordinaryBound one two
  refine ⟨resolve p p.high,highMask p,?_,?_⟩
  · intro j s a;obtain ⟨g,e⟩:=of_decide_eq_true a
    exact ⟨g,congrArg (resolve p) e⟩
  · intro x;refine ⟨onValue p (old x) (flag x),marked (ev1 x) (on x).1 (on x).2 (quiet_of_raw r (others x)),?_⟩
    simpa [onValue,sinkGate] using output1 x

#print axioms excludes
end PetersenPhysicalRailLift
