import PetersenPhysicalRailLift
open PetersenBoostShift PetersenCubicLift PetersenOneAndLayer PetersenIndexedReader PetersenNineData
namespace PetersenMissingPositive
set_option maxHeartbeats 0
variable {n : Nat} {C : Net n}

/-- If the positive mark is never read, a signal other than that raw literal can
only decrease as the marked bit goes from zero to one. -/
theorem antitone {a b data0 data1 : Fin n→Bool} {p : Fin n}
    (ev0 : Eval C data0 emptyMask emptyMask a) (ev1 : Eval C data1 emptyMask emptyMask b)
    (raw : ∀i,C.kind i=.source→i≠p→b i=true→a i=true)
    (absent : ∀j,gated C j→∀s,C.arg j s≠p) : ∀i,i≠p→b i=true→a i=true := by
  suffices go : ∀k:Nat,∀i:Fin n,i.val=k→i≠p→b i=true→a i=true by exact fun i=>go _ i rfl
  intro k;induction k using Nat.strong_induction_on with
  | ind k ih=>
    intro i iv ne on
    have l:=ev0 i;have h:=ev1 i
    have arg (s) (g:gated C i) : b (C.arg i s)=true→a (C.arg i s)=true :=
      ih _ (iv ▸ C.causal i g s) _ rfl (absent _ g s)
    cases op:C.kind i with
    | source=>exact raw i op ne on
    | disj=>
      have g:gated C i:=by simp [gated,op]
      simp [op,takeBit,emptyMask] at h l
      rw [h] at on;rw [l];exact Bool.or_eq_true_iff.mpr ((Bool.or_eq_true_iff.mp on).imp (arg false g) (arg true g))
    | conj=>
      have g:gated C i:=by simp [gated,op]
      simp [op,takeBit,emptyMask] at h l
      rw [h] at on;rw [l];exact Bool.and_eq_true_iff.mpr ((Bool.and_eq_true_iff.mp on).imp (arg false g) (arg true g))

theorem positive_required {data0 data1 old flag : Fin 512→Fin n→Bool} {pos root : Fin n}
    (ev0 : ∀x,Eval C (data0 x) emptyMask emptyMask (old x))
    (ev1 : ∀x,Eval C (data1 x) emptyMask emptyMask (flag x))
    (raw : ∀x i,C.kind i=.source→i≠pos→flag x i=true→ old x i=true)
    (out0 : ∀x,old x root=target (cube x)) (out1 : ∀x,flag x root=markedOn (cube x)) (ne:root≠pos) :
    ∃j s,gated C j ∧ C.arg j s=pos := by
  by_contra! absent
  have off : old 128 root=false := by rw [out0];decide
  have on : flag 128 root=true := by rw [out1];decide
  have hit:=antitone (ev0 128) (ev1 128) (raw 128) (fun j g s=>absent j s g) root ne on
  rw [off] at hit;exact Bool.noConfusion hit
#print axioms positive_required
end PetersenMissingPositive
