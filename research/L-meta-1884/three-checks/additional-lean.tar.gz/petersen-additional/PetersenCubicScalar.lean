import PetersenCubicLift
import PetersenForcingWire
import PetersenNineProjected
open PetersenWordCost PetersenNineData PetersenBoostShift PetersenCubicLift PetersenOneAndLayer
namespace PetersenCubicScalar
set_option maxRecDepth 60000
set_option maxHeartbeats 0
abbrev W:=BitVec 24

def sample (j : Fin 24) : Fin 512 := Fin.ofNat 512 (rowCode j)
def wordOf (h : Fin 512→Bool) : W := pack (h ∘ sample)

/-- The two cubic monomials add precisely two isolated truth-table rows to the
ordinary predicate. Either one can be present independently. -/
def scalar (a b : Bool) : W := label ||| (if a then 1<<<6 else 0) ||| (if b then 1<<<17 else 0)

theorem rows (a b : Bool) (j : Fin 24) : read (scalar a b) j=
    ((target (cube (sample j)) || (decide (sample j=42) && a)) || (decide (sample j=261) && b)) := by
  revert a b j;decide +kernel

theorem labelRow (j : Fin 24) : read label j=target (cube (sample j)) := by revert j;decide +kernel

theorem combine (h : Fin 512→Bool)
    (ok : ∀x,h x=true → target (cube x)=true ∨ x=42 ∨ x=261) :
    label|||wordOf h=scalar (h 42) (h 261) := by
  apply read_inj;funext j
  have vals : read (label|||wordOf h) j=(read label j || h (sample j)) := by
    change (label|||wordOf h).getLsbD j.val=_
    rw [BitVec.getLsbD_or];change (read label j || read (wordOf h) j)=_
    rw [wordOf,read_pack];rfl
  rw [vals,rows,labelRow]
  by_cases p:sample j=42
  · rw [p];simp
  by_cases q:sample j=261
  · rw [q];simp
  simp [p,q]
  have yes:=ok (sample j)
  cases e:h (sample j) with
  | false=>simp
  | true=>obtain v|v|v:=yes e <;> simp_all

/-- The three orbit types of scalar lower bounds eliminate every possible
latest boost. `index_reader` is the transfer from a budget-saturated ordinary
nine program to its indexed reader pattern; the local positive-tape version is
`PetersenForcingWire.one_or_join`. -/
theorem excludes {n : Nat} {C : Net n} {data old : Fin 512→Fin n→Bool} {L : Mask n} {root : Fin n}
    (mon : ∀x y,included x y → ∀i,data x i=true→data y i=true)
    (ev : ∀x,Eval C (data x) emptyMask emptyMask (old x)) (off : ∀x,old x root=target (cube x))
    (fin : ∀j : Fin n,j.val≤root.val)
    (index_reader : ∀i,i≠root → PetersenPhysicalProjection.NoPhysical PetersenNineProjected.basis
      (label|||wordOf (fun x=>old x i)) 15 →
      ∃r,C.kind r=.disj ∧ ∀j s,C.kind j≠.source → C.arg j s=i → j=r)
    (bounds : ∀a b,PetersenPhysicalProjection.NoPhysical PetersenNineProjected.basis (scalar a b) 15) :
    ¬∃i,Works C data L root i := by
  intro work
  have move (i) (yes : Works C data L root i) (_ : True) : ∃j,i.val < j.val ∧ Works C data L root j := by
    have eq:=combine (fun x=>old x i) (fun _ h=>allowed mon ev off yes h)
    apply PetersenCubicLift.push ev off fin yes
    intro ne;apply index_reader i ne;rw [eq];exact bounds _ _
  obtain ⟨_,_,bad⟩:=latest work move;exact bad trivial

#print axioms combine
#print axioms excludes
end PetersenCubicScalar
