import PetersenCubicScalar
open PetersenCubicScalar PetersenNineData PetersenFrontierSymmetry PetersenWordCost PetersenPhysicalWords PetersenPhysicalProjection
namespace PetersenScalarModels
set_option maxRecDepth 30000
set_option maxHeartbeats 0
abbrev raw:=PetersenNineProjected.basis
abbrev Hard (p q : Bool) := NoPhysical raw (scalar p q) 15
private def r := (group 2).row
private theorem good : raw.all (fun v=>raw.contains (act r v))=true := by decide +kernel
private theorem targetSwap : act r (scalar false true)=scalar true false := by decide +kernel
private theorem relabel {n W} (p : Positive raw n W) : ∃Z,Positive raw n Z ∧ ∀v∈W,act r v∈Z := by
  induction p with
  | start=>exact ⟨_,Positive.start,fun _ h=>List.contains_iff_mem.mp (List.all_eq_true.mp good _ h)⟩
  | @add k S a b op _ ha hb ih=>
    obtain ⟨Z,p,seen⟩:=ih
    have fold : act r (gate op a b)=gate op (act r a) (act r b) := by cases op <;> simp [gate,act_or,act_and]
    refine ⟨_,Positive.add op p (seen _ ha) (seen _ hb),?_⟩
    intro x h;rcases List.mem_cons.mp h with rfl|hh
    · rw [fold];exact List.mem_cons_self ..
    · exact List.mem_cons_of_mem _ (seen _ hh)

theorem swapped (h : Hard true false) : Hard false true := by
  intro k small W p out
  obtain ⟨Z,run,map⟩:=relabel p
  have got:=map _ out;rw [targetSwap] at got;exact h _ small _ run got

theorem complete (ordinary : NoPhysical raw label 15) (one : Hard true false) (two : Hard true true) :
    ∀p q,Hard p q := by
  intro p q;cases p <;> cases q
  · have e : scalar false false=label := by decide
    change NoPhysical raw (scalar false false) 15;rw [e];exact ordinary
  · exact swapped one
  · exact one
  · exact two

#print axioms complete
end PetersenScalarModels
