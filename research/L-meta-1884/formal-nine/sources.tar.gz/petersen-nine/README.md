# Petersen nine-vertex lower-bound proof

The theorem `NineCert.fifteen` excludes signed binary circuits of size at most 14 for the Petersen edge predicate after deleting one vertex. The theorem `NineCert.all_deletions` extends that lower bound to all ten single-vertex deletions in `sources/NineAllClasses.lean`.

Use the pequalnp-proofs Lean project at commit `074709bd01fc526b9f6279e5b0a028946ceb39fb` with its pinned dependencies available. The Lean toolchain is `leanprover/lean4:v4.36.0`. Place the matching `lake` executable on PATH, then run `python3 replay.py --project /path/to/pequalnp-proofs/lean --jobs 4` from this directory. The script checks every local source and writes its compiler output to `build/`. Pass `--target ThetaClosing` to replay the seven-vertex subproof separately.

The table `sources.tsv` maps every local module in the import closure to its source SHA-256. The bundle contains source and replay code only.
