import NinePin162
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_2091 : List (BitVec 512) := [w360,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_2091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2091 := by
  intro m le c
  apply rejects_sound r162 i7 6 tgt (small162 adj) hot162 [] s4_2091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v162_360,v162_1388,v162_3766,v162_4344,v162_4716,v162_5135,v162_5393,v162_5585,v162_6179,v162_6300,v162_6588] (PetersenWireProjection.cons pc162_360 (PetersenWireProjection.cons pc162_1388 (PetersenWireProjection.cons pc162_3766 (PetersenWireProjection.cons pc162_4344 (PetersenWireProjection.cons pc162_4716 (PetersenWireProjection.cons pc162_5135 (PetersenWireProjection.cons pc162_5393 (PetersenWireProjection.cons pc162_5585 (PetersenWireProjection.cons pc162_6179 (PetersenWireProjection.cons pc162_6300 (PetersenWireProjection.cons pc162_6588 rfl))))))))))) (by decide +kernel)
def s4_16781 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_16781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16781 := by
  intro m le c
  apply rejects_sound r162 i7 6 tgt (small162 adj) hot162 [] s4_16781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v162_3766,v162_4344,v162_4571,v162_4716,v162_5135,v162_5393,v162_5585,v162_5956,v162_6300,v162_6720,v162_6873] (PetersenWireProjection.cons pc162_3766 (PetersenWireProjection.cons pc162_4344 (PetersenWireProjection.cons pc162_4571 (PetersenWireProjection.cons pc162_4716 (PetersenWireProjection.cons pc162_5135 (PetersenWireProjection.cons pc162_5393 (PetersenWireProjection.cons pc162_5585 (PetersenWireProjection.cons pc162_5956 (PetersenWireProjection.cons pc162_6300 (PetersenWireProjection.cons pc162_6720 (PetersenWireProjection.cons pc162_6873 rfl))))))))))) (by decide +kernel)
def s4_16786 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16786 := by
  intro m le c
  apply rejects_sound r162 i7 6 tgt (small162 adj) hot162 [] s4_16786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v162_3766,v162_4344,v162_4572,v162_4716,v162_5135,v162_5393,v162_5585,v162_5956,v162_6300,v162_6588,v162_6720] (PetersenWireProjection.cons pc162_3766 (PetersenWireProjection.cons pc162_4344 (PetersenWireProjection.cons pc162_4572 (PetersenWireProjection.cons pc162_4716 (PetersenWireProjection.cons pc162_5135 (PetersenWireProjection.cons pc162_5393 (PetersenWireProjection.cons pc162_5585 (PetersenWireProjection.cons pc162_5956 (PetersenWireProjection.cons pc162_6300 (PetersenWireProjection.cons pc162_6588 (PetersenWireProjection.cons pc162_6720 rfl))))))))))) (by decide +kernel)
def s4_17977 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6748,w6873]
theorem b4_17977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17977 := by
  intro m le c
  apply rejects_sound r162 i7 6 tgt (small162 adj) hot162 [] s4_17977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v162_3766,v162_4344,v162_4716,v162_5135,v162_5393,v162_5585,v162_5956,v162_6464,v162_6720,v162_6748,v162_6873] (PetersenWireProjection.cons pc162_3766 (PetersenWireProjection.cons pc162_4344 (PetersenWireProjection.cons pc162_4716 (PetersenWireProjection.cons pc162_5135 (PetersenWireProjection.cons pc162_5393 (PetersenWireProjection.cons pc162_5585 (PetersenWireProjection.cons pc162_5956 (PetersenWireProjection.cons pc162_6464 (PetersenWireProjection.cons pc162_6720 (PetersenWireProjection.cons pc162_6748 (PetersenWireProjection.cons pc162_6873 rfl))))))))))) (by decide +kernel)
def s4_17981 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6857,w6873]
theorem b4_17981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17981 := by
  intro m le c
  apply rejects_sound r162 i7 6 tgt (small162 adj) hot162 [] s4_17981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v162_3766,v162_4344,v162_4716,v162_5135,v162_5393,v162_5585,v162_5956,v162_6464,v162_6720,v162_6857,v162_6873] (PetersenWireProjection.cons pc162_3766 (PetersenWireProjection.cons pc162_4344 (PetersenWireProjection.cons pc162_4716 (PetersenWireProjection.cons pc162_5135 (PetersenWireProjection.cons pc162_5393 (PetersenWireProjection.cons pc162_5585 (PetersenWireProjection.cons pc162_5956 (PetersenWireProjection.cons pc162_6464 (PetersenWireProjection.cons pc162_6720 (PetersenWireProjection.cons pc162_6857 (PetersenWireProjection.cons pc162_6873 rfl))))))))))) (by decide +kernel)
end NineCert
