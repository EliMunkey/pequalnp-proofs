import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3007 : List (BitVec 512) := [w635,w2513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3007 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(1,false),(0,true))] s4_3007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2513,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3073 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_3073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3073 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3082 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_3082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3082 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5605 : List (BitVec 512) := [w1119,w1609,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5605 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_1609,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_1609 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5619 : List (BitVec 512) := [w1119,w1850,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5619 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_1850,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_1850 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5643 : List (BitVec 512) := [w1119,w2223,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5643 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2223,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5645 : List (BitVec 512) := [w1119,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_5645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5645 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(4,true))] s4_5645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5646 : List (BitVec 512) := [w1119,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588]
theorem b4_5646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5646 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(5,true))] s4_5646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5647 : List (BitVec 512) := [w1119,w2320,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5647 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2320,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5648 : List (BitVec 512) := [w1119,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_5648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5648 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5649 : List (BitVec 512) := [w1119,w2354,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5649 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2354,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5650 : List (BitVec 512) := [w1119,w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5650 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5651 : List (BitVec 512) := [w1119,w2427,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5651 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(4,true))] s4_5651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5652 : List (BitVec 512) := [w1119,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_5652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5652 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5653 : List (BitVec 512) := [w1119,w2441,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5653 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2441,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5654 : List (BitVec 512) := [w1119,w2453,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5654 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(5,true))] s4_5654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2453,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2453 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5656 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5656 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5659 : List (BitVec 512) := [w1119,w2499,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5659 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2499,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5738 : List (BitVec 512) := [w1119,w3766,w4041,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5738 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5738 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5738 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4041,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5756 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5294,w5393,w5585,w5956,w6300,w6588]
theorem b4_5756 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5756 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s4_5756 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5294,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5294 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5757 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5306,w5393,w5585,w5956,w6300,w6588]
theorem b4_5757 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5757 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s4_5757 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5306,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5306 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5758 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5311,w5393,w5585,w5956,w6300,w6588]
theorem b4_5758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5758 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s4_5758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5759 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6522,w6588]
theorem b4_5759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5759 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5760 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b4_5760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5760 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s4_5760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_5786 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6246,w6300,w6588]
theorem b4_5786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5786 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(4,true))] s4_5786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6246,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5801 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6505,w6588]
theorem b4_5801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5801 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(5,true))] s4_5801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6505,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6505 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5814 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6559,w6588]
theorem b4_5814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5814 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5840 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6451,w6522,w6588]
theorem b4_5840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5840 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5845 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6300,w6522,w6588]
theorem b4_5845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5845 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true))] s4_5845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5850 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5884,w5956,w6179,w6300,w6588]
theorem b4_5850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5850 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(4,true))] s4_5850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5851 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5884,w5956,w6300,w6464,w6588]
theorem b4_5851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5851 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(7,true),(5,true))] s4_5851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5866 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5251,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5866 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5867 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5283,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5867 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5868 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5290,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5868 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5290,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5290 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5869 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5299,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5869 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5870 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5324,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5870 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5871 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5349,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5871 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5349,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5349 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5872 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5420,w5585,w5956,w6101,w6300,w6588]
theorem b4_5872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5872 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5420,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5420 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5874 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5479,w5585,w5956,w6101,w6300,w6588]
theorem b4_5874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5889 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5884,w5956,w6101,w6300,w6588]
theorem b4_5889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5889 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5904 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6158,w6300,w6588]
theorem b4_5904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5904 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5905 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6163,w6300,w6588]
theorem b4_5905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5905 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6163,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6163 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5915 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6451,w6588]
theorem b4_5915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5915 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_5925 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6767]
theorem b4_5925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5925 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_5925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s4_7208 : List (BitVec 512) := [w1292,w2223,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7208 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7208 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7208 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7209 : List (BitVec 512) := [w1292,w2295,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7209 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7210 : List (BitVec 512) := [w1292,w2295,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7210 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7210 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(4,true))] s4_7210 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2295,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7211 : List (BitVec 512) := [w1292,w2295,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_7211 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7211 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(5,true))] s4_7211 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2295,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7213 : List (BitVec 512) := [w1292,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_7213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7213 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7214 : List (BitVec 512) := [w1292,w2354,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7214 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7215 : List (BitVec 512) := [w1292,w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7215 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7215 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(4,true))] s4_7215 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7216 : List (BitVec 512) := [w1292,w2427,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7216 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7217 : List (BitVec 512) := [w1292,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_7217 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7217 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7217 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7218 : List (BitVec 512) := [w1292,w2441,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7218 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7219 : List (BitVec 512) := [w1292,w2450,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7219 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(5,true))] s4_7219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2450,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2450 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7220 : List (BitVec 512) := [w1292,w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7220 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7224 : List (BitVec 512) := [w1292,w2499,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7224 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7311 : List (BitVec 512) := [w1292,w3766,w4041,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7311 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7322 : List (BitVec 512) := [w1292,w3766,w4344,w4641,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7322 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7349 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5283,w5393,w5956,w6179,w6300,w6588]
theorem b4_7349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7349 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7350 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5290,w5393,w5585,w5956,w6300,w6588]
theorem b4_7350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7350 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s4_7350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5290,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5290 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7351 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5294,w5393,w5956,w6179,w6300,w6588]
theorem b4_7351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7351 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5294,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5294 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7352 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5299,w5393,w5956,w6179,w6300,w6588]
theorem b4_7352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7352 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7353 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5303,w5393,w5585,w5956,w6300,w6588]
theorem b4_7353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7353 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s4_7353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5303,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5303 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
