import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13312 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_13312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13312 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true))] s4_13312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13313 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6372,w6588]
theorem b4_13313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13313 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(8,true))] s4_13313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6372,v0_6588] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6372 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13314 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_13314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13314 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true))] s4_13314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13315 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_13315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13315 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(7,true),(0,false))] s4_13315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13316 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_13316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13316 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true))] s4_13316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_13317 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_13317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13317 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s4_13317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13318 : List (BitVec 512) := [w3374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_13318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13318 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(7,true),(6,true))] s4_13318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13319 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_13319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13319 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_13319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5665,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5665 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13320 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_13320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13320 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(5,true),(0,false))] s4_13320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13321 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6371,w6588]
theorem b4_13321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13321 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(1,true)),(false,(0,true),(8,true))] s4_13321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6371,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6371 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13322 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_13322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13322 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true))] s4_13322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13323 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_13323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13323 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s4_13323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13324 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_13324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13324 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s4_13324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13325 : List (BitVec 512) := [w3376,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_13325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13325 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(6,true))] s4_13325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3376,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3376 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13326 : List (BitVec 512) := [w3382,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13326 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3382,v0_3766,v0_4344,v0_4483,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3382 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4483 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13327 : List (BitVec 512) := [w3382,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_13327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13327 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s4_13327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3382,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3382 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13328 : List (BitVec 512) := [w3382,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13328 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3382,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3382 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13329 : List (BitVec 512) := [w3385,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13329 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3385,v0_3766,v0_4344,v0_4499,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3385 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4499 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13330 : List (BitVec 512) := [w3385,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13330 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3385,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3385 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13331 : List (BitVec 512) := [w3386,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13331 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3386,v0_3766,v0_4344,v0_4502,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3386 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4502 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13332 : List (BitVec 512) := [w3386,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13332 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3386,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3386 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13333 : List (BitVec 512) := [w3391,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13333 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_13333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3391,v0_3766,v0_4344,v0_4515,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3391 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4515 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13334 : List (BitVec 512) := [w3391,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13334 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3391,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3391 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13335 : List (BitVec 512) := [w3392,w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13335 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3392,v0_3766,v0_4344,v0_4516,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3392 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4516 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13336 : List (BitVec 512) := [w3392,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13336 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3392,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3392 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13337 : List (BitVec 512) := [w3394,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13337 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_13337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3394,v0_3766,v0_4344,v0_4519,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3394 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4519 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13338 : List (BitVec 512) := [w3394,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13338 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3394,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3394 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13339 : List (BitVec 512) := [w3394,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_13339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13339 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s4_13339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3394,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3394 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13340 : List (BitVec 512) := [w3400,w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13340 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3400,v0_3766,v0_4344,v0_4544,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3400 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4544 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13341 : List (BitVec 512) := [w3400,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13341 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3400,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3400 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13342 : List (BitVec 512) := [w3403,w3766,w4344,w4557,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13342 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3403,v0_3766,v0_4344,v0_4557,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4557 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13343 : List (BitVec 512) := [w3403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13343 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13344 : List (BitVec 512) := [w3404,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13344 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_13344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3404,v0_3766,v0_4344,v0_4561,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3404 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4561 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13345 : List (BitVec 512) := [w3404,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13345 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3404,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3404 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13346 : List (BitVec 512) := [w3406,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13346 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3406,v0_3766,v0_4344,v0_4571,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3406 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4571 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13347 : List (BitVec 512) := [w3406,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13347 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_13347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3406,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3406 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13348 : List (BitVec 512) := [w3406,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_13348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13348 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s4_13348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3406,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3406 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13351 : List (BitVec 512) := [w3411,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13351 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4392,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4392 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13352 : List (BitVec 512) := [w3411,w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13352 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4402,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4402 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13353 : List (BitVec 512) := [w3411,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13353 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13354 : List (BitVec 512) := [w3411,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13354 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4412,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4412 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13355 : List (BitVec 512) := [w3411,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13355 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4413,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4413 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13356 : List (BitVec 512) := [w3411,w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4415,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4415 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13357 : List (BitVec 512) := [w3411,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13357 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_13357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4426,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4426 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13358 : List (BitVec 512) := [w3411,w3766,w4344,w4427,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13358 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_13358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4427,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4427 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13359 : List (BitVec 512) := [w3411,w3766,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13359 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_13359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4428,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4428 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13360 : List (BitVec 512) := [w3411,w3766,w4344,w4430,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_13360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4430,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4430 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13361 : List (BitVec 512) := [w3411,w3766,w4344,w4431,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13361 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_13361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4431,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4431 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13362 : List (BitVec 512) := [w3411,w3766,w4344,w4433,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13362 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_13362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4433,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4433 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13363 : List (BitVec 512) := [w3411,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13363 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4483,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4483 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13364 : List (BitVec 512) := [w3411,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13364 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4499,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4499 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13365 : List (BitVec 512) := [w3411,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13365 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4502,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4502 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13366 : List (BitVec 512) := [w3411,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13366 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13366 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_13366 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4515,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4515 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13367 : List (BitVec 512) := [w3411,w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13367 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4516,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4516 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13368 : List (BitVec 512) := [w3411,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13368 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_13368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4519,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4519 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13369 : List (BitVec 512) := [w3411,w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13369 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4544,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4544 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13370 : List (BitVec 512) := [w3411,w3766,w4344,w4557,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13370 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4557,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4557 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13371 : List (BitVec 512) := [w3411,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13371 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_13371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4561,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4561 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13372 : List (BitVec 512) := [w3411,w3766,w4344,w4567,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13372 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_13372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4567,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4567 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13373 : List (BitVec 512) := [w3411,w3766,w4344,w4568,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13373 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4568,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4568 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13374 : List (BitVec 512) := [w3411,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13374 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_13374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4571,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4571 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13375 : List (BitVec 512) := [w3411,w3766,w4344,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13375 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_13375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4589,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4589 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13376 : List (BitVec 512) := [w3411,w3766,w4344,w4591,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13376 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_13376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4591,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4591 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13377 : List (BitVec 512) := [w3411,w3766,w4344,w4592,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13377 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_13377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4592,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4592 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
