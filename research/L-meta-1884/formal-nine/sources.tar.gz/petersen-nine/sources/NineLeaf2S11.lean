import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_5052 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6781,w6832]
theorem b3_5052 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5052 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(8,true),(2,true))] s3_5052 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6781,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_5058 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6863]
theorem b3_5058 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5058 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(8,true),(2,true))] s3_5058 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832,v2_6863] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6863 rfl))))))))))) (by decide +kernel)
def s3_5068 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6832]
theorem b3_5068 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5068 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(8,true),(2,true))] s3_5068 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s3_5075 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6451,w6522,w6588]
theorem b3_5075 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5075 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(3,true),(7,true))] s3_5075 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_109 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_109 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true))] s4_109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_110 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_110 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true))] s4_110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_111 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_111 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true))] s4_111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_112 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_112 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true))] s4_112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_113 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_113 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [] s4_113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_114 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_114 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true))] s4_114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_115 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_115 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(3,true))] s4_115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_116 : List (BitVec 512) := [w7,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_116 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(8,true)),(false,(1,false),(0,false))] s4_116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_7,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6917] (PetersenWireProjection.cons pc2_7 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6917 rfl))))))))))) (by decide +kernel)
def s4_163 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_163 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true))] s4_163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_164 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_164 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true))] s4_164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_165 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_165 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s4_165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_166 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_166 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_166 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_166 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_167 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_167 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [] s4_167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_168 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_168 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true))] s4_168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_169 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_169 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_169 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true))] s4_169 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_170 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_170 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,false),(8,true))] s4_170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_171 : List (BitVec 512) := [w17,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_171 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false))] s4_171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_17,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6910] (PetersenWireProjection.cons pc2_17 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6910 rfl))))))))))) (by decide +kernel)
def s4_360 : List (BitVec 512) := [w26,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_360 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(4,true),(0,true))] s4_360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_1915,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_1915 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_361 : List (BitVec 512) := [w26,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6832]
theorem b4_361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_361 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(4,true),(0,true))] s4_361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_1915,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_1915 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_362 : List (BitVec 512) := [w26,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_362 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(1,false),(4,true))] s4_362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_1915,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_1915 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_363 : List (BitVec 512) := [w26,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_363 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true))] s4_363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_2171,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_2171 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_364 : List (BitVec 512) := [w26,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_364 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,true),(7,true))] s4_364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_2175,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_2175 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_365 : List (BitVec 512) := [w26,w2885,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_365 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,true))] s4_365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_2885,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_2885 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_366 : List (BitVec 512) := [w26,w2889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_366 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_366 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true))] s4_366 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_2889,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_2889 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_367 : List (BitVec 512) := [w26,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_367 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(2,true))] s4_367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3182,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3182 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_368 : List (BitVec 512) := [w26,w3186,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_368 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,true),(3,true))] s4_368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3186,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3186 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_369 : List (BitVec 512) := [w26,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_369 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true))] s4_369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_370 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_370 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true))] s4_370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_371 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_371 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true))] s4_371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_372 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_372 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_373 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_373 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s4_373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_374 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_374 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(6,true))] s4_374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_375 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_375 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(2,true))] s4_375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_376 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_376 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(7,true))] s4_376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_377 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_377 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(6,true))] s4_377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_378 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_378 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true))] s4_378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_379 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_379 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(7,true))] s4_379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_380 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_380 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(6,true))] s4_380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6904] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6904 rfl))))))))))) (by decide +kernel)
def s4_381 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_381 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,false),(3,true))] s4_381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6910] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6910 rfl))))))))))) (by decide +kernel)
def s4_382 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_382 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s4_382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6912] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6912 rfl))))))))))) (by decide +kernel)
def s4_383 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_383 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,false),(7,true))] s4_383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6917] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6917 rfl))))))))))) (by decide +kernel)
def s4_384 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_384 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(8,true),(2,true))] s4_384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_385 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_385 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s4_385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_386 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_386 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(8,true),(6,true))] s4_386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_387 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_387 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(4,true),(2,true))] s4_387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_388 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_388 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(4,true),(6,true))] s4_388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_389 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_389 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(3,true),(7,true))] s4_389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_390 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_390 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(3,true),(6,true))] s4_390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_391 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_391 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(3,true),(6,true))] s4_391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_392 : List (BitVec 512) := [w26,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_392 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(4,true),(1,false))] s4_392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_26,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_26 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_565 : List (BitVec 512) := [w43,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_565 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_43,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_43 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_566 : List (BitVec 512) := [w44,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_566 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_44,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_44 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_567 : List (BitVec 512) := [w45,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_567 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(5,true))] s4_567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_45,v2_195,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_45 (PetersenWireProjection.cons pc2_195 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_568 : List (BitVec 512) := [w45,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_568 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(5,true))] s4_568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_45,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_45 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_569 : List (BitVec 512) := [w45,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_569 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_45,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_45 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_575 : List (BitVec 512) := [w48,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_575 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_48,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_48 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_576 : List (BitVec 512) := [w49,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_576 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_49,v2_200,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_49 (PetersenWireProjection.cons pc2_200 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_577 : List (BitVec 512) := [w49,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_577 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_49,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_49 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_578 : List (BitVec 512) := [w49,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_578 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_49,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_49 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_579 : List (BitVec 512) := [w50,w202,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_579 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_50,v2_202,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_50 (PetersenWireProjection.cons pc2_202 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
