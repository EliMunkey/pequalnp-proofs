import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1466 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5470,w5585,w5698,w5956,w6300,w6690]
theorem b5_1466 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1466 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s5_1466 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5470,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1467 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5471,w5698,w5769,w5956,w6300,w6588]
theorem b5_1467 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1467 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_1467 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5471,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1468 : List (BitVec 512) := [w967,w3766,w4716,w5200,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b5_1468 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1468 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_1468 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1469 : List (BitVec 512) := [w967,w3766,w4716,w5200,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b5_1469 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1469 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_1469 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5200,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1470 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6748]
theorem b5_1470 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1470 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(6,true))] s5_1470 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_1471 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6748]
theorem b5_1471 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1471 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(6,true))] s5_1471 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6690,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_1472 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b5_1472 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1472 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s5_1472 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1473 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6690]
theorem b5_1473 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1473 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s5_1473 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1474 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6895]
theorem b5_1474 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1474 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(3,true))] s5_1474 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl)))))))))) (by decide +kernel)
def s5_1475 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5956,w6225,w6300,w6588,w6720]
theorem b5_1475 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1475 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(6,true)),(false,(3,true),(0,false))] s5_1475 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_1476 : List (BitVec 512) := [w967,w3935,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b5_1476 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1476 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(6,true)),(false,(1,false),(2,true))] s5_1476 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3935,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6044,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3935 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6044 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1484 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1484 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1484 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s5_1484 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_972,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_972 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1485 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1485 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1485 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,false),(9,true))] s5_1485 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_972,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_972 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1496 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1496 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1496 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s5_1496 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_975,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_975 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1497 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1497 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1497 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s5_1497 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_975,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_975 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1512 : List (BitVec 512) := [w985,w1795,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1512 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1512 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,false),(9,true))] s5_1512 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_985,v3_1795,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_985 (PetersenWireProjection.cons pc3_1795 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1514 : List (BitVec 512) := [w985,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1514 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1514 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s5_1514 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_985,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_985 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1515 : List (BitVec 512) := [w985,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1515 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1515 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,false),(9,true))] s5_1515 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_985,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_985 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1525 : List (BitVec 512) := [w989,w1795,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1525 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1525 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,false),(9,true))] s5_1525 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_989,v3_1795,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_989 (PetersenWireProjection.cons pc3_1795 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1527 : List (BitVec 512) := [w989,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1527 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1527 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,false),(9,true))] s5_1527 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_989,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_989 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1546 : List (BitVec 512) := [w1002,w2063,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1546 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1546 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,false),(9,true))] s5_1546 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1002,v3_2063,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1002 (PetersenWireProjection.cons pc3_2063 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1548 : List (BitVec 512) := [w1002,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1548 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1548 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,false),(9,true))] s5_1548 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1002,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1002 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1561 : List (BitVec 512) := [w1007,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_1561 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1561 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s5_1561 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1007,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1007 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1579 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1579 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1579 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s5_1579 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1022,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1022 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1580 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1580 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1580 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,false),(9,true))] s5_1580 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1022,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1022 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1589 : List (BitVec 512) := [w1025,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1589 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,false),(9,true))] s5_1589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1025,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1025 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1595 : List (BitVec 512) := [w1026,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1595 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1595 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,false),(9,true))] s5_1595 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1026,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1026 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1862 : List (BitVec 512) := [w1092,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1862 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1862 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,false)),(false,(0,true),(2,true)),(false,(0,true),(9,true))] s5_1862 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1092,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1092 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1894 : List (BitVec 512) := [w1112,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1894 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1894 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1894 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1112,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1112 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1906 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_1906 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1906 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1906 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1933 : List (BitVec 512) := [w1119,w3152,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1933 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1933 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1933 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3152,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3152 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1960 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6690]
theorem b5_1960 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1960 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1960 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1962 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b5_1962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1962 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1964 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_1964 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1964 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1964 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2251 : List (BitVec 512) := [w1249,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2251 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_2251 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1249,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1249 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2258 : List (BitVec 512) := [w1252,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2258 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_2258 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1252,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1252 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2281 : List (BitVec 512) := [w1265,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2281 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2281 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_2281 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1265,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1265 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2286 : List (BitVec 512) := [w1268,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2286 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2286 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_2286 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1268,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1268 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2311 : List (BitVec 512) := [w1284,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_2311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true)),(false,(6,true),(7,true))] s5_2311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1284,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1284 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2350 : List (BitVec 512) := [w1292,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_2350 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2350 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_2350 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2395 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6690]
theorem b5_2395 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2395 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true)),(false,(6,true),(7,true))] s5_2395 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2399 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6389,w6522,w6588]
theorem b5_2399 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2399 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true)),(false,(6,true),(7,true))] s5_2399 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2514 : List (BitVec 512) := [w1312,w3766,w4121,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2514 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2514 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s5_2514 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4121,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_2517 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_2517 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2517 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_2517 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl)))))))))) (by decide +kernel)
def s5_2538 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_2538 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2538 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2538 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_2552 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5678,w5769,w5956,w6300,w6720]
theorem b5_2552 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2552 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s5_2552 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_5135,v3_5393,v3_5678,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5678 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_2605 : List (BitVec 512) := [w1328,w3177,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2605 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2605 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_2605 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3177,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3177 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 rfl)))))))))) (by decide +kernel)
def s5_2608 : List (BitVec 512) := [w1328,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2608 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(0,false))] s5_2608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3197,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3197 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2613 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2613 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2613 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(2,true),(6,false))] s5_2613 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2621 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2621 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2621 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(2,true),(1,true))] s5_2621 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3280,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3280 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2633 : List (BitVec 512) := [w1328,w3766,w4321,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_2633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2633 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_2633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4321,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4321 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl)))))))))) (by decide +kernel)
def s5_2648 : List (BitVec 512) := [w1328,w3766,w4344,w4908,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2648 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2648 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s5_2648 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4908,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4908 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2653 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5773,w5956,w6300,w6720]
theorem b5_2653 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2653 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2653 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5773,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5773 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_2657 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2657 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2657 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2657 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_2660 : List (BitVec 512) := [w1328,w3766,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2660 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2660 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s5_2660 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2669 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_2669 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2669 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s5_2669 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2751 : List (BitVec 512) := [w1369,w3766,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2751 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2751 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,true))] s5_2751 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1369,v3_3766,v3_4402,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1369 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4402 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2812 : List (BitVec 512) := [w1374,w3766,w4174,w4716,w5135,w5393,w5698,w6179,w6300,w6832]
theorem b5_2812 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2812 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s5_2812 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1374,v3_3766,v3_4174,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4174 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_2829 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b5_2829 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2829 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_2829 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6866] (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6866 rfl)))))))))) (by decide +kernel)
def s5_2830 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6378,w6588]
theorem b5_2830 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2830 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true))] s5_2830 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6378,v3_6588] (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6378 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2833 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_2833 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2833 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s5_2833 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_2834 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5684,w6179,w6300,w6832]
theorem b5_2834 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2834 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s5_2834 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5684,v3_6179,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5684 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_2878 : List (BitVec 512) := [w1384,w3199,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2878 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2878 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(0,false))] s5_2878 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3199,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3199 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_2884 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2884 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2884 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(2,true),(6,false))] s5_2884 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
end NineCert
