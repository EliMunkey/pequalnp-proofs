import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_16705 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5512,w5585,w5956,w6300,w6588]
theorem b4_16705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16705 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5512,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5512 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16706 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b4_16706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16706 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16712 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_16712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16712 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16718 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b4_16718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16718 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16725 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b4_16725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16725 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16736 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b4_16736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16736 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s4_16758 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b4_16758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16758 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4571,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4571 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16770 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b4_16770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16770 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4571,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4571 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_16782 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6767,w6873]
theorem b4_16782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16782 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4571,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4571 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_16791 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6029,w6300,w6588]
theorem b4_16791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16791 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_16791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_17012 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6250,w6300,w6588]
theorem b4_17012 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17012 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_17012 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6250,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6250 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17016 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6508,w6588]
theorem b4_17016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17016 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_17016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6508,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6508 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17019 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6562,w6588]
theorem b4_17019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17019 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_17019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6562,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6562 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17026 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6584,w6588]
theorem b4_17026 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17026 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(5,true))] s4_17026 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6584,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6584 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17030 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6830]
theorem b4_17030 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17030 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_17030 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6830] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6830 rfl))))))))))) (by decide +kernel)
def s4_17037 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6872]
theorem b4_17037 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17037 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(9,true))] s4_17037 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6872] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6872 rfl))))))))))) (by decide +kernel)
def s4_17041 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6767,w6908]
theorem b4_17041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17041 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(0,false),(4,true))] s4_17041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6767,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17047 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6827,w6873]
theorem b4_17047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17047 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(9,true),(7,true))] s4_17047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6827,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6827 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17055 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6464,w6767,w6873]
theorem b4_17055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17055 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(7,true))] s4_17055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17062 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6522,w6588,w6901]
theorem b4_17062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17062 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_17062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6901] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6901 rfl))))))))))) (by decide +kernel)
def s4_17064 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6522,w6767,w6873]
theorem b4_17064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17064 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_17064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17070 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w6158,w6522,w6588,w6873]
theorem b4_17070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17070 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_17070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17072 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w6179,w6300,w6767,w6832]
theorem b4_17072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17072 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(4,true),(9,true))] s4_17072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17150 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6101,w6300,w6543,w6588]
theorem b4_17150 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17150 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(1,false))] s4_17150 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6101,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17151 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6101,w6389,w6522,w6588]
theorem b4_17151 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17151 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_17151 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17152 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6101,w6522,w6588,w6873]
theorem b4_17152 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17152 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_17152 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6101,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17153 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6300,w6588,w6908]
theorem b4_17153 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17153 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(4,true),(1,false))] s4_17153 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6300,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17154 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6300,w6690,w6832]
theorem b4_17154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17154 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(8,true)),(false,(4,true),(9,true))] s4_17154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6300,v2_6690,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17155 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6389,w6522,w6588]
theorem b4_17155 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17155 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(2,true)),(false,(5,true),(4,true))] s4_17155 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17156 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6522,w6588,w6873]
theorem b4_17156 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17156 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true))] s4_17156 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17157 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6225,w6300,w6522,w6588]
theorem b4_17157 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17157 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_17157 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6225,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17158 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5698,w6179,w6300,w6522,w6588]
theorem b4_17158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17158 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(3,true)),(false,(7,true),(4,true))] s4_17158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5698,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17159 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5698,w6179,w6300,w6588,w6832]
theorem b4_17159 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17159 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true))] s4_17159 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5698,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17160 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w6179,w6300,w6522,w6588,w6785]
theorem b4_17160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17160 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(4,true),(3,true)),(false,(7,true),(4,true))] s4_17160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_6179,v2_6300,v2_6522,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_17161 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6237,w6300,w6588]
theorem b4_17161 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17161 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_17161 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17162 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6499,w6588]
theorem b4_17162 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17162 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_17162 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17163 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6553,w6588]
theorem b4_17163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17163 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_17163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17164 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6567,w6588]
theorem b4_17164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17164 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(5,true))] s4_17164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17165 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6588,w6821]
theorem b4_17165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17165 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_17165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_17166 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6588,w6866]
theorem b4_17166 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17166 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(9,true))] s4_17166 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_17167 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6785,w6873]
theorem b4_17167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17167 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(9,true),(7,true))] s4_17167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17168 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6464,w6588,w6873]
theorem b4_17168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17168 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(7,true))] s4_17168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17169 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6522,w6588,w6873]
theorem b4_17169 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17169 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_17169 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17203 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6561,w6588]
theorem b4_17203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17203 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true)),(false,(1,false),(4,true))] s4_17203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6561,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6561 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17209 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6585,w6588]
theorem b4_17209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17209 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(5,true))] s4_17209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6585,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6585 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17218 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6767,w6908]
theorem b4_17218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17218 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(1,false),(5,true))] s4_17218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6767,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17219 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6782,w6873]
theorem b4_17219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17219 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(9,true),(8,true))] s4_17219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6782,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17225 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w6101,w6451,w6522,w6588]
theorem b4_17225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17225 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_17225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6101,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17268 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5892,w5956,w6300,w6588]
theorem b4_17268 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17268 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_17268 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5760,v2_5892,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5760 (PetersenWireProjection.cons pc2_5892 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17312 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6250,w6300,w6588]
theorem b4_17312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17312 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6250,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6250 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17318 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6508,w6588]
theorem b4_17318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17318 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(5,true))] s4_17318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6508,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6508 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17323 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6560,w6588]
theorem b4_17323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17323 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(5,true))] s4_17323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6560,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6560 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17328 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6586,w6588]
theorem b4_17328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17328 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6586,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6586 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17334 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6830]
theorem b4_17334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17334 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(9,true))] s4_17334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6830] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6830 rfl))))))))))) (by decide +kernel)
def s4_17338 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6864]
theorem b4_17338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17338 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_17338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6864] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6864 rfl))))))))))) (by decide +kernel)
def s4_17343 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6902]
theorem b4_17343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17343 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_17343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6902] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6902 rfl))))))))))) (by decide +kernel)
def s4_17358 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6767,w6908]
theorem b4_17358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17358 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(1,false),(5,true))] s4_17358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6767,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17359 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6781,w6832]
theorem b4_17359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17359 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(9,true),(3,true))] s4_17359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6781,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17364 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6829,w6873]
theorem b4_17364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17364 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true))] s4_17364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6829,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6829 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17373 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6452,w6522,w6588]
theorem b4_17373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17373 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(5,true),(3,true))] s4_17373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6452,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6452 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17378 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6522,w6767,w6873]
theorem b4_17378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17378 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(5,true),(9,true))] s4_17378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6522,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17388 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6158,w6389,w6522,w6588]
theorem b4_17388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17388 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(5,true),(3,true))] s4_17388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6158,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17395 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6225,w6451,w6522,w6588]
theorem b4_17395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17395 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_17395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6225,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17396 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6249,w6300,w6522,w6588]
theorem b4_17396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17396 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_17396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6249,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6249 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
