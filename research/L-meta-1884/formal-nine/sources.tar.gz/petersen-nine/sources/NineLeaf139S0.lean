import NinePin139
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10190 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6690,w6890]
theorem b4_10190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10190 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s4_10190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1403,v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_5956,v139_6522,v139_6690,v139_6890] (PetersenWireProjection.cons pc139_1403 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6690 (PetersenWireProjection.cons pc139_6890 rfl))))))))))) (by decide +kernel)
def s5_614 : List (BitVec 512) := [w362,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_614 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_614 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_614 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_362,v139_3766,v139_4716,v139_5135,v139_5393,v139_5585,v139_5698,v139_5956,v139_6300,v139_6690] (PetersenWireProjection.cons pc139_362 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6690 rfl)))))))))) (by decide +kernel)
def s5_2670 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_2670 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2670 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_2670 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1328,v139_3766,v139_4716,v139_5135,v139_5393,v139_5698,v139_5956,v139_6179,v139_6300,v139_6690] (PetersenWireProjection.cons pc139_1328 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6179 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6690 rfl)))))))))) (by decide +kernel)
def s5_3210 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6522,w6690]
theorem b5_3210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3210 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1403,v139_3766,v139_4716,v139_5135,v139_5393,v139_5585,v139_5698,v139_5956,v139_6522,v139_6690] (PetersenWireProjection.cons pc139_1403 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6690 rfl)))))))))) (by decide +kernel)
def s5_3211 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6522,w6890]
theorem b5_3211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3211 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1403,v139_3766,v139_4716,v139_5135,v139_5393,v139_5585,v139_5698,v139_5956,v139_6522,v139_6890] (PetersenWireProjection.cons pc139_1403 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6890 rfl)))))))))) (by decide +kernel)
def s5_3307 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_3307 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3307 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3307 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1415,v139_3766,v139_4716,v139_5135,v139_5393,v139_5698,v139_5956,v139_6179,v139_6300,v139_6690] (PetersenWireProjection.cons pc139_1415 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6179 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6690 rfl)))))))))) (by decide +kernel)
def s5_3349 : List (BitVec 512) := [w1839,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3349 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3349 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3349 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1839,v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_5956,v139_6300,v139_6588] (PetersenWireProjection.cons pc139_1839 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6588 rfl)))))))))) (by decide +kernel)
def s5_3350 : List (BitVec 512) := [w1871,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3350 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3350 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3350 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1871,v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_5956,v139_6300,v139_6588] (PetersenWireProjection.cons pc139_1871 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6588 rfl)))))))))) (by decide +kernel)
def s5_3351 : List (BitVec 512) := [w1922,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3351 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3351 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_3351 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1922,v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_5956,v139_6300,v139_6588] (PetersenWireProjection.cons pc139_1922 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6300 (PetersenWireProjection.cons pc139_6588 rfl)))))))))) (by decide +kernel)
def s5_5463 : List (BitVec 512) := [w3766,w4344,w4348,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_5463 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5463 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_5463 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_3766,v139_4344,v139_4348,v139_4716,v139_5135,v139_5393,v139_5585,v139_5956,v139_6522,v139_6588] (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4348 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6588 rfl)))))))))) (by decide +kernel)
def s5_5852 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5844,w5956,w6522,w6588]
theorem b5_5852 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5852 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s5_5852 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_5844,v139_5956,v139_6522,v139_6588] (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_5844 (PetersenWireProjection.cons pc139_5956 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6588 rfl)))))))))) (by decide +kernel)
def s6_29 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5698,w6179,w6522,w6890]
theorem b6_29 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_29 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s6_29 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1403,v139_3766,v139_4716,v139_5135,v139_5393,v139_5698,v139_6179,v139_6522,v139_6890] (PetersenWireProjection.cons pc139_1403 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5698 (PetersenWireProjection.cons pc139_6179 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6890 rfl))))))))) (by decide +kernel)
def s6_36 : List (BitVec 512) := [w1922,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b6_36 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_36 := by
  intro m le c
  apply rejects_sound r139 i7 6 tgt (small139 adj) hot139 [] s6_36 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v139_1922,v139_3766,v139_4344,v139_4716,v139_5135,v139_5393,v139_5585,v139_6522,v139_6588] (PetersenWireProjection.cons pc139_1922 (PetersenWireProjection.cons pc139_3766 (PetersenWireProjection.cons pc139_4344 (PetersenWireProjection.cons pc139_4716 (PetersenWireProjection.cons pc139_5135 (PetersenWireProjection.cons pc139_5393 (PetersenWireProjection.cons pc139_5585 (PetersenWireProjection.cons pc139_6522 (PetersenWireProjection.cons pc139_6588 rfl))))))))) (by decide +kernel)
end NineCert
