import NinePin116
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_563 : List (BitVec 512) := [w40,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_563 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_40,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_40 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1022 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_1022 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1022 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1022 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_160,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6904] (PetersenWireProjection.cons pc116_160 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6904 rfl))))))))))) (by decide +kernel)
def s4_1023 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_1023 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1023 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1023 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_160,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6908] (PetersenWireProjection.cons pc116_160 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6908 rfl))))))))))) (by decide +kernel)
def s4_1034 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_1034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1034 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_160,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6464,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_160 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6464 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1035 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_1035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1035 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_160,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6522,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_160 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1253 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_1253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1253 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_192,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6895] (PetersenWireProjection.cons pc116_192 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6895 rfl))))))))))) (by decide +kernel)
def s4_1481 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_1481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1481 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_195,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6890] (PetersenWireProjection.cons pc116_195 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_1487 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_1487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1487 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_195,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6908] (PetersenWireProjection.cons pc116_195 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6908 rfl))))))))))) (by decide +kernel)
def s4_1506 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_1506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1506 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_195,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6522,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_195 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1515 : List (BitVec 512) := [w197,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1515 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_197,v116_1635,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_197 (PetersenWireProjection.cons pc116_1635 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl))))))))))) (by decide +kernel)
def s4_1521 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1521 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_197,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_197 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1647 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_1647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1647 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_200,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6890] (PetersenWireProjection.cons pc116_200 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_1650 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_1650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1650 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_200,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6904] (PetersenWireProjection.cons pc116_200 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6904 rfl))))))))))) (by decide +kernel)
def s4_1651 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_1651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1651 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_200,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6912] (PetersenWireProjection.cons pc116_200 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6912 rfl))))))))))) (by decide +kernel)
def s4_1653 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6604,w6873]
theorem b4_1653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1653 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_200,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6604,v116_6873] (PetersenWireProjection.cons pc116_200 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6604 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1668 : List (BitVec 512) := [w201,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1668 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_201,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_201 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_1674 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1674 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_1674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_204,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_204 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_9763 : List (BitVec 512) := [w1403,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6873,w6890]
theorem b4_9763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9763 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_9763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_1664,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6873,v116_6890] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_1664 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6873 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_10167 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6873,w6890]
theorem b4_10167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10167 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_10167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6464,v116_6873,v116_6890] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6464 (PetersenWireProjection.cons pc116_6873 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_10192 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6873,w6890]
theorem b4_10192 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10192 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_10192 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6522,v116_6873,v116_6890] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6873 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_10569 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873,w6905]
theorem b4_10569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10569 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_10569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1415,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6873,v116_6905] (PetersenWireProjection.cons pc116_1415 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6873 (PetersenWireProjection.cons pc116_6905 rfl))))))))))) (by decide +kernel)
def s4_10580 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6478,w6873]
theorem b4_10580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10580 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_10580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1415,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6464,v116_6478,v116_6873] (PetersenWireProjection.cons pc116_1415 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6464 (PetersenWireProjection.cons pc116_6478 (PetersenWireProjection.cons pc116_6873 rfl))))))))))) (by decide +kernel)
def s4_12538 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6436,w6522,w6588]
theorem b4_12538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12538 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_12538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6389,v116_6436,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6389 (PetersenWireProjection.cons pc116_6436 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl))))))))))) (by decide +kernel)
def s4_12540 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6478,w6522,w6588]
theorem b4_12540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12540 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_12540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6389,v116_6478,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6389 (PetersenWireProjection.cons pc116_6478 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl))))))))))) (by decide +kernel)
def s4_12546 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588,w6890]
theorem b4_12546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12546 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_12546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6389,v116_6522,v116_6588,v116_6890] (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6389 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6890 rfl))))))))))) (by decide +kernel)
def s4_13006 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6422,w6543,w6588]
theorem b4_13006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13006 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s4_13006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_2488,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6389,v116_6422,v116_6543,v116_6588] (PetersenWireProjection.cons pc116_2488 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6389 (PetersenWireProjection.cons pc116_6422 (PetersenWireProjection.cons pc116_6543 (PetersenWireProjection.cons pc116_6588 rfl))))))))))) (by decide +kernel)
def s5_237 : List (BitVec 512) := [w120,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_237 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_237 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_237 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_120,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_120 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_288 : List (BitVec 512) := [w146,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_288 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_146,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_146 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_295 : List (BitVec 512) := [w153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_295 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_153,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_153 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_299 : List (BitVec 512) := [w160,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_299 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_299 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_299 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_160,v116_2527,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_160 (PetersenWireProjection.cons pc116_2527 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_342 : List (BitVec 512) := [w182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_342 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_342 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_342 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_182,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_182 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_345 : List (BitVec 512) := [w189,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_345 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_345 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_345 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_189,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_189 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_350 : List (BitVec 512) := [w192,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_350 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_350 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_350 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_192,v116_2527,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_192 (PetersenWireProjection.cons pc116_2527 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_362 : List (BitVec 512) := [w195,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_362 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_362 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_362 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_195,v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_195 (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_413 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6602]
theorem b5_413 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_413 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_413 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_197,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6602] (PetersenWireProjection.cons pc116_197 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6602 rfl)))))))))) (by decide +kernel)
def s5_417 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6332,w6588]
theorem b5_417 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_417 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_417 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_197,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6332,v116_6588] (PetersenWireProjection.cons pc116_197 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6332 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_419 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_419 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_419 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_419 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_197,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_197 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_450 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6608]
theorem b5_450 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_450 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_450 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_204,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6608] (PetersenWireProjection.cons pc116_204 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6608 rfl)))))))))) (by decide +kernel)
def s5_458 : List (BitVec 512) := [w205,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_458 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_458 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_458 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_205,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6300,v116_6588] (PetersenWireProjection.cons pc116_205 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_3100 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6873]
theorem b5_3100 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3100 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3100 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6522,v116_6873] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6873 rfl)))))))))) (by decide +kernel)
def s5_3101 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6890]
theorem b5_3101 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3101 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3101 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6522,v116_6890] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6890 rfl)))))))))) (by decide +kernel)
def s5_3116 : List (BitVec 512) := [w1403,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6890]
theorem b5_3116 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3116 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3116 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_2527,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6300,v116_6890] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_2527 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6300 (PetersenWireProjection.cons pc116_6890 rfl)))))))))) (by decide +kernel)
def s5_3172 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6873]
theorem b5_3172 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3172 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3172 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1403,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6567,v116_6873] (PetersenWireProjection.cons pc116_1403 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6567 (PetersenWireProjection.cons pc116_6873 rfl)))))))))) (by decide +kernel)
def s5_3290 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6890]
theorem b5_3290 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3290 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3290 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1415,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6522,v116_6890] (PetersenWireProjection.cons pc116_1415 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6890 rfl)))))))))) (by decide +kernel)
def s5_3291 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6873]
theorem b5_3291 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3291 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_3291 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_1415,v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_5956,v116_6567,v116_6873] (PetersenWireProjection.cons pc116_1415 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6567 (PetersenWireProjection.cons pc116_6873 rfl)))))))))) (by decide +kernel)
def s5_4216 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6355,w6522,w6588]
theorem b5_4216 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4216 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_4216 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_2468,v116_3766,v116_4344,v116_4716,v116_5135,v116_5585,v116_5956,v116_6355,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_2468 (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_5956 (PetersenWireProjection.cons pc116_6355 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
def s5_6089 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6002,w6522,w6588,w6873]
theorem b5_6089 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6089 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_6089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_6002,v116_6522,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_6002 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl)))))))))) (by decide +kernel)
def s5_6092 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6003,w6522,w6588,w6873]
theorem b5_6092 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6092 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_6092 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_6003,v116_6522,v116_6588,v116_6873] (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_6003 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 (PetersenWireProjection.cons pc116_6873 rfl)))))))))) (by decide +kernel)
def s5_6093 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6004,w6389,w6522,w6588]
theorem b5_6093 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6093 := by
  intro m le c
  apply rejects_sound r116 i8 7 tgt (small116 adj) hot116 [] s5_6093 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v116_3766,v116_4344,v116_4716,v116_5135,v116_5393,v116_5585,v116_6004,v116_6389,v116_6522,v116_6588] (PetersenWireProjection.cons pc116_3766 (PetersenWireProjection.cons pc116_4344 (PetersenWireProjection.cons pc116_4716 (PetersenWireProjection.cons pc116_5135 (PetersenWireProjection.cons pc116_5393 (PetersenWireProjection.cons pc116_5585 (PetersenWireProjection.cons pc116_6004 (PetersenWireProjection.cons pc116_6389 (PetersenWireProjection.cons pc116_6522 (PetersenWireProjection.cons pc116_6588 rfl)))))))))) (by decide +kernel)
end NineCert
