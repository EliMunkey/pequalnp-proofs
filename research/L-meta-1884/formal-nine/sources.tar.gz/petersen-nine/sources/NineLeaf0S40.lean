import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3516 : List (BitVec 512) := [w852,w3127,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_3516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3516 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(1,false),(2,true))] s4_3516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3127,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3127 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3517 : List (BitVec 512) := [w852,w3127,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_3517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3517 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(6,true),(2,true))] s4_3517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3127,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3127 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3518 : List (BitVec 512) := [w852,w3129,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3518 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_3518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3129,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3129 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3519 : List (BitVec 512) := [w852,w3149,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_3519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3519 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(6,true),(3,true))] s4_3519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3149,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3149 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3520 : List (BitVec 512) := [w852,w3150,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3520 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(2,true))] s4_3520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3150,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3150 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3521 : List (BitVec 512) := [w852,w3152,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_3521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3521 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(7,true),(3,true))] s4_3521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3152,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3152 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3522 : List (BitVec 512) := [w852,w3153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3522 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(2,true))] s4_3522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3153,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3153 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3523 : List (BitVec 512) := [w852,w3154,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3523 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(2,true))] s4_3523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3154,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3154 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3524 : List (BitVec 512) := [w852,w3175,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3524 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(0,true)),(false,(3,true),(7,true))] s4_3524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3175,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3175 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3525 : List (BitVec 512) := [w852,w3176,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_3525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3525 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(6,true),(7,true))] s4_3525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3176,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3176 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3526 : List (BitVec 512) := [w852,w3177,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3526 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(2,true))] s4_3526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3177,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3177 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3527 : List (BitVec 512) := [w852,w3179,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3527 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(2,true))] s4_3527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3179,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3179 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3528 : List (BitVec 512) := [w852,w3180,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3528 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(2,true))] s4_3528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3180,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3180 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3529 : List (BitVec 512) := [w852,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_3529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3529 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true)),(false,(8,true),(7,true))] s4_3529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3182,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3182 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3530 : List (BitVec 512) := [w852,w3182,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_3530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3530 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(1,false),(2,true))] s4_3530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3182,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3182 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_3531 : List (BitVec 512) := [w852,w3183,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3531 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(2,true))] s4_3531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3183,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3183 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3532 : List (BitVec 512) := [w852,w3184,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3532 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(2,true),(0,true))] s4_3532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3184,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3184 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3533 : List (BitVec 512) := [w852,w3186,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3533 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(2,true))] s4_3533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3186,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3186 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3534 : List (BitVec 512) := [w852,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3534 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_3534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4392,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4392 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3535 : List (BitVec 512) := [w852,w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3535 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_3535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4402,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4402 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3536 : List (BitVec 512) := [w852,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3536 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_3536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3537 : List (BitVec 512) := [w852,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3537 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_3537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4412,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4412 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3538 : List (BitVec 512) := [w852,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3538 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_3538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4413,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4413 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3539 : List (BitVec 512) := [w852,w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3539 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_3539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4415,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4415 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3540 : List (BitVec 512) := [w852,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3540 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_3540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4426,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4426 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3541 : List (BitVec 512) := [w852,w3766,w4344,w4427,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3541 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_3541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4427,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4427 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3542 : List (BitVec 512) := [w852,w3766,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3542 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3542 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_3542 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4428,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4428 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3543 : List (BitVec 512) := [w852,w3766,w4344,w4430,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3543 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_3543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4430,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4430 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3544 : List (BitVec 512) := [w852,w3766,w4344,w4431,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3544 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3544 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_3544 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4431,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4431 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3545 : List (BitVec 512) := [w852,w3766,w4344,w4433,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3545 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_3545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4433,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4433 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3546 : List (BitVec 512) := [w852,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3546 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_3546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4483,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4483 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3547 : List (BitVec 512) := [w852,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3547 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_3547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4499,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4499 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3548 : List (BitVec 512) := [w852,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3548 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_3548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4502,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4502 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3549 : List (BitVec 512) := [w852,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3549 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_3549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4515,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4515 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3550 : List (BitVec 512) := [w852,w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3550 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_3550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4516,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4516 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3551 : List (BitVec 512) := [w852,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3551 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_3551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4519,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4519 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3552 : List (BitVec 512) := [w852,w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3552 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3552 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_3552 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4544,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4544 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3553 : List (BitVec 512) := [w852,w3766,w4344,w4557,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3553 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_3553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4557,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4557 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3554 : List (BitVec 512) := [w852,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3554 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_3554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4561,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4561 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3555 : List (BitVec 512) := [w852,w3766,w4344,w4567,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3555 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_3555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4567,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4567 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3556 : List (BitVec 512) := [w852,w3766,w4344,w4568,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3556 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3556 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_3556 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4568,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4568 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3557 : List (BitVec 512) := [w852,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3557 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_3557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4571,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4571 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3558 : List (BitVec 512) := [w852,w3766,w4344,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3558 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_3558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4589,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4589 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3559 : List (BitVec 512) := [w852,w3766,w4344,w4591,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3559 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3559 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_3559 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4591,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4591 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3560 : List (BitVec 512) := [w852,w3766,w4344,w4592,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3560 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3560 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_3560 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4592,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4592 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3561 : List (BitVec 512) := [w852,w3766,w4344,w4596,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3561 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_3561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4596,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4596 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3562 : List (BitVec 512) := [w852,w3766,w4344,w4597,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3562 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_3562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4597,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4597 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3563 : List (BitVec 512) := [w852,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3563 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_3563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4599,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4599 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3564 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3564 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_3564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4746,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4746 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3565 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3565 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_3565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4747,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4747 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3566 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3566 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_3566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4748,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4748 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3567 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3567 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_3567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4750,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4750 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3568 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4751,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_3568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4751,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4751 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3569 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4753,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3569 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_3569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4753,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4753 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3570 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4764,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3570 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_3570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4764,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4764 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3571 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4765,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3571 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_3571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4765,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4765 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3572 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3572 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3572 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_3572 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4766,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3573 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4768,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3573 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3573 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_3573 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4768,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4768 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3574 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4769,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3574 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_3574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4769,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4769 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3575 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4771,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3575 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_3575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4771,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4771 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3576 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4778,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3576 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_3576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4778,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4778 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3577 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4779,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3577 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_3577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4779,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4779 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3578 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4780,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3578 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_3578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4780,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4780 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3579 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4782,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3579 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_3579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4782,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4782 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
