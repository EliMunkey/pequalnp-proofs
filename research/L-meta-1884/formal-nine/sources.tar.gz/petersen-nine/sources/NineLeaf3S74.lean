import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_67 : List (BitVec 512) := [w22,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_67 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_67 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_67 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_22,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_22 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_68 : List (BitVec 512) := [w22,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_68 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_68 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_68 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_22,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_22 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_69 : List (BitVec 512) := [w22,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_69 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_69 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(1,true))] s5_69 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_22,v3_3935,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_22 (PetersenWireProjection.cons pc3_3935 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_119 : List (BitVec 512) := [w33,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_119 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_33,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_33 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_120 : List (BitVec 512) := [w33,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_120 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(2,true),(0,true))] s5_120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_33,v3_3332,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_33 (PetersenWireProjection.cons pc3_3332 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_126 : List (BitVec 512) := [w35,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_126 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_126 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_126 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_35,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_35 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_127 : List (BitVec 512) := [w35,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_127 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_35,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_35 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_128 : List (BitVec 512) := [w35,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_128 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_35,v3_2530,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_35 (PetersenWireProjection.cons pc3_2530 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_129 : List (BitVec 512) := [w35,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_129 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_35,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_35 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_130 : List (BitVec 512) := [w35,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_130 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_130 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(2,true),(0,true))] s5_130 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_35,v3_3332,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_35 (PetersenWireProjection.cons pc3_3332 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_177 : List (BitVec 512) := [w75,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_177 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_177 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s5_177 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_75,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_75 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_207 : List (BitVec 512) := [w105,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_207 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_207 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_207 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_105,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_105 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_208 : List (BitVec 512) := [w106,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_208 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_208 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_208 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_106,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_106 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_213 : List (BitVec 512) := [w111,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_213 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_213 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_213 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_111,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_111 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_214 : List (BitVec 512) := [w112,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_214 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_214 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_214 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_112,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_112 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_216 : List (BitVec 512) := [w115,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_216 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_216 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_216 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_115,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_115 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_217 : List (BitVec 512) := [w116,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_217 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_116,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_116 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_218 : List (BitVec 512) := [w117,w1875,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_218 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true))] s5_218 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_1875,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_219 : List (BitVec 512) := [w117,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_219 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_219 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_220 : List (BitVec 512) := [w117,w2527,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_220 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_220 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_2527,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_221 : List (BitVec 512) := [w117,w3187,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_221 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_221 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s5_221 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3187,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3187 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_222 : List (BitVec 512) := [w117,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_222 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_222 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_222 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3258,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_223 : List (BitVec 512) := [w117,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_223 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_223 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(1,true),(0,true))] s5_223 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3280,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3280 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_224 : List (BitVec 512) := [w117,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_225 : List (BitVec 512) := [w117,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_225 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_225 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,false)),(false,(2,true),(0,true))] s5_225 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3332,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3332 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_226 : List (BitVec 512) := [w117,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_226 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_226 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_226 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_227 : List (BitVec 512) := [w117,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_227 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_227 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_227 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6522,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_228 : List (BitVec 512) := [w117,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_228 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_228 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_228 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_229 : List (BitVec 512) := [w117,w3766,w4350,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_229 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_229 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_229 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4350,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4350 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_230 : List (BitVec 512) := [w117,w3766,w4716,w4796,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_230 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s5_230 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4716,v3_4796,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4796 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_231 : List (BitVec 512) := [w117,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_231 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_231 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s5_231 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_232 : List (BitVec 512) := [w117,w3766,w4716,w5135,w5393,w5698,w6179,w6522,w6588,w6873]
theorem b5_232 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_232 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(7,true),(6,true)),(false,(7,true),(6,true))] s5_232 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_233 : List (BitVec 512) := [w117,w3766,w4716,w5135,w5470,w5585,w5698,w5956,w6300,w6588]
theorem b5_233 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_233 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s5_233 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3766,v3_4716,v3_5135,v3_5470,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_234 : List (BitVec 512) := [w117,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_234 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_234 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s5_234 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_117,v3_3901,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_117 (PetersenWireProjection.cons pc3_3901 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_412 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_412 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_412 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,false),(9,true))] s5_412 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_197,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_197 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_482 : List (BitVec 512) := [w275,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_482 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_482 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_482 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_275,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_275 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_483 : List (BitVec 512) := [w276,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_483 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_483 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_483 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_276,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_276 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_491 : List (BitVec 512) := [w284,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_491 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_491 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_491 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_284,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_284 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_492 : List (BitVec 512) := [w285,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_492 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_492 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_492 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_285,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_285 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_493 : List (BitVec 512) := [w287,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_493 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_493 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_493 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_287,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_287 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_494 : List (BitVec 512) := [w288,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_494 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_494 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_494 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_288,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_288 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_495 : List (BitVec 512) := [w291,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_495 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_495 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_495 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_496 : List (BitVec 512) := [w291,w2591,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_496 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_496 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(2,true)),(false,(4,true),(0,true))] s5_496 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_2591,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_2591 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_497 : List (BitVec 512) := [w291,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_497 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_497 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_497 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_2683,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_498 : List (BitVec 512) := [w291,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690]
theorem b5_498 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_498 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_498 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_2683,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_499 : List (BitVec 512) := [w291,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690]
theorem b5_499 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_499 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_499 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_2690,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_2690 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_500 : List (BitVec 512) := [w291,w3179,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_500 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_500 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s5_500 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3179,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3179 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_501 : List (BitVec 512) := [w291,w3182,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_501 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_501 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s5_501 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3182,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_502 : List (BitVec 512) := [w291,w3186,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_502 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_502 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s5_502 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3186,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3186 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_503 : List (BitVec 512) := [w291,w3252,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_503 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_503 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(5,true)),(false,(2,true),(0,true))] s5_503 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3252,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3252 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_504 : List (BitVec 512) := [w291,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_504 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_504 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_504 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3258,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_505 : List (BitVec 512) := [w291,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_505 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_505 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(1,true),(0,true))] s5_505 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3280,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3280 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_506 : List (BitVec 512) := [w291,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_506 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_506 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_506 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_507 : List (BitVec 512) := [w291,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_507 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_507 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_507 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_508 : List (BitVec 512) := [w291,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_508 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_508 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_508 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_509 : List (BitVec 512) := [w291,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_509 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_509 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,true)),(false,(2,true),(0,true))] s5_509 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3328,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3328 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_510 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_510 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_510 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_510 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_511 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5995,w6300,w6588]
theorem b5_511 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_511 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,false)),(false,(0,true),(7,true))] s5_511 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5995,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5995 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_512 : List (BitVec 512) := [w291,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_512 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_512 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s5_512 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_513 : List (BitVec 512) := [w291,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_513 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_513 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s5_513 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_605 : List (BitVec 512) := [w362,w3156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_605 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_605 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(7,true))] s5_605 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_362,v3_3156,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300] (PetersenWireProjection.cons pc3_362 (PetersenWireProjection.cons pc3_3156 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 rfl)))))))))) (by decide +kernel)
def s5_608 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_608 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,false),(9,true))] s5_608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_362,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_362 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_610 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_610 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_610 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(7,true))] s5_610 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_362,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_362 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_726 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_726 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_726 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s5_726 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_498,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_498 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
