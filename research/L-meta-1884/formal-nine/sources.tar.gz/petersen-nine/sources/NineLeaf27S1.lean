import NinePin27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_999 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_999 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1001 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_1001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1001 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1002 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_1002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1002 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_1002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1015 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1015 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1015 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_1015 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_1019 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_1019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1019 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_1019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6897] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6897 rfl))))))))))) (by decide +kernel)
def s4_1024 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6599]
theorem b4_1024 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1024 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1024 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6599] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6599 rfl)))))))))) (by decide +kernel)
def s4_1025 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6599,w6873]
theorem b4_1025 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1025 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_1025 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6599,v27_6873] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6599 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_1026 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_1026 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1026 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1026 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s4_1027 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6748]
theorem b4_1027 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1027 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1027 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720,v27_6748] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_1031 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6588]
theorem b4_1031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1031 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6321,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6321 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_1032 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6588,w6873]
theorem b4_1032 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1032 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_1032 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6321,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6321 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_1036 : List (BitVec 512) := [w160,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_1036 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1036 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1036 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1917 : List (BitVec 512) := [w332,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_1917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1917 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s4_1917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_1910,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_1910 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl))))))))))) (by decide +kernel)
def s4_1935 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_1935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1935 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1941 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_1941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1941 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1942 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_1942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1942 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_1942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_1950 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1950 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_1950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_1954 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_1954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1954 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_1954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6859] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6859 rfl))))))))))) (by decide +kernel)
def s4_1960 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6615]
theorem b4_1960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1960 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6615] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6615 rfl)))))))))) (by decide +kernel)
def s4_1961 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6615,w6832]
theorem b4_1961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1961 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_1961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6615,v27_6832] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6615 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_1962 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_1962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1962 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s4_1963 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6748]
theorem b4_1963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1963 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_1966 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5981,w6300,w6588]
theorem b4_1966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1966 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5981,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5981 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_1967 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5981,w6300,w6588,w6832]
theorem b4_1967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1967 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_1967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5981,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5981 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_1970 : List (BitVec 512) := [w332,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_1970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1970 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_1970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5547 : List (BitVec 512) := [w1089,w3766,w4344,w4716,w4782,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_5547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5547 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s4_5547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1089,v27_3766,v27_4344,v27_4716,v27_4782,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1089 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4782 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl))))))))))) (by decide +kernel)
def s4_5550 : List (BitVec 512) := [w1089,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_5550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5550 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1089,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1089 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s4_5580 : List (BitVec 512) := [w1113,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5580 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1113,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1113 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5582 : List (BitVec 512) := [w1113,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5582 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5582 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5582 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1113,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1113 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5583 : List (BitVec 512) := [w1113,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5583 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_5583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1113,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1113 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5584 : List (BitVec 512) := [w1113,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5584 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1113,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1113 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_5585 : List (BitVec 512) := [w1116,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5585 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1116,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1116 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5587 : List (BitVec 512) := [w1116,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5587 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5587 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5587 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1116,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1116 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5588 : List (BitVec 512) := [w1116,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_5588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5588 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_5588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1116,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_1116 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5589 : List (BitVec 512) := [w1116,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5589 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1116,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1116 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_5590 : List (BitVec 512) := [w1117,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5590 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1117,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1117 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5592 : List (BitVec 512) := [w1117,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5592 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5592 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5592 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1117,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1117 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5593 : List (BitVec 512) := [w1117,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_5593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5593 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_5593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1117,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1117 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5594 : List (BitVec 512) := [w1117,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5594 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5594 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5594 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1117,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1117 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_5609 : List (BitVec 512) := [w1119,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5609 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(4,true))] s4_5609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1635,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1635 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5613 : List (BitVec 512) := [w1119,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5613 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(4,true))] s4_5613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1664,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1664 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5615 : List (BitVec 512) := [w1119,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5615 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(4,true))] s4_5615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1666,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1666 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5620 : List (BitVec 512) := [w1119,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5620 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5620 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(2,true))] s4_5620 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1883,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1883 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5624 : List (BitVec 512) := [w1119,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5624 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5624 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s4_5624 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1908,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1908 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5626 : List (BitVec 512) := [w1119,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5626 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s4_5626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1910,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1910 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5637 : List (BitVec 512) := [w1119,w2164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5637 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,false))] s4_5637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2164,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2164 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5639 : List (BitVec 512) := [w1119,w2166,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5639 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(0,true))] s4_5639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2166,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2166 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5655 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_5655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5655 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s4_5655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2468,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5678 : List (BitVec 512) := [w1119,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6748]
theorem b4_5678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5678 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s4_5678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2681,v27_3766,v27_4344,v27_4716,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2681 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s4_5680 : List (BitVec 512) := [w1119,w2683,w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6300,w6748]
theorem b4_5680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5680 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s4_5680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_3766,v27_4344,v27_4716,v27_4926,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5684 : List (BitVec 512) := [w1119,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690]
theorem b4_5684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5684 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s4_5684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_3766,v27_4344,v27_4716,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s4_5685 : List (BitVec 512) := [w1119,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690,w6748]
theorem b4_5685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5685 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s4_5685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_3766,v27_4344,v27_4716,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5686 : List (BitVec 512) := [w1119,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6748]
theorem b4_5686 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5686 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s4_5686 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_3766,v27_4344,v27_4716,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s4_5688 : List (BitVec 512) := [w1119,w2852,w3766,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_5688 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5688 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5688 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2852,v27_3766,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2852 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5691 : List (BitVec 512) := [w1119,w2878,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6300]
theorem b4_5691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5691 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 rfl)))))))))) (by decide +kernel)
def s4_5693 : List (BitVec 512) := [w1119,w2878,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5693 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5693 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5693 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5697 : List (BitVec 512) := [w1119,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5697 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s4_5698 : List (BitVec 512) := [w1119,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720,w6748]
theorem b4_5698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5698 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5699 : List (BitVec 512) := [w1119,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_5699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5699 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s4_5701 : List (BitVec 512) := [w1119,w3075,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_5701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5701 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3075,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3075 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5705 : List (BitVec 512) := [w1119,w3123,w3766,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5705 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3123,v27_3766,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3123 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5712 : List (BitVec 512) := [w1119,w3280,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5712 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s4_5712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3280,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5713 : List (BitVec 512) := [w1119,w3280,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_5713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5713 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s4_5713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3280,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5714 : List (BitVec 512) := [w1119,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5714 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s4_5714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3280,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
end NineCert
