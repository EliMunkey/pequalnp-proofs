import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1464 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_1464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1464 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true))] s4_1464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1473 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_1473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1473 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true))] s4_1473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_1482 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_1482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1482 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(7,false),(0,false))] s4_1482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6895] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_1490 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_1490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1490 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true))] s4_1490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_1492 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_1492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1492 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(7,false),(0,false))] s4_1492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_1524 : List (BitVec 512) := [w200,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1524 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1541 : List (BitVec 512) := [w200,w1819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1541 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_1819,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1552 : List (BitVec 512) := [w200,w2087,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1552 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1552 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1552 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_2087,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_2087 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1569 : List (BitVec 512) := [w200,w2945,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1569 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_2945,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_2945 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1599 : List (BitVec 512) := [w200,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1599 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1600 : List (BitVec 512) := [w200,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1600 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1601 : List (BitVec 512) := [w200,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1601 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1602 : List (BitVec 512) := [w200,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1602 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1603 : List (BitVec 512) := [w200,w3766,w4344,w4710,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1603 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4710,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4710 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1604 : List (BitVec 512) := [w200,w3766,w4344,w4716,w4720,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1604 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_4720,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4720 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1606 : List (BitVec 512) := [w200,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1606 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1626 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_1626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1626 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1638 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_1638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1638 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1648 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_1648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1648 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,false),(0,false))] s4_1648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6895] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_1654 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_1654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1654 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_1654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_1656 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_1656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1656 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,false),(0,false))] s4_1656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_1827 : List (BitVec 512) := [w310,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1827 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_1827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_310,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_310 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1828 : List (BitVec 512) := [w313,w364,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1828 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,false),(6,true))] s4_1828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_313,v4_364,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_313 (PetersenWireProjection.cons pc4_364 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1829 : List (BitVec 512) := [w313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1829 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_1829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_313,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_313 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1830 : List (BitVec 512) := [w313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1830 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_1830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_313,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_313 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1831 : List (BitVec 512) := [w314,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1831 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_1831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_314,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_314 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1833 : List (BitVec 512) := [w316,w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1833 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(1,false),(0,true))] s4_1833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_357,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_357 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1834 : List (BitVec 512) := [w316,w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1834 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_1834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1835 : List (BitVec 512) := [w316,w364,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1835 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(4,true),(3,true)),(false,(1,false),(0,true))] s4_1835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_364,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_364 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1836 : List (BitVec 512) := [w316,w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1836 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(4,false),(0,false))] s4_1836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_365,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_365 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1837 : List (BitVec 512) := [w316,w367,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1837 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(8,true),(5,true)),(false,(1,true),(0,false))] s4_1837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_367,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_367 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1838 : List (BitVec 512) := [w316,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6832]
theorem b4_1838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1838 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(5,true),(0,true))] s4_1838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1366,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1366 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1839 : List (BitVec 512) := [w316,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b4_1839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1839 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(5,true),(0,true))] s4_1839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1366,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6857] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1366 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_1840 : List (BitVec 512) := [w316,w1366,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b4_1840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1840 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false))] s4_1840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1366,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1366 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_1841 : List (BitVec 512) := [w316,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_1841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1841 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s4_1841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1842 : List (BitVec 512) := [w316,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1842 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(3,true))] s4_1842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1599,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1599 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1843 : List (BitVec 512) := [w316,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1843 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true))] s4_1843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1618,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1618 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1844 : List (BitVec 512) := [w316,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1844 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true))] s4_1844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1626,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1845 : List (BitVec 512) := [w316,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1845 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,true),(4,true))] s4_1845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1674,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1674 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1846 : List (BitVec 512) := [w316,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6690,w6832]
theorem b4_1846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1846 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_1846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1908,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1847 : List (BitVec 512) := [w316,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_1847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1847 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(9,true),(0,true))] s4_1847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_1848 : List (BitVec 512) := [w316,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1848 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(6,true))] s4_1848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2104,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2104 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1849 : List (BitVec 512) := [w316,w2140,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1849 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,true))] s4_1849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2140,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2140 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1850 : List (BitVec 512) := [w316,w2141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1850 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(6,true))] s4_1850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2141,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2141 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1851 : List (BitVec 512) := [w316,w2169,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1851 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,true),(7,true))] s4_1851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2169,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2169 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1852 : List (BitVec 512) := [w316,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1852 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true))] s4_1852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2175,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2175 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1853 : List (BitVec 512) := [w316,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_1853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1853 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_1853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1854 : List (BitVec 512) := [w316,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_1854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1854 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_1854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1855 : List (BitVec 512) := [w316,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_1855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1855 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_1855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_1856 : List (BitVec 512) := [w316,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_1856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1856 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s4_1856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2690,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2690 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1857 : List (BitVec 512) := [w316,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1857 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s4_1857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2690,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2690 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1858 : List (BitVec 512) := [w316,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_1858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1858 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s4_1858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2690,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2690 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_1859 : List (BitVec 512) := [w316,w2819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1859 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_1859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2819,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1860 : List (BitVec 512) := [w316,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1860 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_1860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2852,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1861 : List (BitVec 512) := [w316,w2855,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1861 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true))] s4_1861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2855,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2855 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1862 : List (BitVec 512) := [w316,w2889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1862 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true))] s4_1862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2889,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1863 : List (BitVec 512) := [w316,w2889,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1863 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true))] s4_1863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2889,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1864 : List (BitVec 512) := [w316,w2889,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1864 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true))] s4_1864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2889,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1865 : List (BitVec 512) := [w316,w3075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1865 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,false))] s4_1865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3075,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3075 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1866 : List (BitVec 512) := [w316,w3147,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1866 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(2,true))] s4_1866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3147,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3147 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1867 : List (BitVec 512) := [w316,w3149,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1867 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,true),(3,true))] s4_1867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3149,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3149 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1868 : List (BitVec 512) := [w316,w3179,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1868 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,true),(3,true))] s4_1868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3179,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3179 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1869 : List (BitVec 512) := [w316,w3186,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1869 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,true),(4,true))] s4_1869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3186,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3186 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1870 : List (BitVec 512) := [w316,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1870 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s4_1870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
