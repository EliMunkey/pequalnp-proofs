import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_6035 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300]
theorem b4_6035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6035 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_6035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_4748,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4748 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6036 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300]
theorem b4_6036 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6036 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true))] s4_6036 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6037 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300]
theorem b4_6037 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6037 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(1,false))] s4_6037 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6038 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300]
theorem b4_6038 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6038 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(1,false))] s4_6038 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6039 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389]
theorem b4_6039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6039 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true))] s4_6039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 rfl))))))))))) (by decide +kernel)
def s4_6040 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522]
theorem b4_6040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6040 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_6040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6522] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 rfl))))))))))) (by decide +kernel)
def s4_6041 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300]
theorem b4_6041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6041 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s4_6041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6042 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300]
theorem b4_6042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6042 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6043 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b4_6043 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6043 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_6043 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6044 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300]
theorem b4_6044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6044 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6045 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b4_6045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6045 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_6046 : List (BitVec 512) := [w1170,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6046 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6047 : List (BitVec 512) := [w1170,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300]
theorem b4_6047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6047 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_6047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6048 : List (BitVec 512) := [w1170,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b4_6048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6048 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_6048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6049 : List (BitVec 512) := [w1170,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300]
theorem b4_6049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6049 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_6049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_6050 : List (BitVec 512) := [w1170,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b4_6050 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6050 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_6050 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_6051 : List (BitVec 512) := [w1170,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6051 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_6051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6052 : List (BitVec 512) := [w1170,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_6052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6052 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_6052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6053 : List (BitVec 512) := [w1170,w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6053 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_6053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6054 : List (BitVec 512) := [w1170,w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6054 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_6054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6055 : List (BitVec 512) := [w1170,w1618,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_6055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6055 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_6055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1618,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1618 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6056 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6489,w6588]
theorem b4_6056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6056 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_6056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6489,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6489 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6057 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_6057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6057 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s4_6057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6058 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b4_6058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6058 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_6058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6059 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6422,w6588]
theorem b4_6059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6059 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_6059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6060 : List (BitVec 512) := [w1170,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6060 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_6060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6061 : List (BitVec 512) := [w1170,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6549,w6588]
theorem b4_6061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6061 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_6061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6549,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6549 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6062 : List (BitVec 512) := [w1170,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b4_6062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6062 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_6062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6063 : List (BitVec 512) := [w1170,w1649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6063 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_6063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1649,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1649 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6064 : List (BitVec 512) := [w1170,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6588]
theorem b4_6064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_6064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6567,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6567 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6065 : List (BitVec 512) := [w1170,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b4_6065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6065 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_6065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6066 : List (BitVec 512) := [w1170,w1651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6066 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_6066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6067 : List (BitVec 512) := [w1170,w1652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6067 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_6067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1652,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1652 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6068 : List (BitVec 512) := [w1170,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6890]
theorem b4_6068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6068 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_6068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_6069 : List (BitVec 512) := [w1170,w1664,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_6069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6069 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_6069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6070 : List (BitVec 512) := [w1170,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_6070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6070 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_6070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1664,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6071 : List (BitVec 512) := [w1170,w1665,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_6071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6071 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(4,true),(7,true))] s4_6071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1665,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1665 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6072 : List (BitVec 512) := [w1170,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6072 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_6072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1666,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1666 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6073 : List (BitVec 512) := [w1170,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6073 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_6073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1669,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1669 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6074 : List (BitVec 512) := [w1170,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6074 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_6074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1670,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1670 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6075 : List (BitVec 512) := [w1170,w1673,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6075 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_6075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1673,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1673 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6076 : List (BitVec 512) := [w1170,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6076 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_6076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1674,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1674 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6077 : List (BitVec 512) := [w1170,w1676,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6077 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_6077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1676,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1676 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6078 : List (BitVec 512) := [w1170,w1867,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_6078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6078 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(3,true),(5,true))] s4_6078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1867,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1867 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl))))))))))) (by decide +kernel)
def s4_6079 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_6079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6079 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(1,false),(8,true))] s4_6079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6080 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_6080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6080 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(7,true),(3,true))] s4_6080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6081 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_6081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6081 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_6081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5471,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5471 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6082 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_6082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6082 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(4,true),(5,true))] s4_6082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_6083 : List (BitVec 512) := [w1170,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6083 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(8,true))] s4_6083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1883,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1883 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6084 : List (BitVec 512) := [w1170,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6543,w6588]
theorem b4_6084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6084 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(1,false),(8,true))] s4_6084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1891,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1891 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6085 : List (BitVec 512) := [w1170,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6389,w6522,w6588]
theorem b4_6085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6085 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(9,true),(8,true))] s4_6085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1891,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1891 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6086 : List (BitVec 512) := [w1170,w1893,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6086 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(8,true))] s4_6086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1893,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1893 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6087 : List (BitVec 512) := [w1170,w1895,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6087 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(8,true))] s4_6087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1895,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1895 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6088 : List (BitVec 512) := [w1170,w1896,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6088 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,false),(6,true)),(false,(8,true),(0,true))] s4_6088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1896,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1896 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6089 : List (BitVec 512) := [w1170,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_6089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6089 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(9,true),(8,true))] s4_6089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1908,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6090 : List (BitVec 512) := [w1170,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6852]
theorem b4_6090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6090 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(1,false),(8,true))] s4_6090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1908,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6852] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6852 rfl))))))))))) (by decide +kernel)
def s4_6091 : List (BitVec 512) := [w1170,w1908,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588,w6690]
theorem b4_6091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6091 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,true),(7,true)),(false,(3,true),(8,true))] s4_6091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1908,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_6061,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl))))))))))) (by decide +kernel)
def s4_6092 : List (BitVec 512) := [w1170,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6092 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true))] s4_6092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1910,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1910 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6093 : List (BitVec 512) := [w1170,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6093 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(8,true))] s4_6093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1912,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1912 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6094 : List (BitVec 512) := [w1170,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6094 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(8,true))] s4_6094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1913,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1913 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6095 : List (BitVec 512) := [w1170,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_6095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6095 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(1,false),(8,true))] s4_6095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_6096 : List (BitVec 512) := [w1170,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_6096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(9,true),(8,true))] s4_6096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_6097 : List (BitVec 512) := [w1170,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6097 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(8,true),(0,true))] s4_6097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1916,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1916 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6098 : List (BitVec 512) := [w1170,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6098 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true))] s4_6098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1917,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1917 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
