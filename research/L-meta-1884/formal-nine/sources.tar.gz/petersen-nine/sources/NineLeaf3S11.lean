import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3970 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3970 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3970 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3970 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3971 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_3971 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3971 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3971 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3972 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_3972 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3972 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3972 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3973 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3973 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3973 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3973 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3974 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_3974 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3974 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3974 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3975 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_3975 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3975 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3975 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3976 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_3976 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3976 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_3976 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3977 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_3977 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3977 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true))] s3_3977 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3978 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_3978 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3978 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3978 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3979 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_3979 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3979 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3979 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_3980 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_3980 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3980 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_3980 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl)))))))))))) (by decide +kernel)
def s3_3981 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_3981 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3981 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true))] s3_3981 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3982 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_3982 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3982 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(7,true))] s3_3982 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3983 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3983 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3983 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3983 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3984 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_3984 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3984 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_3984 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3985 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_3985 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3985 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(5,true))] s3_3985 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3986 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_3986 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3986 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s3_3986 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3987 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_3987 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3987 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s3_3987 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3988 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3988 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3988 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3988 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3989 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_3989 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3989 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3989 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3990 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6436,w6588]
theorem b3_3990 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3990 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3990 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3991 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6549,w6588]
theorem b3_3991 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3991 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s3_3991 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3992 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6832]
theorem b3_3992 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3992 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(6,true))] s3_3992 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3993 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_3993 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3993 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3993 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3994 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_3994 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3994 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3994 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3995 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6549,w6588]
theorem b3_3995 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3995 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false))] s3_3995 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3996 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6720]
theorem b3_3996 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3996 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(6,true))] s3_3996 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_3997 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_3997 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3997 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3997 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3998 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b3_3998 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3998 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s3_3998 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3999 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3999 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3999 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3999 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4000 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b3_4000 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4000 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s3_4000 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s3_4001 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b3_4001 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4001 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_4001 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s3_4002 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b3_4002 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4002 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s3_4002 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4003 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b3_4003 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4003 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(8,true),(7,true))] s3_4003 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4004 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5848,w5956,w6300,w6588]
theorem b3_4004 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4004 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4004 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4005 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6101,w6300,w6588]
theorem b3_4005 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4005 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4005 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4006 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6422,w6588]
theorem b3_4006 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4006 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_4006 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4007 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6478,w6588]
theorem b3_4007 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4007 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s3_4007 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4008 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6522,w6588]
theorem b3_4008 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4008 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4008 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4009 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6873]
theorem b3_4009 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4009 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s3_4009 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4010 : List (BitVec 512) := [w3766,w4084,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4010 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4010 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4010 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4084,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4084 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4011 : List (BitVec 512) := [w3766,w4084,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4011 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4011 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4011 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4084,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4084 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4014 : List (BitVec 512) := [w3766,w4086,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4014 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4014 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4014 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4086,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4086 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4015 : List (BitVec 512) := [w3766,w4088,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4015 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4015 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4015 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4088,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4088 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4016 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_4016 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4016 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4016 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4017 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_4017 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4017 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4017 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4018 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_4018 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4018 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4018 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4019 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_4019 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4019 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4019 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4020 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_4020 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4020 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4020 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4021 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_4021 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4021 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(5,true))] s3_4021 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4022 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_4022 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4022 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4022 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4023 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_4023 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4023 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4023 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_4024 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_4024 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4024 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_4024 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl)))))))))))) (by decide +kernel)
def s3_4025 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_4025 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4025 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true))] s3_4025 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_4026 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_4026 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4026 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(7,true))] s3_4026 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4027 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_4027 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4027 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4027 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4028 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_4028 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4028 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4028 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4029 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_4029 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4029 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4029 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4030 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_4030 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4030 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4030 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4031 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_4031 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4031 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4031 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4032 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4032 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4032 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4032 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4033 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4033 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4033 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4033 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4034 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_4034 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4034 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4034 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_4035 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b3_4035 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4035 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_4035 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
end NineCert
