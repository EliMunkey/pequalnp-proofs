import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9373 : List (BitVec 512) := [w1384,w3698,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9373 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3698,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3698 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9374 : List (BitVec 512) := [w1384,w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9374 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9388 : List (BitVec 512) := [w1384,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9388 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9401 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9401 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9419 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b4_9419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9419 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9432 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6300,w6588]
theorem b4_9432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9432 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9443 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6300,w6588]
theorem b4_9443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9443 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9455 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5730,w5956,w6300,w6588]
theorem b4_9455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9455 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_9455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5730,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9465 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6048,w6300,w6588]
theorem b4_9465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9465 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9468 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_9468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9468 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9476 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6085,w6300,w6588]
theorem b4_9476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9476 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6085,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6085 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9493 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6195,w6300,w6588]
theorem b4_9493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9493 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s4_9493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9496 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_9496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9496 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_9496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9505 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6206,w6300,w6588]
theorem b4_9505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9505 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6206,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6206 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9515 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6377,w6588]
theorem b4_9515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9515 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9527 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b4_9527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9527 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_9553 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6061,w6300,w6588]
theorem b4_9553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9553 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9554 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6300,w6588]
theorem b4_9554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9554 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s4_9554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9555 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6201,w6300,w6588]
theorem b4_9555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9555 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_9555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9561 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5675,w5698,w5956,w6300,w6588]
theorem b4_9561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9561 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_9561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5675,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9568 : List (BitVec 512) := [w1384,w3766,w4602,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_9568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9585 : List (BitVec 512) := [w1388,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9585 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9599 : List (BitVec 512) := [w1388,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9599 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9611 : List (BitVec 512) := [w1388,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9611 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9612 : List (BitVec 512) := [w1388,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9612 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9613 : List (BitVec 512) := [w1388,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9613 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9614 : List (BitVec 512) := [w1388,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9614 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9615 : List (BitVec 512) := [w1388,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9615 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9616 : List (BitVec 512) := [w1388,w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9616 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9616 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9616 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9617 : List (BitVec 512) := [w1388,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9617 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9618 : List (BitVec 512) := [w1388,w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9618 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(5,true)),(false,(9,true),(0,true))] s4_9618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9619 : List (BitVec 512) := [w1388,w3643,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9619 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_9619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9620 : List (BitVec 512) := [w1388,w3647,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9620 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9620 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9620 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3647,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3647 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9621 : List (BitVec 512) := [w1388,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9621 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9621 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9621 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9622 : List (BitVec 512) := [w1388,w3689,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9622 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9623 : List (BitVec 512) := [w1388,w3697,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9623 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9623 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9623 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3697,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3697 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9624 : List (BitVec 512) := [w1388,w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9624 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9624 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9624 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9637 : List (BitVec 512) := [w1388,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9637 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9645 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9645 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9658 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b4_9658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9658 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9661 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6300,w6588]
theorem b4_9661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9661 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9668 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6300,w6588]
theorem b4_9668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9671 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9671 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9678 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5810,w5956,w6300,w6588]
theorem b4_9678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9678 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9693 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6195,w6300,w6588]
theorem b4_9693 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9693 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_9693 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9696 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_9696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9702 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6232,w6300,w6588]
theorem b4_9702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9708 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b4_9708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_9725 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6300,w6588]
theorem b4_9725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_9725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9734 : List (BitVec 512) := [w1388,w3766,w4344,w4814,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9734 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9734 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_9734 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4814,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9766 : List (BitVec 512) := [w1403,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9766 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_9767 : List (BitVec 512) := [w1403,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9767 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_9767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9768 : List (BitVec 512) := [w1403,w2203,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9768 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_9768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9769 : List (BitVec 512) := [w1403,w2203,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9769 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_9769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9825 : List (BitVec 512) := [w1403,w2550,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9825 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_9825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2550,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2550 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9826 : List (BitVec 512) := [w1403,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9826 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_9827 : List (BitVec 512) := [w1403,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9827 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_9827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9828 : List (BitVec 512) := [w1403,w2552,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9828 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_9828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2552,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9856 : List (BitVec 512) := [w1403,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9856 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_9857 : List (BitVec 512) := [w1403,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9857 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_9857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9858 : List (BitVec 512) := [w1403,w3335,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9858 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_9858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3335,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9859 : List (BitVec 512) := [w1403,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9859 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_9860 : List (BitVec 512) := [w1403,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9860 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_9860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9861 : List (BitVec 512) := [w1403,w3411,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9861 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_9861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3411,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
