import NinePin284
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2296 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_2296 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2296 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s3_2296 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1328,v284_3766,v284_4344,v284_4716,v284_4926,v284_5135,v284_5393,v284_5585,v284_5848,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1328 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4926 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5848 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl)))))))))))) (by decide +kernel)
def s4_1516 : List (BitVec 512) := [w197,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1516 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_1516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_197,v284_3766,v284_4344,v284_4716,v284_4926,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_197 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4926 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_2313 : List (BitVec 512) := [w362,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2313 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_2313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3766,v284_4344,v284_4716,v284_4926,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4926 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_2314 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2314 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_2314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5698,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5698 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_2315 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2315 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_2315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5769,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5769 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_2316 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_2316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2316 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_2316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5848,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5848 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_4882 : List (BitVec 512) := [w985,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_4882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4882 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_4882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_985,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5769,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_985 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5769 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_5553 : List (BitVec 512) := [w1092,w3766,w4344,w4716,w4778,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5553 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_5553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1092,v284_3766,v284_4344,v284_4716,v284_4778,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1092 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4778 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_7578 : List (BitVec 512) := [w1312,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7578 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_7578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1312,v284_1883,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1312 (PetersenWireProjection.cons pc284_1883 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_8224 : List (BitVec 512) := [w1328,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8224 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_8224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1328,v284_1875,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1328 (PetersenWireProjection.cons pc284_1875 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_8225 : List (BitVec 512) := [w1328,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8225 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_8225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1328,v284_1883,v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1328 (PetersenWireProjection.cons pc284_1883 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_8269 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8269 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8269 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_8269 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1328,v284_3280,v284_4344,v284_4716,v284_4926,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1328 (PetersenWireProjection.cons pc284_3280 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4926 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s4_17003 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5843,w5956,w6300,w6588]
theorem b4_17003 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17003 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s4_17003 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_3766,v284_4344,v284_4716,v284_4926,v284_5135,v284_5393,v284_5585,v284_5843,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_4926 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5843 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl))))))))))) (by decide +kernel)
def s5_606 : List (BitVec 512) := [w362,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_606 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_606 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s5_606 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3258,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3258 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl)))))))))) (by decide +kernel)
def s5_607 : List (BitVec 512) := [w362,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_607 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s5_607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_362,v284_3280,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_362 (PetersenWireProjection.cons pc284_3280 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl)))))))))) (by decide +kernel)
def s5_2646 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_2646 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2646 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s5_2646 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_1328,v284_3766,v284_4344,v284_4716,v284_5135,v284_5471,v284_5585,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_1328 (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5471 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl)))))))))) (by decide +kernel)
def s5_5855 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5847,w5956,w6300,w6588]
theorem b5_5855 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5855 := by
  intro m le c
  apply rejects_sound r284 i5 4 tgt (small284 adj) hot284 [] s5_5855 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v284_3766,v284_4344,v284_4716,v284_5135,v284_5393,v284_5585,v284_5847,v284_5956,v284_6300,v284_6588] (PetersenWireProjection.cons pc284_3766 (PetersenWireProjection.cons pc284_4344 (PetersenWireProjection.cons pc284_4716 (PetersenWireProjection.cons pc284_5135 (PetersenWireProjection.cons pc284_5393 (PetersenWireProjection.cons pc284_5585 (PetersenWireProjection.cons pc284_5847 (PetersenWireProjection.cons pc284_5956 (PetersenWireProjection.cons pc284_6300 (PetersenWireProjection.cons pc284_6588 rfl)))))))))) (by decide +kernel)
end NineCert
