import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12593 : List (BitVec 512) := [w2488,w3689,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12593 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12594 : List (BitVec 512) := [w2488,w3689,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12594 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12594 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12594 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12595 : List (BitVec 512) := [w2488,w3689,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12595 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12595 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12595 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12596 : List (BitVec 512) := [w2488,w3689,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12596 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12596 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12596 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12597 : List (BitVec 512) := [w2488,w3766,w3930,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12597 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3930,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3930 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12598 : List (BitVec 512) := [w2488,w3766,w3930,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12598 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12598 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12598 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3930,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3930 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12599 : List (BitVec 512) := [w2488,w3766,w3930,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12599 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3930,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3930 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12600 : List (BitVec 512) := [w2488,w3766,w3930,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12600 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3930,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3930 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12641 : List (BitVec 512) := [w2488,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12641 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12642 : List (BitVec 512) := [w2488,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12642 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12643 : List (BitVec 512) := [w2488,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12643 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12644 : List (BitVec 512) := [w2488,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12644 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12683 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12683 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12683 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12683 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12684 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12684 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12685 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12685 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12686 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6588]
theorem b4_12686 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12686 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12686 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12725 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6061,w6300,w6588]
theorem b4_12725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12726 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6300,w6389,w6588]
theorem b4_12726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12726 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12727 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6300,w6543,w6588]
theorem b4_12727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12727 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12728 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6300,w6588]
theorem b4_12728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12728 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12810 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5675,w5956,w6061,w6300,w6588]
theorem b4_12810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12810 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5675,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12811 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5675,w5956,w6300,w6389,w6588]
theorem b4_12811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12811 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5675,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12812 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5675,w5956,w6300,w6543,w6588]
theorem b4_12812 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12812 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12812 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5675,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12813 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5675,w5956,w6300,w6588]
theorem b4_12813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12813 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12843 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6061,w6300,w6588]
theorem b4_12843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12843 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12844 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6389,w6588]
theorem b4_12844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12844 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12845 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6543,w6588]
theorem b4_12845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12845 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12846 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6588]
theorem b4_12846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12846 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12856 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6085,w6300,w6588]
theorem b4_12856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12856 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6085,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6085 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12865 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6377,w6588]
theorem b4_12865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12865 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12872 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b4_12872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12872 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12873 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6546,w6588]
theorem b4_12873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12873 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12877 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12877 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12879 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588,w6667]
theorem b4_12879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12879 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_12890 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6085,w6300,w6543,w6588]
theorem b4_12890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12890 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6085,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6085 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12891 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6085,w6300,w6588]
theorem b4_12891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12891 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6085,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6085 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12913 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6377,w6389,w6588]
theorem b4_12913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12914 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6377,w6543,w6588]
theorem b4_12914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12914 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6377,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12915 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6377,w6588]
theorem b4_12915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12915 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12920 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6417,w6588]
theorem b4_12920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12920 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6417,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12929 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b4_12929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12929 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12930 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6546,w6588]
theorem b4_12930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12936 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588,w6667]
theorem b4_12936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12936 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_12947 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6417,w6543,w6588]
theorem b4_12947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12947 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6417,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12948 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6417,w6588]
theorem b4_12948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6417,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12967 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6546,w6588]
theorem b4_12967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12967 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12973 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12973 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12975 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6667]
theorem b4_12975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_12986 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6546,w6588]
theorem b4_12986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12986 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12993 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6667]
theorem b4_12993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12993 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl)))))))))) (by decide +kernel)
def s4_13004 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6377,w6389,w6543,w6588]
theorem b4_13004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13004 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_13004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6377,v0_6389,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13005 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6377,w6389,w6588]
theorem b4_13005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13005 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_13005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13012 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6048,w6061,w6300,w6543,w6588]
theorem b4_13012 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13012 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_13012 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6048,v0_6061,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13013 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6048,w6061,w6300,w6588]
theorem b4_13013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13013 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_13013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6048,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13110 : List (BitVec 512) := [w3335,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13110 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4392,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4392 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13111 : List (BitVec 512) := [w3335,w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13111 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4402,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4402 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13112 : List (BitVec 512) := [w3335,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13112 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13113 : List (BitVec 512) := [w3335,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13113 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4412,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4412 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13114 : List (BitVec 512) := [w3335,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13114 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_13114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4413,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4413 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13115 : List (BitVec 512) := [w3335,w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13115 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_13115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4415,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4415 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13116 : List (BitVec 512) := [w3335,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13116 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4483,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4483 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13117 : List (BitVec 512) := [w3335,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13117 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4499,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4499 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13118 : List (BitVec 512) := [w3335,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13118 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_13118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4502,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4502 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13119 : List (BitVec 512) := [w3335,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13119 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_13119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4515,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4515 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
