import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3582 : List (BitVec 512) := [w2352,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3582 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3582 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(4,true),(2,false))] s5_3582 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3583 : List (BitVec 512) := [w2352,w2687,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3583 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3583 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_3583 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_2687,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_2687 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3584 : List (BitVec 512) := [w2352,w3258,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3584 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3584 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(1,false)),(false,(6,true),(4,true))] s5_3584 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3258,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3585 : List (BitVec 512) := [w2352,w3280,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3585 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3585 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(6,true),(4,true))] s5_3585 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3280,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3586 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_3586 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3586 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true)),(false,(6,true),(4,true))] s5_3586 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3587 : List (BitVec 512) := [w2352,w3766,w5135,w5393,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b5_3587 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3587 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(3,true),(5,true)),(false,(9,true),(6,true))] s5_3587 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3588 : List (BitVec 512) := [w2354,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3588 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3588 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3588 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_2681,v2_3766,v2_4344,v2_4716,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3589 : List (BitVec 512) := [w2354,w2468,w2681,w3766,w4344,w4716,w5585,w6300,w6522,w6588]
theorem b5_3589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3589 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_2681,v2_3766,v2_4344,v2_4716,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3590 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6389,w6522,w6588]
theorem b5_3590 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3590 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(4,true),(3,true))] s5_3590 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3591 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6522,w6588,w6890]
theorem b5_3591 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3591 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(0,false),(5,true))] s5_3591 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6522,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_3592 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6522,w6720,w6873]
theorem b5_3592 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3592 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(9,true),(5,true))] s5_3592 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3593 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6522,w6785,w6873]
theorem b5_3593 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3593 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(6,true)),(false,(9,true),(5,true))] s5_3593 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3594 : List (BitVec 512) := [w2354,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3594 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3594 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_3594 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3258,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3595 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w6389,w6522,w6588]
theorem b5_3595 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3595 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(4,true))] s5_3595 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3596 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w6522,w6720,w6873]
theorem b5_3596 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3596 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(10,true))] s5_3596 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3597 : List (BitVec 512) := [w2354,w2683,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588]
theorem b5_3597 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3597 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_3597 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3598 : List (BitVec 512) := [w2354,w2686,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588]
theorem b5_3598 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3598 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_3598 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3599 : List (BitVec 512) := [w2354,w2696,w3766,w4344,w4716,w5393,w5585,w6522,w6588,w6873]
theorem b5_3599 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3599 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_3599 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3600 : List (BitVec 512) := [w2354,w2701,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588]
theorem b5_3600 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3600 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_3600 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2701,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2701 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3601 : List (BitVec 512) := [w2354,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_3601 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3601 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(1,true),(4,true))] s5_3601 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4426,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4426 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3602 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w6522,w6588]
theorem b5_3602 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3602 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true)),(false,(6,true),(5,true))] s5_3602 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5750,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5750 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3603 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6340,w6522,w6588]
theorem b5_3603 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3603 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3603 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6340,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6340 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3604 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6341,w6522,w6588]
theorem b5_3604 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3604 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3604 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6341,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6341 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3605 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6342,w6522,w6588]
theorem b5_3605 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3605 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(6,true))] s5_3605 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6342,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6342 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3606 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6344,w6522,w6588]
theorem b5_3606 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3606 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,true)),(false,(0,true),(6,true))] s5_3606 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6344,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6344 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3607 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6355,w6522,w6588]
theorem b5_3607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3607 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(5,true),(4,true)),(false,(1,true),(6,true))] s5_3607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6355,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6355 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3608 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6720,w6890]
theorem b5_3608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3608 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(5,true),(4,true)),(false,(10,true),(1,false))] s5_3608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6720,v2_6890] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_3609 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6813,w6873]
theorem b5_3609 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3609 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(1,false),(8,true)),(false,(6,true),(10,true))] s5_3609 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3610 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5585,w5802,w5956,w6300,w6588]
theorem b5_3610 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3610 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s5_3610 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5802,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5802 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3611 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5187,w5393,w5585,w6389,w6522,w6588]
theorem b5_3611 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3611 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_3611 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3612 : List (BitVec 512) := [w2354,w3766,w4344,w5135,w5393,w5585,w5769,w6522,w6720,w6873]
theorem b5_3612 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3612 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true)),(false,(10,true),(6,true))] s5_3612 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3613 : List (BitVec 512) := [w2354,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_3613 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3613 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(10,true),(6,true))] s5_3613 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_5135,v2_5393,v2_5769,v2_5956,v2_6464,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3614 : List (BitVec 512) := [w2354,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_3614 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3614 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(4,true),(10,true))] s5_3614 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3615 : List (BitVec 512) := [w2355,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3615 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3615 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(5,true)),(false,(0,true),(5,true))] s5_3615 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2355,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2355 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3616 : List (BitVec 512) := [w2356,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3616 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3616 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,false),(9,true)),(false,(0,true),(5,true))] s5_3616 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2356,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2356 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3617 : List (BitVec 512) := [w2357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3617 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3617 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(0,false),(9,true)),(false,(0,true),(5,true))] s5_3617 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2357,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2357 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3618 : List (BitVec 512) := [w2358,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3618 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3618 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s5_3618 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2358,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2358 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3620 : List (BitVec 512) := [w2362,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3620 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3620 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(5,true))] s5_3620 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2362,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2362 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3621 : List (BitVec 512) := [w2363,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3621 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3621 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(0,true),(5,true))] s5_3621 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2363,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2363 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3622 : List (BitVec 512) := [w2364,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_3622 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3622 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true)),(false,(1,true),(7,true))] s5_3622 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2364,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2364 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3623 : List (BitVec 512) := [w2366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3623 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3623 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true)),(false,(0,true),(5,true))] s5_3623 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2366,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2366 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3624 : List (BitVec 512) := [w2368,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3624 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3624 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(0,true),(5,true))] s5_3624 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2368,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2368 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3625 : List (BitVec 512) := [w2369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3625 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3625 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(0,true),(5,true))] s5_3625 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2369,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2369 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3626 : List (BitVec 512) := [w2370,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3626 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3626 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_3626 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2370,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2370 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3627 : List (BitVec 512) := [w2371,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3627 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_3627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2371,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2371 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3628 : List (BitVec 512) := [w2372,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3628 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3628 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_3628 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2372,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2372 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3629 : List (BitVec 512) := [w2373,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3629 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3629 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_3629 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2373,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2373 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3630 : List (BitVec 512) := [w2374,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3630 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3630 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_3630 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3631 : List (BitVec 512) := [w2375,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3631 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3631 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_3631 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2375,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2375 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3632 : List (BitVec 512) := [w2376,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3632 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3632 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(5,true))] s5_3632 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2376,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2376 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3633 : List (BitVec 512) := [w2377,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3633 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_3633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2377,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2377 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3634 : List (BitVec 512) := [w2378,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3634 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3634 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(5,true)),(false,(0,true),(5,true))] s5_3634 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2378,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2378 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3635 : List (BitVec 512) := [w2379,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3635 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,false),(8,true)),(false,(0,true),(5,true))] s5_3635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2379,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2379 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3638 : List (BitVec 512) := [w2381,w2543,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s5_3638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2381,v2_2543,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2381 (PetersenWireProjection.cons pc2_2543 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3651 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5286,w5585,w5956,w6300,w6588]
theorem b5_3651 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3651 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s5_3651 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2381,v2_3766,v2_4344,v2_4716,v2_5135,v2_5286,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2381 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5286 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3678 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5287,w5585,w5956,w6300,w6588]
theorem b5_3678 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3678 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s5_3678 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2382,v2_3766,v2_4344,v2_4716,v2_5135,v2_5287,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2382 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5287 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3690 : List (BitVec 512) := [w2383,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3690 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s5_3690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2383,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2383 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3693 : List (BitVec 512) := [w2386,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3693 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3693 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s5_3693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2386,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2386 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3694 : List (BitVec 512) := [w2387,w2544,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3694 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3694 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s5_3694 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2387,v2_2544,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2387 (PetersenWireProjection.cons pc2_2544 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3708 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5288,w5585,w5956,w6300,w6588]
theorem b5_3708 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3708 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s5_3708 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2387,v2_3766,v2_4344,v2_4716,v2_5135,v2_5288,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2387 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5288 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3730 : List (BitVec 512) := [w2388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3730 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3730 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true))] s5_3730 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2388,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2388 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3733 : List (BitVec 512) := [w2389,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3733 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3733 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s5_3733 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2389,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2389 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3736 : List (BitVec 512) := [w2390,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6361,w6588]
theorem b5_3736 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3736 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(1,true),(6,true))] s5_3736 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2390,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6361,v2_6588] (PetersenWireProjection.cons pc2_2390 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6361 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3737 : List (BitVec 512) := [w2393,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3737 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3737 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s5_3737 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
