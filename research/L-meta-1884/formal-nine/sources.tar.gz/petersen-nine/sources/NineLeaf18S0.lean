import NinePin18
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_661 : List (BitVec 512) := [w81,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_661 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(7,true),(6,true))] s4_661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_81,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5698,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_81 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5698 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl))))))))))) (by decide +kernel)
def s4_662 : List (BitVec 512) := [w81,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_662 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s4_662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_81,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_81 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s4_663 : List (BitVec 512) := [w81,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_663 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_663 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(5,true),(3,true))] s4_663 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_81,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588,v18_6873] (PetersenWireProjection.cons pc18_81 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 (PetersenWireProjection.cons pc18_6873 rfl))))))))))) (by decide +kernel)
def s4_1689 : List (BitVec 512) := [w256,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1689 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1689 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(6,true),(7,true))] s4_1689 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5698,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5698 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl))))))))))) (by decide +kernel)
def s4_1690 : List (BitVec 512) := [w256,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1690 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s4_1690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s4_1691 : List (BitVec 512) := [w256,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1691 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(1,true),(5,true))] s4_1691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588,v18_6832] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 (PetersenWireProjection.cons pc18_6832 rfl))))))))))) (by decide +kernel)
def s4_3791 : List (BitVec 512) := [w861,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3791 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s4_3791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_861,v18_3901,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_861 (PetersenWireProjection.cons pc18_3901 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_58 : List (BitVec 512) := [w20,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_58 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_58 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s5_58 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_20,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_20 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_184 : List (BitVec 512) := [w81,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588]
theorem b5_184 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_184 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(7,true),(3,true))] s5_184 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_81,v18_3303,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6464,v18_6588] (PetersenWireProjection.cons pc18_81 (PetersenWireProjection.cons pc18_3303 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6464 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_185 : List (BitVec 512) := [w81,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_185 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_185 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s5_185 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_81,v18_3332,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_81 (PetersenWireProjection.cons pc18_3332 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_186 : List (BitVec 512) := [w83,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_186 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_186 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s5_186 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_83,v18_3280,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_83 (PetersenWireProjection.cons pc18_3280 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_206 : List (BitVec 512) := [w104,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_206 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_206 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(5,true),(3,true))] s5_206 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_104,v18_3901,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_104 (PetersenWireProjection.cons pc18_3901 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_466 : List (BitVec 512) := [w256,w3258,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_466 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_466 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(6,true),(7,true)),(false,(2,true),(8,true))] s5_466 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3258,v18_4344,v18_4716,v18_5135,v18_5393,v18_5698,v18_6179,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5698 (PetersenWireProjection.cons pc18_6179 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_467 : List (BitVec 512) := [w256,w3293,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b5_467 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_467 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(7,true),(1,true))] s5_467 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3293,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_6179,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3293 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_6179 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_468 : List (BitVec 512) := [w256,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_468 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_468 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s5_468 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3328,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3328 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s5_469 : List (BitVec 512) := [w258,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_469 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_469 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [] s5_469 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_258,v18_3280,v18_4344,v18_4716,v18_5135,v18_5393,v18_5585,v18_5956,v18_6300,v18_6588] (PetersenWireProjection.cons pc18_258 (PetersenWireProjection.cons pc18_3280 (PetersenWireProjection.cons pc18_4344 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5585 (PetersenWireProjection.cons pc18_5956 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6588 rfl)))))))))) (by decide +kernel)
def s6_6 : List (BitVec 512) := [w256,w3258,w4716,w5135,w5393,w5698,w6179,w6300,w6690]
theorem b6_6 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_6 := by
  intro m le c
  apply rejects_sound r18 i8 9 tgt (small18 adj) hot18 [(false,(6,true),(7,true)),(false,(2,true),(8,true)),(false,(7,true),(8,true))] s6_6 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v18_256,v18_3258,v18_4716,v18_5135,v18_5393,v18_5698,v18_6179,v18_6300,v18_6690] (PetersenWireProjection.cons pc18_256 (PetersenWireProjection.cons pc18_3258 (PetersenWireProjection.cons pc18_4716 (PetersenWireProjection.cons pc18_5135 (PetersenWireProjection.cons pc18_5393 (PetersenWireProjection.cons pc18_5698 (PetersenWireProjection.cons pc18_6179 (PetersenWireProjection.cons pc18_6300 (PetersenWireProjection.cons pc18_6690 rfl))))))))) (by decide +kernel)
end NineCert
