import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3890 : List (BitVec 512) := [w925,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6655]
theorem b4_3890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3890 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(8,true))] s4_3890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_925,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6655] (PetersenWireProjection.cons pc3_925 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6655 rfl))))))))))) (by decide +kernel)
def s4_3891 : List (BitVec 512) := [w925,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6660]
theorem b4_3891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3891 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(8,true))] s4_3891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_925,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6660] (PetersenWireProjection.cons pc3_925 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6660 rfl))))))))))) (by decide +kernel)
def s4_3892 : List (BitVec 512) := [w927,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3892 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_927,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_927 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3893 : List (BitVec 512) := [w927,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6623]
theorem b4_3893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3893 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_3893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_927,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6623] (PetersenWireProjection.cons pc3_927 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6623 rfl))))))))))) (by decide +kernel)
def s4_3894 : List (BitVec 512) := [w928,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3894 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_928,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_928 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3895 : List (BitVec 512) := [w928,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6621]
theorem b4_3895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3895 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_3895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_928,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6621] (PetersenWireProjection.cons pc3_928 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6621 rfl))))))))))) (by decide +kernel)
def s4_3900 : List (BitVec 512) := [w936,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3900 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true))] s4_3900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_936,v3_1875,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_936 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3901 : List (BitVec 512) := [w936,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3901 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_3901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_936,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_936 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3902 : List (BitVec 512) := [w936,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3902 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_936,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_936 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3903 : List (BitVec 512) := [w936,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_3903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3903 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_3903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_936,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6618] (PetersenWireProjection.cons pc3_936 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6618 rfl))))))))))) (by decide +kernel)
def s4_3904 : List (BitVec 512) := [w942,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b4_3904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3904 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_3904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_1366,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6857] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_1366 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_3905 : List (BitVec 512) := [w942,w1366,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b4_3905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3905 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_3905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_1366,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_1366 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_3906 : List (BitVec 512) := [w942,w1366,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3906 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true))] s4_3906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_1366,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_1366 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3907 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_3907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3907 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_3907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5621,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5621 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3908 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3908 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3909 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6097,w6300,w6588]
theorem b4_3909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3909 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,false))] s4_3909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6097,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6097 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3910 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3910 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_3910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3911 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_3911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3911 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(5,true))] s4_3911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3912 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_3912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3912 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_3912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6334,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6334 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3913 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_3913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3913 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3914 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_3914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3914 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s4_3914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3915 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_3915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3915 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s4_3915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3916 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3916 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3917 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6654]
theorem b4_3917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3917 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(8,true))] s4_3917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6654] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6654 rfl))))))))))) (by decide +kernel)
def s4_3918 : List (BitVec 512) := [w942,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_3918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3918 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(7,true),(6,true))] s4_3918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3919 : List (BitVec 512) := [w942,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3919 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_942,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_942 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3920 : List (BitVec 512) := [w944,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_3920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3920 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_3920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_3921 : List (BitVec 512) := [w944,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_3921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3921 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_3921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6866] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_3922 : List (BitVec 512) := [w944,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_3922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3922 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_3922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_3923 : List (BitVec 512) := [w944,w1374,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_3923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3923 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_3923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6785] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_3924 : List (BitVec 512) := [w944,w1374,w3766,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3924 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_3924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3925 : List (BitVec 512) := [w944,w1374,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_3925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3925 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_3925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3926 : List (BitVec 512) := [w944,w1374,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_3926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3926 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_3926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_1374,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3927 : List (BitVec 512) := [w944,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3927 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_3927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3928 : List (BitVec 512) := [w944,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3928 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_3928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_4748,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4748 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3929 : List (BitVec 512) := [w944,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3929 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3930 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_3930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3930 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(8,false),(0,true))] s4_3930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6173,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6173 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3931 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_3931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3931 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_3931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3932 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_3932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3932 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(2,true),(0,false))] s4_3932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3933 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_3933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3933 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_3933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6336,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6336 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3934 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_3934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3934 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3935 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_3935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3935 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s4_3935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3936 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_3936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3936 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false))] s4_3936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3937 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3937 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3938 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_3938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3938 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(6,true))] s4_3938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3939 : List (BitVec 512) := [w944,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_3939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3939 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_3939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3940 : List (BitVec 512) := [w944,w3766,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3940 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_3940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3941 : List (BitVec 512) := [w944,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_3941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3941 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_3941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3942 : List (BitVec 512) := [w944,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_3942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3942 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_3942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_944,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_944 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3943 : List (BitVec 512) := [w946,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3943 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_3943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_1388,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_1388 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3944 : List (BitVec 512) := [w946,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3944 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_3944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3945 : List (BitVec 512) := [w946,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3945 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_3945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3946 : List (BitVec 512) := [w946,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_3946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3946 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_3946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3947 : List (BitVec 512) := [w946,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_3947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3947 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(6,true))] s4_3947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3948 : List (BitVec 512) := [w946,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3948 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_946,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_946 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3949 : List (BitVec 512) := [w947,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3949 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_947,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_947 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3950 : List (BitVec 512) := [w947,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6599]
theorem b4_3950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3950 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(8,true))] s4_3950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_947,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6599] (PetersenWireProjection.cons pc3_947 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6599 rfl))))))))))) (by decide +kernel)
def s4_3951 : List (BitVec 512) := [w947,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6600]
theorem b4_3951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3951 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,false)),(false,(0,true),(8,true))] s4_3951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_947,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6600] (PetersenWireProjection.cons pc3_947 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6600 rfl))))))))))) (by decide +kernel)
def s4_3952 : List (BitVec 512) := [w947,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6603]
theorem b4_3952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3952 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(6,true)),(false,(0,true),(8,true))] s4_3952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_947,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6603] (PetersenWireProjection.cons pc3_947 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6603 rfl))))))))))) (by decide +kernel)
def s4_3953 : List (BitVec 512) := [w949,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3953 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_949,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_949 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_3954 : List (BitVec 512) := [w949,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6606]
theorem b4_3954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3954 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s4_3954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_949,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6606] (PetersenWireProjection.cons pc3_949 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6606 rfl))))))))))) (by decide +kernel)
def s4_3955 : List (BitVec 512) := [w950,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3955 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,true))] s4_3955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_950,v3_1646,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_950 (PetersenWireProjection.cons pc3_1646 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3956 : List (BitVec 512) := [w950,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3956 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s4_3956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_950,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_950 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_3957 : List (BitVec 512) := [w950,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3957 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_3957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_950,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_950 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
