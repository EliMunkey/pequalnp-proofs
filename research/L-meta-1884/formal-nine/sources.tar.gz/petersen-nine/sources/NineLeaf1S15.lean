import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_2938 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6588]
theorem b4_2938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2938 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s4_2938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_632,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_632 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_2939 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2939 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s4_2939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_632,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_632 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_2940 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5101,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2940 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s4_2940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_632,v1_3766,v1_4344,v1_4716,v1_5101,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_632 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5101 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_2950 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6763]
theorem b4_2950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2950 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s4_2950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_632,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6763] (PetersenWireProjection.cons pc1_632 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6763 rfl))))))))))) (by decide +kernel)
def s4_2958 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756]
theorem b4_2958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2958 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s4_2958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_632,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756] (PetersenWireProjection.cons pc1_632 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_2967 : List (BitVec 512) := [w635,w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2967 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_2967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_2981 : List (BitVec 512) := [w635,w1605,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2981 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_2981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_1605,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_1605 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_2993 : List (BitVec 512) := [w635,w1845,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2993 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_2993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_1845,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_1845 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3002 : List (BitVec 512) := [w635,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3002 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3009 : List (BitVec 512) := [w635,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3009 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3010 : List (BitVec 512) := [w635,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3010 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3010 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3010 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3011 : List (BitVec 512) := [w635,w2589,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3011 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3011 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3011 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2589,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_3012 : List (BitVec 512) := [w635,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3012 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3012 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3012 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3013 : List (BitVec 512) := [w635,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3013 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3014 : List (BitVec 512) := [w635,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_3014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3014 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_3015 : List (BitVec 512) := [w635,w2681,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3015 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3015 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3015 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2681,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3021 : List (BitVec 512) := [w635,w2797,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_2797,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_2797 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3041 : List (BitVec 512) := [w635,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3041 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3052 : List (BitVec 512) := [w635,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3052 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3060 : List (BitVec 512) := [w635,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3060 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3061 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3061 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3062 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3062 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3063 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6588]
theorem b4_3063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3063 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3064 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_3065 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5100,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3065 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5100,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5100 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3066 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5100,w5393,w5585,w5956,w6300,w6588]
theorem b4_3066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3066 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5100,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5100 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3067 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5100,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3067 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5100,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5100 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_3068 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5150,w5393,w5585,w5956,w6300,w6588]
theorem b4_3068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3068 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5150,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5150 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3070 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_3070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3070 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3071 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_3071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3071 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3081 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_3081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3081 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3095 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_3095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3095 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s4_3095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_3096 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6763]
theorem b4_3096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6763] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6763 rfl))))))))))) (by decide +kernel)
def s4_3103 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756]
theorem b4_3103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3103 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_3111 : List (BitVec 512) := [w635,w3766,w4344,w5135,w5239,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3111 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_3111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_635,v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_635 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_3164 : List (BitVec 512) := [w757,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3164 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s4_3164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_757,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_757 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3165 : List (BitVec 512) := [w757,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6663]
theorem b4_3165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3165 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(5,true))] s4_3165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_757,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6663] (PetersenWireProjection.cons pc1_757 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6663 rfl))))))))))) (by decide +kernel)
def s4_3820 : List (BitVec 512) := [w886,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3820 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_886,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_886 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3821 : List (BitVec 512) := [w886,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6660]
theorem b4_3821 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3821 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_3821 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_886,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6660] (PetersenWireProjection.cons pc1_886 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6660 rfl))))))))))) (by decide +kernel)
def s4_3822 : List (BitVec 512) := [w888,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3822 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_888,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_888 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3823 : List (BitVec 512) := [w888,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6658]
theorem b4_3823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3823 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_3823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_888,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6658] (PetersenWireProjection.cons pc1_888 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6658 rfl))))))))))) (by decide +kernel)
def s4_3824 : List (BitVec 512) := [w889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3824 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_889,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_889 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3825 : List (BitVec 512) := [w889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6657]
theorem b4_3825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3825 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_3825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_889,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6657] (PetersenWireProjection.cons pc1_889 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6657 rfl))))))))))) (by decide +kernel)
def s4_3826 : List (BitVec 512) := [w893,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3826 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_893,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_893 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3827 : List (BitVec 512) := [w893,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6655]
theorem b4_3827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3827 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_3827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_893,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6655] (PetersenWireProjection.cons pc1_893 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6655 rfl))))))))))) (by decide +kernel)
def s4_3828 : List (BitVec 512) := [w894,w3123,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3828 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true))] s4_3828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_894,v1_3123,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_894 (PetersenWireProjection.cons pc1_3123 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3829 : List (BitVec 512) := [w894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3829 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true))] s4_3829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_894,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_894 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3830 : List (BitVec 512) := [w894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3830 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_894,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_894 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3831 : List (BitVec 512) := [w894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6654]
theorem b4_3831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3831 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_3831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_894,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6654] (PetersenWireProjection.cons pc1_894 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6654 rfl))))))))))) (by decide +kernel)
def s4_3832 : List (BitVec 512) := [w897,w3075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3832 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s4_3832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_897,v1_3075,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_897 (PetersenWireProjection.cons pc1_3075 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3833 : List (BitVec 512) := [w897,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3833 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true))] s4_3833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_897,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_897 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_3834 : List (BitVec 512) := [w897,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3834 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_3834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_897,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_897 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_3835 : List (BitVec 512) := [w897,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6653]
theorem b4_3835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3835 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_3835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_897,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6653] (PetersenWireProjection.cons pc1_897 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6653 rfl))))))))))) (by decide +kernel)
def s4_4934 : List (BitVec 512) := [w1030,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4934 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_4934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1030,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1030 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_4935 : List (BitVec 512) := [w1030,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6650]
theorem b4_4935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4935 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true))] s4_4935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1030,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6650] (PetersenWireProjection.cons pc1_1030 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6650 rfl))))))))))) (by decide +kernel)
def s4_4936 : List (BitVec 512) := [w1031,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4936 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_4936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1031,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1031 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_4937 : List (BitVec 512) := [w1031,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6648]
theorem b4_4937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4937 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_4937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1031,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6648] (PetersenWireProjection.cons pc1_1031 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6648 rfl))))))))))) (by decide +kernel)
def s4_4938 : List (BitVec 512) := [w1032,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4938 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true))] s4_4938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1032,v1_2852,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1032 (PetersenWireProjection.cons pc1_2852 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_4939 : List (BitVec 512) := [w1032,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_4939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4939 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true))] s4_4939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1032,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1032 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_4940 : List (BitVec 512) := [w1032,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4940 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_4940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1032,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1032 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_4941 : List (BitVec 512) := [w1032,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6647]
theorem b4_4941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4941 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_4941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1032,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6647] (PetersenWireProjection.cons pc1_1032 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6647 rfl))))))))))) (by decide +kernel)
def s4_4942 : List (BitVec 512) := [w1035,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4942 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_4942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1035,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1035 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_4943 : List (BitVec 512) := [w1035,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6645]
theorem b4_4943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4943 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_4943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1035,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6645] (PetersenWireProjection.cons pc1_1035 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6645 rfl))))))))))) (by decide +kernel)
def s4_5565 : List (BitVec 512) := [w1105,w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5565 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true))] s4_5565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1105,v1_1119,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1105 (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
