import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4381 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5002,w5135,w5585,w5956,w6300,w6588]
theorem b5_4381 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4381 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4381 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5002,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4382 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5023,w5135,w5585,w5956,w6300,w6588]
theorem b5_4382 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4382 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4382 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5023,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5023 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4383 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5028,w5135,w5585,w5956,w6300,w6588]
theorem b5_4383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4383 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5028,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5028 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4384 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5038,w5135,w5585,w5956,w6300,w6588]
theorem b5_4384 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4384 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4384 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5038,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5038 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4385 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5040,w5135,w5585,w5956,w6300,w6588]
theorem b5_4385 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4385 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4385 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5040,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5040 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4386 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5048,w5135,w5585,w5956,w6300,w6588]
theorem b5_4386 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4386 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4386 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5048,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5048 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4387 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5050,w5135,w5585,w5956,w6300,w6588]
theorem b5_4387 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4387 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4387 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5050,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5050 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4388 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5055,w5135,w5585,w5956,w6300,w6588]
theorem b5_4388 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4388 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4388 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5055,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5055 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4389 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5059,w5135,w5585,w5956,w6300,w6588]
theorem b5_4389 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4389 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4389 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5059,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4390 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5059,w5585,w5956,w6300,w6588]
theorem b5_4390 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4390 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4390 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5059,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
def s5_4391 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5135,w5585,w5956,w6300,w6588]
theorem b5_4391 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4391 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4391 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4392 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6061,w6300,w6588]
theorem b5_4392 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4392 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4392 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4393 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6389,w6588]
theorem b5_4393 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4393 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4393 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4394 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6543,w6588]
theorem b5_4394 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4394 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4394 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4395 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6588]
theorem b5_4395 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4395 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4395 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
def s5_4396 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6588,w6720]
theorem b5_4396 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4396 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_4396 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_4397 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5105,w5135,w5585,w5956,w6300,w6588]
theorem b5_4397 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4397 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4397 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5105,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5105 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4398 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5116,w5135,w5585,w5956,w6300,w6588]
theorem b5_4398 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4398 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4398 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5116,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5116 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4399 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5129,w5135,w5585,w5956,w6300,w6588]
theorem b5_4399 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4399 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4399 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5129,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5129 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4400 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5133,w5135,w5585,w5956,w6300,w6588]
theorem b5_4400 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4400 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4400 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5133,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5133 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4401 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5187,w5585,w5956,w6300,w6588]
theorem b5_4401 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4401 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(1,false)),(false,(7,true),(0,true))] s5_4401 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5187,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4402 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5191,w5585,w5956,w6300,w6588]
theorem b5_4402 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4402 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(5,true)),(false,(7,true),(1,true))] s5_4402 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5191,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5191 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4403 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5194,w5585,w5956,w6300,w6588]
theorem b5_4403 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4403 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(1,false)),(false,(7,true),(0,true))] s5_4403 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5194,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5194 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4404 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5195,w5585,w5956,w6300,w6588]
theorem b5_4404 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4404 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true)),(false,(7,true),(1,true))] s5_4404 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5195,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5195 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4405 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5201,w5585,w5956,w6300,w6588]
theorem b5_4405 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4405 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(3,true)),(false,(8,true),(1,false)),(false,(7,true),(0,true))] s5_4405 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5201,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5201 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4406 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5202,w5585,w5956,w6300,w6588]
theorem b5_4406 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4406 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(0,true),(4,true)),(false,(7,true),(1,true))] s5_4406 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5202,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5202 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4448 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5873,w5956,w6300,w6588]
theorem b5_4448 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4448 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(8,true))] s5_4448 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4466 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6155,w6300,w6588]
theorem b5_4466 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4466 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(2,false))] s5_4466 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6155,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6155 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4473 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6242,w6300,w6588]
theorem b5_4473 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4473 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(2,false))] s5_4473 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6242,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6242 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4490 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6448,w6588]
theorem b5_4490 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4490 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(5,true),(2,false))] s5_4490 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6448,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6448 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4497 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6502,w6588]
theorem b5_4497 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4497 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(8,true),(2,false))] s5_4497 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6502,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6502 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4504 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6558,w6588]
theorem b5_4504 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4504 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(1,false))] s5_4504 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6558,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6558 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4509 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6581,w6588]
theorem b5_4509 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4509 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(1,false))] s5_4509 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4518 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6763]
theorem b5_4518 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4518 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_4518 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6763] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6763 rfl)))))))))) (by decide +kernel)
def s5_4523 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6823]
theorem b5_4523 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4523 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(6,true))] s5_4523 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6823] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6823 rfl)))))))))) (by decide +kernel)
def s5_4528 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6861]
theorem b5_4528 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4528 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(2,false),(6,true))] s5_4528 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6861] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6861 rfl)))))))))) (by decide +kernel)
def s5_4536 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6899]
theorem b5_4536 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4536 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(2,false),(6,true))] s5_4536 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6899] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6899 rfl)))))))))) (by decide +kernel)
def s5_4542 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6915]
theorem b5_4542 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4542 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(1,false),(6,true))] s5_4542 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6915] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6915 rfl)))))))))) (by decide +kernel)
def s5_4546 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720,w6756]
theorem b5_4546 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4546 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_4546 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 rfl)))))))))) (by decide +kernel)
def s5_4556 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6422,w6446,w6588]
theorem b5_4556 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4556 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(5,true),(10,true))] s5_4556 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6422,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4567 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6101,w6153,w6300,w6588]
theorem b5_4567 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4567 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(9,true))] s5_4567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_6101,v1_6153,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4569 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6556,w6588]
theorem b5_4569 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4569 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(9,true))] s5_4569 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_6101,v1_6300,v1_6556,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6556 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4571 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5769,w5861,w5956,w6300,w6588]
theorem b5_4571 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4571 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(8,true))] s5_4571 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5769,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4574 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5861,w5956,w6300,w6588,w6785]
theorem b5_4574 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4574 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(6,true))] s5_4574 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5861,v1_5956,v1_6300,v1_6588,v1_6785] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_4582 : List (BitVec 512) := [w2488,w3766,w4344,w5135,w5239,w5585,w5956,w6300,w6588,w6720]
theorem b5_4582 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4582 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_4582 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_5135,v1_5239,v1_5585,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_4596 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5585,w5956,w6300,w6446,w6588]
theorem b5_4596 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4596 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s5_4596 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4716,v1_4926,v1_5135,v1_5585,v1_5956,v1_6300,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4623 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5956,w6153,w6300,w6588,w6690]
theorem b5_4623 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4623 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(4,true),(6,true))] s5_4623 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4716,v1_5135,v1_5585,v1_5956,v1_6153,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_4654 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6155,w6300,w6588]
theorem b5_4654 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4654 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_4654 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2492,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6155,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2492 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6155 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4664 : List (BitVec 512) := [w2496,w2664,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4664 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4664 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_4664 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_2664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_2664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4682 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w4994,w5135,w5585,w5956,w6300,w6588]
theorem b5_4682 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4682 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_4682 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_4994,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4994 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4683 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5028,w5135,w5585,w5956,w6300,w6588]
theorem b5_4683 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4683 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_4683 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_5028,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5028 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4684 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5050,w5135,w5585,w5956,w6300,w6588]
theorem b5_4684 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4684 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_4684 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_5050,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5050 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4693 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5863,w5956,w6300,w6588]
theorem b5_4693 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4693 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_4693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5863,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4700 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6242,w6300,w6588]
theorem b5_4700 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4700 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_4700 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6242,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6242 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4705 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6581,w6588]
theorem b5_4705 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4705 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_4705 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2496,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_2496 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4749 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5769,w5861,w5956,w6300,w6588]
theorem b5_4749 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4749 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_4749 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2497,v1_3766,v1_4344,v1_4716,v1_5135,v1_5769,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2497 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5241 : List (BitVec 512) := [w3766,w4003,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b5_5241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5241 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(0,false),(6,true))] s5_5241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4003,v1_4344,v1_4716,v1_5393,v1_5585,v1_5654,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4003 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5654 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5242 : List (BitVec 512) := [w3766,w4003,w4344,w4716,w5393,w5585,w5956,w6031,w6300,w6588]
theorem b5_5242 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5242 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s5_5242 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4003,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6031,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4003 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6031 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5494 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5585,w5873,w5956,w6300,w6720]
theorem b5_5494 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5494 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(4,true))] s5_5494 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4392,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_5498 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5769,w5861,w5956,w6300,w6720]
theorem b5_5498 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5498 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(4,true))] s5_5498 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4392,v1_5135,v1_5393,v1_5769,v1_5861,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_5519 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w6241,w6300,w6832]
theorem b5_5519 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5519 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true)),(false,(1,true),(4,true))] s5_5519 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4403,v1_4716,v1_5135,v1_5393,v1_5585,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_5523 : List (BitVec 512) := [w3766,w4344,w4403,w5135,w5239,w5393,w5585,w5956,w6300,w6720]
theorem b5_5523 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5523 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(1,true),(4,true))] s5_5523 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4403,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_5693 : List (BitVec 512) := [w3766,w4344,w4716,w4802,w5393,w5585,w5956,w6300,w6414,w6588]
theorem b5_5693 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5693 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(9,true))] s5_5693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_4802,v1_5393,v1_5585,v1_5956,v1_6300,v1_6414,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4802 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6414 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5765 : List (BitVec 512) := [w3766,w4344,w4716,w5036,w5187,w5393,w5585,w5956,w6522,w6588]
theorem b5_5765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5765 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s5_5765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5036,v1_5187,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5036 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
end NineCert
