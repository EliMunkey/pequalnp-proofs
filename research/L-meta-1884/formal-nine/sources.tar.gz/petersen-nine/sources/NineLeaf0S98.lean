import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3936 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b5_3936 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3936 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s5_3936 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3937 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_3937 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(0,false),(2,false))] s5_3937 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3938 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3938 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3938 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3938 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_3939 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_3939 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3939 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s5_3939 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_3940 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b5_3940 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3940 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s5_3940 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_3941 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_3941 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3941 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(4,true))] s5_3941 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3942 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5698,w6179,w6300,w6522,w6588]
theorem b5_3942 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3942 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s5_3942 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5698,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3943 : List (BitVec 512) := [w2468,w3590,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3943 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3943 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3943 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3590,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3590 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3944 : List (BitVec 512) := [w2468,w3590,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_3944 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3944 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s5_3944 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3590,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3590 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3945 : List (BitVec 512) := [w2468,w3590,w4344,w4716,w5135,w5585,w5725,w5956,w6300,w6588]
theorem b5_3945 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3945 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true)),(false,(0,false),(7,true))] s5_3945 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3590,v0_4344,v0_4716,v0_5135,v0_5585,v0_5725,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3590 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5725 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3946 : List (BitVec 512) := [w2468,w3590,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3946 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3946 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3946 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3590,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3590 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_3947 : List (BitVec 512) := [w2468,w3614,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3947 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3947 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3614,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3614 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3948 : List (BitVec 512) := [w2468,w3619,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3948 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3948 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3949 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_3949 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3949 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s5_3949 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3950 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_3950 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3950 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s5_3950 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3951 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_3951 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3951 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s5_3951 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3952 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_3952 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3952 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true)),(false,(0,false),(7,true))] s5_3952 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3953 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b5_3953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3953 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3954 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_3955 : List (BitVec 512) := [w2468,w3672,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3955 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3672,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3672 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3956 : List (BitVec 512) := [w2468,w3673,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3956 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3956 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3956 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3673,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3673 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3957 : List (BitVec 512) := [w2468,w3674,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3957 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3957 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3957 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3674,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3674 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3958 : List (BitVec 512) := [w2468,w3678,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3958 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3958 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3958 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3678,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3678 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3959 : List (BitVec 512) := [w2468,w3684,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3959 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3959 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3959 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3684,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3684 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3960 : List (BitVec 512) := [w2468,w3686,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3960 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3960 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3960 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3686,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3961 : List (BitVec 512) := [w2468,w3686,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_3961 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3961 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s5_3961 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3962 : List (BitVec 512) := [w2468,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_3962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3962 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(0,false),(2,false))] s5_3962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3963 : List (BitVec 512) := [w2468,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3963 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_3964 : List (BitVec 512) := [w2468,w3687,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3964 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3964 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3964 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3965 : List (BitVec 512) := [w2468,w3736,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3965 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3965 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3736,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3736 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3966 : List (BitVec 512) := [w2468,w3737,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3966 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3966 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3966 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3737,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3737 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3967 : List (BitVec 512) := [w2468,w3764,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3967 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3967 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3967 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3968 : List (BitVec 512) := [w2468,w3766,w3806,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3968 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_3968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3806,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3806 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3969 : List (BitVec 512) := [w2468,w3766,w3814,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3969 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3969 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_3969 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3814,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3814 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3970 : List (BitVec 512) := [w2468,w3766,w3817,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3970 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3970 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3970 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3817,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3817 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3971 : List (BitVec 512) := [w2468,w3766,w3823,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3971 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3971 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_3971 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3823,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3823 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3972 : List (BitVec 512) := [w2468,w3766,w3829,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3972 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3972 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3972 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3829,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3829 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3973 : List (BitVec 512) := [w2468,w3766,w3830,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3973 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3973 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3973 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3974 : List (BitVec 512) := [w2468,w3766,w3865,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3974 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3974 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(2,true))] s5_3974 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3865,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3865 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3975 : List (BitVec 512) := [w2468,w3766,w3866,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3975 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(2,true))] s5_3975 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3866,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3866 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3976 : List (BitVec 512) := [w2468,w3766,w3868,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3976 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(2,true))] s5_3976 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3868,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3868 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3977 : List (BitVec 512) := [w2468,w3766,w3871,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3977 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3977 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(6,true),(1,true))] s5_3977 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3871,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3871 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3978 : List (BitVec 512) := [w2468,w3766,w3872,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3978 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3978 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(6,true),(1,true))] s5_3978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3872,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3872 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3979 : List (BitVec 512) := [w2468,w3766,w3873,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3979 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3979 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,true)),(false,(6,true),(2,true))] s5_3979 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3873,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3873 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3980 : List (BitVec 512) := [w2468,w3766,w3874,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3980 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3980 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(6,true)),(false,(1,true),(0,false)),(false,(6,true),(1,true))] s5_3980 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3874,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3874 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3981 : List (BitVec 512) := [w2468,w3766,w3890,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3981 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3981 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_3981 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3890,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3890 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3982 : List (BitVec 512) := [w2468,w3766,w3896,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3982 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3982 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_3982 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3896,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3896 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3983 : List (BitVec 512) := [w2468,w3766,w3900,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3983 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3983 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true)),(false,(8,true),(7,true)),(false,(6,true),(0,true))] s5_3983 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3900,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3900 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3984 : List (BitVec 512) := [w2468,w3766,w3917,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3984 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3984 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true)),(false,(6,true),(2,true))] s5_3984 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3917,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3917 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3985 : List (BitVec 512) := [w2468,w3766,w3918,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3985 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3985 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,false)),(false,(0,true),(6,true)),(false,(6,true),(2,true))] s5_3985 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3918,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3918 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3986 : List (BitVec 512) := [w2468,w3766,w3920,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3986 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3986 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true)),(false,(0,true),(7,true))] s5_3986 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3920,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3920 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3987 : List (BitVec 512) := [w2468,w3766,w3921,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3987 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3987 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(8,true),(7,true)),(false,(6,true),(0,true))] s5_3987 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3921,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3921 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3988 : List (BitVec 512) := [w2468,w3766,w3922,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3988 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3988 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(8,true),(7,true)),(false,(6,true),(0,true))] s5_3988 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3922,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3922 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3989 : List (BitVec 512) := [w2468,w3766,w3927,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3989 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3989 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,false)),(false,(0,true),(6,true)),(false,(6,true),(2,true))] s5_3989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3927,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3927 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4103 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4965,w5135,w5585,w5956,w6300,w6588]
theorem b5_4103 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4103 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true)),(false,(1,true),(0,true))] s5_4103 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4965,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4965 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4104 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4979,w5135,w5585,w5956,w6300,w6588]
theorem b5_4104 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4104 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true)),(false,(0,false),(4,true))] s5_4104 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4979,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4979 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4121 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5472,w5585,w5956,w6300,w6588]
theorem b5_4121 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4121 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(1,true),(0,true))] s5_4121 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5472,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5472 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4122 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5473,w5585,w5956,w6300,w6588]
theorem b5_4122 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4122 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true)),(false,(1,true),(0,true))] s5_4122 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5473,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5473 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4123 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5475,w5585,w5956,w6300,w6588]
theorem b5_4123 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4123 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(1,true),(0,true))] s5_4123 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5475,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5475 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4134 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5734,w5956,w6300,w6588]
theorem b5_4134 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4134 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true)),(false,(0,false),(7,true))] s5_4134 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5734,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5734 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4140 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5820,w5956,w6300,w6588]
theorem b5_4140 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4140 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true)),(false,(0,false),(4,true))] s5_4140 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5820,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5820 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4147 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5860,w5956,w6300,w6588]
theorem b5_4147 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4147 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true)),(false,(0,false),(7,true))] s5_4147 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4190 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b5_4190 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4190 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false)),(false,(5,true),(1,true))] s5_4190 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4192 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6554,w6588]
theorem b5_4192 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4192 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true)),(false,(0,false),(2,false))] s5_4192 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6554,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6554 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
