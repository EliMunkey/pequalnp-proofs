import NinePin228
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4125 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5478,w5585,w5956,w6300,w6588]
theorem b5_4125 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4125 := by
  intro m le c
  apply rejects_sound r228 i6 5 tgt (small228 adj) hot228 [] s5_4125 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v228_2468,v228_3766,v228_4344,v228_4716,v228_5135,v228_5478,v228_5585,v228_5956,v228_6300,v228_6588] (PetersenWireProjection.cons pc228_2468 (PetersenWireProjection.cons pc228_3766 (PetersenWireProjection.cons pc228_4344 (PetersenWireProjection.cons pc228_4716 (PetersenWireProjection.cons pc228_5135 (PetersenWireProjection.cons pc228_5478 (PetersenWireProjection.cons pc228_5585 (PetersenWireProjection.cons pc228_5956 (PetersenWireProjection.cons pc228_6300 (PetersenWireProjection.cons pc228_6588 rfl)))))))))) (by decide +kernel)
def s5_4127 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5494,w5585,w5956,w6300,w6588]
theorem b5_4127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4127 := by
  intro m le c
  apply rejects_sound r228 i6 5 tgt (small228 adj) hot228 [] s5_4127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v228_2468,v228_3766,v228_4344,v228_4716,v228_5135,v228_5494,v228_5585,v228_5956,v228_6300,v228_6588] (PetersenWireProjection.cons pc228_2468 (PetersenWireProjection.cons pc228_3766 (PetersenWireProjection.cons pc228_4344 (PetersenWireProjection.cons pc228_4716 (PetersenWireProjection.cons pc228_5135 (PetersenWireProjection.cons pc228_5494 (PetersenWireProjection.cons pc228_5585 (PetersenWireProjection.cons pc228_5956 (PetersenWireProjection.cons pc228_6300 (PetersenWireProjection.cons pc228_6588 rfl)))))))))) (by decide +kernel)
def s5_4128 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5495,w5585,w5956,w6300,w6588]
theorem b5_4128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4128 := by
  intro m le c
  apply rejects_sound r228 i6 5 tgt (small228 adj) hot228 [] s5_4128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v228_2468,v228_3766,v228_4344,v228_4716,v228_5135,v228_5495,v228_5585,v228_5956,v228_6300,v228_6588] (PetersenWireProjection.cons pc228_2468 (PetersenWireProjection.cons pc228_3766 (PetersenWireProjection.cons pc228_4344 (PetersenWireProjection.cons pc228_4716 (PetersenWireProjection.cons pc228_5135 (PetersenWireProjection.cons pc228_5495 (PetersenWireProjection.cons pc228_5585 (PetersenWireProjection.cons pc228_5956 (PetersenWireProjection.cons pc228_6300 (PetersenWireProjection.cons pc228_6588 rfl)))))))))) (by decide +kernel)
end NineCert
