import NinePin301
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_66 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5152,w5585,w5956,w6300,w6588]
theorem b6_66 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_66 := by
  intro m le c
  apply rejects_sound r301 i5 4 tgt (small301 adj) hot301 [] s6_66 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v301_2468,v301_3766,v301_4344,v301_4716,v301_5152,v301_5585,v301_5956,v301_6300,v301_6588] (PetersenWireProjection.cons pc301_2468 (PetersenWireProjection.cons pc301_3766 (PetersenWireProjection.cons pc301_4344 (PetersenWireProjection.cons pc301_4716 (PetersenWireProjection.cons pc301_5152 (PetersenWireProjection.cons pc301_5585 (PetersenWireProjection.cons pc301_5956 (PetersenWireProjection.cons pc301_6300 (PetersenWireProjection.cons pc301_6588 rfl))))))))) (by decide +kernel)
end NineCert
