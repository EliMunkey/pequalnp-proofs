import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_14405 : List (BitVec 512) := [w3766,w3842,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_14405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14405 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(6,true),(8,true))] s4_14405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3842,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3842 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14406 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_14406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14406 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_14406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5621,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5621 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14407 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14407 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true))] s4_14407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14408 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_14408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14408 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(6,true))] s4_14408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14409 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_14409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14409 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_14409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6334,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6334 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14410 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14410 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(2,true))] s4_14410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14411 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_14411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14411 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(6,true))] s4_14411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14412 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_14412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14412 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(1,false))] s4_14412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14413 : List (BitVec 512) := [w3766,w3843,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_14413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14413 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(7,true))] s4_14413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3843,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3843 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14414 : List (BitVec 512) := [w3766,w3844,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14414 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_14414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3844,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3844 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14415 : List (BitVec 512) := [w3766,w3845,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14415 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_14415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14416 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14416 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_14416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_4748,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4748 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14417 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14417 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(3,true))] s4_14417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14418 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_14418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14418 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(1,false))] s4_14418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14419 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_14419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14419 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(1,false))] s4_14419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14420 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_14420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14420 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_14420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6336,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6336 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14421 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14421 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(8,true))] s4_14421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14422 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14422 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(8,true),(3,true))] s4_14422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14423 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_14423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14423 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(8,true),(1,false))] s4_14423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14424 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_14424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14424 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_14424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14425 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_14425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14425 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_14425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14426 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_14426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14426 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_14426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s4_14427 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14427 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_14427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14428 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_14428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14428 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14429 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14429 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s4_14429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14430 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_14430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14430 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14431 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14431 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14432 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14432 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_14432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14433 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14433 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(5,true)),(false,(9,true),(0,true))] s4_14433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14434 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14434 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_14434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14435 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_14435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14435 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_14435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14436 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14436 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_14436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14437 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_14437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14437 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_14437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5623,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5623 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14438 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14438 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true))] s4_14438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14439 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_14439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14439 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_14439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5995,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5995 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14440 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14440 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_14440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14441 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14441 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(7,true))] s4_14441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14442 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_14442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14442 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(1,false))] s4_14442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14443 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_14443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14443 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(1,false))] s4_14443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14444 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b4_14444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14444 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_14444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_14445 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_14445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14445 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_14445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14446 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_14446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14446 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_14446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14447 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_14447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14447 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_14447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14448 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14448 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_14448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14449 : List (BitVec 512) := [w3766,w3858,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14449 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(2,true))] s4_14449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3858,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3858 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14450 : List (BitVec 512) := [w3766,w3858,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_14450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14450 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(2,true))] s4_14450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3858,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3858 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14451 : List (BitVec 512) := [w3766,w3858,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14451 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(6,true))] s4_14451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3858,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3858 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14452 : List (BitVec 512) := [w3766,w3858,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14452 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true))] s4_14452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3858,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3858 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14453 : List (BitVec 512) := [w3766,w3859,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14453 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_14453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3859,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3859 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14454 : List (BitVec 512) := [w3766,w3860,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14454 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(2,true))] s4_14454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3860,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3860 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14455 : List (BitVec 512) := [w3766,w3860,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_14455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14455 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(2,true))] s4_14455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3860,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3860 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14456 : List (BitVec 512) := [w3766,w3860,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14456 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_14456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3860,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3860 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14457 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14457 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_14457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14458 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14458 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false)),(false,(0,true),(9,true))] s4_14458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14459 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_14459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14459 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_14459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14460 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_14460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14460 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_14460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14461 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14461 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_14461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14462 : List (BitVec 512) := [w3766,w3862,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14462 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_14462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3862,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3862 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14463 : List (BitVec 512) := [w3766,w3864,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14463 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(3,true),(2,true))] s4_14463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3864,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3864 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14464 : List (BitVec 512) := [w3766,w3864,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14464 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true))] s4_14464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3864,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3864 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14465 : List (BitVec 512) := [w3766,w3864,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14465 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(3,true),(6,true))] s4_14465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3864,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3864 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14466 : List (BitVec 512) := [w3766,w3864,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_14466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14466 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(7,true),(6,true))] s4_14466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3864,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3864 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14467 : List (BitVec 512) := [w3766,w3865,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_14467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14467 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_14467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3865,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3865 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14468 : List (BitVec 512) := [w3766,w3865,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14468 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_14468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3865,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3865 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
