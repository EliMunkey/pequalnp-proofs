import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5904 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b5_5904 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5904 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true))] s5_5904 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5905 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6500,w6588]
theorem b5_5905 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5905 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_5905 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6500,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6500 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5907 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b5_5907 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5907 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true))] s5_5907 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5908 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6573,w6588]
theorem b5_5908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5908 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_5908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6573,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6573 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5910 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6579,w6588]
theorem b5_5910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5910 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true)),(false,(0,false),(8,true)),(false,(2,false),(0,false))] s5_5910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6579,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6579 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5913 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5917 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6590,w6667]
theorem b5_5917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5917 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(10,true))] s5_5917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6590,v0_6667] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6590 (PetersenWireProjection.cons pc0_6667 rfl)))))))))) (by decide +kernel)
def s5_5933 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6600,w6889]
theorem b5_5933 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5933 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5933 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6600,v0_6889] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6600 (PetersenWireProjection.cons pc0_6889 rfl)))))))))) (by decide +kernel)
def s5_5948 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6615,w6851]
theorem b5_5948 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5948 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6615,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6615 (PetersenWireProjection.cons pc0_6851 rfl)))))))))) (by decide +kernel)
def s5_5949 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6616,w6851]
theorem b5_5949 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5949 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(5,true),(1,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_5949 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6616,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6616 (PetersenWireProjection.cons pc0_6851 rfl)))))))))) (by decide +kernel)
def s5_5953 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618,w6851]
theorem b5_5953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5953 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_5953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6618,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6618 (PetersenWireProjection.cons pc0_6851 rfl)))))))))) (by decide +kernel)
def s5_5954 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618,w6889]
theorem b5_5954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(8,true),(9,true)),(false,(1,true),(10,true))] s5_5954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6618,v0_6889] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6618 (PetersenWireProjection.cons pc0_6889 rfl)))))))))) (by decide +kernel)
def s5_5956 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6619,w6667]
theorem b5_5956 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5956 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5956 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6619,v0_6667] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6619 (PetersenWireProjection.cons pc0_6667 rfl)))))))))) (by decide +kernel)
def s5_5962 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6643,w6745]
theorem b5_5962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5962 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6643,v0_6745] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6643 (PetersenWireProjection.cons pc0_6745 rfl)))))))))) (by decide +kernel)
def s5_5965 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6698]
theorem b5_5965 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(2,true),(9,true)),(false,(1,true),(0,false))] s5_5965 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6698] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6698 rfl)))))))))) (by decide +kernel)
def s5_5966 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6793]
theorem b5_5966 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5966 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(6,true)),(false,(9,true),(6,true)),(false,(1,true),(0,false))] s5_5966 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6793] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6793 rfl)))))))))) (by decide +kernel)
def s5_5967 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6812]
theorem b5_5967 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5967 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true)),(false,(1,true),(0,true)),(false,(0,true),(10,true))] s5_5967 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6812] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6812 rfl)))))))))) (by decide +kernel)
def s5_5968 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6668,w6690]
theorem b5_5968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5968 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(9,true),(2,true)),(false,(1,true),(10,true))] s5_5968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6668,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6668 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5969 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6669,w6785]
theorem b5_5969 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5969 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5969 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6669,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6669 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5970 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6670,w6785]
theorem b5_5970 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5970 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5970 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6670,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6670 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5971 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6671,w6690]
theorem b5_5971 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5971 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(5,true)),(false,(2,true),(9,true)),(false,(1,true),(10,true))] s5_5971 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6671,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6671 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5972 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6671,w6785]
theorem b5_5972 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5972 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(2,true),(6,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_5972 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6671,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6671 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5973 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6672,w6785]
theorem b5_5973 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5973 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(1,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_5973 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6672,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6672 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5974 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6673,w6785]
theorem b5_5974 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5974 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5974 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6673,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6673 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5975 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6674,w6785]
theorem b5_5975 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_5975 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6674,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6674 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5976 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6675,w6690]
theorem b5_5976 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5976 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6675,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6675 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5977 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6676,w6690]
theorem b5_5977 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5977 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5977 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6676,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6676 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5978 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6677,w6690]
theorem b5_5978 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5978 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6677,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6677 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5979 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6678,w6690]
theorem b5_5979 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5979 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5979 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6678,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6678 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5980 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6679,w6690]
theorem b5_5980 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5980 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5980 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6679,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6679 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5981 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6680,w6690]
theorem b5_5981 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5981 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_5981 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6680,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6680 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5985 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b5_5985 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5985 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(8,true),(1,true))] s5_5985 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_5994 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b5_5994 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5994 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(8,true),(1,true))] s5_5994 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_6004 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b5_6004 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6004 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(9,true),(2,true))] s5_6004 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6857] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6857 rfl)))))))))) (by decide +kernel)
def s5_6025 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b5_6025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6025 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,false),(7,true)),(false,(9,true),(3,true))] s5_6025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_6052 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873]
theorem b5_6052 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6052 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(8,true)),(false,(8,true),(6,true))] s5_6052 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6057 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b5_6057 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6057 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(2,true),(8,true)),(false,(8,true),(7,true))] s5_6057 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6153 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6048,w6179,w6567,w6785,w6873]
theorem b5_6153 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6153 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(8,true),(9,true)),(false,(7,true),(10,true))] s5_6153 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6048,v0_6179,v0_6567,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6158 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6195,w6522,w6785,w6873]
theorem b5_6158 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6158 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_6158 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6195,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6166 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6538,w6785,w6873]
theorem b5_6166 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6166 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_6166 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6538,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6170 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6805,w6873]
theorem b5_6170 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6170 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_6170 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6805,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6805 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6191 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5810,w5956,w6300,w6588]
theorem b5_6191 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6191 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(6,true),(3,true)),(false,(1,true),(6,true))] s5_6191 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_6197 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6755]
theorem b5_6197 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6197 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(3,true),(1,false)),(false,(1,true),(6,true))] s5_6197 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6755] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6755 rfl)))))))))) (by decide +kernel)
def s5_6203 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6667,w6748]
theorem b5_6203 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6203 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(3,true),(1,false)),(false,(1,true),(6,true))] s5_6203 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6667,v0_6748] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6748 rfl)))))))))) (by decide +kernel)
def s5_6204 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6667,w6807]
theorem b5_6204 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6204 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(6,true),(1,false)),(false,(1,true),(6,true))] s5_6204 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6667,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_6208 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6690,w6745]
theorem b5_6208 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6208 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(9,true),(3,true)),(false,(1,true),(6,true))] s5_6208 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6690,v0_6745] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6745 rfl)))))))))) (by decide +kernel)
def s5_6210 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6715,w6720]
theorem b5_6210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6210 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(9,true),(3,true)),(false,(1,true),(6,true))] s5_6210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6715,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_6224 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5585,w5760,w5892,w5956,w6300,w6588]
theorem b5_6224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6224 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true)),(false,(6,true),(0,true))] s5_6224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5760,v0_5892,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5760 (PetersenWireProjection.cons pc0_5892 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_6232 : List (BitVec 512) := [w3766,w4344,w4716,w5200,w5393,w5698,w6048,w6179,w6300,w6588]
theorem b5_6232 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6232 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(6,true),(2,true)),(false,(1,true),(5,true))] s5_6232 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5200,v0_5393,v0_5698,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5200 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_6238 : List (BitVec 512) := [w3766,w4344,w5135,w5203,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_6238 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6238 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_6238 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_5135,v0_5203,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6248 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6124,w6522,w6720,w6873]
theorem b5_6248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6248 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_6248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6124,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_6254 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6538,w6720,w6873]
theorem b5_6254 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6254 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_6254 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6538,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s6_26 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5698,w6179,w6522,w6588]
theorem b6_26 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_26 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(6,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s6_26 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_39 : List (BitVec 512) := [w2204,w2532,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_39 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_39 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(6,true),(1,true)),(false,(1,true),(0,true))] s6_39 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2204,v0_2532,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2204 (PetersenWireProjection.cons pc0_2532 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_49 : List (BitVec 512) := [w2468,w2681,w3582,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b6_49 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_49 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s6_49 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3582,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_54 : List (BitVec 512) := [w2468,w3356,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_54 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_54 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s6_54 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3356,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3356 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_55 : List (BitVec 512) := [w2468,w3582,w4716,w5135,w5698,w6179,w6389,w6522,w6588]
theorem b6_55 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_55 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true)),(false,(4,true),(10,true))] s6_55 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4716,v0_5135,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_57 : List (BitVec 512) := [w2468,w3619,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_57 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_57 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s6_57 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3619,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_58 : List (BitVec 512) := [w2468,w3741,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_58 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_58 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s6_58 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3741,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3741 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_82 : List (BitVec 512) := [w3341,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b6_82 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_82 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(8,true),(7,true)),(false,(10,true),(4,true))] s6_82 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3341,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3341 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))) (by decide +kernel)
def s6_83 : List (BitVec 512) := [w3582,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b6_83 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_83 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s6_83 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))) (by decide +kernel)
def s6_84 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b6_84 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_84 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(8,true)),(false,(7,true),(6,true)),(false,(10,true),(3,true))] s6_84 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))) (by decide +kernel)
def s6_85 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b6_85 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_85 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true)),(false,(7,true),(6,true)),(false,(9,true),(3,true))] s6_85 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_86 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w6179,w6522,w6588,w6890]
theorem b6_86 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_86 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(8,true)),(false,(2,true),(6,true)),(false,(9,true),(1,false)),(false,(8,true),(9,true))] s6_86 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6522,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))) (by decide +kernel)
end NineCert
