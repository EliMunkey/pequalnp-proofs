import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12697 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4987,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12697 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12698 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4987,w5135,w5585,w5956,w6300,w6588]
theorem b4_12698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12698 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12699 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5013,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12699 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12700 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5013,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12700 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12701 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5013,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12701 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12702 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5013,w5135,w5585,w5956,w6300,w6588]
theorem b4_12702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12702 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12703 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5020,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12703 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5020,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5020 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12704 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5020,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12704 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5020,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5020 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12705 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5020,w5135,w5585,w5956,w6300,w6588]
theorem b4_12705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12705 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5020,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5020 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12706 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5031,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12706 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12707 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5031,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12707 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12708 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5031,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12708 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12709 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5031,w5135,w5585,w5956,w6300,w6588]
theorem b4_12709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12709 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12710 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5034,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12710 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12711 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5034,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12711 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12712 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5034,w5135,w5585,w5956,w6300,w6588]
theorem b4_12712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12712 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12713 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5046,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12713 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5046,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5046 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12714 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5046,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12714 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5046,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5046 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12715 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5046,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12715 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12715 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12715 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5046,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5046 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12716 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5046,w5135,w5585,w5956,w6300,w6588]
theorem b4_12716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12716 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5046,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5046 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12717 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12717 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12717 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12717 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12718 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12718 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12719 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12719 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12720 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300,w6588]
theorem b4_12720 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12720 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12720 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12721 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5198,w5585,w5956,w6061,w6300,w6588]
theorem b4_12721 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12721 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12721 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5198,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5198 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12722 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5198,w5585,w5956,w6300,w6389,w6588]
theorem b4_12722 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12722 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12722 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5198,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5198 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12723 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5198,w5585,w5956,w6300,w6543,w6588]
theorem b4_12723 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12723 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12723 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5198,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5198 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12724 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5198,w5585,w5956,w6300,w6588]
theorem b4_12724 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12724 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12724 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5198,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5198 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12729 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5205,w5585,w5956,w6061,w6300,w6588]
theorem b4_12729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12729 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12730 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5205,w5585,w5956,w6300,w6389,w6588]
theorem b4_12730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12730 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12731 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5205,w5585,w5956,w6300,w6543,w6588]
theorem b4_12731 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12731 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12731 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12732 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5205,w5585,w5956,w6300,w6588]
theorem b4_12732 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12732 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12732 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12733 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5239,w5585,w5956,w6061,w6300,w6588]
theorem b4_12733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12733 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12734 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5239,w5585,w5956,w6300,w6389,w6588]
theorem b4_12734 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12734 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12734 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12735 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5239,w5585,w5956,w6300,w6543,w6588]
theorem b4_12735 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12735 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12735 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12736 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5239,w5585,w5956,w6300,w6588]
theorem b4_12736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12736 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12822 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5861,w5956,w6061,w6300,w6588]
theorem b4_12822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12822 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5861,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12823 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5861,w5956,w6300,w6389,w6588]
theorem b4_12823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12823 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5861,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12824 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5861,w5956,w6300,w6543,w6588]
theorem b4_12824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12824 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5861,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12825 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5861,w5956,w6300,w6588]
theorem b4_12825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12825 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12859 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6147,w6300,w6588]
theorem b4_12859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12859 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6061,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12860 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6153,w6300,w6588]
theorem b4_12860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12860 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6061,v1_6153,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12868 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6444,w6588]
theorem b4_12868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12868 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12875 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6556,w6588]
theorem b4_12875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12875 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6556,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6556 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12882 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588,w6756]
theorem b4_12882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12882 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_12897 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6147,w6300,w6389,w6588]
theorem b4_12897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12897 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6147,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12898 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6147,w6300,w6543,w6588]
theorem b4_12898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12898 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6147,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12899 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6147,w6300,w6588]
theorem b4_12899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12899 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12900 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6153,w6300,w6543,w6588]
theorem b4_12900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12900 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6153,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12901 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6153,w6300,w6588]
theorem b4_12901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12901 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6153,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12923 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6444,w6588]
theorem b4_12923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12923 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12924 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6446,w6588]
theorem b4_12924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12924 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12932 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6556,w6588]
theorem b4_12932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12932 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6556,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6556 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12939 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588,w6756]
theorem b4_12939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12939 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_12953 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6444,w6543,w6588]
theorem b4_12953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12953 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6444,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12954 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6444,w6588]
theorem b4_12954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12954 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12955 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6446,w6543,w6588]
theorem b4_12955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12955 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6446,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12956 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6446,w6588]
theorem b4_12956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12956 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_12956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12970 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6556,w6588]
theorem b4_12970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12970 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6556,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6556 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_12978 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6756]
theorem b4_12978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12978 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_12989 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6556,w6588]
theorem b4_12989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12989 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6556,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6556 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_12996 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6756]
theorem b4_12996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_12996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl)))))))))) (by decide +kernel)
def s4_15877 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_15877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15877 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_15877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4392,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_15878 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5209,w5393,w5585,w5956,w6300,w6588]
theorem b4_15878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15878 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_15878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4392,v1_4716,v1_5135,v1_5209,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5209 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
