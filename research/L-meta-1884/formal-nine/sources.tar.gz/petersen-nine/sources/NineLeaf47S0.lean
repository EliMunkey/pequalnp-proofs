import NinePin47
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3325 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3325 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3325 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s3_3325 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s3_3364 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_3364 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3364 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s3_3364 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6543,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6543 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s3_4576 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4576 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4576 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s3_4576 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_4917,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4917 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_5591 : List (BitVec 512) := [w1117,w1418,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5591 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5591 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_5591 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_1117,v47_1418,v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_1117 (PetersenWireProjection.cons pc47_1418 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12272 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12272 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6549,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6549 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12273 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12273 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6567,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6567 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12283 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12283 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12283 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12283 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588,v47_6908] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6908 rfl))))))))))) (by decide +kernel)
def s4_12285 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12285 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12285 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12285 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_5956,v47_6522,v47_6588,v47_6873] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6873 rfl))))))))))) (by decide +kernel)
def s4_12286 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12286 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12286 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12286 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_6101,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12287 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12287 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4583,v47_4716,v47_5135,v47_5585,v47_6179,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4583 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12319 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4892,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12319 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s4_12319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_4892,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4892 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12325 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4917,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12325 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_4917,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4917 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12326 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4917,w5135,w5585,w5956,w6300,w6588]
theorem b4_12326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12326 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_4917,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4917 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_12353 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4964,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12353 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s4_12353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_4964,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4964 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12362 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5263,w5585,w5956,w6300,w6522,w6588]
theorem b4_12362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12362 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(4,true))] s4_12362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5263,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5263 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12365 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5274,w5585,w5956,w6300,w6522,w6588]
theorem b4_12365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12365 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s4_12365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5274,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5274 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12373 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5291,w5585,w6101,w6300,w6522,w6588]
theorem b4_12373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12373 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5291,v47_5585,v47_6101,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5291 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12378 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5314,w5585,w5956,w6300,w6543,w6588]
theorem b4_12378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12378 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5314,v47_5585,v47_5956,v47_6300,v47_6543,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5314 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6543 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12379 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5314,w5585,w5956,w6300,w6588]
theorem b4_12379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12379 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5314,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5314 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_12395 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5689,w5956,w6300,w6522,w6588]
theorem b4_12395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12395 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5689,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5689 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12396 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5689,w5956,w6300,w6588]
theorem b4_12396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12396 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5689,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5689 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_12421 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5725,w5956,w6300,w6522,w6588]
theorem b4_12421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12421 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(4,true))] s4_12421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5725,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5725 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12433 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5755,w5769,w5956,w6300,w6588]
theorem b4_12433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12433 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s4_12433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5755,v47_5769,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5755 (PetersenWireProjection.cons pc47_5769 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12434 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5755,w5956,w6300,w6522,w6588]
theorem b4_12434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12434 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5755,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5755 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12435 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5755,w5956,w6300,w6588]
theorem b4_12435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12435 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5755,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5755 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_12461 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5802,w5956,w6300,w6522,w6588]
theorem b4_12461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12461 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s4_12461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5802,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5802 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12505 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6553,w6588]
theorem b4_12505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12505 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s4_12505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6553,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6553 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12506 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6572,w6588]
theorem b4_12506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12506 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(4,true))] s4_12506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6572,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6572 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12507 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6575,w6588]
theorem b4_12507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12507 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s4_12507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6522,v47_6575,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6575 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12543 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6549,w6588]
theorem b4_12543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12543 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6389,v47_6522,v47_6549,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6389 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6549 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12545 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6567,w6588]
theorem b4_12545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12545 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6389,v47_6522,v47_6567,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6389 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6567 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_12547 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588,w6908]
theorem b4_12547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12547 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_12547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6389,v47_6522,v47_6588,v47_6908] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6389 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6908 rfl))))))))))) (by decide +kernel)
def s4_15610 : List (BitVec 512) := [w3766,w4284,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_15610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15610 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_15610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4284,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4284 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_15611 : List (BitVec 512) := [w3766,w4284,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15611 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_15611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4284,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4284 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_15612 : List (BitVec 512) := [w3766,w4285,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_15612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15612 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_15612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4285,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4285 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_15613 : List (BitVec 512) := [w3766,w4285,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15613 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_15613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4285,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4285 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s4_16232 : List (BitVec 512) := [w3766,w4344,w4441,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_16232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16232 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_16232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4441,v47_4716,v47_5135,v47_5393,v47_5585,v47_6179,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4441 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_16253 : List (BitVec 512) := [w3766,w4344,w4456,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_16253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16253 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_16253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4456,v47_4716,v47_5135,v47_5393,v47_5585,v47_6101,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4456 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_16971 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16971 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_16971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_4917,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6567,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4917 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6567 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_16973 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_16973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16973 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_16973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_4917,v47_5135,v47_5393,v47_5585,v47_5956,v47_6522,v47_6588,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4917 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6873 rfl))))))))))) (by decide +kernel)
def s4_17002 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5835,w5956,w6300,w6588]
theorem b4_17002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17002 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s4_17002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_4926,v47_5135,v47_5393,v47_5585,v47_5835,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_4926 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5835 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_17176 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5956,w6522,w6588,w6873]
theorem b4_17176 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17176 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_17176 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5689,v47_5956,v47_6522,v47_6588,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5689 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6873 rfl))))))))))) (by decide +kernel)
def s4_17259 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5755,w5956,w6389,w6522,w6588]
theorem b4_17259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17259 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_17259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5755,v47_5956,v47_6389,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5755 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6389 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_17260 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5755,w6225,w6300,w6522,w6588]
theorem b4_17260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17260 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s4_17260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5755,v47_6225,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5755 (PetersenWireProjection.cons pc47_6225 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))))) (by decide +kernel)
def s4_17996 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6516,w6522,w6873]
theorem b4_17996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17996 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s4_17996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6516,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6516 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
def s5_1098 : List (BitVec 512) := [w860,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1098 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1098 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_1098 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_860,v47_3258,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_860 (PetersenWireProjection.cons pc47_3258 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_1534 : List (BitVec 512) := [w994,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1534 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1534 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_1534 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_994,v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_994 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_2276 : List (BitVec 512) := [w1259,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2276 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2276 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_2276 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_1259,v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_1259 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_3845 : List (BitVec 512) := [w2468,w2531,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3845 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3845 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s5_3845 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_2531,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_2531 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_3846 : List (BitVec 512) := [w2468,w2532,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3846 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3846 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(4,true))] s5_3846 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_2532,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_2532 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_3847 : List (BitVec 512) := [w2468,w2533,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3847 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3847 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s5_3847 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_2533,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_2533 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_3873 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5045,w5585,w5956,w6300,w6588]
theorem b5_3873 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3873 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(2,true),(5,true)),(false,(2,true),(0,true))] s5_3873 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_2681,v47_3766,v47_4344,v47_4716,v47_5045,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_2681 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5045 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_3904 : List (BitVec 512) := [w2468,w2701,w3766,w4344,w4716,w5585,w5956,w6300,w6522,w6588]
theorem b5_3904 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3904 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s5_3904 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_2701,v47_3766,v47_4344,v47_4716,v47_5585,v47_5956,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_2701 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4028 : List (BitVec 512) := [w2468,w3766,w4285,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4028 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4028 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_4028 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4285,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4285 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4116 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5314,w5585,w6101,w6300,w6588]
theorem b5_4116 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4116 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_4116 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5314,v47_5585,v47_6101,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5314 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4117 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5319,w5585,w5956,w6300,w6588]
theorem b5_4117 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4117 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(2,true))] s5_4117 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5319,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5319 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4119 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5454,w5585,w5956,w6300,w6588]
theorem b5_4119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4119 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(4,true))] s5_4119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5454,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5454 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4120 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5455,w5585,w5956,w6300,w6588]
theorem b5_4120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4120 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s5_4120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5455,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5455 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4144 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5835,w5956,w6300,w6588]
theorem b5_4144 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4144 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_4144 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5835,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5835 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4210 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6340,w6522,w6588]
theorem b5_4210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4210 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(2,true),(3,true))] s5_4210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6340,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6340 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4211 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6341,w6522,w6588]
theorem b5_4211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4211 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(3,true))] s5_4211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6341,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6341 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4212 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6342,w6522,w6588]
theorem b5_4212 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4212 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(4,true),(2,true))] s5_4212 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6342,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6342 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4213 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6344,w6522,w6588]
theorem b5_4213 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4213 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(5,true))] s5_4213 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6344,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6344 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_4222 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6516,w6522,w6873]
theorem b5_4222 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4222 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_4222 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6516,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6516 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
end NineCert
