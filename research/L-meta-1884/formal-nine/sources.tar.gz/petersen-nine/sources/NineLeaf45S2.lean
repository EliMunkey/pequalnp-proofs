import NinePin45
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7201 : List (BitVec 512) := [w1292,w2164,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6807]
theorem b4_7201 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7201 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7201 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s4_7203 : List (BitVec 512) := [w1292,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b4_7203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7203 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7221 : List (BitVec 512) := [w1292,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_7221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7221 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s4_7221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7241 : List (BitVec 512) := [w1292,w2837,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_7241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7241 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(0,true))] s4_7241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2837,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2837 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7243 : List (BitVec 512) := [w1292,w2838,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7243 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(0,true))] s4_7243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2838,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2838 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7244 : List (BitVec 512) := [w1292,w2857,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7244 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(0,true))] s4_7244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2857,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2857 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7247 : List (BitVec 512) := [w1292,w2878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7247 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,false))] s4_7247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2878,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2878 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7248 : List (BitVec 512) := [w1292,w2878,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_7248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7248 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,false))] s4_7248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2878,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2878 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7250 : List (BitVec 512) := [w1292,w2880,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7250 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(0,true))] s4_7250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2880,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2880 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7252 : List (BitVec 512) := [w1292,w3075,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_7252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7252 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3075,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5848,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3075 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7253 : List (BitVec 512) := [w1292,w3075,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7253 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3075,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3075 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7255 : List (BitVec 512) := [w1292,w3123,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_7255 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7255 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7255 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3123,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3123 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7257 : List (BitVec 512) := [w1292,w3127,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_7257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7257 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3127,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3127 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7258 : List (BitVec 512) := [w1292,w3127,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_7258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7258 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3127,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3127 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7264 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7264 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7265 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_7265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7265 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7266 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_7266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7266 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7272 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7272 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s4_7273 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7273 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7274 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_7274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7274 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7275 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7275 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_7276 : List (BitVec 512) := [w1292,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_7276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7276 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7278 : List (BitVec 512) := [w1292,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_7278 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7278 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7278 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7291 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_7291 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7291 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7291 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7292 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b4_7292 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7292 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7292 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7293 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7293 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7293 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7293 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6785] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 rfl)))))))))) (by decide +kernel)
def s4_7294 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6807]
theorem b4_7294 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7294 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7294 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6785,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7295 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7295 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s4_7333 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w4746,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7333 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_4746,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_4746 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7369 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6807]
theorem b4_7369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7369 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5848,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7375 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6094,w6300,w6588]
theorem b4_7375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7375 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6094,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6094 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7379 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6807]
theorem b4_7379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7379 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6101,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7380 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6105,w6300,w6588]
theorem b4_7380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7380 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6105,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6105 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7386 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6807]
theorem b4_7386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7386 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7388 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_7388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7388 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(0,true))] s4_7388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6237,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6237 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7390 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6421,w6588]
theorem b4_7390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7390 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6421,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6421 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7394 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6807]
theorem b4_7394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7394 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6422,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7395 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6423,w6588]
theorem b4_7395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7395 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6423,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6423 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7401 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6807]
theorem b4_7401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7401 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6478,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7403 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_7403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7403 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(0,true))] s4_7403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6499,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6499 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7405 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6514,w6588]
theorem b4_7405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7405 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6514,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6514 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7409 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6807]
theorem b4_7409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7409 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6522,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7410 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6526,w6588]
theorem b4_7410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7410 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6526,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6526 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7417 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_7417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7417 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s4_7417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6572,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6572 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7431 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6807]
theorem b4_7431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7431 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s4_7431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6748,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6748 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7432 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6813]
theorem b4_7432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7432 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s4_7432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6813] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6813 rfl))))))))))) (by decide +kernel)
def s4_7433 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6821]
theorem b4_7433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7433 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s4_7433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6821] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6821 rfl))))))))))) (by decide +kernel)
def s4_7434 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6852]
theorem b4_7434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7434 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_7434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6852] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6852 rfl))))))))))) (by decide +kernel)
def s4_7435 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6866]
theorem b4_7435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7435 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_7435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6866] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6866 rfl))))))))))) (by decide +kernel)
def s4_7436 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6868]
theorem b4_7436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7436 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_7436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6868] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6868 rfl))))))))))) (by decide +kernel)
def s4_7437 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6890]
theorem b4_7437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7437 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_7437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6890] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6890 rfl))))))))))) (by decide +kernel)
def s4_7438 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6904]
theorem b4_7438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7438 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_7438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6904] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6904 rfl))))))))))) (by decide +kernel)
def s4_7439 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6905]
theorem b4_7439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7439 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_7439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807,v45_6905] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 (PetersenWireProjection.cons pc45_6905 rfl))))))))))) (by decide +kernel)
def s4_7451 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6807]
theorem b4_7451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7451 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7453 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6807]
theorem b4_7453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7453 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7454 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_7454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7454 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6225,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6225 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7455 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_7455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7455 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7457 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6201,w6300,w6588]
theorem b4_7457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7457 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5769,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7458 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_7458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7458 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5769,v45_5956,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7459 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5848,w5956,w6179,w6300,w6588]
theorem b4_7459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7459 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5848,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7480 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6330,w6588]
theorem b4_7480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7480 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6330,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6330 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7486 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6478,w6588]
theorem b4_7486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7486 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7501 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6690,w6807]
theorem b4_7501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7501 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7502 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_7502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7502 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6785] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 rfl)))))))))) (by decide +kernel)
end NineCert
