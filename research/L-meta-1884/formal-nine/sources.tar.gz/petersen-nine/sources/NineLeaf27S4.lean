import NinePin27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5414 : List (BitVec 512) := [w3766,w4275,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5414 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5414 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5414 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4275,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4275 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5456 : List (BitVec 512) := [w3766,w4337,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5456 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5456 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5456 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4337,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4337 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5475 : List (BitVec 512) := [w3766,w4344,w4374,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5475 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5475 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5475 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4374,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4374 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s5_5686 : List (BitVec 512) := [w3766,w4344,w4657,w4716,w5200,w5393,w5698,w5956,w6300,w6588]
theorem b5_5686 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5686 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true)),(false,(0,false),(7,true))] s5_5686 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4657,v27_4716,v27_5200,v27_5393,v27_5698,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4657 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5200 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5698 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5691 : List (BitVec 512) := [w3766,w4344,w4713,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b5_5691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5691 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s5_5691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4713,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720,v27_6890] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4713 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6890 rfl)))))))))) (by decide +kernel)
def s5_5726 : List (BitVec 512) := [w3766,w4344,w4716,w4892,w4964,w5135,w5585,w5956,w6300,w6588]
theorem b5_5726 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5726 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_5726 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4892,v27_4964,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4892 (PetersenWireProjection.cons pc27_4964 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5727 : List (BitVec 512) := [w3766,w4344,w4716,w4909,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5727 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5727 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5727 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4909,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4909 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5728 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5199,w5393,w5585,w5956,w6300,w6588]
theorem b5_5728 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5728 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true)),(false,(0,false),(7,true))] s5_5728 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5199,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5199 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5729 : List (BitVec 512) := [w3766,w4344,w4716,w4911,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5729 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5729 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5729 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4911,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4911 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5730 : List (BitVec 512) := [w3766,w4344,w4716,w4925,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5730 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5730 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5730 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4925,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4925 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
end NineCert
