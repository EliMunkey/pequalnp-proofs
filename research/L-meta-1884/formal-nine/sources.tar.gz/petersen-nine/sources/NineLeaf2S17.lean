import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7354 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5311,w5393,w5585,w5956,w6300,w6588]
theorem b4_7354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7354 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s4_7354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7355 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6522,w6588]
theorem b4_7355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7355 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7356 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b4_7356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7356 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s4_7356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_7357 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5324,w5393,w5956,w6179,w6300,w6588]
theorem b4_7357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7357 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7358 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5338,w5393,w5956,w6179,w6300,w6588]
theorem b4_7358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7358 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5338,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5338 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7359 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5431,w5956,w6179,w6300,w6588]
theorem b4_7359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7359 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5431,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5431 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7361 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5479,w5956,w6179,w6300,w6588]
theorem b4_7361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7361 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7362 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5518,w5956,w6179,w6300,w6588]
theorem b4_7362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7362 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7384 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6163,w6300,w6588]
theorem b4_7384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7384 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(4,true))] s4_7384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6163,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6163 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7399 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6453,w6588]
theorem b4_7399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7399 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(5,true))] s4_7399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6453,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6453 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7415 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6559,w6588]
theorem b4_7415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7415 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7443 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6451,w6522,w6588]
theorem b4_7443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7443 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7448 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6300,w6522,w6588]
theorem b4_7448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7448 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7468 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6158,w6179,w6300,w6588]
theorem b4_7468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7468 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6158,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7477 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6246,w6300,w6588]
theorem b4_7477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7477 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6246,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7485 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6451,w6588]
theorem b4_7485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7485 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7494 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6767]
theorem b4_7494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7494 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(7,true),(4,true))] s4_7494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s4_7509 : List (BitVec 512) := [w1292,w3766,w4344,w5135,w5393,w5518,w5585,w5956,w6101,w6300,w6588]
theorem b4_7509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7509 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(4,true))] s4_7509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7510 : List (BitVec 512) := [w1292,w3766,w4344,w5135,w5393,w5518,w5585,w5956,w6300,w6422,w6588]
theorem b4_7510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7510 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(5,true))] s4_7510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7591 : List (BitVec 512) := [w1312,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7591 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7591 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7591 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7592 : List (BitVec 512) := [w1312,w2223,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7592 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7592 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7592 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7593 : List (BitVec 512) := [w1312,w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_7593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7593 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(4,true))] s4_7593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7594 : List (BitVec 512) := [w1312,w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_7594 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7594 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(5,true))] s4_7594 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7595 : List (BitVec 512) := [w1312,w2229,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7595 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7595 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_7595 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2229,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2229 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7596 : List (BitVec 512) := [w1312,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7596 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7596 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7596 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7599 : List (BitVec 512) := [w1312,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7599 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7600 : List (BitVec 512) := [w1312,w2320,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7600 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2320,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7601 : List (BitVec 512) := [w1312,w2341,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7601 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7602 : List (BitVec 512) := [w1312,w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7602 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(1,false))] s4_7602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7603 : List (BitVec 512) := [w1312,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7603 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7604 : List (BitVec 512) := [w1312,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_7604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7604 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7605 : List (BitVec 512) := [w1312,w2354,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7605 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2354,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7606 : List (BitVec 512) := [w1312,w2362,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7606 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s4_7606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2362,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2362 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7607 : List (BitVec 512) := [w1312,w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7607 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(4,true))] s4_7607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7608 : List (BitVec 512) := [w1312,w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7608 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(4,true))] s4_7608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7609 : List (BitVec 512) := [w1312,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7609 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7610 : List (BitVec 512) := [w1312,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_7610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7610 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7611 : List (BitVec 512) := [w1312,w2441,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7611 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2441,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7612 : List (BitVec 512) := [w1312,w2449,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7612 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(5,true))] s4_7612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2449,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2449 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7613 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7613 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7617 : List (BitVec 512) := [w1312,w2513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7617 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_7617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2513,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7618 : List (BitVec 512) := [w1312,w2513,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7618 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2513,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7619 : List (BitVec 512) := [w1312,w2515,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7619 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_7619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2515,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2515 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7620 : List (BitVec 512) := [w1312,w2517,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7620 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7620 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_7620 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2517,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2517 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7621 : List (BitVec 512) := [w1312,w2517,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7621 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7621 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_7621 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2517,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2517 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_7622 : List (BitVec 512) := [w1312,w2517,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7622 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2517,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2517 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7776 : List (BitVec 512) := [w1312,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7776 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7777 : List (BitVec 512) := [w1312,w3766,w4041,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7777 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_7777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4041,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7778 : List (BitVec 512) := [w1312,w3766,w4045,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7778 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4045,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4045 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7821 : List (BitVec 512) := [w1312,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7821 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7821 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7821 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7870 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6813]
theorem b4_7870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7870 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7871 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5281,w5393,w5585,w5956,w6300,w6588]
theorem b4_7871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7871 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5281,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5281 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7872 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6813]
theorem b4_7872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7872 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7873 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5284,w5393,w5585,w5956,w6300,w6588]
theorem b4_7873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5284,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5284 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7874 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5289,w5393,w5585,w5956,w6300,w6588]
theorem b4_7874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7875 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5297,w5393,w5585,w5956,w6300,w6588]
theorem b4_7875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7875 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5297,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5297 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7876 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6813]
theorem b4_7876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7876 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7877 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5301,w5393,w5585,w5956,w6300,w6588]
theorem b4_7877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5301,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5301 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7878 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5311,w5393,w5585,w5956,w6300,w6588]
theorem b4_7878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7878 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7879 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6522,w6588]
theorem b4_7879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7879 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_7879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7880 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b4_7880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7880 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s4_7880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_7881 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5337,w5393,w5585,w5956,w6300,w6813]
theorem b4_7881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7881 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5337,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5337 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7882 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5362,w5393,w5585,w5956,w6300,w6813]
theorem b4_7882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7882 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_7882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5362,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5362 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7883 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5368,w5393,w5585,w5956,w6300,w6813]
theorem b4_7883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7883 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_7883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5368,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5368 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
end NineCert
