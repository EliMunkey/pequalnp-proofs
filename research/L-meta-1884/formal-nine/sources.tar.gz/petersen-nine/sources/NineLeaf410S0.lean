import NinePin410
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12253 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12253 := by
  intro m le c
  apply rejects_sound r410 i5 4 tgt (small410 adj) hot410 [] s4_12253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v410_2468,v410_3766,v410_4344,v410_4583,v410_4716,v410_5135,v410_5585,v410_5769,v410_5956,v410_6300,v410_6588] (PetersenWireProjection.cons pc410_2468 (PetersenWireProjection.cons pc410_3766 (PetersenWireProjection.cons pc410_4344 (PetersenWireProjection.cons pc410_4583 (PetersenWireProjection.cons pc410_4716 (PetersenWireProjection.cons pc410_5135 (PetersenWireProjection.cons pc410_5585 (PetersenWireProjection.cons pc410_5769 (PetersenWireProjection.cons pc410_5956 (PetersenWireProjection.cons pc410_6300 (PetersenWireProjection.cons pc410_6588 rfl))))))))))) (by decide +kernel)
def s4_12436 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5802,w5956,w6300,w6588]
theorem b4_12436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12436 := by
  intro m le c
  apply rejects_sound r410 i5 4 tgt (small410 adj) hot410 [] s4_12436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v410_2468,v410_3766,v410_4344,v410_4716,v410_5135,v410_5585,v410_5769,v410_5802,v410_5956,v410_6300,v410_6588] (PetersenWireProjection.cons pc410_2468 (PetersenWireProjection.cons pc410_3766 (PetersenWireProjection.cons pc410_4344 (PetersenWireProjection.cons pc410_4716 (PetersenWireProjection.cons pc410_5135 (PetersenWireProjection.cons pc410_5585 (PetersenWireProjection.cons pc410_5769 (PetersenWireProjection.cons pc410_5802 (PetersenWireProjection.cons pc410_5956 (PetersenWireProjection.cons pc410_6300 (PetersenWireProjection.cons pc410_6588 rfl))))))))))) (by decide +kernel)
end NineCert
