import NinePin144
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17330 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6691]
theorem b4_17330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17330 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s4_17330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_4716,v144_5135,v144_5393,v144_5585,v144_5769,v144_5956,v144_6300,v144_6588,v144_6691] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_4716 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5769 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6588 (PetersenWireProjection.cons pc144_6691 rfl))))))))))) (by decide +kernel)
def s4_17524 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6813,w6873]
theorem b4_17524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17524 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s4_17524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_4716,v144_5135,v144_5393,v144_5585,v144_5848,v144_5956,v144_6300,v144_6813,v144_6873] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_4716 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5848 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6813 (PetersenWireProjection.cons pc144_6873 rfl))))))))))) (by decide +kernel)
def s4_17537 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w6225,w6300,w6522,w6588]
theorem b4_17537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17537 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s4_17537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_4716,v144_5135,v144_5393,v144_5585,v144_5848,v144_6225,v144_6300,v144_6522,v144_6588] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_4716 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5848 (PetersenWireProjection.cons pc144_6225 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6588 rfl))))))))))) (by decide +kernel)
def s5_421 : List (BitVec 512) := [w197,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_421 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_421 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_421 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_197,v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_5769,v144_5956,v144_6300,v144_6720] (PetersenWireProjection.cons pc144_197 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5769 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6720 rfl)))))))))) (by decide +kernel)
def s5_2240 : List (BitVec 512) := [w1240,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_2240 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2240 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_2240 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_1240,v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_5956,v144_6101,v144_6300,v144_6720] (PetersenWireProjection.cons pc144_1240 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6101 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6720 rfl)))))))))) (by decide +kernel)
def s5_2659 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6464,w6720]
theorem b5_2659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2659 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_2659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_1328,v144_3766,v144_4344,v144_5135,v144_5393,v144_5769,v144_5956,v144_6300,v144_6464,v144_6720] (PetersenWireProjection.cons pc144_1328 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5769 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6464 (PetersenWireProjection.cons pc144_6720 rfl)))))))))) (by decide +kernel)
def s5_3050 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b5_3050 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3050 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_3050 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_1388,v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_6101,v144_6300,v144_6522,v144_6720] (PetersenWireProjection.cons pc144_1388 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_6101 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 rfl)))))))))) (by decide +kernel)
def s5_3051 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6720]
theorem b5_3051 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3051 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_3051 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_1388,v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_6225,v144_6300,v144_6522,v144_6720] (PetersenWireProjection.cons pc144_1388 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_6225 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 rfl)))))))))) (by decide +kernel)
def s5_3330 : List (BitVec 512) := [w1603,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3330 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3330 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_3330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_1603,v144_3766,v144_4344,v144_4716,v144_5135,v144_5393,v144_5585,v144_5956,v144_6300,v144_6588] (PetersenWireProjection.cons pc144_1603 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_4716 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5956 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6588 rfl)))))))))) (by decide +kernel)
def s5_5835 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5796,w6300,w6522,w6588]
theorem b5_5835 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5835 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_5835 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_4716,v144_5135,v144_5393,v144_5585,v144_5796,v144_6300,v144_6522,v144_6588] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_4716 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5796 (PetersenWireProjection.cons pc144_6300 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6588 rfl)))))))))) (by decide +kernel)
def s5_6244 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w5769,w6225,w6522,w6720,w6873]
theorem b5_6244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6244 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_6244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_5769,v144_6225,v144_6522,v144_6720,v144_6873] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_5769 (PetersenWireProjection.cons pc144_6225 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 (PetersenWireProjection.cons pc144_6873 rfl)))))))))) (by decide +kernel)
def s5_6249 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6136,w6522,w6720,w6873]
theorem b5_6249 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6249 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_6249 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_6101,v144_6136,v144_6522,v144_6720,v144_6873] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_6101 (PetersenWireProjection.cons pc144_6136 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 (PetersenWireProjection.cons pc144_6873 rfl)))))))))) (by decide +kernel)
def s5_6251 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6225,w6522,w6720,w6873]
theorem b5_6251 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6251 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s5_6251 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_6101,v144_6225,v144_6522,v144_6720,v144_6873] (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_6101 (PetersenWireProjection.cons pc144_6225 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 (PetersenWireProjection.cons pc144_6873 rfl)))))))))) (by decide +kernel)
def s6_5 : List (BitVec 512) := [w204,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6720]
theorem b6_5 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_5 := by
  intro m le c
  apply rejects_sound r144 i7 6 tgt (small144 adj) hot144 [] s6_5 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v144_204,v144_3766,v144_4344,v144_5135,v144_5393,v144_5585,v144_6225,v144_6522,v144_6720] (PetersenWireProjection.cons pc144_204 (PetersenWireProjection.cons pc144_3766 (PetersenWireProjection.cons pc144_4344 (PetersenWireProjection.cons pc144_5135 (PetersenWireProjection.cons pc144_5393 (PetersenWireProjection.cons pc144_5585 (PetersenWireProjection.cons pc144_6225 (PetersenWireProjection.cons pc144_6522 (PetersenWireProjection.cons pc144_6720 rfl))))))))) (by decide +kernel)
end NineCert
