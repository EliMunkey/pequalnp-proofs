import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4072 : List (BitVec 512) := [w2468,w3766,w4344,w4528,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4072 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4072 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4072 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4528,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4528 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4076 : List (BitVec 512) := [w2468,w3766,w4344,w4561,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4076 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4076 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(1,true))] s5_4076 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4561,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4561 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4078 : List (BitVec 512) := [w2468,w3766,w4344,w4565,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4078 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4078 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4565,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4565 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4082 : List (BitVec 512) := [w2468,w3766,w4344,w4575,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4082 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4082 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(3,true))] s5_4082 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4575,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4575 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4087 : List (BitVec 512) := [w2468,w3766,w4344,w4587,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4087 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4087 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4087 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4587,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4587 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4089 : List (BitVec 512) := [w2468,w3766,w4344,w4592,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4089 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4089 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(2,true)),(false,(5,true),(1,true))] s5_4089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4592,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4592 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4091 : List (BitVec 512) := [w2468,w3766,w4344,w4594,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4091 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4091 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4091 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4594,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4594 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4097 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4896,w5135,w5585,w5956,w6300,w6588]
theorem b5_4097 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4097 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(3,false))] s5_4097 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_4896,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4896 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4124 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5477,w5585,w5956,w6300,w6588]
theorem b5_4124 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4124 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(6,false))] s5_4124 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5477,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5477 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4126 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5493,w5585,w5956,w6300,w6588]
theorem b5_4126 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4126 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,false))] s5_4126 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5493,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5493 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4188 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6681]
theorem b5_4188 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4188 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4188 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6681] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6681 rfl)))))))))) (by decide +kernel)
def s5_4191 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6553,w6588]
theorem b5_4191 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4191 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false)),(false,(5,true),(1,true))] s5_4191 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6553,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6553 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4202 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6681]
theorem b5_4202 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4202 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4202 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6681] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6681 rfl))))))))) (by decide +kernel)
def s5_4203 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6681,w6690]
theorem b5_4203 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4203 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4203 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6681,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6681 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_4204 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6681,w6720]
theorem b5_4204 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4204 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true))] s5_4204 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6681,v3_6720] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6681 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_4217 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6381,w6389,w6588]
theorem b5_4217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4217 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6381,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6381 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4218 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6381,w6549,w6588]
theorem b5_4218 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s5_4218 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6381,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6381 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4219 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6381,w6588]
theorem b5_4219 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4219 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6381,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6381 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_4324 : List (BitVec 512) := [w2488,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4324 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4324 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4325 : List (BitVec 512) := [w2488,w3766,w4079,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4325 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4325 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4325 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4326 : List (BitVec 512) := [w2488,w3766,w4121,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4326 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4326 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4327 : List (BitVec 512) := [w2488,w3766,w4146,w4344,w4716,w5135,w5585,w6061,w6300,w6588]
theorem b5_4327 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4327 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4327 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4328 : List (BitVec 512) := [w2488,w3766,w4163,w4344,w4716,w5135,w5585,w6061,w6300,w6588]
theorem b5_4328 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4328 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4328 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4163,v3_4344,v3_4716,v3_5135,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4329 : List (BitVec 512) := [w2488,w3766,w4163,w4716,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_4329 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4329 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4163,v3_4716,v3_5135,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4330 : List (BitVec 512) := [w2488,w3766,w4243,w4344,w4716,w5135,w5585,w5956,w6389,w6588]
theorem b5_4330 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4330 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4331 : List (BitVec 512) := [w2488,w3766,w4243,w4716,w5135,w5585,w5956,w6389,w6422,w6588]
theorem b5_4331 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4331 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s5_4331 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4243,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4332 : List (BitVec 512) := [w2488,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4332 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4332 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4333 : List (BitVec 512) := [w2488,w3766,w4316,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4333 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4333 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4333 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4334 : List (BitVec 512) := [w2488,w3766,w4319,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4334 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4334 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4334 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4319,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4335 : List (BitVec 512) := [w2488,w3766,w4344,w4405,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4335 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_4335 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4336 : List (BitVec 512) := [w2488,w3766,w4344,w4415,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4336 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4336 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(8,true)),(false,(5,true),(1,true))] s5_4336 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4415,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4415 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4337 : List (BitVec 512) := [w2488,w3766,w4344,w4547,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4337 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_4337 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4547,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4547 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4338 : List (BitVec 512) := [w2488,w3766,w4344,w4561,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4338 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(1,true))] s5_4338 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4561,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4561 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4339 : List (BitVec 512) := [w2488,w3766,w4344,w4590,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4339 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_4339 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4590,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4590 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4340 : List (BitVec 512) := [w2488,w3766,w4344,w4592,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4340 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4340 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(2,true)),(false,(5,true),(1,true))] s5_4340 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4592,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4592 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4447 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_4447 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4447 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(6,true))] s5_4447 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4478 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6311,w6588]
theorem b5_4478 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4478 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4478 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6311,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6311 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4480 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6350,w6588]
theorem b5_4480 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4480 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4480 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6350,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6350 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4482 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6362,w6588]
theorem b5_4482 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4482 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4482 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6362,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6362 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4517 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6748]
theorem b5_4517 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4517 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s5_4517 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_4521 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6807]
theorem b5_4521 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4521 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s5_4521 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl)))))))))) (by decide +kernel)
def s5_4545 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690,w6720]
theorem b5_4545 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4545 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s5_4545 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_4551 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6378,w6389,w6588]
theorem b5_4551 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4551 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4551 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6378,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6378 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4552 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6378,w6422,w6588]
theorem b5_4552 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4552 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s5_4552 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6378,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6378 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4553 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6378,w6588]
theorem b5_4553 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4553 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4553 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6378,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6378 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_4557 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6890]
theorem b5_4557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4557 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s5_4557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl)))))))))) (by decide +kernel)
def s5_4559 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6053,w6061,w6300,w6588]
theorem b5_4559 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4559 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4559 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6053,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6053 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4560 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6053,w6101,w6300,w6588]
theorem b5_4560 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4560 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4560 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6053,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6053 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4561 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6053,w6300,w6588]
theorem b5_4561 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4561 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4561 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6053,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6053 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_4570 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_4570 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4570 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(6,true))] s5_4570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4580 : List (BitVec 512) := [w2488,w3766,w4344,w4926,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_4580 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4580 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4580 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4926,v3_5135,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4581 : List (BitVec 512) := [w2488,w3766,w4344,w4926,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_4581 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4581 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4581 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4344,v3_4926,v3_5135,v3_5585,v3_6101,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4599 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b5_4599 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4599 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4599 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4611 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6389,w6522,w6588]
theorem b5_4611 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4611 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4611 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4637 : List (BitVec 512) := [w2492,w3766,w3936,w4344,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_4637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4637 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_4637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2492,v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2492 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4677 : List (BitVec 512) := [w2496,w3766,w4079,w4344,w4716,w5135,w5698,w5956,w6300,w6588]
theorem b5_4677 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4677 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_4677 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2496,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2496 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4717 : List (BitVec 512) := [w2497,w3766,w4121,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4717 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4717 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4717 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2497,v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2497 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4718 : List (BitVec 512) := [w2497,w3766,w4178,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4718 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4718 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s5_4718 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2497,v3_3766,v3_4178,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2497 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4178 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4719 : List (BitVec 512) := [w2497,w3766,w4273,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4719 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4719 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4719 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2497,v3_3766,v3_4273,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2497 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4273 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4720 : List (BitVec 512) := [w2497,w3766,w4296,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4720 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4720 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4720 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2497,v3_3766,v3_4296,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2497 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4296 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5185 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5185 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5185 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5185 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5186 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_5186 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5186 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_5186 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6522,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5187 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_5187 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5187 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_5187 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5188 : List (BitVec 512) := [w3766,w3936,w4344,w4759,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5188 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5188 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(3,true))] s5_5188 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4759,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4759 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
