import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4150 : List (BitVec 512) := [w967,w2164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_4150 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4150 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(8,true),(7,true))] s4_4150 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_4151 : List (BitVec 512) := [w967,w2164,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588,w6807]
theorem b4_4151 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4151 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(8,true),(5,true))] s4_4151 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4152 : List (BitVec 512) := [w967,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_4152 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4152 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false))] s4_4152 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4153 : List (BitVec 512) := [w967,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6690]
theorem b4_4153 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4153 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false))] s4_4153 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4154 : List (BitVec 512) := [w967,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6807]
theorem b4_4154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4154 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(5,true),(0,true))] s4_4154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4155 : List (BitVec 512) := [w967,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b4_4155 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4155 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false))] s4_4155 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4156 : List (BitVec 512) := [w967,w2165,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_4156 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4156 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,true))] s4_4156 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2165,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2165 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4157 : List (BitVec 512) := [w967,w2166,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4157 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4157 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(5,true))] s4_4157 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2166,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2166 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4158 : List (BitVec 512) := [w967,w2166,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_4158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4158 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(5,true))] s4_4158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2166,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2166 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4159 : List (BitVec 512) := [w967,w2168,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4159 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4159 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,true),(5,true))] s4_4159 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2168,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2168 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4160 : List (BitVec 512) := [w967,w2169,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4160 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(6,true))] s4_4160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2169,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2169 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4161 : List (BitVec 512) := [w967,w2171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_4161 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4161 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_4161 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4162 : List (BitVec 512) := [w967,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588,w6904]
theorem b4_4162 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4162 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_4162 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
def s4_4163 : List (BitVec 512) := [w967,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6588,w6873]
theorem b4_4163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4163 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(8,true),(6,true))] s4_4163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4164 : List (BitVec 512) := [w967,w2171,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_4164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4164 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_4164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4165 : List (BitVec 512) := [w967,w2171,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_4165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4165 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_4165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4166 : List (BitVec 512) := [w967,w2171,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6873]
theorem b4_4166 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4166 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_4166 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4167 : List (BitVec 512) := [w967,w2172,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4167 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s4_4167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2172,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2172 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4168 : List (BitVec 512) := [w967,w2172,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_4168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4168 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s4_4168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2172,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2172 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4169 : List (BitVec 512) := [w967,w2173,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4169 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4169 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(6,true))] s4_4169 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2173,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2173 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4170 : List (BitVec 512) := [w967,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4170 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_4170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2175,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2175 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4171 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4171 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4172 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_4172 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4172 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_4172 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_4800,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4800 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4173 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_4173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4173 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4174 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_4174 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4174 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s4_4174 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5652,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5652 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4175 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_4175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4175 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4176 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_4176 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4176 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_4176 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4177 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_4177 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4177 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4177 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4178 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6690]
theorem b4_4178 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4178 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4178 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4179 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_4179 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4179 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4179 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4180 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_4180 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4180 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_4180 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4181 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_4181 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4181 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_4181 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4182 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4182 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4182 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4182 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4183 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_4183 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4183 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_4183 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6640] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6640 rfl))))))))))) (by decide +kernel)
def s4_4184 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_4184 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4184 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4184 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4185 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_4185 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4185 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true))] s4_4185 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_4186 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_4186 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4186 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(6,true))] s4_4186 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_4187 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_4187 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4187 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_4187 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_4188 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b4_4188 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4188 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4188 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4189 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_4189 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4189 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4189 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4190 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_4190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4190 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_4190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4191 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_4191 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4191 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_4191 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4192 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_4192 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4192 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_4192 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4193 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b4_4193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4193 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4194 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_4194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4194 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4195 : List (BitVec 512) := [w967,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_4195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4195 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4196 : List (BitVec 512) := [w967,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_4196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4196 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4197 : List (BitVec 512) := [w967,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_4197 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4197 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4197 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4198 : List (BitVec 512) := [w967,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4198 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4198 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4198 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4199 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b4_4199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4199 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4200 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_4200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4200 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_4200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4201 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_4201 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4201 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s4_4201 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4202 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_4202 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4202 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4202 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4203 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_4203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4203 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4204 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4204 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4204 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4204 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4205 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6588]
theorem b4_4205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4205 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s4_4205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4206 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6464,w6588]
theorem b4_4206 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4206 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4206 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4207 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_4207 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4207 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4207 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4208 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4208 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4208 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_4208 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4209 : List (BitVec 512) := [w967,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4209 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_4209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4210 : List (BitVec 512) := [w967,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_4210 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4210 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_4210 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_4211 : List (BitVec 512) := [w967,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_4211 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4211 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_4211 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4212 : List (BitVec 512) := [w967,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_4212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4212 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_4212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_4213 : List (BitVec 512) := [w967,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_4213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4213 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s4_4213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3766,v3_4344,v3_4584,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4584 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
