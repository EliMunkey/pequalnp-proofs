import NinePin142
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_10 : List (BitVec 512) := [w506,w2535,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b6_10 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_10 := by
  intro m le c
  apply rejects_sound r142 i7 6 tgt (small142 adj) hot142 [] s6_10 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v142_506,v142_2535,v142_3766,v142_4344,v142_4716,v142_5135,v142_5585,v142_5956,v142_6300] (PetersenWireProjection.cons pc142_506 (PetersenWireProjection.cons pc142_2535 (PetersenWireProjection.cons pc142_3766 (PetersenWireProjection.cons pc142_4344 (PetersenWireProjection.cons pc142_4716 (PetersenWireProjection.cons pc142_5135 (PetersenWireProjection.cons pc142_5585 (PetersenWireProjection.cons pc142_5956 (PetersenWireProjection.cons pc142_6300 rfl))))))))) (by decide +kernel)
end NineCert
