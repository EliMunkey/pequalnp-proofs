import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2365 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b3_2365 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2365 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2365 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2366 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b3_2366 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2366 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2366 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2376 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b3_2376 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2376 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2376 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2386 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b3_2386 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2386 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2386 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2405 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b3_2405 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2405 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2405 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2415 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b3_2415 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2415 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2415 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2425 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b3_2425 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2425 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_2425 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s3_2454 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2454 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2454 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true))] s3_2454 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2455 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2455 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2455 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true))] s3_2455 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2469 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2469 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2469 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2469 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2470 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2470 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2470 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2470 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2471 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2471 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2471 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2471 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2472 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2472 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2472 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2472 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2473 : List (BitVec 512) := [w1374,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2473 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2473 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2473 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2474 : List (BitVec 512) := [w1374,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2474 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2474 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2474 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2475 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2475 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2475 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2475 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2476 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2476 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2476 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2476 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2477 : List (BitVec 512) := [w1374,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2477 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2477 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2477 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2478 : List (BitVec 512) := [w1374,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2478 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2478 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2478 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2505 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2505 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2505 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2505 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2506 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2506 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2506 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2506 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2523 : List (BitVec 512) := [w1374,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2523 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2523 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2523 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2524 : List (BitVec 512) := [w1374,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2524 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2524 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2524 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2539 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2539 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2539 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2539 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2540 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2540 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2540 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2540 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2541 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2541 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2541 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2541 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2542 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2542 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2542 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2542 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2543 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b3_2543 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2543 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2543 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s3_2544 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2544 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2544 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2544 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2545 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b3_2545 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2545 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2545 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s3_2546 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2546 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2546 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2546 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2547 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5066,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2547 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2547 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2547 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5066,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5066 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2548 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5066,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2548 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2548 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2548 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5066,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5066 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2549 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5183,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2549 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2549 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2549 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5183,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5183 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2550 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5183,w5393,w5585,w5956,w6300,w6588]
theorem b3_2550 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2550 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2550 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5183,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5183 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2553 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2553 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2553 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2553 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2554 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b3_2554 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2554 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2554 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2555 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2555 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2555 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2555 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2556 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b3_2556 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2556 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2556 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2574 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6179,w6300,w6588]
theorem b3_2574 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2574 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2574 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2575 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b3_2575 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2575 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2575 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2585 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6241,w6300,w6588]
theorem b3_2585 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2585 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2585 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2591 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6756]
theorem b3_2591 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2591 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2591 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl)))))))))))) (by decide +kernel)
def s3_2600 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6241,w6300,w6588]
theorem b3_2600 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2600 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2600 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2606 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b3_2606 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2606 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_2606 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s3_2639 : List (BitVec 512) := [w1403,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2639 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2639 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true))] s3_2639 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2640 : List (BitVec 512) := [w1403,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2640 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2640 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true))] s3_2640 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2653 : List (BitVec 512) := [w1403,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2653 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2653 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2653 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2654 : List (BitVec 512) := [w1403,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2654 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2654 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2654 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2655 : List (BitVec 512) := [w1403,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2655 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2655 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2655 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2656 : List (BitVec 512) := [w1403,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2656 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2656 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2656 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2657 : List (BitVec 512) := [w1403,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2657 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2657 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2657 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2658 : List (BitVec 512) := [w1403,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2658 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2658 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2658 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2659 : List (BitVec 512) := [w1403,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2659 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2659 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2659 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2660 : List (BitVec 512) := [w1403,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2660 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2660 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2660 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2661 : List (BitVec 512) := [w1403,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2661 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2661 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2661 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2662 : List (BitVec 512) := [w1403,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2662 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2662 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2662 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2687 : List (BitVec 512) := [w1403,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2687 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2687 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2687 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2688 : List (BitVec 512) := [w1403,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2688 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2688 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2688 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2702 : List (BitVec 512) := [w1403,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2702 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2702 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2702 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2703 : List (BitVec 512) := [w1403,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2703 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2703 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2703 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2718 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2718 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2718 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2718 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_2719 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2719 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2719 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2719 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_2720 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5034,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2720 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2720 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_2720 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
