import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_722 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_722 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_722 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(6,true),(2,true))] s4_722 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6061,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_723 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_723 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_723 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(8,true),(7,true))] s4_723 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_724 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_724 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_724 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(7,true),(6,true))] s4_724 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_725 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(8,true),(7,true))] s4_725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_726 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_726 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(5,true),(2,true))] s4_726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_727 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_727 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(8,true),(6,true))] s4_727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_728 : List (BitVec 512) := [w103,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b4_728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_728 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(2,true),(0,false))] s4_728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_729 : List (BitVec 512) := [w103,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_729 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true))] s4_729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3935,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3935 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_730 : List (BitVec 512) := [w103,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_730 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true))] s4_730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3935,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3935 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_991 : List (BitVec 512) := [w160,w3329,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_991 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_160,v0_3329,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3329 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_992 : List (BitVec 512) := [w160,w3752,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_992 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_160,v0_3752,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3752 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1016 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6889]
theorem b4_1016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1016 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_1016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_160,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6889] (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6889 rfl))))))))))) (by decide +kernel)
def s4_1232 : List (BitVec 512) := [w192,w3329,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1232 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_1232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_192,v0_3329,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_192 (PetersenWireProjection.cons pc0_3329 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1233 : List (BitVec 512) := [w192,w3752,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1233 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_1233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_192,v0_3752,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_192 (PetersenWireProjection.cons pc0_3752 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1251 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6889]
theorem b4_1251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1251 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_1251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_192,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6889] (PetersenWireProjection.cons pc0_192 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6889 rfl))))))))))) (by decide +kernel)
def s4_1267 : List (BitVec 512) := [w195,w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1267 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1267 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1267 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1280 : List (BitVec 512) := [w195,w1563,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1280 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_1563,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_1563 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1301 : List (BitVec 512) := [w195,w1790,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1301 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_1790,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_1790 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1312 : List (BitVec 512) := [w195,w2060,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1312 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_2060,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_2060 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1325 : List (BitVec 512) := [w195,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1325 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1335 : List (BitVec 512) := [w195,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1335 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1345 : List (BitVec 512) := [w195,w2767,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1345 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_2767,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_2767 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1356 : List (BitVec 512) := [w195,w2927,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_2927,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_2927 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1365 : List (BitVec 512) := [w195,w3193,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1365 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3193,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1366 : List (BitVec 512) := [w195,w3230,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1366 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1366 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1366 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3230,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1367 : List (BitVec 512) := [w195,w3242,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1367 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3242,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3242 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1368 : List (BitVec 512) := [w195,w3246,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1368 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3246,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3246 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1369 : List (BitVec 512) := [w195,w3248,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1369 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3248,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1370 : List (BitVec 512) := [w195,w3283,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1370 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3283,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1371 : List (BitVec 512) := [w195,w3297,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1371 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3297,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1372 : List (BitVec 512) := [w195,w3315,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1372 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3315,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3315 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1373 : List (BitVec 512) := [w195,w3329,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1373 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_1373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3329,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3329 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1374 : List (BitVec 512) := [w195,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1374 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1375 : List (BitVec 512) := [w195,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1375 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1376 : List (BitVec 512) := [w195,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1376 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1377 : List (BitVec 512) := [w195,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1377 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1378 : List (BitVec 512) := [w195,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1378 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1379 : List (BitVec 512) := [w195,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1379 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1380 : List (BitVec 512) := [w195,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1380 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1381 : List (BitVec 512) := [w195,w3689,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1382 : List (BitVec 512) := [w195,w3752,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1382 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_1382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3752,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3752 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1383 : List (BitVec 512) := [w195,w3756,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1383 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3756,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3756 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1384 : List (BitVec 512) := [w195,w3766,w3769,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1384 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_3769,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3769 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1397 : List (BitVec 512) := [w195,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1406 : List (BitVec 512) := [w195,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1406 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1416 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b4_1416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1416 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1426 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6300,w6588]
theorem b4_1426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1426 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1435 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6300,w6588]
theorem b4_1435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1435 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1437 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_1437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1437 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1451 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6048,w6300,w6588]
theorem b4_1451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1451 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1462 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6377,w6588]
theorem b4_1462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1462 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1471 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b4_1471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1471 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_1480 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6889]
theorem b4_1480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1480 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_1480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6889] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6889 rfl))))))))))) (by decide +kernel)
def s4_1522 : List (BitVec 512) := [w200,w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1522 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s4_1522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1539 : List (BitVec 512) := [w200,w1790,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1539 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s4_1539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_1790,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_1790 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1550 : List (BitVec 512) := [w200,w2060,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1550 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_2060,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_2060 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1558 : List (BitVec 512) := [w200,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1558 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s4_1558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1568 : List (BitVec 512) := [w200,w2927,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_2927,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_2927 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1575 : List (BitVec 512) := [w200,w3193,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1575 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3193,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1576 : List (BitVec 512) := [w200,w3230,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1576 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3230,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1577 : List (BitVec 512) := [w200,w3242,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1577 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3242,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3242 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1578 : List (BitVec 512) := [w200,w3248,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1578 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3248,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1579 : List (BitVec 512) := [w200,w3297,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1579 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_1579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3297,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_1580 : List (BitVec 512) := [w200,w3329,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1580 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_1580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3329,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3329 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
