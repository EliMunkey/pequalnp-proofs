import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13378 : List (BitVec 512) := [w3411,w3766,w4344,w4596,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13378 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_13378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4596,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4596 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13379 : List (BitVec 512) := [w3411,w3766,w4344,w4597,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13379 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_13379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4597,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4597 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13380 : List (BitVec 512) := [w3411,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13380 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_13380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4599,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4599 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13381 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_13381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4746,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4746 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13382 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13382 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_13382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4747,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4747 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13383 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13383 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_13383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4748,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4748 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13384 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13384 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_13384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4750,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4750 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13385 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4751,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13385 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_13385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4751,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4751 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13386 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4753,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13386 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_13386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4753,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4753 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13387 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4764,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13387 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_13387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4764,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4764 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13388 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4765,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13388 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_13388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4765,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4765 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13389 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13389 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_13389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4766,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13390 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4768,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13390 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_13390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4768,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4768 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13391 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4769,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13391 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_13391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4769,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4769 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13392 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4771,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13392 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_13392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4771,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4771 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13393 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4778,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13393 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_13393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4778,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4778 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13394 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4779,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13394 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_13394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4779,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4779 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13395 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4780,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13395 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_13395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4780,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4780 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13396 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4782,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13396 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_13396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4782,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4782 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13397 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4783,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_13397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4783,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4783 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13398 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13398 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_13398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4785,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4785 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13399 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4789,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13399 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_13399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4789,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4789 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13400 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4790,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13400 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_13400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4790,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4790 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13401 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4791,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13401 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_13401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4791,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4791 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13402 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4793,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13402 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_13402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4793,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4793 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13403 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4794,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13403 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_13403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4794,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4794 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13404 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4796,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13404 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_13404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4796,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4796 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13405 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4803,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13405 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_13405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4803,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4803 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13406 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4804,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13406 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_13406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4804,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4804 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13407 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4805,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13407 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_13407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4805,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4805 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13408 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4807,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13408 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_13408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4807,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4807 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13409 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4808,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13409 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_13409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4808,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4808 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13410 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13410 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_13410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4810,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4810 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13411 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5618,w5956,w6300,w6588]
theorem b4_13411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13411 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_13411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5618,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5618 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13412 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5620,w5956,w6300,w6588]
theorem b4_13412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13412 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_13412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5620,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5620 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13413 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_13413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13413 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_13413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5621,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5621 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13414 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_13414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13414 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_13414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5623,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5623 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13415 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5624,w5956,w6300,w6588]
theorem b4_13415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13415 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_13415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5624,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5624 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13416 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5626,w5956,w6300,w6588]
theorem b4_13416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13416 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_13416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5626,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5626 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13417 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5634,w5956,w6300,w6588]
theorem b4_13417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13417 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_13417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5634,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5634 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13418 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5635,w5956,w6300,w6588]
theorem b4_13418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13418 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_13418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5635,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5635 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13419 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5636,w5956,w6300,w6588]
theorem b4_13419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13419 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))] s4_13419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5636,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5636 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13420 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5638,w5956,w6300,w6588]
theorem b4_13420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13420 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_13420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5638,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5638 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13421 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5639,w5956,w6300,w6588]
theorem b4_13421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13421 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))] s4_13421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5639,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5639 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13422 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5640,w5956,w6300,w6588]
theorem b4_13422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13422 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_13422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5640,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5640 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13423 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5644,w5956,w6300,w6588]
theorem b4_13423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13423 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true))] s4_13423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5644,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5644 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13424 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5645,w5956,w6300,w6588]
theorem b4_13424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13424 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_13424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5645,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5645 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13425 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5646,w5956,w6300,w6588]
theorem b4_13425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13425 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true))] s4_13425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5646,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5646 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13426 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5648,w5956,w6300,w6588]
theorem b4_13426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13426 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true))] s4_13426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5648,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5648 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13427 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5649,w5956,w6300,w6588]
theorem b4_13427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13427 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_13427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5649,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5649 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13428 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5650,w5956,w6300,w6588]
theorem b4_13428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13428 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_13428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5650,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5650 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13429 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5655,w5956,w6300,w6588]
theorem b4_13429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13429 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s4_13429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5655,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5655 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13430 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b4_13430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13430 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s4_13430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5656,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5656 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13431 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5657,w5956,w6300,w6588]
theorem b4_13431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13431 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_13431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5657,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5657 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13432 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5659,w5956,w6300,w6588]
theorem b4_13432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13432 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_13432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5659,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5659 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13433 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5660,w5956,w6300,w6588]
theorem b4_13433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13433 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s4_13433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5660,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5660 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13434 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5662,w5956,w6300,w6588]
theorem b4_13434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13434 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_13434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5662,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5662 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13435 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_13435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13435 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_13435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5665,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5665 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13436 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5666,w5956,w6300,w6588]
theorem b4_13436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13436 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_13436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5666,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5666 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13437 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5667,w5956,w6300,w6588]
theorem b4_13437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13437 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(6,true))] s4_13437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5667,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5667 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13438 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5669,w5956,w6300,w6588]
theorem b4_13438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13438 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(0,true)),(false,(0,true),(6,true))] s4_13438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5669,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5669 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13439 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5670,w5956,w6300,w6588]
theorem b4_13439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13439 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_13439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5670,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5670 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13440 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5672,w5956,w6300,w6588]
theorem b4_13440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13440 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_13440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5672,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5672 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13441 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_13441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13441 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s4_13441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5750,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5750 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
