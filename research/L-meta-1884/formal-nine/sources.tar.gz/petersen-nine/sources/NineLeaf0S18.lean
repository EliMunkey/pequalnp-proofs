import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3701 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3701 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3701 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3701 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3702 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3702 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_3702 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3703 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_3703 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3703 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true))] s3_3703 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3704 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_3704 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3704 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_3704 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3705 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3705 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3705 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3705 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3706 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3706 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3706 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true))] s3_3706 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3707 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_3707 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3707 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s3_3707 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3708 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3708 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s3_3708 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3709 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_3709 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3709 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(5,true),(2,true))] s3_3709 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3710 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3710 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3710 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3710 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3711 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3711 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3711 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_3711 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3712 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_3712 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3712 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true))] s3_3712 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3713 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_3713 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3713 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_3713 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3714 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_3714 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3714 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s3_3714 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3715 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3715 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3715 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3715 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3716 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3716 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3716 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true))] s3_3716 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3717 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_3717 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3717 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s3_3717 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3718 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3718 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3718 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s3_3718 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3719 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3719 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3719 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_3719 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s3_3720 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_3720 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3720 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(5,true),(2,true))] s3_3720 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3721 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3721 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3721 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_3721 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3722 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_3722 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3722 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(2,true))] s3_3722 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3723 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_3723 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3723 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3723 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3724 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_3724 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3724 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true))] s3_3724 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3725 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_3725 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_3725 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3726 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_3726 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3726 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true))] s3_3726 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3727 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_3727 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3727 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true))] s3_3727 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))))) (by decide +kernel)
def s3_3728 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_3728 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3728 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_3728 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6813] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6813 rfl)))))))))))) (by decide +kernel)
def s3_3729 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_3729 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3729 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true))] s3_3729 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))))) (by decide +kernel)
def s3_3730 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_3730 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3730 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true))] s3_3730 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_3731 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3731 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3731 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_3731 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3732 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_3732 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3732 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true))] s3_3732 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3733 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_3733 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3733 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3733 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3734 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_3734 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3734 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true))] s3_3734 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3735 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_3735 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3735 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_3735 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3736 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3736 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3736 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s3_3736 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3737 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_3737 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3737 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true))] s3_3737 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s3_3738 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b3_3738 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3738 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_3738 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6813] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s3_3739 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_3739 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3739 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true))] s3_3739 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s3_3740 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_3740 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3740 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s3_3740 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_3741 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_3741 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3741 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(5,true),(2,true))] s3_3741 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3742 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b3_3742 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3742 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(5,true),(2,true))] s3_3742 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3743 : List (BitVec 512) := [w3595,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b3_3743 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3743 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s3_3743 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3744 : List (BitVec 512) := [w3595,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b3_3744 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3744 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(2,true),(5,true))] s3_3744 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s3_3745 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3745 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3745 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_3745 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3746 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3746 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3746 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s3_3746 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3747 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3747 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3747 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3747 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3748 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_3748 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3748 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s3_3748 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3749 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3749 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3749 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_3749 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3750 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_3750 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3750 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s3_3750 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3751 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3751 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3751 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_3751 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3752 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3752 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3752 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_3752 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3753 : List (BitVec 512) := [w3619,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3753 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3753 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_3753 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3754 : List (BitVec 512) := [w3619,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3754 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3754 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s3_3754 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3755 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3755 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3755 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_3755 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3756 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_3756 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3756 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s3_3756 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3757 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3757 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3757 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_3757 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3758 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_3758 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3758 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s3_3758 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3759 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3759 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3759 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_3759 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_3760 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3760 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3760 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_3760 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s3_3761 : List (BitVec 512) := [w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3761 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3761 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_3761 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3762 : List (BitVec 512) := [w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_3762 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3762 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s3_3762 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_3763 : List (BitVec 512) := [w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_3763 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3763 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,false),(1,true))] s3_3763 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_3764 : List (BitVec 512) := [w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_3764 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3764 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,false),(5,true))] s3_3764 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
