import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_15277 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_15277 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15277 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_15277 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15278 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_15278 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15278 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,false))] s4_15278 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6857] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_15279 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_15279 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15279 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(8,true),(7,true))] s4_15279 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15280 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6499,w6588]
theorem b4_15280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15280 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(2,true))] s4_15280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6499,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6499 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15281 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6553,w6588]
theorem b4_15281 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15281 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(2,true))] s4_15281 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6553,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6553 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15282 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6572,w6588]
theorem b4_15282 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15282 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(6,true))] s4_15282 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6572,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6572 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15283 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6620]
theorem b4_15283 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15283 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(8,true))] s4_15283 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6620] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6620 rfl))))))))))) (by decide +kernel)
def s4_15284 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6634]
theorem b4_15284 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15284 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(8,true))] s4_15284 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6634] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6634 rfl))))))))))) (by decide +kernel)
def s4_15285 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6647]
theorem b4_15285 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15285 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(8,true))] s4_15285 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6647] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6647 rfl))))))))))) (by decide +kernel)
def s4_15286 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6813]
theorem b4_15286 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15286 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(2,true))] s4_15286 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_15287 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6857]
theorem b4_15287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15287 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(2,true))] s4_15287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_15288 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6866]
theorem b4_15288 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15288 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(6,true))] s4_15288 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_15289 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6890]
theorem b4_15289 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15289 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_15289 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15290 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6897]
theorem b4_15290 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15290 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(7,true))] s4_15290 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6897 rfl))))))))))) (by decide +kernel)
def s4_15291 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6905]
theorem b4_15291 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15291 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s4_15291 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6905] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6905 rfl))))))))))) (by decide +kernel)
def s4_15292 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6910]
theorem b4_15292 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15292 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s4_15292 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6910] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6910 rfl))))))))))) (by decide +kernel)
def s4_15293 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6720,w6890]
theorem b4_15293 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15293 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(8,true),(7,true))] s4_15293 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6720,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15294 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6478,w6588,w6890]
theorem b4_15294 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15294 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(7,true),(8,true))] s4_15294 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6478,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15295 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6543,w6588,w6890]
theorem b4_15295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15295 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(7,true),(8,true))] s4_15295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6543,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15296 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_15296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15296 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(6,true),(7,true))] s4_15296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15297 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6543,w6588]
theorem b4_15297 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15297 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s4_15297 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6389,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15298 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_15298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15298 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(5,true)),(false,(7,true),(1,false))] s4_15298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_15299 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832]
theorem b4_15299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15299 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(6,true),(8,true))] s4_15299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15300 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6179,w6389,w6588,w6832]
theorem b4_15300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15300 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_15300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6389,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15301 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_15301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(7,true),(0,false))] s4_15301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6225,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15302 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_15302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15302 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(6,true))] s4_15302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15303 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_15303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15303 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_15303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15304 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5769,w5956,w6389,w6478,w6588]
theorem b4_15304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15304 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(5,true),(2,true))] s4_15304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6389,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15305 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5956,w6179,w6389,w6588,w6785]
theorem b4_15305 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15305 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(5,true),(6,true))] s4_15305 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6389,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15306 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_15306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15306 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s4_15306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15307 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_15307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15307 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s4_15307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_15308 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_15308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15308 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_15308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15309 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_15309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_15309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15310 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_15310 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15310 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_15310 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15311 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_15311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_15311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15312 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5187,w5393,w5585,w5956,w6389,w6588]
theorem b4_15312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15312 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_15312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15313 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5200,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_15313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_15313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15314 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b4_15314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15314 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_15314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15315 : List (BitVec 512) := [w3766,w4179,w4344,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_15315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15315 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(6,true))] s4_15315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15316 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_15316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(3,true),(1,false))] s4_15316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15317 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6690,w6720]
theorem b4_15317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(2,true),(8,true))] s4_15317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15318 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_15318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15318 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(3,true),(9,true))] s4_15318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15319 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6588,w6720]
theorem b4_15319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(5,true))] s4_15319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6389,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15320 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5956,w6101,w6389,w6588,w6720]
theorem b4_15320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15320 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(6,true))] s4_15320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6389,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15321 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_15321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15321 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(6,true)),(false,(3,true),(0,false))] s4_15321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15322 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_15322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15322 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(2,true))] s4_15322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15323 : List (BitVec 512) := [w3766,w4179,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6720]
theorem b4_15323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15323 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(2,true)),(false,(7,true),(3,true))] s4_15323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15324 : List (BitVec 512) := [w3766,w4181,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4181,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4181 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15325 : List (BitVec 512) := [w3766,w4182,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_15325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15325 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_15325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4182,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4182 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15326 : List (BitVec 512) := [w3766,w4182,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4182,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4182 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15327 : List (BitVec 512) := [w3766,w4182,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15327 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_15327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4182,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4182 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15328 : List (BitVec 512) := [w3766,w4182,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_15328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15328 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_15328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4182,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4182 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15329 : List (BitVec 512) := [w3766,w4182,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_15329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15329 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s4_15329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4182,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4182 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_15330 : List (BitVec 512) := [w3766,w4183,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15330 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4183,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4183 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15331 : List (BitVec 512) := [w3766,w4183,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_15331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15331 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4183,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4183 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15332 : List (BitVec 512) := [w3766,w4183,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_15332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4183,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4183 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15333 : List (BitVec 512) := [w3766,w4184,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15333 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_15333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4184,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4184 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15334 : List (BitVec 512) := [w3766,w4184,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15334 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4184,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4184 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15335 : List (BitVec 512) := [w3766,w4184,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_15335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4184,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4184 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15336 : List (BitVec 512) := [w3766,w4184,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_15336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15336 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s4_15336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4184,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4184 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15337 : List (BitVec 512) := [w3766,w4184,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_15337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true))] s4_15337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4184,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4184 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_15338 : List (BitVec 512) := [w3766,w4186,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4186,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4186 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15339 : List (BitVec 512) := [w3766,w4186,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_15339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4186,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4186 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15340 : List (BitVec 512) := [w3766,w4186,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_15340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15340 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s4_15340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4186,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4186 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
