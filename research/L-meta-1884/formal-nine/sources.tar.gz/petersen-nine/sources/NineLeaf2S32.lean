import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11445 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5956,w6179,w6300,w6389,w6588]
theorem b4_11445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11445 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(4,true)),(false,(3,true),(7,true))] s4_11445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11448 : List (BitVec 512) := [w2336,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_11448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11448 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true))] s4_11448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2336,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5750,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2336 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5750 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11449 : List (BitVec 512) := [w2336,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11449 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true))] s4_11449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2336,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2336 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11453 : List (BitVec 512) := [w2340,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_11453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11453 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_11453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2340,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5760,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2340 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5760 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11454 : List (BitVec 512) := [w2340,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11454 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_11454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2340,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2340 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11455 : List (BitVec 512) := [w2341,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_11455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11455 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(8,true))] s4_11455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11456 : List (BitVec 512) := [w2341,w2686,w3766,w4344,w4716,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_11456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11456 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11457 : List (BitVec 512) := [w2341,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11457 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11458 : List (BitVec 512) := [w2341,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_11458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11458 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11459 : List (BitVec 512) := [w2341,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11459 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_11459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4392,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4392 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11460 : List (BitVec 512) := [w2341,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11460 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_11460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4426,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4426 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11461 : List (BitVec 512) := [w2341,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11461 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s4_11461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4483,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4483 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11462 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_11462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11462 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s4_11462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5993,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5993 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11463 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_11463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11463 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_11463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6004,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6004 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11464 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11464 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11465 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11465 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(5,true))] s4_11465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11466 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_11466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11466 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(5,true))] s4_11466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11467 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11467 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11468 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_11468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11468 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(9,true))] s4_11468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_11469 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_11469 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11469 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_11469 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_11470 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_11470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11470 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_11470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_11471 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_11471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11471 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(9,true),(3,true))] s4_11471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_11472 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_11472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11472 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true))] s4_11472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11473 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_11473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11473 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(5,true),(3,true))] s4_11473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11474 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_11474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11474 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_11474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6225,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11475 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_11475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11475 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(3,true),(7,true))] s4_11475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11476 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6489,w6588]
theorem b4_11476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11476 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true)),(false,(3,true),(7,true))] s4_11476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11477 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_11477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11477 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(7,true),(1,false))] s4_11477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11478 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_11478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11478 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(7,true),(5,true))] s4_11478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11479 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5848,w5956,w6300,w6464,w6588]
theorem b4_11479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11479 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(7,true),(5,true))] s4_11479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5848,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11480 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6061,w6300,w6464,w6588]
theorem b4_11480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11480 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(7,true),(5,true))] s4_11480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6061,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11481 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6225,w6300,w6464,w6588]
theorem b4_11481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11481 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(7,true),(5,true))] s4_11481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6225,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11482 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6478,w6588]
theorem b4_11482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11482 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(7,true),(8,true))] s4_11482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11483 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6567,w6588]
theorem b4_11483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11483 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(7,true),(8,true))] s4_11483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11484 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588,w6690]
theorem b4_11484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11484 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(8,true)),(false,(7,true),(8,true))] s4_11484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11485 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588,w6813]
theorem b4_11485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11485 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(7,true),(5,true))] s4_11485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11486 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588,w6832]
theorem b4_11486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11486 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(7,true),(5,true))] s4_11486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_11487 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588,w6904]
theorem b4_11487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11487 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(7,true),(8,true))] s4_11487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588,v2_6904] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6904 rfl))))))))))) (by decide +kernel)
def s4_11488 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6588,w6873]
theorem b4_11488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11488 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(7,true),(5,true))] s4_11488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s4_11489 : List (BitVec 512) := [w2341,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6690,w6720]
theorem b4_11489 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11489 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true))] s4_11489 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11490 : List (BitVec 512) := [w2341,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_11490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11490 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true))] s4_11490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11491 : List (BitVec 512) := [w2341,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_11491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11491 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s4_11491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11492 : List (BitVec 512) := [w2341,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_11492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11492 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true))] s4_11492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11493 : List (BitVec 512) := [w2352,w3258,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11493 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(1,false))] s4_11493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11494 : List (BitVec 512) := [w2352,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11494 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(1,false))] s4_11494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11495 : List (BitVec 512) := [w2352,w3280,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11495 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3280,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11496 : List (BitVec 512) := [w2352,w3280,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_11496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11496 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(2,true),(0,true))] s4_11496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11497 : List (BitVec 512) := [w2352,w3280,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11497 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11498 : List (BitVec 512) := [w2352,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11498 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11499 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_11499 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11499 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(4,true))] s4_11499 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11500 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11500 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(1,false),(8,true))] s4_11500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11501 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_11501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11501 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(4,true))] s4_11501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11502 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11502 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_11502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11503 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_11503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11503 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(5,true))] s4_11503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11504 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_11504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11504 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(1,false),(8,true))] s4_11504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11505 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_11505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11505 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(5,true))] s4_11505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11506 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11506 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_11506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11507 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_11507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11507 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true))] s4_11507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11508 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_11508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11508 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(9,true))] s4_11508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11509 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_11509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11509 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(1,false),(9,true))] s4_11509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6807] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6807 rfl))))))))))) (by decide +kernel)
def s4_11510 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_11510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11510 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(9,true))] s4_11510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11511 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_11511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11511 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_11511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_11512 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_11512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11512 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(0,false),(3,true))] s4_11512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_11513 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_11513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11513 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,false),(7,true))] s4_11513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
end NineCert
