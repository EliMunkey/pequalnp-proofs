import NinePin117
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1030 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_1030 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1030 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_1030 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_160,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6785,v117_6873] (PetersenWireProjection.cons pc117_160 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6873 rfl))))))))))) (by decide +kernel)
def s4_1259 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_1259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1259 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_1259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_192,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_192 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl))))))))))) (by decide +kernel)
def s4_1514 : List (BitVec 512) := [w197,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1514 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_1514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_197,v117_1328,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_197 (PetersenWireProjection.cons pc117_1328 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl))))))))))) (by decide +kernel)
def s4_1658 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_1658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1658 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_1658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_200,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6785,v117_6873] (PetersenWireProjection.cons pc117_200 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6873 rfl))))))))))) (by decide +kernel)
def s4_1669 : List (BitVec 512) := [w204,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1669 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_1669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_204,v117_1388,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_204 (PetersenWireProjection.cons pc117_1388 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl))))))))))) (by decide +kernel)
def s4_2296 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_2296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2296 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_2296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_360,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832] (PetersenWireProjection.cons pc117_360 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 rfl))))))))))) (by decide +kernel)
def s4_2311 : List (BitVec 512) := [w362,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2311 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_2311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_362,v117_1328,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_362 (PetersenWireProjection.cons pc117_1328 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl))))))))))) (by decide +kernel)
def s4_2352 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_2352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2352 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_2352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_365,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832] (PetersenWireProjection.cons pc117_365 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 rfl))))))))))) (by decide +kernel)
def s4_2915 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_2915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2915 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_2915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_628,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_628 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl))))))))))) (by decide +kernel)
def s4_2959 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_2959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2959 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_2959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_632,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_632 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl))))))))))) (by decide +kernel)
def s4_3102 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_3102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3102 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_3102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_635,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720] (PetersenWireProjection.cons pc117_635 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 rfl))))))))))) (by decide +kernel)
def s4_3118 : List (BitVec 512) := [w637,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3118 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_3118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_637,v117_1384,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_637 (PetersenWireProjection.cons pc117_1384 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl))))))))))) (by decide +kernel)
def s4_9228 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6748]
theorem b4_9228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9228 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_9228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1374,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6748] (PetersenWireProjection.cons pc117_1374 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6748 rfl))))))))))) (by decide +kernel)
def s4_9231 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6869]
theorem b4_9231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9231 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_9231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1374,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6869] (PetersenWireProjection.cons pc117_1374 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6869 rfl))))))))))) (by decide +kernel)
def s4_17807 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6868]
theorem b4_17807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17807 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6868] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6868 rfl))))))))))) (by decide +kernel)
def s4_17808 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6869]
theorem b4_17808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17808 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6869] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6869 rfl))))))))))) (by decide +kernel)
def s4_17817 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6905]
theorem b4_17817 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17817 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17817 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6905] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6905 rfl))))))))))) (by decide +kernel)
def s4_17818 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6906]
theorem b4_17818 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17818 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17818 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6906] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6906 rfl))))))))))) (by decide +kernel)
def s4_17819 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6910]
theorem b4_17819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17819 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6910] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6910 rfl))))))))))) (by decide +kernel)
def s4_17820 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6912]
theorem b4_17820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17820 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6720,v117_6912] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6912 rfl))))))))))) (by decide +kernel)
def s4_17844 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807,w6857]
theorem b4_17844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17844 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6807,v117_6857] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6807 (PetersenWireProjection.cons pc117_6857 rfl))))))))))) (by decide +kernel)
def s4_17846 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6813,w6857]
theorem b4_17846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17846 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6813,v117_6857] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6813 (PetersenWireProjection.cons pc117_6857 rfl))))))))))) (by decide +kernel)
def s4_17847 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6813,w6895]
theorem b4_17847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17847 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6813,v117_6895] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6813 (PetersenWireProjection.cons pc117_6895 rfl))))))))))) (by decide +kernel)
def s4_17848 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6821,w6832]
theorem b4_17848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17848 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6821,v117_6832] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6821 (PetersenWireProjection.cons pc117_6832 rfl))))))))))) (by decide +kernel)
def s4_17861 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6869]
theorem b4_17861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17861 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832,v117_6869] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6869 rfl))))))))))) (by decide +kernel)
def s4_17865 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6897]
theorem b4_17865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17865 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832,v117_6897] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6897 rfl))))))))))) (by decide +kernel)
def s4_17868 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6905]
theorem b4_17868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17868 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832,v117_6905] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6905 rfl))))))))))) (by decide +kernel)
def s4_17871 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6912]
theorem b4_17871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17871 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832,v117_6912] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6912 rfl))))))))))) (by decide +kernel)
def s4_17874 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6917]
theorem b4_17874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17874 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6832,v117_6917] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6917 rfl))))))))))) (by decide +kernel)
def s4_17887 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6866]
theorem b4_17887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17887 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6866] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6866 rfl))))))))))) (by decide +kernel)
def s4_17888 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6869]
theorem b4_17888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17888 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6869] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6869 rfl))))))))))) (by decide +kernel)
def s4_17889 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6890]
theorem b4_17889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17889 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6890] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6890 rfl))))))))))) (by decide +kernel)
def s4_17890 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6895]
theorem b4_17890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17890 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6895] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6895 rfl))))))))))) (by decide +kernel)
def s4_17891 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6908]
theorem b4_17891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17891 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6908] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6908 rfl))))))))))) (by decide +kernel)
def s4_17892 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6912]
theorem b4_17892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17892 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6857,v117_6912] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6857 (PetersenWireProjection.cons pc117_6912 rfl))))))))))) (by decide +kernel)
def s4_17895 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6866,w6908]
theorem b4_17895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17895 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6690,v117_6866,v117_6908] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6866 (PetersenWireProjection.cons pc117_6908 rfl))))))))))) (by decide +kernel)
def s4_17918 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6807,w6890]
theorem b4_17918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17918 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6807,v117_6890] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6807 (PetersenWireProjection.cons pc117_6890 rfl))))))))))) (by decide +kernel)
def s4_17919 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6813,w6890]
theorem b4_17919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17919 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6813,v117_6890] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6813 (PetersenWireProjection.cons pc117_6890 rfl))))))))))) (by decide +kernel)
def s4_17920 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6852,w6890]
theorem b4_17920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17920 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6852,v117_6890] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6852 (PetersenWireProjection.cons pc117_6890 rfl))))))))))) (by decide +kernel)
def s4_17925 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890,w6905]
theorem b4_17925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17925 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720,v117_6890,v117_6905] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6890 (PetersenWireProjection.cons pc117_6905 rfl))))))))))) (by decide +kernel)
def s4_17930 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6832,w6890]
theorem b4_17930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17930 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6748,v117_6832,v117_6890] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6748 (PetersenWireProjection.cons pc117_6832 (PetersenWireProjection.cons pc117_6890 rfl))))))))))) (by decide +kernel)
def s4_17936 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6890,w6908]
theorem b4_17936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17936 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s4_17936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6785,v117_6890,v117_6908] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6890 (PetersenWireProjection.cons pc117_6908 rfl))))))))))) (by decide +kernel)
def s5_416 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_416 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_416 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_416 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_197,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6813] (PetersenWireProjection.cons pc117_197 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6813 rfl)))))))))) (by decide +kernel)
def s5_453 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_453 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_453 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_453 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_204,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6813] (PetersenWireProjection.cons pc117_204 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6813 rfl)))))))))) (by decide +kernel)
def s5_589 : List (BitVec 512) := [w360,w1388,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_589 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [(false,(6,true),(7,true))] s5_589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_360,v117_1388,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_6179,v117_6300,v117_6785] (PetersenWireProjection.cons pc117_360 (PetersenWireProjection.cons pc117_1388 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_6179 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6785 rfl)))))))))) (by decide +kernel)
def s5_1477 : List (BitVec 512) := [w968,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1477 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1477 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1477 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_968,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_968 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1499 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1499 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1499 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1499 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_975,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_975 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_1504 : List (BitVec 512) := [w976,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1504 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1504 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1504 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_976,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_976 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1530 : List (BitVec 512) := [w990,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1530 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1530 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1530 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_990,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_990 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1553 : List (BitVec 512) := [w1003,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1553 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1553 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1553 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1003,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1003 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1582 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5159,w5393,w5585,w5956,w6300,w6588]
theorem b5_1582 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1582 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1582 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1022,v117_3766,v117_4344,v117_4716,v117_5159,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1022 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5159 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1592 : List (BitVec 512) := [w1025,w3766,w4344,w4716,w5160,w5393,w5585,w5956,w6300,w6588]
theorem b5_1592 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1592 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1592 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1025,v117_3766,v117_4344,v117_4716,v117_5160,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1025 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5160 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1598 : List (BitVec 512) := [w1026,w3766,w4344,w4716,w5161,w5393,w5585,w5956,w6300,w6588]
theorem b5_1598 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1598 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1598 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1026,v117_3766,v117_4344,v117_4716,v117_5161,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1026 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5161 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1600 : List (BitVec 512) := [w1027,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1600 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1600 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1600 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1027,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1027 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1853 : List (BitVec 512) := [w1086,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1853 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1853 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1853 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1086,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1086 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1875 : List (BitVec 512) := [w1096,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1875 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1875 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1875 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1096,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1096 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1975 : List (BitVec 512) := [w1122,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1975 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1975 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1975 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1122,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1122 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1978 : List (BitVec 512) := [w1125,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1978 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1978 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1125,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1125 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_1981 : List (BitVec 512) := [w1128,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1981 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1981 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_1981 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1128,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1128 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2223 : List (BitVec 512) := [w1234,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2223 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2223 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2223 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1234,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1234 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2233 : List (BitVec 512) := [w1239,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2233 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2233 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2233 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1239,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1239 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_2241 : List (BitVec 512) := [w1241,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2241 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1241,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1241 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2245 : List (BitVec 512) := [w1245,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2245 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1245,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1245 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2265 : List (BitVec 512) := [w1254,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2265 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1254,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1254 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
end NineCert
