import NinePin39
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_445 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_445 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_445 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s3_445 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2482 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_2482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2482 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(3,true),(6,true))] s4_2482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6543,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6543 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2483 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_2483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2483 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(2,true),(6,true))] s4_2483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6549,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6549 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2484 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_2484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2484 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(4,true),(6,true))] s4_2484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6567,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6567 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2492 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6908]
theorem b4_2492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2492 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s4_2492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s4_2493 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_2493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2493 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(3,true),(6,true))] s4_2493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6389,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6389 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2495 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6873]
theorem b4_2495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2495 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s4_2495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6522,v39_6873] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s4_2496 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_2496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2496 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_2496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6101,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6101 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2497 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_2497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2497 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_2497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6179,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6179 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2503 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6832,w6908]
theorem b4_2503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2503 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s4_2503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6832,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6832 (PetersenWireProjection.cons pc39_6908 rfl))))))))))) (by decide +kernel)
def s4_2505 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6873,w6908]
theorem b4_2505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2505 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(5,true))] s4_2505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6873,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6873 (PetersenWireProjection.cons pc39_6908 rfl))))))))))) (by decide +kernel)
def s4_2506 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6908]
theorem b4_2506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2506 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s4_2506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s4_2515 : List (BitVec 512) := [w499,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_2515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2515 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(3,true),(6,true))] s4_2515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_499,v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6543,v39_6588] (PetersenWireProjection.cons pc39_499 (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6543 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2525 : List (BitVec 512) := [w500,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_2525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2525 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(2,true))] s4_2525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_500,v39_2491,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6549,v39_6588] (PetersenWireProjection.cons pc39_500 (PetersenWireProjection.cons pc39_2491 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6549 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_2535 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_2535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2535 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(4,true))] s4_2535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_502,v39_2494,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6567,v39_6588] (PetersenWireProjection.cons pc39_502 (PetersenWireProjection.cons pc39_2494 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6567 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_12679 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4801,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12679 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_12679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_4801,v39_5135,v39_5585,v39_5956,v39_6061,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_4801 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6061 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_12806 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5653,w5956,w6061,w6300,w6588]
theorem b4_12806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12806 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_12806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5653,v39_5956,v39_6061,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5653 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6061 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl))))))))))) (by decide +kernel)
def s4_12878 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588,w6641]
theorem b4_12878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12878 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_12878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6061,v39_6300,v39_6588,v39_6641] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6061 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 (PetersenWireProjection.cons pc39_6641 rfl))))))))))) (by decide +kernel)
def s4_13042 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_13042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13042 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2492,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6061,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2492 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6061 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13044 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_13044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13044 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2492,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6101,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2492 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6101 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13048 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_13048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13048 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2492,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_2492 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13066 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_13066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13066 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2496,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6061,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2496 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6061 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13069 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6588]
theorem b4_13069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13069 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2496,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6179,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2496 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6179 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13073 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_13073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13073 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2496,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_2496 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13091 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_13091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13091 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2497,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6101,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2497 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6101 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_13099 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_13099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13099 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_13099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2497,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_2497 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_18115 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5452,w5585,w5956,w6300,w6522,w6588]
theorem b4_18115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18115 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_18115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_3766,v39_4344,v39_4716,v39_5135,v39_5452,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5452 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_18116 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5456,w5585,w5956,w6300,w6522,w6588]
theorem b4_18116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18116 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_18116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_3766,v39_4344,v39_4716,v39_5135,v39_5456,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5456 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_18117 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5457,w5585,w5956,w6300,w6522,w6588]
theorem b4_18117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18117 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_18117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_3766,v39_4344,v39_4716,v39_5135,v39_5457,v39_5585,v39_5956,v39_6300,v39_6522,v39_6588] (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5457 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s4_18129 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6101,w6300,w6588]
theorem b4_18129 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18129 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [] s4_18129 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_3766,v39_4344,v39_4716,v39_5135,v39_5470,v39_5585,v39_5956,v39_6101,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5470 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6101 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s5_719 : List (BitVec 512) := [w498,w1915,w2468,w3766,w4344,w4716,w5135,w5585,w6300,w6908]
theorem b5_719 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_719 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_719 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_1915,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_1915 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s5_720 : List (BitVec 512) := [w498,w1915,w2468,w3766,w4344,w4716,w5135,w5585,w6522,w6873]
theorem b5_720 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_720 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(5,true))] s5_720 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_1915,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6522,v39_6873] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_1915 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s5_721 : List (BitVec 512) := [w498,w1915,w2527,w3766,w4344,w4716,w5135,w5585,w6300,w6832]
theorem b5_721 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_721 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_721 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_1915,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6300,v39_6832] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_1915 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6832 rfl)))))))))) (by decide +kernel)
def s5_722 : List (BitVec 512) := [w498,w1915,w2527,w3766,w4344,w4716,w5135,w5585,w6300,w6908]
theorem b5_722 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_722 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(5,true))] s5_722 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_1915,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_1915 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s5_727 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6567,w6873]
theorem b5_727 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_727 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(4,true),(6,true)),(false,(6,true),(7,true))] s5_727 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6567,v39_6873] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6567 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s5_728 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6522,w6873]
theorem b5_728 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_728 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_728 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6101,v39_6522,v39_6873] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6101 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s5_729 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6908]
theorem b5_729 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_729 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_729 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6179,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6179 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s5_730 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6522,w6873]
theorem b5_730 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_730 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_730 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2468,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6179,v39_6522,v39_6873] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2468 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6179 (PetersenWireProjection.cons pc39_6522 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s5_733 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6908]
theorem b5_733 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_733 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(5,true),(6,true))] s5_733 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_498,v39_2527,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_6179,v39_6300,v39_6908] (PetersenWireProjection.cons pc39_498 (PetersenWireProjection.cons pc39_2527 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_6179 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6908 rfl)))))))))) (by decide +kernel)
def s5_753 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6567,w6873]
theorem b5_753 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_753 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(6,true),(4,true)),(false,(6,true),(7,true))] s5_753 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_502,v39_2494,v39_3766,v39_4344,v39_4716,v39_5135,v39_5585,v39_5956,v39_6567,v39_6873] (PetersenWireProjection.cons pc39_502 (PetersenWireProjection.cons pc39_2494 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6567 (PetersenWireProjection.cons pc39_6873 rfl)))))))))) (by decide +kernel)
def s5_4409 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5293,w5585,w5956,w6300,w6588]
theorem b5_4409 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4409 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(2,true),(3,true))] s5_4409 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5293,v39_5585,v39_5956,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5293 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s5_4410 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5296,w5585,w5956,w6300,w6588]
theorem b5_4410 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4410 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(4,true),(3,true))] s5_4410 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5296,v39_5585,v39_5956,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5296 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s5_4418 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5449,w5585,w5956,w6300,w6588]
theorem b5_4418 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4418 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(3,true),(5,true))] s5_4418 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_2488,v39_3766,v39_4344,v39_4716,v39_5135,v39_5449,v39_5585,v39_5956,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_2488 (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5449 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
def s5_6195 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6225,w6300,w6588]
theorem b5_6195 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6195 := by
  intro m le c
  apply rejects_sound r39 i7 8 tgt (small39 adj) hot39 [(false,(4,true),(2,true))] s5_6195 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v39_3766,v39_4344,v39_4716,v39_5135,v39_5470,v39_5585,v39_5956,v39_6225,v39_6300,v39_6588] (PetersenWireProjection.cons pc39_3766 (PetersenWireProjection.cons pc39_4344 (PetersenWireProjection.cons pc39_4716 (PetersenWireProjection.cons pc39_5135 (PetersenWireProjection.cons pc39_5470 (PetersenWireProjection.cons pc39_5585 (PetersenWireProjection.cons pc39_5956 (PetersenWireProjection.cons pc39_6225 (PetersenWireProjection.cons pc39_6300 (PetersenWireProjection.cons pc39_6588 rfl)))))))))) (by decide +kernel)
end NineCert
