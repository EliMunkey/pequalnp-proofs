import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10021 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6522,w6588]
theorem b4_10021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10064 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6890]
theorem b4_10064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10065 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6522,w6588]
theorem b4_10065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10065 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10066 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5862,w5956,w6300,w6588]
theorem b4_10066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10066 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_10066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5862,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5862 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10067 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5873,w5956,w6300,w6588]
theorem b4_10067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10067 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_10067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10083 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6522,w6588]
theorem b4_10083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10083 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10096 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6241,w6300,w6588]
theorem b4_10096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true))] s4_10096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10111 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6502,w6588]
theorem b4_10111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10111 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(1,false))] s4_10111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6502,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6502 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10130 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6899]
theorem b4_10130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10130 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6899] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6899 rfl))))))))))) (by decide +kernel)
def s4_10136 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6762,w6890]
theorem b4_10136 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10136 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10136 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6762,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10142 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890,w6899]
theorem b4_10142 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10142 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10142 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890,v1_6899] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 (PetersenWireProjection.cons pc1_6899 rfl))))))))))) (by decide +kernel)
def s4_10162 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6873,w6890]
theorem b4_10162 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10162 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(0,true))] s4_10162 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6873,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10163 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6446,w6522,w6588]
theorem b4_10163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10163 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6446,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10175 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6555,w6588]
theorem b4_10175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10175 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6555,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10182 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6756]
theorem b4_10182 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10182 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10182 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_10199 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6147,w6300,w6588]
theorem b4_10199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10199 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true))] s4_10199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10251 : List (BitVec 512) := [w1411,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10251 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(0,false),(2,true)),(false,(5,true),(0,true))] s4_10251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10257 : List (BitVec 512) := [w1411,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10257 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10258 : List (BitVec 512) := [w1411,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10258 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10259 : List (BitVec 512) := [w1411,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10259 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10260 : List (BitVec 512) := [w1411,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10260 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10272 : List (BitVec 512) := [w1411,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10272 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10279 : List (BitVec 512) := [w1411,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10279 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10279 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10279 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10287 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10287 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10288 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10288 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10288 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10288 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10289 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5058,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10289 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10289 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10289 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5058,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5058 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10290 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5188,w5393,w5585,w5956,w6300,w6588]
theorem b4_10290 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10290 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10290 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5188,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5188 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10292 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_10292 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10292 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10292 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10293 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_10293 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10293 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10293 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10304 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_10304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10304 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10322 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_10322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10322 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_10337 : List (BitVec 512) := [w1412,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10337 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_10337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1412,v1_3766,v1_4344,v1_4716,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1412 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10338 : List (BitVec 512) := [w1412,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_10338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10338 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_10338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1412,v1_3766,v1_4344,v1_4716,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1412 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_10343 : List (BitVec 512) := [w1415,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10343 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10354 : List (BitVec 512) := [w1415,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10354 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10355 : List (BitVec 512) := [w1415,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10355 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10356 : List (BitVec 512) := [w1415,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10356 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10357 : List (BitVec 512) := [w1415,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10357 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10358 : List (BitVec 512) := [w1415,w2615,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10358 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true))] s4_10358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2615,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10359 : List (BitVec 512) := [w1415,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10359 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10360 : List (BitVec 512) := [w1415,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10360 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10361 : List (BitVec 512) := [w1415,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10361 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,false)),(false,(0,true),(5,true))] s4_10361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10362 : List (BitVec 512) := [w1415,w2654,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10362 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2654,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2654 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10363 : List (BitVec 512) := [w1415,w2655,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10363 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2655,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2655 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10364 : List (BitVec 512) := [w1415,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10364 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10408 : List (BitVec 512) := [w1415,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10408 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10421 : List (BitVec 512) := [w1415,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10421 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10435 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10435 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10436 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10436 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10437 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4994,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10437 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true))] s4_10437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_4994,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4994 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10438 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10438 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10439 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10439 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10440 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5034,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10440 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,false)),(false,(0,true),(5,true))] s4_10440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10441 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5039,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10441 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5039,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5039 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10442 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5040,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10442 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5040,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5040 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10443 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10443 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10444 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5057,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10444 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5057,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5057 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10445 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5189,w5393,w5585,w5956,w6300,w6588]
theorem b4_10445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10445 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5189,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5189 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10447 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_10447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10447 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10448 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_10448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10448 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10462 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_10462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10462 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10484 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_10484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10484 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10485 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6588]
theorem b4_10485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10485 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true))] s4_10485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10498 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b4_10498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10498 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_10498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
