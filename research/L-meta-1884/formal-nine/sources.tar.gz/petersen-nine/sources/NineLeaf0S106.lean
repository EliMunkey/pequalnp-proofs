import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5099 : List (BitVec 512) := [w3766,w3822,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5099 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5099 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5099 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3822,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3822 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5100 : List (BitVec 512) := [w3766,w3824,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5100 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5100 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5100 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3824,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3824 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5101 : List (BitVec 512) := [w3766,w3825,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5101 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5101 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5101 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3825,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3825 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5102 : List (BitVec 512) := [w3766,w3826,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5102 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3826,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3826 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5103 : List (BitVec 512) := [w3766,w3827,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5103 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5103 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5103 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3827,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3827 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5104 : List (BitVec 512) := [w3766,w3828,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5104 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5104 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5104 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3828,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3828 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5105 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_5105 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5105 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(6,true),(7,true)),(false,(10,true),(1,true))] s5_5105 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5106 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_5106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5106 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_5106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_5107 : List (BitVec 512) := [w3766,w3831,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_5107 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5107 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5107 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5108 : List (BitVec 512) := [w3766,w3832,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5108 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5108 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5108 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3832,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3832 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5109 : List (BitVec 512) := [w3766,w3833,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5109 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5109 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5109 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3833,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3833 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5110 : List (BitVec 512) := [w3766,w3834,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5110 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5110 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5110 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3834,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3834 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5111 : List (BitVec 512) := [w3766,w3835,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5111 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5111 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5111 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3835,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3835 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5112 : List (BitVec 512) := [w3766,w3836,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5112 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5112 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5112 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3836,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3836 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5113 : List (BitVec 512) := [w3766,w3837,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5113 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5113 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5113 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3837,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3837 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5114 : List (BitVec 512) := [w3766,w3838,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5114 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5114 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5114 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3838,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3838 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5115 : List (BitVec 512) := [w3766,w3839,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5115 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5115 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5115 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3839,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3839 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5116 : List (BitVec 512) := [w3766,w3840,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5116 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5116 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5116 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3840,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3840 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5117 : List (BitVec 512) := [w3766,w3841,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5117 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5117 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_5117 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3841,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3841 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5118 : List (BitVec 512) := [w3766,w3845,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6785]
theorem b5_5118 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5118 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(7,true),(10,true))] s5_5118 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6522,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5119 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_5119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5119 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_5119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_5120 : List (BitVec 512) := [w3766,w3846,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_5120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5120 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true)),(false,(7,true),(10,true))] s5_5120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5121 : List (BitVec 512) := [w3766,w3846,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_5121 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5121 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5121 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5122 : List (BitVec 512) := [w3766,w3846,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_5122 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5122 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5122 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5123 : List (BitVec 512) := [w3766,w3846,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_5123 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5123 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5123 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3846,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3846 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5124 : List (BitVec 512) := [w3766,w3847,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_5124 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5124 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(7,true),(10,true))] s5_5124 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3847,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3847 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5125 : List (BitVec 512) := [w3766,w3848,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5125 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5125 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false)),(false,(0,true),(10,true))] s5_5125 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3848,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3848 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5126 : List (BitVec 512) := [w3766,w3849,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5126 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5126 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5126 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3849,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3849 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5127 : List (BitVec 512) := [w3766,w3850,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5127 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3850,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3850 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5128 : List (BitVec 512) := [w3766,w3851,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5128 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3851,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3851 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5129 : List (BitVec 512) := [w3766,w3852,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5129 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3852,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3852 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5130 : List (BitVec 512) := [w3766,w3853,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5130 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5130 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5130 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3853,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3853 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5131 : List (BitVec 512) := [w3766,w3854,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5131 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5131 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5131 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3854,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3854 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5132 : List (BitVec 512) := [w3766,w3855,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5132 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3855,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3855 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5133 : List (BitVec 512) := [w3766,w3856,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5133 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5133 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_5133 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3856,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3856 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5134 : List (BitVec 512) := [w3766,w3857,w4344,w4716,w5187,w5393,w5585,w5956,w6522,w6588]
theorem b5_5134 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5134 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(5,true))] s5_5134 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5135 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_5135 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5135 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(6,true),(2,true)),(false,(10,true),(1,true))] s5_5135 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5136 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_5136 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5136 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,false),(7,true)),(false,(2,true),(7,true)),(false,(10,true),(1,true))] s5_5136 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5137 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_5137 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5137 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true)),(false,(3,true),(7,true))] s5_5137 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5138 : List (BitVec 512) := [w3766,w3857,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b5_5138 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5138 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_5138 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5139 : List (BitVec 512) := [w3766,w3857,w4716,w5187,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_5139 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5139 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true)),(false,(1,true),(5,true))] s5_5139 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3857,v0_4716,v0_5187,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5140 : List (BitVec 512) := [w3766,w3858,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_5140 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5140 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(2,true)),(false,(4,true),(7,true))] s5_5140 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3858,v0_4344,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3858 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5141 : List (BitVec 512) := [w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_5141 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5141 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_5141 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_5142 : List (BitVec 512) := [w3766,w3861,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_5142 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5142 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5142 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3861,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5143 : List (BitVec 512) := [w3766,w3863,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5143 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5143 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(2,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_5143 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3863,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3863 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5144 : List (BitVec 512) := [w3766,w3864,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_5144 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5144 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true)),(false,(8,true),(7,true))] s5_5144 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3864,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3864 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5145 : List (BitVec 512) := [w3766,w3865,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_5145 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5145 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_5145 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3865,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3865 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_5146 : List (BitVec 512) := [w3766,w3867,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5146 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5146 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_5146 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3867,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3867 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5147 : List (BitVec 512) := [w3766,w3868,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_5147 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5147 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(7,true),(10,true))] s5_5147 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3868,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3868 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_5148 : List (BitVec 512) := [w3766,w3869,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5148 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5148 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(6,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_5148 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3869,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3869 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5149 : List (BitVec 512) := [w3766,w3870,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5149 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5149 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false)),(false,(0,true),(10,true))] s5_5149 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3870,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3870 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5150 : List (BitVec 512) := [w3766,w3884,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5150 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5150 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(2,true)),(false,(0,false),(7,true))] s5_5150 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3884,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3884 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5151 : List (BitVec 512) := [w3766,w3887,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5151 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5151 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_5151 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3887,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3887 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5152 : List (BitVec 512) := [w3766,w3888,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5152 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5152 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_5152 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3888,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3888 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5153 : List (BitVec 512) := [w3766,w3889,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5153 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5153 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_5153 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3889,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3889 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5154 : List (BitVec 512) := [w3766,w3891,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5154 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5154 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5154 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3891,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3891 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5155 : List (BitVec 512) := [w3766,w3892,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5155 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5155 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5155 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3892,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3892 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5156 : List (BitVec 512) := [w3766,w3893,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5156 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5156 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5156 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3893,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3893 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5157 : List (BitVec 512) := [w3766,w3894,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5157 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5157 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5157 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3894,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3894 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5158 : List (BitVec 512) := [w3766,w3895,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5158 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5158 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5158 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3895,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3895 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5159 : List (BitVec 512) := [w3766,w3897,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5159 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5159 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5159 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3897,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3897 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5160 : List (BitVec 512) := [w3766,w3898,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5160 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5160 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5160 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3898,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3898 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5161 : List (BitVec 512) := [w3766,w3899,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5161 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5161 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true))] s5_5161 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3899,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3899 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5162 : List (BitVec 512) := [w3766,w3903,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5162 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5162 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5162 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3903,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3903 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
