import NinePin302
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_16978 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16978 := by
  intro m le c
  apply rejects_sound r302 i5 4 tgt (small302 adj) hot302 [] s4_16978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v302_3766,v302_4344,v302_4716,v302_4918,v302_5135,v302_5393,v302_5585,v302_5956,v302_6300,v302_6567,v302_6588] (PetersenWireProjection.cons pc302_3766 (PetersenWireProjection.cons pc302_4344 (PetersenWireProjection.cons pc302_4716 (PetersenWireProjection.cons pc302_4918 (PetersenWireProjection.cons pc302_5135 (PetersenWireProjection.cons pc302_5393 (PetersenWireProjection.cons pc302_5585 (PetersenWireProjection.cons pc302_5956 (PetersenWireProjection.cons pc302_6300 (PetersenWireProjection.cons pc302_6567 (PetersenWireProjection.cons pc302_6588 rfl))))))))))) (by decide +kernel)
end NineCert
