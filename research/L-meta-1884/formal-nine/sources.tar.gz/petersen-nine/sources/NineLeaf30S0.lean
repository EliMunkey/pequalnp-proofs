import NinePin30
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s2_107 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b2_107 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_107 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s2_107 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_533 : List (BitVec 512) := [w632,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_533 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_533 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_533 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_534 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_534 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_534 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_534 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_535 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6720]
theorem b3_535 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_535 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s3_535 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6720 rfl)))))))))))) (by decide +kernel)
def s3_536 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_536 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_536 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_536 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s3_2354 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2354 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2354 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2354 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_4747,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_4747 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2381 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5620,w5956,w6300,w6588]
theorem b3_2381 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2381 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2381 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5620,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5620 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2384 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_2384 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2384 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(2,true))] s3_2384 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5769,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5769 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2392 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b3_2392 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2392 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2392 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6136,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6136 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2393 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b3_2393 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2393 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2393 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2394 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6588]
theorem b3_2394 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2394 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(2,true))] s3_2394 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6422,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6422 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2395 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b3_2395 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2395 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(0,true))] s3_2395 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6464,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6464 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2396 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b3_2396 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2396 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2396 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6543,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6588 rfl)))))))))))) (by decide +kernel)
def s3_2402 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6852]
theorem b3_2402 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2402 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2402 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s3_2404 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_2404 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2404 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2404 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6136,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6136 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2408 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_2408 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2408 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2408 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2411 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6333,w6588]
theorem b3_2411 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2411 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2411 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6333,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6333 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2419 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_2419 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2419 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2419 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6543,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2433 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6852]
theorem b3_2433 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2433 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2433 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6690,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s3_2435 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6832,w6852]
theorem b3_2435 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2435 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2435 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6832,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6832 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s3_2436 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b3_2436 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2436 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2436 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s3_2437 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b3_2437 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2437 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2437 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s3_2439 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b3_2439 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2439 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s3_2439 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_2930 : List (BitVec 512) := [w632,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_2930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2930 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s4_2930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2681,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2681 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_2943 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_2943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2943 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_2943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_2945 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_2945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2945 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(1,true))] s4_2945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6464,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6464 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_2947 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2947 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s4_2947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6720 rfl))))))))))) (by decide +kernel)
def s4_2952 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_2952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2952 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s4_2952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588,v30_6859] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6859 rfl))))))))))) (by decide +kernel)
def s4_2953 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6644]
theorem b4_2953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2953 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_2953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6644] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6644 rfl)))))))))) (by decide +kernel)
def s4_2954 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6644,w6720]
theorem b4_2954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2954 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s4_2954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6644,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6644 (PetersenWireProjection.cons pc30_6720 rfl))))))))))) (by decide +kernel)
def s4_2955 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_2955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2955 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_2955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_2957 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6852]
theorem b4_2957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2957 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_2957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6690,v30_6852] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_2960 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5149,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2960 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s4_2960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_4716,v30_5149,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5149 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6720 rfl))))))))))) (by decide +kernel)
def s4_2961 : List (BitVec 512) := [w632,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_2961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2961 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_2961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_2962 : List (BitVec 512) := [w632,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_2962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2962 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s4_2962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_4344,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6588,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6720 rfl))))))))))) (by decide +kernel)
def s4_7543 : List (BitVec 512) := [w1305,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7543 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_7543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1305,v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1305 (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_7544 : List (BitVec 512) := [w1305,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_7544 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7544 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(0,true))] s4_7544 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1305,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5769,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1305 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5769 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_7545 : List (BitVec 512) := [w1305,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_7545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7545 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_7545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1305,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1305 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_7546 : List (BitVec 512) := [w1305,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7546 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_7546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1305,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1305 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_8483 : List (BitVec 512) := [w1351,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8483 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1351,v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1351 (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8484 : List (BitVec 512) := [w1351,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_8484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8484 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1351,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1351 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8485 : List (BitVec 512) := [w1351,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8485 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1351,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1351 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_8494 : List (BitVec 512) := [w1353,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6852]
theorem b4_8494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8494 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1908,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1908 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s4_8496 : List (BitVec 512) := [w1353,w1908,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b4_8496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8496 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1908,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1908 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_8504 : List (BitVec 512) := [w1353,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_8504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8504 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_8504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8505 : List (BitVec 512) := [w1353,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_8505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8505 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_8505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6543,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8506 : List (BitVec 512) := [w1353,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_8506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8506 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_8506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_8515 : List (BitVec 512) := [w1353,w2838,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8515 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,false),(2,true))] s4_8515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2838,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2838 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8517 : List (BitVec 512) := [w1353,w2861,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8517 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,false),(2,true))] s4_8517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2861,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2861 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8518 : List (BitVec 512) := [w1353,w3123,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_8518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8518 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3123,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3123 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8521 : List (BitVec 512) := [w1353,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_8521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8521 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(5,true),(0,false))] s4_8521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3293,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3293 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8522 : List (BitVec 512) := [w1353,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_8522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8522 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(5,true),(0,false))] s4_8522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3293,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3293 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8523 : List (BitVec 512) := [w1353,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8523 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(5,true),(0,false))] s4_8523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3293,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3293 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_8550 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5759,w5956,w6300,w6588]
theorem b4_8550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8550 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(0,true))] s4_8550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5759,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5759 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8554 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6852]
theorem b4_8554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8554 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(0,true))] s4_8554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5769,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5769 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8555 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5775,w5956,w6300,w6588]
theorem b4_8555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8555 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(0,true))] s4_8555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5775,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5775 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8564 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6852]
theorem b4_8564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8564 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6136,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6136 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8566 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6852]
theorem b4_8566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8566 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6201,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8568 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_8568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8568 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(2,true))] s4_8568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6237,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6237 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8570 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6420,w6588]
theorem b4_8570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8570 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(1,true))] s4_8570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6420,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6420 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8574 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6852]
theorem b4_8574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8574 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(1,true))] s4_8574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6422,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6422 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8575 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6424,w6588]
theorem b4_8575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8575 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(1,true))] s4_8575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6424,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6424 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8581 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6458,w6588]
theorem b4_8581 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8581 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(1,true))] s4_8581 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6458,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6458 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8585 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6852]
theorem b4_8585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8585 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(1,true))] s4_8585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6464,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6464 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
end NineCert
