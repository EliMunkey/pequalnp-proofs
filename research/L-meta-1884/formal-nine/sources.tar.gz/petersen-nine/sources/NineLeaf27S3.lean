import NinePin27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_16972 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_16972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16972 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s4_16972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4917,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6785] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6785 rfl))))))))))) (by decide +kernel)
def s4_16974 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16974 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4918,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16975 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16975 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_16975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4918,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16976 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_16976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16976 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(0,true))] s4_16976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4918,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16977 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16977 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_16977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4918,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16979 : List (BitVec 512) := [w3766,w4344,w4716,w4918,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16979 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4918,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_16980 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_16980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16980 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16981 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16981 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_16981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16982 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_16982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16982 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s4_16982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6821] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6821 rfl))))))))))) (by decide +kernel)
def s4_16984 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16984 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4923,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4923 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16985 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16985 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_16985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4923,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4923 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16986 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16986 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4923,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4923 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_16987 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_16987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16987 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(0,true))] s4_16987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4923,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6785] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4923 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6785 rfl))))))))))) (by decide +kernel)
def s4_16988 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_16988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16988 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_16988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4923,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4923 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_17009 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_17009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17009 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_17009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6237,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6237 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_17013 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_17013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17013 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_17013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6499,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6499 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_17017 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_17017 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17017 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true))] s4_17017 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6553,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6553 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_17028 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_17028 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17028 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s4_17028 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6821] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6821 rfl))))))))))) (by decide +kernel)
def s5_25 : List (BitVec 512) := [w6,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_25 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_25 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_25 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_6,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_6 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_77 : List (BitVec 512) := [w24,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_77 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_77 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_77 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_2468,v27_3766,v27_4344,v27_4716,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_297 : List (BitVec 512) := [w159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_297 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_159,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_159 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_301 : List (BitVec 512) := [w160,w2668,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6599]
theorem b5_301 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_301 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_301 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_2668,v27_3766,v27_4344,v27_4716,v27_5393,v27_5585,v27_5956,v27_6300,v27_6599] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_2668 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6599 rfl)))))))))) (by decide +kernel)
def s5_304 : List (BitVec 512) := [w160,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_304 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_304 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s5_304 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3280,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_307 : List (BitVec 512) := [w160,w3932,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_307 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_307 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true)),(false,(0,false),(6,true))] s5_307 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3932,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3932 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_558 : List (BitVec 512) := [w332,w1910,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_558 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_558 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s5_558 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_1910,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_6061,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_1910 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s5_563 : List (BitVec 512) := [w332,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_563 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_563 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s5_563 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3280,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1858 : List (BitVec 512) := [w1089,w3766,w4716,w4782,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_1858 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1858 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s5_1858 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1089,v27_3766,v27_4716,v27_4782,v27_5135,v27_5393,v27_5585,v27_6061,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1089 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4782 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s5_1891 : List (BitVec 512) := [w1109,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1891 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1891 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1891 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1109,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1109 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1893 : List (BitVec 512) := [w1111,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1893 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1893 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1893 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1111,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1111 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1896 : List (BitVec 512) := [w1117,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1896 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1896 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s5_1896 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1117,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_6101,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1117 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1897 : List (BitVec 512) := [w1118,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1897 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1897 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1897 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1118,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1118 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1900 : List (BitVec 512) := [w1119,w1883,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1900 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1900 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(2,true))] s5_1900 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1883,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1883 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1902 : List (BitVec 512) := [w1119,w1910,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6748]
theorem b5_1902 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1902 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(2,true))] s5_1902 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_1910,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_6101,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_1910 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1908 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6748]
theorem b5_1908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1908 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_1908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2468,v27_3766,v27_4344,v27_4716,v27_5135,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1913 : List (BitVec 512) := [w1119,w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1913 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_1913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2492,v27_3766,v27_4344,v27_4716,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2492 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1919 : List (BitVec 512) := [w1119,w2681,w2878,w3766,w4344,w5393,w5585,w5956,w6300,w6748]
theorem b5_1919 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1919 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_1919 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2681,v27_2878,v27_3766,v27_4344,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2681 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1921 : List (BitVec 512) := [w1119,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6748]
theorem b5_1921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1921 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_1921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2681,v27_3766,v27_4344,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2681 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1922 : List (BitVec 512) := [w1119,w2683,w2878,w3766,w4344,w4926,w5393,w5585,w5956,w6300]
theorem b5_1922 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1922 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_1922 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_2878,v27_3766,v27_4344,v27_4926,v27_5393,v27_5585,v27_5956,v27_6300] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 rfl)))))))))) (by decide +kernel)
def s5_1924 : List (BitVec 512) := [w1119,w2683,w2878,w3766,w4344,w5393,w5585,w5956,w6300,w6748]
theorem b5_1924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1924 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_1924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_2878,v27_3766,v27_4344,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1926 : List (BitVec 512) := [w1119,w2683,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6748]
theorem b5_1926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1926 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(6,true),(1,false))] s5_1926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2683,v27_3766,v27_4344,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2683 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1928 : List (BitVec 512) := [w1119,w2878,w3766,w4926,w5135,w5393,w5585,w5956,w6300,w6389]
theorem b5_1928 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1928 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1928 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2878,v27_3766,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6389] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2878 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 rfl)))))))))) (by decide +kernel)
def s5_1930 : List (BitVec 512) := [w1119,w2880,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1930 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s5_1930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2880,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2880 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1932 : List (BitVec 512) := [w1119,w2886,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1932 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1932 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s5_1932 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_2886,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_2886 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1935 : List (BitVec 512) := [w1119,w3177,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1935 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1935 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s5_1935 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3177,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3177 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1937 : List (BitVec 512) := [w1119,w3179,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1937 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1937 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(1,true))] s5_1937 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3179,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3179 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1940 : List (BitVec 512) := [w1119,w3183,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1940 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1940 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(1,true))] s5_1940 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3183,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3183 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1942 : List (BitVec 512) := [w1119,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1942 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1942 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s5_1942 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3280,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1943 : List (BitVec 512) := [w1119,w3280,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b5_1943 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1943 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(5,true),(0,false))] s5_1943 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3280,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3280 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1945 : List (BitVec 512) := [w1119,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1945 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1945 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true)),(false,(6,true),(0,true))] s5_1945 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3321,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3321 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1947 : List (BitVec 512) := [w1119,w3323,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_1947 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1947 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(0,true)),(false,(6,true),(0,true))] s5_1947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3323,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3323 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1953 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6748]
theorem b5_1953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1953 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(4,true)),(false,(0,true),(4,true))] s5_1953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5470,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5470 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1954 : List (BitVec 512) := [w1119,w3766,w4344,w4803,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1954 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s5_1954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4803,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4803 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1961 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6748]
theorem b5_1961 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1961 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s5_1961 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_6101,v27_6300,v27_6522,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_1967 : List (BitVec 512) := [w1119,w3766,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1967 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1967 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s5_1967 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4589,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4589 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1968 : List (BitVec 512) := [w1119,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_1968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1968 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s5_1968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4926,v27_5135,v27_5393,v27_5585,v27_6101,v27_6389,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_1971 : List (BitVec 512) := [w1119,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b5_1971 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1971 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1971 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_5135,v27_5393,v27_5585,v27_6061,v27_6101,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl))))))))) (by decide +kernel)
def s5_1972 : List (BitVec 512) := [w1119,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6748]
theorem b5_1972 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1972 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_1972 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_5135,v27_5393,v27_5585,v27_6061,v27_6101,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s5_3343 : List (BitVec 512) := [w1719,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3343 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3343 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_3343 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1719,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1719 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_4098 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4918,w5135,w5585,w5956,w6300,w6588]
theorem b5_4098 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4098 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_4098 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_2468,v27_3766,v27_4344,v27_4716,v27_4918,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4918 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_4099 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4921,w5135,w5585,w5956,w6300,w6588]
theorem b5_4099 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4099 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_4099 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_2468,v27_3766,v27_4344,v27_4716,v27_4921,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5306 : List (BitVec 512) := [w3766,w4136,w4344,w5135,w5393,w5769,w5956,w6300,w6588,w6720]
theorem b5_5306 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5306 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5306 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4136,v27_4344,v27_5135,v27_5393,v27_5769,v27_5956,v27_6300,v27_6588,v27_6720] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4136 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5769 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s5_5312 : List (BitVec 512) := [w3766,w4141,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_5312 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5312 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5312 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4141,v27_4716,v27_5135,v27_5393,v27_5698,v27_5769,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4141 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5698 (PetersenWireProjection.cons pc27_5769 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5333 : List (BitVec 512) := [w3766,w4173,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_5333 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5333 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5333 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4173,v27_4716,v27_5135,v27_5393,v27_5585,v27_6061,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4173 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s5_5395 : List (BitVec 512) := [w3766,w4248,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b5_5395 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5395 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s5_5395 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4248,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6389,v27_6422,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4248 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6422 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
end NineCert
