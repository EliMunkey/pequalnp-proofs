import NinePin222
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4922 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6389,w6588]
theorem b3_4922 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4922 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s3_4922 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5769,v222_5956,v222_6225,v222_6300,v222_6389,v222_6588] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5769 (PetersenWireProjection.cons pc222_5956 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6389 (PetersenWireProjection.cons pc222_6588 rfl)))))))))))) (by decide +kernel)
def s3_4931 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6499,w6588]
theorem b3_4931 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4931 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s3_4931 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5769,v222_5956,v222_6300,v222_6389,v222_6499,v222_6588] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5769 (PetersenWireProjection.cons pc222_5956 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6389 (PetersenWireProjection.cons pc222_6499 (PetersenWireProjection.cons pc222_6588 rfl)))))))))))) (by decide +kernel)
def s4_3087 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_3087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3087 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s4_3087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_635,v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5956,v222_6300,v222_6389,v222_6588] (PetersenWireProjection.cons pc222_635 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5956 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6389 (PetersenWireProjection.cons pc222_6588 rfl))))))))))) (by decide +kernel)
def s4_9855 : List (BitVec 512) := [w1403,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9855 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s4_9855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_2837,v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5956,v222_6300,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_2837 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5956 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6588 rfl))))))))))) (by decide +kernel)
def s4_10095 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_10095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10095 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s4_10095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5956,v222_6225,v222_6300,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5956 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6588 rfl))))))))))) (by decide +kernel)
def s4_17394 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6225,w6389,w6522,w6588]
theorem b4_17394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17394 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s4_17394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_5769,v222_6225,v222_6389,v222_6522,v222_6588] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_5769 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6389 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 rfl))))))))))) (by decide +kernel)
def s5_3127 : List (BitVec 512) := [w1403,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_3127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3127 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s5_3127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_2837,v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_6522,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_2837 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 rfl)))))))))) (by decide +kernel)
def s5_3186 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_3186 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3186 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s5_3186 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_3766,v222_4344,v222_4716,v222_5135,v222_5393,v222_5585,v222_6225,v222_6522,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 rfl)))))))))) (by decide +kernel)
def s5_6262 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5698,w6225,w6300,w6522,w6588,w6720]
theorem b5_6262 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6262 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s5_6262 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_5135,v222_5393,v222_5698,v222_6225,v222_6300,v222_6522,v222_6588,v222_6720] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5698 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6300 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 (PetersenWireProjection.cons pc222_6720 rfl)))))))))) (by decide +kernel)
def s6_25 : List (BitVec 512) := [w1403,w2837,w3766,w4716,w5135,w5393,w5698,w6522,w6588]
theorem b6_25 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_25 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s6_25 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_2837,v222_3766,v222_4716,v222_5135,v222_5393,v222_5698,v222_6522,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_2837 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5698 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 rfl))))))))) (by decide +kernel)
def s6_30 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5698,w6225,w6522,w6588]
theorem b6_30 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_30 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s6_30 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_1403,v222_3766,v222_4716,v222_5135,v222_5393,v222_5698,v222_6225,v222_6522,v222_6588] (PetersenWireProjection.cons pc222_1403 (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4716 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5698 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6588 rfl))))))))) (by decide +kernel)
def s6_95 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6720,w6890]
theorem b6_95 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_95 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s6_95 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_5135,v222_5393,v222_5585,v222_6225,v222_6522,v222_6720,v222_6890] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5585 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6720 (PetersenWireProjection.cons pc222_6890 rfl))))))))) (by decide +kernel)
def s6_96 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5698,w6225,w6522,w6720,w6873]
theorem b6_96 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_96 := by
  intro m le c
  apply rejects_sound r222 i6 5 tgt (small222 adj) hot222 [] s6_96 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v222_3766,v222_4344,v222_5135,v222_5393,v222_5698,v222_6225,v222_6522,v222_6720,v222_6873] (PetersenWireProjection.cons pc222_3766 (PetersenWireProjection.cons pc222_4344 (PetersenWireProjection.cons pc222_5135 (PetersenWireProjection.cons pc222_5393 (PetersenWireProjection.cons pc222_5698 (PetersenWireProjection.cons pc222_6225 (PetersenWireProjection.cons pc222_6522 (PetersenWireProjection.cons pc222_6720 (PetersenWireProjection.cons pc222_6873 rfl))))))))) (by decide +kernel)
end NineCert
