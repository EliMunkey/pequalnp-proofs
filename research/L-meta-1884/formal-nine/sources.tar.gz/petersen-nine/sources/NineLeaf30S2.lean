import NinePin30
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2699 : List (BitVec 512) := [w1353,w3179,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b5_2699 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2699 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s5_2699 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3179,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3179 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2701 : List (BitVec 512) := [w1353,w3186,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b5_2701 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2701 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s5_2701 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3186,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3186 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2703 : List (BitVec 512) := [w1353,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b5_2703 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2703 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(5,true),(0,false))] s5_2703 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3293,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3293 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2704 : List (BitVec 512) := [w1353,w3293,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_2704 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2704 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(5,true),(0,false))] s5_2704 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3293,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3293 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2706 : List (BitVec 512) := [w1353,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b5_2706 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2706 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true)),(false,(6,true),(0,true))] s5_2706 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3321,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3321 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2707 : List (BitVec 512) := [w1353,w3321,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_2707 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2707 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true)),(false,(6,true),(0,true))] s5_2707 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3321,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3321 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2709 : List (BitVec 512) := [w1353,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852]
theorem b5_2709 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2709 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(0,true)),(false,(6,true),(0,true))] s5_2709 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3328,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3328 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2713 : List (BitVec 512) := [w1353,w3766,w4716,w4782,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_2713 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2713 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s5_2713 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_4782,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_4782 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2715 : List (BitVec 512) := [w1353,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6748]
theorem b5_2715 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2715 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s5_2715 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6690,v30_6748] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6748 rfl)))))))))) (by decide +kernel)
def s5_4027 : List (BitVec 512) := [w2468,w3766,w4282,w4344,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_4027 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4027 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_4027 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2468,v30_3766,v30_4282,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_2468 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_4442 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5743,w5956,w6300,w6588]
theorem b5_4442 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4442 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_4442 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5743,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5743 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_4459 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6058,w6300,w6588]
theorem b5_4459 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4459 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_4459 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6058,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6058 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_4460 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6059,w6300,w6588]
theorem b5_4460 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4460 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_4460 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6059,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6059 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_5328 : List (BitVec 512) := [w3766,w4170,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_5328 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5328 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_5328 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4170,v30_4344,v30_5135,v30_5393,v30_5585,v30_6101,v30_6300,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4170 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_5428 : List (BitVec 512) := [w3766,w4282,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_5428 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5428 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_5428 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4282,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6101,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_5429 : List (BitVec 512) := [w3766,w4282,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b5_5429 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5429 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_5429 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4282,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6179,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6179 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_5430 : List (BitVec 512) := [w3766,w4282,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_5430 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5430 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_5430 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4282,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6389,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6389 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s6_14 : List (BitVec 512) := [w632,w2681,w3766,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b6_14 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_14 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s6_14 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2681,v30_3766,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2681 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl))))))))) (by decide +kernel)
end NineCert
