import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1816 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b5_1816 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1816 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s5_1816 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1817 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b5_1817 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1817 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true))] s5_1817 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1818 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6543,w6720]
theorem b5_1818 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1818 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true))] s5_1818 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6543,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1819 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_1819 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1819 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(4,true),(8,true))] s5_1819 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1820 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6389,w6522,w6720]
theorem b5_1820 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1820 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(4,true),(8,true))] s5_1820 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6389,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1821 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588,w6604]
theorem b5_1821 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1821 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(8,true),(4,true)),(false,(1,true),(6,true))] s5_1821 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588,v4_6604] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6604 rfl)))))))))) (by decide +kernel)
def s5_1822 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588,w6890]
theorem b5_1822 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1822 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,false),(5,true)),(false,(5,true),(9,true))] s5_1822 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl)))))))))) (by decide +kernel)
def s5_1823 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b5_1823 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1823 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s5_1823 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1824 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6720]
theorem b5_1824 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1824 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s5_1824 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1825 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6225,w6389,w6522,w6588]
theorem b5_1825 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1825 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(7,true)),(false,(9,true),(5,true))] s5_1825 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1826 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6588,w6873]
theorem b5_1826 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1826 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_1826 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_1827 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5698,w6225,w6300,w6522,w6588]
theorem b5_1827 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1827 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(3,true)),(false,(9,true),(8,true))] s5_1827 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1828 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588,w6601]
theorem b5_1828 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1828 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(7,true),(4,true)),(false,(1,true),(6,true))] s5_1828 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588,v4_6601] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6601 rfl)))))))))) (by decide +kernel)
def s5_1829 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5470,w5585,w5769,w5956,w6300,w6588]
theorem b5_1829 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1829 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s5_1829 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5470,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5470 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1830 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b5_1830 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1830 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s5_1830 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1831 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5471,w5585,w5769,w5956,w6300,w6720]
theorem b5_1831 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1831 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s5_1831 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1832 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5471,w5698,w5769,w5956,w6300,w6588]
theorem b5_1832 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1832 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true)),(false,(1,true),(7,true))] s5_1832 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5471,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1833 : List (BitVec 512) := [w1076,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_1833 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1833 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(8,true)),(false,(8,true),(9,true)),(false,(5,true),(6,true))] s5_1833 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4716,v4_5135,v4_5393,v4_5698,v4_6179,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1834 : List (BitVec 512) := [w1076,w3766,w5135,w5393,w5585,w5698,w6101,w6389,w6522,w6588]
theorem b5_1834 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1834 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s5_1834 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_5135,v4_5393,v4_5585,v4_5698,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1842 : List (BitVec 512) := [w1082,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1842 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1842 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_1842 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1082,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1082 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1848 : List (BitVec 512) := [w1085,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1848 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1848 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_1848 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1085,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1085 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1849 : List (BitVec 512) := [w1085,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1849 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1849 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_1849 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1085,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1085 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1863 : List (BitVec 512) := [w1092,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1863 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1863 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true)),(false,(0,false),(6,true))] s5_1863 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1092,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1092 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1883 : List (BitVec 512) := [w1101,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_1883 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1883 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(0,false),(6,true))] s5_1883 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1101,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1101 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1907 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_1907 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1907 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(8,true),(4,true)),(false,(7,true),(0,true))] s5_1907 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1958 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6088,w6101,w6300,w6588]
theorem b5_1958 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1958 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s5_1958 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6088,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_2146 : List (BitVec 512) := [w1231,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6785]
theorem b5_2146 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2146 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true)),(false,(2,true),(1,true))] s5_2146 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_2686,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2153 : List (BitVec 512) := [w1231,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2153 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2153 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_2153 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3197,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3197 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_2156 : List (BitVec 512) := [w1231,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2156 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2156 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_2156 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_2194 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_2194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2194 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2228 : List (BitVec 512) := [w1237,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2228 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2228 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2228 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1237,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1237 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2237 : List (BitVec 512) := [w1240,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2237 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2237 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2237 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1240,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1240 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2297 : List (BitVec 512) := [w1275,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2297 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1275,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1275 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2387 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_2387 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2387 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_2387 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6807] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6807 rfl)))))))))) (by decide +kernel)
def s5_2388 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6300,w6588]
theorem b5_2388 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2388 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s5_2388 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_2406 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2406 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2406 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2406 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6690] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 rfl)))))))))) (by decide +kernel)
def s5_2425 : List (BitVec 512) := [w1307,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_2425 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2425 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2425 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1307,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1307 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2451 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_2451 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2451 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(8,true),(4,true)),(false,(7,true),(0,true))] s5_2451 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2484 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4704,w5393,w5585,w5956,w6300,w6785]
theorem b5_2484 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2484 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true)),(false,(2,true),(1,true))] s5_2484 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2686,v4_3766,v4_4344,v4_4704,v4_5393,v4_5585,v4_5956,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2491 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5613,w5956,w6300,w6785]
theorem b5_2491 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2491 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true)),(false,(2,true),(1,true))] s5_2491 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2686,v4_3766,v4_4344,v4_4716,v4_5393,v4_5613,v4_5956,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2497 : List (BitVec 512) := [w1312,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2497 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2497 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_2497 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3197,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3197 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2503 : List (BitVec 512) := [w1312,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2503 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2503 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_2503 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2515 : List (BitVec 512) := [w1312,w3766,w4344,w4704,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b5_2515 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2515 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2515 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4704,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2524 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5956,w6181,w6300,w6785]
theorem b5_2524 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2524 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2524 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5956,v4_6181,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6181 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_2602 : List (BitVec 512) := [w1328,w2880,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2602 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2602 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_2602 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_2880,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_2880 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_2614 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2614 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2614 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_2614 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2622 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2622 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2622 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_2622 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2634 : List (BitVec 512) := [w1328,w3766,w4344,w4705,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_2634 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2634 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_2634 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4705,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6807] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4705 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6807 rfl)))))))))) (by decide +kernel)
def s5_2647 : List (BitVec 512) := [w1328,w3766,w4344,w4746,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2647 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2647 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s5_2647 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2665 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5703,w5956,w6300,w6690]
theorem b5_2665 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2665 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2665 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5703,v4_5956,v4_6300,v4_6690] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5703 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 rfl)))))))))) (by decide +kernel)
def s5_2711 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5753,w5956,w6300,w6588]
theorem b5_2711 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2711 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s5_2711 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5753,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5753 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_2750 : List (BitVec 512) := [w1369,w3766,w4344,w4747,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2750 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2750 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s5_2750 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2791 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4684,w5393,w5585,w5956,w6300,w6720]
theorem b5_2791 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2791 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(2,true),(6,false))] s5_2791 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_2681,v4_3766,v4_4344,v4_4684,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2793 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6610]
theorem b5_2793 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2793 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(2,true),(6,false))] s5_2793 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl)))))))))) (by decide +kernel)
def s5_2807 : List (BitVec 512) := [w1374,w2883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2807 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2807 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(6,true))] s5_2807 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_2883,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_2883 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_2814 : List (BitVec 512) := [w1374,w3766,w4344,w4671,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2814 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2814 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s5_2814 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4671,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2815 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2815 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2815 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s5_2815 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2816 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4774,w5135,w5393,w5585,w5956,w6300]
theorem b5_2816 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2816 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,false),(0,false)),(false,(6,true),(1,true))] s5_2816 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_4774,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4774 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_2827 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610]
theorem b5_2827 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2827 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s5_2827 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl)))))))))) (by decide +kernel)
def s5_2916 : List (BitVec 512) := [w1384,w3766,w4344,w4683,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2916 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_2916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4683,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4683 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_2931 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6609]
theorem b5_2931 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2931 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_2931 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6609] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6609 rfl)))))))))) (by decide +kernel)
def s5_3011 : List (BitVec 512) := [w1388,w2883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_3011 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3011 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_3011 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_2883,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_2883 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_3015 : List (BitVec 512) := [w1388,w3766,w4344,w4709,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b5_3015 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3015 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_3015 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4709,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6866] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4709 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6866 rfl)))))))))) (by decide +kernel)
def s5_3032 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6181,w6300,w6832]
theorem b5_3032 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3032 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s5_3032 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6181,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6181 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl)))))))))) (by decide +kernel)
end NineCert
