import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_76 : List (BitVec 512) := [w23,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_76 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_76 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s5_76 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_3935,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_3935 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_131 : List (BitVec 512) := [w36,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_131 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_131 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_131 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_132 : List (BitVec 512) := [w36,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_132 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_133 : List (BitVec 512) := [w36,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_133 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_133 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(4,true)),(false,(0,false),(9,true)),(false,(8,true),(0,true))] s5_133 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2530,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2530 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_134 : List (BitVec 512) := [w36,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_134 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_134 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_134 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2686,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_135 : List (BitVec 512) := [w36,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_135 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_135 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_135 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2696,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2696 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_136 : List (BitVec 512) := [w36,w2698,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_136 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_136 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(5,true)),(false,(2,true),(0,true))] s5_136 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_2698,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_2698 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_137 : List (BitVec 512) := [w36,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_137 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_137 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))] s5_137 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_3303,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_3303 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_138 : List (BitVec 512) := [w36,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_138 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_138 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))] s5_138 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_3321,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_3321 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_139 : List (BitVec 512) := [w36,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_139 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(4,true)),(false,(4,true),(0,false)),(false,(4,true),(0,true))] s5_139 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_36,v4_3332,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_36 (PetersenWireProjection.cons pc4_3332 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_165 : List (BitVec 512) := [w71,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_165 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_165 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_165 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_166 : List (BitVec 512) := [w71,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_166 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_166 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_166 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_167 : List (BitVec 512) := [w71,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_167 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_167 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,false),(3,true)),(false,(9,true),(0,false)),(false,(8,true),(0,true))] s5_167 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2528,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2528 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_168 : List (BitVec 512) := [w71,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b5_168 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_168 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_168 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_169 : List (BitVec 512) := [w71,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_169 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_169 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(1,true),(0,true))] s5_169 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2683,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2683 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_170 : List (BitVec 512) := [w71,w2697,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_170 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_170 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true)),(false,(2,true),(0,true))] s5_170 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2697,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2697 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_171 : List (BitVec 512) := [w71,w2852,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_171 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_171 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s5_171 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2852,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_172 : List (BitVec 512) := [w71,w2852,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_172 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_172 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s5_172 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2852,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_173 : List (BitVec 512) := [w71,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_173 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_173 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s5_173 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2878,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_174 : List (BitVec 512) := [w71,w2886,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_174 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_174 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true))] s5_174 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_2886,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_2886 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_175 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_175 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_175 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_175 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_176 : List (BitVec 512) := [w71,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_176 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_176 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_176 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_195 : List (BitVec 512) := [w92,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_195 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_195 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s5_195 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_92,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_92 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_209 : List (BitVec 512) := [w107,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_209 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_209 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_209 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_107,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_107 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_247 : List (BitVec 512) := [w134,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_247 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_247 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_247 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_134,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_134 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_248 : List (BitVec 512) := [w135,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_248 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_135,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_135 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_250 : List (BitVec 512) := [w138,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_250 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_138,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_138 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_251 : List (BitVec 512) := [w139,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_251 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_251 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_251 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_139,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_139 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_252 : List (BitVec 512) := [w141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_252 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_252 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_252 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_141,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_141 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_253 : List (BitVec 512) := [w142,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_253 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_142,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_142 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_254 : List (BitVec 512) := [w143,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_254 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_254 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s5_254 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_255 : List (BitVec 512) := [w143,w2125,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_255 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_255 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true))] s5_255 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2125,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2125 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_256 : List (BitVec 512) := [w143,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_256 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_257 : List (BitVec 512) := [w143,w2681,w2885,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_257 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_257 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(1,true),(5,false))] s5_257 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2681,v4_2885,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_2885 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_258 : List (BitVec 512) := [w143,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_258 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_258 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_258 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_259 : List (BitVec 512) := [w143,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_259 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_259 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_259 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_260 : List (BitVec 512) := [w143,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_260 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s5_260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2878,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_261 : List (BitVec 512) := [w143,w2885,w3766,w4344,w5135,w5393,w5585,w5956,w6522,w6720]
theorem b5_261 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_261 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(8,true),(4,true))] s5_261 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2885,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2885 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_262 : List (BitVec 512) := [w143,w2886,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_262 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_262 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(3,true))] s5_262 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2886,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2886 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_263 : List (BitVec 512) := [w143,w2889,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_263 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_263 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false))] s5_263 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2889,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_264 : List (BitVec 512) := [w143,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_264 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_264 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s5_264 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_265 : List (BitVec 512) := [w143,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_265 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s5_265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_266 : List (BitVec 512) := [w143,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_266 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_266 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_266 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_267 : List (BitVec 512) := [w143,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_267 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_267 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(3,true),(0,true))] s5_267 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3293,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3293 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_268 : List (BitVec 512) := [w143,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_268 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_268 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(4,true)),(false,(1,false),(0,false)),(false,(4,true),(0,true))] s5_268 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3332,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3332 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_269 : List (BitVec 512) := [w143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_269 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_269 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_269 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_270 : List (BitVec 512) := [w143,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_270 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_270 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(4,true),(8,true)),(false,(8,true),(9,true)),(false,(6,true),(7,true))] s5_270 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_6179,v4_6522,v4_6785,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_271 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5585,w5767,w5956,w6522,w6588]
theorem b5_271 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_271 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_271 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5767,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5767 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_272 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5585,w5956,w6037,w6300,w6720]
theorem b5_272 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_272 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(8,true))] s5_272 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6037,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6037 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_273 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_273 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_273 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s5_273 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_274 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_274 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_274 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s5_274 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_275 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_275 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_275 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(4,true),(5,true))] s5_275 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_276 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5698,w5767,w5956,w6300,w6588]
theorem b5_276 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_276 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(7,false),(0,true)),(false,(8,true),(4,true))] s5_276 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5767,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5767 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_277 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_277 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_277 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s5_277 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_278 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_278 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_278 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s5_278 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_279 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b5_279 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_279 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s5_279 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_280 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588,w6895]
theorem b5_280 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_280 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s5_280 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588,v4_6895] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6895 rfl)))))))))) (by decide +kernel)
def s5_281 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_281 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_281 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(5,true),(4,true))] s5_281 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_282 : List (BitVec 512) := [w143,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6813,w6873]
theorem b5_282 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_282 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(4,true)),(false,(8,true),(5,true))] s5_282 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6813,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6813 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_283 : List (BitVec 512) := [w143,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_283 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_283 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true)),(false,(0,true),(2,true))] s5_283 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3901,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3901 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_284 : List (BitVec 512) := [w143,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_284 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_284 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s5_284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3935,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3935 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_285 : List (BitVec 512) := [w143,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_285 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_285 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(3,true)),(false,(5,true),(9,true)),(false,(1,true),(4,true))] s5_285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_3935,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_3935 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_371 : List (BitVec 512) := [w195,w2825,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_371 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_371 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(9,true),(5,true))] s5_371 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_2825,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_2825 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_372 : List (BitVec 512) := [w195,w2864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522]
theorem b5_372 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_372 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(9,true),(5,true))] s5_372 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_2864,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_2864 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 rfl)))))))))) (by decide +kernel)
end NineCert
