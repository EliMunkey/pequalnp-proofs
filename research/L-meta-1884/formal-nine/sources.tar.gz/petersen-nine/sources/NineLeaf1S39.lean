import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2020 : List (BitVec 512) := [w1170,w1257,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b5_2020 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2020 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1257,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1257 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2021 : List (BitVec 512) := [w1170,w1275,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2021 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2021 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1275,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1275 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2022 : List (BitVec 512) := [w1170,w1279,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2022 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1279,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1279 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2023 : List (BitVec 512) := [w1170,w1374,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b5_2023 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2023 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true)),(false,(7,true),(0,true))] s5_2023 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_2443,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2443 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2024 : List (BitVec 512) := [w1170,w1374,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b5_2024 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2024 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(1,false)),(false,(7,true),(0,true))] s5_2024 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_2494,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2025 : List (BitVec 512) := [w1170,w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2025 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s5_2025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2026 : List (BitVec 512) := [w1170,w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2026 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_2026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1384,v1_3293,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2027 : List (BitVec 512) := [w1170,w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2027 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2027 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(1,false),(0,false)),(false,(0,true),(6,true))] s5_2027 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1390,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1390 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2028 : List (BitVec 512) := [w1170,w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2028 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2028 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_2028 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1423,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1423 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2029 : List (BitVec 512) := [w1170,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2029 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(3,true)),(false,(3,true),(0,true))] s5_2029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2468,v1_3258,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2030 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6611]
theorem b5_2030 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2030 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_2030 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6611] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6611 rfl)))))))))) (by decide +kernel)
def s5_2031 : List (BitVec 512) := [w1170,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_2031 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2031 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true)),(false,(8,true),(9,true))] s5_2031 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4716,v1_5135,v1_5393,v1_5698,v1_6179,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2032 : List (BitVec 512) := [w1170,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_2032 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2032 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true)),(false,(9,true),(5,true))] s5_2032 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4926,v1_5135,v1_5393,v1_5585,v1_6101,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2033 : List (BitVec 512) := [w1171,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2033 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(2,true)),(false,(1,false),(0,true))] s5_2033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1171,v1_2681,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1171 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2034 : List (BitVec 512) := [w1172,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2034 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(2,true)),(false,(1,false),(0,true))] s5_2034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1172,v1_2681,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1172 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2035 : List (BitVec 512) := [w1173,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2035 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2035 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s5_2035 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1173,v1_2681,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1173 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2036 : List (BitVec 512) := [w1175,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2036 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,true))] s5_2036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1175,v1_2681,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1175 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2226 : List (BitVec 512) := [w1237,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_2226 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2226 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2226 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1237,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1237 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2231 : List (BitVec 512) := [w1237,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6588]
theorem b5_2231 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2231 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2231 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1237,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1237 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2266 : List (BitVec 512) := [w1257,w2468,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300]
theorem b5_2266 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2266 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2266 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1257,v1_2468,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1257 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2295 : List (BitVec 512) := [w1275,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_2295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2295 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1275,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1275 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2303 : List (BitVec 512) := [w1279,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_2303 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2303 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_2303 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1279,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1279 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2449 : List (BitVec 512) := [w1312,w2468,w2613,w3766,w4344,w4716,w5135,w5956,w6300,w6588]
theorem b5_2449 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2449 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_2449 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2468,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2454 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5861,w5956,w6300,w6588]
theorem b5_2454 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2454 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_2454 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2461 : List (BitVec 512) := [w1312,w2613,w2686,w3766,w4344,w4716,w5393,w5956,w6300,w6785]
theorem b5_2461 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2461 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s5_2461 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_2686,v1_3766,v1_4344,v1_4716,v1_5393,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_2462 : List (BitVec 512) := [w1312,w2613,w2686,w3766,w4344,w4716,w5393,w5956,w6300,w6813]
theorem b5_2462 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2462 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s5_2462 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_2686,v1_3766,v1_4344,v1_4716,v1_5393,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_2463 : List (BitVec 512) := [w1312,w2613,w3197,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_2463 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2463 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_2463 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3197,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3197 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2464 : List (BitVec 512) := [w1312,w2613,w3280,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_2464 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2464 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false)),(false,(3,true),(0,true))] s5_2464 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2465 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w5135,w5393,w5956,w6101,w6300,w6720]
theorem b5_2465 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2465 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2465 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5956,v1_6101,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2466 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w5135,w5393,w5956,w6225,w6300,w6720]
theorem b5_2466 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2466 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_2466 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2467 : List (BitVec 512) := [w1312,w2615,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2467 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2467 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_2467 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2615,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2469 : List (BitVec 512) := [w1312,w2623,w3766,w4344,w5135,w5393,w5698,w5956,w6300,w6720]
theorem b5_2469 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2469 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_2469 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2623,v1_3766,v1_4344,v1_5135,v1_5393,v1_5698,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2470 : List (BitVec 512) := [w1312,w2636,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_2470 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2470 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2470 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2636,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2471 : List (BitVec 512) := [w1312,w2642,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2471 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2471 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2471 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2642,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2642 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2472 : List (BitVec 512) := [w1312,w2644,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785]
theorem b5_2472 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2472 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2472 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_2473 : List (BitVec 512) := [w1312,w2646,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2473 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2473 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_2473 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2646,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2476 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5098,w5393,w5585,w5769,w5956,w6300]
theorem b5_2476 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2476 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s5_2476 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2681,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2485 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5105,w5393,w5585,w5956,w6300]
theorem b5_2485 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2485 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s5_2485 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5105,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5105 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2486 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300]
theorem b5_2486 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2486 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s5_2486 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2489 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6798]
theorem b5_2489 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2489 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s5_2489 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6798] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6798 rfl)))))))))) (by decide +kernel)
def s5_2500 : List (BitVec 512) := [w1312,w3197,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6588]
theorem b5_2500 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2500 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_2500 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3197,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3197 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2506 : List (BitVec 512) := [w1312,w3280,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6588]
theorem b5_2506 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2506 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false)),(false,(3,true),(0,true))] s5_2506 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2516 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6813]
theorem b5_2516 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2516 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s5_2516 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_2525 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5956,w6241,w6300,w6785]
theorem b5_2525 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2525 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(7,true),(8,true)),(false,(6,true),(1,true))] s5_2525 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6241,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_2532 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_2532 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2532 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s5_2532 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2533 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_2533 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2533 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2533 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2534 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_2534 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2534 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_2534 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2535 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2535 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2535 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_2535 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5393,v1_5698,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2543 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6154,w6300,w6720]
theorem b5_2543 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2543 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2543 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6154,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6154 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2547 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6243,w6300,w6720]
theorem b5_2547 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2547 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_2547 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2549 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w6101,w6147,w6300,w6720]
theorem b5_2549 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2549 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2549 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2556 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5698,w5873,w5956,w6300,w6720]
theorem b5_2556 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2556 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_2556 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5698,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2558 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5769,w5863,w5956,w6300,w6720]
theorem b5_2558 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2558 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_2558 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5863,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2560 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5861,w5956,w6101,w6300,w6720]
theorem b5_2560 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2560 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_2560 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5861,v1_5956,v1_6101,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2561 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5861,w5956,w6225,w6300,w6720]
theorem b5_2561 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2561 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_2561 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5861,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2585 : List (BitVec 512) := [w1328,w2555,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_2585 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2585 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2585 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2555,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6748] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6748 rfl)))))))))) (by decide +kernel)
def s5_2586 : List (BitVec 512) := [w1328,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b5_2586 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2586 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2586 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_2587 : List (BitVec 512) := [w1328,w2613,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2587 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2587 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2587 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2588 : List (BitVec 512) := [w1328,w2615,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2588 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2588 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2588 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2615,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2589 : List (BitVec 512) := [w1328,w2623,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2589 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2623,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2635 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5103,w5393,w5585,w5956,w6300,w6748]
theorem b5_2635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2635 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5103,v1_5393,v1_5585,v1_5956,v1_6300,v1_6748] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5103 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6748 rfl)))))))))) (by decide +kernel)
def s5_2636 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6813]
theorem b5_2636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2636 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_2637 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5108,w5393,w5585,w5956,w6300,w6821]
theorem b5_2637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2637 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s5_2637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5108,v1_5393,v1_5585,v1_5956,v1_6300,v1_6821] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5108 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6821 rfl)))))))))) (by decide +kernel)
def s5_2644 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6813]
theorem b5_2644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2644 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
end NineCert
