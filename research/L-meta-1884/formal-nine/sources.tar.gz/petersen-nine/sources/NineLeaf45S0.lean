import NinePin45
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s2_103 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_103 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_103 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s2_103 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_282 : List (BitVec 512) := [w192,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_282 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_282 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_282 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_283 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_283 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_283 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_283 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_284 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_284 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_284 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(5,true))] s3_284 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588,v45_6873] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6873 rfl)))))))))))) (by decide +kernel)
def s3_285 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_285 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_285 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_285 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_400 : List (BitVec 512) := [w357,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_400 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_400 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_400 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_401 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_401 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_401 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_401 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_402 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6832]
theorem b3_402 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_402 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(5,true))] s3_402 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588,v45_6832] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6832 rfl)))))))))))) (by decide +kernel)
def s3_403 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_403 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_403 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_403 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_528 : List (BitVec 512) := [w628,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_528 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_528 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_528 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_529 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_529 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_529 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_529 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_530 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_530 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_530 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s3_530 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl)))))))))))) (by decide +kernel)
def s3_531 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_531 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_531 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_531 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_1893 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_1893 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1893 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1893 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1894 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1894 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1894 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1894 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_1924 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1924 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1924 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1924 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_4746,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_4746 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1952 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_1952 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1952 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1952 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5848,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1953 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_1953 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1953 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(0,true))] s3_1953 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1954 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_1954 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1954 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1954 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1955 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_1955 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1955 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s3_1955 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1956 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b3_1956 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1956 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1956 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1957 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_1957 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1957 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s3_1957 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_1963 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6807]
theorem b3_1963 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1963 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1963 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s3_1965 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1965 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1965 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1965 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5848,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1971 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b3_1971 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1971 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1971 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_5992,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_5992 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1978 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_1978 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1978 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1978 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1981 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6330,w6588]
theorem b3_1981 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1981 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1981 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6330,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6330 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_1988 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b3_1988 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1988 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_1988 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_2003 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b3_2003 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2003 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2003 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s3_2005 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6807]
theorem b3_2005 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2005 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2005 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6785,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s3_2006 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b3_2006 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2006 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2006 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s3_2007 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_2007 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2007 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2007 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_2008 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b3_2008 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2008 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2008 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_2010 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b3_2010 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2010 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2010 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_2012 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b3_2012 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2012 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_2012 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s3_4800 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5683,w5698,w5956,w6101,w6300,w6588]
theorem b3_4800 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4800 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s3_4800 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5683,v45_5698,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5683 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_4801 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5683,w5698,w5956,w6300,w6588]
theorem b3_4801 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4801 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4801 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5683,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5683 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_4803 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5683,w5956,w6300,w6588]
theorem b3_4803 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4803 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4803 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5683,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5683 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_4804 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5698,w5956,w6300,w6522,w6588]
theorem b3_4804 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4804 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s3_4804 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5698,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_4805 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5698,w5956,w6300,w6588]
theorem b3_4805 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4805 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4805 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s3_4806 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5956,w6300,w6588]
theorem b3_4806 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4806 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4806 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s3_4829 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6201,w6300,w6588]
theorem b3_4829 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4829 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4829 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5848,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_4831 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6478,w6588]
theorem b3_4831 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4831 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4831 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5848,v45_5956,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl)))))))))))) (by decide +kernel)
def s3_4836 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588,w6807]
theorem b3_4836 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4836 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s3_4836 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5848,v45_5956,v45_6300,v45_6588,v45_6807] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6807 rfl)))))))))))) (by decide +kernel)
def s4_445 : List (BitVec 512) := [w28,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_445 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_446 : List (BitVec 512) := [w28,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_446 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_1618,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_1618 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_447 : List (BitVec 512) := [w28,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_447 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_1867,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_1867 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_448 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_448 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_449 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_449 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s4_449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_450 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_450 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_451 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_451 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6832] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6832 rfl))))))))))) (by decide +kernel)
def s4_452 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_452 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6873] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6873 rfl))))))))))) (by decide +kernel)
def s4_1214 : List (BitVec 512) := [w192,w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_1214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1214 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1218 : List (BitVec 512) := [w192,w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588]
theorem b4_1218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1218 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(5,true))] s4_1218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_1415,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6464,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_1415 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6464 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1223 : List (BitVec 512) := [w192,w2171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_1223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1223 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_1223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_2171,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_2171 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1229 : List (BitVec 512) := [w192,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1229 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1230 : List (BitVec 512) := [w192,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1230 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_1231 : List (BitVec 512) := [w192,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1231 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_1231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6873] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6873 rfl))))))))))) (by decide +kernel)
def s4_1241 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_1241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1241 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_1241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1250 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1250 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_1250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6873] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6873 rfl))))))))))) (by decide +kernel)
def s4_1256 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_1256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1256 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(5,true))] s4_1256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6905] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6905 rfl))))))))))) (by decide +kernel)
def s4_1257 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6600]
theorem b4_1257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1257 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6600] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6600 rfl)))))))))) (by decide +kernel)
def s4_1258 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6600,w6873]
theorem b4_1258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1258 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_1258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6600,v45_6873] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6600 (PetersenWireProjection.cons pc45_6873 rfl))))))))))) (by decide +kernel)
def s4_1261 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_1261 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1261 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1261 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6785] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 rfl)))))))))) (by decide +kernel)
end NineCert
