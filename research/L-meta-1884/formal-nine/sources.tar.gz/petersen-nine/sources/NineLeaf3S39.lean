import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4726 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b4_4726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4726 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_4726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4727 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6690]
theorem b4_4727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4727 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_4727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6422,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4728 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b4_4728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4728 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s4_4728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4729 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6690]
theorem b4_4729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4729 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s4_4729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6478,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4730 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6499,w6588]
theorem b4_4730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4730 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(5,true))] s4_4730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6499,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6499 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4731 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b4_4731 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4731 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_4731 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4732 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6690]
theorem b4_4732 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4732 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_4732 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4733 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6549,w6588]
theorem b4_4733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4733 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_4733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4734 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6572,w6588]
theorem b4_4734 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4734 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(7,true))] s4_4734 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6572,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6572 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4735 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_4735 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4735 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_4735 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4736 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6748]
theorem b4_4736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4736 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_4736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_4737 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6821]
theorem b4_4737 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4737 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(8,true))] s4_4737 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6821] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6821 rfl))))))))))) (by decide +kernel)
def s4_4738 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6852]
theorem b4_4738 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4738 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_4738 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_4739 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6857]
theorem b4_4739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4739 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s4_4739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_4740 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6868]
theorem b4_4740 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4740 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,true))] s4_4740 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6868] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6868 rfl))))))))))) (by decide +kernel)
def s4_4741 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b4_4741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4741 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_4741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_4742 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6895]
theorem b4_4742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4742 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_4742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_4743 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6905]
theorem b4_4743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4743 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(7,true))] s4_4743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6905] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6905 rfl))))))))))) (by decide +kernel)
def s4_4744 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6908]
theorem b4_4744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4744 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s4_4744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_4745 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6748]
theorem b4_4745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4745 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_4745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_4746 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6852]
theorem b4_4746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4746 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_4746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_4747 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6890]
theorem b4_4747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4747 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_4747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_4748 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6522,w6588,w6873]
theorem b4_4748 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4748 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(7,true),(6,true))] s4_4748 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4749 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5698,w6101,w6300,w6522,w6588]
theorem b4_4749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4749 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(6,true),(7,true))] s4_4749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4750 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b4_4750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4750 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4751 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6690]
theorem b4_4751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4751 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4752 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6201,w6300,w6588]
theorem b4_4752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4752 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(5,true),(2,true))] s4_4752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4753 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6478,w6588]
theorem b4_4753 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4753 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(5,true),(7,true))] s4_4753 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4754 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6041,w6300,w6588]
theorem b4_4754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4754 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(6,true))] s4_4754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6041,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6041 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4755 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6042,w6300,w6588]
theorem b4_4755 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4755 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(6,true))] s4_4755 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6042,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6042 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4756 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_4756 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4756 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(6,true))] s4_4756 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6044,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6044 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4757 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588,w6873]
theorem b4_4757 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4757 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(6,true))] s4_4757 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6044,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6044 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4758 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b4_4758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4758 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s4_4758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4759 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6690]
theorem b4_4759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4759 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s4_4759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6136,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4760 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b4_4760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4760 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_4760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4761 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6690]
theorem b4_4761 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4761 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_4761 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4762 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6237,w6300,w6588]
theorem b4_4762 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4762 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(2,true))] s4_4762 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6237,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6237 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4763 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6588]
theorem b4_4763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4763 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_4763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4764 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6690]
theorem b4_4764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4764 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_4764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6422,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4765 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b4_4765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4765 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s4_4765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4766 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6690]
theorem b4_4766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4766 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s4_4766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6464,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4767 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6489,w6588]
theorem b4_4767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4767 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s4_4767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4768 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b4_4768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4768 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_4768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4769 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6690]
theorem b4_4769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4769 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_4769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6543,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4770 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6553,w6588]
theorem b4_4770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4770 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(2,true))] s4_4770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6553,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6553 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4771 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6572,w6588]
theorem b4_4771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4771 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(7,true))] s4_4771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6572,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6572 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4772 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_4772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4772 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_4772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4773 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6748]
theorem b4_4773 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4773 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_4773 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_4774 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6807]
theorem b4_4774 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4774 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_4774 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4775 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6813]
theorem b4_4775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4775 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true))] s4_4775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_4776 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6859]
theorem b4_4776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4776 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(8,true))] s4_4776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6859] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6859 rfl))))))))))) (by decide +kernel)
def s4_4777 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6868]
theorem b4_4777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4777 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(8,true))] s4_4777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6868] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6868 rfl))))))))))) (by decide +kernel)
def s4_4778 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6890]
theorem b4_4778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4778 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_4778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_4779 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6895]
theorem b4_4779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4779 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(2,true))] s4_4779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_4780 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6904]
theorem b4_4780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4780 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(5,true))] s4_4780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
def s4_4781 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6910]
theorem b4_4781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4781 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(8,true))] s4_4781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6910] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6910 rfl))))))))))) (by decide +kernel)
def s4_4782 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6748]
theorem b4_4782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4782 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_4782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_4783 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6807]
theorem b4_4783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4783 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_4783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4784 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6890]
theorem b4_4784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4784 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_4784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_4785 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6464,w6588,w6873]
theorem b4_4785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4785 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(7,true),(5,true))] s4_4785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4786 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6136,w6201,w6300,w6588]
theorem b4_4786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4786 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(6,true),(2,true))] s4_4786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4787 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6543,w6588]
theorem b4_4787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4787 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s4_4787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4788 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b4_4788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4788 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4789 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6690]
theorem b4_4789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4789 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
end NineCert
