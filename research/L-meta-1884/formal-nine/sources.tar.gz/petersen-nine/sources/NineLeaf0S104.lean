import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4971 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_4971 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4971 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true)),(false,(3,true),(9,true))] s5_4971 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4972 : List (BitVec 512) := [w3583,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4972 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4972 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4972 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3583,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3583 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4973 : List (BitVec 512) := [w3583,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4973 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4973 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4973 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3583,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3583 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4974 : List (BitVec 512) := [w3587,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4974 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4974 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4974 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3587,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3587 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4975 : List (BitVec 512) := [w3587,w4344,w4716,w5135,w5393,w5585,w5705,w5956,w6300,w6588]
theorem b5_4975 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true)),(false,(1,true),(0,false))] s5_4975 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3587,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5705,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3587 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5705 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4976 : List (BitVec 512) := [w3587,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4976 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4976 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3587,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3587 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4977 : List (BitVec 512) := [w3588,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4977 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4977 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4977 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3588,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3588 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4978 : List (BitVec 512) := [w3588,w4344,w4716,w5135,w5393,w5585,w5707,w5956,w6300,w6588]
theorem b5_4978 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4978 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(2,true)),(false,(1,true),(0,false))] s5_4978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3588,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5707,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3588 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5707 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4979 : List (BitVec 512) := [w3588,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4979 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4979 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4979 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3588,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3588 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4980 : List (BitVec 512) := [w3589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4980 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4980 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4980 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3589,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3589 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4981 : List (BitVec 512) := [w3589,w4344,w4716,w5135,w5393,w5585,w5708,w5956,w6300,w6588]
theorem b5_4981 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4981 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true)),(false,(1,true),(0,false))] s5_4981 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3589,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5708,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3589 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5708 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4982 : List (BitVec 512) := [w3589,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4982 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4982 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4982 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3589,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3589 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4983 : List (BitVec 512) := [w3595,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_4983 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4983 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s5_4983 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4984 : List (BitVec 512) := [w3595,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_4984 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4984 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_4984 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_4344,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4985 : List (BitVec 512) := [w3595,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_4985 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4985 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(8,true)),(false,(2,true),(9,true)),(false,(7,true),(4,true))] s5_4985 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_4986 : List (BitVec 512) := [w3595,w3766,w5135,w5393,w5698,w5769,w5956,w6389,w6422,w6588]
theorem b5_4986 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4986 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(5,true),(1,true)),(false,(8,true),(2,true)),(false,(7,true),(4,true))] s5_4986 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3595,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4987 : List (BitVec 512) := [w3596,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4987 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4987 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4987 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3596,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3596 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4988 : List (BitVec 512) := [w3597,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4988 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4988 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4988 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3597,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3597 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4989 : List (BitVec 512) := [w3601,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4989 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4989 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3601,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3601 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4990 : List (BitVec 512) := [w3602,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4990 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4990 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4990 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3602,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3602 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4991 : List (BitVec 512) := [w3603,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4991 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4991 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4991 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3603,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3603 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4992 : List (BitVec 512) := [w3604,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4992 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4992 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4992 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3604,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3604 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4993 : List (BitVec 512) := [w3607,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4993 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4993 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4993 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3607,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3607 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4994 : List (BitVec 512) := [w3608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4994 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4994 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4994 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3608,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3608 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4995 : List (BitVec 512) := [w3609,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4995 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4995 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4995 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3609,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3609 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4996 : List (BitVec 512) := [w3611,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4996 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4996 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4996 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3611,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3611 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4997 : List (BitVec 512) := [w3611,w4344,w4716,w5135,w5393,w5585,w5794,w5956,w6300,w6588]
theorem b5_4997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4997 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(6,true),(3,true)),(false,(1,true),(0,false))] s5_4997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3611,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5794,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3611 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5794 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4998 : List (BitVec 512) := [w3611,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4998 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3611,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3611 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4999 : List (BitVec 512) := [w3612,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4999 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4999 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3612,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3612 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5000 : List (BitVec 512) := [w3612,w4344,w4716,w5135,w5393,w5585,w5796,w5956,w6300,w6588]
theorem b5_5000 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5000 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(6,true)),(false,(6,true),(3,true)),(false,(1,true),(0,false))] s5_5000 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3612,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5796,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3612 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5796 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5001 : List (BitVec 512) := [w3612,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5001 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5001 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5001 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3612,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3612 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5002 : List (BitVec 512) := [w3613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5002 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5002 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5002 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3613,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3613 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5003 : List (BitVec 512) := [w3615,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5003 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5003 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5003 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3615,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3615 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5004 : List (BitVec 512) := [w3616,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5004 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5004 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5004 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3616,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3616 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5005 : List (BitVec 512) := [w3617,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5005 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5005 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5005 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3617,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3617 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5006 : List (BitVec 512) := [w3618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5006 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5006 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5006 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3618,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3618 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5007 : List (BitVec 512) := [w3619,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_5007 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5007 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_5007 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_3766,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5008 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b5_5008 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5008 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s5_5008 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5009 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b5_5009 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5009 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s5_5009 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6618] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6618 rfl)))))))))) (by decide +kernel)
def s5_5010 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b5_5010 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5010 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true))] s5_5010 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_5011 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b5_5011 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5011 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(6,true))] s5_5011 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl)))))))))) (by decide +kernel)
def s5_5012 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b5_5012 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5012 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(7,true),(6,true))] s5_5012 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_5013 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5471,w5585,w5848,w5956,w6300,w6588]
theorem b5_5013 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5013 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(2,true),(1,false)),(false,(1,true),(6,true))] s5_5013 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5014 : List (BitVec 512) := [w3619,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_5014 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5014 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_5014 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5015 : List (BitVec 512) := [w3619,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b5_5015 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5015 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(8,true),(2,true))] s5_5015 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5016 : List (BitVec 512) := [w3619,w4716,w5135,w5393,w5585,w5848,w5956,w6389,w6522,w6588]
theorem b5_5016 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5016 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true)),(false,(1,false),(6,true)),(false,(9,true),(3,true))] s5_5016 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5017 : List (BitVec 512) := [w3619,w5135,w5393,w5585,w5769,w5848,w5956,w6389,w6422,w6588]
theorem b5_5017 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5017 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false)),(false,(2,true),(8,true)),(false,(4,true),(9,true))] s5_5017 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3619,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3619 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5018 : List (BitVec 512) := [w3628,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_5018 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5018 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_5018 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_5019 : List (BitVec 512) := [w3628,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_5019 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5019 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(7,true),(6,true)),(false,(3,true),(7,true)),(false,(9,true),(3,true))] s5_5019 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3628,v0_3766,v0_4926,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5020 : List (BitVec 512) := [w3629,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5020 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5020 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5020 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3629,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3629 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5021 : List (BitVec 512) := [w3631,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5021 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5021 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5021 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3631,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3631 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5022 : List (BitVec 512) := [w3634,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5022 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3634,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3634 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5023 : List (BitVec 512) := [w3635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5023 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5023 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5023 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3635,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3635 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5024 : List (BitVec 512) := [w3636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5024 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5024 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5024 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3636,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3636 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5025 : List (BitVec 512) := [w3638,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5025 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3638,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3638 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5026 : List (BitVec 512) := [w3639,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5026 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3639,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3639 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5027 : List (BitVec 512) := [w3640,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5027 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5027 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5027 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3640,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3640 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5028 : List (BitVec 512) := [w3641,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5028 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5028 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5028 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3641,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3641 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5029 : List (BitVec 512) := [w3645,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5029 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3645,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3645 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5030 : List (BitVec 512) := [w3646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5030 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5030 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5030 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3646,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3646 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5031 : List (BitVec 512) := [w3648,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5031 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5031 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5031 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3648,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3648 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5032 : List (BitVec 512) := [w3648,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b5_5032 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5032 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false))] s5_5032 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3648,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3648 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5033 : List (BitVec 512) := [w3648,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5033 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3648,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3648 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5034 : List (BitVec 512) := [w3652,w3766,w5135,w5393,w5698,w5769,w5956,w6389,w6422,w6588]
theorem b5_5034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5034 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true)),(false,(3,true),(6,true)),(false,(3,true),(9,true))] s5_5034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3652,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3652 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
