import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_138 : List (BitVec 512) := [w11,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_138 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_138 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false))] s4_138 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_11,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6912] (PetersenWireProjection.cons pc1_11 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6912 rfl))))))))))) (by decide +kernel)
def s4_321 : List (BitVec 512) := [w25,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_321 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(4,true),(0,false)),(false,(8,true),(0,true))] s4_321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_322 : List (BitVec 512) := [w25,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6832]
theorem b4_322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_322 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(8,true),(0,true))] s4_322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_323 : List (BitVec 512) := [w25,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_323 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(1,false),(8,true))] s4_323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_324 : List (BitVec 512) := [w25,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_324 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true))] s4_324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_325 : List (BitVec 512) := [w25,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_325 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true))] s4_325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2175,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2175 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_326 : List (BitVec 512) := [w25,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_326 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_327 : List (BitVec 512) := [w25,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_327 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(1,false))] s4_327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_328 : List (BitVec 512) := [w25,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_328 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_329 : List (BitVec 512) := [w25,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_329 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_330 : List (BitVec 512) := [w25,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_330 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_331 : List (BitVec 512) := [w25,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_331 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_332 : List (BitVec 512) := [w25,w2885,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_332 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,true))] s4_332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2885,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2885 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_333 : List (BitVec 512) := [w25,w2889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_333 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(4,true))] s4_333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_2889,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_2889 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_334 : List (BitVec 512) := [w25,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_334 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(2,true))] s4_334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3182,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3182 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_335 : List (BitVec 512) := [w25,w3186,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_335 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(3,true))] s4_335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3186,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3186 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_336 : List (BitVec 512) := [w25,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_336 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true))] s4_336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_337 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_337 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true))] s4_337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_338 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_338 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true))] s4_338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_339 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_339 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(0,false),(2,true))] s4_339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_340 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_340 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(0,false),(3,true))] s4_340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6549,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6549 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_341 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_341 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(0,false),(6,true))] s4_341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6567,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6567 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_342 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_342 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(2,true))] s4_342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6852] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6852 rfl))))))))))) (by decide +kernel)
def s4_343 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_343 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true))] s4_343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6857] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_344 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_344 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(6,true))] s4_344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6866] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_345 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_345 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true))] s4_345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_346 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_346 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false))] s4_346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6895] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6895 rfl))))))))))) (by decide +kernel)
def s4_347 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_347 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(6,true))] s4_347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6904] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6904 rfl))))))))))) (by decide +kernel)
def s4_348 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_348 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,false),(3,true))] s4_348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6910] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6910 rfl))))))))))) (by decide +kernel)
def s4_349 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_349 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,false),(4,true))] s4_349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6912] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6912 rfl))))))))))) (by decide +kernel)
def s4_350 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_350 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,false),(7,true))] s4_350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6917] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6917 rfl))))))))))) (by decide +kernel)
def s4_351 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_351 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(4,true),(2,true))] s4_351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6832] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_352 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_352 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(4,true),(3,true))] s4_352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_353 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_353 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(4,true),(6,true))] s4_353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_354 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_354 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(8,true),(2,true))] s4_354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_355 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_355 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(8,true),(6,true))] s4_355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6464,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_356 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_356 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(7,true),(3,true))] s4_356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_357 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_357 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(7,true),(6,true))] s4_357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_358 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_358 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(7,true),(6,true))] s4_358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_359 : List (BitVec 512) := [w25,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_359 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(8,true),(1,false))] s4_359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_536 : List (BitVec 512) := [w38,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588,w6904]
theorem b4_536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_536 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(1,false),(7,true))] s4_536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_2171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6588,v1_6904] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_2171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6904 rfl))))))))))) (by decide +kernel)
def s4_537 : List (BitVec 512) := [w38,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_537 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true))] s4_537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_538 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_538 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true))] s4_538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_539 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_539 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true))] s4_539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_540 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_540 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true))] s4_540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_541 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_541 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(3,true))] s4_541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6489,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6489 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_542 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_542 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_542 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,false),(7,true))] s4_542 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6567,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6567 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_543 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_543 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(2,true))] s4_543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6807] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6807 rfl))))))))))) (by decide +kernel)
def s4_544 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_544 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_544 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true))] s4_544 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6813] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_545 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_545 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(7,true))] s4_545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6866] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_546 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_546 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true))] s4_546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_547 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_547 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false))] s4_547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6895] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6895 rfl))))))))))) (by decide +kernel)
def s4_548 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_548 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(3,true),(0,false))] s4_548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6905] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6905 rfl))))))))))) (by decide +kernel)
def s4_549 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_549 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(4,true)),(false,(0,false),(4,true))] s4_549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6906] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6906 rfl))))))))))) (by decide +kernel)
def s4_550 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_550 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false))] s4_550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_551 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_551 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true))] s4_551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6917] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6917 rfl))))))))))) (by decide +kernel)
def s4_552 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_552 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_552 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(4,true))] s4_552 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_553 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_553 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(8,true))] s4_553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_554 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_554 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(6,true),(3,true))] s4_554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_555 : List (BitVec 512) := [w38,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6785]
theorem b4_555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_555 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(6,true),(7,true))] s4_555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588,v1_6785] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_964 : List (BitVec 512) := [w155,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_964 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true))] s4_964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_155,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_967 : List (BitVec 512) := [w160,w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_967 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_985 : List (BitVec 512) := [w160,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_986 : List (BitVec 512) := [w160,w2694,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_2694,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_2694 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
