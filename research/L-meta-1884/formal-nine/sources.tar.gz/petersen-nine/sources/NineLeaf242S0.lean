import NinePin242
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4088 : List (BitVec 512) := [w2468,w3766,w4344,w4588,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4088 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4088 := by
  intro m le c
  apply rejects_sound r242 i6 5 tgt (small242 adj) hot242 [] s5_4088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v242_2468,v242_3766,v242_4344,v242_4588,v242_4716,v242_5135,v242_5585,v242_5956,v242_6300,v242_6588] (PetersenWireProjection.cons pc242_2468 (PetersenWireProjection.cons pc242_3766 (PetersenWireProjection.cons pc242_4344 (PetersenWireProjection.cons pc242_4588 (PetersenWireProjection.cons pc242_4716 (PetersenWireProjection.cons pc242_5135 (PetersenWireProjection.cons pc242_5585 (PetersenWireProjection.cons pc242_5956 (PetersenWireProjection.cons pc242_6300 (PetersenWireProjection.cons pc242_6588 rfl)))))))))) (by decide +kernel)
def s5_4092 : List (BitVec 512) := [w2468,w3766,w4344,w4595,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4092 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4092 := by
  intro m le c
  apply rejects_sound r242 i6 5 tgt (small242 adj) hot242 [] s5_4092 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v242_2468,v242_3766,v242_4344,v242_4595,v242_4716,v242_5135,v242_5585,v242_5956,v242_6300,v242_6588] (PetersenWireProjection.cons pc242_2468 (PetersenWireProjection.cons pc242_3766 (PetersenWireProjection.cons pc242_4344 (PetersenWireProjection.cons pc242_4595 (PetersenWireProjection.cons pc242_4716 (PetersenWireProjection.cons pc242_5135 (PetersenWireProjection.cons pc242_5585 (PetersenWireProjection.cons pc242_5956 (PetersenWireProjection.cons pc242_6300 (PetersenWireProjection.cons pc242_6588 rfl)))))))))) (by decide +kernel)
end NineCert
