import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5189 : List (BitVec 512) := [w3766,w3936,w4344,w4760,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5189 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5189 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,false),(7,true)),(false,(0,true),(3,true))] s5_5189 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4760,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4760 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5190 : List (BitVec 512) := [w3766,w3936,w4344,w4768,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_5190 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5190 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(2,true)),(false,(1,true),(5,true))] s5_5190 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4768,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4768 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5191 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5191 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5191 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5191 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5192 : List (BitVec 512) := [w3766,w3936,w4344,w5135,w5393,w5585,w5956,w6219,w6300,w6588]
theorem b5_5192 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5192 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,false)),(false,(0,true),(3,true))] s5_5192 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6219,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6219 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5193 : List (BitVec 512) := [w3766,w3936,w4589,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5193 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5193 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(2,true),(0,true))] s5_5193 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4589,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4589 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5194 : List (BitVec 512) := [w3766,w3936,w4591,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5194 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(2,true))] s5_5194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4591,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4591 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5195 : List (BitVec 512) := [w3766,w3936,w4592,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5195 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5195 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(2,true),(0,true))] s5_5195 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4592,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4592 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5196 : List (BitVec 512) := [w3766,w3936,w4596,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5196 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5196 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(2,true))] s5_5196 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4596,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4596 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5197 : List (BitVec 512) := [w3766,w3936,w4597,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5197 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5197 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(2,true))] s5_5197 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4597,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4597 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5198 : List (BitVec 512) := [w3766,w3936,w4599,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5198 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5198 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,true))] s5_5198 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4599,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4599 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5199 : List (BitVec 512) := [w3766,w3937,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5199 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5199 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5199 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3937,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3937 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5200 : List (BitVec 512) := [w3766,w3942,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5200 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5200 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5200 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3942,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3942 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5204 : List (BitVec 512) := [w3766,w3950,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5204 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5204 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5204 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3950,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3950 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5205 : List (BitVec 512) := [w3766,w3951,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5205 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5205 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5205 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3951,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3951 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5206 : List (BitVec 512) := [w3766,w3952,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5206 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5206 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5206 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3952,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3952 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5207 : List (BitVec 512) := [w3766,w3954,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5207 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5207 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5207 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3954,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3954 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5208 : List (BitVec 512) := [w3766,w3956,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_5208 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5208 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5208 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3956,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3956 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5209 : List (BitVec 512) := [w3766,w3957,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5209 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5209 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5209 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3957,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3957 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5210 : List (BitVec 512) := [w3766,w3958,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5210 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3958,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3958 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5218 : List (BitVec 512) := [w3766,w3969,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5218 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5218 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3969,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3969 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5219 : List (BitVec 512) := [w3766,w3970,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5219 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5219 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3970,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3970 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5220 : List (BitVec 512) := [w3766,w3971,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5220 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5220 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3971,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3971 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5221 : List (BitVec 512) := [w3766,w3972,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5221 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5221 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5221 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3972,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3972 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5222 : List (BitVec 512) := [w3766,w3974,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5222 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5222 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5222 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3974,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3974 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5223 : List (BitVec 512) := [w3766,w3975,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5223 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5223 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5223 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3975,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3975 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5224 : List (BitVec 512) := [w3766,w3977,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_5224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3977,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3977 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5225 : List (BitVec 512) := [w3766,w3978,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5225 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5225 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5225 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3978,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3978 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5226 : List (BitVec 512) := [w3766,w3979,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5226 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5226 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5226 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3979,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3979 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5227 : List (BitVec 512) := [w3766,w3979,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_5227 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5227 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s5_5227 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3979,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3979 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5235 : List (BitVec 512) := [w3766,w3990,w4344,w4716,w5200,w5393,w5585,w6300,w6522,w6588]
theorem b5_5235 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5235 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(7,true),(8,true)),(false,(1,true),(5,true))] s5_5235 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3990,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3990 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5236 : List (BitVec 512) := [w3766,w3990,w4344,w4716,w5200,w5393,w5698,w5956,w6300,w6588]
theorem b5_5236 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5236 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_5236 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3990,v3_4344,v3_4716,v3_5200,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3990 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5237 : List (BitVec 512) := [w3766,w4000,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5237 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5237 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_5237 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4000,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4000 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5238 : List (BitVec 512) := [w3766,w4000,w4583,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b5_5238 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5238 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s5_5238 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4000,v3_4583,v3_4716,v3_4800,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4000 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4800 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5239 : List (BitVec 512) := [w3766,w4002,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5239 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5239 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_5239 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4002,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4002 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5240 : List (BitVec 512) := [w3766,w4002,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5240 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5240 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_5240 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4002,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4002 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_5243 : List (BitVec 512) := [w3766,w4039,w4589,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_5243 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5243 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_5243 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4039,v3_4589,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4039 (PetersenWireProjection.cons pc3_4589 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5245 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5245 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5246 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5246 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5246 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5246 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5247 : List (BitVec 512) := [w3766,w4079,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_5247 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5247 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_5247 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5248 : List (BitVec 512) := [w3766,w4079,w4544,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5248 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(5,true),(0,true))] s5_5248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4544,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4544 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5249 : List (BitVec 512) := [w3766,w4079,w4557,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5249 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5249 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(5,true))] s5_5249 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4557,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4557 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5250 : List (BitVec 512) := [w3766,w4079,w4561,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5250 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(5,true))] s5_5250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4561,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4561 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5251 : List (BitVec 512) := [w3766,w4079,w4571,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5251 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_5251 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4571,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4571 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5252 : List (BitVec 512) := [w3766,w4080,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5252 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5252 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5252 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4080,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4080 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5253 : List (BitVec 512) := [w3766,w4081,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5253 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4081,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4081 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5254 : List (BitVec 512) := [w3766,w4083,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5254 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5254 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5254 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4083,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4083 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5255 : List (BitVec 512) := [w3766,w4084,w4571,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5255 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5255 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s5_5255 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4084,v3_4571,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4084 (PetersenWireProjection.cons pc3_4571 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5256 : List (BitVec 512) := [w3766,w4084,w4716,w4796,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5256 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s5_5256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4084,v3_4716,v3_4796,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4084 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4796 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5258 : List (BitVec 512) := [w3766,w4086,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5258 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5258 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4086,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4086 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5259 : List (BitVec 512) := [w3766,w4088,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5259 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5259 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5259 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4088,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4088 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5260 : List (BitVec 512) := [w3766,w4089,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5260 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4089,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4089 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5261 : List (BitVec 512) := [w3766,w4090,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5261 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5261 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5261 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4090,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4090 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5262 : List (BitVec 512) := [w3766,w4092,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5262 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5262 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5262 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4092,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4092 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5263 : List (BitVec 512) := [w3766,w4093,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5263 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5263 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5263 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4093,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4093 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5264 : List (BitVec 512) := [w3766,w4094,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5264 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5264 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5264 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4094,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4094 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5265 : List (BitVec 512) := [w3766,w4094,w4716,w5135,w5393,w5621,w5698,w5956,w6300,w6588]
theorem b5_5265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_5265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4094,v3_4716,v3_5135,v3_5393,v3_5621,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4094 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5621 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5266 : List (BitVec 512) := [w3766,w4095,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5266 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5266 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5266 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4095,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4095 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5267 : List (BitVec 512) := [w3766,w4096,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5267 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5267 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5267 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4096,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4096 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5268 : List (BitVec 512) := [w3766,w4099,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5268 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5268 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5268 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4099,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4099 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5269 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5269 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5269 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5269 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5270 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5270 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5270 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s5_5270 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5279 : List (BitVec 512) := [w3766,w4119,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5279 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5279 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_5279 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4119,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4119 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5280 : List (BitVec 512) := [w3766,w4119,w4583,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b5_5280 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5280 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s5_5280 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4119,v3_4583,v3_4716,v3_5135,v3_5585,v3_5652,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4119 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5652 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5281 : List (BitVec 512) := [w3766,w4120,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5281 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5281 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5281 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4120,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4120 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
