import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_14734 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_14734 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14734 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s4_14734 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_14735 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_14735 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14735 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(4,true),(8,true))] s4_14735 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_14736 : List (BitVec 512) := [w3766,w3945,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14736 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14741 : List (BitVec 512) := [w3766,w3947,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14741 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3947,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3947 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14742 : List (BitVec 512) := [w3766,w3947,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14742 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3947,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3947 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14743 : List (BitVec 512) := [w3766,w3947,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_14743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14743 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s4_14743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3947,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3947 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14758 : List (BitVec 512) := [w3766,w3963,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14758 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s4_14758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3963,v4_4344,v4_4403,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3963 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4403 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14759 : List (BitVec 512) := [w3766,w3963,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14759 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_14759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3963,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3963 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14760 : List (BitVec 512) := [w3766,w3963,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14760 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3963,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3963 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14761 : List (BitVec 512) := [w3766,w3965,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14761 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14761 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s4_14761 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3965,v4_4344,v4_4413,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3965 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4413 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14762 : List (BitVec 512) := [w3766,w3965,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14762 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14762 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14762 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3965,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3965 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14763 : List (BitVec 512) := [w3766,w3966,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14763 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s4_14763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3966,v4_4344,v4_4415,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3966 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4415 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14764 : List (BitVec 512) := [w3766,w3966,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14764 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3966,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3966 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14765 : List (BitVec 512) := [w3766,w3968,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14765 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_14765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14766 : List (BitVec 512) := [w3766,w3968,w4344,w4392,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14766 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_14766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4392,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14767 : List (BitVec 512) := [w3766,w3968,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14767 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_14767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4402,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14768 : List (BitVec 512) := [w3766,w3968,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14768 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_14768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4412,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14769 : List (BitVec 512) := [w3766,w3968,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14769 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14770 : List (BitVec 512) := [w3766,w3968,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14770 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14771 : List (BitVec 512) := [w3766,w3968,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14771 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14788 : List (BitVec 512) := [w3766,w3983,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14788 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(4,true))] s4_14788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3983,v4_4344,v4_4428,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3983 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4428 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14789 : List (BitVec 512) := [w3766,w3983,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14789 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true))] s4_14789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3983,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3983 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14790 : List (BitVec 512) := [w3766,w3983,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14790 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3983,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3983 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14791 : List (BitVec 512) := [w3766,w3986,w4344,w4431,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14791 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_14791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3986,v4_4344,v4_4431,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3986 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4431 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14792 : List (BitVec 512) := [w3766,w3986,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14792 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3986,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3986 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14793 : List (BitVec 512) := [w3766,w3987,w4344,w4433,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14793 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_14793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3987,v4_4344,v4_4433,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3987 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4433 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14794 : List (BitVec 512) := [w3766,w3987,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14794 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3987,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3987 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14795 : List (BitVec 512) := [w3766,w3989,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14795 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(3,true))] s4_14795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4426,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4426 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14796 : List (BitVec 512) := [w3766,w3989,w4344,w4426,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14796 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(3,true))] s4_14796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4426,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4426 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14797 : List (BitVec 512) := [w3766,w3989,w4344,w4427,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14797 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(0,true),(3,true))] s4_14797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4427,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4427 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14798 : List (BitVec 512) := [w3766,w3989,w4344,w4430,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14798 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,false)),(false,(0,true),(3,true))] s4_14798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4430,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4430 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14799 : List (BitVec 512) := [w3766,w3989,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14799 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14800 : List (BitVec 512) := [w3766,w3989,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14800 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14800 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14800 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14801 : List (BitVec 512) := [w3766,w3989,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14801 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_15872 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w4737,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15872 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_4737,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4737 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15875 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w4930,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15875 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_4930,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4930 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15885 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5613,w5956,w6300,w6588]
theorem b4_15885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15885 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5613,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15890 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_15890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15890 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_15901 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_15901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15901 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15910 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_15910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15910 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15919 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15919 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_15927 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_15927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15927 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_15927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_15943 : List (BitVec 512) := [w3766,w4344,w4402,w4716,w4931,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15943 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_15943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4402,v4_4716,v4_4931,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4931 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15957 : List (BitVec 512) := [w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15957 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_15957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4402,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15971 : List (BitVec 512) := [w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_15971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15971 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_15971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4402,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_15980 : List (BitVec 512) := [w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15980 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_15980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4402,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_15987 : List (BitVec 512) := [w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_15987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15987 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(3,true))] s4_15987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4402,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4402 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_16080 : List (BitVec 512) := [w3766,w4344,w4412,w4716,w4933,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16080 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_16080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4412,v4_4716,v4_4933,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4933 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16093 : List (BitVec 512) := [w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_16093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16093 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_16093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4412,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16099 : List (BitVec 512) := [w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16099 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_16099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4412,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16114 : List (BitVec 512) := [w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16114 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_16114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4412,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_16121 : List (BitVec 512) := [w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_16121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16121 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(3,true))] s4_16121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4412,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4412 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_16274 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w4948,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16274 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_4948,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4948 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16288 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5769,w6101,w6300,w6588]
theorem b4_16288 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16288 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16288 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16297 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16297 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16297 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16297 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16307 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16307 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16318 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16318 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_16326 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_16326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16326 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_16326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_16344 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w4949,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16344 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(3,true))] s4_16344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4499,v4_4716,v4_4949,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4499 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4949 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16357 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_16357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16357 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(3,true))] s4_16357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4499,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4499 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16362 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16362 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(3,true))] s4_16362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4499,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4499 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_16379 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16379 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(3,true))] s4_16379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4499,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4499 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_16385 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_16385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16385 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(3,true))] s4_16385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4499,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4499 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_16445 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w4951,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16445 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,false)),(false,(0,true),(3,true))] s4_16445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4515,v4_4716,v4_4951,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4515 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4951 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
